﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using Oracle.DataAccess.Client;
using MapfreMMX.oracle;
using MapfreMMX.Seguridad;
using MapfreMMX.util;
using System.IO;

public partial class appAcceso : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Usuario objUsuario = null;
        WebLogin objAcceso = new WebLogin();
        DataRow outRow;

        if (!IsPostBack)
        {
            try
            {
                Session.Clear();
                if (Request["appID"] != null)
                {
                    using (OracleConnection conexion = MConexion.getConexion("connSegApp"))
                    {
                        MapfreMMX.Seguridad.GUID.ClsGuid clsGuid = new MapfreMMX.Seguridad.GUID.ClsGuid();
                        outRow = clsGuid.getToken(Request["appID"], conexion);
                    }

                    if (outRow.ItemArray[3] != null && outRow.ItemArray[3] != System.DBNull.Value)
                    {
                        MemoryStream mStream = new MemoryStream((byte[])outRow[3]);
                        IFormatter formatter = new BinaryFormatter();
                        objUsuario = (Usuario)formatter.Deserialize(mStream);
                        if (objUsuario != null)
                        {
                            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
                            {
                                objAcceso.cargaDatosAgente(objUsuario, conexion);
                            }
                            Session.Add("sUSUARIO", objUsuario);
                        }

                        Session["tipoCambioUSD"] = Request["usd"];
                        Session["tipoCambioUDIS"] = Request["udis"];

                        if (!(Request["app"] == null))
                        {
                            string newUrl = Request["app"];
                            if ((Request.QueryString.Keys.Count > 2))
                            {
                                foreach (string parametro in Request.QueryString.AllKeys)
                                {
                                    if (parametro != "app" & parametro != "appID" & parametro != "usd" & parametro != "udis")
                                    {
                                        newUrl += "&" + parametro + "=" + Request[parametro];
                                    }
                                }
                            }
                            Response.Redirect(newUrl, false);
                        }
                        else
                        {
                            Response.Redirect(outRow["p_url_menu"].ToString(), false);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
