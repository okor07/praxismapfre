﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

/// <summary>
/// Summary description for TWCalendario.
/// </summary>
public partial class TWCalendario : System.Web.UI.Page
{

    //private object designerPlaceholderDeclaration; 
    public System.DateTime strfecha1anio;
    public string bandera = "";
    public string strFormName;
    public object strCtrlName;
    public object strCtrlName2;
    public object strCtrlName3;
    public object strSelectedDate;
    public object strSelectedDate2;
    public object strSelectedDate3;
    public string ValFec;


    private void Page_Load(object sender, System.EventArgs e)
    {
        // Put user code to initialize the page here

        ValFec = Request.QueryString["ValFec"];
        if (ValFec == null) ValFec = "";
        if (!(IsPostBack))
        {


            // agregar en el querystring la var "aniosAnteriores" como true, para 
            // calendario factura y false para todos los demás.

            if (Request.QueryString["anioAnt"] == "S")
            {
                cargaComboAnio(true);
            }
            else
            {
                cargaComboAnio(false);
            }

            // Se configura el dropdownlist del anio y mes actuales
            if (ValFec == "")
            {
                ddlMonth.Items.FindByValue(Convert.ToString(DateTime.Today.Month)).Selected = true;
                ddlYear.Items.FindByValue(Convert.ToString(DateTime.Today.Year)).Selected = true;
            }
            else
            {
                ddlMonth.Items.FindByValue(Convert.ToInt32(ValFec.Substring(3, 2)).ToString()).Selected = true;
                ddlYear.Items.FindByValue(ValFec.Substring(6, 4)).Selected = true;
            }
        }

        // Se almacena la fecha seleccionada en una cadena temporal
        // Se almacena el nombre de la forma y el del control en 2 cadenas de 
        //los valores en el query string
        strfecha1anio = myCalendar.SelectedDate;
        strfecha1anio = strfecha1anio.AddMonths(Convert.ToInt32(Request.QueryString["Meses"]));

        strSelectedDate = myCalendar.SelectedDate.ToString("dd/MM/yyyy");
        strSelectedDate2 = myCalendar.SelectedDate.AddYears(1).ToString("MM/dd/yyyy");
        strSelectedDate3 = myCalendar.SelectedDate.AddYears(1).ToString("MM/dd/yyyy");

        strFormName = Request.QueryString["FormName"];
        strCtrlName = Request.QueryString["CtrlName"];
        strCtrlName2 = Request.QueryString["CtrlName2"];
        strCtrlName3 = Request.QueryString["CtrlName3"];

        if (ValFec != "")
        {
            myCalendar.SelectedDate = Convert.ToDateTime(ValFec);
            myCalendar.VisibleDate = Convert.ToDateTime(ValFec);
        }

    }


    #region Web Form Designer generated code
    override protected void OnInit(EventArgs e)
    {
        //
        // CODEGEN: This call is required by the ASP.NET Web Form Designer.
        //

        InitializeComponent();
        base.OnInit(e);
    }

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.ddlMonth.SelectedIndexChanged += new System.EventHandler(this.ddlMonth_SelectedIndexChanged);
        this.ddlYear.SelectedIndexChanged += new System.EventHandler(this.ddlYear_SelectedIndexChanged);
        this.myCalendar.DayRender += new System.Web.UI.WebControls.DayRenderEventHandler(this.myCalendar_DayRender);
        this.myCalendar.SelectionChanged += new System.EventHandler(this.myCalendar_SelectionChanged);
        this.Load += new System.EventHandler(this.Page_Load);

    }
    #endregion

    public void myCalendar_SelectionChanged(object sender, System.EventArgs e)
    {
        strfecha1anio = myCalendar.SelectedDate;
        strfecha1anio = strfecha1anio.AddMonths(Convert.ToInt32(Request.QueryString["Meses"]));

        strSelectedDate = myCalendar.SelectedDate.ToString("dd/MM/yyyy");
        strSelectedDate2 = strfecha1anio.ToString("dd/MM/yyyy");
        strSelectedDate3 = strfecha1anio.ToString("dd/MM/yyyy");

        bandera = strSelectedDate.ToString();
        myCalendar.VisibleDate = new DateTime(System.Convert.ToInt32(ddlYear.SelectedItem.Value), System.Convert.ToInt32(ddlMonth.SelectedItem.Value), 1);
    }

    void ddl_SelectedIndexChanged(object Sender, EventArgs e)
    {
        myCalendar.VisibleDate = new DateTime(System.Convert.ToInt32(ddlYear.SelectedItem.Value), System.Convert.ToInt32(ddlMonth.SelectedItem.Value), 1);
    }


    /// <summary>Llena la lista desplegable de Años</summary>
    /// <param name="blAniosAnteriores">Indica si es calendario factura.</param>
    private void cargaComboConfig(bool blAniosAnteriores)
    {
        int intAtras = 0;
        int intAdelante = 0;

        intAtras = Convert.ToInt32(ConfigurationSettings.AppSettings["aniosAtras"]);
        intAdelante = Convert.ToInt32(ConfigurationSettings.AppSettings["aniosAdelante"]);

        for (int i = intAdelante; i >= 0; i--)
        {
            ddlYear.Items.Add(Convert.ToString(DateTime.Today.Year + i));
        }

        if (blAniosAnteriores == true)
        {
            for (int i = 0; i <= intAtras - 1; i++)
            {
                ddlYear.Items.Add(Convert.ToString(DateTime.Today.Year - (i + 1)));
            }
        }

    }

    private void ddlMonth_SelectedIndexChanged(object sender, System.EventArgs e)
    {
        myCalendar.VisibleDate = new DateTime(System.Convert.ToInt32(ddlYear.SelectedItem.Value), System.Convert.ToInt32(ddlMonth.SelectedItem.Value), 1);
    }

    private void ddlYear_SelectedIndexChanged(object sender, System.EventArgs e)
    {
        myCalendar.VisibleDate = new DateTime(System.Convert.ToInt32(ddlYear.SelectedItem.Value), System.Convert.ToInt32(ddlMonth.SelectedItem.Value), 1);
    }


    public void myCalendar_DayRender(object sender, System.Web.UI.WebControls.DayRenderEventArgs e)
    {
        System.DateTime rangoInicial;
        System.DateTime rangoFinal;
        if (Request.QueryString["BackForward"] == "ADELANTE")
        {
            rangoInicial = System.Convert.ToDateTime(Request.QueryString[7]).AddMonths(-Convert.ToInt32((ConfigurationSettings.AppSettings["mesesAtras"])));
            rangoInicial = rangoInicial.AddDays(-1);

            // IBM 220606 
            //if (strCtrlName2 != null) 
            //if (strCtrlName2.ToString() != "")
            //{
            //    rangoFinal = System.Convert.ToDateTime(Request.QueryString[7]).AddMonths(Convert.ToInt32(ConfigurationSettings.AppSettings["mesesAdelante"]));
            //}
            //else
            //{
            rangoFinal = System.Convert.ToDateTime(Request.QueryString[7]).AddMonths(Convert.ToInt32(Request.QueryString["Meses"]));
            //}
        }
        else
        {
            //rangoInicial = Convert.ToDateTime("01/01/1980");
            //rangoFinal = DateTime.Today.AddYears(1);

            rangoInicial = System.Convert.ToDateTime(Request.QueryString[7]);
            rangoInicial = rangoInicial.AddMonths(-(Convert.ToInt32(Request.QueryString["Meses"])));
            //rangoInicial = rangoInicial.AddDays(-(Convert.ToInt32(Request.QueryString["Meses"]) * 30));
            rangoInicial = rangoInicial.AddDays(-0);
            rangoFinal = System.Convert.ToDateTime(Request.QueryString[7]);
            //rangoFinal = rangoFinal.AddMonths(Convert.ToInt32(Request.QueryString["Meses"]));
            if (Request.QueryString["BackForward"] == "REGLASVIDA")
            {
                rangoInicial = System.Convert.ToDateTime(Request.QueryString[7]).AddMonths(-(Convert.ToInt32(Request.QueryString["Meses"])));
                rangoInicial = rangoInicial.AddDays(-1);
                rangoFinal = System.Convert.ToDateTime(Request.QueryString[7]).AddMonths(Convert.ToInt32(Request.QueryString["Meses"]));
            }
        }

        //if (e.Day.Date >= rangoInicial & e.Day.Date <= rangoFinal) 
        if (e.Day.Date > rangoInicial & e.Day.Date <= rangoFinal)
        {
            e.Day.IsSelectable = true;
        }
        else
        {
            e.Day.IsSelectable = false;
        }
    }

    private void cargaComboAnio(bool blAniosAnteriores)
    {
        if (blAniosAnteriores == true)
        {
            int anioIni = System.Convert.ToDateTime(Request.QueryString[6]).Year - (Convert.ToInt32(Request.QueryString["Meses"]) / 12);
            int anioFin = System.Convert.ToDateTime(Request.QueryString[7]).Year;
            for (int i = anioFin; i >= anioIni; i--)
            {
                ddlYear.Items.Add(i.ToString());
            }
        }
        else
        {
            int anioIni = System.Convert.ToDateTime(Request.QueryString[6]).Year;
            int anioFin = System.Convert.ToDateTime(Request.QueryString[7]).Year + (Convert.ToInt32(Request.QueryString["Meses"]) / 12);
            for (int i = anioIni; i <= anioFin; i++)
            {
                ddlYear.Items.Add(i.ToString());
            }
        }
    }
}