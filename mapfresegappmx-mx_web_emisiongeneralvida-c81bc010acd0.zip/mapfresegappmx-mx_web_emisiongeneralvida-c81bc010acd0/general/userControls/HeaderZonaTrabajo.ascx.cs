﻿using System;
using MapfreMMX.util;

public partial class general_userControls_HeaderZonaTrabajo : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Usuario objUsuario = (Usuario)(Session["sUSUARIO"]);
        if (objUsuario == null)
        {
            Response.Redirect("/zonaliados/SessionOFF.aspx");
        }
        lblFecha.Text = DateTime.Now.ToLongDateString();
        lblFecha2.Text = objUsuario.ULT_ACCESO;
        lblFechaMovil.Text = "Hoy es: " + DateTime.Now.ToLongDateString() + " - " + objUsuario.ULT_ACCESO;
    }
}