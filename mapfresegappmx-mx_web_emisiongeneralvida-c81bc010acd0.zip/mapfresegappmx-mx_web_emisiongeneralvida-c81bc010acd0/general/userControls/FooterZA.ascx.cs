﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class general_userControls_FooterZA : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblAño.Text = DateTime.Now.Year.ToString();
        lblUSD.Text = (string)Session["tipoCambioUSD"];
        lblUDIS.Text = (string)Session["tipoCambioUDIS"];
    }
}