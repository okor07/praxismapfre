﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MapfreMMX.util;

public partial class general_userControls_MenuZonaTrabajo : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Usuario objUsuario = null;
        objUsuario = (Usuario)Session["sUSUARIO"];
        string[] strMenu;
        strMenu = objUsuario.CONTRASENIA.Split('|');
        litMenuLateral.Text = strMenu[2].ToString();
    }
}