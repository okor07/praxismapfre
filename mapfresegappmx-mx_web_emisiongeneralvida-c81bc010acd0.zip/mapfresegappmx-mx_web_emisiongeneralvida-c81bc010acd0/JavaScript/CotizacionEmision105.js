﻿function Cotiza_105() {
//03052018
// document.getElementById("divPrimas105").style.display = "block";
//            document.getElementById("divPrimas105").innerHTML = "<table id='Coberturas' border='1' cellspacing='0' cellpadding='0' ><tr class='cabeza_tabla_small_gray'><td></td><td>CONTADO</td><td>SEMESTRAL</td><td>TRIMESTRAL</td><td>MENSUAL</td></tr><tr class='cuerpo_tabla_small_gray' ><td align='left'>PRIMA NETA</td><td align='right' style='width: 80px' >1559</td><td align='right' style='width: 80px' >1559</td><td align='right' style='width: 80px' >1559</td><td align='right' style='width: 80px' >1559</td></tr><tr class='cuerpo_tabla_small_gray' ><td align='left'>RECARGO FIJO</td><td align='right' style='width: 80px' >0</td><td align='right' style='width: 80px' >0</td><td align='right' style='width: 80px' >0</td><td align='right' style='width: 80px' >0</td></tr><tr class='cuerpo_tabla_small_gray' ><td align='left'>RECARGO POR PAGO FRACCIONADO</td><td align='right' style='width: 80px' >0</td><td align='right' style='width: 80px' >38</td><td align='right' style='width: 80px' >54</td><td align='right' style='width: 80px' >70</td></tr><tr class='cuerpo_tabla_small_gray' ><td align='left'>DERECHOS DE POLIZA</td><td align='right' style='width: 80px' >60</td><td align='right' style='width: 80px' >60</td><td align='right' style='width: 80px' >60</td><td align='right' style='width: 80px' >60</td></tr><tr class='cuerpo_tabla_small_gray' ><td align='left'>PRIMA TOTAL</td><td align='right' style='width: 80px' >1619</td><td align='right' style='width: 80px' >1658</td><td align='right' style='width: 80px' >1674</td><td align='right' style='width: 80px' >1689</td></tr></table>";
    if (Valida_cot105()) {
        armaCadena_105("C", "PRIMAS");
    }
}
function Valida_cot105() {
    if (document.getElementById("drpAgente").options.length > 1) {
        if (selIndiceCtrl("drpAgente") < 1) {
            alert("DEBES SELECCIONAR UN AGENTE");
            focusCtrl("drpAgente");
            return false;
        }
    }
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        if (selIndiceCtrl("drpPolizaGrupo") < 1) {
            alert("DEBES SELECCIONAR UNA P\u00d3LIZA GRUPO");
            focusCtrl("drpPolizaGrupo");
            return false;
        }
        if (selIndiceCtrl("drpContrato") < 1) {
            alert("DEBES SELECCIONAR UN CONTRATO");
            focusCtrl("drpContrato");
            return false;
        }
    }
    if (selIndiceCtrl("drpMoneda") < 1) {
        alert("DEBES SELECCIONAR UNA MONEDA");
        focusCtrl("drpMoneda");
        return false;
    }

    if (selIndiceCtrl("drpCrecimiento") < 1) {
        alert("DEBES SELECCIONAR EL CRECIMIENTO");
        focusCtrl("drpCrecimiento");
        return false;
    }
    if (document.getElementById("HiddenDeducible").value == "-1" || document.getElementById("HiddenDeducible").value == "") {
        alert("EXISTE UN PROBLEMA Y NO PUDO SER OBTENIDO EL DEDUCIBLE CON EL CRECIMIENTO SELECCIONADO");
        return false;
    }
    if (selIndiceCtrl("drpPlazo") < 1) {
        alert("DEBES SELECCIONAR EL PLAZO");
        focusCtrl("drpPlazo");
        return false;
    }

    if (selIndiceCtrl("drpComision") < 1) {
        alert("DEBES SELECCIONAR LA COMISI\u00d3N.");
        focusCtrl("drpComision");
        return false;
    }

    if (selIndiceCtrl("drpFormaPago") < 1) {
        alert("DEBES SELECCIONAR UNA FORMA DE PAGO");
        focusCtrl("drpFormaPago");
        return false;
    }
    if (selIndiceCtrl("drpTipoPago") < 1) {
        alert("DEBES SELECCIONAR UN TIPO DE PAGO.");
        focusCtrl("drpTipoPago");
        return false;
    }
    if (document.getElementById("dvCobertura105").innerHTML == "") {
        alert("NO SE HAN DEFINIDO LAS COBERTURAS");
        return false;
    }
    return true;
}
function armaCadena_105(oper) {
    Cargando(true);

    var token = document.getElementById("UscAsegCLM_hdnToken").value;
    var agente = selValorCtrl("drpAgente");
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var moneda = selValorCtrl("drpMoneda");
    var tip_regulariza = selValorCtrl("drpCrecimiento", 0);
    var pct_regulariza = selValorCtrl("drpCrecimiento", 1);
    var deducible = "";
    deducible = document.getElementById("HiddenDeducible").value;
    var comision = selValorCtrl("drpComision");
    var duracion = selValorCtrl("drpPlazo");
    MetodosAjax.setDuracion(duracion);
    var modalidad = document.getElementById("HiddenModalidad").value;
    var envio = 1; //Agente
    var formaPago = selValorCtrl("drpFormaPago");
    var tipoPago = selValorCtrl("drpTipoPago");

    var cod_gestor = valorCtrl("UscContCLM_hdnCodEntidad");
    var zona = valorCtrl("UscContCLM_hdnEdo"); //Estado del Contratante
    var localidad = valorCtrl("UscContCLM_hdnPoblacion"); //Poblacion del Contratante

    var fecEfecto = valorCtrl("txtFechaEfecto");
    var fecEfectoMas1Anio = MetodosAjax.sumarUnAnioAFecha(fecEfecto);
    var fecVcto = fecEfectoMas1Anio.value;

    var CLM_Cont = valorCtrl("UscContCLM_hdnCLM");
    var tip_docum = "CLM";
    var nombre_riesgo = "RIESGO COTIZACION";
    var mca_sexo = 1;
    var dctoAgente = selValorCtrl("drpAgente");
    var polizaGrupo = "";
    var contrato = "";
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        polizaGrupo = textoCtrl("drpPolizaGrupo");
        contrato = selValorCtrl("drpContrato");
    }
    CLM_Cont = "PRUEBA";
    tipoPago = "AG";
    cod_gestor = agente;
    formaPago = 1;
    var endosoEdu = "N";
    var num_riesgo = document.getElementById("txtNoAseg").value -1;

    //Datos de la póliza P2000030
    var arrDatosPoliza = new Array();
    arrDatosPoliza.push("COD_RAMO=" + ramo);
    arrDatosPoliza.push("COD_AGT=" + agente);
    arrDatosPoliza.push("NUM_RIESGOS=" + num_riesgo);
    arrDatosPoliza.push("COD_MON=" + moneda);
    arrDatosPoliza.push("COD_CUADRO_COM=" + document.getElementById("HidCuadroCom").value);
    arrDatosPoliza.push("COD_GESTOR=" + cod_gestor);
    arrDatosPoliza.push("TIP_REGULARIZA=" + tip_regulariza);
    arrDatosPoliza.push("COD_FRACC_PAGO=" + formaPago);
    arrDatosPoliza.push("COD_DOCUM=" + CLM_Cont);
    arrDatosPoliza.push("COD_COMPENSACION=1");
    arrDatosPoliza.push("MCA_IMPRESION=N");
    arrDatosPoliza.push("COD_MODALIDAD=" + modalidad);
    arrDatosPoliza.push("NOM_RIESGO=" + nombre_riesgo);
//    arrDatosPoliza.push("COD_SECTOR=1");
//    arrDatosPoliza.push("COD_NIVEL3_CAPTURA=4920");
// 

    var indAgt = 2;
    for (i = 2; i <= 5; i++) {
        var index = ((parseInt(i) < 10) ? "0" + i : i);
        if (document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave").value != "") {
            var codAgt = document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave").value
            var pctAgt = document.getElementById("dtgReferencias_ctl" + index + "_txtgrdPorcentaje").value
            if (i == 2)
                arrDatosPoliza.push("PCT_AGT=" + pctAgt);
            else {
                arrDatosPoliza.push("COD_AGT" + indAgt + "=" + codAgt);
                arrDatosPoliza.push("PCT_AGT" + indAgt + "=" + pctAgt);
                indAgt++;
            }
        }
    }
    arrDatosPoliza.push("TIP_DURACION=1");
    arrDatosPoliza.push("FEC_EFEC_POLIZA=" + fecEfecto);
    arrDatosPoliza.push("FEC_VCTO_POLIZA=" + fecVcto);
    arrDatosPoliza.push("FEC_EFEC_SPTO=" + fecEfecto);
    arrDatosPoliza.push("FEC_VCTO_SPTO=" + fecVcto);
    arrDatosPoliza.push("FEC_EFEC_RIESGO=" + fecEfecto);
    arrDatosPoliza.push("FEC_VCTO_RIESGO=" + fecVcto);
    arrDatosPoliza.push("TIP_DOCUM=" + tip_docum);
    arrDatosPoliza.push("TIP_GESTOR=" + tipoPago);

    //Datos variables P2000020
    var arrDatosVariables = new Array();
    var secu = 1;
    arrDatosVariables.push("COD_CAMPO=VAL_FONDO|VAL_CAMPO=7|VAL_COR_CAMPO=7|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=COD_ENVIO|VAL_CAMPO=1|VAL_COR_CAMPO=1|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=COD_ZONA|VAL_CAMPO=99|VAL_COR_CAMPO=99|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=TIP_DEDUCIBLE|VAL_CAMPO=" + deducible + "|VAL_COR_CAMPO=" + deducible + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=TIP_COMISION|VAL_CAMPO=" + comision + "|VAL_COR_CAMPO=" + comision + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=VAL_DURACION_SEGURO|VAL_CAMPO=" + duracion + "|VAL_COR_CAMPO=" + duracion + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=COD_MODALIDAD|VAL_CAMPO=" + modalidad + "|VAL_COR_CAMPO=" + modalidad + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=VAL_FOLIO_SOLICITUD|VAL_CAMPO=1|VAL_COR_CAMPO=1|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=NUM_EMPLEADO|VAL_CAMPO=1|VAL_COR_CAMPO=1|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=MCA_BENEFMEN|VAL_CAMPO=N|VAL_COR_CAMPO=N|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    if (ramo == 105) {
        arrDatosVariables.push("COD_CAMPO=TIP_SEGURO_VIDA|VAL_CAMPO=P|VAL_COR_CAMPO=P|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);  //------>C3<--------
        arrDatosVariables.push("COD_CAMPO=COD_PARENTESCO|VAL_CAMPO=38|VAL_COR_CAMPO=38|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);  //------>C3<--------
        //arrDatosVariables.push("COD_CAMPO=TIP_SEGURO_VIDA|VAL_CAMPO=999|VAL_COR_CAMPO=999|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);  //------>C3<--------

    }
    else {
        arrDatosVariables.push("COD_CAMPO=TIP_SEGURO_VIDA|VAL_CAMPO=" + tipo_seguro + "|VAL_COR_CAMPO=" + tipo_seguro +
            "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);  //------>C3<--------

    }
    //Datos coberturas P2000040
    var arrayDatosCobertura = new Array();
    var tabla = document.getElementById("tblBenef105");
    var cadena = "";
    var nombre = "";
    var secu = 1;

    if (tabla.rows.length == 0) {
        for (var i = 1; i < tabla.rows.length; i++) {
            var cell = tabla.rows[i].getElementsByTagName('td');
            //  osi      cadena += "COD_COB=" + cell[6].innerHTML+"|";
            cadena += "COD_COB=1000|";
            cadena += "SUMA_ASEG=" + cell[4].innerHTML + "|";
            cadena += "SUMA_ASEG_SPTO=" + cell[4].innerHTML + "|";
            cadena += "NUM_SECU=" + secu++ + "|";
            cadena += "COD_RAMO=" + ramo + "|";
            cadena += "MCA_BAJA_COB=N";
            arrayDatosCobertura.push(cadena);
        }
    }
    else {
        var suma = 0;
        for (var i = 1; i < tabla.rows.length; i++) {
            var cell = tabla.rows[i].getElementsByTagName('td');
            //  osi      cadena += "COD_COB=" + cell[6].innerHTML+"|";

            suma = parseInt(suma) + parseInt(cell[4].innerHTML);
            secu++;

        }
        cadena += "COD_COB=1000|";
        cadena += "SUMA_ASEG=" + suma + "|";
        cadena += "SUMA_ASEG_SPTO=" + suma + "|";
        cadena += "NUM_SECU=" + secu + "|";
        cadena += "COD_RAMO=" + ramo + "|";
        cadena += "MCA_BAJA_COB=N";
        arrayDatosCobertura.push(cadena);
    }



    //Datos Titular
    var arrDatosTitular = new Array();
    arrDatosTitular.push("COD_DOCUM=PRUEBA");
    arrDatosTitular.push("TIP_DOCUM=CLM");
    arrDatosTitular.push("TIP_BENEF=2");
    arrDatosTitular.push("NUM_SECU=1");

    var arrDatosContratante = new Array();
    //arrDatosContratante.push("FEC_NACIMIENTO=01/01/2007");
    //arrDatosContratante.push("MCA_SEXO=0");
    //arrDatosContratante.push("MCA_FUMA=0");
    //arrDatosContratante.push("TIP_BENEF=2");
    //arrDatosContratante.push("COD_PARENTESCO=38");
    cadena = "";
    cadena += "FEC_NACIMIENTO=01/01/2007|";
    cadena += "MCA_SEXO=0|";
    cadena += "MCA_FUMA=0|";
    cadena += "TIP_BENEF=2|";
    cadena += "COD_PARENTESCO=38";
    arrDatosContratante.push(cadena);
    //Datos beneficiario
    var arrDatosBenef = new Array();
    cadena = "";
    cadena += "TIP_DOCUM=CLM";
    cadena += "|COD_DOCUM=PRUEBA";
    cadena += "|PCT_PARTICIPACION=" + 100;
    cadena += "|TIP_BENEF=6";
    cadena += "|NUM_SECU=1";
    arrDatosBenef.push(cadena);
    var arrDatosBanco = new Array();

    MetodosAjax.setOperacion("COTIZACION");
    MetodosAjax.getCotizacion(oper, arrDatosPoliza, arrDatosVariables, arrayDatosCobertura, arrDatosContratante, arrDatosTitular, arrDatosBenef, arrDatosBanco, token, getCot_CallBack105);



}
function getCot_CallBack105(cotiza) {
    document.getElementById("divPrimas105").innerHTML = "";


    if (cotiza.error == null) {
        if (cotiza != null && cotiza.value != null && cotiza.value.Tables.length != 0) {
            var tablaPrimas = cotiza.value.Tables[5].Rows[0].TABLA_PRIMAS;
            //             document.getElementById("trPrim_105").style.display = "block";
            document.getElementById('divPrimas105').innerHTML = tablaPrimas;
            document.getElementById("HiddenPrimaTotal").value = cotiza.value.Tables[1].Rows[0].IMP_PRIMA_TOTAL;
            document.getElementById('UscContCLM_hdnNumCotizacion').value = cotiza.value.Tables[4].Rows[0].COTIZACION;
            Cargando(false);
            LlenarDatosDelSeguro_105();
            AjustarFrame();

            habilitarCtrl("btnEmite", true);


        } else {
            habilitarCtrl("btnEmite", false);
        }
    }

}

function Emite105() {
    if (validaPagina105("P")) {
        var prima1 = document.getElementById('HiddenPrimaTotal').value;

        MetodosAjax.setPRIMA(prima1);
        Cargando(true);
        var Modo = ValidarEmision105();

        if (Modo != "E") {

            armaCadena(Modo, "SOLICITUD");
        }
        else {
            Cargando(false);
            return;
        }
    }
}

function validaPagina105(oper) {
    var gridViewArch = document.getElementById("grdAdjuntarArchivo");

    if (gridViewArch == null && oper == "P") {
        alert("SE DEBE ADJUNTAR LA SOLICITUD FIRMADA POR EL CLIENTE, AS\u00cd COMO SU IDENTIFICACI\u00d3N OFICIAL.");
        return false;
    }

    if (document.getElementById("drpAgente").options.length > 1) {
        if (selIndiceCtrl("drpAgente") < 1) {
            alert("DEBES SELECCIONAR UN AGENTE");
            focusCtrl("drpAgente");
            return false;
        }
    }

    //    if(document.getElementById("txtEdad").value == "")
    //    {
    //        alert("DEBES CAPTURAR LA EDAD");
    //	    focusCtrl("txtEdad");
    //	    return false;
    //    }

    //Valida Edad Tope
    if (parseInt(document.getElementById("txtEdad").value) < parseInt(document.getElementById("HiddenEdadTopeMin").value) || parseInt(document.getElementById("txtEdad").value) > parseInt(document.getElementById("HiddenEdadTopeMax").value)) {
        if (document.getElementById("HiddenRamoRequest").value == "105") {
            if (selIndex("drpParentesco1") != 4 || selIndex("drpParentesco1") != 37) {
                alert("EDAD DE ACEPTACI\u00d3N DE " + document.getElementById("HiddenEdadTopeMin").value + " A " + document.getElementById("HiddenEdadTopeMax").value);
                document.getElementById("txtEdad").value = "";
                focusCtrl("txtEdad");
                return false;
            }
        } else {
            alert("EDAD DE ACEPTACI\u00d3N DE " + document.getElementById("HiddenEdadTopeMin").value + " A " + document.getElementById("HiddenEdadTopeMax").value);
            document.getElementById("txtEdad").value = "";
            focusCtrl("txtEdad");
            return false;
        }

    }

    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        if (selIndiceCtrl("drpPolizaGrupo") < 1) {
            alert("DEBES SELECCIONAR UNA P\u00d3LIZA GRUPO");
            focusCtrl("drpPolizaGrupo");
            return false;
        }
        if (selIndiceCtrl("drpContrato") < 1) {
            alert("DEBES SELECCIONAR UN CONTRATO");
            focusCtrl("drpContrato");
            return false;
        }
    }

    if (selIndiceCtrl("drpMoneda") < 1) {
        alert("DEBES SELECCIONAR UNA MONEDA");
        focusCtrl("drpMoneda");
        return false;
    }

    if (selIndiceCtrl("drpCrecimiento") < 1) {
        alert("DEBES SELECCIONAR EL CRECIMIENTO");
        focusCtrl("drpCrecimiento");
        return false;
    }

    if (document.getElementById("HiddenRamoRequest").value == "101") {
        if (selIndiceCtrl("drpDeducible") < 1) {
            alert("DEBES SELECCIONAR EL DEDUCIBLE.");
            focusCtrl("drpDeducible");
            return false;
        }
    }
    else {
        if (document.getElementById("HiddenDeducible").value == "-1" || document.getElementById("HiddenDeducible").value == "") {
            alert("EXISTE UN PROBLEMA Y NO PUDO SER OBTENIDO EL DEDUCIBLE CON EL CRECIMIENTO SELECCIONADO");
            return false;
        }
    }

    if (selIndiceCtrl("drpPlazo") < 1) {
        alert("DEBES SELECCIONAR EL PLAZO");
        focusCtrl("drpPlazo");
        return false;
    }

    if (selIndiceCtrl("drpComision") < 1) {
        alert("DEBES SELECCIONAR LA COMISI\u00d3N.");
        focusCtrl("drpComision");
        return false;
    }

    if (selIndiceCtrl("drpFormaPago") < 1) {
        alert("DEBES SELECCIONAR UNA FORMA DE PAGO");
        focusCtrl("drpFormaPago");
        return false;
    }

    if (selIndiceCtrl("drpTipoPago") < 1) {
        alert("DEBES SELECCIONAR UN TIPO DE PAGO.");
        focusCtrl("drpTipoPago");
        return false;
    }

    //    if(document.getElementById("DivCoberturas").innerHTML == "")
    //    {
    //        alert("NO SE HAN DEFINIDO LAS COBERTURAS");
    //	    return false;    
    //    }

    //    if(ValidarUnaCobMarcada())
    //    {
    //        alert("DEBES SELECCIONAR POR LO MENOS UNA COBERTURA");
    //        return false;     
    //    }

    var ctrlTxtSuma = ValidarVaciosEnSumasConCobMarcadas();
    if (ctrlTxtSuma != "") {
        alert("DEBE CAPTURAR UNA SUMA PARA LA COBERTURA MARCADA.");
        focusCtrl(ctrlTxtSuma);
        return false;
    }

    var totPart = document.all("HidTotalPorcentaje").value;
    if (parseFloat(totPart) < 100) {
        alert("EL PORCENTAJE DE AGENTES DEBE SUMAR 100%.");
        return false;
    }

    if (oper == "P") {

        //	    if(document.getElementById("divPrimas").innerHTML == "")
        //	    {
        //	        alert("DEBES DE OBTENER PRIMAS ANTES DE EMITIR");
        //            return false;        
        //	    }

        // Valida captura de los beneficiarios
        var gridView = document.getElementById("grdBeneficiarios").firstChild;
        if (gridView == null) {
            if (oper == "P") {
                alert("DEBES INGRESAR POR LO MENOS UN BENEFICIARIO");
                return false;
            }
        }
        else {
            // Valida la suma de porcentaje de los beneficiarios
            var tblBenef = MetodosAjax.obtieneTablaBenef();
            if (!validaPorcentaje(tblBenef, "beneficiarios"))
                return false;
        }
    }

    if (oper == "P") {
        //	    if(document.getElementById("txtPeso").value == "")
        //        {
        //            alert("DEBES CAPTURAR EL PESO");
        //	        focusCtrl("txtPeso");
        //	        return false;
        //        }

        //        if(document.getElementById("txtEstatura").value == "")
        //        {
        //            alert("DEBES CAPTURAR LA ESTATURA");
        //	        focusCtrl("txtEstatura");
        //	        return false;
        //        }

        //        if(document.getElementById("chkboxNo").checked == false && document.getElementById("chkboxSi").checked == false)
        //        {
        //            alert("DEBES CONTESTAR LA PREGUNTA DEL DEPORTE Y/O AFICI\u00d3N PELIGROSA");
        //            return false;
        //        }

        //        if(!validaCuest())
        //        {
        //            alert("DEBES CONTESTAR TODO EL CUESTIONARIO");
        //            return false;
        //        }
        if (ValidaServFune()) {
            return false;
        }

        if (document.getElementById("divCuestionario").innerHTML != "") {
            if (ValidarCuestionarioEnfRespiratorias()) {
                alert('DEBES CONTESTAR TODO EL CUESTIONARIO');
                return false;
            }
        }
    }

    return true;
}

function ValidarCuestionarioEnfRespiratorias() {

    if ($('#HiddenRamoRequest').val() == '101') {
        if ($('#txtPeso').val() == '') {
            alert('DEBES AGREGAR PESO');
            focusCtrl("txtPeso");
            return true;
        }

        if ($('#txtEstatura').val() == '') {
            alert('DEBES AGREGAR ESTATURA');
            focusCtrl("txtEstatura");
            return true;
        }
    }

    if (!document.getElementById("chkSi14").checked) {
        if (!document.getElementById("chkNo14").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi14");
            return true;
        }
    } else {
        if ($('#txt14').val() == '') {
            alert('DEBES ESCRIBIR ENFERMEDAD RESPIRATORIA');
            focusCtrl("txt14");
            return true;
        }
    }

    if (!document.getElementById("chkSi15").checked) {
        if (!document.getElementById("chkNo15").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi15");
            return true;
        }
    } else {
        if ($('#txt15').val() == '') {
            alert('DEBES ESCRIBIR ENFERMEDAD RESPIRATORIA');
            focusCtrl("txt15");
            return true;
        }
    }

    if (!document.getElementById("chkSi16").checked) {
        if (!document.getElementById("chkNo16").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi16");
            return true;
        }
    } else {
        if (!document.getElementById("chk16a").checked) {
            if (!document.getElementById("chk16b").checked) {
                if (!document.getElementById("chk16c").checked) {
                    if (!document.getElementById("chk16d").checked) {
                        if (!document.getElementById("chk16e").checked) {
                            if (!document.getElementById("chk16f").checked) {
                                if (!document.getElementById("chk16g").checked) {
                                    if (!document.getElementById("chk16h").checked) {
                                        alert('DEBES SELECCIONAR ALGUN SINTOMA');
                                        focusCtrl("chk16a");
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (!document.getElementById("chkSi17").checked) {
        if (!document.getElementById("chkNo17").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi17");
            return true;
        }
    } else {
        if ($('#txt17a').val() == 'Seleccione') {
            alert('DEBES SELECCIONAR EL TIPO DE PRUEBA');
            focusCtrl("txt17a");
            return true;
        } else {
            if ($('#txt17b').val() == '') {
                alert('DEBES SELECCIONAR LA FECHA DE LA PRUEBA');
                focusCtrl("txt17b");
                return true;
            }
        }
    }

    if (!document.getElementById("chkSi18").checked) {
        if (!document.getElementById("chkNo18").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi18");
            return true;
        }
    } else {
        if ($('#txt18a').val() == '') {
            alert('DEBES SELECCIONAR LA FECHA');
            focusCtrl("txt18a");
            return true;
        } else {
            if ($('#txt18b').val() == 'SELECCIONE') {
                alert('DEBES SELECCIONAR TIPO DE ATENCIÓN');
                focusCtrl("txt18b");
                return true;
            } else {
                if ($('#txt18c').val() == '') {
                    alert('DEBES AGREGAR EL TRATAMIENTO');
                    focusCtrl("txt18c");
                    return true;
                }
            }
        }
    }

    if (!document.getElementById("chkSi19").checked) {
        if (!document.getElementById("chkNo19").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi19");
            return true;
        }
    } else {
        if ($('#txt19a').val() == 'Seleccione') {
            alert('DEBES SELECCIONAR EL TIPO DE PRUEBA');
            focusCtrl("txt19a");
            return true;
        } else {
            if ($('#txt19b').val() == '') {
                alert('DEBES SELECCIONAR LA FECHA DE LA PRUEBA');
                focusCtrl("txt19b");
                return true;
            }
        }
    }

    if (!document.getElementById("chkSi20").checked) {
        if (!document.getElementById("chkNo20").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi20");
            return true;
        }
    } else {
        if ($('#txt20a').val() == '') {
            alert('DEBES ESCRIBIR EL TIPO DE SECUELA');
            focusCtrl("txt20a");
            return true;
        } else {
            if ($('#txt20b').val() == '') {
                alert('DEBES ESCRIBIR TRATAMIENTO MEDICO');
                focusCtrl("txt20b");
                return true;
            } else {
                if ($('#txt20c').val() == '') {
                    alert('DEBES ESCRIBIR ESTADO ACTUAL');
                    focusCtrl("txt20c");
                    return true;
                }
            }
        }
    }

    if (!document.getElementById("chkSi21").checked) {
        if (!document.getElementById("chkNo21").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi21");
            return true;
        }
    } else {
        if ($('#txt21').val() == '') {
            alert('DEBES SELECCIONAR LA FECHA QUE ESTUVISTE EN CUARENTENA');
            focusCtrl("txt21");
            return true;
        }
    }

    if (!document.getElementById("chkSi22").checked) {
        if (!document.getElementById("chkNo22").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi22");
            return true;
        }
    } else {
        if ($('#txt22a').val() == '') {
            alert('DEBES SELECCI0NAR LA FECHA QUE VIAJO');
            focusCtrl("txt22a");
            return true;
        } else {
            if ($('#txt22b').val() == 'SELECCIONE') {
                alert('DEBES SELECCI0NAR MEDIO DE TRANSPORTE');
                focusCtrl("txt22b");
                return true;
            } else {
                if ($('#txt22c').val() == 'SELECCIONE') {
                    alert('DEBES SELECCIONAR DESTINO');
                    focusCtrl("txt22c");
                    return true;
                }
            }
        }
    }

    if (!document.getElementById("chkSi23").checked) {
        if (!document.getElementById("chkNo23").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi23");
            return true;
        }
    } else {
        if ($('#txt23a').val() == '') {
            alert('DEBES SELECCIONAR LA FECHA DE INICIO DE TU VIAJE');
            focusCtrl("txt23a");
            return true;
        } else {
            if ($('#txt23b').val() == '') {
                alert('DEBES SELECCIONAR LA FECHA DE TERMINO DE TU VIAJE');
                focusCtrl("txt23b");
                return true;
            } else {
                if ($('#txt23c').val() == 'SELECCIONE') {
                    alert('DEBES SELECCIONAR DESTINO');
                    focusCtrl("txt23c");
                    return true;
                } else {
                    if ($('#txt23d').val() == 'SELECCIONE') {
                        alert('DEBES SELECCIONAR MEDIO DE TRANSPORTE');
                        focusCtrl("txt23d");
                        return true;
                    }
                }
            }
        }
    }

    if (!document.getElementById("chkSi24").checked) {
        if (!document.getElementById("chkNo24").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi24");
            return true;
        }
    } else {
        if ($('#txt24a').val() == '') {
            alert('DEBES ESCRIBIR LAS FECHAS');
            focusCtrl("txt24a");
            return true;
        } else {
            if ($('#txt24b').val() == '') {
                alert('DEBES ESCRIBIR LOS LUGARES');
                focusCtrl("txt24b");
                return true;
            }
        }
    }

    if (!document.getElementById("chkSi25").checked) {
        if (!document.getElementById("chkNo25").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi25");
            return true;
        }
    } else {
        if ($('#txt25a').val() == '') {
            alert('DEBES SELECCIONAR LA FECHA DE PRIMERA DOSIS');
            focusCtrl("txt25a");
            return true;
        } else {
            if ($('#txt25b').val() == '') {
                alert('DEBES SELECCIONAR LA FECHA DE LA SEGUNDA DOSIS');
                focusCtrl("txt25b");
                return true;
            } else {
                if ($('#txt25c').val() == '') {
                    alert('DEBES ESCRIBIR TIPO DE VACUNA APLICADA');
                    focusCtrl("txt25c");
                    return true;
                }
            }
        }
    }

    if (!document.getElementById("chkSi26").checked) {
        if (!document.getElementById("chkNo26").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi26");
            return true;
        }
    }

}


function ValidarVaciosEnSumasConCobMarcadas() {
    var CtrltxtSuma = "";

    var tbCoberturas = document.getElementById("Coberturas");
    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            if (document.getElementById("chk" + i).checked) {
                var CodCob = document.getElementById("chk" + i).value;
                if (document.getElementById("txtSuma" + CodCob).value == "") {
                    CtrltxtSuma = "txtSuma" + CodCob;
                    return CtrltxtSuma;
                }
            }
        }
    }

    return CtrltxtSuma;
}

function ValidarEmision105() {
    //----->C22<-----
    if (!validarExamen()) {
        return "C";
    }

    if (!validarSumaAseguradaBasica_105()) {
        return "C";
    }

    if (!validarCumulos_105()) {
        return "C";
    }

    //<--- C7 --->
    if (!validarIMC()) {
        return "C";
    }

    if (!validarOcupacion()) {
        return "C";
    }

    if (!validarDeporte()) {
        return "C";
    }


    if (!validarCuestionario()) {
        return "C";
    }

    if (!validarDeporte()) {
        return "C";
    }

    if (!validarImprimePolizaSolicitud_105()) {
        return "C";
    }

    return "P";
}
function validarImprimePolizaSolicitud_105() {
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = getNumContrato();
    var MarcaValidacion;

    var imprimePolizaSolicitud = MetodosAjax.validaImprimePolizaSolicitud(ramo, modalidad, contrato);

    if (imprimePolizaSolicitud.error == null) {
        if (imprimePolizaSolicitud != null && imprimePolizaSolicitud.value != null) {
            MarcaValidacion = imprimePolizaSolicitud.value.p_poli_soli;

            if (MarcaValidacion == "S")
                return true //Emite (Poliza)
            else
                return false //Cotiza (Solicitud)
        }
    }
    else {
        alert(imprimePolizaSolicitud.error.description);
        return false;
    }
}

function validarExamen() {
    var ramo = document.getElementById("HiddenRamoRequest").value;
    if (ramo == "105") {
        var tabla = document.getElementById("tblBenef105")
        var cell = tabla.rows[1].getElementsByTagName('td');
        var Edad = cell[3].innerHTML;
    }
    else {
        var Edad = document.getElementById("txtEdad").value;
    }
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = getNumContrato();
    var moneda = document.getElementById("drpMoneda").value;
    if (ramo == "105") {
        var tablaAsegurados = MetodosAjax.setAsegurados();
        var renglones = tablaAsegurados.value.Rows.length;
        var nombre = valorCtrl("UscAsegCLM_lblNombre");
        var apellidoPat = valorCtrl("UscAsegCLM_lblApellidoPaterno");
        var apellidoMat = valorCtrl("UscAsegCLM_lblApellidoMaterno");
        var fecNac = valorCtrl("UscAsegCLM_lblNacimiento");
    }
    else {
        var nombre = valorCtrl("UscAsegCLM_lblNombre");
        var apellidoPat = valorCtrl("UscAsegCLM_lblApellidoPaterno");
        var apellidoMat = valorCtrl("UscAsegCLM_lblApellidoMaterno");
        var fecNac = valorCtrl("UscAsegCLM_lblNacimiento");
    }
    var sumAseg = 0;
    var tbCoberturas = document.getElementById("Coberturas");
    var sumaValor = 0;

    /* Se realiza cambio a petición de usuario apl-09122014
       La suma asegurada tiene que ser igual a la cobertura básica.
       Texto original de petición : "ya podemos emitir la mayoría de los ramos, está pendiente que nos corrijan la parte de cúmulos ya que el sistema esta sumando las SA de todas las coberturas adicionales"

    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            if (document.getElementById("chk" + i).checked) {
                var CodCob = document.getElementById("chk" + i).value;

                if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                    sumaValor = parseFloat(document.getElementById("txtSuma" + CodCob).value);
                    sumAseg = sumAseg + sumaValor;
                }  
            }
        }
    }
*/
    /* Solo se toma en cuenta la cobertura básica*/
    if (document.getElementById("chk1") != null) {
        if (document.getElementById("chk1").checked) {
            var CodCob = document.getElementById("chk1").value;
            if (isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                sumAseg = sumAseg + parseFloat(document.getElementById("txtSuma" + CodCob).value);
            }
        }

        if (document.getElementById("chk2").checked) {
            var CodCob = document.getElementById("chk2").value;
            if (isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                sumAseg = sumAseg + parseFloat(document.getElementById("txtSuma" + CodCob).value);
            }
        }
        if (document.getElementById("chk3").checked) {
            var CodCob = document.getElementById("chk3").value;
            if (isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                sumAseg = sumAseg + parseFloat(document.getElementById("txtSuma" + CodCob).value);
            }
        }
        if (document.getElementById("chk4").checked) {
            var CodCob = document.getElementById("chk4").value;
            if (isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                sumAseg = sumAseg + parseFloat(document.getElementById("txtSuma" + CodCob).value);
            }
        }


    }
    if (ramo == "105") {
        for (var i = 0; i <= renglones - 1; i++) {
            var nombre = tablaAsegurados.value.Rows[i].nombre;
            var apellidoPat = tablaAsegurados.value.Rows[i].paterno;
            var apellidoMat = tablaAsegurados.value.Rows[i].materno;
            var fecNac = tablaAsegurados.value.Rows[i].fec_nac;

            var examenes = MetodosAjax.validaExamenes(ramo, modalidad, contrato, moneda, Edad, sumAseg, nombre, apellidoMat, apellidoPat, fecNac);

            if (examenes.error == null) {
                if (examenes != null && examenes.value != null) {
                    var examen = examenes.value.p_mensaje;
                    if (examen != "") {
                        //------->C24<-------
                        if (examen.indexOf("NO SE ENCUENTRA INFORMACIÓN") != -1) {
                            alert("NO EXISTEN DATOS CONFIGURADOS PARA EL TIPO DE EXAMEN SEGUN LOS PAR\u00c1METROS INGRESADOS.");
                            return true;
                        }
                        else {
                            alert("DE ACUERDO AL MONTO DE SUMA ASEGURADA, LE CORRESPONDE UN EXAMEN TIPO: " + examenes.value.p_mensaje);
                            var aux = examenes.value.p_mensaje;
                            if (aux.substring(0, 1) == "A")
                                return true;
                            else
                                return false;
                        }
                    }
                    else {
                        alert("NO EXISTEN DATOS CONFIGURADOS PARA EL TIPO DE EXAMEN");
                        return false;
                    }
                }
            }
            else {
                alert(examenes.error.description);
                return false;
            }

        }

    }
    else {
        var examenes = MetodosAjax.validaExamenes(ramo, modalidad, contrato, moneda, Edad, sumAseg, nombre, apellidoMat, apellidoPat, fecNac);

        if (examenes.error == null) {
            if (examenes != null && examenes.value != null) {
                var examen = examenes.value.p_mensaje;
                if (examen != "") {
                    //------->C24<-------
                    if (examen.indexOf("NO SE ENCUENTRA INFORMACIÓN") != -1) {
                        alert("NO EXISTEN DATOS CONFIGURADOS PARA EL TIPO DE EXAMEN SEGUN LOS PAR\u00c1METROS INGRESADOS.");
                        return true;
                    }
                    else {
                        alert("DE ACUERDO AL MONTO DE SUMA ASEGURADA, LE CORRESPONDE UN EXAMEN TIPO: " + examenes.value.p_mensaje);
                        var aux = examenes.value.p_mensaje;
                        if (aux.substring(0, 1) == "A")
                            return true;
                        else
                            return false;
                    }
                }
                else {
                    alert("NO EXISTEN DATOS CONFIGURADOS PARA EL TIPO DE EXAMEN");
                    return false;
                }
            }
        }
        else {
            alert(examenes.error.description);
            return false;
        }
    }
}

function validarCumulos_105() {
    //------------------->C14<-------------------
    var ramo = document.getElementById("HiddenRamoRequest").value;
    if (ramo == "105") {
        var tabla = document.getElementById("tblBenef105")
        var cell = tabla.rows[1].getElementsByTagName('td');
        var Edad = cell[3].innerHTML;
    }
    else {
        var Edad = document.getElementById("txtEdad").value;
    }
    if (ramo == "105") {
        var tablaAsegurados = MetodosAjax.setAsegurados();
        var renglones = tablaAsegurados.value.Rows.length;
        var sumAseg = 0;
    }
    else {
        var ramo = document.getElementById("HiddenRamoRequest").value;
        var modalidad = document.getElementById("HiddenModalidad").value;
        var contrato = getNumContrato();
        var moneda = document.getElementById("drpMoneda").value;
        var nombre = valorCtrl("UscAsegCLM_lblNombre");
        var apellidoPat = valorCtrl("UscAsegCLM_lblApellidoPaterno");
        var apellidoMat = valorCtrl("UscAsegCLM_lblApellidoMaterno");
        var fecNac = valorCtrl("UscAsegCLM_lblNacimiento");
        var sumAseg = 0;
        var tbCoberturas = document.getElementById("Coberturas");
        var sumaValor = 0;
    }
    /* Se realiza cambio a petición de usuario apl-09122014
       La suma asegurada tiene que ser igual a la cobertura básica.
       Texto original de petición : "ya podemos emitir la mayoría de los ramos, está pendiente que nos corrijan la parte de cúmulos ya que el sistema esta sumando las SA de todas las coberturas adicionales"

    for (var i = 1; i <= tbCoberturas.rows.length; i++) 
    {
        if (document.getElementById("chk" + i) != null) 
        {
            if (document.getElementById("chk" + i).checked) 
            {
                var CodCob = document.getElementById("chk" + i).value;

                if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) 
                {
                    sumaValor = parseFloat(document.getElementById("txtSuma" + CodCob).value);
                    sumAseg = sumAseg + sumaValor; 
                }  
            }
        }
    }
    */

    /* Solo se toma en cuenta la cobertura básica*/
    if (document.getElementById("chk1") != null) {
        if (document.getElementById("chk1").checked) {
            var CodCob = document.getElementById("chk1").value;
            if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                sumAseg = parseFloat(document.getElementById("txtSuma" + CodCob).value);
            }
        }
    }

    if (document.getElementById("chk2") != null) {
        if (document.getElementById("chk2").checked) {
            var CodCob = document.getElementById("chk2").value;
            if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                sumAseg = parseFloat(document.getElementById("txtSuma" + CodCob).value);
            }
        }
    }

    if (document.getElementById("chk3") != null) {
        if (document.getElementById("chk3").checked) {
            var CodCob = document.getElementById("chk3").value;
            if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                sumAseg = parseFloat(document.getElementById("txtSuma" + CodCob).value);
            }
        }
    }

    if (document.getElementById("chk4") != null) {
        if (document.getElementById("chk4").checked) {
            var CodCob = document.getElementById("chk4").value;
            if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                sumAseg = parseFloat(document.getElementById("txtSuma" + CodCob).value);
            }
        }
    }
    if (ramo == "105") {
        for (var i = 0; i <= renglones - 1; i++) {
            var nombre = tablaAsegurados.value.Rows[i].nombre;
            var apellidoPat = tablaAsegurados.value.Rows[i].paterno;
            var apellidoMat = tablaAsegurados.value.Rows[i].materno;
            var fecNac = tablaAsegurados.value.Rows[i].fec_nac;

            var ramo = document.getElementById("HiddenRamoRequest").value;
            var modalidad = document.getElementById("HiddenModalidad").value;
            var contrato = getNumContrato();
            var moneda = document.getElementById("drpMoneda").value;
            var nombre = tablaAsegurados.value.Rows[i].nombre;
            var apellidoPat = tablaAsegurados.value.Rows[i].paterno;
            var apellidoMat = tablaAsegurados.value.Rows[i].materno;
            var fecNac = tablaAsegurados.value.Rows[i].fec_nac;
            var tbCoberturas = document.getElementById("Coberturas");


            var Cumulos = MetodosAjax.validaCumulos(ramo, modalidad, contrato, moneda, Edad, nombre, apellidoPat, apellidoMat, fecNac, sumAseg);

            if (Cumulos.error == null) {
                if (Cumulos != null && Cumulos.value != null) {
                    var MarcaValidacion = Cumulos.value.p_mca_valido;
                    if (MarcaValidacion == "S")
                        return true; //Emite (Poliza)
                    else

                        return false;  //Cotiza (Solicitud)
                }
            }
            else {
                alert(Cumulos.error.description);
                return false;
            }


        }
    }
    else {
        var Cumulos = MetodosAjax.validaCumulos(ramo, modalidad, contrato, moneda, Edad, nombre, apellidoPat, apellidoMat, fecNac, sumAseg);

        if (Cumulos.error == null) {
            if (Cumulos != null && Cumulos.value != null) {
                var MarcaValidacion = Cumulos.value.p_mca_valido;
                if (MarcaValidacion == "S")
                    return true; //Emite (Poliza)
                else

                    return false;  //Cotiza (Solicitud)
            }
        }
        else {
            alert(Cumulos.error.description);
            return false;
        }
    }
}

function validarSumaAseguradaBasica_105() {
    //----------------->C13<-----------------
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = getNumContrato();

    var Moneda = selValorCtrl("drpMoneda");
    var SumaAsegBasica = 0;



    try {
        SumaAsegBasica = document.getElementById("txtSuma1000").value;
    }
    catch (err) {


        if (document.getElementById("chk1").checked) {
            var CodCob = document.getElementById("chk1").value;
            if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                SumaAsegBasica = parseFloat(document.getElementById("txtSuma" + CodCob).value);
            }
        }


        if (document.getElementById("chk2").checked) {
            var CodCob = document.getElementById("chk2").value;
            if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                SumaAsegBasica = parseFloat(document.getElementById("txtSuma" + CodCob).value);
            }
        }
        try {
            if (document.getElementById("chk3").checked) {
                var CodCob = document.getElementById("chk3").value;
                if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                    SumaAsegBasica = parseFloat(document.getElementById("txtSuma" + CodCob).value);
                }
            }
        }
        catch (err) { }
        try {
            if (document.getElementById("chk4").checked) {
                var CodCob = document.getElementById("chk4").value;
                if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                    SumaAsegBasica = parseFloat(document.getElementById("txtSuma" + CodCob).value);
                }
            }
        }
        catch (err) { }

    }

    var SumaBasica;
    try {
        SumaBasica = MetodosAjax.validaSumaBasica(ramo, modalidad, contrato, Moneda, SumaAsegBasica);
    }
    catch (ex) { }
    if (SumaBasica.error == null) {
        if (SumaBasica != null && SumaBasica.value != null) {
            var MarcaValidacion = SumaBasica.value.p_mca_valido;
            if (MarcaValidacion == "S")
                return true; //Emite (Poliza)
            else {
                //------->C25<-------
                alert(SumaBasica.value.p_error);
                return false;  //Cotiza (Solicitud)
            }
        }
    }
    else {
        alert(SumaBasica.error.description);
        return false;
    }



    //    if(!validarOcupacion())
    //    {
    //        return "C";
    //    }
    //    
    //    if(!validarIMC())
    //    {
    //        return "C";    
    //    }
    //    
    //    if(!validarDeporte())
    //    {
    //        return "C";
    //    }
    //    
    //    if(!validarCuestionario())
    //    {
    //        return "C";
    //    }

    return "P";
}