﻿//'****************************************************************************
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2010
//'Name of the file              : LlenadoDeDrops.js
//'Creation/Modification History :
//'Modification                  : emontoya  Indra SWLabs
//'C1                            : emontoya - 30-12-2012
//                               : Se agrega el método LlenarParentesco.
//'C2                            : emontoya - 30-12-2012
//                               : Se agrega el método obtenerPrimeraModalidad.
//                               : Así mismo se agrega el llamado del método en la función
//                               : LlenarDropFormaPago.
//'C3                            : emontoya - 30-12-2012
//                               : Se agregan los parámetros:Ramo, Modalidad
//                               : y contrato al método getTipoPago.
//'C4                            : emontoya - 30-12-2012
//                               : Se crea el método LlenarOcupacion
//'C5                            : jchuertas - 14-11-2013
//                               : Se crea el cuestionario por medio de llamado ajax
//								   después del calculo de la modalidad
//'C6                            : jchuertas - 19-11-2013
//                               : Corrección de mensaje mostrado de forma incorrecta (repetidamente)
//'C7                            : jglopezh - 20-11-2013
//                               : Se crea la variable tipoPlan y se envia como parámetro
//                               : al método getDuracion
//'C8                            : jchuertas - 20-11-2013

//                               : Solamente se marca para meridiano y preferente
//                               : Adicional se crea la variable tipoPLan
//'*****************************************************************************
function limpiaCtrlsConAgente() {
    setPolizaConContrato(false);
}

function LlenarPlanyMoneda(pcomboFill) {
    var Ramo = document.getElementById("HiddenRamoRequest").value;

    limpiaCtrlsConMoneda();

    comboFill = pcomboFill;
    valFill = 'COD_MON';
    txtFill = 'NOM_MON';
    NombreFuncionDrop = 'LlenarDropCrecimiento';
    comboFillAuto = 'drpCrecimiento';
    bdrContinuar = true;

    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    var tipoPlan = document.getElementById("HiddenTipoPlanRequest").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked && !(document.getElementById("drpContrato").value === undefined)) {
        contrato = selIndex("drpContrato");
    }
    MetodosAjax.getMoneda(Ramo, contrato, tipoPlan, llenaCombo_CallBack);
}

function LlenarDropCrecimiento(pcomboFill) {
    limpiaCtrlsConMoneda();

    comboFill = pcomboFill;

    //Se valida el plan en el que se trabaja para llenar el Crecimiento, ya 
    //que para jubilación los nombres de los campos son diferentes.
    if (document.getElementById("HiddenRamoRequest").value != "101") {
        valFill = 'TIP_REGULARIZA_SUMA|PCT_REGULARIZA_SUMA';
        txtFill = 'NOM_CRECIMIENTO';
    }
    else {
        valFill = 'TIP_REGULARIZA_PRIMA|PCT_REGULARIZA_PRIMA';
        txtFill = 'NOM_CRECIMIENTO_PRIMA';
    }
    NombreFuncionDrop = 'LlenarDropDeducible';
    comboFillAuto = 'drpDeducible';
    bdrContinuar = true;

    var PlanRamo = document.getElementById("HiddenRamoRequest").value;

    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Crecimiento.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    var tipoPlan = document.getElementById("HiddenTipoPlanRequest").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    MetodosAjax.getCrecimiento(PlanRamo, contrato, selIndex("drpMoneda"), tipoPlan, llenaCombo_CallBack);
}

function limpiaCtrlsConMoneda() {
    //limpiaCombo("drpCrecimiento");
    //Se valida que control se limpiará al Momento de cambiar el DropMoneda
    //ya que en los planes que no sean jubilación el drpDeducible aparecerá oculto y no podrá ser encontrado.
    //if(document.getElementById("HiddenRamoRequest").value == "101")
    //    limpiaCombo("drpDeducible");
    //else
    //    document.getElementById("HiddenDeducible").value = "";

    limpiaCombo("drpPlazo");
    //limpiaCombo("drpComision");

    limpiaCombo("drpFormaPago");
    limpiaCombo("drpTipoPago");
    document.getElementById('DivCoberturas').innerHTML = "";
    document.getElementById('divPrimas').innerHTML = "";

    LimpiarDatosDelSeguro(false);
}

function LlenarDropDeducible(pcomboFill) {
    //Ramo Millon Vida
    //limpiaCtrlsConCrecimiento();

    comboFill = pcomboFill;
    valFill = 'TIP_DEDUCIBLE';
    txtFill = 'NOM_VALOR';
    NombreFuncionDrop = 'LlenarDropDuracion';
    comboFillAuto = 'drpPlazo';
    bdrContinuar = true;

    var PlanRamo = document.getElementById("HiddenRamoRequest").value;
    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    //Se valida como se llenará el Combo de deducible para el Caso de Jubilación a través del drpDeducible
    //para los demás casos se llenará por el control "HiddenDeducible".
    //La función "getDeducibleNoJubilación" deberá regresar solo un valor.
    if (document.getElementById("HiddenRamoRequest").value == "101")
        MetodosAjax.getDeducible(PlanRamo, contrato, selIndex("drpMoneda"), selValorCtrl("drpCrecimiento", 0), llenaCombo_CallBack);
    else
        MetodosAjax.getDeducibleNoJubilacion(PlanRamo, contrato, selIndex("drpMoneda"), selValorCtrl("drpCrecimiento", 0), llenaDuracion_CallBack);
}

function llenaDuracion_CallBack(res) {
    if (res.error == null) {
        if (res != null && res.value != null) {
            document.getElementById("HiddenDeducible").value = res.value;

            var FunctionDuracion = "LlenarDropDuracion('drpPlazo');";
            eval(FunctionDuracion);
        }
    }
}

function limpiaCtrlsConCrecimiento() {
    //Se valida que control se limpiará al Momento de cambiar el drpCrecimiento
    //ya que en los planes que no sean jubilación el drpDeducible aparecerá oculto y no podrá ser encontrado.
    if (document.getElementById("HiddenRamoRequest").value == "101")
        limpiaCombo("drpDeducible");
    else
        document.getElementById("HiddenDeducible").value = "";

    limpiaCombo("drpPlazo");
    limpiaCombo("drpComision");
    limpiaCombo("drpFormaPago");
    limpiaCombo("drpTipoPago");
}

function LlenarDropDuracion(pcomboFill) {
    limpiaCtrlsConDuracion();

    comboFill = pcomboFill;
    valFill = 'DURACION_HASTA';
    txtFill = 'DURACION_HASTA';
    NombreFuncionDrop = 'LlenarDropComision';
    comboFillAuto = 'drpComision';
    bdrContinuar = true;

    var PlanRamo = document.getElementById("HiddenRamoRequest").value;
    // <---- C7 ---->
    var tipoPlan = document.getElementById("HiddenTipoPlanRequest").value;
    // <------------>
    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Duración.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    var Deducible = "-1"
    if (document.getElementById("HiddenRamoRequest").value == "101")
        Deducible = selIndex("drpDeducible");
    else
        Deducible = document.getElementById("HdnDeducible").value;

    // <---- C7 ---->
    //MetodosAjax.getDuracion(PlanRamo, contrato, selIndex("drpMoneda"), selValorCtrl("drpCrecimiento", 0), Deducible, tipoPlan, llenaCombo_CallBack);
    MetodosAjax.getDuracion(PlanRamo, contrato, selIndex("drpMoneda"), document.getElementById("HiddenCrecimiento").value, document.getElementById("HdnDeducible").value, tipoPlan, llenaCombo_CallBack);
}

function limpiaCtrlsConDuracion() {
    limpiaCombo("drpComision");
    limpiaCombo("drpFormaPago");
    limpiaCombo("drpTipoPago");
}

function LlenarDropComision(pcomboFill) {
    //    if (document.getElementById("hdnJubilacion") != null || document.getElementById("hdnJubilacion") != undefined) {
    //        ValidaPlazoEdad();
    //        FecVenJub();
    //    }
    //    else
    if (!ValidaPlazoMV()) {
        document.getElementById("hdnPlazo").value = selIndex("drpPlazo");

        comboFill = pcomboFill;
        valFill = 'TIP_COMISION';
        txtFill = 'NOM_VALOR';
        NombreFuncionDrop = 'LlenarDropComision';
        comboFillAuto = 'drpFormaPago';
        bdrContinuar = true;
        ValidaFechaVen(document.getElementById("hdnPlazo").value);
        var PlanRamo = document.getElementById("HiddenRamoRequest").value;
        //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
        //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
        //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
        //en el drpContrato.
        var contrato = document.getElementById("HiddenContratoGenerico").value;
        if (document.getElementById("rbtnListPolizaContrato_1").checked) {
            contrato = selIndex("drpContrato");
        }
        var tipoPlan = document.getElementById("HiddenTipoPlanRequest").value;

        var Deducible = "-1"
        if (document.getElementById("HiddenRamoRequest").value == "101")
            Deducible = selIndex("drpDeducible");
        else
            Deducible = document.getElementById("HdnDeducible").value;

        MetodosAjax.getComision(PlanRamo, contrato, selIndex("drpMoneda"), document.getElementById("HiddenCrecimiento").value, Deducible, document.getElementById("hdnPlazo").value, tipoPlan, llenaComboComision_CallBack);
    }
    else {
    }
}

function EliminarComision() {
    var PlanRamo = document.getElementById("HiddenRamoRequest").value;
    //Cambio para millon vida.
    if (PlanRamo == "111") {
        if (document.getElementById("drpComision") != null) {
            for (i = document.getElementById("drpComision").options.length; i >= 0; i--) {
                if (document.getElementById("drpComision").options[i] != null) {
                    if (document.getElementById("drpComision").options[i] != "NIVELADA") {
                        document.getElementById("drpComision").options[i] = null;
                    }
                }
            }
        }
    }
}

function limpiaCtrlsConPolizaGrupo() {
    limpiaCombo("drpContrato");
    limpiaCtrlsConMoneda();
}


function LlenarFormaPago(pcomboFill, bdrLlenado) {
    comboFill = pcomboFill;
    valFill = 'COD_FRACC_PAGO';
    txtFill = 'NOM_FRACC_PAGO';
    NombreFuncionDrop = '';
    comboFillAuto = '';
    bdrContinuar = false;

    var Ramo = document.getElementById("HiddenRamoRequest").value;
    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    var Modalidad = document.getElementById("HiddenModalidad").value;

    if (bdrLlenado)
        MetodosAjax.getFormasPago(Ramo, Modalidad, contrato, llenaComboFormaPago_CallBack);
    else
        MetodosAjax.getFormasPago(Ramo, Modalidad, contrato, llenaCombo_CallBack);

}

/// <summary>
///     Este método se encarga de llenar el combo drpFormaPago según la modalidad y 
///     el contrato.
/// </summary>
function LlenarDropFormaPago(pcomboFill) {
    limpiaCtrlsConFormaPago();

    comboFill = pcomboFill;
    valFill = 'COD_VALOR';
    txtFill = 'NOM_VALOR';
    NombreFuncionDrop = 'LlenarDropTipoPago';
    comboFillAuto = 'drpTipoPago';
    bdrContinuar = false;

    var Ramo = document.getElementById("HiddenRamoRequest").value;
    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    // var Modalidad = document.getElementById("HiddenModalidad").value;
    // <--- C2 --->
    var Modalidad = obtenerModalidadSencilla();

    if (Modalidad.error == null) {
        if (Modalidad != null && Modalidad.value != null) {
            var arrModalidadEdad = new Array();
            arrModalidadEdad = Modalidad.value.split('|');
            var ModalidadSencilla = arrModalidadEdad[0];
        }
    }
    // -----------

    MetodosAjax.getFormasPago(Ramo, ModalidadSencilla, contrato, llenaFormaPago_CallBack);
}

// <--- C2 --->
/// <summary>
///     Método que obtiene la modalidad.
/// </summary>
function obtenerModalidadSencilla() {
    var PlanRamo = document.getElementById("HiddenRamoRequest").value;
    // <--- C7 --->
    var tipoPlan = document.getElementById("HiddenTipoPlanRequest").value;
    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    var Deducible = "-1"
    if (document.getElementById("HiddenRamoRequest").value == "101")
        Deducible = selIndex("drpDeducible");
    else
        Deducible = document.getElementById("HdnDeducible").value;

    var Comision = 1;
    if (document.getElementById("drpComision").selectedIndex > 0) {
        Comision = selIndex("drpComision");
    }

    var marMerPref = "N";

    // <--- C8 --->
    if (tipoPlan == "2" || tipoPlan == "4") {
        if (document.getElementById("chkBxMeridianoPrefe").checked == true)
            marMerPref = "S";
    }

    return MetodosAjax.getModalidad(PlanRamo, contrato, selIndex("drpMoneda"), document.getElementById("HiddenCrecimiento").value,
        Deducible, Comision, document.getElementById("hdnPlazo").value, marMerPref, tipoPlan);
}
// -----------

function limpiaCtrlsConFormaPago() {
    limpiaCombo("drpTipoPago");
}

/// <summary>
///     Este método se encarga de llenar el combo drpTipoPago según la modalidad, 
///     el contrato y forma de pago seleccionados.
/// </summary>
function LlenarDropTipoPago(pcomboFill) {
    comboFill = pcomboFill;
    valFill = 'TIP_GESTOR';
    txtFill = 'NOM_TIP_GESTOR';
    NombreFuncionDrop = 'ConsultaOcupacion';
    comboFillAuto = 'drpOcupacion';
    bdrContinuar = false;

    // <--- C3 --->
    var Ramo = document.getElementById("HiddenRamoRequest").value;
    var Modalidad = document.getElementById("hdnmodalidadul").value;
    var contrato = document.getElementById("hdncontrato").value;

    MetodosAjax.getTipoPago(Ramo, Modalidad, contrato, "1", llenaComboTipoPago_CallBack);
    // <---------->
}

function ObtenerModalidad() {
    var PlanRamo = document.getElementById("HiddenRamoRequest").value;
    // <--- C7 --->
    var tipoPlan = document.getElementById("HiddenTipoPlanRequest").value;
    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    var Deducible = "-1"
    if (document.getElementById("HiddenRamoRequest").value == "101")
        Deducible = selIndex("drpDeducible");
    else
        Deducible = document.getElementById("HdnDeducible").value;

    var Comision = "";
    if (document.getElementById("drpComision").selectedIndex > 0) {
        Comision = selIndex("drpComision");
    }

    var marMerPref = "N";

    // <--- C8 --->
    if (tipoPlan == "2" || tipoPlan == "4") {
        if (document.getElementById("chkBxMeridianoPrefe").checked == true)
            marMerPref = "S";
    }

    var Modalidad = MetodosAjax.getModalidad(PlanRamo, contrato, selIndex("drpMoneda"), document.getElementById("HiddenCrecimiento").value,
        Deducible, Comision, document.getElementById("hdnPlazo").value, marMerPref, tipoPlan);


    if (Modalidad.error == null) {
        if (Modalidad != null && Modalidad.value != null) {
            var arrModalidadEdad = new Array();
            arrModalidadEdad = Modalidad.value.split('|');
            document.getElementById("HiddenModalidad").value = arrModalidadEdad[0];
            document.getElementById("HiddenEdadTopeMin").value = arrModalidadEdad[1];
            document.getElementById("HiddenEdadTopeMax").value = arrModalidadEdad[2];

            if (parseInt(document.getElementById("txtEdad").value) < parseInt(document.getElementById("HiddenEdadTopeMin").value) || parseInt(document.getElementById("txtEdad").value) > parseInt(document.getElementById("HiddenEdadTopeMax").value)) {
                if (document.getElementById("HiddenRamoRequest").value == "105") {
                    if (selIndex("drpParentesco1") != 4 || selIndex("drpParentesco1") != 37) {
                        //---C6---
                        if (document.getElementById("hdnBanderaModalidad").value == 0) {
                            document.getElementById("hdnBanderaModalidad").value = 1;
                            //AEP BWMEILL. Corrección en los acentos de los mensajes. Millón Vida Fase 2
                            alert("Edad de aceptaciu00f3n de " + arrModalidadEdad[1] + " a " + arrModalidadEdad[2]);
                        }
                        document.getElementById("txtEdad").value = "";
                        focusCtrl("txtEdad");
                    }
                } else {
                    //---C6---
                    if (document.getElementById("hdnBanderaModalidad").value == 0) {
                        document.getElementById("hdnBanderaModalidad").value = 1;
                        //AEP BWMEILL. Corrección en los acentos de los mensajes. Millón Vida Fase 2
                        alert("Edad de aceptaciu00f3n de " + arrModalidadEdad[1] + " a " + arrModalidadEdad[2]);
                    }

                    document.getElementById("txtEdad").value = "";
                    focusCtrl("txtEdad");
                }
            }
            else {
                obtenerCoberturas();
            }

            LlenarDropFormaPago('drpFormaPago')
            //----C5-----
            devuelveCuestionario();
        }
    }

}

///----C5-----
/// <summary>
///     Este método se encarga de hacer el llamado para la carga del cuestionario 
///     el contrato.
/// </summary>
function devuelveCuestionario() {
    var Ramo = document.getElementById("HiddenRamoRequest").value;
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    var Modalidad = document.getElementById("HiddenModalidad").value;

    MetodosAjax.devuelveCuestionario(Ramo, Modalidad, contrato, cuestionario_CallBack);
}

function cuestionario_CallBack(res) {
    if (res.error == null) {
        if (res != null && res.value != null) {
            var newdiv = document.createElement("div");
            newdiv.innerHTML = res.value;
            var container = document.getElementById("divCuestionario");
            container.innerHTML = "";
            container.appendChild(newdiv);

            if (document.getElementById("divCuestionario").innerHTML == "")
                document.getElementById("divCuestionario").innerHTML = res.value;

            AjustarFrame();
        }
    }
}




function ValidaPlazoEdad() {
    if (ValidaPlazoMV()) {
        //alert("La edad no corresponde al plan seleccionado.");
        document.getElementById("txtEdad").value = "";
        focusCtrl("txtEdad");
    }
}
//AEP BWMEILL. Millón Vida Fase 2. Modificación de plazos para PPR
function ValidaPlazoMV() {
    var e = document.getElementById("txtEdad").value;
    var dur = selIndex("drpPlazo");

    if (document.getElementById("txtEdad").value.length != 0 && (dur == "5" || dur == "10")) {
        if (e == "70" && dur == "10" && (document.getElementById("hdnJubilacion") != null || document.getElementById("hdnPPR") != null)) {
            alert("El plazo del seguro con esta edad, no puede exceder los 10 a\u00f1os");
            document.getElementById("drpMoneda").value = "0"
            limpiaCombo("drpPlazo");
            limpiaCombo("drpComision");
            return true;
        }
        else if (document.getElementById("hdnJubilacion") != null || document.getElementById("hdnJubilacion") != undefined) {
            //Valida si es mayor a 45 y menor a 70 para JUBILACION
            if (document.all("TxtEdad").value < 45 || document.all("TxtEdad").value > 70) {
                alert("Las edades de aceptaci\u00f3n son de 45 a 70 a\u00f1os");
                return true;
            }
        }
        else if (document.getElementById("hdnPPR") != null || document.getElementById("hdnPPR") != undefined) {
            //Valida si es mayor a 55 y menor a 70 para PPR
            if (document.all("TxtEdad").value < 55 || document.all("TxtEdad").value > 70) {
                alert("Las edades de aceptaci\u00f3n son de 55 a 70 a\u00f1os");
                return true;
            }
        }
        else if (document.all("TxtEdad").value.length != 0) {
            //Valida si es mayor a 18 y menor a 70 INVERSION
            if (document.all("TxtEdad").value < 18 || document.all("TxtEdad").value > 70) {
                alert("Las edades de aceptaci\u00f3n son de 18 a 70 a\u00f1os");
                return true;
            }
        }
    }
    else {
        return false;
    }
}

// <--- C1 --->
/// <summary>
///     Este método se encarga de llenar el combo drpParentesco según el tipo de seguro que 
///     el usuario seleccione.
/// </summary>
function LlenarParentesco(pcomboFill, tipoSeguro) {
    comboFill = pcomboFill;
    valFill = 'COD_VALOR';
    txtFill = 'NOM_VALOR';
    NombreFuncionDrop = '';
    comboFillAuto = '';
    bdrContinuar = false;

    var Ramo = document.getElementById("HiddenRamoRequest").value;
    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var Modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = document.getElementById("HiddenContratoGenerico").value;

    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    MetodosAjax.getParentescoSeguro(Ramo, Modalidad, contrato, tipoSeguro, selIndex("drpTipBenef"), llenaCombo_CallBack);
}

/// <summary>
///     Este método se encarga de llenar el combo drpOcupacion según el código del Ramo,
///     modalidad y número de contrato.
/// </summary>
function LlenarOcupacion(pcomboFill) {
    comboFill = pcomboFill;
    valFill = 'COD_PROFESION';
    txtFill = 'NOM_PROFESION';
    NombreFuncionDrop = '';
    comboFillAuto = '';
    bdrContinuar = false;

    var Ramo = document.getElementById("HiddenRamoRequest").value;
    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var Modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = document.getElementById("hdncontrato").value;

    MetodosAjax.getOcupacion(Ramo, Modalidad, contrato, llenaCombo_CallBack);
}

//MU-080082 Se manda el cuestionario en base a la nueva cobertura INI
function muestracuest() {
    if (document.getElementById("chk2").checked) {
        document.getElementById("divCuestionario").style.display = "block";
        devuelveCuestionario();
    }
    else {
        document.getElementById("divCuestionario").style.display = "none";
    }
}
//MU-080082 Se manda el cuestionario en base a la nueva cobertura FIN    


//Unit Linked Funcion para validar el limite de edad y plazos INI
function ValidarEdad() {
    var edad = document.all("txtEdad").value;
    if (edad == "" || edad == "0") {
        alert("Favor de capturar la edad.")
    }
    else {
        document.all("drpSexo").focus();
    }
    validacontratoypolgpo();
}

function LimiteEdad() {
    var edad = document.all("txtEdad").value;

    if (edad != "" && edad != 0) {
        if (selIndex("drpPlan") == "11204") {//Inv
            if (parseInt(edad) < "18" || parseInt(edad) > "80") {
                alert("Para la modalidad Inversi\u00F3n las edades de aceptaci\u00F3n son de 18 a\u00f1os a 80 a\u00f1os.");
                return true;
            }
        }
        else if (selIndex("drpPlan") == "11205") {//Jub
            if (parseInt(edad) < "18" || parseInt(edad) > "70") {
                alert("Para la modalidad Jubilaci\u00F3n las edades de aceptaci\u00F3n son de 18 a\u00f1os a 70 a\u00f1os.");
                return true;
            }
        }
        else if (selIndex("drpPlan") == "11206") {//PPR
            if (parseInt(edad) < "18" || parseInt(edad) > "70") {
                alert("Para la modalidad PPR las edades de aceptaci\u00F3n son de 18 a\u00f1os a 70 a\u00f1os.");
                return true;
            }
        }
    }
    else {

        return false;
    }
}

function validaplazoUL() {
    var edad = document.all("txtEdad").value;
    var duracion = selIndex("drpDuracion");
    var res = duracion - edad;

    if (document.getElementById("drpPlan").value == "11204") {
        var resultado = parseInt(edad) + parseInt(duracion);
        res = duracion;
        document.all("EdadAlcanzada").style.display = 'block';
        document.all("TxtEA").style.display = 'block';
        document.all("ValorEA").style.display = 'block';
        document.getElementById("ValorEA").innerHTML = resultado + " a\u00f1os";
    }
    else if (document.getElementById("drpPlan").value == "11205") {
        if (res < 5) {
            alert("Para la modalidad Contigo en tu Jubilaci\u00f3n el plazo m\u00ednimo es de 5 a\u00f1os.");
            document.all("txtEdad").focus();
            document.all("txtEdad").value = "";
            return false;
        }
    }
    else if (document.getElementById("drpPlan").value == "11206") {
        if (res < 1) {
            alert("Para la modalidad Contigo en tu PPR el plazo m\u00ednimo es de 1 a\u00f1o.");
            document.all("txtEdad").focus();
            document.all("txtEdad").value = "";
            return false;
        }
    }
    document.all("txtMontoIni").readOnly = false;
    document.all("txtMontoIni").disabled = false;
    document.all("txtMontoIni").style.display = 'block';
    document.all("txtMontoIni").value = "0";
    MetodosAjax.setSession("duration", res);
    return true;
}
//Unit Linked Funcion para validar el limite de edad y plazos FIN

//Unit Linked Perfiles INI
function LeePerfil() {
    var cia = "1";
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var fecha = document.getElementById("hidFechaSistema").value;
    var contrato = document.getElementById("hdncontrato").value;
    var mod = document.getElementById("hdnmodalidadul").value;
    if (mod == "") {
        mod = "'" + "'";
    }
    document.all("drpPerfil").focus();
    fecha = fecha.replace(new RegExp('/', 'g'), "");
    if (parseInt(ramo) != 0) {
        comboFill = 'drpPerfil';
        valFill = 'COD_PERFIL';
        txtFill = 'NOM_PERFIL';
        var parametros = "[cod_cia = " + cia + "][fec_efec_poliza = '" + fecha + "'" + "][cod_modalidad = " + mod + "][cod_ramo = " + ramo + "][num_contrato = " + contrato + "]";
        MetodosAjax.getPerfilesULind(cia, ramo, parametros, llenaCombo_CallBack);
    }
    else {
        document.all("drpPerfil").disabled = true;
    }
}
//Unit Linked Perfiles FIN

function LeePlan() {
    var ramo = document.getElementById("HiddenRamoRequest").value;
    if (parseInt(ramo) != 0) {
        comboFill = 'drpPlan';
        valFill = 'COD_VALOR';
        txtFill = 'NOM_VALOR';
        NombreFuncionDrop = "";
        comboFillAuto = "";
        bdrContinuar = true;
        MetodosAjax.PlanInd(ramo, llenaCombo_CallBack);
    }
    else {
        document.all("drpPlan").disabled = true;
    }
}

//Unit Linked Monedas INI
function LeeMoneda() {
    if (LimiteEdad()) {
        LimpiarPrimas();
        document.getElementById("txtEdad").value = "";
        document.getElementById("txtEdad").focus();
    }
    else {
        var cia = 1;
        var Ramo = document.getElementById("HiddenRamoRequest").value;
        var Contrato = document.getElementById("hdncontrato").value;
        if (parseInt(Ramo) != 0) {
            document.all("drpMoneda").disabled = false;
            comboFill = 'drpMoneda';
            valFill = 'COD_MON';
            txtFill = 'NOM_MON';
            //NombreFuncionDrop = 'LeeDuracion';
            //comboFillAuto = 'drpDuracion';
            //bdrContinuar = true;
            MetodosAjax.getMonedasUL(cia, Ramo, Contrato, llenaCombo_CallBack);
        }
        else {
            document.all("drpMoneda").disabled = true;
        }
    }
}
//Unit Linked Monedas FIN

//Unit Linked Llenado de Duracion INI
function LeeDuracion() {
    var ramo = document.getElementById("HiddenRamoRequest").value;
    document.all("hdnmodalidadul").value = document.all("drpPlan").value;
    var edad = document.getElementById("txtEdad").value;
    if (parseInt(ramo) != 0) {
        comboFill = 'drpDuracion';
        valFill = 'VALOR_EA';
        txtFill = 'NOM_EA';
        MetodosAjax.getduracioULInd(ramo, document.all("hdnmodalidadul").value, edad, llenaCombo_CallBack);
    }
    else {
        document.all("txtMontoIni").readOnly = true;
        document.all("txtMontoIni").value = "0";
        document.all("drpDuracion").disabled = true;
    }
}
//Unit Linked Llenado de Duracion FIN

//Unit Linked Periodicidad Primas INI
function PeriodicidadPrimas() {
    var cia = "1";
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var mod = document.getElementById("hdnmodalidadul").value;
    comboFill = 'drpPeriodos';
    valFill = 'COD_FRACC_PAGO';
    txtFill = 'NOM_FRACC_PAGO';
    var parametros = "[cod_cia = " + cia + "][cod_ramo = " + ramo + "][dvcod_modalidad = " + mod + "]";
    MetodosAjax.getPeriodicidadP(cia, ramo, parametros, llenaCombo_CallBack);
    document.all("drpPeriodos").focus();

}
//Unit Linked Periodicidad Primas FIN

//Unit Linked Dias Pago INI
function diapago() {

    comboFill = 'drpDiaPago';
    valFill = 'DIA';
    txtFill = 'VALOR_DIA';
    MetodosAjax.diaspago(llenaCombo_CallBack);
}
//Unit Linked Dias Pago FIN

//Unit Linked INI
function monto_min_ind() {
    var prima = document.all("txtMontoIni").value;
    var mod = document.getElementById("hdnmodalidadul").value;
    //Se agregan parametros
    var mon = document.getElementById("drpMoneda").value;
    var mensaje = MetodosAjax.prima_min_ind(prima, mod, mon);
    if (mensaje.value != "") {
        var mens = mensaje.value.split(":");
        if (mens.length > "1") {
            var numero = formatCurrency(mens[1]);
            alert(mens[0] + " " + numero);
            document.all("txtMontoIni").value = "0";
        }
        else {
            alert(mensaje.value);
            document.all("txtMontoIni").value = "0";
        }
    }
    else {
        document.all("txtMontoPro").disabled = false;
        document.all("txtMontoPro").value = "0";
        document.all("txtMontoPro").focus();
    }
}


function monto_min_ad_ind() {
    var moda = document.getElementById("hdnmodalidadul").value;
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var primaad = document.all("txtMontoPro").value;
    //Se agregan parametros
    var mon = document.getElementById("drpMoneda").value;
    var per = document.getElementById("drpPeriodos").value;
    var mensaje = MetodosAjax.programada_min_ind(ramo, moda, primaad, mon, per);
    if (mensaje.value != "") {
        document.all("txtMontoPro").value = "0";
        document.all("txtMontoPro").focus();
        var mens = mensaje.value.split(":");
        if (mens.length > "1") {
            var numero = formatCurrency(mens[1]);
            alert(mensaje.value);
        }
        else {
            alert(mensaje.value);
        }
    }
    else {
        fondosInv();
    }
}
//Unit Linked FIN

//MU-2017-064392
function LlenarDropPolizaGrupo(pcomboFill) {

    comboFill = pcomboFill;

    valFill = 'NUM_POLIZA_GRUPO';
    txtFill = 'NUM_POLIZA_GRUPO';
    NombreFuncionDrop = 'LlenarDropContrato';
    comboFillAuto = 'drpContrato';
    bdrContinuar = true;

    var Ramo = document.getElementById("HiddenRamoRequest").value;
    MetodosAjax.getPolizaGrupoUL(Ramo, selIndex("drpAgente"), llenaCombo_CallBack);
}
function LlenarDropContrato(pcomboFill) {

    comboFill = pcomboFill;
    valFill = 'NUM_CONTRATO';
    txtFill = 'NUM_CONTRATO';
    NombreFuncionDrop = '';
    comboFillAuto = '';
    bdrContinuar = true;

    var polgpo = selIndex("drpPolizaGrupo");
    var Ramo = document.getElementById("HiddenRamoRequest").value;

    MetodosAjax.getContratosUL(Ramo, polgpo, selIndex("drpAgente"), llenaCombo_CallBack);
}
function validacontratoypolgpo() {
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        if (selIndex("drpPolizaGrupo") != "") {
            document.getElementById("hdnpolgpo").value = selIndex("drpPolizaGrupo");
        }
        else {
            alert("No se pudo obtener la poliza grupo.");
        }
        if (selIndex("drpContrato") != "") {
            document.getElementById("hdncontrato").value = selIndex("drpContrato");
        }
        else {
            alert("No se pudo obtener el contrato.");
        }
    }
    else {
        document.getElementById("hdncontrato").value = "99999";
        document.getElementById("hdnpolgpo").value = "";
    }
}
//MU-2017-064392

function obtienebeneficiarios() {
    var contrato = document.getElementById("hdncontrato").value;
    var modalidad = document.getElementById("hdnmodalidadul").value;
    comboFill = 'drpTipBenef';
    valFill = 'COD_VALOR';
    txtFill = 'NOM_VALOR';

    MetodosAjax.ObtenBeneficiariosULIND(contrato, modalidad, llenaCombo_CallBack);
}
