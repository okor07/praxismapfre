﻿//Modificaciones 
/// C1:       APL 10-08-2017
//           Se crean funciones para ramo 105
//09052018
// C2:		 26-08-2019
//   		 MU-2019-050447 - MX_NC_VID Incremento de sumas aseguradas
// 			 Se agrega al método actSumaAseg(), la validación de Incremento de sumas aseguradas desde el portal de ZA
//			 Se agrega al método actSumaAseg(), validación para mostrar Archivo a adjuntar
//			 Cuestionario Enfermedades respiratorias
function Init() {


    AjustarFrame();
    limpiaCtrlsConMoneda();
    cambiaAgente(document.getElementById("drpAgente"));
    if (document.getElementById("HiddenRamoRequest").value == "105") {
        limpiaImportes();
    }

    habilitarCtrl("btnEmite", false);

    habilitarCtrl("btnImprimeSolicitud", false);
    habilitarCtrl("btnImprimePoliza", false);
    //habilitarCtrl("btnNuevaSolicitud",false);      

    habilitarCtrl("btnEnviar", false);

    Cargando(false);
}

var ValSumaAseg;
function AjustarFrame() {
    var IFrameAAjustar = document.getElementById("HiddenIFrameAAjustar").value;
    var frmPrincipal = parent.document.getElementById(IFrameAAjustar);
    if (frmPrincipal != null)
        autofitIframe(IFrameAAjustar);
}

function Cargando(bdrCargando) {
    if (bdrCargando)
        document.getElementById('divCargando').style.display = 'block';
    else
        document.getElementById('divCargando').style.display = 'none';
}

function cambiaAgente(cmbAgt) {
    if (!(cmbAgt.selectedIndex == 0 && cmbAgt.options.length > 1)) {
        document.getElementById("txtClaveAgen").value = selIndex("drpAgente");
        document.getElementById("txtClaveAgen").disabled = true;
        wsObtieneAgente();
    }
}

function OcultarMostrarDivsConContrato() {
    if (document.getElementById("rbtnListPolizaContrato_0").checked) {
        document.getElementById("divPolizaGrupo").style.visibility = "hidden";
        document.getElementById("divContrato").style.visibility = "hidden";

        limpiaCtrlsConMoneda();
        //Con ésta función se llena la forma de pago y con el parámetro "true" le indicamos que 
        //una vez que haya llenado el drpFormaPago se llenará el drpMoneda.
        LlenarFormaPago('drpFormaPago', true);
    }
    else {
        document.getElementById("divPolizaGrupo").style.visibility = "visible";
        document.getElementById("divContrato").style.visibility = "visible";

        //Se limpian Drops desde Moneda.
        limpiaCombo('drpMoneda');
        limpiaCtrlsConMoneda();
        LlenarDropPolizaGrupo('drpPolizaGrupo');

    }
}

function setPolizaConContrato(bdrHabilitar) {
    HabilitarPolConContrato(bdrHabilitar);

    document.getElementById("rbtnListPolizaContrato_0").checked = true;
    limpiaCombo("drpPolizaGrupo");
    limpiaCombo("drpContrato");

    OcultarMostrarDivsConContrato();
}

function HabilitarPolConContrato(bdrHabilitar) {
    document.getElementById("rbtnListPolizaContrato_0").disabled = bdrHabilitar;
    document.getElementById("rbtnListPolizaContrato_1").disabled = bdrHabilitar;
}

function LlenadoEspecialDeDrop(comboALlenar, NoRegistros, pBdrContinuar, pNombreFuncionDrop, pComboFillAuto) {
    if (NoRegistros == 1 && pBdrContinuar) {
        document.getElementById(comboALlenar).selectedIndex = 1;
        document.getElementById(comboALlenar).disabled = true;

        //Recursión.
        var FuncionDinamica = pNombreFuncionDrop + "('" + pComboFillAuto + "');";
        eval(FuncionDinamica);
    }
    else {
        return;
    }
}

function LimpiaCamposConEdad() {
    document.getElementById("rbtnListPolizaContrato_0").checked = true;
    limpiaCombo("drpPolizaGrupo");
    limpiaCombo("drpContrato");
    document.getElementById("divPolizaGrupo").style.visibility = "hidden";
    document.getElementById("divContrato").style.visibility = "hidden";

    if (selIndiceCtrl("drpAgente") < 1) {
        limpiaCtrlsConMoneda();
        //Con ésta función se llena la forma de pago y con el parámetro "true" le indicamos que 
        //una vez que haya llenado el drpFormaPago se llenará el drpMoneda.
        LlenarFormaPago('drpFormaPago', true);
    }
}

function obtenerCoberturas() {
    document.getElementById('DivCoberturas').innerHTML = "";

    var Ramo = document.getElementById("HiddenRamoRequest").value;
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }
    var Modalidad = document.getElementById("HiddenModalidad").value;
    var Tip_plan = document.getElementById("HiddenTipoPlanRequest").value;
    MetodosAjax.getCoberturasEdad(Ramo, contrato, Modalidad, document.getElementById("txtEdad").value, selIndex("drpMoneda"), Tip_plan, Coberturas_CallBack);

    MetodosAjax.getDctoSexoFuma(Ramo, Modalidad, 1000, getDctoSexoFuma_CallBack);

}

function Coberturas_CallBack(res) {
    if (res.error == null) {
        if (res != null && res.value != null) {
            document.getElementById('DivCoberturas').innerHTML = res.value;
            AjustarFrame();
        }
    }
}

function getDctoSexoFuma_CallBack(res) {
    if (res.error == null) {
        if (res != null && res.value != null && res.value.Rows.length != 0) {
            document.getElementById("HiddenDctoSex").value = res.value.Rows[0].NUM_DIF_MUJER;
            document.getElementById("HiddenDctoFuma").value = res.value.Rows[0].NUM_DIF_FUMADOR;
        }
    }
    else alert(res.error);
}

function validaCopia() {
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var agente = selValorCtrl("drpAgente");
    var cod_docum = document.getElementById(usrCtrl + 'hdnCLM').value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var edad = document.getElementById("txtEdad").value;
    var contrato = "";
    var polizaGpo = "";
    contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
        polizaGpo = textoCtrl("drpPolizaGrupo");
    }

    var validaCLM = CLM.validaCopia(parseInt(ramo), agente, "2", cod_docum, "", polizaGpo, contrato, modalidad, edad, "", "", "");
    if (validaCLM.error != null) {
        alert(validaCLM.error.description);
        return false;
    }
    return true;
}

function actSumaAseg(codCob, ctrlTxtSuma) {
    LimpiarPrimas();

    if (codCob != 1000) {
        try {
            if (document.getElementById("txtSuma1000").value != "") {
                var ramo = document.getElementById("HiddenRamoRequest").value;
                var modalidad = document.getElementById("HiddenModalidad").value;
                var suma_basica = document.getElementById("txtSuma1000").value;
                var suma = document.getElementById(ctrlTxtSuma).value;
                if (suma != "") {
                    var Validacion = MetodosAjax.validaCoberturas(codCob, ramo, modalidad, selIndex("drpMoneda"), suma_basica, suma);
                    if (Validacion.error == null) {
                        if (Validacion != null && Validacion.value != null) {
                            var Marca = Validacion.value.p_mca_valido;
                            var MensajeError = Validacion.value.p_error;
                            var Suma = Validacion.value.p_suma_aseg;
                            if (Marca != 'S') {
                                alert(MensajeError);
                                document.getElementById(ctrlTxtSuma).value = "";
                            }
                            else
                                document.getElementById(ctrlTxtSuma).value = Suma;
                        }
                    }
                }
            }
            else {
                alert("Primero debe capturar la suma Basica");
                document.getElementById(ctrlTxtSuma).value = "";
            }
        }
        catch (e) {
            if (document.getElementById(ctrlTxtSuma).value != "") {
                var ramo = document.getElementById("HiddenRamoRequest").value;
                var modalidad = document.getElementById("HiddenModalidad").value;
                var suma_basica = document.getElementById(ctrlTxtSuma).value;
                var suma = document.getElementById(ctrlTxtSuma).value;
                if (suma != "") {
                    var Validacion = MetodosAjax.validaCoberturas(codCob, ramo, modalidad, selIndex("drpMoneda"), suma_basica, suma);
                    if (Validacion.error == null) {
                        if (Validacion != null && Validacion.value != null) {
                            var Marca = Validacion.value.p_mca_valido;
                            var MensajeError = Validacion.value.p_error;
                            var Suma = Validacion.value.p_suma_aseg;
                            if (Marca != 'S') {
                                alert(MensajeError);
                                document.getElementById(ctrlTxtSuma).value = "";
                            }
                            else
                                if (codCob == "1014") {
                                    var SumaAsegBasica = parseInt(document.getElementById(ctrlTxtSuma).value);
                                    var SumaDesde = parseInt(document.getElementById("hdnSumaAsegDesde" + codCob).value);
                                    var SumaHasta = parseInt(document.getElementById("hdnSumaAsegHasta" + codCob).value);
                                    try {
                                        var ramo = document.getElementById("HiddenRamoRequest").value;
                                        var moneda = selIndex("drpMoneda");
                                        //

                                        if (ramo == 105) {

                                            if (moneda == 2) {
                                                SumaHasta = 150000;
                                            }

                                            if (moneda == 6) {
                                                SumaHasta = 380000;
                                            }

                                        }
                                    }
                                    catch (err) {

                                    }
                                    //adr
                                    if (!(SumaAsegBasica >= SumaDesde && SumaAsegBasica <= SumaHasta)) {
                                        alert("Rango fuera del permitido, la suma debe estar dentro de: " + SumaDesde + " hasta " + SumaHasta);
                                        document.getElementById(ctrlTxtSuma).value = "";
                                    } else {
                                        document.getElementById(ctrlTxtSuma).value = suma_basica;
                                    }



                                    var EdadAseg = parseInt(document.getElementById('txtEdad').value);
                                    var IngresoAsegAnual = parseFloat(document.getElementById('txtIngresoM').value);
                                    var TipoCambioDlls = parseFloat(document.getElementById("Footer_lblUSD").innerHTML);
                                    var TipoCambioUdis = parseFloat(document.getElementById("Footer_lblUDIS").innerHTML);
                                    var TipoMoneda = $('#drpMoneda').val();
                                    switch (TipoMoneda) {
                                        case '1':
                                            if (EdadAseg < 50) {
                                                if (SumaAsegBasica > (IngresoAsegAnual * 15)) {
                                                    alert("De acuerdo con el ingreso anual capturado, la suma asegurada solicitada para la cobertura básica rebasa el límite máximo permitido.");
                                                    document.getElementById(ctrlTxtSuma).value = "";
                                                }
                                            } else if (EdadAseg > 49) {
                                                if (SumaAsegBasica > (IngresoAsegAnual * 10)) {
                                                    alert("De acuerdo con el ingreso anual capturado, la suma asegurada solicitada para la cobertura básica rebasa el límite máximo permitido.");
                                                    document.getElementById(ctrlTxtSuma).value = "";
                                                }
                                            }
                                            break;
                                        case '2':
                                            if (EdadAseg < 50) {
                                                if (SumaAsegBasica > ((IngresoAsegAnual / TipoCambioDlls) * 15)) {
                                                    alert("De acuerdo con el ingreso anual capturado, la suma asegurada solicitada para la cobertura básica rebasa el límite máximo permitido.");
                                                    document.getElementById(ctrlTxtSuma).value = "";
                                                }
                                            } else if (EdadAseg > 49) {
                                                if (SumaAsegBasica > ((IngresoAsegAnual / TipoCambioDlls) * 10)) {
                                                    alert("De acuerdo con el ingreso anual capturado, la suma asegurada solicitada para la cobertura básica rebasa el límite máximo permitido.");
                                                    document.getElementById(ctrlTxtSuma).value = "";
                                                }
                                            }
                                            break;
                                        case '6':
                                            if (EdadAseg < 50) {
                                                if (SumaAsegBasica > ((IngresoAsegAnual / TipoCambioUdis) * 15)) {
                                                    alert("De acuerdo con el ingreso anual capturado, la suma asegurada solicitada para la cobertura básica rebasa el límite máximo permitido.");
                                                    document.getElementById(ctrlTxtSuma).value = "";
                                                }
                                            } else if (EdadAseg > 49) {
                                                if (SumaAsegBasica > ((IngresoAsegAnual / TipoCambioUdis) * 10)) {
                                                    alert("De acuerdo con el ingreso anual capturado, la suma asegurada solicitada para la cobertura básica rebasa el límite máximo permitido.");
                                                    document.getElementById(ctrlTxtSuma).value = "";
                                                }
                                            }
                                            break;
                                        default:

                                            break;
                                    }


                                    //                    
                                    //  document.getElementById(ctrlTxtSuma).value = suma_basica;

                                }
                                else {
                                    document.getElementById(ctrlTxtSuma).value = Suma;
                                }
                        }
                    }
                }
            }
            else {
                alert("Primero debe capturar la suma");
                document.getElementById(ctrlTxtSuma).value = "";
            }
        }

    }
    else {

        if (document.getElementById("txtSuma1000").value != "") {
            //Se valida Suma asegurada Básica.
            var ramo = document.getElementById("HiddenRamoRequest").value;
            var modalidad = document.getElementById("HiddenModalidad").value;
            var suma_basica = document.getElementById("txtSuma1000").value;
            var suma = document.getElementById(ctrlTxtSuma).value;
            if (suma != "") {
                var Validacion = MetodosAjax.validaCoberturas(codCob, ramo, modalidad, selIndex("drpMoneda"), suma_basica, suma);
                if (Validacion.error == null) {
                    if (Validacion != null && Validacion.value != null) {
                        var Marca = Validacion.value.p_mca_valido;
                        var MensajeError = Validacion.value.p_error;
                        var Suma = Validacion.value.p_suma_aseg;
                        if (Marca != 'S') {
                            alert(MensajeError);
                            document.getElementById(ctrlTxtSuma).value = "";
                        }
                        else {

                            // INICIO BWM-LDN
                            // A17547
                            // Primero valida la cobertura con MetodosAjax.validaCoberturas,
                            // despues se validan los importes maximos y minimos.

                            var SumaAsegBasica = parseInt(document.getElementById(ctrlTxtSuma).value);
                            var SumaDesde = parseInt(document.getElementById("hdnSumaAsegDesde" + codCob).value);
                            var TipoCambioDlls = parseFloat(document.getElementById("Footer_lblUSD").innerHTML);
                            var TipoCambioUdis = parseFloat(document.getElementById("Footer_lblUDIS").innerHTML);
                            var TipoMoneda = $('#drpMoneda').val();

                            switch (TipoMoneda) {
                                case '1':
                                    if (SumaAsegBasica > 1500000) {
                                        ConstruyeCuestionarioMillon();
                                    } else {
                                        document.getElementById("divCuestionarioMillon").innerHTML = "";
                                    }
                                    break;
                                case '2':
                                    if ((TipoCambioDlls * SumaAsegBasica) > 1500000) {
                                        ConstruyeCuestionarioMillon();
                                    } else {
                                        document.getElementById("divCuestionarioMillon").innerHTML = "";
                                    }
                                    break;
                                case '6':
                                    if ((TipoCambioUdis * SumaAsegBasica) > 1500000) {
                                        ConstruyeCuestionarioMillon();
                                    } else {
                                        document.getElementById("divCuestionarioMillon").innerHTML = "";
                                    }
                                    break;
                                default:
                                    document.getElementById("divCuestionarioMillon").innerHTML = "";
                                    break;
                            }

                            var SumaHasta = parseInt(document.getElementById("hdnSumaAsegHasta" + codCob).value);
                            var ramo = document.getElementById("HiddenRamoRequest").value;
                            var moneda = selIndex("drpMoneda");
                            var edad = document.getElementById("txtEdad").value;
                            var validaAdj2 = MetodosAjax.ValidaBtNAdjunta2(moneda);
                            //var activaDiv = 0;
                            //adr
                            if (ramo == 105) {

                                if (moneda == 2) {
                                    SumaHasta = 150000;
                                }

                                if (moneda == 6) {
                                    SumaHasta = 380000;
                                }

                            }

                            var cantMax = MetodosAjax.ValidaCantMax(ramo, modalidad, moneda, edad);
                            if (cantMax.value > 0) {
                                SumaHasta = cantMax.value;

                                //validacion de activacion Btn subir 2do archivo
                                if (SumaAsegBasica > validaAdj2.value) {
                                    //document.getElementById("divDivDocumentosAdjuntar2").style.visibility = "visible";
                                    document.getElementById("HiddenBtnAdj").value = 1;
                                    document.getElementById("hdnDivAdj2").value = "1";
                                }
                                else {
                                    //document.getElementById("divDivDocumentosAdjuntar2").style.visibility = "hidden";
                                    document.getElementById("HiddenBtnAdj").value = "";
                                    document.getElementById("hdnDivAdj2").value = "0";
                                }

                            }

                            //adr
                            if (!(SumaAsegBasica >= SumaDesde && SumaAsegBasica <= SumaHasta)) {
                                alert("Rango fuera del permitido, la suma debe estar dentro de: " + SumaDesde + " hasta " + SumaHasta);
                                document.getElementById(ctrlTxtSuma).value = "";
                            } else {
                                document.getElementById(ctrlTxtSuma).value = Suma;
                                ReObtenerConBasica();
                            }

                            var EdadAseg = parseInt(document.getElementById('txtEdad').value);
                            var IngresoAsegAnual = parseFloat(document.getElementById('txtIngresoM').value);
                            var TipoCambioDlls = parseFloat(document.getElementById("Footer_lblUSD").innerHTML);
                            var TipoCambioUdis = parseFloat(document.getElementById("Footer_lblUDIS").innerHTML);
                            var TipoMoneda = $('#drpMoneda').val();
                            switch (TipoMoneda) {
                                case '1':
                                    if (EdadAseg < 50) {
                                        if (SumaAsegBasica > (IngresoAsegAnual * 15)) {
                                            alert("De acuerdo con el ingreso anual capturado, la suma asegurada solicitada para la cobertura básica rebasa el límite máximo permitido.");
                                            document.getElementById(ctrlTxtSuma).value = "";
                                        }
                                    } else if (EdadAseg > 49) {
                                        if (SumaAsegBasica > (IngresoAsegAnual * 10)) {
                                            alert("De acuerdo con el ingreso anual capturado, la suma asegurada solicitada para la cobertura básica rebasa el límite máximo permitido.");
                                            document.getElementById(ctrlTxtSuma).value = "";
                                        }
                                    }
                                    break;
                                case '2':
                                    if (EdadAseg < 50) {
                                        if (SumaAsegBasica > ((IngresoAsegAnual / TipoCambioDlls) * 15)) {
                                            alert("De acuerdo con el ingreso anual capturado, la suma asegurada solicitada para la cobertura básica rebasa el límite máximo permitido.");
                                            document.getElementById(ctrlTxtSuma).value = "";
                                        }
                                    } else if (EdadAseg > 49) {
                                        if (SumaAsegBasica > ((IngresoAsegAnual / TipoCambioDlls) * 10)) {
                                            alert("De acuerdo con el ingreso anual capturado, la suma asegurada solicitada para la cobertura básica rebasa el límite máximo permitido.");
                                            document.getElementById(ctrlTxtSuma).value = "";
                                        }
                                    }
                                    break;
                                case '6':
                                    if (EdadAseg < 50) {
                                        if (SumaAsegBasica > ((IngresoAsegAnual / TipoCambioUdis) * 15)) {
                                            alert("De acuerdo con el ingreso anual capturado, la suma asegurada solicitada para la cobertura básica rebasa el límite máximo permitido.");
                                            document.getElementById(ctrlTxtSuma).value = "";
                                        }
                                    } else if (EdadAseg > 49) {
                                        if (SumaAsegBasica > ((IngresoAsegAnual / TipoCambioUdis) * 10)) {
                                            alert("De acuerdo con el ingreso anual capturado, la suma asegurada solicitada para la cobertura básica rebasa el límite máximo permitido.");
                                            document.getElementById(ctrlTxtSuma).value = "";
                                        }
                                    }
                                    break;
                                default:

                                    break;
                            }

                            var moneda = selValorCtrl("drpMoneda");

                            //Se comenta para aplicar validación en checkbox
                            //ValSumaAseg = MetodosAjax.ValidaSAAnexo(SumaAsegBasica, moneda);

                            //Se almacena valor y se recupera para validar si aplica el cuestionario de millon y medio
                            document.getElementById("hdnSumaAseg").value = SumaAsegBasica;

                            //Se comenta para aplicar validación en checkBox
                            //if (ValSumaAseg.value) {
                            //    //Mostrar div Preguntas millon y medio
                            //    ConstruyeCuestionarioMillon();
                            //}
                            //else {
                            //    document.getElementById("divCuestionarioMillon").innerHTML = "";
                            //}

                            // FINAL BWM-LDN
                        }
                    }
                }
            }
        }

        else {
            LimpCobConBasica();
        }

    }

}

function actMarcaCobertura(codCob, ctrlCbxCob, ctrlTxtSuma) {
    LimpiarPrimas();
    var CodigoRamo = document.getElementById("HiddenRamoRequest").value;
    var Modalidad = document.getElementById("HiddenModalidad").value;
    var Moneda = selIndex("drpMoneda");
    var Edad = document.getElementById("txtEdad").value;

    if (CodigoRamo == "101") {
        if (Moneda == "2" && document.getElementById("txtSuma1000").value > 250000 && Edad <= "50") {
            alert('La suma asegurada  no debe ser mayor a 250,000 dll con coberturas adicionales');
            document.getElementById("txtSuma1000").value = "250000";
        }

        if (Moneda == "2" && document.getElementById("txtSuma1000").value > 125000 && Edad >= "51" && Edad <= "65") {
            alert('La suma asegurada  no debe ser mayor a 125,000 dll con coberturas adicionales');
            document.getElementById("txtSuma1000").value = "125000";
        }

        if (Moneda == "2" && document.getElementById("txtSuma1000").value > 75000 && Edad >= "66" && Edad <= "70") {
            alert('La suma asegurada  no debe ser mayor a 75,000 dll con coberturas adicionales');
            document.getElementById("txtSuma1000").value = "75000";
        }


        if (Moneda == "1" && document.getElementById("txtSuma1000").value > 5110000 && Edad <= "50") {
            alert('La suma asegurada  no debe ser mayor a 5,110,000 pesos con coberturas adicionales');
            document.getElementById("txtSuma1000").value = "5110000";
        }

        if (Moneda == "1" && document.getElementById("txtSuma1000").value > 2555000 && Edad >= "51" && Edad <= "65") {
            alert('La suma asegurada  no debe ser mayor a 2,555,000 pesos con coberturas adicionales');
            document.getElementById("txtSuma1000").value = "2555000";
        }

        if (Moneda == "1" && document.getElementById("txtSuma1000").value > 1533000 && Edad >= "66" && Edad <= "70") {
            alert('La suma asegurada  no debe ser mayor a 1,533,000 pesos con coberturas adicionales');
            document.getElementById("txtSuma1000").value = "1533000";
        }

        if (Moneda == "6" && document.getElementById("txtSuma1000").value > 692412 && Edad <= "50") {
            alert('La suma asegurada  no debe ser mayor a 692,412 udis con coberturas adicionales');
            document.getElementById("txtSuma1000").value = "692412";
        }


        if (Moneda == "6" && document.getElementById("txtSuma1000").value > 346206 && Edad >= "51" && Edad <= "65") {
            alert('La suma asegurada  no debe ser mayor a 346,206 udis con coberturas adicionales');
            document.getElementById("txtSuma1000").value = "346206";
        }

        if (Moneda == "6" && document.getElementById("txtSuma1000").value > 207724 && Edad >= "66" && Edad <= "70") {
            alert('La suma asegurada  no debe ser mayor a 207,724 udis con coberturas adicionales');
            document.getElementById("txtSuma1000").value = "207724";
        }


    }


    if ((document.getElementById("txtSuma1000") && document.getElementById("txtSuma1000").value != "") || (CodigoRamo == "100" && Modalidad == "10007" && codCob == "1019")) {

        if (document.getElementById("hdnMarcaAcc" + codCob).value == "S") {
            DesmAccidentes(codCob);
        }

        if (document.getElementById("hdnSumaAsegDesde" + codCob).value == "0" && document.getElementById("hdnSumaAsegHasta" + codCob).value == "0") {
            if (document.getElementById(ctrlCbxCob).checked) {
                document.getElementById(ctrlTxtSuma).disabled = true;
                document.getElementById(ctrlTxtSuma).value = "AMPARADA";
            }
            else {
                document.getElementById(ctrlTxtSuma).disabled = true;
                document.getElementById(ctrlTxtSuma).value = "";
            }
        }
        else {
            if (document.getElementById(ctrlCbxCob).checked) {
                document.getElementById(ctrlTxtSuma).disabled = false;
                var SumaAseg = MetodosAjax.SumaAseguradaBasica(CodigoRamo, codCob, Modalidad, Moneda, document.getElementById("txtSuma1000").value);

                if (SumaAseg.error == null) {
                    if (SumaAseg != null && SumaAseg.value != null) {

                        // <---- apl 05122014 Se limpian la suma asegurada para los controles tipos RadioButton---->
                        var rds = document.getElementsByName('rbCobertura');
                        for (var s = 0; s < rds.length; s++) {
                            if (!rds[s].checked) {
                                document.getElementById("txtSuma" + rds[s].value).value = "";
                            }
                        }

                        var Suma = SumaAseg.value.p_suma_aseg;
                        var McaModifica = SumaAseg.value.p_mca_modifica;
                        document.getElementById(ctrlTxtSuma).value = Suma;
                        if (McaModifica != "S") {
                            document.getElementById(ctrlTxtSuma).disabled = true;
                        }

                    }
                }
            }
            else {
                document.getElementById(ctrlTxtSuma).disabled = true;
                document.getElementById(ctrlTxtSuma).value = "";
            }
        }
    }
    else {

        ////
        if (CodigoRamo == "105") {
            //      BIT   = txtSuma1011
            //      BIPA   = txtSuma1012
            //      TEMPORAL  =  txtSuma1014
            //      BEF = txtSuma1013

            if (document.getElementById('chk1').checked == true) {
                if (document.getElementById('txtSuma1014').value == '') {
                    document.getElementById('txtSuma1014').value = '';
                    document.getElementById('txtSuma1014').disabled = false;
                }

            }
            else {

                document.getElementById('txtSuma1014').value = '';
                document.getElementById('txtSuma1014').disabled = true;
                document.getElementById('chk1').checked = false;

            }
            try {
                if (document.getElementById('chk4').checked == true) {
                    if (document.getElementById('txtSuma1013').value == '') {
                        document.getElementById('txtSuma1013').disabled = false;
                        document.getElementById('txtSuma1013').value = 'AMPARADA';
                        document.getElementById('txtSuma1013').disabled = true;
                    }
                }
                else {
                    document.getElementById('txtSuma1013').disabled = false;
                    document.getElementById('txtSuma1013').value = '';
                    document.getElementById('txtSuma1013').disabled = true;
                    document.getElementById('chk4').checked = false;
                }
            }
            catch (err) {

            }


            if (document.getElementById('chk2').checked == true) {

                try {
                    if (document.getElementById('txtSuma1011').value == '') {
                        document.getElementById('txtSuma1011').disabled = false;
                        document.getElementById('txtSuma1011').value = 'AMPARADA';
                        document.getElementById('txtSuma1011').disabled = true;
                    }
                }
                catch (err) {
                    document.getElementById('txtSuma1013').disabled = false;
                    document.getElementById('txtSuma1013').value = 'AMPARADA';
                    document.getElementById('txtSuma1013').disabled = true;
                }


            }
            else {

                try {

                    document.getElementById('txtSuma1011').disabled = false;
                    document.getElementById('txtSuma1011').value = '';
                    document.getElementById('txtSuma1011').disabled = true;
                    document.getElementById('chk2').checked = false;
                }

                catch (err) {


                    document.getElementById('txtSuma1013').disabled = false;
                    document.getElementById('txtSuma1013').value = '';
                    document.getElementById('txtSuma1013').disabled = true;
                    document.getElementById('chk2').checked = false;

                }



            }
            try {
                if (document.getElementById('chk3').checked == true) {

                    if (document.getElementById('txtSuma1012').value == '') {
                        document.getElementById('txtSuma1012').disabled = false;
                        if (document.getElementById('chk2').checked == true || document.getElementById('chk1').checked == true) {
                            document.getElementById('txtSuma1012').disabled = false;
                            var numeroDecimal = Array();
                            var d1014 = document.getElementById('txtSuma1014').value;
                            if (d1014 != '') {
                                document.getElementById('txtSuma1012').value = document.getElementById('txtSuma1014').value;
                                document.getElementById('txtSuma1012').disabled = true;
                            }
                            else {
                                document.getElementById('txtSuma1012').value = '';
                            }

                            numeroDecimal = document.getElementById('txtSuma1012').value.split('.');
                            var valor = numeroDecimal[0].replace(/\$|\,/g, '');
                            if (selIndex("drpMoneda") == 2) {
                                if (parseInt(valor) > 500000) {
                                    //alert('La suma asegurada del BIPA tiene que ser menor o igual a la del temporal Individual y Mancomunado, pero no debe ser mayor a 500,000 dll');
                                    document.getElementById('txtSuma1012').value = "500,000.00";

                                }
                                else {
                                    if (document.getElementById('txtSuma1012').value != "") {
                                        //                       document.getElementById('txtSuma1012').value = formatCurrency(valor);
                                        document.getElementById('txtSuma1012').value = valor;
                                    }
                                }
                            }
                            else {
                                if (parseInt(valor) > "1400000.00") {
                                    //alert('La suma asegurada del BIPA tiene que ser menor o igual a la del temporal Individual y Mancomunado, pero no debe ser mayor a 1,400,000 udis');
                                    document.getElementById('txtSuma1012').value = "1,400,000.00";
                                }
                                else {
                                    //                   document.getElementById('txtSuma1012').value = formatCurrency(valor);
                                    document.getElementById('txtSuma1012').value = valor;
                                }
                            }//drpMoneda
                        }//else if 1012
                        
                    }
                }
                else {
                    document.getElementById('txtSuma1012').value = '';
                    document.getElementById('txtSuma1012').disabled = true;
                    document.getElementById('chk3').checked = false;
                }
            }
            catch (err) {

            }



        }
        else {

            /////

            alert("Primero debe capturar la suma Basica");
            document.getElementById(ctrlCbxCob).checked = false;

        }
    }
}

function DesmAccidentes(codCob) {
    var tbCoberturas = document.getElementById("Coberturas");
    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            if (document.getElementById("chk" + i).checked) {
                var cod_cob = document.getElementById("chk" + i).value;
                if (codCob != cod_cob) {
                    if (document.getElementById("hdnMarcaAcc" + cod_cob).value == "S") {
                        document.getElementById("chk" + i).checked = false;
                        document.getElementById("txtSuma" + cod_cob).disabled = true;
                        document.getElementById("txtSuma" + cod_cob).value = "";
                    }
                }
            }
        }
    }
}

//Calcula la fecha de Nacimiento en base a la edad
function calcula_fechaNac(edad) {
    if (document.all("txtEdad").value.length != 0) {
        //calculo la fecha de hoy 
        hoy = new Date()
        //resto los años de las dos fechas 
        anio = hoy.getFullYear()
        anioAseg = parseInt(anio) - parseInt(edad)
        fecha = "01/01/" + anioAseg
        document.all("hidFechaNac").value = fecha;
    } else {
        document.all("hidFechaNac").value = "";
    }
}

function DatosSeguroCLM(ctrlChk) {
    if (document.getElementById(ctrlChk.id).checked) {
        LlenarDatosDelSeguro();
        validarBotonEmite();
    }
    else {
        LimpiarDatosDelSeguro(true);
        habilitarCtrl("btnEmite", false);
    }

    valOcupacion();
}

function valOcupacion() {
    document.getElementById("drpOcupacion").selectedIndex = 0;
    document.getElementById("drpOcupacion").disabled = false;

    var ocu = document.getElementById("UscAsegCLM_hdnProfesion").value;
    if (ocu != "") {
        if (ocu == "-1")
            document.getElementById("drpOcupacion").selectedIndex = 0;
        else {
            selEnDrop("drpOcupacion", ocu);
            document.getElementById("drpOcupacion").disabled = true;
        }
    }
}

function selEnDrop(Drop, valor) {
    var combo = document.getElementById(Drop);
    var cantidad = combo.length;
    for (i = 0; i < cantidad; i++) {
        if (combo[i].value == valor) {
            combo[i].selected = true;
        }
    }
}

function validarBotonEmite() {
    if (document.getElementById("divPrimas").innerHTML != "")
        habilitarCtrl("btnEmite", false);
}

function LlenarDatosDelSeguro() {
    document.getElementById("lblPlan").innerText = document.getElementById("HiddenRamoDescripcion").value + " MONEDA " + textoCtrl("drpMoneda") + " " + textoCtrl("drpCrecimiento");
    document.getElementById("lblFormaPago").innerText = textoCtrl("drpFormaPago");
    document.getElementById("lblTipoPago").innerText = textoCtrl("drpTipoPago");
    document.getElementById("lblAsegurado").innerText = valorCtrl("UscAsegCLM_lblNombre") + " " + valorCtrl("UscAsegCLM_lblApellidoPaterno") + " " + valorCtrl("UscAsegCLM_lblApellidoMaterno");
    document.getElementById("lblFechaNac").innerText = valorCtrl("UscAsegCLM_lblNacimiento");
    document.getElementById("lblDomicilio").innerText = valorCtrl("UscAsegCLM_lblDireccion") + " " + valorCtrl("UscAsegCLM_lblColonia") + " " + valorCtrl("UscAsegCLM_lblEdo") + " " + valorCtrl("UscAsegCLM_lblCP");
    if (document.getElementById("HiddenRamoRequest").value == "105") {
        var primaTotal = document.querySelector("#lblPrimatotal").textContent;
        if (primaTotal.includes("USD")) {
            document.getElementById("lblPrimaTotal").innerText = formatCurrency(primaTotal.replace(/\$|\,|/g, '').replace("USD", ""));
        } else {
            document.getElementById("lblPrimaTotal").innerText = formatCurrency(primaTotal.replace(/\$|\,|/g, '').replace("UDIS", ""));
        }
    } else {
        document.getElementById("lblPrimaTotal").innerText = formatCurrency(document.getElementById('HiddenPrimaTotal').value);
    }
}

function LlenarDatosDelSeguro_105() {
    var tabla = document.getElementById("tblBenef105");
    var cadena = "";
    var nombre = "";
    var edad = "";
    //    var primas = MetodosAjax.setprimas();
    for (var i = 1; i < tabla.rows.length; i++) {
        var cell = tabla.rows[i].getElementsByTagName('td');

        nombre += cell[2].innerHTML + ",";
        edad += cell[3].innerHTML + ",";


    }

    document.getElementById("lblPlan").innerText = document.getElementById("HiddenRamoDescripcion").value + " MONEDA " + textoCtrl("drpMoneda") + " " + textoCtrl("drpCrecimiento");
    document.getElementById("lblFormaPago").innerText = textoCtrl("drpFormaPago");
    document.getElementById("lblTipoPago").innerText = textoCtrl("drpTipoPago");
    document.getElementById("lblAsegurado").innerText = nombre
    document.getElementById("lblFechaNac").innerText = edad
    document.getElementById("lblDomicilio").innerText = textoCtrl("UscAsegCLM_lblDireccion") + " " + textoCtrl("UscAsegCLM_lblColonia") + " " + textoCtrl("UscAsegCLM_lblEdo") + " " + valorCtrl("UscAsegCLM_lblCP") + " " + "México";
    document.getElementById("lblPrimaTotal").innerText = formatCurrency(document.getElementById('HiddenPrimaTotal').value);
}

function LimpiarDatosDelSeguro(bdrDatosCLM) {
    document.getElementById("lblPlan").innerText = "";
    document.getElementById("lblFormaPago").innerText = "";
    document.getElementById("lblTipoPago").innerText = "";
    document.getElementById("lblPrimaTotal").innerText = "";

    if (bdrDatosCLM) {
        document.getElementById("lblAsegurado").innerText = "";
        document.getElementById("lblFechaNac").innerText = "";
        document.getElementById("lblDomicilio").innerText = "";
    }
}

//Funciones de Impresión Nuevo Modelo.
function ImpSolicitud() {
    var strNombre = prompt('Ingresa el nombre del Cliente', '');
    if (strNombre == null) return;

    var Ramo = document.getElementById("HiddenRamoRequest").value;

    var vParametros = "Cliente=" + strNombre
        + "&Ramo=" + Ramo;

    window.open("../Impresion/TWImpSolicitud.aspx?" + vParametros, "VistaPrevia", "toolbar=false,scrollbars=1,resizable=0,width=800,height=680,left=0,top=0");

}

function ImpPoliza() {
    var strNombre = prompt('Ingresa el nombre del Cliente', '');
    if (strNombre == null) return;

    var Ramo = document.getElementById("HiddenRamoRequest").value;

    var vParametros = "Cliente=" + strNombre
        + "&Ramo=" + Ramo;

    window.open("../Impresion/TWImpPoliza.aspx?" + vParametros, "VistaPrevia", "toolbar=false,scrollbars=1,resizable=0,width=800,height=680,left=0,top=0");

}

//Funciones de Impresión Viejo Modelo
//Contenido.aspx?img=bannervida&bnn=vida&CodMenu=20305&cod_App=16&RutaApp=/EmisionGeneralVida/appAcceso.aspx?app=EmisionGeneral/EmisionGeneralVida.aspx?codRamo=100&codTipoPlan=6
var wnventanasol;
function MM_ImprimirSolicitud() {
    var lblpoliza = document.getElementById("lblNoPoliza").innerHTML;
    document.getElementById("btnImprimePoliza").disabled = false;
    //Datos de la Impresión.
    var poliza = document.getElementById("lblNoPoliza").innerText;
    var sector = 1;
    var usuario = document.getElementById("HiddenUsuario").value;
    var agente = document.getElementById("HiddenAgente").value;
    var boton = 'N';

    var relacion = "";

    var nacionalidad = manejoLabel("UscAsegCLM_lblNacionalidad");
    var Fuma = selValorCtrl("drpFuma");
    var Ocupacion = selValorCtrl("drpOcupacion");
    var RamoDesc = document.getElementById("HiddenRamoDescripcion").value;
    var Plazo = selValorCtrl("drpPlazo");
    var Peso = document.getElementById("txtPeso").value;
    var Estatura = document.getElementById("txtEstatura").value;
    var Edad = document.getElementById("txtEdad").value;

    var RelSol = Array();
    RelSol[0] = nacionalidad + "|" +
        Fuma + "|" +
        Ocupacion + "|" +
        RamoDesc + " " + Plazo + "|" +
        Peso + "|" +
        Estatura + "|" +
        Edad + "|";

    relacion = RelSol[0];

    var correo = manejoLabel("UscAsegCLM_lblCorreo");

    if (lblpoliza.substring(0, 2) != 10) {
        //Validamos si es una impresión de solicitud de Emisión General Vida apl 08.12.2014
        // Agregamos parametro EGVImpSol = Emisión General Vida Impresión Solicitud
        wnventanasol = window.open('/impresionSeGA/TWImpSolicitudMarco.aspx?noPoliza=' + poliza + '&sector=' + sector + '&usuario=' + usuario + '&agente=' + agente + "&eMail=" + correo + "&btnPoliza=" + boton + "&RelSol=" + relacion + "&EGVImpSol=1", 'SOLICITUD', 'toolbar=false,scrollbars=1,resizable=0,width=800,height=680,left=0,top=0');
    }
    else {
        wnventanasol = window.open('/impresionSeGA/TWImpSolicitudMarco.aspx?noPoliza=' + poliza + '&sector=' + sector + '&usuario=' + usuario + '&agente=' + agente + "&eMail=" + correo + "&btnPoliza=" + boton + "&RelSol=" + relacion, 'SOLICITUD', 'toolbar=false,scrollbars=1,resizable=0,width=800,height=680,left=0,top=0');
    }
}

function MM_ImprimirPoliza() {
    document.getElementById("btnNuevaSolicitud").disabled = false;

    var poliza = document.getElementById("lblNoPoliza").innerText;
    var sector = 1;
    var usuario = document.getElementById("HiddenUsuario").value;
    var agente = document.getElementById("HiddenAgente").value;
    var correo = manejoLabel("UscAsegCLM_lblCorreo");

    if (!confirm(unescape("Si desea obtener la p%f3liza a traves de la oficina en donde usted imprime sus p%f3lizas y endosos de vida presione ACEPTAR, \nde lo contrario presione CANCELAR para impirmirla en este momento")))
        window.open('/impresionSeGA/TWImpPolizaMarco.aspx?noPoliza=' + poliza + '&sector=' + sector + '&simpol=n&usuario=' + usuario + '&agente=' + agente + '&eMail=' + correo, 'POLIZA', 'toolbar=false,scrollbars=1,resizable=0,width=800,height=680,left=30,top=30');

}

function getEmailAgente() {
    var EmailAgente = MetodosAjax.getCorreoAgente(selValorCtrl("drpAgente"));
    document.getElementById("HiddenEmailAgente").value = EmailAgente;
}

// Valida la seleccion de un checkbox de la tabla de preguntas
function selCheckBox(i, sel) {
    if (sel == "Si") {
        document.getElementById("chkNo" + i).checked = false;
    }
    else if (sel == "No")
        document.getElementById("chkSi" + i).checked = false;
    var numPreg = document.getElementById("gvCuestionario").rows.length - 1;
    var totalPreguntasNo = 0;
    var totalPreguntasSi = 0;
    for (var preg = 1; preg <= numPreg; preg++) {
        var chkSi;
        var chkNo;
        try {
            if (document.getElementById("chkSi" + preg) != null) {
                if (document.getElementById("chkSi" + preg).checked) {
                    totalPreguntasSi++;
                }
            }
            if (document.getElementById("chkNo" + preg) != null) {
                if (document.getElementById("chkNo" + preg).checked) {
                    totalPreguntasNo++;
                }
            }
        }
        catch (e) { alert(e); }
    }

    if (numPreg == totalPreguntasNo) {
        var resValidacion = ValidarFirma();
        if (resValidacion == "P") {
            //Todas las preguntas tienen No
            //if (!ValSumaAseg.value) {
            //    //Mostrar div Preguntas millon y medio
            //    //document.getElementById("divCuestionarioMillon").style.display = "block";
            //    //ConstruyeCuestionarioMillon();
            //}
            //else {
            //    document.getElementById("divCuestionarioMillon").innerHTML = "";
            //}
            //Mostrar firma digital
            //document.getElementById("divFirma").style.display = "block";
            document.getElementById("divChkConf").style.visibility = "visible";
            document.getElementById("chkboxSiFirma").checked = false;
            document.getElementById("chkboxNoFirma").checked = false;
            document.getElementById("divEmite").style.display = "none";
            document.getElementById("divEmiteTxt").style.display = "none";
            document.getElementById("divEmiteAdj").style.display = "none";
            document.getElementById("divDivDocumentosAdjuntar2").style.visibility = "hidden";
        }
        else {
            //Ocultar firma digital
            // document.getElementById("divCuestionarioMillon").innerHTML = "";
            document.getElementById("divFirma").style.display = "none";
            //document.getElementById("divChkConf").style.visibility = "hidden";
            document.getElementById("chkboxSiFirma").checked = false;
            document.getElementById("chkboxNoFirma").checked = false;
            document.getElementById("divEmite").style.display = "block";
            document.getElementById("divEmiteTxt").style.display = "block";
            document.getElementById("divEmiteAdj").style.display = "block";

            if (document.getElementById("hdnDivAdj2").value == "1") { document.getElementById("divDivDocumentosAdjuntar2").style.visibility = "visible"; }
            else { document.getElementById("divDivDocumentosAdjuntar2").style.visibility = "hidden"; }
        }
    }
    else {
        //Ocultar firma digital
        //document.getElementById("divCuestionarioMillon").innerHTML = "";
        document.getElementById("divFirma").style.display = "none";
        //document.getElementById("divChkConf").style.visibility = "hidden";
        document.getElementById("chkboxSiFirma").checked = false;
        document.getElementById("chkboxNoFirma").checked = false;
        document.getElementById("divEmite").style.display = "block";
        document.getElementById("divEmiteTxt").style.display = "block";
        document.getElementById("divEmiteAdj").style.display = "block";

        if (document.getElementById("hdnDivAdj2").value == "1") { document.getElementById("divDivDocumentosAdjuntar2").style.visibility = "visible"; }
        else { document.getElementById("divDivDocumentosAdjuntar2").style.visibility = "hidden"; }
    }
}

// Valida el cuestionario
function validaCuest() {
    if (document.getElementById("HiddenRamoRequest").value == "105") {
        if (document.getElementById("rdoMenor").checked) {
            return true;
        }
    }
    var numPreg = document.getElementById("gvCuestionario").rows.length - 1;
    for (var preg = 1; preg <= numPreg; preg++) {
        var chkSi;
        var chkNo;
        try {
            if (document.getElementById("chkSi" + preg) != null)
                chkSi = document.getElementById("chkSi" + preg).checked;
            if (document.getElementById("chkNo" + preg) != null)
                chkNo = document.getElementById("chkNo" + preg).checked;
        }
        catch (e) { alert(e); }


        if (chkSi == false && chkNo == false) {
            document.getElementById("chkNo" + preg).focus();
            return false;
        }
    }
    return true;
}

function validaCuestResp() {
    if (document.getElementById("HiddenRamoRequest").value == "105") {
        if (document.getElementById("rdoMenor").checked) {
            return true;
        }
    }
    var numPreg = document.getElementById("gvCuestionario").rows.length - 1;
    for (var preg = 1; preg <= numPreg; preg++) {
        var chkSi;
        var chkNo;
        try {
            if (document.getElementById("chkSi" + preg) != null)
                chkSi = document.getElementById("chkSi" + preg).checked;
            if (document.getElementById("chkNo" + preg) != null)
                chkNo = document.getElementById("chkNo" + preg).checked;
        }
        catch (e) { alert(e); }

        if (preg == 14 && chkSi == true) {
            if (document.getElementById('txt14').value == '')
                return false;
        }

        if (preg == 15 && chkSi == true) {
            if (document.getElementById('txt15').value == '')
                return false;
        }

        if (preg == 16 && chkSi == true) {
            if (!document.getElementById('chk16a').checked) {
                if (!document.getElementById('chk16b').checked) {
                    if (!document.getElementById('chk16c').checked) {
                        if (!document.getElementById('chk16d').checked) {
                            if (!document.getElementById('chk16e').checked) {
                                if (!document.getElementById('chk16f').checked) {
                                    if (!document.getElementById('chk16g').checked) {
                                        if (!document.getElementById('chk16h').checked) {
                                            return false;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }



        if (preg == 17 && chkSi == true) {
            if (document.getElementById('txt17a').value == 'Seleccione' || document.getElementById('txt17b').value == '') {
                return false;
            }
        }

        if (preg == 18 && chkSi == true) {
            if (document.getElementById('txt18a').value == '' || document.getElementById('txt18b').value == 'Seleccione' || document.getElementById('txt18c').value == '') {
                return false;
            }
        }

        if (preg == 19 && chkSi == true) {
            if (document.getElementById('txt19a').value == 'Seleccione' || document.getElementById('txt19b').value == '') {
                return false;
            }
        }

        if (preg == 20 && chkSi == true) {
            if (document.getElementById('txt20a').value == '' || document.getElementById('txt20b').value == '' || document.getElementById('txt20c').value == '') {
                return false;
            }
        }

        if (preg == 21 && chkSi == true) {
            if (document.getElementById('txt21').value == '')
                return false;
        }

        if (preg == 22 && chkSi == true) {
            if (document.getElementById('txt22a').value == '' || document.getElementById('txt22b').value == 'Seleccione' || document.getElementById('txt22c').value == 'Seleccione') {
                return false;
            }
        }

        if (preg == 23 && chkSi == true) {
            if (document.getElementById('txt23a').value == '' || document.getElementById('txt23b').value == '' || document.getElementById('txt23c').value == 'Seleccione' || document.getElementById('txt23d').value == 'Seleccione') {
                return false;
            }
        }

        if (preg == 24 && chkSi == true) {
            if (document.getElementById('txt24a').value == '' || document.getElementById('txt24b').value == '') {
                return false;
            }
        }

        if (preg == 25 && chkSi == true) {
            if (document.getElementById('txt25a').value == '' || document.getElementById('txt25b').value == '' || document.getElementById('txt25c').value == '') {
                return false;
            }
        }
    }
    return true;

}
function ValidaServFune() {
    if (document.getElementById("HiddenRamoRequest").value == "105") {
        if (document.getElementById("rdoMenor").checked) {
            return false;
        }
    }
    var MarcaSF = false;
    var tbCoberturas = document.getElementById("Coberturas");
    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            if (document.getElementById("chk" + i).checked) {
                if (document.getElementById("chk" + i).value == "1019")
                    MarcaSF = true;
            }
        }
    }

    if (MarcaSF) {
        var valorCLM = valorCtrl("UscAsegCLM_hdnCLM");
        var validaCLM = MetodosAjax.validaCLMServFun(valorCLM);
        if (validaCLM.error == null) {
            if (validaCLM != null && validaCLM.value != null) {
                var MarcaVal = validaCLM.value.p_mca_valido;
                var Mensaje = validaCLM.value.p_valida;
                if (MarcaVal == 'S')
                    return false; //No cuenta con servicios funerarios debe dejar pasar.
                else {
                    alert(Mensaje);
                    DesmarcarServFun();
                    return true; //Ya cuenta con servicios funerarios No debe dejar Pasar
                }
            }
        }
        else {
            alert(validaCLM.error.description);
            return true; //No debe dejar pasar.
        }
    }
    else
        return false; //No aparece Servicios Funerarios. Debe dejar Pasar .
}

function DesmarcarServFun() {

    document.getElementById('divPrimas').innerHTML = "";

    var tbCoberturas = document.getElementById("Coberturas");
    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            var cod_cob = document.getElementById("chk" + i).value;
            if (cod_cob == "1019") {
                if (document.getElementById("chk" + i).checked) {
                    document.getElementById("chk" + i).checked = false;
                    document.getElementById("txtSuma" + cod_cob).disabled = true;
                    document.getElementById("txtSuma" + cod_cob).value = "";
                    document.getElementById("txtPrima" + cod_cob).value = "";
                }
            }
        }
    }
}

function NuevaEmision() {
    window.location.href = "../appAcceso.aspx?app=EmisionGeneral/EmisionGeneralVida.aspx?codRamo=" + document.getElementById("HiddenRamoRequest").value;
    //focusCtrl("drpAgente");
}

function EsperaImpPoliza() {
    Cargando(true);
    setTimeout("EjecutarImpPoliza();", document.getElementById("HiddenTiempoRetardo").value)
}

function EjecutarImpPoliza() {
    Cargando(false);
    MM_ImprimirPoliza();
}

function LimpiarPrimas() {
    document.getElementById('divPrimas').innerHTML = "";
}

function LimpCobConBasica() {
    var tbCoberturas = document.getElementById("Coberturas");
    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            if (document.getElementById("chk" + i).checked) {
                if (document.getElementById("chk" + i).value != "1000") {
                    var cod_cob = document.getElementById("chk" + i).value;
                    if (document.getElementById("chk" + i).disabled != true) {
                        document.getElementById("chk" + i).checked = false;
                        document.getElementById("txtSuma" + cod_cob).disabled = true;
                        document.getElementById("txtSuma" + cod_cob).value = "";
                    }
                    else
                        document.getElementById("txtSuma" + cod_cob).value = "";
                }
            }
        }
    }
}

function ReObtenerConBasica() {
    Cargando(true);
    var tbCoberturas = document.getElementById("Coberturas");
    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            if (document.getElementById("chk" + i).checked) {
                if (document.getElementById("chk" + i).value != "1000") {
                    var cod_cob = document.getElementById("chk" + i).value;
                    if (document.getElementById("txtSuma1000").value != "") {
                        var ramo = document.getElementById("HiddenRamoRequest").value;
                        var modalidad = document.getElementById("HiddenModalidad").value;
                        var suma_basica = document.getElementById("txtSuma1000").value;
                        var sumaCob = document.getElementById("txtSuma" + cod_cob).value;
                        if (sumaCob != "") {
                            if (isNaN(sumaCob))
                                document.getElementById("txtSuma" + cod_cob).value = "AMPARADA";
                            else {
                                var Validacion = MetodosAjax.validaCoberturas(cod_cob, ramo, modalidad, selIndex("drpMoneda"), suma_basica, sumaCob);
                                if (Validacion.error == null) {
                                    if (Validacion != null && Validacion.value != null) {
                                        var Marca = Validacion.value.p_mca_valido;
                                        var MensajeError = Validacion.value.p_error;
                                        var Suma = Validacion.value.p_suma_aseg;
                                        if (Marca != 'S') {
                                            document.getElementById("txtSuma" + cod_cob).value = "";
                                        }
                                        else
                                            document.getElementById("txtSuma" + cod_cob).value = Suma;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    Cargando(false);
}
//C1 <---- ini ---->
function obtenerCoberturas105() {

    if (selIndex("drpParentescoAseg") == "37") {

        document.getElementById('txtNombreBenef').disabled = true;
        document.getElementById('txtPaternoBenef').disabled = true;
        document.getElementById('txtMaternoBenef').disabled = true;
        document.getElementById('drpTipBenef').disabled = true;
        document.getElementById('drpParentesco').disabled = true;
        document.getElementById('txtPctBenef').disabled = true;
        document.getElementById('txtFecNac').disabled = true;
        document.getElementById('txtFecNac').disabled = true;
        document.getElementById('txtDomicilio').disabled = true;
        document.getElementById('txtTel').disabled = true;
        document.getElementById('txtMail').disabled = true;


        try {
            document.getElementById('txtSuma1014').disabled = true;
            document.getElementById('chk1').disabled = true;
        }
        catch (err) {

            var mancomunado = false;

            try {
                mancomunado = document.getElementById("chkManco_Si").checked;
            }
            catch (err) {
                mancomunado = false;
            }

            if (mancomunado == false) {
                alert("Para elegir mancomunado debe seleccionar primero al titular");
                document.getElementById("drpParentescoAseg").value = 0;
                document.getElementById("txtEdadParentesco").value = "";
                throw new Error("Para elegir mancomunado debe seleccionar primero al titular");
            }

        }
        try {
            document.getElementById('chk4').disabled = true;
            document.getElementById('txtSuma1013').disabled = true;
        }
        catch (err) { }
        try {
            document.getElementById('chk2').disabled = true;
            document.getElementById('txtSuma1011').disabled = true;
        }
        catch (err) { }
        try {
            document.getElementById('chk3').disabled = true;
            document.getElementById('txtSuma1012').disabled = true;
        }
        catch (err) { }

    }
    else {

        document.getElementById('txtNombreBenef').disabled = false;
        document.getElementById('txtPaternoBenef').disabled = false;
        document.getElementById('txtMaternoBenef').disabled = false;
        document.getElementById('drpTipBenef').disabled = false;
        document.getElementById('drpParentesco').disabled = false;
        document.getElementById('txtPctBenef').disabled = false;
        document.getElementById('txtFecNac').disabled = false;
        document.getElementById('txtFecNac').disabled = false;
        document.getElementById('txtDomicilio').disabled = false;
        document.getElementById('txtTel').disabled = false;
        document.getElementById('txtMail').disabled = false;


        document.getElementById('dvCobertura105').innerHTML = "";

        var Ramo = document.getElementById("HiddenRamoRequest").value;
        var contrato = document.getElementById("HiddenContratoGenerico").value;
        if (document.getElementById("rbtnListPolizaContrato_1").checked) {
            contrato = selIndex("drpContrato");
        }
        var Modalidad = document.getElementById("HiddenModalidad").value;
        var Tip_plan = document.getElementById("HiddenTipoPlanRequest").value;
        MetodosAjax.getCoberturasEdad(Ramo, contrato, Modalidad, document.getElementById("txtEdadParentesco").value, selIndex("drpMoneda"), Tip_plan, Coberturas105_CallBack);
    }
}
function Coberturas105_CallBack(res) {
    if (res.error == null) {
        if (res != null && res.value != null) {
            document.getElementById('dvCobertura105').innerHTML = res.value;
            AjustarFrame();
        }
    }
}
function OcultaSeg_Manco() {

    if (selIndex("drpParentescoAseg") != "4")
        document.getElementById("trMancomunado").style.display = "none";
    else
        document.getElementById("trMancomunado").style.display = "block";

    if (selIndex("drpParentescoAseg") == "38") {
        document.getElementById("divCuestionario").style.display = "none";
        document.getElementById("cuestionario").style.display = "none";
        document.getElementById("cuestionario1").style.display = "none";
    }
    else {
        document.getElementById("divCuestionario").style.display = "block";
        document.getElementById("cuestionario").style.display = "block";
        document.getElementById("cuestionario1").style.display = "block";

    }

}
function OcultaSeg_Manco105() {


    document.getElementById('drpMoneda').disabled = true;
    document.getElementById('drpPlazo').disabled = true;
    document.getElementById('txtNoAseg').disabled = true;
    document.getElementById('drpFormaPago').disabled = true;
    document.getElementById('drpTipoPago').disabled = true;


    if (selIndex("drpParentescoAseg") != "4")
        document.getElementById("trMancomunado").style.display = "none";
    else
        document.getElementById("trMancomunado").style.display = "block";

    if (selIndex("drpParentescoAseg") == "38") {
        document.getElementById("divCuestionario").style.display = "none";
        document.getElementById("cuestionario").style.display = "none";
        document.getElementById("cuestionario1").style.display = "none";
    }
    else {
        document.getElementById("divCuestionario").style.display = "block";
        document.getElementById("cuestionario").style.display = "block";
        document.getElementById("cuestionario1").style.display = "block";

    }


}
function ValidaBeneficiario105() {
    var tabla = document.getElementById("tblBenef105");
    var edad = parseInt(document.getElementById("txtEdadParentesco").value);
    var validaedad = MetodosAjax.ComparaEdad(edad);
    var mancomunado;
    try {
        mancomunado = document.getElementById("chkManco_Si").checked;
    }
    catch (err) {
        mancomunado = false;
    }
    //    if (validaedad == false)
    //    {
    //    alert("Los asegurados menores deben ser capturados del MENOR al MAS GRANDE, favor de verificar.");
    //    throw new Error("Los asegurados menores deben ser capturados del MENOR al MAS GRANDE, favor de verificar.");
    //    }
    //    else
    //    { 
    if (selIndex("drpParentescoAseg") == "37") {
        if (mancomunado == false) {
            alert("Para elegir mancomunado debe seleccionar primero al titular");
            document.getElementById("drpParentescoAseg").value = 0;
            document.getElementById("txtEdadParentesco").value = "";
            throw new Error("Para elegir mancomunado debe seleccionar primero al titular");
        }
    }


    if (mancomunado) {

        if (selIndex("drpParentescoAseg") != "37") {
            for (var k = 0; k < 1; k++) {
                alert("Debe elegir un MACOMUNADO");

                document.getElementById("drpParentescoAseg").value = 0;
                document.getElementById("txtEdadParentesco").value = "";

                break;
            }
        }

    }

    if (mancomunado == false) {
        if (selIndex("drpParentescoAseg") == "37") {
            if (validaedad == false) {
                alert("Los aseguerados deben capturarse de Mayor menor edad");
                throw new Error("Los aseguerados deben capturarse de Mayor menor edad");
            }

            for (var k = 0; k < 1; k++) {
                alert("Debe elegir un TITULAR");

                document.getElementById("drpParentescoAseg").value = 0;
                document.getElementById("txtEdadParentesco").value = "";

                break;
            }
        }
    }


    if (tabla.rows.length >= 2) {
        var no_aseg = document.getElementById("txtNoAseg").value;


        if (parseInt(no_aseg) > 3) {


            switch (selIndex("drpParentescoAseg")) {
                case "38": validaedad105();
                    break;
                //                case "4": alert("Debe ingresar primero todos los asegurados con el parentesco de HIJO/A.");
                //                    document.getElementById("txtEdadParentesco").value = "";
                //                    document.getElementById("drpParentescoAseg").focus();
                //                    break;
                //                case "37": alert("Para asegurar el MACOMUNADO debe amparar la cobertura de TEMPORAL con el TITULAR.");
                //                    document.getElementById("txtEdadParentesco").value = "";
                //                    document.getElementById("drpParentescoAseg").focus();
                //                    break;
            }
        }
    }
    else {
        switch (selIndex("drpParentescoAseg")) {
            case "38": validaedad105();
                break;
            case "4": alert("Debe ingresar primero todos los asegurados con el parentesco de HIJO/A.");
                document.getElementById("txtEdadParentesco").value = "";
                document.getElementById("drpParentescoAseg").focus();
                break;
            case "37": alert("Para asegurar el MACOMUNADO debe amparar la cobertura de TEMPORAL con el TITULAR.");
                document.getElementById("txtEdadParentesco").value = "";
                document.getElementById("drpParentescoAseg").focus();
                break;
        }
    }
    //    }  
}
function validaedad105() {
    var edad = document.getElementById("txtEdadParentesco").value;
    var duracion = selIndex("drpPlazo");
    if ((parseInt(duracion) - parseInt(edad)) < 5) {
        alert("La edad del asegurado debe ser menor de " + parseInt(duracion - 4) + " años");
        document.getElementById("txtEdadParentesco").value = parseInt(duracion - 5);
        obtenerCoberturas105();
    }
}
function agregaBenef() {
    var edad = document.getElementById("txtEdadParentesco").value;
    var validaedad = MetodosAjax.ComparaEdad(parseInt(edad));
    var cod_parent2 = document.getElementById("drpParentescoAseg").value;
    var mancomunado;
    try {
        mancomunado = document.getElementById("chkManco_Si").checked;
    }
    catch (err) {
        mancomunado = false;
    }

    var porcentajeprincipal = MetodosAjax.setPorcentaje6();
    var porventajeadicional = MetodosAjax.setm_Tip_Benef();

    if (porcentajeprincipal.value == 0) {

    }
    else {
        if (porcentajeprincipal.value < 100) {
            alert("Los beneficiarios principales no cumple el 100%");
            throw new Error("Los beneficiarios principales no cumple el 100%");
        }
    }

    if (porventajeadicional.value == 0) { }
    else {
        if (porventajeadicional.value < 100) {
            alert("Los beneficiarios adicionales no cumple el 100%");
            throw new Error("Los beneficiarios adicionales no cumple el 100%");
        }
    }


    if (cod_parent2 == 4) {
        if (document.getElementById('chk3').checked == true) {
            var v1014 = document.getElementById('txtSuma1014').value;
            var v1012 = document.getElementById('txtSuma1012').value;

            if (v1014 < v1012) {

                alert("La suma asegurada del BIPA tiene que ser menor o igual a la del temporal Individual y Mancomunado");
                throw new Error("La suma asegurada del BIPA tiene que ser menor o igual a la del temporal Individual y Mancomunado");
            }
            else {

            }
        }
    }
    if (cod_parent2 == 4 && mancomunado == true) {

        if (document.getElementById('chk1').checked == false) {
            if (document.getElementById('txtSuma1014').value == '') {
                alert("En mancomunados se debe de elegir la cobertura temporal");
                throw new Error("En mancomunados se debe de elegir la cobertura temporal.");

            }

        }


    }
    if (validaedad.value == false && cod_parent2 == 38) {
        alert("Los asegurados menores deben ser capturados del MENOR al MAS GRANDE, favor de verificar.");

    }
    else {
        var num_ase = document.getElementById("txtNoAseg").value;
        var divBenef105 = document.getElementById("trCob_benef_105");
        var tabBenef105 = divBenef105.getElementsByTagName('Table');
        if (tabBenef105[0].rows.length - 1 < parseInt(num_ase)) {
            document.getElementById("trCob_benef_105").style.display = "block";
            var tabla = document.getElementById("tblBenef105");
            var posicion = tabla.rows.length;
            var row = tabla.insertRow();
            var cellCod_parentesco = row.insertCell(0);
            cellCod_parentesco.innerHTML = document.getElementById("drpParentescoAseg").value;
            cellCod_parentesco.className = "EtiquetaGeneralDescripcion";
            cellCod_parentesco.style.display = "none";
            var cellParentesco = row.insertCell(1);
            var combo = document.getElementById("drpParentescoAseg");
            cellParentesco.innerHTML = combo.options[combo.selectedIndex].text;
            cellParentesco.className = "EtiquetaGeneralDescripcion";
            var cellNombreAseg = row.insertCell(2);
            var Ramo = document.getElementById("HiddenRamoRequest").value;
            if (Ramo == "105") {
                cellNombreAseg.innerHTML = document.getElementById("UscAsegCLM_lblNombre").innerHTML;
                cellNombreAseg.className = "EtiquetaGeneralDescripcion";
                var nombre_aseg = document.getElementById("UscAsegCLM_lblNombre").innerHTML;
                var cod_docum_aseg = document.getElementById("UscAsegCLM_lblCLM").innerHTML;
                var rfc_aseg = document.getElementById("UscAsegCLM_lblRFC").innerHTML;
                var nombre_aseg = document.getElementById("UscAsegCLM_lblNombre").innerHTML;
                var paterno_aseg = document.getElementById("UscAsegCLM_lblApellidoPaterno").innerHTML;
                var materno_aseg = document.getElementById("UscAsegCLM_lblApellidoMaterno").innerHTML;
                var cod_parent = document.getElementById("drpParentescoAseg").value;
                var nom_parent = combo.options[combo.selectedIndex].text;
                var fec_nac = document.getElementById("UscAsegCLM_lblNacimiento").innerHTML;
                var edad_aseg = document.getElementById("UscAsegCLM_lblEdad").innerHTML;
                var sexo_aseg = document.getElementById("UscAsegCLM_lblSexo").innerHTML;
                var edo_civil = document.getElementById("UscAsegCLM_lblEdoCivil").innerHTML;
                var nom_civil = document.getElementById("UscAsegCLM_lblEdoCivil").innerHTML;


            }
            else {
                cellNombreAseg.innerHTML = document.getElementById("UscContCLM_lblNombre").innerHTML;
                cellNombreAseg.className = "EtiquetaGeneralDescripcion";
            }

            var cellEdadAseg = row.insertCell(3);
            cellEdadAseg.innerHTML = document.getElementById("txtEdadParentesco").value;
            cellEdadAseg.className = "EtiquetaGeneralDescripcion";
            var cellSumaAseg = row.insertCell(4);
            var cellCobertura = row.insertCell(5);
            var cellCod_cob = row.insertCell(6);
            var divCoberturas = document.getElementById("dvCobertura105");
            var suma;
            var cobertura;
            var tabCoberturas = divCoberturas.getElementsByTagName('Table');
            for (var i = 1; i < tabCoberturas[0].rows.length; i++) {
                var cell = tabCoberturas[0].rows[i].getElementsByTagName('td');
                if (cell[0].firstChild.checked) {

                    if (suma == undefined) {
                        if (cell[2].firstChild.value == "AMPARADA") {
                            suma = 0;
                        }
                        else {
                            suma = cell[2].firstChild.value.replace(/\$|\,/g, '');
                        }
                    }
                    else {
                        if (cell[2].firstChild.value == "AMPARADA") {
                            suma = suma;
                        }
                        else {
                            suma = parseInt(suma) + parseInt(cell[2].firstChild.value.replace(/\$|\,/g, ''));
                        }
                    }

                    if (cobertura == undefined) {
                        cobertura = cell[1].innerText;
                    }
                    else {
                        cobertura = cobertura + " , " + cell[1].innerText;
                    }

                    var coberturas = cell[1].innerText;
                    var sumacobertura = parseInt(cell[2].firstChild.value.replace(/\$|\,/g, ''));
                    var bandera = isNaN(sumacobertura);
                    if (coberturas == "BIT" || coberturas == "BEF") { }
                    else {
                        if (bandera == true) {
                            alert("La cobertura no puede ir vacia");
                            throw new Error("La cobertura no puede ir vacia");
                        }
                    }
                    MetodosAjax.setCoberturas(coberturas, sumacobertura, cod_docum_aseg, cod_parent);

                    cellSumaAseg.innerHTML = suma;
                    cellSumaAseg.className = "EtiquetaGeneralDescripcion";
                    cellCobertura.innerHTML = cobertura;
                    cellCobertura.className = "EtiquetaGeneralDescripcion";
                    cellCod_cob.innerHTML = cell[0].firstChild.defaultValue;
                    cellCod_cob.className = "EtiquetaGeneralDescripcion";
                    cellCod_cob.style.display = "none";
                }
            }
            var cellCLM = row.insertCell(7);
            //        cellCLM.innerHTML = document.getElementById("UscContCLM_lblCLM").innerHTML;
            cellCLM.innerHTML = document.getElementById("UscAsegCLM_lblCLM").innerHTML;
            cellCLM.style.display = "none";
            MetodosAjax.GuardaSession(combo.options[combo.selectedIndex].text);
            if (Ramo == "105") {
                if (sexo_aseg == "Masculino") {
                    sexo_aseg = 1;
                }
                else {
                    sexo_aseg = 0;
                }

                MetodosAjax.insertaAseg(cod_docum_aseg, rfc_aseg, nombre_aseg, paterno_aseg, materno_aseg, parseInt(cod_parent), nom_parent, fec_nac, parseInt(edad_aseg), parseInt(sexo_aseg), edo_civil, nom_civil);

                //MetodosAjax.GuardaSession2(cod_docum_aseg.toString,rfc_aseg.toString,nombre_aseg.toString, paterno_aseg.toString, materno_aseg.toString,parseInt(cod_parent), nom_parent.toString,fec_nac.toString,parseInt(edad_aseg),parseInt(sexo_aseg),edo_civil.toString, nom_civil.toString);
            }


            document.getElementById("trBtn_Prima_105").style.display = "block";
            document.getElementById("trPrim_105").style.display = "block";
            limpiaCLM("UscAsegCLM_");
            limpBenef()


            var num_ase = document.getElementById("txtNoAseg").value;
            if (tabBenef105[0].rows.length - 1 == parseInt(num_ase)) {

                document.getElementById("drpParentescoAseg").style.display = "none";
                document.getElementById("txtEdadParentesco").style.display = "none";
                document.getElementById('txtNombreBenef').disabled = true;
                document.getElementById('txtPaternoBenef').disabled = true;
                document.getElementById('txtMaternoBenef').disabled = true;
                document.getElementById('drpTipBenef').disabled = true;
                document.getElementById('drpParentesco').disabled = true;
                document.getElementById('txtPctBenef').disabled = true;
                document.getElementById('txtFecNac').disabled = true;
                document.getElementById('txtFecNac').disabled = true;
                document.getElementById('txtDomicilio').disabled = true;
                document.getElementById('txtTel').disabled = true;
                document.getElementById('txtMail').disabled = true;
                document.getElementById("UscAsegCLM_txtRFC").style.display = "none";
                try {
                    document.getElementById("chkManco_Si").style.display = "none";
                }
                catch (err) { }

            }





        }
    }
}
function limpBenef() {
    var edad = parseInt(document.getElementById("txtEdadParentesco").value);
    MetodosAjax.setEdad(edad);
    document.getElementById("drpParentescoAseg").value = 0;
    document.getElementById("txtEdadParentesco").value = "";
    document.getElementById("grdBeneficiarios").style.display = "none";
    document.getElementById("grdFallecimiento").style.display = "none";
    document.getElementById("grdRemanente").style.display = "none";
    //MetodosAjax.Eliminasession();



}


function valida_Edad105() {
    if (document.getElementById("HiddenRamoRequest").value == "105") {
        var Asegurados = AseguradosType();
        var numAsegurado = getNumAsegurado();
        var clm = document.getElementById("UscAsegCLM_lblEdad").innerHTML;
        var clmSexo = document.getElementById("UscAsegCLM_lblSexo").innerHTML;
        var BanderaEdad = false;
        var BanderaSexo = false;
        edadAsegurado = Asegurados[numAsegurado].split("|");
        if (clm == edadAsegurado[0]) {
            BanderaEdad = true;
        } else {
            alert("FECHA DE NACIMIENTO DISTINTA A LA COTIZACION");
            limpiaCLM("UscAsegCLM_");
            return false;
        }

        if (clmSexo == edadAsegurado[5]) {
            BanderaSexo = true;
        }else {
            alert("SEXO DISTINTO A LA COTIZACION");
            limpiaCLM("UscAsegCLM_");
            return false;
        }

        if (BanderaEdad == true && BanderaSexo == true) {
            return true;
        }
    } else {
        var edad_cotiza = document.getElementById("txtEdadParentesco").value;
        var clm = document.getElementById("UscAsegCLM_lblEdad").innerHTML;

        if (parseInt(edad_cotiza) != parseInt(clm)) {
            alert("FECHA DE NACIMIENTO DISTINTA A LA COTIZACION");
            limpiaCLM("UscAsegCLM_");
        }
    }
}
function valida_obtener_prima_105() {
    var divBenef105 = document.getElementById("trCob_benef_105");
    var tabBenef105 = divBenef105.getElementsByTagName('Table');
    var num_ase = document.getElementById("txtNoAseg").value;
    if (tabBenef105[0].rows.length - 1 == parseInt(num_ase)) {
        Cotiza_105();
    }
    else {
        alert("Debes capturar todos los asegurados");
    }
}
function validaNoAseg() {
    var num_ase = document.getElementById("txtNoAseg").value;
    if (parseInt(num_ase) > 5) {
        alert("El número de asegurados no puede ser mayor a 5");
        document.getElementById("txtNoAseg").value = "";
    }
    else {

    }
}

function selectTranspote() {
    if ($('#txtTipoTransporte').val() == "AEREO") {
        $('#divAeronaves').removeAttr('hidden');
    } else {
        $('#divAeronaves').attr('hidden', true);
    }
}

function selectLugarTrabajo() {
    if ($('#txtLugarTrabajo').val() == "OTRO") {
        $('#divOtro').removeAttr('hidden');
    } else {
        $('#divOtro').attr('hidden', true);
    }
}

function selectDeporte() {
    if ($('#txtDeporte').val() == "NINGUNO" || $('#txtDeporte').val() == "SELECCIONE") {
        $('#divCubrirRiesgo').attr('hidden', true);
    } else {
        $('#divCubrirRiesgo').removeAttr('hidden');
    }
}

function selectCopas() {
    if ($('#txtCantBebida').val() == "0" || $('#txtCantBebida').val() == "SELECCIONE") {
        $('#divFrecuencia').attr('hidden', true);
    } else {
        $('#divFrecuencia').removeAttr('hidden');
    }
}

function selectFuma() {
    if ($('#txtFuma').val() == "NINGUNO" || $('#txtFuma').val() == "SELECCIONE") {
        $('#divCantidadFumar').attr('hidden', true);
        $('#divFrecuenciaFumar').attr('hidden', true);
    } else {
        $('#divCantidadFumar').removeAttr('hidden');
        $('#divFrecuenciaFumar').removeAttr('hidden');
    }
}

function selectViveMadre() {
    if ($('#txtViveMadre').val() == "NO") {
        $('#txtEdadMuerteMadre').removeAttr('disabled');
        $('#txtMotivosMadre').removeAttr('disabled');
    } else {
        $('#txtEdadMuerteMadre').attr('disabled', true);
        $('#txtMotivosMadre').attr('disabled', true);
    }
}

function selectVivePadre() {
    if ($('#txtVivePadre').val() == "NO") {
        $('#txtEdadMuertePadre').removeAttr('disabled');
        $('#txtMotivosPadre').removeAttr('disabled');
    } else {
        $('#txtEdadMuertePadre').attr('disabled', true);
        $('#txtMotivosPadre').attr('disabled', true);
    }
}

function selectViveHermanos() {
    if ($('#txtViveHermanos').val() == "NO") {
        $('#txtEdadMuerteHermanos').removeAttr('disabled');
        $('#txtMotivosHermanos').removeAttr('disabled');
    } else {
        $('#txtEdadMuerteHermanos').attr('disabled', true);
        $('#txtMotivosHermanos').attr('disabled', true);
    }
}

function selectViveHijos() {
    if ($('#txtViveHijos').val() == "NO") {
        $('#txtEdadMuerteHijos').removeAttr('disabled');
        $('#txtMotivosHijos').removeAttr('disabled');
    } else {
        $('#txtEdadMuerteHijos').attr('disabled', true);
        $('#txtMotivosHijos').attr('disabled', true);
    }
}

function selectQuienCardiaca() {
    if ($('#txtQuienCardiaca').val() != "NINGUNO") {
        $('#txtEvolucionCardiaca').removeAttr('disabled');
    } else {
        $('#txtEvolucionCardiaca').attr('disabled', true);
    }
}

function selectQuienCancer() {
    if ($('#txtQuienCancer').val() != "NINGUNO") {
        $('#txtEvolucionCancer').removeAttr('disabled');
    } else {
        $('#txtEvolucionCancer').attr('disabled', true);
    }
}

function selectQuienPresion() {
    if ($('#txtQuienPresion').val() != "NINGUNO") {
        $('#txtEvolucionPresion').removeAttr('disabled');
    } else {
        $('#txtEvolucionPresion').attr('disabled', true);
    }
}

function selectQuienDiabetes() {
    if ($('#txtQuienDiabetes').val() != "NINGUNO") {
        $('#txtEvolucionDiabetes').removeAttr('disabled');
    } else {
        $('#txtEvolucionDiabetes').attr('disabled', true);
    }
}

function valNumero() {
    var pattern = new RegExp('^[A-Z]+$', 'i');
    if (!(pattern.test(document.getElementById('txtGiro').value))) {
        document.getElementById('txtGiro').value = "";
        alert("Campo Giro de la empresa no puede tener numeros");
    }
}
//C1<--- Fin ---->