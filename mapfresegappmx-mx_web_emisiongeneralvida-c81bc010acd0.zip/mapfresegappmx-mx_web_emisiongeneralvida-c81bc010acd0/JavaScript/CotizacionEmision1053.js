﻿//'******************************************************************************
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2010
//'Name of the file              : CotizacionEmision.js
//'Creation/Modification History :
//'Modification                  : jdgomezc  Indra SWLabs
//                               : jchuertas Indra SWLabs
//                               : emontoya  Indra SWLabs
//'C1                            : jdgomezc - 30-12-2012
//                                 Originalmente la prima minima valida se
//                                 calculaba a partir la prima neta + recargos
//                                 y derechos. Segun el proyecto A16742 este
//                                 calculo solo se hace a partir de la primaNeta
//'C2                            : jdgomezc - 30-12-2012
//                                 Se incluye la validación de la politica de
//                                 lavado de dinero
//'C3                            : jchuertas - 30-12-2012
//                                 Se captura el tipo de seguro seleccionado y
//                                 se agrega al arreglo de datos variables.
//'C4                            : jchuertas - 30-12-2012
//                                 Se agrega la validación de antecedentes OII para
//                                 saber si es debe generar poliza o solicitud.
//'C5                            : jchuertas - 30-12-2012
//                                 Se cambian los parametros que se envian al procedimiento
//                                 eliminando el campo mensaje ya que este se obtendrá de la BD
//'C6                            : jchuertas - 30-12-2012
//                                 Se agrega el metodo getNumContrato
//'C7                            : emontoya - 30-12-2012
//                                 se agrega la validación para saber si se realiza póliza o solicitud.
//'C8                            : emontoya - 30-12-2012
//                                 se agrega validación para habilitar el botón imprime solicitud.
//'C10                           : jdgomezc - 30-12-2012
//                                 Se envia por defecto una N en la variable endosoEdu
//'C11                           : jchuertas - 30-12-2012
//                                 Se habilita el botón Adjuntar cuando se realiza el cálculo de las primas.
//'C12                           : jchuertas - 30-12-2012
//'                                Envío de los nuevos parámetros de consulta al método MetodosAjax.validaPrimaMinima.
//'C13                           : jchuertas - 30-12-2012
//'                                Envío de los nuevos parámetros de consulta al método MetodosAjax.validaSumaBasica.
//'C14                           : jchuertas - 30-12-2012
//'                                Se modificó el método validarCumulos cambiando los parámetros de envío al método
//                                 MetodosAjax.validaCumulos
//'C15                           : jchuertas - 04-01-2013
//'                                Cuando se genera la solicitud de emisión se llama al metodo AgregarFolioDocumentum en
//                                 metodosAjax para que se actualice en documentum con el numero de folio ram.
//'C16                           : jdgomezc - 27-02-2012
//'                                Se habilita el botón de imprimir poliza siempre que haya una emisión
//'C17                           : jchuertas - 30-12-2012
//                               : Se agregaron los métodos obtenerTipoSeguros() y Seguros_CallBack
//'C18                           : jchuertas - 28-02-2013
//                                 Obtiene las coberturas seleccionadas para enviarlas al procedimiento que retorna
//                                 los tipos de seguro
//'C19                             jchuertas - 28-02-2013
//                                 Se hace el llamado para obtener los tipos de seguro
//'C20                             jchuertas - 01-03-2013
//                                 Se inicializa el tipo de seguro en patrimonial para que no salga la validación
//                                 de datos obligatorios a la hora de armar la cadena de datos variables.
//'C21                             emontoya - 04-03-2013
//                                 Se agrega el llamado de la función OcultarMostrarBeneficiario.
//'C22                             jhuertas - 01-10-2013
//                                 Se agrega el llamado de la función de validación de exámenes.
//'C23                             jhuertas - 01-11-2013
//                                 Se cambia el mensaje de error de la suma asegurada minima en dolares. 
//'C24                             jhuertas - 06-11-2013
//                                 Si no existen mensajes de exámenes configurados se muestra una alerta y no se realiza
//								   ni solicitud ni póliza.
//'C25                             jglopezh - 21-11-2013
//                                 Se agrega el mensaje de validación de suma asegurada.
//'C26                             Se manda la prima a un hidden para expediente cliente.                                                                                                                             ni solicitud ni póliza.
//'C27                             apl 09-12-2014
//                                 Modificación a 'C20. Se quita valor por default de Seguro Patromonial y se deja selección de acuerdo a RadioButton.
//'C28                             AEP Se agrega funcionalidad de requerimiento A27840 Segunda Fase Expediente Cliente 
//'C29                             Se agrega validaciones para el funcionamiento del cuestionario millon
//09052018
//								   Cuestionario Enfermedades respiratorias
//'*****************************************************************************

var MSI = "N"; //MGM_MSI
var modifica = "";
var numTotalCob = "";

//// Funcion de inicio
//function init() {
//    numTotalCob = document.all('hdnTotalCob').value;
//    initTablaAseg();
//    //autofitIframe('ctl00_ContentPlaceHolder1_frmPrincipal');
//    setSelFindByValue('drpRamo', document.all('hdnEducacional').value);
//    document.all('drpRamo').onchange();
//    document.all('drpRamo').disabled = true;
//    document.all('lblNOCoberturas').style.display = "none";
//    setSelFindByValue('drpParentesco1', 38);
//    cambioParentesco();
//    document.all('pnlCotizacion').style.display = "inline";
//    limpiaImportes();
//    cambioAgente();
//}

function Cotiza() {
    // <--- C19 --->
    obtenerTipoSeguros();

    //obtenerDocumentosAdjuntar();
    if (validaPagina("C"))
        armaCadena("C", "PRIMAS");
    // <--- C11 --->
    document.getElementById("btnAdjuntar").disabled = false;
    // <----------->        
}

//------->C17<-------
/// <summary>
///     Este método se encarga de obtener el codigo html generado con los tipos de seguro para beneficiarios
///     y agregarlos en el formulario de emision.
/// </summary>

function obtenerTipoSeguros() {
    document.getElementById("DivTipoSeguros").innerHTML = "";

    var Ramo = document.getElementById("HiddenRamoRequest").value;
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    var Modalidad = document.getElementById("HiddenModalidad").value;

    //----------------->C18<--------------------

    var coberturas = "";
    var coberturaRadio = document.getElementsByName("rbCobertura");
    var coberturaCheck = document.getElementsByName("chkCobertura");

    for (j = 0; j < coberturaRadio.length; j++) {
        if (coberturaRadio[j].checked == true) {
            coberturas = coberturaRadio[j].value;
        }
    }

    for (k = 0; k < coberturaCheck.length; k++) {
        if (coberturaCheck[k].checked == true) {
            if (coberturas == "") {
                coberturas = coberturaCheck[k].value;
            }
            else {
                coberturas = coberturas + "," + coberturaCheck[k].value;
            }
        }
    }
    //----------------------------------------

    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    MetodosAjax.getObtieneTipoSeguros(Ramo, contrato, Modalidad, coberturas, Seguros_CallBack);
    console.log(MetodosAjax.getObtieneTipoSeguros(Ramo, contrato, Modalidad, coberturas, Seguros_CallBack))
}

//------->C17<-------
/// <summary>
///     Este método se encarga de agregar el codigo html generado con los tipos de seguros en el formulario de emision.
/// </summary>

function Seguros_CallBack(res) {
    if (res.error == null) {
        if (res != null && res.value != null) {
            if (res.value != "") {

                document.getElementById("DivTipoSeguros").innerHTML = res.value;

                //<--- C21 --->
                //OcultarMostrarBeneficiario();
                //<----------->
                AjustarFrame();
            }
            else {
                alert("NO SE ENCONTRARON TIPOS DE SEGUROS CONFIGURADOS, DEBE CAMBIAR LOS PAR\u00c1METROS INGRESADOS PARA PODER EMITIR.");
            }

        }
    }
    else {
        alert("NO SE PUDO OBTENER LOS TIPOS DE SEGUROS, SI EL PROBLEMA PERSISTE COMUN\u00cdQUESE CON EL ADMINISTRADOR.");
    }
}

function Emite() {
    if (document.getElementById("btnInserta").style.display != "none") {
        alert("Debe ingresar antes a todos los asegurados");
        return;
    }
    var prima1 = document.querySelector("#lblPrimatotal").textContent.replace(/\$|\,|/g, '').replace("USD", "");
    MetodosAjax.setPRIMA(prima1);
    if (validaPagina("P")) {
        Cargando(true);
        var Modo = ValidarEmision();

        if (Modo != "E") {
            armaCadena(Modo, "SOLICITUD");
        }
        else {
            Cargando(false);
            return;
        }
    }
}

function CotizaBasePrima(visible) {
    document.getElementById("CotizaBasePrima").style.display = visible;
    document.getElementById("CotizaBasePrima2").style.display = visible;
    document.getElementById("CotizaBasePrima3").style.display = visible;
    document.getElementById("Table4").style.display = visible;
}

function validaPagina(oper) {
    var gridViewArch = document.getElementById("grdAdjuntarArchivo");
    // REGRESAR A FALSE EN CAUNTO SE ARREGLE DETALLE DE LOS ARCHIVOS
    if (gridViewArch == null && oper == "P") {
        alert("SE DEBE ADJUNTAR LA SOLICITUD FIRMADA POR EL CLIENTE, AS\u00cd COMO SU IDENTIFICACI\u00d3N OFICIAL.");
        return true;
    }

    if (document.getElementById("drpAgente").options.length > 1) {
        if (selIndiceCtrl("drpAgente") < 1) {
            alert("DEBES SELECCIONAR UN AGENTE");
            focusCtrl("drpAgente");
            return false;
        }
    }

    //if (document.getElementById("txtEdad").value == "") {
    //    alert("DEBES CAPTURAR LA EDAD");
    //    console.log("mensaje6")

    //    focusCtrl("txtEdad");
    //    return false;
    //}

    //if (document.getElementById("txtIngresoM").value == "") {
    //    alert("DEBES CAPTURAR INGRESO ANUAL");
    //    focusCtrl("txtIngresoM");
    //    return false;
    //}

    //Valida Edad Tope
    //if (parseInt(document.getElementById("txtEdad").value) < parseInt(document.getElementById("HiddenEdadTopeMin").value) || parseInt(document.getElementById("txtEdad").value) > parseInt(document.getElementById("HiddenEdadTopeMax").value)) {
    //    alert("EDAD DE ACEPTACI\u00d3N DE " + document.getElementById("HiddenEdadTopeMin").value + " A " + document.getElementById("HiddenEdadTopeMax").value);
    //    document.getElementById("txtEdad").value = "";
    //    focusCtrl("txtEdad");
    //    return false;
    //}

    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        if (selIndiceCtrl("drpPolizaGrupo") < 1) {
            alert("DEBES SELECCIONAR UNA P\u00d3LIZA GRUPO");
            focusCtrl("drpPolizaGrupo");
            return false;
        }
        if (selIndiceCtrl("drpContrato") < 1) {
            alert("DEBES SELECCIONAR UN CONTRATO");
            focusCtrl("drpContrato");
            return false;
        }
    }

    if (selIndiceCtrl("drpMoneda") < 1) {
        alert("DEBES SELECCIONAR UNA MONEDA");
        focusCtrl("drpMoneda");
        return false;
    }

    if (selIndiceCtrl("drpCrecimiento") < 1) {
        alert("DEBES SELECCIONAR EL CRECIMIENTO");
        focusCtrl("drpCrecimiento");
        return false;
    }

    if (document.getElementById("HiddenRamoRequest").value == "101") {
        if (selIndiceCtrl("drpDeducible") < 1) {
            alert("DEBES SELECCIONAR EL DEDUCIBLE.");
            focusCtrl("drpDeducible");
            return false;
        }
    }
    else {
        if (document.getElementById("HiddenDeducible").value == "-1" || document.getElementById("HiddenDeducible").value == "") {
            alert("EXISTE UN PROBLEMA Y NO PUDO SER OBTENIDO EL DEDUCIBLE CON EL CRECIMIENTO SELECCIONADO");
            return false;
        }
    }

    if (selIndiceCtrl("drpPlazo") < 1) {
        alert("DEBES SELECCIONAR EL PLAZO");
        focusCtrl("drpPlazo");
        return false;
    }

    if (selIndiceCtrl("drpPlazoPrima") < 1) {
        alert("DEBES SELECCIONAR EL PLAZO PRIMA");
        focusCtrl("drpPlazoPrima");
        return false;
    }

    if (selIndiceCtrl("drpComision") < 1) {
        alert("DEBES SELECCIONAR LA COMISI\u00d3N.");
        focusCtrl("drpComision");
        return false;
    }

    if (selIndiceCtrl("drpFormaPago") < 1) {
        alert("DEBES SELECCIONAR UNA FORMA DE PAGO");
        focusCtrl("drpFormaPago");
        return false;
    }

    if (selIndiceCtrl("drpTipoPago") < 1) {
        alert("DEBES SELECCIONAR UN TIPO DE PAGO.");
        focusCtrl("drpTipoPago");
        return false;
    }

    //if (document.getElementById("DivCoberturas").innerHTML == "") {
    //    alert("NO SE HAN DEFINIDO LAS COBERTURAS");
    // return false;    
    //}

    //if (ValidarUnaCobMarcada()) {
    //    alert("DEBES SELECCIONAR POR LO MENOS UNA COBERTURA");
    //    return false;     
    //}

    //var ctrlTxtSuma = ValidarVaciosEnSumasConCobMarcadas();
    //if (ctrlTxtSuma != "") {
    //    alert("DEBE CAPTURAR UNA SUMA PARA LA COBERTURA MARCADA.");
    //    focusCtrl(ctrlTxtSuma);
    //    return false;     
    //}

    var totPart = document.all("HidTotalPorcentaje").value;
    if (parseFloat(totPart) < 100) {
        alert("EL PORCENTAJE DE AGENTES DEBE SUMAR 100%.");
        return false;
    }

    if (oper == "P") {
        // ESTO NO APLICA PARA MULTIRIESGO
        //if (document.getElementById("divPrimas").innerHTML == "") {
        //   alert("DEBES DE OBTENER PRIMAS ANTES DE EMITIR");
        //   return false;
        //}

        // Valida captura de los beneficiarios
        var gridView = document.getElementById("grdBeneficiarios").firstChild.firstChild.nextElementSibling;
        if (gridView == null) {
            if (oper == "P") {
                alert("DEBES INGRESAR POR LO MENOS UN BENEFICIARIO");
                return false;
            }
        }
        else {
            // Valida la suma de porcentaje de los beneficiarios
            var tblBenef = MetodosAjax.obtieneTablaBenef();
            if (!validaPorcentaje(tblBenef, "beneficiarios"))
                return false;
        }
    }

    if (oper == "P") {
        

        if (document.getElementById("txtPeso").value == "") {
            if (!document.getElementById("rdoMenor").checked) {
                alert("DEBES CAPTURAR EL PESO");
                focusCtrl("txtPeso");
                return false;
            }
            
        }

        if (document.getElementById("txtEstatura").value == "") {
            if (!document.getElementById("rdoMenor").checked) {
                alert("DEBES CAPTURAR LA ESTATURA");
                focusCtrl("txtEstatura");
                return false;
            }
        }

        if (document.getElementById("chkboxNo").checked == false && document.getElementById("chkboxSi").checked == false) {
            if (!document.getElementById("rdoMenor").checked) {
                alert("DEBES CONTESTAR LA PREGUNTA DEL DEPORTE Y/O AFICI\u00d3N PELIGROSA");
                return false;
            }
        }

        var adicionales = false;
        for (var i = 2; i < 12; i++) {
            if (document.getElementById('chk' + i) != null) {
                if (document.getElementById('chk' + i).checked) {
                    adicionales = true;
                    break;
                }
            }
        }

        if ($('#HiddenRamoRequest').val() == '101' && adicionales) {
            if (!validaCuest()) {
                alert("DEBES CONTESTAR TODO EL CUESTIONARIO");
                return false;
            }

            if (!validaCuestResp()) {
                alert("DEBES CONTESTAR TODO EL CUESTIONARIO");
                return false;
            }
        }
        if ($('#HiddenRamoRequest').val() != '101') {
            if (!validaCuest()) {
                alert("DEBES CONTESTAR TODO EL CUESTIONARIO");
                return false;
            }

            if (!validaCuestResp()) {
                alert("DEBES CONTESTAR TODO EL CUESTIONARIO");
                return false;
            }
        }

        // NO SE TIENE CONSIDERADA ESTA COBERTURA DENTRO DE TODOS LOS TIPOS DE ASEGURADOS
        //if (ValidaServFune()) {
        //    return false;
        //}

        if (document.getElementById("divCuestionario").innerHTML != "") {
            if (ValidarCuestionarioEnfRespiratorias()) {
                alert('DEBES CONTESTAR TODO EL CUESTIONARIO');
                return false;
            }
        }

        if (document.getElementById("divCuestionarioMillon").innerHTML != "") {
            if (ValidarCuestionarioMillon()) {
                return false;
            }
        }
    }



    return true;
}

function ValidarCuestionarioEnfRespiratorias() {

    if (document.getElementById("HiddenRamoRequest").value == "105") {
        if (document.getElementById("rdoMenor").checked) {
            return false;
        }
    }

    if ($('#HiddenRamoRequest').val() == '101') {
        if ($('#txtPeso').val() == '') {
            alert('DEBES AGREGAR PESO');
            focusCtrl("txtPeso");
            return true;
        }

        if ($('#txtEstatura').val() == '') {
            alert('DEBES AGREGAR ESTATURA');
            focusCtrl("txtEstatura");
            return true;
        }
    }

    if (!document.getElementById("chkSi14").checked) {
        if (!document.getElementById("chkNo14").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi14");
            return true;
        }
    } else {
        if ($('#txt14').val() == '') {
            alert('DEBES ESCRIBIR ENFERMEDAD RESPIRATORIA');
            focusCtrl("txt14");
            return true;
        }
    }

    if (!document.getElementById("chkSi15").checked) {
        if (!document.getElementById("chkNo15").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi15");
            return true;
        }
    } else {
        if ($('#txt15').val() == '') {
            alert('DEBES ESCRIBIR ENFERMEDAD RESPIRATORIA');
            focusCtrl("txt15");
            return true;
        }
    }

    if (!document.getElementById("chkSi16").checked) {
        if (!document.getElementById("chkNo16").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi16");
            return true;
        }
    } else {
        if (!document.getElementById("chk16a").checked) {
            if (!document.getElementById("chk16b").checked) {
                if (!document.getElementById("chk16c").checked) {
                    if (!document.getElementById("chk16d").checked) {
                        if (!document.getElementById("chk16e").checked) {
                            if (!document.getElementById("chk16f").checked) {
                                if (!document.getElementById("chk16g").checked) {
                                    if (!document.getElementById("chk16h").checked) {
                                        alert('DEBES SELECCIONAR ALGUN SINTOMA');
                                        focusCtrl("chk16a");
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (!document.getElementById("chkSi17").checked) {
        if (!document.getElementById("chkNo17").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi17");
            return true;
        }
    } else {
        if ($('#txt17a').val() == 'Seleccione') {
            alert('DEBES SELECCIONAR EL TIPO DE PRUEBA');
            focusCtrl("txt17a");
            return true;
        } else {
            if ($('#txt17b').val() == '') {
                alert('DEBES SELECCIONAR LA FECHA DE LA PRUEBA');
                focusCtrl("txt17b");
                return true;
            }
        }
    }

    if (!document.getElementById("chkSi18").checked) {
        if (!document.getElementById("chkNo18").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi18");
            return true;
        }
    } else {
        if ($('#txt18a').val() == '') {
            alert('DEBES SELECCIONAR LA FECHA');
            focusCtrl("txt18a");
            return true;
        } else {
            if ($('#txt18b').val() == 'SELECCIONE') {
                alert('DEBES SELECCIONAR TIPO DE ATENCIÓN');
                focusCtrl("txt18b");
                return true;
            } else {
                if ($('#txt18c').val() == '') {
                    alert('DEBES AGREGAR EL TRATAMIENTO');
                    focusCtrl("txt18c");
                    return true;
                }
            }
        }
    }

    if (!document.getElementById("chkSi19").checked) {
        if (!document.getElementById("chkNo19").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi19");
            return true;
        }
    } else {
        if ($('#txt19a').val() == 'Seleccione') {
            alert('DEBES SELECCIONAR EL TIPO DE PRUEBA');
            focusCtrl("txt19a");
            return true;
        } else {
            if ($('#txt19b').val() == '') {
                alert('DEBES SELECCIONAR LA FECHA DE LA PRUEBA');
                focusCtrl("txt19b");
                return true;
            }
        }
    }

    if (!document.getElementById("chkSi20").checked) {
        if (!document.getElementById("chkNo20").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi20");
            return true;
        }
    } else {
        if ($('#txt20a').val() == '') {
            alert('DEBES ESCRIBIR EL TIPO DE SECUELA');
            focusCtrl("txt20a");
            return true;
        } else {
            if ($('#txt20b').val() == '') {
                alert('DEBES ESCRIBIR TRATAMIENTO MEDICO');
                focusCtrl("txt20b");
                return true;
            } else {
                if ($('#txt20c').val() == '') {
                    alert('DEBES ESCRIBIR ESTADO ACTUAL');
                    focusCtrl("txt20c");
                    return true;
                }
            }
        }
    }

    if (!document.getElementById("chkSi21").checked) {
        if (!document.getElementById("chkNo21").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi21");
            return true;
        }
    } else {
        if ($('#txt21').val() == '') {
            alert('DEBES SELECCIONAR LA FECHA QUE ESTUVISTE EN CUARENTENA');
            focusCtrl("txt21");
            return true;
        }
    }

    if ($('#txtQuienCardiaca').val() == 'MADRE' || $('#txtQuienCardiaca').val() == 'PADRE') {
        if ($('#txtEvolucionCardiaca').val() == '') {
            alert('DEBES AGREGAR EVOLUCION');
            focusCtrl("txtEvolucionCardiaca");
            return true;
        }
    }
    if ($('#txtQuienCancer').val() == 'MADRE' || $('#txtQuienCancer').val() == 'PADRE') {
        if ($('#txtEvolucionCancer').val() == '') {
            alert('DEBES AGREGAR EVOLUCION');
            focusCtrl("txtEvolucionCancer");
            return true;
        }
    }
    if ($('#txtQuienPresion').val() == 'MADRE' || $('#txtQuienPresion').val() == 'PADRE') {
        if ($('#txtEvolucionPresion').val() == '') {
            alert('DEBES AGREGAR EVOLUCION');
            focusCtrl("txtEvolucionPresion");
            return true;
        }
    }
    if ($('#txtQuienDiabetes').val() == 'MADRE' || $('#txtQuienDiabetes').val() == 'PADRE') {
        if ($('#txtEvolucionDiabetes').val() == '') {
            alert('DEBES AGREGAR EVOLUCION');
            focusCtrl("txtEvolucionDiabetes");
            return true;
        }
    }


    if (!document.getElementById("chkSi22").checked) {
        if (!document.getElementById("chkNo22").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi22");
            return true;
        }
    } else {
        if ($('#txt22a').val() == '') {
            alert('DEBES SELECCI0NAR LA FECHA QUE VIAJO');
            focusCtrl("txt22a");
            return true;
        } else {
            if ($('#txt22b').val() == 'SELECCIONE') {
                alert('DEBES SELECCI0NAR MEDIO DE TRANSPORTE');
                focusCtrl("txt22b");
                return true;
            } else {
                if ($('#txt22c').val() == 'SELECCIONE') {
                    alert('DEBES SELECCIONAR DESTINO');
                    focusCtrl("txt22c");
                    return true;
                }
            }
        }
    }

    if (!document.getElementById("chkSi23").checked) {
        if (!document.getElementById("chkNo23").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi23");
            return true;
        }
    } else {
        if ($('#txt23a').val() == '') {
            alert('DEBES SELECCIONAR LA FECHA DE INICIO DE TU VIAJE');
            focusCtrl("txt23a");
            return true;
        } else {
            if ($('#txt23b').val() == '') {
                alert('DEBES SELECCIONAR LA FECHA DE TERMINO DE TU VIAJE');
                focusCtrl("txt23b");
                return true;
            } else {
                if ($('#txt23c').val() == 'SELECCIONE') {
                    alert('DEBES SELECCIONAR DESTINO');
                    focusCtrl("txt23c");
                    return true;
                } else {
                    if ($('#txt23d').val() == 'SELECCIONE') {
                        alert('DEBES SELECCIONAR MEDIO DE TRANSPORTE');
                        focusCtrl("txt23d");
                        return true;
                    }
                }
            }
        }
    }

    if (!document.getElementById("chkSi24").checked) {
        if (!document.getElementById("chkNo24").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi24");
            return true;
        }
    } else {
        if ($('#txt24a').val() == '') {
            alert('DEBES ESCRIBIR LAS FECHAS');
            focusCtrl("txt24a");
            return true;
        } else {
            if ($('#txt24b').val() == '') {
                alert('DEBES ESCRIBIR LOS LUGARES');
                focusCtrl("txt24b");
                return true;
            }
        }
    }

    if (!document.getElementById("chkSi25").checked) {
        if (!document.getElementById("chkNo25").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi25");
            return true;
        }
    } else {
        if ($('#txt25a').val() == '') {

            alert('DEBES SELECCIONAR LA FECHA DE PRIMERA DOSIS');
            focusCtrl("txt25a");
            return true;
        } else {
            if ($('#txt25b').val() == '') {

                alert('DEBES SELECCIONAR LA FECHA DE LA SEGUNDA DOSIS');
                focusCtrl("txt25b");
                return true;
            } else {
                if ($('#txt25c').val() == '') {

                    alert('DEBES ESCRIBIR TIPO DE VACUNA APLICADA');
                    focusCtrl("txt25c");
                    return true;
                }
            }
        }
    }

    if (!document.getElementById("chkSi26").checked) {
        if (!document.getElementById("chkNo26").checked) {

            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi26");
            return true;
        }
    }

}


function ValidarCuestionarioMillon() {
    if (document.getElementById("chkSiOtraOcupacion").checked) {
        if ($('#txtOtraOcupacion').val() == '0') {
            alert('DEBES SELECCIONAR EN QUE CONSISTE TU OTRA OCUPACION');
            focusCtrl("txtOtraOcupacion");
            return true;
        }
    }

    if (document.getElementById("chkSiViajar").checked) {
        if ($('#txtTipoTransporte').val() == 'SELECCIONE') {
            alert('DEBES SELECCIONAR TIPO DE TRANSPORTE');
            focusCtrl("txtTipoTransporte");
            return true;
        }
    }

    if ($('#txtTipoTransporte').val() == 'AEREO') {
        if (document.getElementById("chkSiAParticular").checked) {
            if ($('#txtTipoAeronave').val() == '') {
                alert('DEBES AGREGAR TIPO DE AERONAVE Y HORAS DE VUELO');
                focusCtrl("txtTipoAeronave");
                return true;
            }
        }
    }

    if (document.getElementById("chkSiMotocicleta").checked) {
        if ($('#txtFMotocicleta').val() == '') {
            alert('DEBES AGREGAR LA FRECUENCIA Y PARA QUE USAS LA MOTOCICLETA');
            focusCtrl("txtFMotocicleta");
            return true;
        }
    }

    if (document.getElementById("chkSiAlturas").checked) {
        if ($('#txtAlturas').val() == '') {
            alert('DEBES AGREGAR PROMEDIO EN METROS');
            focusCtrl("txtAlturas");
            return true;
        }
    }

    if ($('#txtLugarTrabajo').val() == 'OTRO') {
        if ($('#txtOtroLugarTrabajo').val() == '') {
            alert('DEBES AGREGAR EL OTRO LUGAR DE TRABAJO');
            focusCtrl("txtOtroLugarTrabajo");
            return true;
        }
    }

    if ($('#txtCantBebida').val() != '0') {
        if ($('#txtFrecuenciaBebida').val() == 'SELECCIONE') {
            alert('DEBES SELECCIONAR LA FRECUENCIA');
            focusCtrl("txtFrecuenciaBebida");
            return true;
        }
    }

    if ($('#drpFuma').val() == '1') {
        if ($('#txtFuma').val() == 'SELECCIONE') {
            alert('DEBES SELECCIONAR QUE TIPO ES LO QUE FUMAS');
            focusCtrl("txtFuma");
            return true;
        }
    }

    if ($('#drpFuma').val() == '1') {
        if ($('#txtFuma').val() != 'SELECCIONE') {
            if ($('#txtFuma').val() == 'NINGUNO') {
                alert('DEBES SELECCIONAR OTRA APARTE DE NINGUNO EN FUMADOR');
                focusCtrl("txtFuma");
                return true;
            }
        }
    }

    if ($('#drpFuma').val() == '1') {
        if ($('#txtFuma').val() != 'SELECCIONE') {
            if ($('#txtFuma').val() != 'NINGUNO') {
                if ($('#txtCantidadFumar').val() == 'SELECCIONE') {
                    alert('DEBES SELECCIONAR LA CANTIDAD QUE FUMA');
                    focusCtrl("txtCantidadFumar");
                    return true;
                }
            }
        }
    }

    if ($('#drpFuma').val() == '1') {
        if ($('#txtFuma').val() != 'SELECCIONE') {
            if ($('#txtFuma').val() != 'NINGUNO') {
                if ($('#txtCantidadFumar').val() == '0') {
                    alert('DEBES SELECCIONAR LA CANTIDAD QUE FUMA');
                    focusCtrl("txtCantidadFumar");
                    return true;
                }
            }
        }
    }

    if ($('#drpFuma').val() == '1') {
        if ($('#txtFuma').val() != 'SELECCIONE') {
            if ($('#txtFuma').val() != 'NINGUNO') {
                if ($('#txtCantidadFumar').val() != '0') {
                    if ($('#txtCantidadFumar').val() != 'SELECCIONE') {
                        if ($('#txtFrecuenciaFumar').val() == 'SELECCIONE') {
                            alert('DEBES SELECCIONAR LA FRECUENCIA QUE FUMA');
                            focusCtrl("txtFrecuenciaFumar");
                            return true;
                        }
                    }
                }
            }
        }
    }

    if (document.getElementById("chkSiDroga").checked) {
        if ($('#txtTipoFrecuenciaDroga').val() == '') {
            alert('DEBES AGREGAR FRECUENCIA DE CONSUMO DE DROGA');
            focusCtrl("txtTipoFrecuenciaDroga");
            return true;
        }
    }

    if ($('#txtViveMadre').val() == 'NO') {
        if ($('#txtEdadMuerteMadre').val() == '' || $('#txtMotivosMadre').val() == '') {
            alert('DEBES AGREGAR EDAD DE MUERTE Y MOTIVOS');
            focusCtrl("txtEdadMuerteMadre");
            return true;
        }
    }

    if ($('#txtVivePadre').val() == 'NO') {
        if ($('#txtEdadMuertePadre').val() == '' || $('#txtMotivosPadre').val() == '') {
            alert('DEBES AGREGAR EDAD DE MUERTE Y MOTIVOS');
            focusCtrl("txtEdadMuertePadre");
            return true;
        }
    }

    if ($('#txtViveHermanos').val() == 'NO') {
        if ($('#txtEdadMuerteHermanos').val() == '' || $('#txtMotivosHermanos').val() == '') {
            alert('DEBES AGREGAR EDAD DE MUERTE Y MOTIVOS');
            focusCtrl("txtEdadMuerteHermanos");
            return true;
        }
    }

    if ($('#txtViveHijos').val() == 'NO') {
        if ($('#txtEdadMuerteHijos').val() == '' || $('#txtMotivosHijos').val() == '') {
            alert('DEBES AGREGAR EDAD DE MUERTE Y MOTIVOS');
            focusCtrl("txtEdadMuerteHijos");
            return true;
        }
    }

    if ($('#txtQuienCardiaca').val() == 'MADRE' || $('#txtQuienCardiaca').val() == 'PADRE') {
        if ($('#txtEvolucionCardiaca').val() == '') {
            alert('DEBES AGREGAR EVOLUCION');
            focusCtrl("txtEvolucionCardiaca");
            return true;
        }
    }
    if ($('#txtQuienCancer').val() == 'MADRE' || $('#txtQuienCancer').val() == 'PADRE') {
        if ($('#txtEvolucionCancer').val() == '') {
            alert('DEBES AGREGAR EVOLUCION');
            focusCtrl("txtEvolucionCancer");
            return true;
        }
    }
    if ($('#txtQuienPresion').val() == 'MADRE' || $('#txtQuienPresion').val() == 'PADRE') {
        if ($('#txtEvolucionPresion').val() == '') {
            alert('DEBES AGREGAR EVOLUCION');
            focusCtrl("txtEvolucionPresion");
            return true;
        }
    }
    if ($('#txtQuienDiabetes').val() == 'MADRE' || $('#txtQuienDiabetes').val() == 'PADRE') {
        if ($('#txtEvolucionDiabetes').val() == '') {
            alert('DEBES AGREGAR EVOLUCION');
            focusCtrl("txtEvolucionDiabetes");
            return true;
        }
    }


    if (document.getElementById("chk1Si").checked) {
        if ($('#txt1Causa').val() == '') {
            alert('DEBES AGREGAR LA CAUSA');
            focusCtrl("txt1Causa");
            return true;
        }
    }

    if (document.getElementById("chk2Si").checked) {
        if ($('#txt2Causa').val() == '' || $('#txt2Cuando').val() == '') {
            alert('DEBES AGREGAR LA CAUSA Y CUANDO');
            focusCtrl("txt2Causa");
            return true;
        }
    }

    if (document.getElementById("chk3Si").checked) {
        if ($('#txt3Causa').val() == '' || $('#txt3Cuando').val() == '') {
            alert('DEBES AGREGAR LA CAUSA Y CUANDO');
            focusCtrl("txt3Causa");
            return true;
        }
    }

    if (document.getElementById("chk4Si").checked) {
        if ($('#txt4Causa').val() == '' || $('#txt4Cuando').val() == '') {
            alert('DEBES AGREGAR LA CAUSA Y CUANDO');
            focusCtrl("txt4Causa");
            return true;
        }
    }

    if (document.getElementById("chk5Si").checked) {
        if ($('#txtKgAumentados').val() == '' || $('#txtKgDisminuidos').val() == '') {
            alert('DEBES AGREGAR KILOS AUMENTADOS Y DISMINUIDOS');
            focusCtrl("txtKgAumentados");
            return true;
        }
    }

    if (document.getElementById("chk7Si").checked) {
        if ($('#txt7Causa').val() == '') {
            alert('DEBES AGREGAR CAUSA');
            focusCtrl("txt7Causa");
            return true;
        }
    }

    if (document.getElementById("chk8Si").checked) {
        if ($('#txt8Meses').val() == '') {
            alert('DEBES AGREGAR MESES');
            focusCtrl("txt8Meses");
            return true;
        }
    }

    if ($('#txtTiempoConocer').val() == '') {
        alert('DEBES AGREGAR TIEMPO DE CONOCER AL SOLICITANTE');
        focusCtrl("txtTiempoConocer");
        return true;
    }

    if ($('#txtCapitalEstimado').val() == '') {
        alert('DEBES AGREGAR CAPITAL ESTIMADO');
        focusCtrl("txtCapitalEstimado");
        return true;
    }

    if ($('#txtRiesgoPeligroso').val() == '') {
        alert('DEBES AGREGAR ALGUN RIESGO DENTRO DE SU OCUPACION');
        focusCtrl("txtRiesgoPeligroso");
        return true;
    }

    if ($('#txtSaludRiesgo').val() == '') {
        alert('DEBES AGREGAR SI CONOCES ALGO SU SALUD O HABITOS');
        focusCtrl("txtSaludRiesgo");
        return true;
    }

    if ($('#txtIngresos').val() == '') {
        alert('DEBES AGREGAR EN CUANTO ESTIMAS SUS INGRESOS');
        focusCtrl("txtIngresos");
        return true;
    }
}

function validaPaginaFirma(oper) {
    //Validacion si ya se firmó la emision
    var valFirma = MetodosAjax.getValSession("BanderaEmision");
    if (valFirma.value == "1") {
        alert("ESTA SOLICITUD YA FUE ENVIADA A FIRMA");
        return false;
    }

    if (document.getElementById("drpAgente").options.length > 1) {
        if (selIndiceCtrl("drpAgente") < 1) {
            alert("DEBES SELECCIONAR UN AGENTE");
            focusCtrl("drpAgente");
            return false;
        }
    }

    //if (document.getElementById("txtEdad").value == "") {
    //    alert("DEBES CAPTURAR LA EDAD");
    //    focusCtrl("txtEdad");
    //    return false;
    //}

    //Valida Edad Tope
    //if (parseInt(document.getElementById("txtEdad").value) < parseInt(document.getElementById("HiddenEdadTopeMin").value) || parseInt(document.getElementById("txtEdad").value) > parseInt(document.getElementById("HiddenEdadTopeMax").value)) {
    //    if (selIndex("drpParentesco1") != 4 || selIndex("drpParentesco1") != 37) {
    //        alert("EDAD DE ACEPTACI\u00d3N DE " + document.getElementById("HiddenEdadTopeMin").value + " A " + document.getElementById("HiddenEdadTopeMax").value);
    //        document.getElementById("txtEdad").value = "";
    //        focusCtrl("txtEdad");
    //        return false;
    //    }
    //}

    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        if (selIndiceCtrl("drpPolizaGrupo") < 1) {
            alert("DEBES SELECCIONAR UNA P\u00d3LIZA GRUPO");
            focusCtrl("drpPolizaGrupo");
            return false;
        }
        if (selIndiceCtrl("drpContrato") < 1) {
            alert("DEBES SELECCIONAR UN CONTRATO");
            focusCtrl("drpContrato");
            return false;
        }
    }

    if (selIndiceCtrl("drpMoneda") < 1) {
        alert("DEBES SELECCIONAR UNA MONEDA");
        focusCtrl("drpMoneda");
        return false;
    }

    if (selIndiceCtrl("drpCrecimiento") < 1) {
        alert("DEBES SELECCIONAR EL CRECIMIENTO");
        focusCtrl("drpCrecimiento");
        return false;
    }

    if (document.getElementById("HiddenRamoRequest").value == "101") {
        if (selIndiceCtrl("drpDeducible") < 1) {
            alert("DEBES SELECCIONAR EL DEDUCIBLE.");
            focusCtrl("drpDeducible");
            return false;
        }
    }
    else {
        if (document.getElementById("HiddenDeducible").value == "-1" || document.getElementById("HiddenDeducible").value == "") {
            alert("EXISTE UN PROBLEMA Y NO PUDO SER OBTENIDO EL DEDUCIBLE CON EL CRECIMIENTO SELECCIONADO");
            return false;
        }
    }

    if (selIndiceCtrl("drpPlazo") < 1) {
        alert("DEBES SELECCIONAR EL PLAZO");
        focusCtrl("drpPlazo");
        return false;
    }

    if (selIndiceCtrl("drpComision") < 1) {
        alert("DEBES SELECCIONAR LA COMISI\u00d3N.");
        focusCtrl("drpComision");
        return false;
    }

    if (selIndiceCtrl("drpFormaPago") < 1) {
        alert("DEBES SELECCIONAR UNA FORMA DE PAGO");
        focusCtrl("drpFormaPago");
        return false;
    }

    if (selIndiceCtrl("drpTipoPago") < 1) {
        alert("DEBES SELECCIONAR UN TIPO DE PAGO.");
        focusCtrl("drpTipoPago");
        return false;
    }

    //if (document.getElementById("DivCoberturas").innerHTML == "") {
    //    alert("NO SE HAN DEFINIDO LAS COBERTURAS");
    //    return false;
    //}

    //if (ValidarUnaCobMarcada()) {
    //    alert("DEBES SELECCIONAR POR LO MENOS UNA COBERTURA");
    //    return false;
    //}

    //var ctrlTxtSuma = ValidarVaciosEnSumasConCobMarcadas();
    //if (ctrlTxtSuma != "") {
    //    alert("DEBE CAPTURAR UNA SUMA PARA LA COBERTURA MARCADA.");
    //    focusCtrl(ctrlTxtSuma);
    //    return false;
    //}

    var totPart = document.all("HidTotalPorcentaje").value;
    if (parseFloat(totPart) < 100) {
        alert("EL PORCENTAJE DE AGENTES DEBE SUMAR 100%.");
        return false;
    }

    if (oper == "P") {

        //if (document.getElementById("divPrimas").innerHTML == "") {
        //    alert("DEBES DE OBTENER PRIMAS ANTES DE EMITIR");
        //    return false;
        //}

        // Valida captura de los beneficiarios
        var gridView = document.getElementById("grdBeneficiarios").firstChild;
        if (gridView == null) {
            if (oper == "P") {
                alert("DEBES INGRESAR POR LO MENOS UN BENEFICIARIO");
                return false;
            }
        }
        else {
            // Valida la suma de porcentaje de los beneficiarios
            var tblBenef = MetodosAjax.obtieneTablaBenef();
            if (!validaPorcentaje(tblBenef, "beneficiarios"))
                return false;
        }
    }

    if (oper == "P") {
        if (document.getElementById("txtPeso").value == "") {
            if (!document.getElementById("rdoMenor").checked) {
                alert("DEBES CAPTURAR EL PESO");
                focusCtrl("txtPeso");
                return false;
            }
        }

        if (document.getElementById("txtEstatura").value == "") {
            if (!document.getElementById("rdoMenor").checked) {
                alert("DEBES CAPTURAR LA ESTATURA");
                focusCtrl("txtEstatura");
                return false;
            }
        }

        if (document.getElementById("chkboxNo").checked == false && document.getElementById("chkboxSi").checked == false) {
            alert("DEBES CONTESTAR LA PREGUNTA DEL DEPORTE Y/O AFICI\u00d3N PELIGROSA");
            return false;
        }

        if (!validaCuest()) {
            alert("DEBES CONTESTAR TODO EL CUESTIONARIO");
            return false;
        }

        if (!validaCuestResp()) {
            alert("DEBES CONTESTAR TODO EL CUESTIONARIO");
            return false;
        }
        if (ValidaServFune()) {
            return false;
        }
    }

    return true;
}

function ValidarUnaCobMarcada() {
    var bdrValidacion = false;

    var ContadorChecados = 0;
    var tbCoberturas = document.getElementById("Coberturas");
    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            if (document.getElementById("chk" + i).checked) {
                ContadorChecados = ContadorChecados + 1;
            }
        }
    }
    if (ContadorChecados == 0) {
        bdrValidacion = true;
    }
    return bdrValidacion;
}

function ValidarVaciosEnSumasConCobMarcadas() {
    var CtrltxtSuma = "";
    var tbCoberturas = document.getElementById("Coberturas1");
    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            if (document.getElementById("chk" + i).checked) {
                var CodCob = document.getElementById("chk" + i).value;
                if (document.getElementById("txtSuma" + CodCob).value == "") {
                    CtrltxtSuma = "txtSuma" + CodCob;
                    return CtrltxtSuma;
                }
            }
        }
    }

    return CtrltxtSuma;
}

function IngresoAnualAndOcupacion() {
    var parentesco = selIndex("drpParentesco1");

    if (parentesco != 38) {
        document.getElementById("divIngresoAnual").style.display = "block";
        document.getElementById("divFuma").style.display = "block";
        document.getElementById("ocupacion").style.display = "block";
    } else {
        document.getElementById("divIngresoAnual").style.display = "none";
        document.getElementById("divFuma").style.display = "none";
        document.getElementById("ocupacion").style.display = "none";
    }
}

function cotizar() {
    if (validaCotizacion()) {
        Cargando(true);

        var agente = selValorCtrl("drpAgente");
        var plazo = selValorCtrl("drpPlazo");
        var ramo = document.getElementById("HiddenRamoRequest").value;
        var tip_regulariza = selValorCtrl("drpCrecimiento", 0);
        var pct_regulariza = selValorCtrl("drpCrecimiento", 1);
        var modalidad = document.getElementById("HiddenModalidad").value;
        var tip_comision = selValorCtrl("drpComision");
        var tip_deducible = "";
        if (document.getElementById("HiddenRamoRequest").value == "101")
            tip_deducible = selIndex("drpDeducible");
        else
            tip_deducible = document.getElementById("HiddenDeducible").value;
        var polizaGrupo = "";
        var contrato = "";
        if (document.getElementById("rbtnListPolizaContrato_1").checked) {
            polizaGrupo = textoCtrl("drpPolizaGrupo");
            contrato = selValorCtrl("drpContrato");
        }
        //if ((contrato2 != null && contrato2.value != null)) {
        //    contrato = contrato2;
        //}
        //var monto_prima_min = selIndex("drpNombrePlan", 6);
        //var crecimiento = selIndex("drpIncremento", 0);
        var moneda = document.all("drpMoneda").value;
        if (moneda == 2) {
            var moneda_nom = " USD";
        }
        else {
            var moneda_nom = " UDIS";
        }
        var tasaInv = document.all("drpTasaInversion").value;
        var cuadroCom = document.getElementById('HidCuadroCom').value;

        var fechaActual = valorCtrl("txtFechaEfecto");

        var fecEfectoMas1Anio = MetodosAjax.sumarUnAnioAFecha(fechaActual);
        var fecVcto = fecEfectoMas1Anio.value;
        var arrFechaActual = new Array();
        arrFechaActual = fechaActual.split('/');
        var riesgo = new Array();
        riesgo = validaRiesgo();
        var riesgos = (riesgo.length - 1);
        if (riesgo[riesgo.length - 1] == riesgo[riesgo.length - 2])
            riesgos = riesgos - 1;
        var cadena = "";
        var formaPago = selValorCtrl("drpFormaPago");
        var CLM_Cont = "PRUEBA";
        var tip_docum = "CLM";
        var tipoPago = "AG";

        var CoberturaBasica = 0;

        var envio = 1;

        var arrDatosPoliza = new Array();
        arrDatosPoliza[0] = "COD_RAMO=" + ramo;
        arrDatosPoliza[1] = "NUM_RIESGOS=" + riesgos;
        arrDatosPoliza[2] = "COD_AGT=" + agente;
        arrDatosPoliza[3] = "COD_MON=" + moneda;
        arrDatosPoliza[4] = "COD_CUADRO_COM=" + cuadroCom;
        arrDatosPoliza[5] = "COD_GESTOR=" + agente;
        arrDatosPoliza[6] = "TIP_REGULARIZA=" + tip_regulariza;
        if (contrato == '19040') {
            arrDatosPoliza[7] = "NUM_CONTRATO=" + contrato;
            arrDatosPoliza[8] = "NUM_POLIZA_GRUPO=1VIDAMAS";
        }
        arrDatosPoliza.push("FEC_EFEC_POLIZA=" + fechaActual);
        arrDatosPoliza.push("FEC_VCTO_POLIZA=" + fecVcto);
        arrDatosPoliza.push("FEC_EFEC_SPTO=" + fechaActual);
        arrDatosPoliza.push("FEC_VCTO_SPTO=" + fecVcto);
        arrDatosPoliza.push("TIP_DURACION=1");
        arrDatosPoliza.push("ANIOS_MAX_DURACION=" + plazo);
        arrDatosPoliza.push("COD_ENVIO=" + envio);
        arrDatosPoliza.push("COD_FRACC_PAGO=" + formaPago);
        arrDatosPoliza.push("COD_DOCUM=" + CLM_Cont);
        arrDatosPoliza.push("TIP_DOCUM=" + tip_docum);
        arrDatosPoliza.push("TIP_GESTOR=" + tipoPago);
        arrDatosPoliza.push("MCA_IMPRESION=N");
        var indAgt = 2;
        for (i = 2; i <= 5; i++) {
            var index = ((parseInt(i) < 10) ? "0" + i : i);
            if (document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave").value != "") {
                var codAgt = document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave").value
                var pctAgt = document.getElementById("dtgReferencias_ctl" + index + "_txtgrdPorcentaje").value
                if (i == 2)
                    arrDatosPoliza.push("PCT_AGT=" + pctAgt);
                else {
                    arrDatosPoliza.push("COD_AGT" + indAgt + "=" + codAgt);
                    arrDatosPoliza.push("PCT_AGT" + indAgt + "=" + pctAgt);
                    indAgt++;
                }
            }
        }
        //arrDatosPoliza.push("COD_MODALIDAD=" + modalidad);


        var arrDatosAsegurado = new Array();
        var arrDatosBeneficiarios = new Array();
        var arrDatosCoberturas = new Array();
        var arrDatosFunerarios = new Array();
        var arrDatosMancomunado = new Array();
        var arrDatosImpresion = new Array();

        var numAsegurados = document.getElementById('DropDownList1').value;
        for (var j = 1; j <= numAsegurados; j++) {
            cadena = "";
            cadena = "parentesco=" + document.getElementById('lblParentesco' + j).innerHTML;
            cadena += "|" + "nombre=" + document.getElementById('lblNombre' + j).innerHTML;
            cadena += "|" + "edad=" + document.getElementById('lblEdad' + j).innerHTML;
            cadena += "|" + "sexo=" + "F";
            //cadena += "|"  + "sexo="		+ document.getElementById('lblSexo'+j).innerHTML;	            
            cadena += "|" + "suma=" + document.getElementById('lblSumaAseg' + j).innerHTML;

            arrDatosImpresion[j - 1] = cadena;
        }

        for (var i = 1; i <= 7; i++) {
            cadena = "";
            cadena2 = "";
            cadena3 = "";
            if (document.getElementById("Renglon" + i).style.display == "table-row") {
                //var fuma = document.getElementById("hdnFuma" + i).value;
                var fuma = 0;
                var nombre = document.getElementById("lblNombre" + i).innerText;
                var cod_parent = document.getElementById("lblParentesco" + i).value;
                var nom_parent = document.getElementById("lblParentesco" + i).innerText;
                var secu = 1;
                if (cod_parent == 37) secu = 2;
                var fechaNac = "01/01/" + (parseInt(arrFechaActual[2]) - parseInt(document.all("lblEdad" + i).innerText));
                //var RFC = Catalogos.getRFC(nombre, fechaNac);
                var sexo = "0";
                /*if(document.getElementById("lblSexo" + i).innerText == 'F') sexo = 0;
                else if(document.getElementById("lblSexo" + i).innerText == 'M') sexo = 1;*/

                cadena += "NUM_RIESGO=" + riesgo[i] + "|";
                cadena += "NUM_SECU=" + secu + "|";
                cadena += "TIP_BENEF=2|";
                cadena += "COD_PARENTESCO=" + cod_parent + "|";
                cadena += "NOM_PARENTESCO=" + nom_parent + "|";
                cadena += "NOMBRE=" + nombre + "|";
                cadena += "FEC_NACIMIENTO=" + fechaNac + "|";
                cadena += "MCA_SEXO=" + sexo + "|";
                cadena += "MCA_FUMA=" + fuma + "|";
                cadena += "COD_MODALIDAD=" + modalidad + "|";
                cadena += "FEC_EFEC_RIESGO=" + fechaActual + "|";
                cadena += "FEC_VCTO_RIESGO=" + fecVcto + "|";
                cadena += "FEC_EFEC_SPTO=" + fechaActual + "|";
                cadena += "FEC_VCTO_SPTO=" + fecVcto;


                if (cod_parent != 37) {
                    cadena3 += "NUM_RIESGO=" + riesgo[i] + "|";
                    cadena3 += "NUM_SECU=" + secu + "|";
                    cadena3 += "TIP_BENEF=2|";
                    cadena3 += "COD_PARENTESCO=" + cod_parent + "|";
                    cadena3 += "NOM_PARENTESCO=" + nom_parent + "|";
                    cadena3 += "NOMBRE=" + nombre + "|";
                    cadena3 += "FEC_NACIMIENTO=" + fechaNac + "|";
                    cadena3 += "MCA_SEXO=" + sexo + "|";
                    cadena3 += "MCA_FUMA=" + fuma + "|";
                    cadena3 += "COD_MODALIDAD=" + modalidad;
                    arrDatosMancomunado[arrDatosMancomunado.length] = cadena;
                }

                arrDatosAsegurado[arrDatosAsegurado.length] = cadena;

                if (cod_parent != 37) {
                    // Si el Titular ampara la cobertura Servicios Funerarios, se le agrega al menor
                    var cobert = document.getElementById('lblCoberturas' + i).value;
                    var cobert_name = document.getElementById('lblCoberturas' + i).innerText;

                    if (cod_parent == 2) {
                        var aux = Array();
                        aux = document.getElementById('lblCoberturas' + riesgos).value.split(',');
                        /*for(var a=0; a < aux.length; a++)
                        {
                            if(aux[a] == 1019)
                                cobert += "," + aux[a];
                        }*/
                    }
                    var cob = Array();
                    var suma = Array();
                    cob = cobert.split(',');
                    //suma = document.getElementById('lblSumaAseg' + i).innerText.split(moneda_nom);
                    suma = document.getElementById('lblSumaAseg' + i).innerText.split(" ");
                    for (var j = 0; j < cob.length; j++) {
                        if (cob[j] == 1019) {
                            cadena2 = "";
                            cadena2 += "NUM_RIESGO=" + riesgo[i] + "|";
                            cadena2 += "NUM_SECU=" + secu + "|";
                            cadena2 += "TIP_BENEF=10|";
                            cadena2 += "COD_PARENTESCO=" + cod_parent + "|";
                            cadena2 += "NOM_PARENTESCO=" + nom_parent + "|";
                            cadena2 += "NOMBRE=" + nombre + "|";
                            cadena2 += "FEC_NACIMIENTO=" + fechaNac + "|";
                            cadena2 += "MCA_SEXO=" + sexo + "|";
                            cadena2 += "MCA_FUMA=" + fuma + "|";
                            cadena2 += "COD_MODALIDAD=" + modalidad;
                            arrDatosFunerarios[arrDatosFunerarios.length] = cadena2;
                        }

                        /*if(cob[j]==1019){
                        cadena2 = "";
                        cadena2 += "TIP_BENEF=10|";
                        cadena2 += "NUM_RIESGO=" + 1 + "|";						    
                        cadena2 += "TIP_DOCUM=CLM|";                            
                        cadena2 += "COD_DOCUM=PRUEBA";                            						    
                        //cadena2 += "NUM_RIESGO=" + riesgo[i] + "|";
                        }*/



                        if (cobert_name != null) {
                            var datos = [];
                            datos = cobert_name?.split(',');
                            if (datos[0] == "BASICA" || datos[0] == "TEMPORAL") {
                                if (datos[0] == "BASICA") {
                                    CoberturaBasica = suma[j].replace(/\$|\,/g, '');
                                }
                                if (datos[0] == "TEMPORAL" && suma[j] != "" && suma[j] != null && suma[j] != "AMPARADA") {
                                    CoberturaBasica = suma[j].replace(/\$|\,/g, '');
                                }
                                
                            }

                            var nameCobertura = "";

                            switch (cob[j]) {
                                case "1000":
                                    nameCobertura = "BASICA";
                                    break;
                                case "1014":
                                    nameCobertura = "TEMPORAL";
                                    break;
                                case "1011":
                                    nameCobertura = "BIT";
                                    break;
                                case "1012":
                                    nameCobertura = "BIPA";
                                    break;
                                case "1013":
                                    nameCobertura = "BEF";
                                    break;
                                default:
                            }

                            cadena = "";
                            cadena += "COD_COB=" + cob[j] + "|";
                            cadena += "NOM_COB=" + nameCobertura + "|";
                            cadena += "MCA_BAJA_COB=N|";
                            cadena += "COD_RAMO=" + ramo + "|";
                            cadena += "NUM_RIESGO=" + riesgo[i] + "|"; // *
                            if (ramo != "112") {
                                cadena += "COD_SECC_REAS=13|"
                            } else {
                                cadena += "COD_SECC_REAS=0|"
                            }
                            //cadena += "COD_SECC_REAS=" + datos[9] + "|";
                            cadena += "SUMA_ASEG=";

                            if (suma[j] != null) {
                                if (cob[j] == 1011) {
                                    cadena += suma[j - 1] != undefined ? suma[j - 1].replace(/\$|\,/g, '') : CoberturaBasica;
                                }
                                else if (cob[j] == 1013) {
                                    cadena += suma[j - 1] != undefined ? suma[j - 1].replace(/\$|\,/g, '') : CoberturaBasica;
                                }
                                else if (cob[j] == 1019) {
                                    cadena += 0;
                                }
                                else {
                                    var sumAseg = suma[j].replace(/\$|\,/g, '');
                                    cadena += sumAseg;
                                }
                            }
                            else {
                                if (cob[j] == 1013) {
                                    cadena += CoberturaBasica;
                                }
                                else {
                                    cadena += 0;
                                }
                            }
                            cadena += "|";
                            cadena += "SUMA_ASEG_SPTO=";
                            if (suma[j] != null) {
                                if (cob[j] == 1011) {
                                    cadena += suma[j - 1] != undefined ? suma[j - 1].replace(/\$|\,/g, '') : CoberturaBasica;
                                }
                                else if (cob[j] == 1013) {
                                    cadena += suma[j - 1] != undefined ? suma[j - 1].replace(/\$|\,/g, '') : CoberturaBasica;
                                }
                                else if (cob[j] == 1019) {
                                    cadena += 0;
                                }
                                else {
                                    var sumAseg = suma[j].replace(/\$|\,/g, '');
                                    cadena += sumAseg;
                                }
                            }
                            else {
                                if (cob[j] == 1013) {
                                    cadena += CoberturaBasica;
                                }
                                else {
                                    cadena += 0;
                                }
                            }

                            arrDatosCoberturas[arrDatosCoberturas.length] = cadena;
                        }
                    }
                    //if (riesgo[i]==1){
                    //arrDatosBeneficiarios[arrDatosBeneficiarios.length] = cadena2;                   
                    cadena2 += "NUM_RIESGO=" + riesgo[i] + "|";
                    cadena2 += "NUM_SECU=" + secu + "|";
                    cadena2 += "TIP_BENEF=2|";
                    cadena2 += "COD_PARENTESCO=" + cod_parent + "|";
                    cadena2 += "NOM_PARENTESCO=" + nom_parent + "|";
                    cadena2 += "NOMBRE=" + nombre + "|";
                    cadena2 += "FEC_NACIMIENTO=" + fechaNac + "|";
                    cadena2 += "MCA_SEXO=" + sexo + "|";
                    cadena2 += "MCA_FUMA=" + fuma + "|";
                    cadena2 += "COD_MODALIDAD=" + modalidad + "|";
                    cadena2 += "FEC_EFEC_RIESGO=" + fechaActual + "|";
                    cadena2 += "FEC_VCTO_RIESGO=" + fecVcto + "|";
                    cadena2 += "FEC_EFEC_SPTO=" + fechaActual + "|";
                    cadena2 += "FEC_VCTO_SPTO=" + fecVcto + "|";
                    cadena2 += "TIP_DOCUM=" + tip_docum + "|";
                    cadena2 += "COD_DOCUM=" + CLM_Cont;

                    arrDatosBeneficiarios[arrDatosBeneficiarios.length] = cadena2;
                    //}//if (riesgo[i]==1){
                }
            }
            else i = 8;
        }

        var arrDatosVariables = new Array();
        var tablaVar = MetodosAjax.getDatosVariables(ramo);
        if (tablaVar.error == null) {
            if (tablaVar != null && tablaVar.value != null && tablaVar.value != 0) {
                cadena = "";
                cadena += "COD_CAMPO=VAL_FONDO";
                cadena += "|VAL_CAMPO=" + 7;
                cadena += "|TIP_NIVEL=" + tablaVar.value.Rows[i].TIP_NIVEL;
                cadena += "|NUM_SECU=" + tablaVar.value.Rows[i].NUM_SECU;
                cadena += "|NUM_RIESGO=" + tablaVar.value.Rows[i].NUM_RIESGO;

                arrDatosVariables[arrDatosVariables.length] = cadena;
                for (var i = 0; i < tablaVar.value.Rows.length; i++) {
                    campo = tablaVar.value.Rows[i].COD_CAMPO;
                    if (tablaVar.value.Rows[i].NUM_RIESGO == 0) {
                        cadena = "";
                        cadena += "COD_CAMPO=" + campo;
                        switch (campo) {
                            case "COD_ENVIO":
                                cadena += "|VAL_CAMPO=1";
                                break;

                            case "COD_ZONA":
                                cadena += "|VAL_CAMPO=99";
                                break;

                            case "TIP_DEDUCIBLE":
                                cadena += "|VAL_CAMPO=" + tip_deducible;
                                break;

                            case "TIP_COMISION":
                                cadena += "|VAL_CAMPO=" + tip_comision;
                                break;

                            case "VAL_DURACION_SEGURO":
                                cadena += "|VAL_CAMPO=" + plazo;
                                break;

                            case "COD_MODALIDAD":
                                cadena += "|VAL_CAMPO=" + modalidad;
                                break;

                            case "VAL_FOLIO_SOLICITUD":
                                cadena += "|VAL_CAMPO=1";
                                break;

                            case "NUM_EMPLEADO":
                                cadena += "|VAL_CAMPO=1";
                                break;

                            case "MCA_BENEFMEN":
                                cadena += "|VAL_CAMPO=N";
                                break;
                        }
                        if (cadena != "") {
                            cadena += "|TIP_NIVEL=" + tablaVar.value.Rows[i].TIP_NIVEL;
                            cadena += "|NUM_SECU=" + tablaVar.value.Rows[i].NUM_SECU;
                            cadena += "|NUM_RIESGO=" + tablaVar.value.Rows[i].NUM_RIESGO;

                            arrDatosVariables[arrDatosVariables.length] = cadena;
                        }
                    }
                }
            }
        }
        else alert(tablaVar.error);

        MetodosAjax.getCotiza(arrDatosPoliza, arrDatosVariables, arrDatosBeneficiarios, arrDatosCoberturas, arrDatosAsegurado, arrDatosFunerarios, arrDatosMancomunado, arrDatosImpresion, cotizacion_CallBack);
    }
}


function textoCtrl(nombreCtrl, valor) {
    var control = document.getElementById(nombreCtrl);
    if (control != null) {
        try {
            var objControl = new clsControl(control);
            if (valor == undefined)
                return objControl.texto();
            else objControl.texto(valor);
        }
        catch (ex) {
            alert(ex.name + " textoCtrl(): " + ex.description);
        }
    }
}

// Obtiene uno de los valores de un combo mediante un indice
function selValorCtrl(nombreCtrl, valor) {
    var control = document.getElementById(nombreCtrl);
    if (control != null) {
        try {
            var objControl = new clsControl(control);
            return objControl.selValor(valor);
        }
        catch (ex) {
            alert(ex.name + " selValorCtrl(): " + ex.description);
        }
    }
}

// Asigna el numero de riesgo para cada asegurado
function validaRiesgo() {
    var riesgo = new Array();
    for (var i = 1; i <= 7; i++) {
        if (document.getElementById("Renglon" + i).style.display == "table-row") {
            if (document.getElementById("lblParentesco" + i).value == 37)
                riesgo[i] = riesgo[(i - 1)];
            else
                riesgo[i] = i;
        }
        else i = 8;
    }
    return riesgo;
}

// Funcion que valida los datos que se van a cotizar
function validaCotizacion() {
    if (selIndex("drpAgente") == 0) {
        alert("Es necesario seleccionar un agente.");
        return false;
    }

    return true;
}



function cotizacion_CallBack(res) {
    if (res.error == null) {
        if (res != null && res.value != null && res.value.Tables != 0) {
            var Primaneta = formatCurrency(res.value.Tables[0].Rows[0].IMP_PRIMA);
            var Derechos = formatCurrency(res.value.Tables[0].Rows[0].IMP_DERECHOS);
            var Recargos = formatCurrency(res.value.Tables[0].Rows[0].IMP_RECARGOS);
            var Primatotal = formatCurrency(res.value.Tables[0].Rows[0].IMP_PRIMA_TOTAL);

            if (selIndex('drpMoneda') == "2") {
                var Primaneta2 = Primaneta + " USD";
                var Derechos2 = Derechos + " USD";
                var Recargos2 = Recargos + " USD";
                var Primatotal2 = Primatotal + " USD";
            }
            else {
                var Primaneta2 = Primaneta + " UDIS";
                var Derechos2 = Derechos + " UDIS";
                var Recargos2 = Recargos + " UDIS";
                var Primatotal2 = Primatotal + " UDIS";
            }

            document.getElementById("lblPrimaneta").innerText = Primaneta2;
            document.getElementById("lblDerechos").innerText = Derechos2;
            document.getElementById("lblRecargos").innerText = Recargos2;
            //document.getElementById("lblIVA").innerText = formatCurrency(res.value.Tables[0].Rows[0].IMP_IMPUESTOS);
            document.getElementById("lblPrimatotal").innerText = Primatotal2;
            var arrRiesgo = new Array();
            arrRiesgo = validaRiesgo();
            //for(var i=0; i<res.value.Tables[4].Rows.length; i++)
            /*for(var i=0; i<res.value.Tables[3].Rows.length; i++)
            {
                for(var j=1; j<=15; j++)
                {
                    if(document.getElementById("Renglon" + j).style.display == "inline")
                    {
                        if(arrRiesgo[j] == res.value.Tables[3].Rows[i].NUM_RIESGO)
                            document.getElementById("lblPrima" + j).innerText = formatCurrency(res.value.Tables[3].Rows[i].IMP_PRIMA);
                    }
                    else j = 16;
                }
            }*/
            //document.getElementById("pnlTotales").style.display = "inline";
            document.getElementById("pnlCotizacion").style.display = "inline";
            document.getElementById("lblNumCot").innerText = res.value.Tables[3].Rows[0].COTIZACION;
            //document.getElementById("btnNuevaCotizacion1").disabled = false;
            //document.getElementById("btnImprimir").disabled = false;
            document.getElementById("btnCotizar").disabled = true;

            MetodosAjax.getPrimas(res.value.Tables[3].Rows[0].COTIZACION, llenaPrimas_CallBack);
        }
        Cargando(false);
        //alert("No hubo error en la cotizacion");
        //alert(res.value.Tables[3].Rows[0].COTIZACION);
    }
    else {
        Cargando(false);
        alert(res.error);
    }
}

// Funcion que recibe una tabla (res) y llena el combo indicado en las variables globales
// valor es el codigo del catalog ej: cod_moneda	
function llenaPrimas_CallBack(res) {
    if (res.value.p_cadena != null) {
        oArray = new Array();
        oArray = res.value.p_cadena.split("|");

        for (i = 0; i + 1 < oArray.length; i++) {
            document.getElementById('lblPrima' + (i + 1)).innerHTML = formatCurrency(oArray[i]);
        }
    }
}

// Muestra y oculta las opciones de impresion
function impresion(visible) {
    if (visible == undefined) {
        if (document.getElementById("impresion").style.display == "none")
            visible = "inline";
        else if (document.getElementById("impresion").style.display == "inline")
            visible = "none";
    }
    document.getElementById("impresion").style.display = visible;
    document.getElementById("impresionCheckBoxes").style.display = visible;
    document.getElementById("impresionButtons").style.display = visible;
}



// Funcion para seleccion de coberturas
function NuevaCotizacion() {
    document.getElementById("drpAgente").focus();
}

function armaCadenaFirma(oper, ModoCotizacion) {

    Cargando(true);

    var token = document.getElementById("UscAsegCLM_hdnToken").value;
    var agente = selValorCtrl("drpAgente");
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var moneda = selValorCtrl("drpMoneda");
    var tip_regulariza = selValorCtrl("drpCrecimiento", 0);
    var pct_regulariza = selValorCtrl("drpCrecimiento", 1);
    var deducible = "";
    if (document.getElementById("HiddenRamoRequest").value == "101")
        deducible = selIndex("drpDeducible");
    else
        deducible = document.getElementById("HiddenDeducible").value;

    var comision = selValorCtrl("drpComision");
    var duracion = selValorCtrl("drpPlazo");
    MetodosAjax.setDuracion(duracion);
    var duracion1 = selValorCtrl("drpPlazo");
    var modalidad = document.getElementById("HiddenModalidad").value;
    MetodosAjax.setModalidad(modalidad);
    var tablaAsegurados = MetodosAjax.setAsegurados();
    if (ramo == "105") {
        duracion1 = duracion - tablaAsegurados.value.Rows[0].edad;
    }


    //	if (modalidad == "16010")
    //	{
    //	
    //	    if (document.getElementById("rbtnListPolizaContrato_1").checked)
    //        {
    //            modalidad= "16000" ;
    //        }
    //	
    //	}

    var envio = 1; //Agente
    var formaPago = selValorCtrl("drpFormaPago");
    var tipoPago = selValorCtrl("drpTipoPago");

    var cod_gestor = valorCtrl("UscContCLM_hdnCodEntidad");
    var zona = valorCtrl("UscContCLM_hdnEdo"); //Estado del Contratante
    var localidad = valorCtrl("UscContCLM_hdnPoblacion"); //Poblacion del Contratante

    //-------->C3<--------
    var tipo_seguro = "";
    var tip_seguros = document.getElementsByName("rblTipoSeguro");

    for (i = 0; i < tip_seguros.length; i++) {
        if (tip_seguros[i].checked == true) {
            tipo_seguro = tip_seguros[i].value;
        }
    }

    //Parte para el Envío de la Fecha de Nacimiento.
    var fecNac = "";
    //Si es una marca "C" de contización se debe preguntar si es solo la Cotización Inicial
    //o se trata de una "SOLICITUD" en caso de que no sea "C" es una "P" y deberá enviar la fecha del CLM
    //del Asegurado.
    if (oper == "C") {
        //Si solo se quieren obtener las primas Se obtiene la fecha obtenida a través de la edad.
        //Y si es una "Solicitud" entonces se envía la fecha del CLM.
        if (ModoCotizacion == "PRIMAS") {
            fecNac = document.getElementById("hidFechaNac").value;

            //------>C27<------
            //------>C20<------
            //tipo_seguro = "P";
        }
        else {
            if (ramo == "105") {
                fecNac = tablaAsegurados.value.Rows[0].fec_nac;
            }
            else {
                fecNac = valorCtrl("UscAsegCLM_lblNacimiento");
            }

        }
    }
    else {
        if (ramo == "105") {
            fecNac = tablaAsegurados.value.Rows[0].fec_nac;
        }
        else {
            fecNac = valorCtrl("UscAsegCLM_lblNacimiento");
        }

    }

    var fecEfecto = valorCtrl("txtFechaEfecto");
    MetodosAjax.setFecha(fecEfecto);
    var fecEfectoMas1Anio = MetodosAjax.sumarUnAnioAFecha(fecEfecto);
    var fecVcto = fecEfectoMas1Anio.value;

    var CLM_Cont = valorCtrl("UscContCLM_hdnCLM");
    if (ramo == "105") {
        var CLM_Aseg = tablaAsegurados.value.Rows[0].cod_docum;
    }
    else {
        var CLM_Aseg = valorCtrl("UscAsegCLM_hdnCLM");
    }
    var tip_docum = "CLM";

    var nombre_riesgo = "";
    if (oper == "C") {
        if (ModoCotizacion == "PRIMAS")
            nombre_riesgo = "RIESGO COTIZACION";
        else
            nombre_riesgo = valorCtrl("UscAsegCLM_lblNombre") + " " + valorCtrl("UscAsegCLM_lblApellidoPaterno") + " " + valorCtrl("UscAsegCLM_lblApellidoMaterno");
    }
    else {
        if (ramo == "105") {
            nombre_riesgo = tablaAsegurados.value.Rows[0].nombre + " " + tablaAsegurados.value.Rows[0].paterno + " " + tablaAsegurados.value.Rows[0].materno;
        }
        else {
            nombre_riesgo = valorCtrl("UscAsegCLM_lblNombre") + " " + valorCtrl("UscAsegCLM_lblApellidoPaterno") + " " + valorCtrl("UscAsegCLM_lblApellidoMaterno");
        }
    }
    //Se inicializa la variable sexo como 1 [Masculino]
    var mca_sexo = 1;
    if (oper == "C") {
        if (ModoCotizacion == "PRIMAS")
            mca_sexo = selValorCtrl("drpSexo");
        else {

            if (manejoLabel("UscAsegCLM_lblSexo") == "Femenino")
                mca_sexo = 0;
        }
    }
    else {
        if (ramo == "105") {

            mca_sexo = tablaAsegurados.value.Rows[0].sexo;
        }
        else {
            if (manejoLabel("UscAsegCLM_lblSexo") == "Femenino")
                mca_sexo = 0;
        }

    }

    var fuma = valorCtrl("drpFuma");
    var ingresoAnual = $('#txtIngresoM').val();
    var dctoSexo = document.getElementById("HiddenDctoSex").value;
    var dctoAgente = selValorCtrl("drpAgente");
    MetodosAjax.setAgente(dctoAgente);
    var dctoFuma = document.getElementById("HiddenDctoFuma").value;
    var polizaGrupo = "";
    var contrato = "";

    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        polizaGrupo = textoCtrl("drpPolizaGrupo");
        contrato = selValorCtrl("drpContrato");
    }

    if (oper == "C") {
        //tipoPago = "AG";
        if (ModoCotizacion == "PRIMAS")
            CLM_Cont = "PRUEBA";
        else
            CLM_Cont = valorCtrl("UscContCLM_hdnCLM");
    }
    else
        CLM_Cont = valorCtrl("UscContCLM_hdnCLM");

    if (tipoPago == "AG")
        cod_gestor = agente;

    //Esto es solo para que siempre deje Cotizar en caso de que el tipo
    //de Pago sea diferente de "AG" ya que la variable "cod_gestor"
    //al momento de obtener primas no tiene un valor y genera un error.
    if (ModoCotizacion == "PRIMAS") {
        tipoPago = "AG";
        cod_gestor = agente;
    }

    //Esto es para que al Obtener Primas siempre mande los valores correctos
    //en la Prima de cada Cobertura.
    if (ModoCotizacion == "PRIMAS")
        formaPago = 1;

    //C10
    var endosoEdu = "N";
    //C10

    var Ocupacion = selValorCtrl("drpOcupacion");
    var Peso = valorCtrl("txtPeso");
    var Estatura = valorCtrl("txtEstatura");

    //Validación de Vicente García Sepulveda.
    var codRiesgo = "0";
    var tipRiesgo = "0";
    if (ramo == "100") {
        if (modalidad == "10008") {
            codRiesgo = "1";
            tipRiesgo = "1";
        }
        if (modalidad == "10011" && polizaGrupo == "") {
            polizaGrupo = "1TEMPORAL1001";
            contrato = "10059";
        }
    }

    //	var cuadroCom = MetodosAjax.getCuadroComision(agente);
    //    if(cuadroCom.error != null)
    //        alert(cuadroCom.error.description);

    ///////////////////////////////////
    // Arreglo de datos de la poliza //
    ///////////////////////////////////
    var arrDatosPoliza = new Array();
    arrDatosPoliza.push("TIP_DURACION=1");
    arrDatosPoliza.push("COD_RAMO=" + ramo);
    arrDatosPoliza.push("COD_AGT=" + agente);
    if (ramo == "105") {
        arrDatosPoliza.push("ANIOS_MAX_DURACION=" + duracion1);
    }
    else {
        arrDatosPoliza.push("ANIOS_MAX_DURACION=" + duracion);
    }
    arrDatosPoliza.push("COD_ENVIO=" + envio);
    arrDatosPoliza.push("COD_FRACC_PAGO=" + formaPago);
    arrDatosPoliza.push("COD_GESTOR=" + cod_gestor);
    arrDatosPoliza.push("COD_MON=" + moneda);
    arrDatosPoliza.push("TIP_GESTOR=" + tipoPago);
    //Cuadros de Comision INI
    //arrDatosPoliza.push("COD_CUADRO_COM=" + cuadroCom.value);
    arrDatosPoliza.push("COD_CUADRO_COM=" + document.getElementById("HidCuadroCom").value);
    //Cuadros de Comision FIN
    arrDatosPoliza.push("TIP_DOCUM=" + tip_docum);
    arrDatosPoliza.push("COD_DOCUM=" + CLM_Cont);
    arrDatosPoliza.push("TXT_MOTIVO_SPTO=" + oper);
    arrDatosPoliza.push("MCA_IMPRESION=N");
    arrDatosPoliza.push("COD_MODALIDAD=" + modalidad);
    arrDatosPoliza.push("FEC_EFEC_POLIZA=" + fecEfecto);
    arrDatosPoliza.push("FEC_VCTO_POLIZA=" + fecVcto);
    if (ramo == "105") {

        var renglones = tablaAsegurados.value.Rows.length;
        //	for (var i = 0; i <= renglones -1; i++) {
        nombre_riesgo = tablaAsegurados.value.Rows[0].nombre + " " + tablaAsegurados.value.Rows[0].paterno + " " + tablaAsegurados.value.Rows[0].materno;
        arrDatosPoliza.push("FEC_EFEC_RIESGO=" + fecEfecto);
        arrDatosPoliza.push("FEC_VCTO_RIESGO=" + fecVcto);
        //	for (var i = 0; i <= renglones -1; i++) {
        arrDatosPoliza.push("NOM_RIESGO=" + nombre_riesgo);
        //}
    }
    else {
        arrDatosPoliza.push("FEC_EFEC_RIESGO=" + fecEfecto);
        arrDatosPoliza.push("FEC_VCTO_RIESGO=" + fecVcto);
        arrDatosPoliza.push("NOM_RIESGO=" + nombre_riesgo);
    }
    arrDatosPoliza.push("NUM_POLIZA_GRUPO=" + polizaGrupo);
    arrDatosPoliza.push("NUM_CONTRATO=" + contrato);
    arrDatosPoliza.push("TIP_REGULARIZA=" + tip_regulariza);
    arrDatosPoliza.push("PCT_REGULARIZA=" + pct_regulariza);



    var indAgt = 2;
    for (i = 2; i <= 5; i++) {
        var index = ((parseInt(i) < 10) ? "0" + i : i);
        if (document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave").value != "") {
            var codAgt = document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave").value
            var pctAgt = document.getElementById("dtgReferencias_ctl" + index + "_txtgrdPorcentaje").value
            if (i == 2)
                arrDatosPoliza.push("PCT_AGT=" + pctAgt);
            else {
                arrDatosPoliza.push("COD_AGT" + indAgt + "=" + codAgt);
                arrDatosPoliza.push("PCT_AGT" + indAgt + "=" + pctAgt);
                indAgt++;
            }
        }
    }

    ////////////////////////////////
    // Arreglo de datos variables //
    ////////////////////////////////
    var arrDatosVariables = new Array();
    var secu = 1;
    arrDatosVariables.push("COD_CAMPO=COD_ZONA|VAL_CAMPO=" + zona + "|VAL_COR_CAMPO=" + zona + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=COD_RIESGO|VAL_CAMPO=" + codRiesgo + "|VAL_COR_CAMPO=" + codRiesgo + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=TIP_RIESGO|VAL_CAMPO=" + tipRiesgo + "|VAL_COR_CAMPO=" + tipRiesgo + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=TIP_DEDUCIBLE|VAL_CAMPO=" + deducible + "|VAL_COR_CAMPO=" + deducible + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=TIP_COMISION|VAL_CAMPO=" + comision + "|VAL_COR_CAMPO=" + comision + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=VAL_DURACION_SEGURO|VAL_CAMPO=" + duracion + "|VAL_COR_CAMPO=" + duracion + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=COD_MODALIDAD|VAL_CAMPO=" + modalidad + "|VAL_COR_CAMPO=" + modalidad + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=VAL_FOLIO_SOLICITUD|VAL_CAMPO=1|VAL_COR_CAMPO=1|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=NUM_EMPLEADO|VAL_CAMPO=1|VAL_COR_CAMPO=1|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=MCA_BENEFMEN|VAL_CAMPO=" + endosoEdu + "|VAL_COR_CAMPO=" + endosoEdu + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    if (ramo == 105) {
        arrDatosVariables.push("COD_CAMPO=TIP_SEGURO_VIDA|VAL_CAMPO=P|VAL_COR_CAMPO=P|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);  //------>C3<--------
        //arrDatosVariables.push("COD_CAMPO=COD_PARENTESCO|VAL_CAMPO=38|VAL_COR_CAMPO=38|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);  //------>C3<--------
        //arrDatosVariables.push("COD_CAMPO=TIP_SEGURO_VIDA|VAL_CAMPO=999|VAL_COR_CAMPO=999|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);  //------>C3<--------

    }
    else {
        arrDatosVariables.push("COD_CAMPO=TIP_SEGURO_VIDA|VAL_CAMPO=" + tipo_seguro + "|VAL_COR_CAMPO=" + tipo_seguro +
            "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);  //------>C3<--------

    }

    if (ramo == "101" && modalidad == "12003" || ramo == "101" && modalidad == "12004") {

        var pp = selIndex("drpPlazoPrima");
        arrDatosVariables.push("COD_CAMPO=VAL_PLAZO_PRIMA|VAL_CAMPO=" + pp + "|VAL_COR_CAMPO=" + pp + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);

    }

    if (document.getElementById("chkMSI").checked == true) //MGM_MSI
    {
        arrDatosVariables.push("COD_CAMPO=NUM_AFILI_PORTAL|VAL_CAMPO=S|VAL_COR_CAMPO=S|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
        MSI = "S";
    }

    //DatoVariable Firma Digital 070520
    arrDatosVariables.push("COD_CAMPO=MCA_FIR_DGT|VAL_CAMPO=SI|VAL_COR_CAMPO=SI|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);

    //Nivel 2
    secu = 1;
    if (ramo == "105") {
        var renglones = tablaAsegurados.value.Rows.length;
        for (var i = 0; i <= renglones - 1; i++) {
            fecNac = tablaAsegurados.value.Rows[i].fec_nac;
            arrDatosVariables.push("COD_CAMPO=FEC_NACIMIENTO|VAL_CAMPO=" + fecNac.replace(/\/|\,/g, "") + "|VAL_COR_CAMPO=" + fecNac.replace(/\/|\,/g, "") + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=" + (i + 1) + "|COD_RAMO=" + ramo);
            arrDatosVariables.push("COD_CAMPO=MCA_SEXO|VAL_CAMPO=" + tablaAsegurados.value.Rows[i].sexo + "|VAL_COR_CAMPO=" + tablaAsegurados.value.Rows[i].sexo + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=" + (i + 1) + "|COD_RAMO=" + ramo);
            arrDatosVariables.push("COD_CAMPO=MCA_FUMAR|VAL_CAMPO=" + 0 + "|VAL_COR_CAMPO=" + 0 + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=" + (i + 1) + "|COD_RAMO=" + ramo);

            if (document.getElementById("divCuestionarioMillon").innerHTML != "") {
                arrDatosVariables.push("COD_CAMPO=MCA_ANUAL|VAL_CAMPO=" + ingresoAnual + "|VAL_COR_CAMPO=" + ingresoAnual + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
            }

        }

    }
    else {
        arrDatosVariables.push("COD_CAMPO=FEC_NACIMIENTO|VAL_CAMPO=" + fecNac.replace(/\/|\,/g, "") + "|VAL_COR_CAMPO=" + fecNac.replace(/\/|\,/g, "") + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
        arrDatosVariables.push("COD_CAMPO=MCA_SEXO|VAL_CAMPO=" + mca_sexo + "|VAL_COR_CAMPO=" + mca_sexo + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
        arrDatosVariables.push("COD_CAMPO=MCA_FUMAR|VAL_CAMPO=" + fuma + "|VAL_COR_CAMPO=" + fuma + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);

        if (document.getElementById("divCuestionarioMillon").innerHTML != "") {
            arrDatosVariables.push("COD_CAMPO=MCA_ANUAL|VAL_CAMPO=" + ingresoAnual + "|VAL_COR_CAMPO=" + ingresoAnual + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
        }
    }
    //Se agregan los Datos para la Ocupación Peso y Estatura.
    if (oper == "P") {
        var renglones = tablaAsegurados.value.Rows.length;
        for (var i = 0; i <= renglones - 1; i++) {
            arrDatosVariables.push("COD_CAMPO=COD_OCUPACION|VAL_CAMPO=" + tablaAsegurados.value.Rows[i].ocupacion + "|VAL_COR_CAMPO=" + 0 + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=" + (i + 1) + "|COD_RAMO=" + ramo);
            arrDatosVariables.push("COD_CAMPO=NUM_ESTATURA|VAL_CAMPO=" + tablaAsegurados.value.Rows[i].estatura + "|VAL_COR_CAMPO=" + tablaAsegurados.value.Rows[i].estatura + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=" + (i + 1) + "|COD_RAMO=" + ramo);
            arrDatosVariables.push("COD_CAMPO=NUM_PESO|VAL_CAMPO=" + tablaAsegurados.value.Rows[i].peso + "|VAL_COR_CAMPO=" + tablaAsegurados.value.Rows[i].peso + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=" + (i+1) + "|COD_RAMO=" + ramo);
        }
    }
    else {
        if (ModoCotizacion == "SOLICITUD") {
            arrDatosVariables.push("COD_CAMPO=COD_OCUPACION|VAL_CAMPO=" + Ocupacion + "|VAL_COR_CAMPO=" + Ocupacion + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
            arrDatosVariables.push("COD_CAMPO=NUM_ESTATURA|VAL_CAMPO=" + Estatura + "|VAL_COR_CAMPO=" + Estatura + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
            arrDatosVariables.push("COD_CAMPO=NUM_PESO|VAL_CAMPO=" + Peso + "|VAL_COR_CAMPO=" + Peso + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
        }
    }

    //Nivel 3
    secu = 1;
    if (dctoSexo == null) {
        dctoSexo = 0;
    }

    if (dctoFuma == null) {
        dctoFuma = 0;
    }

    arrDatosVariables.push("COD_CAMPO=DTO_SEXO|VAL_CAMPO=" + dctoSexo + "|VAL_COR_CAMPO=" + dctoSexo + "|TIP_NIVEL=3|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=DTO_FUMAR|VAL_CAMPO=" + dctoFuma + "|VAL_COR_CAMPO=" + dctoFuma + "|TIP_NIVEL=3|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=DTO_AGENTE_DIR|VAL_CAMPO=" + dctoAgente + "|VAL_COR_CAMPO=" + dctoAgente + "|TIP_NIVEL=3|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
    var arregloAsegurados = tablaAsegurados.value.Rows.length;
    for (var i = 0; i <= arregloAsegurados - 1; i++) {
        arrDatosVariables.push("COD_CAMPO=COD_PARENTESCO|VAL_CAMPO=" + tablaAsegurados.value.Rows[i].cod_parent + "|VAL_COR_CAMPO=38|NUM_RIESGO=" + (i + 1) + "|TIP_NIVEL=2|COD_RAMO=" + ramo + "|NUM_SECU=7");
    }

    var suma_aseg0 = "";
    // Arreglo con datos de las coberturas
    var arrDatosCoberturas = new Array();
    var tbCoberturas = document.getElementById("Coberturas");
    var cadena;
    var ExisteBIT = false;
    var EstaMarcadaBIT = false;
    var ContSumas = 0;

    var Cod_CobBit = "";

    secu = 1

    var mcaSF = "N";
    var suma_asegBasica = "";

    if (ramo == "105") {

    }
    else {
        for (var i = 1; i <= tbCoberturas.rows.length; i++) {
            cadena = "";
            if (document.getElementById("chk" + i) != null) {
                if (document.getElementById("chk" + i).value == "1095" || document.getElementById("chk" + i).value == "1001") {
                    ExisteBIT = true;
                    Cod_CobBit = document.getElementById("chk" + i).value;
                }

                if (document.getElementById("chk" + i).checked) {
                    var cod_cob = document.getElementById("chk" + i).value;
                    var sumaAseg = document.getElementById("txtSuma" + cod_cob).value;

                    /////Parte para suma_aseg0
                    if (ContSumas == 0)
                        suma_aseg0 = sumaAseg

                    ContSumas++;
                    //////////////////////////

                    if (isNaN(sumaAseg))
                        sumaAseg = "0";

                    cadena += "COD_COB=" + cod_cob + "|";

                    if (cod_cob == "1000") {
                        suma_asegBasica = sumaAseg;
                    }

                    //Caso especial para cobertura [1019] SF.
                    //****************************************************************************************
                    //Cuando sea diferente de [1019] SF se envía de manera normal la Suma Asegurada Capturada.
                    if (cod_cob != "1019") {
                        //Aplica el 25% de la suma asegurada basica para la cobertura EG
                        if (cod_cob == "1003") {
                            cadena += "SUMA_ASEG=" + suma_asegBasica * 0.25 + "|";
                            cadena += "SUMA_ASEG_SPTO=" + suma_asegBasica * 0.25 + "|";
                        }
                        else {
                            cadena += "SUMA_ASEG=" + sumaAseg + "|";
                            cadena += "SUMA_ASEG_SPTO=" + sumaAseg + "|";
                        }
                    }
                    //En caso de que la Cobertura [1019] SF haya sido marcada se envía como Suma el Valor de 0.
                    else {
                        cadena += "SUMA_ASEG=0|";
                        cadena += "SUMA_ASEG_SPTO=0|";

                        mcaSF = "S";
                    }
                    //*****************************************************************************************
                    cadena += "NUM_SECU=" + (secu++) + "|";
                    cadena += "COD_RAMO=" + ramo + "|";
                    cadena += "MCA_BAJA_COB=N";

                    //Caso especial para la Cobertura [1095] BIT si la Cobertura está Marcada, entonces no debe
                    //de Enviarse.
                    if (cod_cob != "1095" && cod_cob != "1001")
                        arrDatosCoberturas[arrDatosCoberturas.length] = cadena;
                    else {
                        if (ExisteBIT)
                            EstaMarcadaBIT = true;
                    }
                }
            }
        }
    }



    //Cuando la cobertura [1095] BIT exista pero no se haya marcado deberá enviarse con suma Asegurada igual a Cero.
    if (ExisteBIT) {
        if (!EstaMarcadaBIT) {
            var codCobBit = Cod_CobBit;

            /*if(ramo == "108")
               codCobBit = "1001";*/

            cadena = "";
            cadena += "COD_COB=" + codCobBit;
            cadena += "|SUMA_ASEG=0";
            cadena += "|SUMA_ASEG_SPTO=0";
            cadena += "|NUM_SECU=" + secu++;
            cadena += "|COD_RAMO=" + ramo;
            cadena += "|MCA_BAJA_COB=N";
            cadena += "|COD_SECC_REAS=13";
            cadena += "|NUM_RIESGO=" + (getNumAsegurado() + 1);
            arrDatosCoberturas.push(cadena);
        }
    }
    else {
        //Cuando no exista BIT en las coberturas se debe mandar con el fin de no AMPARARSE.
        if (ramo == 105) {
            cadena = "";
            cadena += "COD_COB=1091";
            cadena += "|SUMA_ASEG=0";
            cadena += "|SUMA_ASEG_SPTO=0";
            cadena += "|NUM_SECU=" + secu++;
            cadena += "|COD_RAMO=" + ramo;
            cadena += "|MCA_BAJA_COB=N";
            cadena += "|COD_SECC_REAS=13";
            cadena += "|NUM_RIESGO=" + 1;
            arrDatosCoberturas.push(cadena);

        }
        else {
            cadena = "";
            cadena += "COD_COB=1095";
            cadena += "|SUMA_ASEG=0";
            cadena += "|SUMA_ASEG_SPTO=0";
            cadena += "|NUM_SECU=" + secu++;
            cadena += "|COD_RAMO=" + ramo;
            cadena += "|COD_SECC_REAS=13";
            cadena += "|MCA_BAJA_COB=N";
            cadena += "|NUM_RIESGO=" + 1;
            arrDatosCoberturas.push(cadena);

            cadena = "";
            cadena += "COD_COB=1001";
            cadena += "|SUMA_ASEG=0";
            cadena += "|SUMA_ASEG_SPTO=0";
            cadena += "|NUM_SECU=" + secu++;
            cadena += "|COD_RAMO=" + ramo;
            cadena += "|MCA_BAJA_COB=N";
            arrDatosCoberturas.push(cadena);
        }
    }


    arrDatosPoliza.push("MCA_SF=" + mcaSF);

    //////////////////////////////
    // Arreglo de datos titular //
    //////////////////////////////
    var arrDatosTitular = new Array();
    if (oper == "C") {
        if (ModoCotizacion == "PRIMAS")
            arrDatosTitular.push("COD_DOCUM=PRUEBA");
        else
            arrDatosTitular.push("COD_DOCUM=" + CLM_Aseg);
    }
    else
        arrDatosTitular.push("COD_DOCUM=" + CLM_Aseg);
    arrDatosTitular.push("TIP_DOCUM=CLM");
    arrDatosTitular.push("TIP_BENEF=2");
    arrDatosTitular.push("NUM_SECU=1");
    arrDatosTitular.push("NUM_RIESGO=" + 1);
    //////////////////////////////////
    // Arreglo de datos contratante //
    //////////////////////////////////

    //Datos que son proporcionados por el Contratante de la persona que desea Asegurar.
    var arrDatosContratante = new Array();
    if (oper == "C") {
        arrDatosContratante.push("FEC_NACIMIENTO=" + fecNac);
        arrDatosContratante.push("MCA_SEXO=" + mca_sexo);
        arrDatosContratante.push("MCA_FUMA=" + selValorCtrl("drpFuma"));
    }

    ///////////////////////////////////
    // Arreglo de datos beneficiario //
    ///////////////////////////////////
    var arrDatosBenef = new Array();
    if (ModoCotizacion == "SOLICITUD")
    //if(oper == "P")
    {
        var tblBenef = MetodosAjax.generaCodDocumBENEF();
        if (tblBenef.error == null) {
            if (tblBenef != null && tblBenef.value != null && tblBenef.value.Rows.length != 0) {
                secu = 0;
                var prim = 0;
                var totalpor = 0;
                for (var i = 0; i < tblBenef.value.Rows.length; i++) {
                    secu++;
                    var tip_benef = tblBenef.value.Rows[i].tip_benef;
                    if (tip_benef == 6) {
                        prim++;
                        secu = 0;
                    }

                    cadena = "";
                    cadena += "TIP_DOCUM=" + tblBenef.value.Rows[i].tip_docum;
                    cadena += "|COD_DOCUM=" + tblBenef.value.Rows[i].cod_docum;
                    var cant_bene = tblBenef.value.Rows.length;
                    var porcentanje;
                    var porcentaje2;
                    if (ramo != "105") {


                    }

                    else {
                        cadena += "|PCT_PARTICIPACION=" + tblBenef.value.Rows[i].porcentaje;
                    }


                    cadena += "|TIP_BENEF=" + tip_benef;
                    cadena += "|NUM_RIESGO=" + (i + 1);

                    if (tip_benef == 6)
                        cadena += "|NUM_SECU=" + prim;
                    else cadena += "|NUM_SECU=" + secu;

                    arrDatosBenef[arrDatosBenef.length] = cadena;

                }
            }
        }
        else alert(tblBenef.error.description);
    }

    var arrDatosBanco = new Array();

    if (ModoCotizacion == "SOLICITUD") {
        MetodosAjax.setSession("COD_AGT", agente);
        MetodosAjax.setSession("CodigoMoneda", moneda);
        MetodosAjax.setSession("EdadTitular", manejoLabel("UscAsegCLM_lblEdad"));
        MetodosAjax.setSession("SumaAsegurada", suma_aseg0);
        MetodosAjax.setSession("COD_RAMO", ramo);
        MetodosAjax.setSession("COD_DOCUMT", CLM_Aseg);
        MetodosAjax.setSession("NOM_TERCEROT", valorCtrl("UscAsegCLM_lblNombre"));
        MetodosAjax.setSession("COD_ESTADOT", zona);
    }


    if (oper == "C") {
        if (ModoCotizacion == "PRIMAS")
            MetodosAjax.getCotizacion(oper, arrDatosPoliza, arrDatosVariables, arrDatosCoberturas, arrDatosContratante, arrDatosTitular, arrDatosBenef, arrDatosBanco, token, getCot_CallBack);
        else {
            MetodosAjax.getSolicitudFirma(oper, arrDatosPoliza, arrDatosVariables, arrDatosCoberturas, arrDatosContratante, arrDatosTitular, arrDatosBenef, arrDatosBanco, token, getXmlEmision_CallBack);
        }
    }
    else {
        MetodosAjax.setOperacion("EMISION");
        MetodosAjax.getXmlEmision(oper, arrDatosPoliza, arrDatosVariables, arrDatosCoberturas, arrDatosContratante, arrDatosTitular, arrDatosBenef, arrDatosBanco, token, MSI, getXmlEmision_CallBack);
    }

}

function getXmlEmision_CallBack(res) {
    if (res.error == null) {
        if (res != null && res.value != null) {
            var tablaAsegurados = MetodosAjax.setAsegurados();

            var token = document.getElementById("UscAsegCLM_hdnToken").value;
            var agente = selValorCtrl("drpAgente");
            var numCotizacion = MetodosAjax.getValSession("numCotizacion").value;
            var ramo = document.getElementById("HiddenRamoRequest").value;
            var cuestionarioMillon = document.getElementById("hdnValCuestMillon").value;
            var CLM_Contratante = document.getElementById("UscContCLM_lblCLM").innerHTML;
            var CLM_Asegurado = "";
            var CLM_AseguradoMancomunado = "";
            var EsMoral = false;
            var AseguradoEsContratante = false;
            for (var i = 0; i < tablaAsegurados.value.Rows.length; i++) {
                if (tablaAsegurados.value.Rows[i].cod_parent == "4") {
                    CLM_Asegurado = tablaAsegurados.value.Rows[i].cod_docum;
                    if (CLM_Contratante == CLM_Asegurado) {
                        AseguradoEsContratante = true;
                    }
                } else if (tablaAsegurados.value.Rows[i].cod_parent == "37") {
                    CLM_AseguradoMancomunado = tablaAsegurados.value.Rows[i].cod_docum;
                }
            }
            if (CLM_Asegurado == "") {
                CLM_Asegurado = tablaAsegurados.value.Rows[0].cod_docum;
            }
            ////////////////////////////////////////////////////////////////////////////////////////////////
            /*VARIABLES SOLICITUD VIDA*/

            ///Solicitud de vida

            if (document.getElementById('UscContCLM_rdoMoral').checked) {
                ////////////Datos contratante persona Moral//////////////////
                var txtrazonSocial = valorCtrl("UscContCLM_lblNombre");
                var txtRfcPersonaMoral = valorCtrl("UscContCLM_lblRFC");
                var txtRelacionSolicitante = valorCtrl("UscContCLM_lblParentesco");
                var txtnNumSerieFirmElectr = "";
                var txtNacionalidad = document.getElementById("UscContCLM_lblNacionalidad").innerHTML;
                var txtCorreoElectrPagWeb = valorCtrl("UscContCLM_lblCorreo");
                var txtGiroMercantilObjSocial = valorCtrl("UscContCLM_lblActividad");
                var txtFolioMercantil = "";
                var txtFechaConstitucion = document.getElementById("UscContCLM_lblNacimiento").innerHTML;
                var txtNombreCompletoApoderadoLegal = valorCtrl("UscContCLM_lblRepresentante");
                var txtNacionalidadApoderado = valorCtrl("UscContCLM_lblPaisRepresentanteLegal");
                var txtDomicApoderadoLegal = valorCtrl("UscContCLM_lblDireccion") + " " + valorCtrl("UscContCLM_lblColonia") + " " + valorCtrl("UscContCLM_lblCP") + " " + valorCtrl("UscContCLM_lblPoblacion") + " " + valorCtrl("UscContCLM_lblEdo");
                ////////////Datos contratante persona fisica en blanco////////
                var txtRelacionSolicitantePersonaFisica = "";
                var txtPaisLugarNacimientoPersonaFisica = "";
                //var txtFechaNacimientoPersonaFisica = valorCtrl(UscContCLM_lblNacimiento);
                var txtFechaNacimientoPersonaFisica = "";
                var txtCorreoElectronicoPersonaFisica = "";
                var drpOcupacion = "";
                var txtOcupacionProfesionPersonaFisica = "";
                //var txtOcupacionProfesionPersonaFisica = valorCtrl("drpOcupacion");
                var txtEspecifiquePersonaFIsica = "";
                var txtNombrePaternoMaternoPersonaFisica = "";
                var txtNacionPersFis = "";
                var txtRfcPersonaFisica = "";
                var txtTinNifPersonaFisica = "";
                var txtCurpPersonaFIsica = "";
                var txtGiroNegocioPersonaFisica = "";
                var txtNumeroSerieFIrmaElectronicaAvanzadaPersonaFisica = "";
                var txtVigenciaPersonaFisica = "";
                var txtTipoNumeroEmisorIdentificacionOficialPersonaFisica = "";
                EsMoral = true;
            } else {
                ////////////Datos contratante persona fisica///////////////////
                var txtRelacionSolicitantePersonaFisica = valorCtrl("UscContCLM_lblParentesco");
                var txtPaisLugarNacimientoPersonaFisica = valorCtrl("UscContCLM_lblNacionalidad");
                //var txtFechaNacimientoPersonaFisica = valorCtrl(UscContCLM_lblNacimiento);
                var txtFechaNacimientoPersonaFisica = document.getElementById("UscContCLM_lblNacimiento").innerHTML;
                var txtCorreoElectronicoPersonaFisica = valorCtrl("UscContCLM_lblCorreo");
                var drpOcupacion = document.getElementById("drpOcupacion");
                var txtOcupacionProfesionPersonaFisica = drpOcupacion.options[drpOcupacion.selectedIndex].text;
                //var txtOcupacionProfesionPersonaFisica = valorCtrl("drpOcupacion");
                var txtEspecifiquePersonaFIsica = valorCtrl("UscContCLM_lblActividad");
                var txtNombrePaternoMaternoPersonaFisica = valorCtrl("UscContCLM_lblNombre") + " " + valorCtrl("UscContCLM_lblApellidoPaterno") + " " + valorCtrl("UscContCLM_lblApellidoMaterno");
                var txtNacionPersFis = document.getElementById("UscContCLM_lblNacionalidad").innerHTML;
                var txtRfcPersonaFisica = valorCtrl("UscContCLM_lblRFC");
                var txtTinNifPersonaFisica = valorCtrl("UscContCLM_lblTin");
                var txtCurpPersonaFIsica = valorCtrl("UscContCLM_lblCURP");
                var txtGiroNegocioPersonaFisica = valorCtrl("UscContCLM_lblActividad");
                var txtNumeroSerieFIrmaElectronicaAvanzadaPersonaFisica = "";
                var txtVigenciaPersonaFisica = "";
                var txtTipoNumeroEmisorIdentificacionOficialPersonaFisica = "";
                ////////////Datos contratante persona Moral en blanco//////////////////
                var txtrazonSocial = "";
                var txtRfcPersonaMoral = "";
                var txtRelacionSolicitante = "";
                var txtnNumSerieFirmElectr = "";
                var txtNacionalidad = "";
                var txtCorreoElectrPagWeb = "";
                var txtGiroMercantilObjSocial = "";
                var txtFolioMercantil = "";
                var txtFechaConstitucion = "";
                var txtNombreCompletoApoderadoLegal = "";
                var txtNacionalidadApoderado = "";
                var txtDomicApoderadoLegal = "";

            }


            ////////////////////DOMICILIO CONTRATANTE////////////
            var txtCalleContratente = valorCtrl("UscContCLM_lblDireccion");
            var txtNoExteriorContratante = "";//valorCtrl("UscContCLM_lblDireccion");
            var txtNoInteriorContratante = "";//valorCtrl("UscContCLM_lblDireccion");
            var txtColoniaContratente = valorCtrl("UscContCLM_lblColonia");
            var txtMunicipioDelegacionContratante = valorCtrl("UscContCLM_lblPoblacion");
            var txtCiudadPoblacionContratente = valorCtrl("UscContCLM_lblPoblacion");
            var txtEstadoProvinciaContratante = valorCtrl("UscContCLM_lblEdo");
            var txtPaisContratante = valorCtrl("UscContCLM_lblPaisRef");
            var txtCpPoboxContratante = valorCtrl("UscContCLM_lblCP");
            var txtTelefonoContratante = valorCtrl("UscContCLM_lblTelefono");
            var txtClavePaisContratante = "";
            var txtCodigoPaisContratante = "";
            var txtPaisResidenciaFiscalContratante = valorCtrl("UscContCLM_lblPaisRef");
            var txtOrdenesTransferenciaPermanentesContratante = "";


            ////////////////////FATCA////////////
            var chkContratanteNo = "";
            var chkContratanteSi = "";
            var chkBeneficiarioSi = "";
            var chkBeneficiarioNo = "";
            var chkSolicitanteSi = "";
            var chkSolicitanteNo = "";
            ///////////FIN FATCA//////////////////

            ////////////////////SOLICITANTE////////////

            var txtNombrePaternoMaternoSolicitante = valorCtrl("UscAsegCLM_lblNombre") + " " + valorCtrl("UscAsegCLM_lblApellidoPaterno") + " " + valorCtrl("UscAsegCLM_lblApellidoMaterno");
            var txtNacionalidadesSolicitante = document.getElementById("UscAsegCLM_lblNacionalidad").innerHTML;
            var txtFechaNacimientoSolicitante = document.getElementById("UscAsegCLM_lblNacimiento").innerHTML;
            var txtPaisLugarNacimientoSolicitante = valorCtrl("UscAsegCLM_lblNacionalidad");
            var txtRfcSolicitante = valorCtrl("UscAsegCLM_lblRFC");
            var txtCurpSolicitante = valorCtrl("UscAsegCLM_lblCURP");
            var txtTinNifEquivalenteSolicitante = valorCtrl("UscAsegCLM_lblTin");
            var txtEstadoCivilSolicitante = valorCtrl("UscAsegCLM_lblEdoCivil");
            var txtOcupacionSolicitante = "txtOcupacionSolicitante";

            var drpOcupacionSol = document.getElementById("drpOcupacion");
            var txtOcupacionSolicitante = drpOcupacionSol.options[drpOcupacionSol.selectedIndex].text;
            var txtEspecifiqueSolicitante = valorCtrl("UscAsegCLM_lblActividad");
            //var txtEmpresaPrestaServicioSolicitante = valorCtrl("drpSexo");
            var txtGiroTelefonoEmpresaSolicitante = "";
            var txtTipoNumeroEmisorIdentidadOficialSolicitante = "";
            var txtVigenciaSolicitante = "";
            var txtEmpresaPrestaServicioSolicitante = "";
            var txtCanFumaSol = "";
            if (valorCtrl("drpSexo") == 0) {
                var chkSexoFemeninoSolicitante = "Yes";
            } else {
                var chkSexoMasculinoSolicitante = "Yes";
            }

            if (valorCtrl("drpFuma") == 0) {
                var chkFumaNoSolicitante = "Yes";
            } else {
                var chkFumaSiSolicitante = "Yes";
            }
            var txtNumeroSerieFimaElectronicaAvanzadaSolicitante = "";
            var txtCorreoElectronicoSolicitante = valorCtrl("UscAsegCLM_lblCorreo");
            var txtCalleSolicitante = valorCtrl("UscAsegCLM_lblDireccion");
            var txtNoExteriorSolicitante = "";
            var txtNoInteriorSolicitante = "";
            var txtColoniaSolicitante = valorCtrl("UscAsegCLM_lblColonia");
            var txtMunicipioDelegacionSolicitante = valorCtrl("UscAsegCLM_lblPoblacion");
            var txtCiudadPoblacionSolicitante = valorCtrl("UscAsegCLM_lblPoblacion");
            var txtEstadoProvinciaSolicitante = valorCtrl("UscAsegCLM_lblEdo");
            var txtPaisRecidenciaFiscalSolicitante = valorCtrl("UscAsegCLM_lblPaisRef");
            var txtCpPoboxSolicitante = valorCtrl("UscAsegCLM_lblCP");
            var txtTelefonoSolicitante = valorCtrl("UscAsegCLM_lblTelefono");
            var txtClavePaisSolicitante = "";
            var txtCodigoCiudadSolicitante = "";
            var chkCargoPublicoSiSolicitante = "";
            var chkCagoPublicoNoSolicitante = "";
            var txtEspecificarCargoSolicitante = "";
            ////////////////////FIN SOLICITANTE////////////

            ///////////////////COBRO////////////////////
            var chkFormaPagoContado = "";
            var chkFormaPagoSemanal = "";
            var chkFormaPagoQuincenal = "";
            var chkFormaPagoSemestral = "";
            var chkFormaPagoTrimestral = "";
            var chkFormaPagoUnico = "";
            var chkFormaPagoMensual = "";

            if (valorCtrl("drpFormaPago") == 1) {
                chkFormaPagoContado = "Yes";
            } else {
                if (valorCtrl("drpFormaPago") == 2) {
                    chkFormaPagoSemestral = "Yes";
                } else {
                    if (valorCtrl("drpFormaPago") == 3) {
                        chkFormaPagoTrimestral = "Yes";
                    } else {
                        if (valorCtrl("drpFormaPago") == 4) {
                            chkFormaPagoMensual = "Yes";
                        }
                    }

                }
            }

            ///////////////////COBRO////////////////////
            var chkConductoCobroTransferenciaBancaria = "";//
            var chkConductoCobroEfectivo = "";//BA
            var chkConductoCobroAgente = "";//AG
            var chkConductoCobroDomiciliado = "";
            if (valorCtrl("drpTipoPago") == "BA") {
                chkConductoCobroEfectivo = "Yes";
            } else {
                chkConductoCobroAgente = "Yes";
            }
            ///////////////////FIN COBRO////////////////////
            ///////////////////PLAN////////////////////
            var txtPlan = valorCtrl("lblPlan");
            var txtPlazo = valorCtrl("drpPlazo");
            var txtEa = "";

            var txtMoneda = "";
            if (valorCtrl("drpMoneda") == 1) {
                var chkMonedaNacional = "Yes";
            } else {
                if (valorCtrl("drpMoneda") == 2) {
                    var chkMonedaDolares = "Yes";
                } else {
                    var chkMonedaUdis = "Yes";
                }
            }

            var txtCrecimiento = "";
            if (valorCtrl("drpCrecimiento") == "0,0,") {
                var chkCrecimientoConstante = "Yes";
            } else {
                if (valorCtrl("drpCrecimiento") == "2,10,") {
                    var chkCrecimientoLineal = "Yes";
                } else {
                    var chkCrecimientoGeometrico = "Yes";
                }
            }

            var txtSumaAseguradaBasica = valorCtrl("txtSuma1000");




            ////////////////////VALORES COBERTURAS//////////////////////////7

            var tbCoberturas = document.getElementById("Coberturas");
            var chkAccidentePo = "";
            var chkAccidenteMa = "";
            var chkAccidenteMac = "";
            var chkAccidenteMapoc = "";
            var chkAccidentePoc = "";
            var chkAccidenteMapo = "";
            var chkBipa = "";
            var chkBit = "";
            var txtSumaAseguradaAccidente = "";
            var txtSumaAseguradaInvalidez = "";
            var chkPasi = "";
            var txtSumaAseguradaPlanSuperacionPlus = "";
            var chkTemporalIndividual = "";
            var chkMancomunado = "";
            var chkBita = "";

            for (var i = 1; i <= tbCoberturas.rows.length; i++) {

                if (document.getElementById("chk" + i) != null) {

                    if (document.getElementById("chk" + i).value == "1095" || document.getElementById("chk" + i).value == "1001") {
                        //BIT-A
                        if (document.getElementById("HiddenModalidad").value == "10003") {
                            if (document.getElementById("chk" + i).checked) { chkBita = "Yes"; }
                        }
                        else if (document.getElementById("chk" + i).checked) { chkBit = "Yes"; }
                    }
                    if (document.getElementById("chk" + i).value == "1096" || document.getElementById("chk" + i).value == "1002") {

                        if (document.getElementById("chk" + i).checked) {
                            chkBipa = "Yes";
                            if (valorCtrl("txtSuma1096") != undefined)
                                txtSumaAseguradaInvalidez = valorCtrl("txtSuma1096");
                            if (valorCtrl("txtSuma1002") != undefined)
                                txtSumaAseguradaInvalidez = valorCtrl("txtSuma1002");
                        }
                    }
                    //PASI
                    if (document.getElementById("chk" + i).value == "1018") {
                        if (document.getElementById("chk" + i).checked) {
                            chkPasi = "Yes";
                            if (valorCtrl("txtSuma1018") != undefined) {
                                txtSumaAseguradaInvalidez = valorCtrl("txtSuma1018");
                            }
                        }
                    }

                    if (document.getElementById("chk" + i).value == "1003") {
                        if (document.getElementById("chk" + i).checked) {
                            var chkEnfermedadesGravesSi = "Yes";
                        }
                        else {
                            var chkEnfermedadesGravesNo = "Yes";
                        }
                    }

                    if (document.getElementById("chk" + i).value == "1004") {
                        if (document.getElementById("chk" + i).checked) {
                            chkAccidenteMa = "Yes";
                            txtSumaAseguradaAccidente = valorCtrl("txtSuma1004");
                        }
                    }
                    if (document.getElementById("chk" + i).value == "1005") {
                        if (document.getElementById("chk" + i).checked) {
                            chkAccidentePo = "Yes";
                            txtSumaAseguradaAccidente = valorCtrl("txtSuma1005");
                        }
                    }
                    if (document.getElementById("chk" + i).value == "1006") {
                        if (document.getElementById("chk" + i).checked) {
                            chkAccidenteMac = "Yes";
                            txtSumaAseguradaAccidente = valorCtrl("txtSuma1006");
                        }
                    }
                    if (document.getElementById("chk" + i).value == "1007") {
                        if (document.getElementById("chk" + i).checked) {
                            chkAccidentePoc = "Yes";
                            txtSumaAseguradaAccidente = valorCtrl("txtSuma1007");
                        }
                    }
                    if (document.getElementById("chk" + i).value == "1008") {
                        if (document.getElementById("chk" + i).checked) {
                            chkAccidenteMapo = "Yes";
                            txtSumaAseguradaAccidente = valorCtrl("txtSuma1008");
                        }
                    }
                    if (document.getElementById("chk" + i).value == "1009") {
                        if (document.getElementById("chk" + i).checked) {
                            chkAccidenteMapoc = "Yes";
                            txtSumaAseguradaAccidente = valorCtrl("txtSuma1009");
                        }
                    }
                    if (document.getElementById("chk" + i).value == "1019") {
                        if (document.getElementById("chk" + i).checked) {
                            var chkServiciosFunerariosSI = "Yes";
                        } else {
                            var chkServiciosFunerariosNo = "Yes";
                        }
                    }
                }
            }








            ///////////////////FIN PLAN////////////////////

            ///////////////////CUESTIONARIO MEDICO////////////////////
            //if (document.getElementById('chk5').checked) {
            //    txtSumaAseguradaAccidente = valorCtrl("txtSuma1004");
            //    chkAccidenteMa = "Yes";
            //}
            //if (document.getElementById('chk6').checked) {
            //    txtSumaAseguradaAccidente = valorCtrl("txtSuma1005");
            //    chkAccidentePo = "Yes";
            //}
            //if (document.getElementById('chk7').checked) {
            //    txtSumaAseguradaAccidente = valorCtrl("txtSuma1006");
            //    chkAccidenteMac = "Yes";
            //}
            //if (document.getElementById('chk8').checked) {
            //    txtSumaAseguradaAccidente = valorCtrl("txtSuma1007");
            //    chkAccidentePoc = "Yes";
            //}
            //if (document.getElementById('chk9') != null) {
            //    if (document.getElementById('chk9').checked) {
            //        txtSumaAseguradaAccidente = valorCtrl("txtSuma1008");
            //        chkAccidenteMapo = "Yes";
            //    }
            //}
            //if (document.getElementById('chk10') != null) {
            //    if (document.getElementById('chk10').checked) {
            //        txtSumaAseguradaAccidente = valorCtrl("txtSuma1009");
            //        chkAccidenteMapoc = "Yes";
            //    }
            //}

            //if (document.getElementById('chk3').checked) {
            //    var txtSumaAseguradaInvalidez = valorCtrl("txtSuma1096");
            //    var chkBipa = "Yes";
            //}



            //if (document.getElementById('chk2').checked) {
            //    var chkBit = "Yes";
            //}
            //if (document.getElementById('chk4').checked) {
            //    var chkEnfermedadesGravesSi = "Yes";
            //} else {
            //    var chkEnfermedadesGravesNo = "Yes";
            //}

            //if (document.getElementById('chk11') != null) {
            //    if (document.getElementById('chk11').checked) {
            //        var chkServiciosFunerariosSI = "Yes";
            //    } else {
            //        var chkServiciosFunerariosNo = "Yes";
            //    }
            //}


            var chkBefSi = "";
            var chkBefNO = "";

            var txtPeso = valorCtrl("txtPeso");
            var txtEstatura = valorCtrl("txtEstatura");
            var txtCualDeporte = "";

            if (document.getElementById('chkboxSi').checked) {
                var chkDeportePeligrosoSi = "Yes";
            }

            if (document.getElementById('chkboxNo').checked) {
                var chkDeportePeligrosoNo = "Yes";
            }

            if (document.getElementById('chkSi1').checked) {
                var chkCorazonSi = "Yes";
            } else {
                var chkCorazonNo = "Yes";
            }
            if (document.getElementById('chkSi2').checked) {
                var chkHipertesionArterialSi = "Yes";
            } else {
                var chkHipertensionArterialNo = "Yes";
            }

            if (document.getElementById('chkSi3').checked) {
                var chkCrebroVasculadresSI = "Yes";;
            } else {
                var chkCerebroVasculadresNo = "Yes";
            }
            if (document.getElementById('chkSi4').checked) {
                var chkPsiquiatricasNerviosasSi = "Yes";
            } else {
                var chkPsiquiatricasNerviosasNo = "Yes";
            }
            if (document.getElementById('chkSi5').checked) {
                var chkEndocrinasSI = "Yes";
            } else {
                var chkEndocrinasNo = "Yes";
            }
            if (document.getElementById('chkSi6').checked) {
                var chkInsuficienciaRenalSi = "Yes";
            } else {
                var chkInsuficienciaRenalNo = "Yes";
            }
            if (document.getElementById('chkSi7').checked) {
                var chkSangreSi = "Yes";
            } else {
                var chkSangreNo = "Yes";
            }
            if (document.getElementById('chkSi8').checked) {
                var chkCirrosisHeptitisSi = "Yes";
            } else {
                var chkCirrosisHeptitisNo = "Yes";
            }
            if (document.getElementById('chkSi9').checked) {
                var chkPulmonaresRespiratoriasSi = "Yes";
            } else {
                var chkPulmonaresRespiratoriasNo = "Yes";
            }
            if (document.getElementById('chkSi10').checked) {
                var chkConsumoDrogasSI = "Yes";
            } else {
                var chkConsumoDrogasNo = "Yes";
            }
            if (document.getElementById('chkSi11').checked) {
                var chkSidaSI = "Yes";
            } else {
                var chkSidaNo = "Yes";
            }
            if (document.getElementById('chkSi12').checked) {
                var chkArtritisSI = "Yes";
            } else {
                var chkartritisNo = "Yes";
            }

            if (document.getElementById('chkSi13').checked) {
                var chkAparatoDigestivoSi = "Yes";
            } else {
                var chkAparatoDigestivoNo = "Yes";
            }

            var chkEnfermedadMencionadaNo = "Yes";
            var chkEnfermedadMencionadaSi = "";
            ///////////////////FIN CUESTIONARIO MEDICO////////////////////
            ///////////////////EN CASO AFIRMATIVO DE ALGUNA DE LAS PREGUNTAS ANTERIORES AMPLIAR LA INFORMACIÓN////////////////////
            var txtPreguntaUno = "";
            var txtPreguntaDos = "";
            var txtPreguntaTres = "";
            var txtPadecimientoUno = "";
            var txtPadecimientoDos = "";
            var txtPadecimientoTres = "";
            var txtFechaInicioUno = "";
            var txtFechaInicioTres = "";
            var txtFechaInicioDos = "";
            var txtDuracionUno = "";
            var txtDuracionTres = "";
            var txtDuracionDos = "";
            var txtEstadoActualUno = "";
            var txtEstadoActualTres = "";
            var txtEstadoActualDos = "";

            ///////////////////FIN EN CASO AFIRMATIVO DE ALGUNA DE LAS PREGUNTAS ANTERIORES AMPLIAR LA INFORMACIÓN////////////////////
            ///////////////////OTROS SEGUROS////////////////////
            var chkSolicitudSi = "";
            var chkSolicitudNo = "";
            var txtEspecificacionCompañiaSumaAseguradaMonedaPlan = "";
            var chkRechazadoSi = "";
            var chkRechazadoNo = "";
            var txtMotivo = "";
            ///////////////////FIN OTROS SEGUROS////////////////////

            ///////////////////BENEFICIARIOS////////////////////
            var txtBeneficiariosNombreCompletoUno = "";
            var txtBeneficiariosNombreCompletoDos = "";
            var txtBeneficiariosNombreCompletoTres = "";
            var txtParentescoUno = "";
            var txtParentescoDos = "";
            var txtParentescoTres = "";

            var txtPorcentajeUno = "";
            var txtPorcentajeDos = "";
            var txtPorcentajeTres = "";
            var txtDomicilioCompletoUno = "";
            var txtDomicilioCompletoDos = "";
            var txtDomicilioCompletoTres = "";
            var txtFechaNacimientoUno = "";
            var txtFechaNacimientoDos = "";
            var txtFechaNacimientoTres = "";


            ////var tbBeneficiarios = document.getElementById("grdBeneficiarios");
            //var tbBeneficiarios = document.get
            //if (tbBeneficiarios != null) {
            //    for (var i = 0; i < tbBeneficiarios.rows.length; i++) {
            //        if (tbBeneficiarios.rows[i].id != rowId) {
            //            if (i != 0)
            //                tbBeneficiarios.rows[i].style.backgroundColor = "";
            //        }
            //    }
            //}






            ///////////////////////////////////
            // Arreglo de datos beneficiario //
            //////////////////////////////////
            /*
            var arrDatosBenef2 = new Array();
    
                 var tblBenef2 = MetodosAjax.generaCodDocumBENEF();
      if(tblBenef2.error == null)
                {
                              if(tblBenef2 != null && tblBenef2.value != null && tblBenef2.value.Rows.length != 0)
                              {
                                  secu = 0;
              var prim = 0;
              var totalpor = 0;
              for(var i = 0; i < tblBenef2.value.Rows.length; i++)
              {
                  secu++;
                 var tip_benef = tblBenef2.value.Rows[i].tip_benef;
                  if(tip_benef == 6)
                  {
                      prim++;
                      secu = 0;
                  }
    
                  cadena = "";
                  cadena += "TIP_DOCUM=" + tblBenef2.value.Rows[i].tip_docum;
                  cadena += "|COD_DOCUM=" + tblBenef2.value.Rows[i].cod_docum;
                  var cant_bene2 = tblBenef2.value.Rows.length;
                  var porcentanje; 
                  var porcentaje2;
    
                  cadena += "|PCT_PARTICIPACION=" + tblBenef.value.Rows[i].porcentaje;
                 
                  cadena += "|TIP_BENEF=" + tip_benef;
                  
                  if(tip_benef == 6)
                      cadena += "|NUM_SECU=" + prim;
                  else cadena += "|NUM_SECU=" + secu;
                  
                  arrDatosBenef[arrDatosBenef.length] = cadena;
                 
              }
                              }
                          }
                          else alert(tblBenef.error.description);
            */

            ///////////////////FIN BENEFICIARIOS////////////////////


            ///////////////////OBSERVACIONES////////////////////
            var txtOberservacionesUno = "";
            var txtOberservacionesDos = "";
            var txtOberservacionesTres = "";
            ///////////////////FIN OBSERVACIONES////////////////////
            ///////////////////USO EXCLUSIVO CONTRATANTE////////////////////
            var txtMedioEntrega = "";
            ///////////////////FIN USO EXCLUSIVO CONTRATANTE////////////////////

            ///////////////////NOMBRE FIRMAS////////////////////
            var txtNombreFirmaContratante = valorCtrl("UscContCLM_lblNombre") + " " + valorCtrl("UscContCLM_lblApellidoPaterno") + " " + valorCtrl("UscContCLM_lblApellidoMaterno");
            var txtNombreFirmaSolicitante = valorCtrl("UscAsegCLM_lblNombre") + " " + valorCtrl("UscAsegCLM_lblApellidoPaterno") + " " + valorCtrl("UscAsegCLM_lblApellidoMaterno");
            var txtFirmaAgente = valorCtrl("dtgReferencias_ctl02_txtgrdNomAgente");
            ///////////////////FIN NOMBRE FIRMAS////////////////////


            ///////////////////AGENTE////////////////////

            var txtNombreAgente = valorCtrl("dtgReferencias_ctl02_txtgrdNomAgente");
            var txtClaveAgente = valorCtrl("dtgReferencias_ctl02_txtgrdClave");
            var txtComisionAgente = "%" + valorCtrl("dtgReferencias_ctl02_txtgrdPorcentaje");



            if (valorCtrl("drpComision") == 1) {
                var chkNivelada = "Yes";
            } else {
                var chkDecreciente = "Yes";
            }
            ///////////////////FIN AGENTE////////////////////

            ///////////////////FINALIDAD SEGURO////////////////////
            var chkFinalidadSeguroPatrimonial = "";
            var chkFinalidadSeguroCredito = "";
            var chkFinalidadSeguroSocios = "";
            var chkFinalidadSeguroRetiro = "";
            var chkFinalidadSeguroHombreClave = "";
            var chkFinalidadSeguroEducacion = "";
            if (document.getElementById('rblTipoSeguro_0') != null && document.getElementById('rblTipoSeguro_0').checked) {
                if (document.getElementById('rblTipoSeguro_0').value == "P") {
                    chkFinalidadSeguroPatrimonial = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_0').value == "C") {
                    chkFinalidadSeguroCredito = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_0').value == "S") {
                    chkFinalidadSeguroSocios = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_0').value == "R") {
                    chkFinalidadSeguroRetiro = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_0').value == "H") {
                    chkFinalidadSeguroHombreClave = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_0').value == "E") {
                    chkFinalidadSeguroEducacion = "Yes";
                }
            }
            if (document.getElementById('rblTipoSeguro_1') != null && document.getElementById('rblTipoSeguro_1').checked) {
                if (document.getElementById('rblTipoSeguro_1').value == "P") {
                    chkFinalidadSeguroPatrimonial = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_1').value == "C") {
                    chkFinalidadSeguroCredito = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_1').value == "S") {
                    chkFinalidadSeguroSocios = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_1').value == "R") {
                    chkFinalidadSeguroRetiro = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_1').value == "H") {
                    chkFinalidadSeguroHombreClave = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_1').value == "E") {
                    chkFinalidadSeguroEducacion = "Yes";
                }
            }
            if (document.getElementById('rblTipoSeguro_2') != null && document.getElementById('rblTipoSeguro_2').checked) {
                if (document.getElementById('rblTipoSeguro_2').value == "P") {
                    chkFinalidadSeguroPatrimonial = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_2').value == "C") {
                    chkFinalidadSeguroCredito = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_2').value == "S") {
                    chkFinalidadSeguroSocios = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_2').value == "R") {
                    chkFinalidadSeguroRetiro = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_2').value == "H") {
                    chkFinalidadSeguroHombreClave = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_2').value == "E") {
                    chkFinalidadSeguroEducacion = "Yes";
                }
            }
            if (document.getElementById('rblTipoSeguro_3') != null && document.getElementById('rblTipoSeguro_3').checked) {
                if (document.getElementById('rblTipoSeguro_3').value == "P") {
                    chkFinalidadSeguroPatrimonial = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_3').value == "C") {
                    chkFinalidadSeguroCredito = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_3').value == "S") {
                    chkFinalidadSeguroSocios = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_3').value == "R") {
                    chkFinalidadSeguroRetiro = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_3').value == "H") {
                    chkFinalidadSeguroHombreClave = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_3').value == "E") {
                    chkFinalidadSeguroEducacion = "Yes";
                }
            }
            if (document.getElementById('rblTipoSeguro_4') != null && document.getElementById('rblTipoSeguro_4').checked) {
                if (document.getElementById('rblTipoSeguro_4').value == "P") {
                    chkFinalidadSeguroPatrimonial = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_4').value == "C") {
                    chkFinalidadSeguroCredito = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_4').value == "S") {
                    chkFinalidadSeguroSocios = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_4').value == "R") {
                    chkFinalidadSeguroRetiro = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_4').value == "H") {
                    chkFinalidadSeguroHombreClave = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_4').value == "E") {
                    chkFinalidadSeguroEducacion = "Yes";
                }
            }
            if (document.getElementById('rblTipoSeguro_5') != null && document.getElementById('rblTipoSeguro_5').checked) {
                if (document.getElementById('rblTipoSeguro_5').value == "P") {
                    chkFinalidadSeguroPatrimonial = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_5').value == "C") {
                    chkFinalidadSeguroCredito = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_5').value == "S") {
                    chkFinalidadSeguroSocios = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_5').value == "R") {
                    chkFinalidadSeguroRetiro = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_5').value == "H") {
                    chkFinalidadSeguroHombreClave = "Yes";
                }
                if (document.getElementById('rblTipoSeguro_5').value == "E") {
                    chkFinalidadSeguroEducacion = "Yes";
                }
            }
            ///////////////////FIN FINALIDAD SEGURO////////////////////


            var txtPolizaUno = "";
            var txtFolioUno = "";
            var txtFolioTres = "";
            var txtFolioCinco = "";
            var txtPolizaNueve = "";
            var txtFolioDiez = "";
            var txtFolioTrece = "";
            var txtFolioNueve = "";
            var txtPolizaOnce = "";

            if (document.getElementById('chkSiCargoP').checked) {
                var chkCargoFuncionPublicaSi = "Yes";
            } else {
                var chkCargoFuncionPublicaNo = "Yes";
            }

            var txtEspecifiqueCargoPersonaFisica = valorCtrl("txtCargoP");
            var txtIngresoMensualSolicitante = valorCtrl("txtIngresoM");
            var txtPolizaDos = "";
            var txtPolizaCinco = "";
            var txtPolizaDiez = "";
            var txtFolioSiete = "";
            var txtFolioDoce = "";
            var txtPolizaCuatro = "";
            var txtPolizaSeis = "";
            var txtPolizaSiete = "";
            var txtFolioSeis = "";
            var txtFolioOcho = "";
            var txtFolioOnce = "";
            var txtPolizaOcho = "";
            var txtFolioCuatro = "";
            var txtPolizaDoce = "";
            var txtPolizaTrece = "";
            var txtFolioDos = "";
            var txtPolizaTres = "";

            ////////////////////////////////////////////////////////////////////////////////////////////////
            /*VARIABLES CUESTIONARIO MAYOR A 1.5 MDP*/
            if (document.getElementById("divCuestionarioMillon").innerHTML != "") {
                /*1*/var txtGiro = valorCtrl("txtGiro");
                /*2*/var txtTelefono = valorCtrl("txtTelefono");
                /*3*/var txtCvePais = valorCtrl("txtCvePais");
                /*4*/var txtCodCiudad = valorCtrl("txtCodCiudad");
                /*5*/var txtTipoMaquinas = valorCtrl("txtTipoMaquinas");

                /*6*/if (document.getElementById("chkSiOtraOcupacion").checked) {
                    var chkSiOtraOcupacion = "Yes";
                }

                /*6*/if (document.getElementById("chkNoOtraOcupacion").checked) {
                    var chkNoOtraOcupacion = "Yes";
                }

                /*7*/var txtOtraOcupacion = valorCtrl("txtOtraOcupacion");

                /*8*/if (document.getElementById("chkSiViajar").checked) {
                    var chkSiViajar = "Yes";
                }

                /*8*/if (document.getElementById("chkNoViajar").checked) {
                    var chkNoViajar = "Yes";
                }

                /*9*/var txtTipoTransporte = valorCtrl("txtTipoTransporte");


                /*10*/if (document.getElementById("chkSiAParticular").checked) {
                    var chkSiAParticular = "Yes";
                }

                /*10*/if (document.getElementById("chkNoAParticular").checked) {
                    var chkNoAParticular = "Yes";
                }

                /*11*/var txtTipoAeronave = valorCtrl("txtTipoAeronave");

                /*12*/if (document.getElementById("chkSiMotocicleta").checked) {
                    var chkSiMotocicleta = "Yes";
                }

                /*12*/if (document.getElementById("chkNoMotocicleta").checked) {
                    var chkNoMotocicleta = "Yes";
                }

                /*13*/var txtFMotocicleta = valorCtrl("txtFMotocicleta");

                /*14*/if (document.getElementById("chkSiAlturas").checked) {
                    var chkSiAlturas = "Yes";
                }

                /*14*/if (document.getElementById("chkNoAlturas").checked) {
                    var chkNoAlturas = "Yes";
                }

                /*15*/var txtAlturas = valorCtrl("txtAlturas");

                /*14a*/if (document.getElementById("chkOficina").checked) {
                    var chkOficina = "Yes";
                }

                /*14a*/if (document.getElementById("chkFabrica").checked) {
                    var chkFabrica = "Yes";
                }

                /*14a*/if (document.getElementById("chkTaller").checked) {
                    var chkTaller = "Yes";
                }

                /*14a*/if (document.getElementById("chkCalle").checked) {
                    var chkCalle = "Yes";
                }

                /*15a*/var txtOtroLugarTrabajo = valorCtrl("txtOtroLugarTrabajo");


                /*16*/if (document.getElementById("chkDProfesional").checked) {
                    var chkDProfesional = "Yes";
                }

                /*16*/if (document.getElementById("chkDAficionado").checked) {
                    var chkDAficionado = "Yes";
                }

                /*16*/if (document.getElementById("chkDAmateur").checked) {
                    var chkDAmateur = "Yes";
                }

                /*17*/if (document.getElementById("chkSiRiesgo").checked) {
                    var chkSiRiesgo = "Yes";
                }

                /*17*/if (document.getElementById("chkNoRiesgo").checked) {
                    var chkNoRiesgo = "Yes";
                }

                /*18*/var txtCantCopas = valorCtrl("txtCantCopas");
                /*19*/var txtFrecuenciaBebida = valorCtrl("txtFrecuenciaBebida");

                /*20*/if (document.getElementById("chkCigarros").checked) {
                    var chkCigarros = "Yes";
                }

                /*20*/if (document.getElementById("chkPuro").checked) {
                    var chkPuro = "Yes";
                }

                /*20*/if (document.getElementById("chkPipa").checked) {
                    var chkPipa = "Yes";
                }


                /*21*/var txtCantFumar = valorCtrl("txtCantFumar");
                /*22*/var txtFrecuenciaFumar = valorCtrl("txtFrecuenciaFumar");
                /*23*/var txtTipoDroga = valorCtrl("txtTipoDroga");
                /*24*/var txtFrecuenciaDroga = valorCtrl("txtFrecuenciaDroga");

                /*25*/
                var chrDd1Bebida, chrDd2Bebida, chrMm1Bebida, chrMm2Bebida, chrYy1Bebida, chrYy2Bebida;
                if (valorCtrl("txtFIBebida") == "") {
                    chrDd1Bebida = ""; chrDd2Bebida = ""; chrMm1Bebida = ""; chrMm2Bebida = ""; chrYy1Bebida = ""; chrYy2Bebida = "";
                }
                else {
                    var txtFIBebida = valorCtrl("txtFIBebida").split("");
                    chrDd1Bebida = txtFIBebida[0]; chrDd2Bebida = txtFIBebida[1]; chrMm1Bebida = txtFIBebida[3];
                    chrMm2Bebida = txtFIBebida[4]; chrYy1Bebida = txtFIBebida[8]; chrYy2Bebida = txtFIBebida[9];
                }
                /*26*/
                var chrDd1BebidaF, chrDd2BebidaF, chrMm1BebidaF, chrMm2BebidaF, chrYy1BebidaF, chrYy2BebidaF;
                if (valorCtrl("txtFFBebida") == "") {
                    chrDd1BebidaF = ""; chrDd2BebidaF = ""; chrMm1BebidaF = ""; chrMm2BebidaF = ""; chrYy1BebidaF = ""; chrYy2BebidaF = "";
                }
                else {
                    var txtFFBebida = valorCtrl("txtFFBebida").split("");
                    chrDd1BebidaF = txtFFBebida[0]; chrDd2BebidaF = txtFFBebida[1]; chrMm1BebidaF = txtFFBebida[3];
                    chrMm2BebidaF = txtFFBebida[4]; chrYy1BebidaF = txtFFBebida[8]; chrYy2BebidaF = txtFFBebida[9];
                }

                /*27*/var txtMotivoBebida = valorCtrl("txtMotivoBebida");

                /*28*/
                var chrDd1Fumar, chrDd2Fumar, chrMm1Fumar, chrMm2Fumar, chrYy1Fumar, chrYy2Fumar;
                if (valorCtrl("txtFIFumar") == "") {
                    chrDd1Fumar = ""; chrDd2Fumar = ""; chrMm1Fumar = ""; chrMm2Fumar = ""; chrYy1Fumar = ""; chrYy2Fumar = "";
                }
                else {
                    var txtFIFumar = valorCtrl("txtFIFumar").split("");
                    chrDd1Fumar = txtFIFumar[0]; chrDd2Fumar = txtFIFumar[1]; chrMm1Fumar = txtFIFumar[3];
                    chrMm2Fumar = txtFIFumar[4]; chrYy1Fumar = txtFIFumar[8]; chrYy2Fumar = txtFIFumar[9];
                }
                /*29*/
                var chrDd1FumarF, chrDd2FumarF, chrMm1FumarF, chrMm2FumarF, chrYy1FumarF, chrYy2FumarF;
                if (valorCtrl("txtFFFumar") == "") {
                    chrDd1FumarF = ""; chrDd2FumarF = ""; chrMm1FumarF = ""; chrMm2FumarF = ""; chrYy1FumarF = ""; chrYy2FumarF = "";
                }
                else {
                    var txtFFFumar = valorCtrl("txtFFFumar").split("");
                    chrDd1FumarF = txtFFFumar[0]; chrDd2FumarF = txtFFFumar[1]; chrMm1FumarF = txtFFFumar[3];
                    chrMm2FumarF = txtFFFumar[4]; chrYy1FumarF = txtFFFumar[8]; chrYy2FumarF = txtFFFumar[9];
                }
                /*30*/var txtMotivoFumar = valorCtrl("txtMotivoFumar");

                /*31*/
                var chrDd1Droga, chrDd2Droga, chrMm1Droga, chrMm2Droga, chrYy1Droga, chrYy2Droga;
                if (valorCtrl("txtFIDroga") == "") {
                    chrDd1Droga = ""; chrDd2Droga = ""; chrMm1Droga = ""; chrMm2Droga = ""; chrYy1Droga = ""; chrYy2Droga = "";
                }
                else {
                    var txtFIDroga = valorCtrl("txtFIDroga").split("");
                    chrDd1Droga = txtFIDroga[0]; chrDd2Droga = txtFIDroga[1]; chrMm1Droga = txtFIDroga[3];
                    chrMm2Droga = txtFIDroga[4]; chrYy1Droga = txtFIDroga[8]; chrYy2Droga = txtFIDroga[9];
                }
                /*32*/
                var chrDd1DrogaF, chrDd2DrogaF, chrMm1DrogaF, chrMm2DrogaF, chrYy1DrogaF, chrYy2DrogaF;
                if (valorCtrl("txtFFDroga") == "") {
                    chrDd1DrogaF = ""; chrDd2DrogaF = ""; chrMm1DrogaF = ""; chrMm2DrogaF = ""; chrYy1DrogaF = ""; chrYy2DrogaF = "";
                }
                else {
                    var txtFFDroga = valorCtrl("txtFFDroga").split("");
                    chrDd1DrogaF = txtFFDroga[0]; chrDd2DrogaF = txtFFDroga[1]; chrMm1DrogaF = txtFFDroga[3];
                    chrMm2DrogaF = txtFFDroga[4]; chrYy1DrogaF = txtFFDroga[8]; chrYy2DrogaF = txtFFDroga[9];
                }
                /*33*/var txtMotivoDroga = valorCtrl("txtMotivoDroga");

                /*34*/var txtEdadMadre = valorCtrl("txtEdadMadre");
                /*35*/var txtEdoSaludMadre = valorCtrl("txtEdoSaludMadre");
                /*36*/var txtViveMadre = valorCtrl("txtViveMadre");
                /*37*/var txtEdadMuerteMadre = valorCtrl("txtEdadMuerteMadre");
                /*38*/var txtMotivosMadre = valorCtrl("txtMotivosMadre");
                /*39*/var txtEdadPadre = valorCtrl("txtEdadPadre");
                /*40*/var txtEdoSaludPadre = valorCtrl("txtEdoSaludPadre");
                /*41*/var txtVivePadre = valorCtrl("txtVivePadre");
                /*42*/var txtEdadMuertePadre = valorCtrl("txtEdadMuertePadre");
                /*43*/var txtMotivosPadre = valorCtrl("txtMotivosPadre");
                /*44*/var txtEdadHermanos = valorCtrl("txtEdadHermanos");
                /*45*/var txtEdoSaludHermanos = valorCtrl("txtEdoSaludHermanos");
                /*46*/var txtViveHermanos = valorCtrl("txtViveHermanos");
                /*47*/var txtEdadMuerteHermanos = valorCtrl("txtEdadMuerteHermanos");
                /*48*/var txtMotivosHermanos = valorCtrl("txtMotivosHermanos");
                /*49*/var txtEdadHijos = valorCtrl("txtEdadHijos");
                /*50*/var txtEdoSaludHijos = valorCtrl("txtEdoSaludHijos");
                /*51*/var txtViveHijos = valorCtrl("txtViveHijos");
                /*52*/var txtEdadMuerteHijos = valorCtrl("txtEdadMuerteHijos");
                /*53*/var txtMotivosHijos = valorCtrl("txtMotivosHijos");
                /*54*/var txtQuienCardiaca = valorCtrl("txtQuienCardiaca");
                /*55*/var txtEvolucionCardiaca = valorCtrl("txtEvolucionCardiaca");
                /*56*/var txtQuienCancer = valorCtrl("txtQuienCancer");
                /*57*/var txtEvolucionCancer = valorCtrl("txtEvolucionCancer");
                /*58*/var txtQuienPresion = valorCtrl("txtQuienPresion");
                /*59*/var txtEvolucionPresion = valorCtrl("txtEvolucionPresion");
                /*60*/var txtQuienDiabetes = valorCtrl("txtQuienDiabetes");
                /*61*/var txtEvolucionDiabetes = valorCtrl("txtEvolucionDiabetes");

                /*62*/if (document.getElementById("chk1Si").checked) {
                    var chk1Si = "Yes";
                }

                /*62*/if (document.getElementById("chk1No").checked) {
                    var chk1No = "Yes";
                }

                /*63*/var txt1Causa = valorCtrl("txt1Causa");

                /*64*/if (document.getElementById("chk2Si").checked) {
                    var chk2Si = "Yes";
                }

                /*64*/if (document.getElementById("chk2No").checked) {
                    var chk2No = "Yes";
                }

                /*65*/var txt2Causa = valorCtrl("txt2Causa");
                /*66*/var txt2Cuando = valorCtrl("txt2Cuando");

                /*67*/if (document.getElementById("chk3Si").checked) {
                    var chk3Si = "Yes";
                }

                /*67*/if (document.getElementById("chk3No").checked) {
                    var chk3No = "Yes";
                }


                /*68*/var txt3Causa = valorCtrl("txt3Causa");
                /*69*/var txt3Cuando = valorCtrl("txt3Cuando");

                /*70*/if (document.getElementById("chk4Si").checked) {
                    var chk4Si = "Yes";
                }

                /*70*/if (document.getElementById("chk4No").checked) {
                    var chk4No = "Yes";
                }

                /*71*/var txt4Causa = valorCtrl("txt4Causa");
                /*72*/var txt4Cuando = valorCtrl("txt4Cuando");

                /*73*/if (document.getElementById("chk5Si").checked) {
                    var chk5Si = "Yes";
                }

                /*73*/if (document.getElementById("chk5No").checked) {
                    var chk5No = "Yes";
                }

                /*74*/var txtKgAumentados = valorCtrl("txtKgAumentados");
                /*75*/var txtKgDisminuidos = valorCtrl("txtKgDisminuidos");

                /*76*/if (document.getElementById("chk7Si").checked) {
                    var chk7Si = "Yes";
                }

                /*76*/if (document.getElementById("chk7No").checked) {
                    var chk7No = "Yes";
                }

                /*77*/var txt7Causa = valorCtrl("txt7Causa");


                /*78*/if (document.getElementById("chk8Si").checked) {
                    var chk8Si = "Yes";
                }

                /*78*/if (document.getElementById("chk8No").checked) {
                    var chk8No = "Yes";
                }

                /*79*/var txt8Meses = valorCtrl("txt8Meses");


                /*80*///var txtFPapanicolau = valorCtrl("txtFPapanicolau").split("");
                var chrDd1Papani, chrDd2Papani, chrMm1Papani, chrMm2Papani, chrYy1Papani, chrYy2Papani;
                if (valorCtrl("txtFPapanicolau") == "") {
                    chrDd1Papani = ""; chrDd2Papani = ""; chrMm1Papani = ""; chrMm2Papani = ""; chrYy1Papani = ""; chrYy2Papani = "";
                }
                else {
                    var txtFPapanicolau = valorCtrl("txtFPapanicolau").split("");
                    chrDd1Papani = txtFPapanicolau[0]; chrDd2Papani = txtFPapanicolau[1]; chrMm1Papani = txtFPapanicolau[3];
                    chrMm2Papani = txtFPapanicolau[4]; chrYy1Papani = txtFPapanicolau[8]; chrYy2Papani = txtFPapanicolau[9];
                }


                /*81*///var txtFMamografia = valorCtrl("txtFMamografia").split("");
                var chrDd1Mamo, chrDd2Mamo, chrMm1Mamo, chrMm2Mamo, chrYy1Mamo, chrYy2Mamo;
                if (valorCtrl("txtFMamografia") == "") {
                    chrDd1Mamo = ""; chrDd2Mamo = ""; chrMm1Mamo = ""; chrMm2Mamo = ""; chrYy1Mamo = ""; chrYy2Mamo = "";
                }
                else {
                    var txtFMamografia = valorCtrl("txtFMamografia").split("");
                    chrDd1Mamo = txtFMamografia[0]; chrDd2Mamo = txtFMamografia[1]; chrMm1Mamo = txtFMamografia[3];
                    chrMm2Mamo = txtFMamografia[4]; chrYy1Mamo = txtFMamografia[8]; chrYy2Mamo = txtFMamografia[9];
                }


                /*82*/var txtResPapanicolau = valorCtrl("txtResPapanicolau");
                /*83*/var txtResMamografia = valorCtrl("txtResMamografia");
                /*84*/var txt1Pregunta = valorCtrl("txt1Pregunta");
                /*85*/var txt1Padecimiento = valorCtrl("txt1Padecimiento");
                /*86*/var txt1FInicio = valorCtrl("txt1FInicio");
                /*87*/var txt1Duracion = valorCtrl("txt1Duracion");
                /*88*/var txt1Estado = valorCtrl("txt1Estado");
                /*89*/var txt2Pregunta = valorCtrl("txt2Pregunta");
                /*90*/var txt2Padecimiento = valorCtrl("txt2Padecimiento");
                /*91*/var txt2FInicio = valorCtrl("txt2FInicio");
                /*92*/var txt2Duracion = valorCtrl("txt2Duracion");
                /*93*/var txt2Estado = valorCtrl("txt2Estado");
                /*94*/var txt3Pregunta = valorCtrl("txt3Pregunta");
                /*95*/var txt3Padecimiento = valorCtrl("txt3Padecimiento");
                /*96*/var txt3FInicio = valorCtrl("txt3FInicio");
                /*97*/var txt3Duracion = valorCtrl("txt3Duracion");
                /*98*/var txt3Estado = valorCtrl("txt3Estado");
                /*99*/var txt4Pregunta = valorCtrl("txt4Pregunta");
                /*100*/var txt4Padecimiento = valorCtrl("txt4Padecimiento");
                /*101*/var txt4FInicio = valorCtrl("txt4FInicio");
                /*102*/var txt4Duracion = valorCtrl("txt4Duracion");
                /*103*/var txt4Estado = valorCtrl("txt4Estado");
                /*104*/var txtNomDomMedico = valorCtrl("txtNomDomMedico");
                /*105*/var txtNHospital = valorCtrl("txtNHospital");
                /*106*/var txt1Nombre = valorCtrl("txt1Nombre");
                /*107*/var txt1Domicilio = valorCtrl("txt1Domicilio");
                /*108*/var txt1Telefono = valorCtrl("txt1Telefono");
                /*109*/var txt2Nombre = valorCtrl("txt2Nombre");
                /*110*/var txt2Domicilio = valorCtrl("txt2Domicilio");
                /*111*/var txt2Telefono = valorCtrl("txt2Telefono");
                /*112*/var txtTiempoConocer = valorCtrl("txtTiempoConocer");
                /*113*/var txtCapitalEstimado = valorCtrl("txtCapitalEstimado");
                /*114*/var txtRiesgoPeligroso = valorCtrl("txtRiesgoPeligroso");
                /*115*/var txtSaludRiesgo = valorCtrl("txtSaludRiesgo");
                /*116*/var txtIngresos = valorCtrl("txtIngresos");

                /*117*/if (document.getElementById("chkSaludSi").checked) {
                    var chkSaludSi = "Yes";
                }

                /*117*/if (document.getElementById("chkSaludNo").checked) {
                    var chkSaludNo = "Yes";
                }

                /*118*/if (document.getElementById("chkFirmoSi").checked) {
                    var chkFirmoSi = "Yes";
                }

                /*118*/if (document.getElementById("chkFirmoNo").checked) {
                    var chkFirmoNo = "Yes";
                }
            }

            /*119*/var txtTelAgt = valorCtrl("txtTelefonoAgt");
            /*120*/var txtMailAgt = valorCtrl("txtMailAgt");
            /*121*/var txt1Agente = valorCtrl("txt1Agente");
            /*122*/var txt1CveAg = valorCtrl("txt1CveAg");
            /*123*/var txt1Porcentaje = valorCtrl("txt1Porcentaje");
            /*124*/var txt2Agente = valorCtrl("txt2Agente");
            /*125*/var txt2CveAg = valorCtrl("txt2CveAg");
            /*126*/var txt2Porcentaje = valorCtrl("txt2Porcentaje");
            /*127*/var txt3Agente = valorCtrl("txt3Agente");
            /*128*/var txt3CveAg = valorCtrl("txt3CveAg");
            /*129*/var txt3Porcentaje = valorCtrl("txt3Porcentaje");

            //////////////////////////////////////////////////////////////////////////////////////////
            /*ENFERMEDADES RESPIRATORIAS*/

            var version = document.getElementById('gvCuestionario').dataset.version;

            if (version == '1') {

                /*1*/if (document.getElementById("chkSi14").checked) {
                    var chkSi14 = "Yes";
                }

                /*1*/if (document.getElementById("chkNo14").checked) {
                    var chkNo14 = "Yes";
                }

                /*2*/if (document.getElementById("chkSi15").checked) {
                    var chkSi15 = "Yes";
                }

                /*2*/if (document.getElementById("chkNo15").checked) {
                    var chkNo15 = "Yes";
                }

                /*3*/if (document.getElementById("chkSi16").checked) {
                    var chkSi16 = "Yes";
                }

                /*3*/if (document.getElementById("chkNo16").checked) {
                    var chkNo16 = "Yes";
                }

                /*4*/if (document.getElementById("chkSi17").checked) {
                    var chkSi17 = "Yes";
                }

                /*4*/if (document.getElementById("chkNo17").checked) {
                    var chkNo17 = "Yes";
                }

                /*5*/if (document.getElementById("chkSi18").checked) {
                    var chkSi18 = "Yes";
                }

                /*5*/if (document.getElementById("chkNo18").checked) {
                    var chkNo18 = "Yes";
                }

                /*6*/if (document.getElementById("chkSi19").checked) {
                    var chkSi19 = "Yes";
                }

                /*6*/if (document.getElementById("chkNo19").checked) {
                    var chkNo19 = "Yes";
                }

            }

            if (version == '2') {
                 /*1*/if (document.getElementById("chkSi14").checked) {
                    var chkSi14 = "Yes";
                }

                /*1*/if (document.getElementById("chkNo14").checked) {
                    var chkNo14 = "Yes";
                }

                /*1*/ var txt14 = valorCtrl('txt14');

                /*2*/if (document.getElementById("chkSi15").checked) {
                    var chkSi15 = "Yes";
                }

                /*2*/if (document.getElementById("chkNo15").checked) {
                    var chkNo15 = "Yes";
                }


                 /*2*/ var txt15 = valorCtrl('txt15');



                /*3*/if (document.getElementById("chkSi16").checked) {
                    var chkSi16 = "Yes";
                }

                /*3*/if (document.getElementById("chkNo16").checked) {
                    var chkNo16 = "Yes";
                }

                /*3*/if (document.getElementById("chk16a").checked) {
                    var chk16a = "Yes";
                }
                /*3*/if (document.getElementById("chk16b").checked) {
                    var chk16b = "Yes";
                }
                /*3*/if (document.getElementById("chk16c").checked) {
                    var chk16c = "Yes";
                }
                /*3*/if (document.getElementById("chk16d").checked) {
                    var chk16d = "Yes";
                }
                /*3*/if (document.getElementById("chk16e").checked) {
                    var chk16e = "Yes";
                }
                /*3*/if (document.getElementById("chk16f").checked) {
                    var chk16f = "Yes";
                }
                /*3*/if (document.getElementById("chk16g").checked) {
                    var chk16g = "Yes";
                }
                /*3*/if (document.getElementById("chk16h").checked) {
                    var chk16h = "Yes";
                }



                /*4*/if (document.getElementById("chkSi17").checked) {
                    var chkSi17 = "Yes";
                }

                /*4*/if (document.getElementById("chkNo17").checked) {
                    var chkNo17 = "Yes";
                }

                /*4*/ var txt17a = valorCtrl('txt17a');
                /*4*/ var txt17b = valorCtrl('txt17b');


                /*5*/if (document.getElementById("chkSi18").checked) {
                    var chkSi18 = "Yes";
                }

                /*5*/if (document.getElementById("chkNo18").checked) {
                    var chkNo18 = "Yes";
                }

                /*4*/ var txt18a = valorCtrl('txt18a');
                /*4*/ var txt18b = valorCtrl('txt18b');
                /*4*/ var txt18c = valorCtrl('txt18c');



                /*6*/if (document.getElementById("chkSi19").checked) {
                    var chkSi19 = "Yes";
                }

                /*6*/if (document.getElementById("chkNo19").checked) {
                    var chkNo19 = "Yes";
                }

                /*6*/ var txt19a = valorCtrl('txt19a');
                /*6*/ var txt19b = valorCtrl('txt19b');



                /*7*/if (document.getElementById("chkSi20").checked) {
                    var chkSi20 = "Yes";
                }

                /*7*/if (document.getElementById("chkNo20").checked) {
                    var chkNo20 = "Yes";
                }


                /*7*/ var txt20a = valorCtrl('txt20a');
                /*7*/ var txt20b = valorCtrl('txt20b');
                /*7*/ var txt20c = valorCtrl('txt20c');


                /*8*/if (document.getElementById("chkSi21").checked) {
                    var chkSi21 = "Yes";
                }

                /*8*/if (document.getElementById("chkNo21").checked) {
                    var chkNo21 = "Yes";
                }

                /*8*/ var txt21 = valorCtrl('txt21');



                /*9*/if (document.getElementById("chkSi22").checked) {
                    var chkSi22 = "Yes";
                }

                /*9*/if (document.getElementById("chkNo22").checked) {
                    var chkNo22 = "Yes";
                }

                /*9*/ var txt22a = valorCtrl('txt22a');
                /*9*/ var txt22b = valorCtrl('txt22b');
                /*9*/ var txt22c = valorCtrl('txt22c');



                /*10*/if (document.getElementById("chkSi23").checked) {
                    var chkSi23 = "Yes";
                }

                /*10*/if (document.getElementById("chkNo23").checked) {
                    var chkNo23 = "Yes";
                }

                /*10*/ var txt23a = valorCtrl('txt23a');
                /*10*/ var txt23b = valorCtrl('txt23b');
                /*10*/ var txt23c = valorCtrl('txt23c');
                /*10*/ var txt23d = valorCtrl('txt23d');



                 /*11*/if (document.getElementById("chkSi24").checked) {
                    var chkSi24 = "Yes";
                }

                /*11*/if (document.getElementById("chkNo24").checked) {
                    var chkNo24 = "Yes";
                }

                /*11*/ var txt24a = valorCtrl('txt24a');
                /*11*/ var txt24b = valorCtrl('txt24b');


                /*12*/if (document.getElementById("chkSi25").checked) {
                    var chkSi25 = "Yes";
                }

                /*12*/if (document.getElementById("chkNo25").checked) {
                    var chkNo25 = "Yes";
                }



                /*12*/ var txt25a = formatDate(valorCtrl('txt25a'));
                /*12*/ var txt25b = formatDate(valorCtrl('txt25b'));
                /*12*/ var txt25c = valorCtrl('txt25c');


                /*13*/if (document.getElementById("chkSi26").checked) {
                    var chkSi26 = "Yes";
                }

                /*13*/if (document.getElementById("chkNo26").checked) {
                    var chkNo26 = "Yes";
                }
                // NOMBRE DE ASEGURADO TENDRA QUE SER EL TITULAR Y MANCOMUNADO
                var nombreCompletoContratante = valorCtrl("UscContCLM_lblNombre") + " " + valorCtrl("UscContCLM_lblApellidoPaterno") + " " + valorCtrl("UscContCLM_lblApellidoMaterno");
                var nombreCompletoAsegurado = valorCtrl("UscAsegCLM_lblNombre") + " " + valorCtrl("UscAsegCLM_lblApellidoPaterno") + " " + valorCtrl("UscAsegCLM_lblApellidoMaterno");
            }

            if (document.getElementById("divCuestionarioMillon").innerHTML != "") {
                var param = {
                    'emailId': token,
                    'age': agente,
                    'numCotizacion': numCotizacion,
                    'ramo': ramo,
                    'cuestionarioMillon': cuestionarioMillon,
                    ////////////////////////////////////////////////////////////////////////////////////////////////
                    /*PARAMETROS SOLICITUD VIDA*/
                    'CLM_Contratante': CLM_Contratante,
                    'CLM_Asegurado': CLM_Asegurado,
                    'EsMoral': EsMoral,
                    'AseguradoEsContratante': AseguradoEsContratante,
                    'txtRelacionSolicitantePersonaFisica': txtRelacionSolicitantePersonaFisica,
                    'chkRechazadoSi': chkRechazadoSi,
                    'txtParentescoDos': txtParentescoDos,
                    'txtCodigoCiudadSolicitante': txtCodigoCiudadSolicitante,
                    'chkCagoPublicoNoSolicitante': chkCagoPublicoNoSolicitante,
                    'txtDuracionUno': txtDuracionUno,
                    'chkInsuficienciaRenalNo': chkInsuficienciaRenalNo,
                    'chkCorazonSi': chkCorazonSi,
                    'chkFinalidadSeguroPatrimonial': chkFinalidadSeguroPatrimonial,
                    'txtNoInteriorSolicitante': txtNoInteriorSolicitante,
                    'txtPaisLugarNacimientoPersonaFisica': txtPaisLugarNacimientoPersonaFisica,
                    'txtEa': txtEa,
                    'txtOberservacionesDos': txtOberservacionesDos,
                    'txtPlan': txtPlan,
                    'txtPolizaUno': txtPolizaUno,
                    'txtFolioUno': txtFolioUno,
                    'txtFolioTres': txtFolioTres,
                    'chkEndocrinasNo': chkEndocrinasNo,
                    'txtBeneficiariosNombreCompletoUno': txtBeneficiariosNombreCompletoUno,
                    'txtDomicilioCompletoDos': txtDomicilioCompletoDos,
                    'txtEspecificacionCompañiaSumaAseguradaMonedaPlan': txtEspecificacionCompañiaSumaAseguradaMonedaPlan,
                    'chkMancomunado': chkMancomunado,
                    'chkBefSi': chkBefSi,
                    'txtEspecifiquePersonaFIsica': txtEspecifiquePersonaFIsica,
                    'chkBeneficiarioNo': chkBeneficiarioNo,
                    'txtFechaNacimientoUno': txtFechaNacimientoUno,
                    'txtTelefonoContratante': txtTelefonoContratante,
                    'txtNoInteriorContratante': txtNoInteriorContratante,
                    'txtMotivo': txtMotivo,
                    'txtFechaNacimientoPersonaFisica': txtFechaNacimientoPersonaFisica,
                    'txtFechaConstitucion': txtFechaConstitucion,
                    'chkSolicitanteNo': chkSolicitanteNo,
                    'chkCerebroVasculadresNo': chkCerebroVasculadresNo,
                    'chkCrecimientoGeometrico': chkCrecimientoGeometrico,
                    'txtTipoNumeroEmisorIdentidadOficialSolicitante': txtTipoNumeroEmisorIdentidadOficialSolicitante,
                    'txtCurpSolicitante': txtCurpSolicitante,
                    'txtPadecimientoTres': txtPadecimientoTres,
                    'txtOberservacionesTres': txtOberservacionesTres,
                    'chkMonedaNacional': chkMonedaNacional,
                    'chkFinalidadSeguroCredito': chkFinalidadSeguroCredito,
                    'txtCorreoElectronicoPersonaFisica': txtCorreoElectronicoPersonaFisica,
                    'txtFolioCinco': txtFolioCinco,
                    'txtPaisResidenciaFiscalContratante': txtPaisResidenciaFiscalContratante,
                    'txtNombreCompletoApoderadoLegal': txtNombreCompletoApoderadoLegal,
                    'chkFormaPagoSemestral': chkFormaPagoSemestral,
                    'chkCorazonNo': chkCorazonNo,
                    'txtOcupacionProfesionPersonaFisica': txtOcupacionProfesionPersonaFisica,
                    'txtNombreFirmaSolicitante': txtNombreFirmaSolicitante,
                    'chkAparatoDigestivoSi': chkAparatoDigestivoSi,
                    'txtPolizaNueve': txtPolizaNueve,
                    'txtOcupacionSolicitante': txtOcupacionSolicitante,
                    'txtVigenciaSolicitante': txtVigenciaSolicitante,
                    'txtFolioDiez': txtFolioDiez,
                    'chkFormaPagoTrimestral': chkFormaPagoTrimestral,
                    'txtFolioTrece': txtFolioTrece,
                    'txtMoneda': txtMoneda,
                    'txtNacionPersFis': txtNacionPersFis,
                    'chkAccidenteMac': chkAccidenteMac,
                    'chkHipertesionArterialSi': chkHipertesionArterialSi,
                    'chkConductoCobroTransferenciaBancaria': chkConductoCobroTransferenciaBancaria,
                    'chkFumaNoSolicitante': chkFumaNoSolicitante,
                    'txtSumaAseguradaInvalidez': txtSumaAseguradaInvalidez,
                    'chkSolicitanteSi': chkSolicitanteSi,
                    'txtFolioNueve': txtFolioNueve,
                    'chkServiciosFunerariosSI': chkServiciosFunerariosSI,
                    'chkSidaNo': chkSidaNo,
                    'txtDuracionTres': txtDuracionTres,
                    'txtRfcPersonaFisica': txtRfcPersonaFisica,
                    'chkConductoCobroEfectivo': chkConductoCobroEfectivo,
                    'txtClaveAgente': txtClaveAgente,
                    'chkSexoMasculinoSolicitante': chkSexoMasculinoSolicitante,
                    'txtRelacionSolicitante': txtRelacionSolicitante,
                    'txtPolizaOnce': txtPolizaOnce,
                    'chkSangreSi': chkSangreSi,
                    'chkCargoFuncionPublicaSi': chkCargoFuncionPublicaSi,
                    'chkAccidentePo': chkAccidentePo,
                    'chkPsiquiatricasNerviosasNo': chkPsiquiatricasNerviosasNo,
                    'txtOrdenesTransferenciaPermanentesContratante': txtOrdenesTransferenciaPermanentesContratante,
                    'chkContratanteSi': chkContratanteSi,
                    'txtTipoNumeroEmisorIdentificacionOficialPersonaFisica': txtTipoNumeroEmisorIdentificacionOficialPersonaFisica,
                    'chkConductoCobroAgente': chkConductoCobroAgente,
                    'chkAccidentePoc': chkAccidentePoc,
                    'chkFormaPagoUnico': chkFormaPagoUnico,
                    'txtFechaNacimientoDos': txtFechaNacimientoDos,
                    'txtSumaAseguradaBasica': txtSumaAseguradaBasica,
                    'txtIngresoMensualSolicitante': txtIngresoMensualSolicitante,
                    'txtComisionAgente': txtComisionAgente,
                    'txtFechaNacimientoSolicitante': txtFechaNacimientoSolicitante,
                    'chkPulmonaresRespiratoriasNo': chkPulmonaresRespiratoriasNo,
                    'chkNivelada': chkNivelada,
                    'chkCargoFuncionPublicaNo': chkCargoFuncionPublicaNo,
                    'txtPolizaDos': txtPolizaDos,
                    'txtPorcentajeDos': txtPorcentajeDos,
                    'chkSolicitudSi': chkSolicitudSi,
                    'txtCrecimiento': txtCrecimiento,
                    'txtFechaInicioTres': txtFechaInicioTres,
                    'chkFinalidadSeguroSocios': chkFinalidadSeguroSocios,
                    'txtPreguntaUno': txtPreguntaUno,
                    'txtOberservacionesUno': txtOberservacionesUno,
                    'txtnNumSerieFirmElectr': txtnNumSerieFirmElectr,
                    'txtPolizaCinco': txtPolizaCinco,
                    'chkEnfermedadesGravesNo': chkEnfermedadesGravesNo,
                    'txtGiroTelefonoEmpresaSolicitante': txtGiroTelefonoEmpresaSolicitante,
                    'txtColoniaSolicitante': txtColoniaSolicitante,
                    'txtEstadoProvinciaContratante': txtEstadoProvinciaContratante,
                    'chkConsumoDrogasNo': chkConsumoDrogasNo,
                    'txtFechaInicioDos': txtFechaInicioDos,
                    'txtMunicipioDelegacionContratante': txtMunicipioDelegacionContratante,
                    'txtPolizaDiez': txtPolizaDiez,
                    'txtFolioSiete': txtFolioSiete,
                    'txtRfcPersonaMoral': txtRfcPersonaMoral,
                    'txtTelefonoSolicitante': txtTelefonoSolicitante,
                    'txtFolioDoce': txtFolioDoce,
                    'chkAccidenteMapoc': chkAccidenteMapoc,
                    'txtPolizaCuatro': txtPolizaCuatro,
                    'txtPaisRecidenciaFiscalSolicitante': txtPaisRecidenciaFiscalSolicitante,
                    'txtPeso': txtPeso,
                    'txtNacionalidadesSolicitante': txtNacionalidadesSolicitante,
                    'txtFolioMercantil': txtFolioMercantil,
                    'txtNombreFirmaContratante': txtNombreFirmaContratante,
                    'chkCirrosisHeptitisNo': chkCirrosisHeptitisNo,
                    'txtPolizaSeis': txtPolizaSeis,
                    'chkCrebroVasculadresSI': chkCrebroVasculadresSI,
                    'txtPorcentajeUno': txtPorcentajeUno,
                    'txtCanFumaSol': txtCanFumaSol,
                    'txtCalleSolicitante': txtCalleSolicitante,
                    'txtNombrePaternoMaternoSolicitante': txtNombrePaternoMaternoSolicitante,
                    'txtVigenciaPersonaFisica': txtVigenciaPersonaFisica,
                    'txtEstadoProvinciaSolicitante': txtEstadoProvinciaSolicitante,
                    'txtPadecimientoUno': txtPadecimientoUno,
                    'chkBipa': chkBipa,
                    'chkEnfermedadMencionadaNo': chkEnfermedadMencionadaNo,
                    'chkDecreciente': chkDecreciente,
                    'txtDomicilioCompletoTres': txtDomicilioCompletoTres,
                    'chkBita': chkBita,
                    'chkFumaSiSolicitante': chkFumaSiSolicitante,
                    'txtNombreAgente': txtNombreAgente,
                    'txtPolizaSiete': txtPolizaSiete,
                    'txtCpPoboxSolicitante': txtCpPoboxSolicitante,
                    'txtNumeroSerieFIrmaElectronicaAvanzadaPersonaFisica': txtNumeroSerieFIrmaElectronicaAvanzadaPersonaFisica,
                    'txtMunicipioDelegacionSolicitante': txtMunicipioDelegacionSolicitante,
                    'chkFormaPagoMensual': chkFormaPagoMensual,
                    'txtNoExteriorContratante': txtNoExteriorContratante,
                    'chkAccidenteMa': chkAccidenteMa,
                    'txtDomicilioCompletoUno': txtDomicilioCompletoUno,
                    'chkServiciosFunerariosNo': chkServiciosFunerariosNo,
                    'txtCualDeporte': txtCualDeporte,
                    'chkBeneficiarioSi': chkBeneficiarioSi,
                    'txtNombrePaternoMaternoPersonaFisica': txtNombrePaternoMaternoPersonaFisica,
                    'txtEstadoActualUno': txtEstadoActualUno,
                    'txtFolioSeis': txtFolioSeis,
                    'chkFinalidadSeguroRetiro': chkFinalidadSeguroRetiro,
                    'txtPreguntaTres': txtPreguntaTres,
                    'txtGiroNegocioPersonaFisica': txtGiroNegocioPersonaFisica,
                    'txtCiudadPoblacionContratente': txtCiudadPoblacionContratente,
                    'chkBefNO': chkBefNO,
                    'txtParentescoUno': txtParentescoUno,
                    'txtEstadoActualTres': txtEstadoActualTres,
                    'txtEstadoCivilSolicitante': txtEstadoCivilSolicitante,
                    'txtBeneficiariosNombreCompletoTres': txtBeneficiariosNombreCompletoTres,
                    'txtFolioOcho': txtFolioOcho,
                    'txtFechaNacimientoTres': txtFechaNacimientoTres,
                    'txtCiudadPoblacionSolicitante': txtCiudadPoblacionSolicitante,
                    'txtMedioEntrega': txtMedioEntrega,
                    'chkartritisNo': chkartritisNo,
                    'chkFinalidadSeguroHombreClave': chkFinalidadSeguroHombreClave,
                    'txtBeneficiariosNombreCompletoDos': txtBeneficiariosNombreCompletoDos,
                    'txtPaisLugarNacimientoSolicitante': txtPaisLugarNacimientoSolicitante,
                    'chkFinalidadSeguroEducacion': chkFinalidadSeguroEducacion,
                    'txtNacionalidadApoderado': txtNacionalidadApoderado,
                    'txtFirmaAgente': txtFirmaAgente,
                    'chkPulmonaresRespiratoriasSi': chkPulmonaresRespiratoriasSi,
                    'chkEndocrinasSI': chkEndocrinasSI,
                    'txtColoniaContratente': txtColoniaContratente,
                    'txtCalleContratente': txtCalleContratente,
                    'chkFormaPagoQuincenal': chkFormaPagoQuincenal,
                    'chkSexoFemeninoSolicitante': chkSexoFemeninoSolicitante,
                    'txtFolioOnce': txtFolioOnce,
                    'txtPlazo': txtPlazo,
                    'txtCorreoElectronicoSolicitante': txtCorreoElectronicoSolicitante,
                    'txtCurpPersonaFIsica': txtCurpPersonaFIsica,
                    'txtClavePaisContratante': txtClavePaisContratante,
                    'txtPolizaOcho': txtPolizaOcho,
                    'txtClavePaisSolicitante': txtClavePaisSolicitante,
                    'chkMonedaDolares': chkMonedaDolares,
                    'chkCrecimientoConstante': chkCrecimientoConstante,
                    'txtSumaAseguradaPlanSuperacionPlus': txtSumaAseguradaPlanSuperacionPlus,
                    'txtEspecifiqueSolicitante': txtEspecifiqueSolicitante,
                    'chkPsiquiatricasNerviosasSi': chkPsiquiatricasNerviosasSi,
                    'txtCorreoElectrPagWeb': txtCorreoElectrPagWeb,
                    'chkRechazadoNo': chkRechazadoNo,
                    'chkDeportePeligrosoNo': chkDeportePeligrosoNo,
                    'txtSumaAseguradaAccidente': txtSumaAseguradaAccidente,
                    'txtEspecificarCargoSolicitante': txtEspecificarCargoSolicitante,
                    'txtCodigoPaisContratante': txtCodigoPaisContratante,
                    'chkSangreNo': chkSangreNo,
                    'txtCpPoboxContratante': txtCpPoboxContratante,
                    'chkTemporalIndividual': chkTemporalIndividual,
                    'chkMonedaUdis': chkMonedaUdis,
                    'txtFolioCuatro': txtFolioCuatro,
                    'txtNumeroSerieFimaElectronicaAvanzadaSolicitante': txtNumeroSerieFimaElectronicaAvanzadaSolicitante,
                    'txtPolizaDoce': txtPolizaDoce,
                    'chkHipertensionArterialNo': chkHipertensionArterialNo,
                    'txtTinNifEquivalenteSolicitante': txtTinNifEquivalenteSolicitante,
                    'chkAparatoDigestivoNo': chkAparatoDigestivoNo,
                    'txtTinNifPersonaFisica': txtTinNifPersonaFisica,
                    'chkInsuficienciaRenalSi': chkInsuficienciaRenalSi,
                    'chkDeportePeligrosoSi': chkDeportePeligrosoSi,
                    'txtDomicApoderadoLegal': txtDomicApoderadoLegal,
                    'txtrazonSocial': txtrazonSocial,
                    'chkSidaSI': chkSidaSI,
                    'chkCargoPublicoSiSolicitante': chkCargoPublicoSiSolicitante,
                    'txtPolizaTrece': txtPolizaTrece,
                    'txtParentescoTres': txtParentescoTres,
                    'chkEnfermedadesGravesSi': chkEnfermedadesGravesSi,
                    'txtFolioDos': txtFolioDos,
                    'chkBit': chkBit,
                    'chkConsumoDrogasSI': chkConsumoDrogasSI,
                    'txtRfcSolicitante': txtRfcSolicitante,
                    'txtEstatura': txtEstatura,
                    'txtPaisContratante': txtPaisContratante,
                    'chkFormaPagoSemanal': chkFormaPagoSemanal,
                    'txtDuracionDos': txtDuracionDos,
                    'txtNoExteriorSolicitante': txtNoExteriorSolicitante,
                    'chkFormaPagoContado': chkFormaPagoContado,
                    'chkCrecimientoLineal': chkCrecimientoLineal,
                    'txtEspecifiqueCargoPersonaFisica': txtEspecifiqueCargoPersonaFisica,
                    'chkArtritisSI': chkArtritisSI,
                    'txtGiroMercantilObjSocial': txtGiroMercantilObjSocial,
                    'chkCirrosisHeptitisSi': chkCirrosisHeptitisSi,
                    'txtPolizaTres': txtPolizaTres,
                    'chkEnfermedadMencionadaSi': chkEnfermedadMencionadaSi,
                    'chkPasi': chkPasi,
                    'txtPadecimientoDos': txtPadecimientoDos,
                    'txtPreguntaDos': txtPreguntaDos,
                    'txtEmpresaPrestaServicioSolicitante': txtEmpresaPrestaServicioSolicitante,
                    'chkConductoCobroDomiciliado': chkConductoCobroDomiciliado,
                    'txtNacionalidad': txtNacionalidad,
                    'txtFechaInicioUno': txtFechaInicioUno,
                    'chkSolicitudNo': chkSolicitudNo,
                    'txtEstadoActualDos': txtEstadoActualDos,
                    'chkContratanteNo': chkContratanteNo,
                    'chkAccidenteMapo': chkAccidenteMapo,
                    'txtPorcentajeTres': txtPorcentajeTres,


                    ////////////////////////////////////////////////////////////////////////////////////////////////
                    /*PARAMETROS CUESTIONARIO MAYOR A 1.5 MDP*/

                    'txtSAGiroEmpresa': txtGiro,
                    'txtSATelefono': txtTelefono,
                    'txtSAClavePais': txtCvePais,
                    'txtSACodCiudad': txtCodCiudad,
                    'txtSASustancias': txtTipoMaquinas,
                    'chkSAOcupacionSi': chkSiOtraOcupacion,
                    'chkSAOcupacionNo': chkNoOtraOcupacion,
                    'txtSAOcupacion': txtOtraOcupacion,
                    'chkSAReqViajarSi': chkSiViajar,
                    'chkSAReqViajarNo': chkNoViajar,
                    'txtSATipoTransporte': txtTipoTransporte,
                    'chkSAAeroPartSi': chkSiAParticular,
                    'chkSAAeroPartNo': chkNoAParticular,
                    'txtSAAeronaveHoras': txtTipoAeronave,
                    'chkSAUsarMotoSi': chkSiMotocicleta,
                    'chkSAUsarMotoNo': chkNoMotocicleta,
                    'txtSAFrecuenciaMoto': txtFMotocicleta,
                    'chkSATraAltSi': chkSiAlturas,
                    'chkSATraAltNo': chkNoAlturas,
                    'txtSAAlturaTrabajo': txtAlturas,
                    'chkSAProfe': chkDProfesional,
                    'chkSAAfici': chkDAficionado,
                    'chkSAAmat': chkDAmateur,
                    'chkSACubRiesDepoSi': chkSiRiesgo,
                    'chkSACubRiesDepoNo': chkNoRiesgo,
                    'txtSANumCopas': txtCantCopas,
                    'txtSAFrecAlcohol': txtFrecuenciaBebida,
                    'chkSACigarros': chkCigarros,
                    'chkSAPuro': chkPuro,
                    'chkSAPipa': chkPipa,
                    'txtSANumCigarros': txtCantFumar,
                    'txtSAFrecFumar': txtFrecuenciaFumar,
                    'txtSATipoFrecDrogas': txtTipoDroga,
                    'txtSAFrecDrogas': txtFrecuenciaDroga,
                    'txtSAd1IniAlcohol': chrDd1Bebida,
                    'txtSAd2IniAlcohol': chrDd2Bebida,
                    'txtSAm1IniAlcohol': chrMm1Bebida,
                    'txtSAm2IniAlcohol': chrMm2Bebida,
                    'txtSAa1IniAlcohol': chrYy1Bebida,
                    'txtSAa2IniAlcohol': chrYy2Bebida,

                    'txtSAd1FinAlcohol': chrDd1BebidaF,
                    'txtSAd2FinAlcohol': chrDd2BebidaF,
                    'txtSAm1FinAlcohol': chrMm1BebidaF,
                    'txtSAm2FinAlcohol': chrMm2BebidaF,
                    'txtSAa1FinAlcohol': chrYy1BebidaF,
                    'txtSAa2FinAlcohol': chrYy2BebidaF,

                    'txtSAMotAlcohol': txtMotivoBebida,

                    'txtSAd1IniFumar': chrDd1Fumar,
                    'txtSAd2IniFumar': chrDd2Fumar,
                    'txtSAm1IniFumar': chrMm1Fumar,
                    'txtSAm2IniFumar': chrMm2Fumar,
                    'txtSAa1IniFumar': chrYy1Fumar,
                    'txtSAa2IniFumar': chrYy2Fumar,

                    'txtSAd1FinFumar': chrDd1FumarF,
                    'txtSAd2FinFumar': chrDd2FumarF,
                    'txtSAm1FinFumar': chrMm1FumarF,
                    'txtSAm2FinFumar': chrMm2FumarF,
                    'txtSAa1FinFumar': chrYy1FumarF,
                    'txtSAa2FinFumar': chrYy2FumarF,

                    'txtSAMotFumar': txtMotivoFumar,

                    'txtSAd1IniDroga': chrDd1Droga,
                    'txtSAd2IniDroga': chrDd2Droga,
                    'txtSAm1IniDroga': chrMm1Droga,
                    'txtSAm2IniDroga': chrMm2Droga,
                    'txtSAa1IniDroga': chrYy1Droga,
                    'txtSAa2IniDroga': chrYy2Droga,

                    'txtSAd1FinDroga': chrDd1DrogaF,
                    'txtSAd2FinDroga': chrDd2DrogaF,
                    'txtSAm1FinDroga': chrMm1DrogaF,
                    'txtSAm2FinDroga': chrMm2DrogaF,
                    'txtSAa1FinDroga': chrYy1DrogaF,
                    'txtSAa2FinDroga': chrYy2DrogaF,

                    'txtSAMotDrogas': txtMotivoDroga,
                    'txtSAEdadMadre': txtEdadMadre,
                    'txtSAEdoSAlMadre': txtEdoSaludMadre,
                    'txtSAViveMadre': txtViveMadre,
                    'txtSAEdadFalleMadre': txtEdadMuerteMadre,
                    'txtSACausasMadre': txtMotivosMadre,
                    'txtSAEdadPadre': txtEdadPadre,
                    'txtSAEdoSAlPadre': txtEdoSaludPadre,
                    'txtSAVivePadre': txtVivePadre,
                    'txtSAEdadFallePadre': txtEdadMuertePadre,
                    'txtSACausasPadre': txtMotivosPadre,
                    'txtSAEdadHnos': txtEdadHermanos,
                    'txtSAEdoSAlHnos': txtEdoSaludHermanos,
                    'txtSAViveHnos': txtViveHermanos,
                    'txtSAEdadFalleHnos': txtEdadMuerteHermanos,
                    'txtSACausasHnos': txtMotivosHermanos,
                    'txtSAEdadHijos': txtEdadHijos,
                    'txtSAEdoSAlHijos': txtEdoSaludHijos,
                    'txtSAViveHijos': txtViveHijos,
                    'txtSAEdadFalleHijos': txtEdadMuerteHijos,
                    'txtSACausasHijos': txtMotivosHijos,
                    'txtSAQuienCardiaca': txtQuienCardiaca,
                    'txtSAEvoCardiaca': txtEvolucionCardiaca,
                    'txtSAQuienCancer': txtQuienCancer,
                    'txtSAEvoCancer': txtEvolucionCancer,
                    'txtSAQuienPresion': txtQuienPresion,
                    'txtSAEvoPresion': txtEvolucionPresion,
                    'txtSAQuienDiabetes': txtQuienDiabetes,
                    'txtSAEvoDiabetes': txtEvolucionDiabetes,
                    'chkSACuest1Si': chk1Si,
                    'chkSACuest1No': chk1No,
                    'txtSACuestCausa1': txt1Causa,
                    'chkSACuest2Si': chk2Si,
                    'chkSACuest2No': chk2No,
                    'txtSACuestCausa2': txt2Causa,
                    'txtSACuestCuando2': txt2Cuando,
                    'chkSACuest3Si': chk3Si,
                    'chkSACuest3No': chk3No,
                    'txtSACuestCausa3': txt3Causa,
                    'txtSACuestCuando3': txt3Cuando,
                    'chkSACuest4Si': chk4Si,
                    'chkSACuest4No': chk4No,
                    'txtSACuestCausa4': txt4Causa,
                    'txtSACuestCuando4': txt4Cuando,
                    'chkSACuest5Si': chk5Si,
                    'chkSACuest5No': chk5No,
                    'txtSACuestKgAum': txtKgAumentados,
                    'txtSACuestKgDism': txtKgDisminuidos,
                    'chkSACuest6aSi': chk7Si,
                    'chkSACuest6aNo': chk7No,
                    'txtCuest6aCual': txt7Causa,
                    'chkSACuest6bSi': chk8Si,
                    'chkSACuest6bNo': chk8No,
                    'txtCuest6bCuant': txt8Meses,

                    'txtSAd1Papani': chrDd1Papani,//txtFPapanicolau[0],
                    'txtSAd2Papani': chrDd2Papani,//txtFPapanicolau[1],
                    'txtSAm1Papani': chrMm1Papani,//txtFPapanicolau[3],
                    'txtSAm2Papani': chrMm2Papani,//txtFPapanicolau[4],
                    'txtSAa1Papani': chrYy1Papani,//txtFPapanicolau[8],
                    'txtSAa2Papani': chrYy2Papani,//txtFPapanicolau[9],

                    'txtSAd1Mamo': chrDd1Mamo,//txtFMamografia[0],
                    'txtSAd2Mamo': chrDd2Mamo,//txtFMamografia[1],
                    'txtSAm1Mamo': chrMm1Mamo,//txtFMamografia[3],
                    'txtSAm2Mamo': chrMm2Mamo,//txtFMamografia[4],
                    'txtSAa1Mamo': chrYy1Mamo,//txtFMamografia[8],
                    'txtSAa2Mamo': chrYy2Mamo,//txtFMamografia[9],

                    'txtSACuest6c1Res': txtResPapanicolau,
                    'txtSACuest6c2Res': txtResMamografia,
                    'txtSANumPre1': txt1Pregunta,
                    'txtSAPade1': txt1Padecimiento,
                    'txtSAFecPade1': txt1FInicio,
                    'txtSAPadeDura1': txt1Duracion,
                    'txtSAPadeEdoAct1': txt1Estado,
                    'txtSANumPre2': txt2Pregunta,
                    'txtSAPade2': txt2Padecimiento,
                    'txtSAFecPade2': txt2FInicio,
                    'txtSAPadeDura2': txt2Duracion,
                    'txtSAPadeEdoAct2': txt2Estado,
                    'txtSANumPre3': txt3Pregunta,
                    'txtSAPade3': txt3Padecimiento,
                    'txtSAFecPade3': txt3FInicio,
                    'txtSAPadeDura3': txt3Duracion,
                    'txtSAPadeEdoAct3': txt3Estado,
                    'txtSANumPre4': txt4Pregunta,
                    'txtSAPade4': txt4Padecimiento,
                    'txtSAFecPade4': txt4FInicio,
                    'txtSAPadeDura4': txt4Duracion,
                    'txtSAPadeEdoAct4': txt4Estado,
                    'txtSANomDomiDr': txtNomDomMedico,
                    'txtSANomHosp': txtNHospital,
                    'txtSANomRef1': txt1Nombre,
                    'txtSADomRef1': txt1Domicilio,
                    'txtSATelRef1': txt1Telefono,
                    'txtSANomRef2': txt2Nombre,
                    'txtSADomRef2': txt2Domicilio,
                    'txtSATelRef2': txt2Telefono,
                    'txtSAInfAgt1': txtTiempoConocer,
                    'txtSAInfAgt2': txtCapitalEstimado,
                    'txtSAInfAgt3': txtRiesgoPeligroso,
                    'txtSAInfAgt4': txtSaludRiesgo,
                    'txtSAInfAgt6': txtIngresos,
                    'chkSAInfAgt7Si': chkSaludSi,
                    'chkSAInfAgt7No': chkSaludNo,
                    'chkSAInfAgt8Si': chkFirmoSi,
                    'chkSAInfAgt8No': chkFirmoNo,
                    'txtSATelAgt': txtTelAgt,
                    'txtSAEmailAgt': txtMailAgt,
                    'txtSANomAgt1': txt1Agente,
                    'txtSACVEAgt1': txt1CveAg,
                    'txtSAPctAgt1': txt1Porcentaje,
                    'txtSANomAgt2': txt2Agente,
                    'txtSACVEAgt2': txt2CveAg,
                    'txtSAPctAgt2': txt2Porcentaje,
                    'txtSANomAgt3': txt3Agente,
                    'txtSACVEAgt3': txt3CveAg,
                    'txtSAPctAgt3': txt3Porcentaje,
                    'txtSAOtroLugarTrabajo': txtOtroLugarTrabajo,
                    'chkSALugOfc': chkOficina,
                    'chkSALugFab': chkFabrica,
                    'chkSALugTal': chkTaller,
                    'chkSALugCal': chkCalle
                };

                ////////////////////////////////////////////////////////////////////////////////////////////////
                /*PARAMETROS CUESTIONARIO ENFERMEDADES RESPIRATORIAS*/
                if (version = '1') {
                    param.chkSiPregunta1 = chkSi14;
                    param.chkNoPregunta1 = chkNo14;

                    param.chkSiPregunta2 = chkSi15;
                    param.chkNoPregunta2 = chkNo15;

                    param.chkSiPregunta3 = chkSi16;
                    param.chkNoPregunta3 = chkNo16;

                    param.chkSiPregunta4 = chkSi17;
                    param.chkNoPregunta4 = chkNo17;

                    param.chkSiPregunta5 = chkSi18;
                    param.chkNoPregunta5 = chkNo18;

                    param.chkSiPregunta6 = chkSi19;
                    param.chkNoPregunta6 = chkNo19;

                    param.txtContratante = nombreCompletoContratante;
                    param.txtSolicitante = nombreCompletoAsegurado;

                }

                if (version = '2') {
                    param.chkSiPregunta1 = chkSi14;
                    param.chkNoPregunta1 = chkNo14;

                    param.chkSiPregunta2 = chkSi15;
                    param.chkNoPregunta2 = chkNo15;

                    param.chkSiPregunta3 = chkSi16;
                    param.chkNoPregunta3 = chkNo16;

                    param.chkSiPregunta4 = chkSi17;
                    param.chkNoPregunta4 = chkNo17;

                    param.chkSiPregunta5 = chkSi18;
                    param.chkNoPregunta5 = chkNo18;

                    param.chkSiPregunta5_1 = chkSi19;
                    param.chkNoPregunta5_1 = chkNo19;

                    param.chkSiPregunta6 = chkSi20
                    param.chkNoPregunta6 = chkNo20;

                    param.chkSiPregunta7 = chkSi21;
                    param.chkNoPregunta7 = chkNo21;

                    param.chkSiPregunta8 = chkSi22;
                    param.chkNoPregunta8 = chkNo22;

                    param.chkSiPregunta9 = chkSi23;
                    param.chkNoPregunta9 = chkNo23;

                    param.chkSiPregunta10 = chkSi24;
                    param.chkNoPregunta10 = chkNo24;


                    param.chkSiPregunta11 = chkSi25;
                    param.chkNoPregunta11 = chkNo25;
                    param.txtPregunta11a = txt25a;
                    param.txtPregunta11b = txt25b;
                    param.txtPregunta11c = txt25c;


                    param.chkSiPregunta12 = chkSi26;
                    param.chkNoPregunta12 = chkNo26;

                    param.txtContratante = nombreCompletoContratante;
                    param.txtSolicitante = nombreCompletoAsegurado;

                }

                param.version = version;


            }
            else {
                var param = {
                    'emailId': token,
                    'age': agente,
                    'numCotizacion': numCotizacion,
                    'ramo': ramo,
                    ////////////////////////////////////////////////////////////////////////////////////////////////
                    /*PARAMETROS SOLICITUD VIDA*/
                    'CLM_Contratante': CLM_Contratante,
                    'CLM_Asegurado': CLM_Asegurado,
                    'EsMoral': EsMoral,
                    'AseguradoEsContratante': AseguradoEsContratante,
                    'txtRelacionSolicitantePersonaFisica': txtRelacionSolicitantePersonaFisica,
                    'chkRechazadoSi': chkRechazadoSi,
                    'txtParentescoDos': txtParentescoDos,
                    'txtCodigoCiudadSolicitante': txtCodigoCiudadSolicitante,
                    'chkCagoPublicoNoSolicitante': chkCagoPublicoNoSolicitante,
                    'txtDuracionUno': txtDuracionUno,
                    'chkInsuficienciaRenalNo': chkInsuficienciaRenalNo,
                    'chkCorazonSi': chkCorazonSi,
                    'chkFinalidadSeguroPatrimonial': chkFinalidadSeguroPatrimonial,
                    'txtNoInteriorSolicitante': txtNoInteriorSolicitante,
                    'txtPaisLugarNacimientoPersonaFisica': txtPaisLugarNacimientoPersonaFisica,
                    'txtEa': txtEa,
                    'txtOberservacionesDos': txtOberservacionesDos,
                    'txtPlan': txtPlan,
                    'txtPolizaUno': txtPolizaUno,
                    'txtFolioUno': txtFolioUno,
                    'txtFolioTres': txtFolioTres,
                    'chkEndocrinasNo': chkEndocrinasNo,
                    'txtBeneficiariosNombreCompletoUno': txtBeneficiariosNombreCompletoUno,
                    'txtDomicilioCompletoDos': txtDomicilioCompletoDos,
                    'txtEspecificacionCompañiaSumaAseguradaMonedaPlan': txtEspecificacionCompañiaSumaAseguradaMonedaPlan,
                    'chkMancomunado': chkMancomunado,
                    'chkBefSi': chkBefSi,
                    'txtEspecifiquePersonaFIsica': txtEspecifiquePersonaFIsica,
                    'chkBeneficiarioNo': chkBeneficiarioNo,
                    'txtFechaNacimientoUno': txtFechaNacimientoUno,
                    'txtTelefonoContratante': txtTelefonoContratante,
                    'txtNoInteriorContratante': txtNoInteriorContratante,
                    'txtMotivo': txtMotivo,
                    'txtFechaNacimientoPersonaFisica': txtFechaNacimientoPersonaFisica,
                    'txtFechaConstitucion': txtFechaConstitucion,
                    'chkSolicitanteNo': chkSolicitanteNo,
                    'chkCerebroVasculadresNo': chkCerebroVasculadresNo,
                    'chkCrecimientoGeometrico': chkCrecimientoGeometrico,
                    'txtTipoNumeroEmisorIdentidadOficialSolicitante': txtTipoNumeroEmisorIdentidadOficialSolicitante,
                    'txtCurpSolicitante': txtCurpSolicitante,
                    'txtPadecimientoTres': txtPadecimientoTres,
                    'txtOberservacionesTres': txtOberservacionesTres,
                    'chkMonedaNacional': chkMonedaNacional,
                    'chkFinalidadSeguroCredito': chkFinalidadSeguroCredito,
                    'txtCorreoElectronicoPersonaFisica': txtCorreoElectronicoPersonaFisica,
                    'txtFolioCinco': txtFolioCinco,
                    'txtPaisResidenciaFiscalContratante': txtPaisResidenciaFiscalContratante,
                    'txtNombreCompletoApoderadoLegal': txtNombreCompletoApoderadoLegal,
                    'chkFormaPagoSemestral': chkFormaPagoSemestral,
                    'chkCorazonNo': chkCorazonNo,
                    'txtOcupacionProfesionPersonaFisica': txtOcupacionProfesionPersonaFisica,
                    'txtNombreFirmaSolicitante': txtNombreFirmaSolicitante,
                    'chkAparatoDigestivoSi': chkAparatoDigestivoSi,
                    'txtPolizaNueve': txtPolizaNueve,
                    'txtOcupacionSolicitante': txtOcupacionSolicitante,
                    'txtVigenciaSolicitante': txtVigenciaSolicitante,
                    'txtFolioDiez': txtFolioDiez,
                    'chkFormaPagoTrimestral': chkFormaPagoTrimestral,
                    'txtFolioTrece': txtFolioTrece,
                    'txtMoneda': txtMoneda,
                    'txtNacionPersFis': txtNacionPersFis,
                    'chkAccidenteMac': chkAccidenteMac,
                    'chkHipertesionArterialSi': chkHipertesionArterialSi,
                    'chkConductoCobroTransferenciaBancaria': chkConductoCobroTransferenciaBancaria,
                    'chkFumaNoSolicitante': chkFumaNoSolicitante,
                    'txtSumaAseguradaInvalidez': txtSumaAseguradaInvalidez,
                    'chkSolicitanteSi': chkSolicitanteSi,
                    'txtFolioNueve': txtFolioNueve,
                    'chkServiciosFunerariosSI': chkServiciosFunerariosSI,
                    'chkSidaNo': chkSidaNo,
                    'txtDuracionTres': txtDuracionTres,
                    'txtRfcPersonaFisica': txtRfcPersonaFisica,
                    'chkConductoCobroEfectivo': chkConductoCobroEfectivo,
                    'txtClaveAgente': txtClaveAgente,
                    'chkSexoMasculinoSolicitante': chkSexoMasculinoSolicitante,
                    'txtRelacionSolicitante': txtRelacionSolicitante,
                    'txtPolizaOnce': txtPolizaOnce,
                    'chkSangreSi': chkSangreSi,
                    'chkCargoFuncionPublicaSi': chkCargoFuncionPublicaSi,
                    'chkAccidentePo': chkAccidentePo,
                    'chkPsiquiatricasNerviosasNo': chkPsiquiatricasNerviosasNo,
                    'txtOrdenesTransferenciaPermanentesContratante': txtOrdenesTransferenciaPermanentesContratante,
                    'chkContratanteSi': chkContratanteSi,
                    'txtTipoNumeroEmisorIdentificacionOficialPersonaFisica': txtTipoNumeroEmisorIdentificacionOficialPersonaFisica,
                    'chkConductoCobroAgente': chkConductoCobroAgente,
                    'chkAccidentePoc': chkAccidentePoc,
                    'chkFormaPagoUnico': chkFormaPagoUnico,
                    'txtFechaNacimientoDos': txtFechaNacimientoDos,
                    'txtSumaAseguradaBasica': txtSumaAseguradaBasica,
                    'txtIngresoMensualSolicitante': txtIngresoMensualSolicitante,
                    'txtComisionAgente': txtComisionAgente,
                    'txtFechaNacimientoSolicitante': txtFechaNacimientoSolicitante,
                    'chkPulmonaresRespiratoriasNo': chkPulmonaresRespiratoriasNo,
                    'chkNivelada': chkNivelada,
                    'chkCargoFuncionPublicaNo': chkCargoFuncionPublicaNo,
                    'txtPolizaDos': txtPolizaDos,
                    'txtPorcentajeDos': txtPorcentajeDos,
                    'chkSolicitudSi': chkSolicitudSi,
                    'txtCrecimiento': txtCrecimiento,
                    'txtFechaInicioTres': txtFechaInicioTres,
                    'chkFinalidadSeguroSocios': chkFinalidadSeguroSocios,
                    'txtPreguntaUno': txtPreguntaUno,
                    'txtOberservacionesUno': txtOberservacionesUno,
                    'txtnNumSerieFirmElectr': txtnNumSerieFirmElectr,
                    'txtPolizaCinco': txtPolizaCinco,
                    'chkEnfermedadesGravesNo': chkEnfermedadesGravesNo,
                    'txtGiroTelefonoEmpresaSolicitante': txtGiroTelefonoEmpresaSolicitante,
                    'txtColoniaSolicitante': txtColoniaSolicitante,
                    'txtEstadoProvinciaContratante': txtEstadoProvinciaContratante,
                    'chkConsumoDrogasNo': chkConsumoDrogasNo,
                    'txtFechaInicioDos': txtFechaInicioDos,
                    'txtMunicipioDelegacionContratante': txtMunicipioDelegacionContratante,
                    'txtPolizaDiez': txtPolizaDiez,
                    'txtFolioSiete': txtFolioSiete,
                    'txtRfcPersonaMoral': txtRfcPersonaMoral,
                    'txtTelefonoSolicitante': txtTelefonoSolicitante,
                    'txtFolioDoce': txtFolioDoce,
                    'chkAccidenteMapoc': chkAccidenteMapoc,
                    'txtPolizaCuatro': txtPolizaCuatro,
                    'txtPaisRecidenciaFiscalSolicitante': txtPaisRecidenciaFiscalSolicitante,
                    'txtPeso': txtPeso,
                    'txtNacionalidadesSolicitante': txtNacionalidadesSolicitante,
                    'txtFolioMercantil': txtFolioMercantil,
                    'txtNombreFirmaContratante': txtNombreFirmaContratante,
                    'chkCirrosisHeptitisNo': chkCirrosisHeptitisNo,
                    'txtPolizaSeis': txtPolizaSeis,
                    'chkCrebroVasculadresSI': chkCrebroVasculadresSI,
                    'txtPorcentajeUno': txtPorcentajeUno,
                    'txtCanFumaSol': txtCanFumaSol,
                    'txtCalleSolicitante': txtCalleSolicitante,
                    'txtNombrePaternoMaternoSolicitante': txtNombrePaternoMaternoSolicitante,
                    'txtVigenciaPersonaFisica': txtVigenciaPersonaFisica,
                    'txtEstadoProvinciaSolicitante': txtEstadoProvinciaSolicitante,
                    'txtPadecimientoUno': txtPadecimientoUno,
                    'chkBipa': chkBipa,
                    'chkEnfermedadMencionadaNo': chkEnfermedadMencionadaNo,
                    'chkDecreciente': chkDecreciente,
                    'txtDomicilioCompletoTres': txtDomicilioCompletoTres,
                    'chkBita': chkBita,
                    'chkFumaSiSolicitante': chkFumaSiSolicitante,
                    'txtNombreAgente': txtNombreAgente,
                    'txtPolizaSiete': txtPolizaSiete,
                    'txtCpPoboxSolicitante': txtCpPoboxSolicitante,
                    'txtNumeroSerieFIrmaElectronicaAvanzadaPersonaFisica': txtNumeroSerieFIrmaElectronicaAvanzadaPersonaFisica,
                    'txtMunicipioDelegacionSolicitante': txtMunicipioDelegacionSolicitante,
                    'chkFormaPagoMensual': chkFormaPagoMensual,
                    'txtNoExteriorContratante': txtNoExteriorContratante,
                    'chkAccidenteMa': chkAccidenteMa,
                    'txtDomicilioCompletoUno': txtDomicilioCompletoUno,
                    'chkServiciosFunerariosNo': chkServiciosFunerariosNo,
                    'txtCualDeporte': txtCualDeporte,
                    'chkBeneficiarioSi': chkBeneficiarioSi,
                    'txtNombrePaternoMaternoPersonaFisica': txtNombrePaternoMaternoPersonaFisica,
                    'txtEstadoActualUno': txtEstadoActualUno,
                    'txtFolioSeis': txtFolioSeis,
                    'chkFinalidadSeguroRetiro': chkFinalidadSeguroRetiro,
                    'txtPreguntaTres': txtPreguntaTres,
                    'txtGiroNegocioPersonaFisica': txtGiroNegocioPersonaFisica,
                    'txtCiudadPoblacionContratente': txtCiudadPoblacionContratente,
                    'chkBefNO': chkBefNO,
                    'txtParentescoUno': txtParentescoUno,
                    'txtEstadoActualTres': txtEstadoActualTres,
                    'txtEstadoCivilSolicitante': txtEstadoCivilSolicitante,
                    'txtBeneficiariosNombreCompletoTres': txtBeneficiariosNombreCompletoTres,
                    'txtFolioOcho': txtFolioOcho,
                    'txtFechaNacimientoTres': txtFechaNacimientoTres,
                    'txtCiudadPoblacionSolicitante': txtCiudadPoblacionSolicitante,
                    'txtMedioEntrega': txtMedioEntrega,
                    'chkartritisNo': chkartritisNo,
                    'chkFinalidadSeguroHombreClave': chkFinalidadSeguroHombreClave,
                    'txtBeneficiariosNombreCompletoDos': txtBeneficiariosNombreCompletoDos,
                    'txtPaisLugarNacimientoSolicitante': txtPaisLugarNacimientoSolicitante,
                    'chkFinalidadSeguroEducacion': chkFinalidadSeguroEducacion,
                    'txtNacionalidadApoderado': txtNacionalidadApoderado,
                    'txtFirmaAgente': txtFirmaAgente,
                    'chkPulmonaresRespiratoriasSi': chkPulmonaresRespiratoriasSi,
                    'chkEndocrinasSI': chkEndocrinasSI,
                    'txtColoniaContratente': txtColoniaContratente,
                    'txtCalleContratente': txtCalleContratente,
                    'chkFormaPagoQuincenal': chkFormaPagoQuincenal,
                    'chkSexoFemeninoSolicitante': chkSexoFemeninoSolicitante,
                    'txtFolioOnce': txtFolioOnce,
                    'txtPlazo': txtPlazo,
                    'txtCorreoElectronicoSolicitante': txtCorreoElectronicoSolicitante,
                    'txtCurpPersonaFIsica': txtCurpPersonaFIsica,
                    'txtClavePaisContratante': txtClavePaisContratante,
                    'txtPolizaOcho': txtPolizaOcho,
                    'txtClavePaisSolicitante': txtClavePaisSolicitante,
                    'chkMonedaDolares': chkMonedaDolares,
                    'chkCrecimientoConstante': chkCrecimientoConstante,
                    'txtSumaAseguradaPlanSuperacionPlus': txtSumaAseguradaPlanSuperacionPlus,
                    'txtEspecifiqueSolicitante': txtEspecifiqueSolicitante,
                    'chkPsiquiatricasNerviosasSi': chkPsiquiatricasNerviosasSi,
                    'txtCorreoElectrPagWeb': txtCorreoElectrPagWeb,
                    'chkRechazadoNo': chkRechazadoNo,
                    'chkDeportePeligrosoNo': chkDeportePeligrosoNo,
                    'txtSumaAseguradaAccidente': txtSumaAseguradaAccidente,
                    'txtEspecificarCargoSolicitante': txtEspecificarCargoSolicitante,
                    'txtCodigoPaisContratante': txtCodigoPaisContratante,
                    'chkSangreNo': chkSangreNo,
                    'txtCpPoboxContratante': txtCpPoboxContratante,
                    'chkTemporalIndividual': chkTemporalIndividual,
                    'chkMonedaUdis': chkMonedaUdis,
                    'txtFolioCuatro': txtFolioCuatro,
                    'txtNumeroSerieFimaElectronicaAvanzadaSolicitante': txtNumeroSerieFimaElectronicaAvanzadaSolicitante,
                    'txtPolizaDoce': txtPolizaDoce,
                    'chkHipertensionArterialNo': chkHipertensionArterialNo,
                    'txtTinNifEquivalenteSolicitante': txtTinNifEquivalenteSolicitante,
                    'chkAparatoDigestivoNo': chkAparatoDigestivoNo,
                    'txtTinNifPersonaFisica': txtTinNifPersonaFisica,
                    'chkInsuficienciaRenalSi': chkInsuficienciaRenalSi,
                    'chkDeportePeligrosoSi': chkDeportePeligrosoSi,
                    'txtDomicApoderadoLegal': txtDomicApoderadoLegal,
                    'txtrazonSocial': txtrazonSocial,
                    'chkSidaSI': chkSidaSI,
                    'chkCargoPublicoSiSolicitante': chkCargoPublicoSiSolicitante,
                    'txtPolizaTrece': txtPolizaTrece,
                    'txtParentescoTres': txtParentescoTres,
                    'chkEnfermedadesGravesSi': chkEnfermedadesGravesSi,
                    'txtFolioDos': txtFolioDos,
                    'chkBit': chkBit,
                    'chkConsumoDrogasSI': chkConsumoDrogasSI,
                    'txtRfcSolicitante': txtRfcSolicitante,
                    'txtEstatura': txtEstatura,
                    'txtPaisContratante': txtPaisContratante,
                    'chkFormaPagoSemanal': chkFormaPagoSemanal,
                    'txtDuracionDos': txtDuracionDos,
                    'txtNoExteriorSolicitante': txtNoExteriorSolicitante,
                    'chkFormaPagoContado': chkFormaPagoContado,
                    'chkCrecimientoLineal': chkCrecimientoLineal,
                    'txtEspecifiqueCargoPersonaFisica': txtEspecifiqueCargoPersonaFisica,
                    'chkArtritisSI': chkArtritisSI,
                    'txtGiroMercantilObjSocial': txtGiroMercantilObjSocial,
                    'chkCirrosisHeptitisSi': chkCirrosisHeptitisSi,
                    'txtPolizaTres': txtPolizaTres,
                    'chkEnfermedadMencionadaSi': chkEnfermedadMencionadaSi,
                    'chkPasi': chkPasi,
                    'txtPadecimientoDos': txtPadecimientoDos,
                    'txtPreguntaDos': txtPreguntaDos,
                    'txtEmpresaPrestaServicioSolicitante': txtEmpresaPrestaServicioSolicitante,
                    'chkConductoCobroDomiciliado': chkConductoCobroDomiciliado,
                    'txtNacionalidad': txtNacionalidad,
                    'txtFechaInicioUno': txtFechaInicioUno,
                    'chkSolicitudNo': chkSolicitudNo,
                    'txtEstadoActualDos': txtEstadoActualDos,
                    'chkContratanteNo': chkContratanteNo,
                    'chkAccidenteMapo': chkAccidenteMapo,
                    'txtPorcentajeTres': txtPorcentajeTres
                };

                ////////////////////////////////////////////////////////////////////////////////////////////////
                /*PARAMETROS CUESTIONARIO ENFERMEDADES RESPIRATORIAS*/


                if (version == '1') {
                    param.chkSiPregunta1 = chkSi14;
                    param.chkNoPregunta1 = chkNo14;

                    param.chkSiPregunta2 = chkSi15;
                    param.chkNoPregunta2 = chkNo15;

                    param.chkSiPregunta3 = chkSi16;
                    param.chkNoPregunta3 = chkNo16;

                    param.chkSiPregunta4 = chkSi17;
                    param.chkNoPregunta4 = chkNo17;

                    param.chkSiPregunta5 = chkSi18;
                    param.chkNoPregunta5 = chkNo18;

                    param.chkSiPregunta6 = chkSi19;
                    param.chkNoPregunta6 = chkNo19;

                    param.txtContratante = nombreCompletoContratante;
                    param.txtSolicitante = nombreCompletoAsegurado;

                }

                if (version == '2') {
                    param.chkSiPregunta1 = chkSi14;
                    param.chkNoPregunta1 = chkNo14;

                    param.chkSiPregunta2 = chkSi15;
                    param.chkNoPregunta2 = chkNo15;

                    param.chkSiPregunta3 = chkSi16;
                    param.chkNoPregunta3 = chkNo16;

                    param.chkSiPregunta4 = chkSi17;
                    param.chkNoPregunta4 = chkNo17;

                    param.chkSiPregunta5 = chkSi18;
                    param.chkNoPregunta5 = chkNo18;

                    param.chkSiPregunta5_1 = chkSi19;
                    param.chkNoPregunta5_1 = chkNo19;

                    param.chkSiPregunta6 = chkSi20
                    param.chkNoPregunta6 = chkNo20;

                    param.chkSiPregunta7 = chkSi21;
                    param.chkNoPregunta7 = chkNo21;

                    param.chkSiPregunta8 = chkSi22;
                    param.chkNoPregunta8 = chkNo22;

                    param.chkSiPregunta9 = chkSi23;
                    param.chkNoPregunta9 = chkNo23;

                    param.chkSiPregunta10 = chkSi24;
                    param.chkNoPregunta10 = chkNo24;


                    param.chkSiPregunta11 = chkSi25;
                    param.chkNoPregunta11 = chkNo25;
                    param.txtPregunta11a = txt25a;
                    param.txtPregunta11b = txt25b;
                    param.txtPregunta11c = txt25c;


                    param.chkSiPregunta12 = chkSi26;
                    param.chkNoPregunta12 = chkNo26;

                    param.txtContratante = nombreCompletoContratante;
                    param.txtSolicitante = nombreCompletoAsegurado;

                }

                param.version = version;
            }




            //alert(param);
            OpenWindowWithPost("FirmaElectronica.aspx", "width=1400, height=600, left=100, top=100, resizable=yes, scrollbars=yes", "Firma Digital", param);
            //window.open("FirmaDigital.aspx?uid=1234", "", "width=800,height=600,left=100,top=100,resizable=yes,scrollbars=yes");
        }
    }
    else {
        alert("Error interno, favor de realizar nuevamente el proceso");
    }
    Cargando(false);
}


function armaCadena(oper, ModoCotizacion) {

    Cargando(true);

    var token = document.getElementById("UscAsegCLM_hdnToken").value;
    var agente = selValorCtrl("drpAgente");
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var moneda = selValorCtrl("drpMoneda");
    var tip_regulariza = selValorCtrl("drpCrecimiento", 0);
    var pct_regulariza = selValorCtrl("drpCrecimiento", 1);
    var deducible = "";
    if (document.getElementById("HiddenRamoRequest").value == "101")
        deducible = selIndex("drpDeducible");
    else
        deducible = document.getElementById("HiddenDeducible").value;

    var comision = selValorCtrl("drpComision");
    var duracion = selValorCtrl("drpPlazo");
    MetodosAjax.setDuracion(duracion);
    var duracion1 = selValorCtrl("drpPlazo");
    var modalidad = document.getElementById("HiddenModalidad").value;
    MetodosAjax.setModalidad(modalidad);
    var tablaAsegurados = MetodosAjax.setAsegurados();
    if (ramo == "105") {
        duracion1 = duracion - tablaAsegurados.value.Rows[0].edad;
    }


    //	if (modalidad == "16010")
    //	{
    //	
    //	    if (document.getElementById("rbtnListPolizaContrato_1").checked)
    //        {
    //            modalidad= "16000" ;
    //        }
    //	
    //	}

    var envio = 1; //Agente
    var formaPago = selValorCtrl("drpFormaPago");
    var tipoPago = selValorCtrl("drpTipoPago");

    var cod_gestor = valorCtrl("UscContCLM_hdnCodEntidad");
    var zona = valorCtrl("UscContCLM_hdnEdo"); //Estado del Contratante
    var localidad = valorCtrl("UscContCLM_hdnPoblacion"); //Poblacion del Contratante

    //-------->C3<--------
    var tipo_seguro = "";
    var tip_seguros = document.getElementsByName("rblTipoSeguro");

    for (i = 0; i < tip_seguros.length; i++) {
        if (tip_seguros[i].checked == true) {
            tipo_seguro = tip_seguros[i].value;
        }
    }

    //Parte para el Envío de la Fecha de Nacimiento.
    var fecNac = "";
    //Si es una marca "C" de contización se debe preguntar si es solo la Cotización Inicial
    //o se trata de una "SOLICITUD" en caso de que no sea "C" es una "P" y deberá enviar la fecha del CLM
    //del Asegurado.
    if (oper == "C") {
        //Si solo se quieren obtener las primas Se obtiene la fecha obtenida a través de la edad.
        //Y si es una "Solicitud" entonces se envía la fecha del CLM.
        if (ModoCotizacion == "PRIMAS") {
            fecNac = document.getElementById("hidFechaNac").value;

            //------>C27<------
            //------>C20<------
            //tipo_seguro = "P";
        }
        else {
            if (ramo == "105") {
                fecNac = tablaAsegurados.value.Rows[0].fec_nac;
            }
            else {
                fecNac = valorCtrl("UscAsegCLM_lblNacimiento");
            }
        }
    }
    else {
        if (ramo == "105") {
            fecNac = tablaAsegurados.value.Rows[0].fec_nac;
        }
        else {
            fecNac = valorCtrl("UscAsegCLM_lblNacimiento");
        }

    }

    var fecEfecto = valorCtrl("txtFechaEfecto");
    MetodosAjax.setFecha(fecEfecto);
    var fecEfectoMas1Anio = MetodosAjax.sumarUnAnioAFecha(fecEfecto);
    var fecVcto = fecEfectoMas1Anio.value;

    var CLM_Cont = valorCtrl("UscContCLM_hdnCLM");
    if (ramo == "105") {
        //var CLM_Aseg = valorCtrl("UscAsegCLM_lblCLM");
        var CLM_Aseg = tablaAsegurados.value.Rows[0].cod_docum;
    }
    else {
        var CLM_Aseg = valorCtrl("UscAsegCLM_hdnCLM");
    }
    var tip_docum = "CLM";

    var nombre_riesgo = "";
    if (oper == "C") {
        if (ModoCotizacion == "PRIMAS")
            nombre_riesgo = "RIESGO COTIZACION";
        else
            nombre_riesgo = valorCtrl("UscAsegCLM_lblNombre") + " " + valorCtrl("UscAsegCLM_lblApellidoPaterno") + " " + valorCtrl("UscAsegCLM_lblApellidoMaterno");
    }
    else {
        if (ramo == "105") {
            nombre_riesgo = tablaAsegurados.value.Rows[0].nombre + " " + tablaAsegurados.value.Rows[0].paterno + " " + tablaAsegurados.value.Rows[0].materno;
        }
        else {
            nombre_riesgo = valorCtrl("UscAsegCLM_lblNombre") + " " + valorCtrl("UscAsegCLM_lblApellidoPaterno") + " " + valorCtrl("UscAsegCLM_lblApellidoMaterno");
        }
    }
    //Se inicializa la variable sexo como 1 [Masculino]
    var mca_sexo = 1;
    if (oper == "C") {
        if (ModoCotizacion == "PRIMAS")
            mca_sexo = selValorCtrl("drpSexo");
        else {

            if (manejoLabel("UscAsegCLM_lblSexo") == "Femenino")
                mca_sexo = 0;
        }
    }
    else {
        if (ramo == "105") {
            mca_sexo = tablaAsegurados.value.Rows[0].sexo;
        }
        else {
            if (manejoLabel("UscAsegCLM_lblSexo") == "Femenino")
                mca_sexo = 0;
        }

    }

    var fuma = valorCtrl("drpFuma");
    var ingresoAnual = $('#txtIngresoM').val();
    var dctoSexo = document.getElementById("HiddenDctoSex").value;
    var dctoAgente = selValorCtrl("drpAgente");
    MetodosAjax.setAgente(dctoAgente);
    var dctoFuma = document.getElementById("HiddenDctoFuma").value;
    var polizaGrupo = "";
    var contrato = "";

    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        polizaGrupo = textoCtrl("drpPolizaGrupo");
        contrato = selValorCtrl("drpContrato");
    }

    if (oper == "C") {
        //tipoPago = "AG";
        if (ModoCotizacion == "PRIMAS")
            CLM_Cont = "PRUEBA";
        else
            CLM_Cont = valorCtrl("UscContCLM_hdnCLM");
    }
    else
        CLM_Cont = valorCtrl("UscContCLM_hdnCLM");
    if (tipoPago == "AG")
        cod_gestor = agente;

    //Esto es solo para que siempre deje Cotizar en caso de que el tipo
    //de Pago sea diferente de "AG" ya que la variable "cod_gestor"
    //al momento de obtener primas no tiene un valor y genera un error.
    if (ModoCotizacion == "PRIMAS") {
        tipoPago = "AG";
        cod_gestor = agente;
    }

    //Esto es para que al Obtener Primas siempre mande los valores correctos
    //en la Prima de cada Cobertura.
    if (ModoCotizacion == "PRIMAS")
        formaPago = 1;

    //C10
    var endosoEdu = "N";
    //C10

    var Ocupacion = selValorCtrl("drpOcupacion");
    var Peso = valorCtrl("txtPeso");
    var Estatura = valorCtrl("txtEstatura");

    //Validación de Vicente García Sepulveda.
    var codRiesgo = "0";
    var tipRiesgo = "0";
    if (ramo == "100") {
        if (modalidad == "10008") {
            codRiesgo = "1";
            tipRiesgo = "1";
        }
        if (modalidad == "10011" && polizaGrupo == "") {
            polizaGrupo = "1TEMPORAL1001";
            contrato = "10059";
        }
    }

    //	var cuadroCom = MetodosAjax.getCuadroComision(agente);
    //    if(cuadroCom.error != null)
    //        alert(cuadroCom.error.description);

    ///////////////////////////////////
    // Arreglo de datos de la poliza //
    ///////////////////////////////////
    var arrDatosPoliza = new Array();
    arrDatosPoliza.push("TIP_DURACION=1");
    arrDatosPoliza.push("COD_RAMO=" + ramo);
    arrDatosPoliza.push("COD_AGT=" + agente);
    if (ramo == "105") {
        arrDatosPoliza.push("ANIOS_MAX_DURACION=" + duracion1);
    }
    else {
        arrDatosPoliza.push("ANIOS_MAX_DURACION=" + duracion);
    }
    arrDatosPoliza.push("COD_ENVIO=" + envio);
    arrDatosPoliza.push("COD_FRACC_PAGO=" + formaPago);
    arrDatosPoliza.push("COD_GESTOR=" + cod_gestor);
    arrDatosPoliza.push("COD_MON=" + moneda);
    arrDatosPoliza.push("TIP_GESTOR=" + tipoPago);
    //Cuadros de Comision INI
    //arrDatosPoliza.push("COD_CUADRO_COM=" + cuadroCom.value);
    arrDatosPoliza.push("COD_CUADRO_COM=" + document.getElementById("HidCuadroCom").value);
    //Cuadros de Comision FIN
    arrDatosPoliza.push("TIP_DOCUM=" + tip_docum);
    arrDatosPoliza.push("COD_DOCUM=" + CLM_Cont);
    arrDatosPoliza.push("TXT_MOTIVO_SPTO=" + oper);
    arrDatosPoliza.push("MCA_IMPRESION=N");
    arrDatosPoliza.push("COD_MODALIDAD=" + modalidad);
    arrDatosPoliza.push("FEC_EFEC_POLIZA=" + fecEfecto);
    arrDatosPoliza.push("FEC_VCTO_POLIZA=" + fecVcto);
    arrDatosPoliza.push("FEC_EFEC_SPTO=" + fecEfecto);
    arrDatosPoliza.push("FEC_VCTO_SPTO=" + fecVcto);
    if (ramo == "105") {
        var renglones = tablaAsegurados.value.Rows.length;
        //for (var i = 0; i <= renglones - 1; i++) {
            nombre_riesgo = tablaAsegurados.value.Rows[0].nombre + " " + tablaAsegurados.value.Rows[0].paterno + " " + tablaAsegurados.value.Rows[0].materno;
            arrDatosPoliza.push("FEC_EFEC_RIESGO=" + fecEfecto);
            arrDatosPoliza.push("FEC_VCTO_RIESGO=" + fecVcto);
            arrDatosPoliza.push("NOM_RIESGO=" + nombre_riesgo);
            arrDatosPoliza.push("NUM_RIESGO=" + 1);
        //}
    }
    else {
        arrDatosPoliza.push("FEC_EFEC_RIESGO=" + fecEfecto);
        arrDatosPoliza.push("FEC_VCTO_RIESGO=" + fecVcto);
        arrDatosPoliza.push("NOM_RIESGO=" + nombre_riesgo);
        arrDatosPoliza.push("NUM_RIESGO=" + (i + 1));
    }
    arrDatosPoliza.push("NUM_POLIZA_GRUPO=" + polizaGrupo);
    arrDatosPoliza.push("NUM_CONTRATO=" + contrato);
    arrDatosPoliza.push("TIP_REGULARIZA=" + tip_regulariza);
    arrDatosPoliza.push("PCT_REGULARIZA=" + pct_regulariza);

    var indAgt = 2;
    for (i = 2; i <= 5; i++) {
        var index = ((parseInt(i) < 10) ? "0" + i : i);
        if (document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave").value != "") {
            var codAgt = document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave").value
            var pctAgt = document.getElementById("dtgReferencias_ctl" + index + "_txtgrdPorcentaje").value
            if (i == 2)
                arrDatosPoliza.push("PCT_AGT=" + pctAgt);
            else {
                arrDatosPoliza.push("COD_AGT" + indAgt + "=" + codAgt);
                arrDatosPoliza.push("PCT_AGT" + indAgt + "=" + pctAgt);
                indAgt++;
            }
        }
    }

    ////////////////////////////////
    // Arreglo de datos variables //
    ////////////////////////////////
    var arrDatosVariables = new Array();
    MetodosAjax.setSession("COMISION", comision);
    var secu = 1;
    arrDatosVariables.push("COD_CAMPO=COD_ZONA|VAL_CAMPO=" + zona + "|VAL_COR_CAMPO=" + zona + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=COD_RIESGO|VAL_CAMPO=" + codRiesgo + "|VAL_COR_CAMPO=" + codRiesgo + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=TIP_RIESGO|VAL_CAMPO=" + tipRiesgo + "|VAL_COR_CAMPO=" + tipRiesgo + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=TIP_DEDUCIBLE|VAL_CAMPO=" + deducible + "|VAL_COR_CAMPO=" + deducible + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=TIP_COMISION|VAL_CAMPO=" + comision + "|VAL_COR_CAMPO=" + comision + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=VAL_DURACION_SEGURO|VAL_CAMPO=" + duracion + "|VAL_COR_CAMPO=" + duracion + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=COD_MODALIDAD|VAL_CAMPO=" + modalidad + "|VAL_COR_CAMPO=" + modalidad + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=VAL_FOLIO_SOLICITUD|VAL_CAMPO=1|VAL_COR_CAMPO=1|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=NUM_EMPLEADO|VAL_CAMPO=1|VAL_COR_CAMPO=1|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=MCA_BENEFMEN|VAL_CAMPO=" + endosoEdu + "|VAL_COR_CAMPO=" + endosoEdu + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    if (ramo == 105) {
        arrDatosVariables.push("COD_CAMPO=TIP_SEGURO_VIDA|VAL_CAMPO=P|VAL_COR_CAMPO=P|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);  //------>C3<--------
        //------>C3<--------
        //arrDatosVariables.push("COD_CAMPO=TIP_SEGURO_VIDA|VAL_CAMPO=999|VAL_COR_CAMPO=999|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);  //------>C3<--------

    }
    else {
        arrDatosVariables.push("COD_CAMPO=TIP_SEGURO_VIDA|VAL_CAMPO=" + tipo_seguro + "|VAL_COR_CAMPO=" + tipo_seguro +
            "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);  //------>C3<--------

    }

    if (document.getElementById("chkMSI").checked == true) //MGM_MSI
    {
        arrDatosVariables.push("COD_CAMPO=NUM_AFILI_PORTAL|VAL_CAMPO=S|VAL_COR_CAMPO=S|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
        MSI = "S";
    }

    //Nivel 2
    secu = 1;
    if (ramo == "105") {
        var renglones = tablaAsegurados.value.Rows.length;
        for (var i = 0; i <= renglones - 1; i++) {
            fecNac = tablaAsegurados.value.Rows[i].fec_nac;
            arrDatosVariables.push("COD_CAMPO=FEC_NACIMIENTO|VAL_CAMPO=" + fecNac.replace(/\/|\,/g, "") + "|VAL_COR_CAMPO=" + fecNac.replace(/\/|\,/g, "") + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=" + (i + 1) + "|COD_RAMO=" + ramo);
            arrDatosVariables.push("COD_CAMPO=MCA_SEXO|VAL_CAMPO=" + tablaAsegurados.value.Rows[i].sexo + "|VAL_COR_CAMPO=" + tablaAsegurados.value.Rows[i].sexo + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=" + (i + 1) + "|COD_RAMO=" + ramo);
            arrDatosVariables.push("COD_CAMPO=MCA_FUMAR|VAL_CAMPO=" + 0 + "|VAL_COR_CAMPO=" + 0 + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=" + (i + 1) + "|COD_RAMO=" + ramo);

            if (document.getElementById("divCuestionarioMillon").innerHTML != "") {
                arrDatosVariables.push("COD_CAMPO=MCA_ANUAL|VAL_CAMPO=" + ingresoAnual + "|VAL_COR_CAMPO=" + ingresoAnual + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
            }
        }
    }
    else {
        arrDatosVariables.push("COD_CAMPO=FEC_NACIMIENTO|VAL_CAMPO=" + fecNac.replace(/\/|\,/g, "") + "|VAL_COR_CAMPO=" + fecNac.replace(/\/|\,/g, "") + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
        arrDatosVariables.push("COD_CAMPO=MCA_SEXO|VAL_CAMPO=" + mca_sexo + "|VAL_COR_CAMPO=" + mca_sexo + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
        arrDatosVariables.push("COD_CAMPO=MCA_FUMAR|VAL_CAMPO=" + fuma + "|VAL_COR_CAMPO=" + fuma + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);

        if (document.getElementById("divCuestionarioMillon").innerHTML != "") {
            arrDatosVariables.push("COD_CAMPO=MCA_ANUAL|VAL_CAMPO=" + ingresoAnual + "|VAL_COR_CAMPO=" + ingresoAnual + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
        }
    }
    if (ramo == "101" && modalidad == "12003" || ramo == "101" && modalidad == "12004") {

        var pp = selIndex("drpPlazoPrima");
        arrDatosVariables.push("COD_CAMPO=VAL_PLAZO_PRIMA|VAL_CAMPO=" + pp + "|VAL_COR_CAMPO=" + pp + "|TIP_NIVEL=1|NUM_SECU=" + secu++ + "|NUM_RIESGO=0|COD_RAMO=" + ramo);
    }
    //Se agregan los Datos para la Ocupación Peso y Estatura.
    if (oper == "P") {
        var renglones = tablaAsegurados.value.Rows.length;
        for (var i = 0; i <= renglones - 1; i++) {
            arrDatosVariables.push("COD_CAMPO=COD_OCUPACION|VAL_CAMPO=" + tablaAsegurados.value.Rows[i].ocupacion + "|VAL_COR_CAMPO=" + 0 + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=" + (i + 1) + "|COD_RAMO=" + ramo);
            arrDatosVariables.push("COD_CAMPO=NUM_ESTATURA|VAL_CAMPO=" + tablaAsegurados.value.Rows[i].estatura + "|VAL_COR_CAMPO=" + tablaAsegurados.value.Rows[i].estatura + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=" + (i + 1) + "|COD_RAMO=" + ramo);
            arrDatosVariables.push("COD_CAMPO=NUM_PESO|VAL_CAMPO=" + tablaAsegurados.value.Rows[i].peso + "|VAL_COR_CAMPO=" + tablaAsegurados.value.Rows[i].peso + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=" + (i+1) + "|COD_RAMO=" + ramo);
        }
        //arrDatosVariables.push("COD_CAMPO=COD_OCUPACION|VAL_CAMPO=" + 0 + "|VAL_COR_CAMPO=" + 0 + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
        //arrDatosVariables.push("COD_CAMPO=NUM_ESTATURA|VAL_CAMPO=" + Estatura + "|VAL_COR_CAMPO=" + Estatura + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
        //arrDatosVariables.push("COD_CAMPO=NUM_PESO|VAL_CAMPO=" + Peso + "|VAL_COR_CAMPO=" + Peso + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
    }
    else {
        if (ModoCotizacion == "SOLICITUD") {
            arrDatosVariables.push("COD_CAMPO=COD_OCUPACION|VAL_CAMPO=" + Ocupacion + "|VAL_COR_CAMPO=" + Ocupacion + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
            arrDatosVariables.push("COD_CAMPO=NUM_ESTATURA|VAL_CAMPO=" + Estatura + "|VAL_COR_CAMPO=" + Estatura + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
            arrDatosVariables.push("COD_CAMPO=NUM_PESO|VAL_CAMPO=" + Peso + "|VAL_COR_CAMPO=" + Peso + "|TIP_NIVEL=2|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
        }
    }

    //Nivel 3
    secu = 1;
    if (dctoSexo == null) {
        dctoSexo = 0;
    }

    if (dctoFuma == null) {
        dctoFuma = 0;
    }

    arrDatosVariables.push("COD_CAMPO=DTO_SEXO|VAL_CAMPO=" + dctoSexo + "|VAL_COR_CAMPO=" + dctoSexo + "|TIP_NIVEL=3|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=DTO_FUMAR|VAL_CAMPO=" + dctoFuma + "|VAL_COR_CAMPO=" + dctoFuma + "|TIP_NIVEL=3|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=DTO_AGENTE_DIR|VAL_CAMPO=" + dctoAgente + "|VAL_COR_CAMPO=" + dctoAgente + "|TIP_NIVEL=3|NUM_SECU=" + secu++ + "|NUM_RIESGO=1|COD_RAMO=" + ramo);
    var arregloAsegurados = tablaAsegurados.value.Rows.length;
    for (var i = 0; i <= arregloAsegurados - 1; i++) {
        arrDatosVariables.push("COD_CAMPO=COD_PARENTESCO|VAL_CAMPO=" + tablaAsegurados.value.Rows[i].cod_parent +"|VAL_COR_CAMPO=38|NUM_RIESGO="+ (i+1) +"|TIP_NIVEL=2|COD_RAMO=" + ramo + "|NUM_SECU=7");
    }
    var suma_aseg0 = "";
    // Arreglo con datos de las coberturas
    var arrDatosCoberturas = new Array();
    var tbCoberturas = document.getElementById("Coberturas");
    var cadena;
    var ExisteBIT = false;
    var EstaMarcadaBIT = false;
    var ContSumas = 0;

    var Cod_CobBit = "";

    secu = 1

    var mcaSF = "N";
    var suma_asegBasica = "";

    //aseg = getNumAsegurado();
    //datosAseg = AseguradosType()[aseg].split("|");

    if (ramo == "105") {
        // lo dejamos pasar por este flujo para que no cargue las coberturas
    }
    else { // ESTA RECORRE LA TABLA DE COBERTURAS EN EL QUE EMITE, PERO EN NUESTRO CASO SOLO SERA POR ASEGURADO Y NO POR COBERTURAS
        //for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        cadena = "";

        if (datosAseg[2] != null) {
            var coberturasTemp = datosAseg[2].split(",");
            var coberturas = [];
            for (var i = 0; i < coberturasTemp.length; i++) {
                switch (coberturasTemp[i]) {
                    case "BASICA":
                        coberturas.push(1000);
                        break;
                    case "TEMPORAL":
                        coberturas.push(1014);
                        break;
                    case "BIT":
                        coberturas.push(1011);
                        break;
                    case "BIPA":
                        coberturas.push(1012);
                        break;
                    case "BEF":
                        coberturas.push(1013);
                        break;
                    default:
                }
            }
            var sumaAsegCob = datosAseg[3].replace(",", "").split();
            for (var i = 0; i < coberturas.length; i++) {

                // AQUI PARA BIT EL CODIGO ES 1011
                if (coberturas[i] == 1095 || coberturas[i] == 1001 || coberturas[i] == 1011) {
                    ExisteBIT = true;
                    Cod_CobBit = coberturas[i];
                }
                if (coberturas[i] != "") {
                    var cod_cob = coberturas[i];
                    var sumaAseg = sumaAsegCob[i];
                    /////Parte para suma_aseg0
                    if (ContSumas == 0)
                        suma_aseg0 = sumaAseg
                    ContSumas++;
                    //////////////////////////
                    if (isNaN(sumaAseg))
                        sumaAseg = "0";
                    cadena += "COD_COB=" + cod_cob + "|";
                    if (cod_cob == 1000) {
                        suma_asegBasica = sumaAseg;
                    }
                    if (cod_cob == 1014) {
                        suma_asegBasica = sumaAseg;
                    }
                    //Caso especial para cobertura [1019] SF.
                    //****************************************************************************************
                    //Cuando sea diferente de [1019] SF se envía de manera normal la Suma Asegurada Capturada.
                    if (cod_cob != "1019") {
                        //Aplica el 25% de la suma asegurada basica para la cobertura EG
                        if (cod_cob == "1003") {
                            cadena += "SUMA_ASEG=" + suma_asegBasica * 0.25 + "|";
                            cadena += "SUMA_ASEG_SPTO=" + suma_asegBasica * 0.25 + "|";
                        }
                        else {
                            cadena += "SUMA_ASEG=" + sumaAseg + "|";
                            cadena += "SUMA_ASEG_SPTO=" + sumaAseg + "|";
                        }
                    }
                    //En caso de que la Cobertura [1019] SF haya sido marcada se envía como Suma el Valor de 0.
                    else {
                        cadena += "SUMA_ASEG=0|";
                        cadena += "SUMA_ASEG_SPTO=0|";
                        mcaSF = "S";
                    }
                    //*****************************************************************************************
                    cadena += "NUM_SECU=" + (secu++) + "|";
                    cadena += "COD_SECC_REAS=13";
                    cadena += "|NUM_RIESGO=" + (getNumAsegurado() + 1) + "|";
                    cadena += "COD_RAMO=" + ramo + "|";
                    cadena += "MCA_BAJA_COB=N";
                    //Caso especial para la Cobertura [1095] BIT si la Cobertura está Marcada, entonces no debe
                    //de Enviarse.
                    if (cod_cob != "1095" && cod_cob != "1001" && cod_cob != "1011")
                        arrDatosCoberturas[arrDatosCoberturas.length] = cadena;
                    else {
                        if (ExisteBIT)
                            EstaMarcadaBIT = true;
                    }
                }
            }
        }
    }



    //Cuando la cobertura [1095] BIT exista pero no se haya marcado deberá enviarse con suma Asegurada igual a Cero.
    if (ExisteBIT) {
        if (!EstaMarcadaBIT) {
            var codCobBit = Cod_CobBit;

            /*if(ramo == "108")
               codCobBit = "1001";*/

            cadena = "";
            cadena += "COD_COB=" + codCobBit;
            cadena += "|SUMA_ASEG=0";
            cadena += "|SUMA_ASEG_SPTO=0";
            cadena += "|NUM_SECU=" + secu++;
            cadena += "|COD_RAMO=" + ramo;
            cadena += "|MCA_BAJA_COB=N";
            cadena += "|COD_SECC_REAS=13";
            cadena += "|NUM_RIESGO=" + (getNumAsegurado() + 1);
            arrDatosCoberturas.push(cadena);
        }
    }
    else {
        //Cuando no exista BIT en las coberturas se debe mandar con el fin de no AMPARARSE.
        if (ramo == 105) {
            cadena = "";
            cadena += "COD_COB=1091";
            cadena += "|SUMA_ASEG=0";
            cadena += "|SUMA_ASEG_SPTO=0";
            cadena += "|NUM_SECU=" + secu++;
            cadena += "|COD_RAMO=" + ramo;
            cadena += "|MCA_BAJA_COB=N";
            cadena += "|COD_SECC_REAS=13";
            cadena += "|NUM_RIESGO=" + 1;
            arrDatosCoberturas.push(cadena);

        }
        else {
            cadena = "";
            cadena += "COD_COB=1095";
            cadena += "|SUMA_ASEG=0";
            cadena += "|SUMA_ASEG_SPTO=0";
            cadena += "|NUM_SECU=" + secu++;
            cadena += "|COD_RAMO=" + ramo;
            cadena += "|COD_SECC_REAS=13";
            cadena += "|MCA_BAJA_COB=N";
            cadena += "|NUM_RIESGO=" + 1;
            arrDatosCoberturas.push(cadena);

            //cadena = "";
            //cadena += "COD_COB=1001";
            //cadena += "|SUMA_ASEG=0";
            //cadena += "|SUMA_ASEG_SPTO=0";
            //cadena += "|NUM_SECU=" + secu++;
            //cadena += "|COD_RAMO=" + ramo;
            //cadena += "|COD_SECC_REAS=13";
            //cadena += "|MCA_BAJA_COB=N";
            //cadena += "|NUM_RIESGO=" + (getNumAsegurado() + 1);
            //arrDatosCoberturas.push(cadena);
        }
    }


    arrDatosPoliza.push("MCA_SF=" + mcaSF);

    //////////////////////////////
    // Arreglo de datos titular //
    //////////////////////////////
    var arrDatosTitular = new Array();
    if (oper == "C") {
        if (ModoCotizacion == "PRIMAS")
            arrDatosTitular.push("COD_DOCUM=PRUEBA");
        else
            arrDatosTitular.push("COD_DOCUM=" + CLM_Aseg);
    }
    else
        arrDatosTitular.push("COD_DOCUM=" + CLM_Aseg);
    arrDatosTitular.push("TIP_DOCUM=CLM");
    arrDatosTitular.push("TIP_BENEF=2");
    arrDatosTitular.push("NUM_SECU=1");
    arrDatosTitular.push("NUM_RIESGO=" + 1);


    //////////////////////////////////
    // Arreglo de datos contratante //
    //////////////////////////////////

    //Datos que son proporcionados por el Contratante de la persona que desea Asegurar.
    var arrDatosContratante = new Array();
    if (oper == "C") {
        arrDatosContratante.push("FEC_NACIMIENTO=" + fecNac);
        arrDatosContratante.push("MCA_SEXO=" + mca_sexo);
        arrDatosContratante.push("MCA_FUMA=" + selValorCtrl("drpFuma"));
    }

    ///////////////////////////////////
    // Arreglo de datos beneficiario //
    ///////////////////////////////////
    var arrDatosBenef = new Array();
    if (ModoCotizacion == "SOLICITUD")
    //if(oper == "P")
    {
        var tblBenef = MetodosAjax.generaCodDocumBENEF();
        if (tblBenef.error == null) {
            if (tblBenef != null && tblBenef.value != null && tblBenef.value.Rows.length != 0) {
                secu = 0;
                var prim = 0;
                var totalpor = 0;
                for (var i = 0; i < tblBenef.value.Rows.length; i++) {
                    secu++;
                    var tip_benef = tblBenef.value.Rows[i].tip_benef;
                    if (tip_benef == 6) {
                        prim++;
                        secu = 0;
                    }

                    cadena = "";
                    cadena += "TIP_DOCUM=" + tblBenef.value.Rows[i].tip_docum;
                    cadena += "|COD_DOCUM=" + tblBenef.value.Rows[i].cod_docum;
                    var cant_bene = tblBenef.value.Rows.length;
                    var porcentanje;
                    var porcentaje2;
                    if (ramo != "105") {


                    }

                    else {
                        cadena += "|PCT_PARTICIPACION=" + tblBenef.value.Rows[i].porcentaje;
                    }


                    cadena += "|TIP_BENEF=" + tip_benef;
                    cadena += "|NUM_RIESGO=" + (i + 1);


                    if (tip_benef == 6)
                        cadena += "|NUM_SECU=" + prim;
                    else cadena += "|NUM_SECU=" + secu;

                    arrDatosBenef[arrDatosBenef.length] = cadena;

                }
            }
        }
        else alert(tblBenef.error.description);
    }

    var arrDatosBanco = new Array();

    if (ModoCotizacion == "SOLICITUD") {
        MetodosAjax.setSession("COD_AGT", agente);
        MetodosAjax.setSession("CodigoMoneda", moneda);
        MetodosAjax.setSession("EdadTitular", manejoLabel("UscAsegCLM_lblEdad"));
        MetodosAjax.setSession("SumaAsegurada", suma_aseg0);
        MetodosAjax.setSession("COD_RAMO", ramo);
        MetodosAjax.setSession("COD_DOCUMT", CLM_Aseg);
        MetodosAjax.setSession("NOM_TERCEROT", valorCtrl("UscAsegCLM_lblNombre"));
        MetodosAjax.setSession("COD_ESTADOT", zona);
    }


    //Facturacion 4.0 JDVI
    arrDatosPoliza[arrDatosPoliza.length] = "RegFiscal=" + document.all["UscContCLM_hdnRegFiscal"].value;
    arrDatosPoliza[arrDatosPoliza.length] = "CodPostalFiscal=" + document.all["UscContCLM_hdnCodPostalFiscal"].value;
    arrDatosPoliza[arrDatosPoliza.length] = "RegSocietario=" + document.all["UscContCLM_hdnRegSocietario"].value;
    arrDatosPoliza[arrDatosPoliza.length] = "RfcStr=" + document.getElementById('UscContCLM_lblRFC').textContent;
    arrDatosPoliza[arrDatosPoliza.length] = "Facturar=" + $('#UscContCLM_rdoFacturarSi').is(":checked");

    if (oper == "C") {
        if (ModoCotizacion == "PRIMAS")
            MetodosAjax.getCotizacion(oper, arrDatosPoliza, arrDatosVariables, arrDatosCoberturas, arrDatosContratante, arrDatosTitular, arrDatosBenef, arrDatosBanco, token, getCot_CallBack);
        else {
            MetodosAjax.getSolicitud(oper, arrDatosPoliza, arrDatosVariables, arrDatosCoberturas, arrDatosContratante, arrDatosTitular, arrDatosBenef, arrDatosBanco, token, getSolicitud_CallBack);
        }
    }
    else {
        MetodosAjax.setOperacion("EMISION");
        ActualizarEstadoRAM();
        MetodosAjax.getEmision(oper, arrDatosPoliza, arrDatosVariables, arrDatosCoberturas, arrDatosContratante, arrDatosTitular, arrDatosBenef, arrDatosBanco, token, MSI, getEmision_CallBack);
    }
}
function getCot_CallBack(cotiza) {
    document.getElementById("divPrimas").innerHTML = "";

    if (cotiza.error == null) {
        if (cotiza != null && cotiza.value != null && cotiza.value.Tables.length != 0) {

            //C1 Se evalua la prima Minima en base de la prima neta 
            //if (validaPrimaMinima(cotiza.value.Tables[0].Rows[0].PRIMAS)) {
            var tablaPrimas = cotiza.value.Tables[5].Rows[0].TABLA_PRIMAS;
            document.getElementById("divPrimas").innerHTML = tablaPrimas;

            //Se Limpian los valores de Primas para cada Cobertura.
            //por cada vez que se Obtengan las Primas.
            var tbCoberturas = document.getElementById("Coberturas");
            for (var i = 1; i <= tbCoberturas.rows.length - 1; i++) {
                var Cob = document.getElementById("chk" + i).value;
                valorCtrl("txtPrima" + Cob, "");
            }

            //Se agregan a cada Cobertura marcada, que haya sido Cotizada.                
            for (var i = 0; i < cotiza.value.Tables[0].Rows.length; i++) {
                var cod_cob = cotiza.value.Tables[0].Rows[i].COD_COB;
                var prima = cotiza.value.Tables[0].Rows[i].PRIMAS;
                valorCtrl("txtPrima" + cod_cob, prima);
            }

            document.getElementById("HiddenPrimaTotal").value = cotiza.value.Tables[1].Rows[0].IMP_PRIMA_TOTAL;
            //<----C26---->  
            document.getElementById('UscContCLM_hdnNumCotizacion').value = cotiza.value.Tables[4].Rows[0].COTIZACION;
            //<----------->


            //C2
            validaPoliticaLavadoDeDinero(cotiza.value.Tables[0].Rows[0].PRIMAS);
            //}
            //else
            //habilitarCtrl("btnEmite", false);
        }
    }
    else {
        //-----C23------
        if (cotiza.error.description.indexOf("RANGO NO VALIDO, MAXIMO") != -1) {
            if (cotiza.error.description.indexOf("RANGO NO VALIDO, MAXIMO POR DEP.") != -1) {
                alert(cotiza.error.description);
            }
            else {
                //alert("EL MONTO MINIMO DE SUMA ASEGURADA ES DE 150,000 DLLS.");
                alert("EL MONTO MINIMO DE SUMA ASEGURADA ES MENOR AL PERMITIDO.");
            }
        }
        else
            alert(cotiza.error.description);
    }
    Cargando(false);

    LlenarDatosDelSeguro();
    AjustarFrame();
    focusCtrl("UscContCLM_txtRFC");
}

//C2
/// <summary>
///     Muestra el mensaje según la pólitica lavado de dinero
/// </summary

function validaPoliticaLavadoDeDinero(prima) {
    if (document.getElementById("rbtnListPolizaContrato_0").checked) {
        var Moneda = selValorCtrl("drpMoneda");
        var FormaPago = selValorCtrl("drpFormaPago");
        var ramo = document.getElementById("HiddenRamoRequest").value;
        var modalidad = document.getElementById("HiddenModalidad").value;

        var contrato = getNumContrato();

        var valPolitica = MetodosAjax.validaPoliticaLavadoDeDinero("2", "1", ramo, modalidad, contrato, Moneda, prima);

        if (valPolitica.error == null) {
            if (valPolitica != null && valPolitica.value != null) {
                var Mensaje = valPolitica.value.p_mensaje;
                alert(Mensaje);
                return true;
            }
        }
        else {
            return false;
        }
    }
    else
        return true;
}

function validaPrimaMinima(prima) {
    if (document.getElementById("rbtnListPolizaContrato_0").checked) {
        var Moneda = selValorCtrl("drpMoneda");
        var FormaPago = selValorCtrl("drpFormaPago");

        //-----------------> C12 <----------------
        var edad = document.getElementById("txtEdad").value;
        var ramo = document.getElementById("HiddenRamoRequest").value;
        var modalidad = document.getElementById("HiddenModalidad").value;
        var contrato = getNumContrato();

        var valPrima = MetodosAjax.validaPrimaMinima(prima, Moneda, FormaPago, "2", "1", ramo, modalidad, contrato);
        if (valPrima.error == null) {
            if (valPrima != null && valPrima.value != null) {
                var MarcaValidacion = valPrima.value.p_mca_valido;
                var Mensaje = valPrima.value.p_error;
                if (MarcaValidacion == "S")
                    return true;
                else {
                    alert(Mensaje);
                    return false;
                }
            }
        }
        else {
            alert(valPrima.error.description);
            return false;
        }
    }
    else {
        var ramo = document.getElementById("HiddenRamoRequest").value;
        var modalidad = document.getElementById("HiddenModalidad").value;
        var contrato = getNumContrato();

        if (ramo == "100" && contrato == "10100" && modalidad == "10003") {
            if (prima < 50) {
                //Se Limpian los valores de Primas para cada Cobertura.
                //por cada vez que se Obtengan las Primas.
                var tbCoberturas = document.getElementById("Coberturas");
                for (var i = 1; i <= tbCoberturas.rows.length - 1; i++) {
                    var Cob = document.getElementById("chk" + i).value;
                    valorCtrl("txtPrima" + Cob, "")
                };

                alert("La prima m\u00EDnima quincenal no debe ser menor a 50 PESOS.");
                return false;
            }
            else {
                return true;
            }
        }
        else {
            return true;
        }

    }

}

function getSolicitud_CallBack(cotiza) {
    document.getElementById("HiddenFolioRAM").value = "";
    //document.getElementById("HiddenIDSistemaRAM").value = "";
    if (cotiza.error == null) {
        if (cotiza != null && cotiza.value != null && cotiza.value.Tables.length != 0) {
            var arrFolioRAM = new Array();
            arrFolioRAM = cotiza.value.Tables[5].Rows[0].FOLIO_RAM.split('|');
            var FolioRAM = arrFolioRAM[0];
            var IdSistemaRAM = arrFolioRAM[1];
            var Mensaje = "SU N\u00daMERO DE SOLICITUD ES: " + cotiza.value.Tables[4].Rows[0].COTIZACION + " Y EL FOLIO RAM ES : " + FolioRAM;
            alert(Mensaje);



            //------------------> C15 <------------ documentum folio ram
            var documentos = document.getElementById("grdAdjuntarArchivo");
            var archivos = "";

            if (documentos != null) {
                for (var i = 1; i < documentos.rows.length; i++) {
                    archivos = archivos + documentos.rows[i].cells[0].innerHTML + ",";
                }
            }

            MetodosAjax.AgregarFolioDocumentum(archivos, FolioRAM, cotiza.value.Tables[4].Rows[0].COTIZACION, IdSistemaRAM);

            //agregar la 
            try {
                MetodosAjax.AgregarDictamenMedicoDocumentumARam(FolioRAM, cotiza.value.Tables[4].Rows[0].COTIZACION, IdSistemaRAM);
            }
            catch (err) {

            }

            //--------------------

            habilitarCtrl("btnEmite", false);
            habilitarCtrl("btnModDatos", false);
            document.getElementById("HiddenFolioRAM").value = FolioRAM;
            document.getElementById("HiddenIDSistemaRAM").value = IdSistemaRAM;
            document.getElementById("lblEncPoliza").innerText = "Solicitud"//
            document.getElementById("lblPolizaSoli").innerText = "Su Número de Solicitud es:"
            document.getElementById("lblNoPoliza").innerText = cotiza.value.Tables[4].Rows[0].COTIZACION;
            document.getElementById("HiddenNoSolPol").innerText = cotiza.value.Tables[4].Rows[0].COTIZACION;

            // <--- C8 --->

            if (document.getElementById("rbtnListPolizaContrato_0").checked)
                habilitarCtrl("btnImprimeSolicitud", true);

            habilitarCtrl("btnImprimePoliza", false);
            habilitarCtrl("btnImprimeSolicitud", false);
            habilitarCtrl("btnNuevaSolicitud", true);
            // <---------->

            var Asunto = "SOLICITUD " + document.getElementById("lblNoPoliza").innerText;
            var EmailTo = document.getElementById("HiddenEmailAgente").value;

            //--->C5<---
            var funcionEmail = "EnviarCorreoAAgente('" + Asunto + "','" + EmailTo + "');";
            eval(funcionEmail);

            //ToDo: aqui va la parte de la solicitud(dictamen)

            setRespuestasCuestionario();
            var cuestionarioRespuestas = document.getElementById("HiddenRespuestasCuestionario").value;
            var hiddenNoSolPol = document.getElementById("HiddenNoSolPol").value;
            //HHAC 20/01/2015 se comenta para que no adjunte el cuestionario
            //MetodosAjax.AnexarDocRamC(cuestionarioRespuestas, hiddenNoSolPol, IdSistemaRAM);
        }
    }
    else alert(cotiza.error.description);
    Cargando(false);
}

function getEmision_CallBack(poliza) {

    if (poliza.error == null) {
        if (poliza != null && poliza.value != null) {
            //'C28           
            var Mensaje1 = "“Hago constar que el cliente act\u00faa en nombre y cuenta propia o con las facultades suficientes otorgadas por su representada(do); y  que los recursos utilizados en la o las operaciones provienen de actividades l\u00edcitas”.";
            alert(Mensaje1);
            //'C28F

            var str = poliza.value;
            var n = str.split("|");

            //var arrEmision = new Array();
            var Poliza = n[0];
            var FolioRAM = n[1];
            var IdSistemaRAM = n[2];


            //------------------> C15 <------------ documentum folio ram
            var documentos = document.getElementById("grdAdjuntarArchivo");
            document.getElementById("HiddenIDSistemaRAM").value = IdSistemaRAM;
            var archivos = "";

            if (documentos != null) {
                for (var i = 1; i < documentos.rows.length; i++) {
                    archivos = archivos + documentos.rows[i].cells[0].innerHTML + ",";
                }
            }

            try {
                MetodosAjax.AgregarFolioDocumentum(archivos, FolioRAM, Poliza, IdSistemaRAM);
                //--------------------
            }
            catch (err) {
            }

            //MGM_MSI
            //if (document.getElementById("chkMSI").checked = true)
            if (MSI == "S") {
            }
            else {
                var Mensaje = "SU N\u00daMERO DE P\u00d3LIZA ES: " + Poliza + " Y EL FOLIO RAM ES : " + FolioRAM;
                alert(Mensaje);
            }

            habilitarCtrl("btnEmite", false);
            document.getElementById("HiddenFolioRAM").value = FolioRAM;
            document.getElementById("HiddenNoSolPol").innerText = Poliza;
            document.getElementById("lblNoPoliza").innerText = Poliza;

            habilitarCtrl("btnModDatos", false);

            // <--- C8 --->
            if (document.getElementById("rbtnListPolizaContrato_1").checked) {
                var ramo = document.getElementById("HiddenRamoRequest").value;
                var modalidad = document.getElementById("HiddenModalidad").value;
                var contrato = getNumContrato();
                var imprime = MetodosAjax.validaImpresion(contrato, ramo, modalidad);

                if (imprime != null && imprime.value != null) {
                    var validaImpresion = imprime.value.p_imprime_sol;
                    if (validaImpresion == "S")
                        habilitarCtrl("btnImprimeSolicitud", true);
                }
            }

            //C16
            habilitarCtrl("btnImprimePoliza", true);
            habilitarCtrl("btnNuevaSolicitud", true);

            var Asunto = "PÓLIZA " + document.getElementById("lblNoPoliza").innerText;
            var EmailTo = document.getElementById("HiddenEmailAgente").value;

            //--->C5<---
            var funcionEmail = "EnviarCorreoAAgente('" + Asunto + "','" + EmailTo + "');";
            eval(funcionEmail);

            //var sector = 1;
            //var usuario = document.getElementById("HiddenUsuario").value;
            //var agente = document.getElementById("HiddenAgente").value;
            //var correo = manejoLabel("UscAsegCLM_lblCorreo");
            //var urlPoliza = '/impresionSeGA/TWImpPolizaMarco.aspx?noPoliza=' + Poliza + '&sector=' + sector + '&simpol=n&usuario=' + usuario + '&agente=' + agente + '&eMail=' + correo;
            //document.getElementById("frmImpresionArchivo").src = urlPoliza;

            //agregar la poliza a ram
            try {
                MetodosAjax.AgregarPolizaDocumentumARam(Poliza, '', 'n', FolioRAM, Poliza, IdSistemaRAM);
            }
            catch (err) { }

            setRespuestasCuestionario();
            var cuestionarioRespuestas = document.getElementById("HiddenRespuestasCuestionario").value;
            var hiddenNoSolPol = document.getElementById("HiddenNoSolPol").value;
            //HHAC 20/01/2015 se comenta para que no adjunte el cuestionario
            //MetodosAjax.AnexarDocRamC(cuestionarioRespuestas, hiddenNoSolPol, IdSistemaRAM);
            var relacion = "";
            var nacionalidad = manejoLabel("UscAsegCLM_lblNacionalidad");
            var Fuma = selValorCtrl("drpFuma");
            var Ocupacion = selValorCtrl("drpOcupacion");
            var RamoDesc = document.getElementById("HiddenRamoDescripcion").value;
            var Plazo = selValorCtrl("drpPlazo");
            var Peso = document.getElementById("txtPeso").value;
            var Estatura = document.getElementById("txtEstatura").value;
            var Edad = document.getElementById("txtEdad").value;

            var RelSol = Array();
            RelSol[0] = nacionalidad + "|" +
                Fuma + "|" +
                Ocupacion + "|" +
                RamoDesc + " " + Plazo + "|" +
                Peso + "|" +
                Estatura + "|" +
                Edad + "|";

            relacion = RelSol[0];
            try {
                MetodosAjax.AgregarSolicitud(Poliza, relacion, FolioRAM, IdSistemaRAM);
            }
            catch (err) { }

            //MGM_MSI
            //if (document.getElementById("chkMSI").checked = true)
            if (MSI == "S") {
                habilitarCtrl("btnImprimeSolicitud", false);
                habilitarCtrl("btnImprimePoliza", false);
                document.getElementById("lblNoPoliza").style.display = 'none';
                abreCobranza();
                Cargando(false);
                return;
            }
        }
    }
    else alert(poliza.error.description);

    //ToDo: Mostrar Boton Solicitud
    var configSolicitudDB = validarImprimePolizaSolicitud();
    var seleccionUsuario = validarCuestionario();
    if (configSolicitudDB)
        if (!seleccionUsuario) {
            habilitarCtrl("btnImprimeSolicitud", false);
            document.getElementById("HiddenModoEmision").value = "P";
        }
        else {
            habilitarCtrl("btnImprimeSolicitud", true);
            document.getElementById("HiddenModoEmision").value = "S";
        }
    else
        if (!seleccionUsuario) {
            habilitarCtrl("btnImprimeSolicitud", false);
            document.getElementById("HiddenModoEmision").value = "P";
        }
        else {
            habilitarCtrl("btnImprimeSolicitud", true);
            document.getElementById("HiddenModoEmision").value = "S";
        }

    Cargando(false);
    MetodosAjax.BorraSessionAsegurados("Asegurados");
    MetodosAjax.BorraSessionAsegurados("coberturas");
}

function ValidarEmision() {
    if (document.getElementById("divCuestionarioMillon").innerHTML != "") {
        /*Validacion nuevas RAM*/
        if (validarRAM()) {
            return "C";
        }
    }

    //Validacion Funcion Publica
    if (validarFuncionPublica()) {
        return "C";
    }

    //----->C22<-----
    if (!validarExamen()) {
        return "C";
    }

    if (!validarSumaAseguradaBasica()) {
        return "C";
    }

    if (!validarCumulos()) {
        return "P";
    }

    //<--- C7 --->
    if (!validarImprimePolizaSolicitud()) {
        return "C";
    }

    if (!validarOcupacion()) {
        return "C";
    }

    if (!validarIMC()) {
        return "C";
    }

    if (!validarDeporte()) {
        return "C";
    }

    if (!validarCuestionario()) {
        return "C";
    }



    return "P";
}

//<--- C7 --->
/// <summary>
///     Método que valida si se realiza una póliza o una solicitud.
/// </summary>
function validarImprimePolizaSolicitud() {
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = getNumContrato();
    var MarcaValidacion;

    var imprimePolizaSolicitud = MetodosAjax.validaImprimePolizaSolicitud(ramo, modalidad, contrato);

    if (imprimePolizaSolicitud.error == null) {
        if (imprimePolizaSolicitud != null && imprimePolizaSolicitud.value != null) {
            MarcaValidacion = imprimePolizaSolicitud.value.p_poli_soli;

            if (MarcaValidacion == "S")
                return true //Emite (Poliza)
            else
                return false //Cotiza (Solicitud)
        }
    }
    else {
        alert(imprimePolizaSolicitud.error.description);
        return false;
    }
}

function validarSumaAseguradaBasica() {
    //----------------->C13<-----------------
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = getNumContrato();

    var Moneda = selValorCtrl("drpMoneda");
    var SumaAsegBasica;


    var arrDatosAseg = AseguradosType()[0];
    if (arrDatosAseg) {
        datosAsegurado = arrDatosAseg.split("|");
    }


    try {
        SumaAsegBasica = datosAsegurado[3].replace(",", "");
    }
    catch (err) {

        if (document.getElementById("chk1") != null) {
            if (document.getElementById("chk1").checked) {
                var CodCob = document.getElementById("chk1").value;
                if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                    sumAseg = sumAseg + parseFloat(document.getElementById("txtSuma" + CodCob).value);
                }
            }

            if (document.getElementById("chk2").checked) {
                var CodCob = document.getElementById("chk2").value;
                if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                    sumAseg = sumAseg + parseFloat(document.getElementById("txtSuma" + CodCob).value);
                }
            }
            if (document.getElementById("chk3").checked) {
                var CodCob = document.getElementById("chk3").value;
                if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                    sumAseg = sumAseg + parseFloat(document.getElementById("txtSuma" + CodCob).value);
                }
            }
            if (document.getElementById("chk4").checked) {
                var CodCob = document.getElementById("chk4").value;
                if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                    sumAseg = sumAseg + parseFloat(document.getElementById("txtSuma" + CodCob).value);
                }
            }

        }
    }
    var SumaBasica;
    //try {
    if (Moneda == 2) {
        SumaHasta = 150000;
    }

    if (Moneda == 6) {
        SumaHasta = 380000;
    }

    if (SumaAsegBasica < SumaHasta) {
        SumaBasica = SumaAsegBasica;
        return true;
    } else {
        alert(`La suma asegurada no puede ser mayor a ${SumaHasta}`);
        return false;
    }

    //MetodosAjax.validaSumaBasica(ramo, modalidad, contrato, Moneda, parseInt(SumaAsegBasica));
    //}
    //catch (err) { }
    //if (SumaBasica.error == null) {
    //    if (SumaBasica != null && SumaBasica.value != null) {
    //        var MarcaValidacion = SumaBasica.value.p_mca_valido;
    //        if (MarcaValidacion == "S")
    //            return true; //Emite (Poliza)
    //        else {
    //            //------->C25<-------
    //            alert(SumaBasica.value.p_error);
    //            return false;  //Cotiza (Solicitud)
    //        }
    //    }
    //}
    //else {
    //    alert(SumaBasica.error.description);
    //    return false;
    //}
}

//--->C6<---
/// <summary>
///     Obtiene el numero del contrato seleccionado o el numero genérico si no se ha seleccionado alguno.
/// </summary>
function getNumContrato() {
    var contrato = document.getElementById("HiddenContratoGenerico").value;

    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    return contrato;
}

function validarCumulos() {
    //------------------->C14<-------------------

    //var aseg = getNumAsegurado();
    var Edad = AseguradosType()[0].split("|")[0];
    var tablaAsegurados = MetodosAjax.setAsegurados();


    var ramo = document.getElementById("HiddenRamoRequest").value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = getNumContrato();
    var moneda = document.getElementById("drpMoneda").value;
    var nombre = tablaAsegurados.value.Rows[0].nombre; // valorCtrl("UscAsegCLM_lblNombre");
    var apellidoPat = tablaAsegurados.value.Rows[0].paterno //valorCtrl("UscAsegCLM_lblApellidoPaterno");
    var apellidoMat = tablaAsegurados.value.Rows[0].materno //valorCtrl("UscAsegCLM_lblApellidoMaterno");
    var fecNac = tablaAsegurados.value.Rows[0].fec_nac //valorCtrl("UscAsegCLM_lblNacimiento");

    var sumAseg = 0;
    var tbCoberturas = document.getElementById("Coberturas");
    var sumaValor = 0;

    /* Se realiza cambio a petición de usuario apl-09122014
       La suma asegurada tiene que ser igual a la cobertura básica.
       Texto original de petición : "ya podemos emitir la mayoría de los ramos, está pendiente que nos corrijan la parte de cúmulos ya que el sistema esta sumando las SA de todas las coberturas adicionales"

    for (var i = 1; i <= tbCoberturas.rows.length; i++) 
    {
        if (document.getElementById("chk" + i) != null) 
        {
            if (document.getElementById("chk" + i).checked) 
            {
                var CodCob = document.getElementById("chk" + i).value;

                if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) 
                {
                    sumaValor = parseFloat(document.getElementById("txtSuma" + CodCob).value);
                    sumAseg = sumAseg + sumaValor; 
                }  
            }
        }
    }
    */

    var arrDatosAseg = AseguradosType()[0];
    if (arrDatosAseg) {
        datosAsegurado = arrDatosAseg.split("|");
    }

    /* Solo se toma en cuenta la cobertura básica*/
    //if (document.getElementById("chk1") != null) {
    //  if (document.getElementById("chk1").checked) {
    //    var CodCob = document.getElementById("chk1").value;
    //  if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
    sumAseg = datosAsegurado[3].replace(",", ""); //parseFloat(document.getElementById("txtSuma" + CodCob).value);
    //}
    //}
    //}



    var Cumulos = MetodosAjax.validaCumulos(ramo, modalidad, contrato, moneda, parseInt(Edad), nombre, apellidoPat, apellidoMat, fecNac, sumAseg);

    if (Cumulos.error == null) {
        if (Cumulos != null && Cumulos.value != null) {
            var MarcaValidacion = Cumulos.value.p_mca_valido;
            if (MarcaValidacion == "S")
                return true; //Emite (Poliza)
            else

                return false;  //Cotiza (Solicitud)
        }
    }
    else {
        alert(Cumulos.error.description);
        return false;

    }
}

function validarFuncionPublica() {
    var funcionPublica = document.getElementById('chkSiCargoP').checked;
    if (funcionPublica) {
        return true;
    }
}

//Validaciones nuevas suscripcion
function validarRAM() {
    //Validacion Función Pública
    var funcionPublica = document.getElementById('chkSiCargoP').checked;
    if (funcionPublica) {
        return true;
    }
    //Validaciones Maq, Herra, Sust, Vehi
    var maq = $('#txtTipoMaquinas').val();
    if ((maq != 'SELECCIONE')) {
        if (maq != 'NINGUNA DE LAS ANTERIORES') {
            return true;
        }

    }
    //Validaciones otra ocupacion
    var ocupacion = document.getElementById('chkSiOtraOcupacion').checked;
    if (ocupacion) {
        return true;
    }
    //Validaciones aeronaves particulares
    var aeronaves = document.getElementById('chkSiAParticular').checked;
    if (aeronaves) {
        return true;
    }
    //Validaciones motocicleta
    var moto = document.getElementById('chkSiMotocicleta').checked;
    if (moto) {
        return true;
    }
    //Validaciones trabaja altura
    var altura = document.getElementById('chkSiAlturas').checked;
    if (altura) {
        return true;
    }
    //Validaciones lugar de trabajo
    var lugarTrabajo = $('#txtLugarTrabajo').val();
    if (lugarTrabajo == 'TALLER' || lugarTrabajo == 'FABRICA' || lugarTrabajo == 'OTRO') {
        return true;
    }
    //Validaciones practica deporte o aficion
    var deporte = $('#txtDeporte').val();
    if (deporte != 'NINGUNO') {
        return true;
    }
    //Validaciones bebida alcoholicas
    var cantidad = $('#txtCantBebida').val();
    var frecuencia = $('#txtFrecuenciaBebida').val();
    if (frecuencia == 'DIARIA') {
        if (parseInt(cantidad) >= 8) {
            return true;
        }

    } else if (frecuencia == "SEMANAL") {
        if (parseInt(cantidad) >= 56) {
            return true;
        }
    } else if (frecuencia == "MENSUAL") {
        if (parseInt(cantidad) >= 240) {
            return true;
        }
    }
    //Validaciones cantidad fumar
    var cantidadFumar = $('#txtCantidadFumar').val();
    if (cantidadFumar != "SELECCIONE") {
        if (parseInt(cantidadFumar) > 20) {
            return true;
        }
    }
    //Validaciones drogas
    var drogas = document.getElementById('chkSiDroga').checked;
    if (drogas) {
        return true;
    }
    //Validaciones pregunta 1
    var pregunta1 = document.getElementById('chk1Si').checked;
    if (pregunta1) {
        return true;
    }
    //Validaciones pregunta 3
    var pregunta3 = document.getElementById('chk3Si').checked;
    if (pregunta3) {
        return true;
    }
    //Validaciones pregunta 5
    var pregunta5 = document.getElementById('chk5Si').checked;
    if (pregunta5) {
        return true;
    }

}
//----->C22<-----
/// <summary>
///     Obtiene los exámenes que se deben realizar.
/// </summary>
function validarExamen() {
    //var aseg = getNumAsegurado();
    var Edad = AseguradosType()[0].split("|")[0];
    var tablaAsegurados = MetodosAjax.setAsegurados();
    // OBTENER AQUI LOS DATOS DEL QUE TIENE COBERTURA BASICA QUE SON LOS PRIMEROS 4 PERO SETEAREMOS EL 0
    var moneda = document.getElementById("drpMoneda").value;
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = getNumContrato();
    var nombre = tablaAsegurados.value.Rows[0].nombre; // valorCtrl("UscAsegCLM_lblNombre");
    var apellidoPat = tablaAsegurados.value.Rows[0].paterno //valorCtrl("UscAsegCLM_lblApellidoPaterno");
    var apellidoMat = tablaAsegurados.value.Rows[0].materno //valorCtrl("UscAsegCLM_lblApellidoMaterno");
    var fecNac = tablaAsegurados.value.Rows[0].fec_nac //valorCtrl("UscAsegCLM_lblNacimiento");

    var sumAseg = 0;
    var tbCoberturas = document.getElementById("Coberturas");
    var sumaValor = 0;

    /* Se realiza cambio a petición de usuario apl-09122014
       La suma asegurada tiene que ser igual a la cobertura básica.
       Texto original de petición : "ya podemos emitir la mayoría de los ramos, está pendiente que nos corrijan la parte de cúmulos ya que el sistema esta sumando las SA de todas las coberturas adicionales"

    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            if (document.getElementById("chk" + i).checked) {
                var CodCob = document.getElementById("chk" + i).value;

                if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                    sumaValor = parseFloat(document.getElementById("txtSuma" + CodCob).value);
                    sumAseg = sumAseg + sumaValor;
                }  
            }
        }
    }
*/
    /* Solo se toma en cuenta la cobertura básica*/
    if (AseguradosType()[0].split("|")[2] == "BASICA") {
        sumAseg = sumAseg + parseFloat(AseguradosType()[0].split("|")[3].replace(",", ""));
    }


    var examenes = MetodosAjax.validaExamenes(ramo, modalidad, contrato, moneda, Edad, sumAseg, nombre, apellidoMat, apellidoPat, fecNac);

    if (examenes.error == null) {
        if (examenes != null && examenes.value != null) {
            var examen = examenes.value.p_mensaje;
            if (examen != "") {
                //------->C24<-------
                if (examen.indexOf("NO SE ENCUENTRA INFORMACIÓN") != -1) {
                    alert("NO EXISTEN DATOS CONFIGURADOS PARA EL TIPO DE EXAMEN SEGUN LOS PAR\u00c1METROS INGRESADOS.");
                    return true;
                }
                else {
                    alert("DE ACUERDO AL MONTO DE SUMA ASEGURADA, LE CORRESPONDE UN EXAMEN TIPO: " + examenes.value.p_mensaje);
                    var aux = examenes.value.p_mensaje;
                    if (aux.substring(0, 1) == "A")
                        return true;
                    else
                        return false;
                }
            }
            else {
                alert("NO EXISTEN DATOS CONFIGURADOS PARA EL TIPO DE EXAMEN");
                return false;
            }
        }
    }
    else {
        alert(examenes.error.description);
        return false;

    }
}

function validarOcupacion() {

    if (document.getElementById("HiddenRamoRequest").value == "105") {
        if (document.getElementById("rdoMenor").checked) {
            return true;
        }
    }

    var Ocupacion = selValorCtrl("drpOcupacion");
    var valOcupacion = MetodosAjax.validaOcupacion(Ocupacion);
    if (Ocupacion == 0) {
        return true;
    }
    if (valOcupacion.error == null) {
        if (valOcupacion != null && valOcupacion.value != null) {
            var MarcaValidacion = valOcupacion.value.p_mca_valido;
            if (MarcaValidacion == "S")
                return true //Emite (Poliza)
            else
                return false //Cotiza (Solicitud)
        }
    }
    else {
        alert(valOcupacion.error.description);
        return false;
    }
}

function validarIMC() {

    var Peso = valorCtrl("txtPeso");
    var Estatura = valorCtrl("txtEstatura");
    if (Peso == "") {
        return true
    }
    if (Estatura == "") {
        return true;
    }
    var valIMC = MetodosAjax.validaIMC(Peso, Estatura);
    if (valIMC.error == null) {
        if (valIMC != null && valIMC.value != null) {
            var MarcaValidacion = valIMC.value.p_mca_valido;
            if (MarcaValidacion == "S")
                return true //Emite (Poliza)
            else
                return false //Cotiza (Solicitud)
        }
    }
    else {
        alert(valIMC.error.description);
        return false;
    }
}

function validarDeporte() {
    if (document.getElementById("chkboxSi").checked == true) {
        return false;//Cotiza (Solicitud)
    }
    return true;//Emite (Poliza)CallBack
}

function validarCuestionarioFirma() {
    var banderaMenores = false;
    if (document.getElementById("rdoMenor").checked) {
        banderaMenores = true;
    }
    if (valCuestionario() && banderaMenores) {
        return false;//Cotiza (Solicitud)
    }
    return true;//Emite (Poliza)
}

function validarCuestionario() {
    var tablaAsegurados = MetodosAjax.setAsegurados();
    var banderaMenores;
    for (var i = 0; i < tablaAsegurados.value.Rows.length; i++) {
        if (tablaAsegurados.value.Rows[i].parentesco != "Menor") {
            banderaMenores = true;
        }
    }
    if (valCuestionario() && banderaMenores) {
        return false;//Cotiza (Solicitud)
    }
    return true;//Emite (Poliza)
}

function valCuestionario() {
    var adicionales = false;
    for (var i = 2; i < 12; i++) {
        if (document.getElementById('chk' + i) != null) {
            if (document.getElementById('chk' + i).checked) {
                adicionales = true;
                break;
            }
        }
    }
    var numPreg = document.getElementById("gvCuestionario").rows.length - 1;
    for (var preg = 1; preg <= numPreg; preg++) {

        if (preg > 13) {
            if (document.getElementById("chkSi" + preg).checked) {
                return false;
            }
            if (document.getElementById("chkNo" + preg).checked) {
                return false;
            }
        }

        if ($('#HiddenRamoRequest').val() == '101' && adicionales) {
            if (document.getElementById("chkSi" + preg).checked) {
                return true;
            }
        }
        if ($('#HiddenRamoRequest').val() != '101') {
            if (document.getElementById("chkSi" + preg).checked) {
                return true;
            }
        }

    }
    return false;
}

function ValidaDatosFirma() {
    var resValidacion = ValidarFirma();
    if (resValidacion == "P") {
        //Mostrar firma digital
        //document.getElementById("divFirma").style.display = "block";
        if (document.getElementById("rdoMenor").checked) {
            document.getElementById("divChkConf2").style.visibility = "visible";
            document.getElementById("chkboxSiFirma2").checked = false;
            document.getElementById("chkboxNoFirma2").checked = false;
        } else {
            document.getElementById("divChkConf").style.visibility = "visible";
            document.getElementById("chkboxSiFirma").checked = false;
            document.getElementById("chkboxNoFirma").checked = false;

            document.getElementById("divChkConf2").style.display = "none";
            document.getElementById("chkboxSiFirma2").checked = false;
            document.getElementById("chkboxNoFirma2").checked = false;
            document.getElementById("chkboxSiFirma2").style.display = "none";
            document.getElementById("chkboxNoFirma2").style.display = "none";

        }
        
        document.getElementById("divEmite").style.display = "none";
        document.getElementById("divEmiteTxt").style.display = "none";
        document.getElementById("divEmiteAdj").style.display = "none";
        document.getElementById("divDivDocumentosAdjuntar2").style.visibility = "hidden";
    }
    else {
        //Ocultar firma digital
        //document.getElementById("divCuestionarioMillon").innerHTML = "";
        document.getElementById("divEmite").style.display = "block";
        document.getElementById("divFirma").style.display = "none";
        //document.getElementById("divChkConf").style.visibility = "hidden";
        document.getElementById("chkboxSiFirma").checked = false;
        document.getElementById("chkboxNoFirma").checked = false;
        document.getElementById("divEmiteTxt").style.display = "block";
        document.getElementById("divEmiteAdj").style.display = "block";
        if (document.getElementById("hdnDivAdj2").value == "1") { document.getElementById("divDivDocumentosAdjuntar2").style.visibility = "visible"; }
        else { document.getElementById("divDivDocumentosAdjuntar2").style.visibility = "hidden"; }
    }
}

function ValidarFirma() {
    if (!validarExamenFirma()) {
        return "C";
    }

    if (!validarSumaAseguradaBasicaFirma()) {
        return "C";
    }

    if (!validarCumulosFirma()) {
        return "C";
    }

    //<--- C7 --->
    if (!validarImprimePolizaSolicitudFirma()) {
        return "C";
    }

    if (!validarOcupacionFirma()) {
        return "C";
    }

    if (!validarIMCFirma()) {
        return "C";
    }

    if (!validarDeporte()) {
        return "C";
    }

    if (!validarCuestionario()) {
        return "C";
    }

    return "P";
}

function validarExamenFirma() {
    var Edad = document.getElementById("txtEdad").value;

    var ramo = document.getElementById("HiddenRamoRequest").value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = getNumContrato();
    var moneda = document.getElementById("drpMoneda").value;
    var nombre = valorCtrl("UscAsegCLM_lblNombre");
    var apellidoPat = valorCtrl("UscAsegCLM_lblApellidoPaterno");
    var apellidoMat = valorCtrl("UscAsegCLM_lblApellidoMaterno");
    var fecNac = valorCtrl("UscAsegCLM_lblNacimiento");
    var sumAseg = 0;
    var tbCoberturas = document.getElementById("Coberturas");
    var sumaValor = 0;

    /* Solo se toma en cuenta la cobertura básica*/
    if (document.getElementById("chk1") != null) {
        if (document.getElementById("chk1").checked) {
            var CodCob = document.getElementById("chk1").value;
            if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                sumAseg = sumAseg + parseFloat(document.getElementById("txtSuma" + CodCob).value);
            }
        }
    }

    var examenes = MetodosAjax.validaExamenes(ramo, modalidad, contrato, moneda, Edad, sumAseg, nombre, apellidoMat, apellidoPat, fecNac);

    if (examenes.error == null) {
        if (examenes != null && examenes.value != null) {
            var examen = examenes.value.p_mensaje;
            if (examen != "") {
                //------->C24<-------
                if (examen.indexOf("NO SE ENCUENTRA INFORMACIÓN") != -1) {
                    return true;
                }
                else {
                    var aux = examenes.value.p_mensaje;
                    if (aux.substring(0, 1) == "A")
                        return true;
                    else
                        return false;
                }
            }
            else {
                return false;
            }
        }
    }
    else {
        return false;

    }
}

function validarOcupacionFirma() {
    var Ocupacion = selValorCtrl("drpOcupacion");
    var valOcupacion = MetodosAjax.validaOcupacion(Ocupacion);
    if (Ocupacion == 0) {
        return true;
    }
    if (valOcupacion.error == null) {
        if (valOcupacion != null && valOcupacion.value != null) {
            var MarcaValidacion = valOcupacion.value.p_mca_valido;
            if (MarcaValidacion == "S")
                return true //Emite (Poliza)
            else
                return false //Cotiza (Solicitud)
        }
    }
    else {
        return false;
    }
}

function validarIMCFirma() {
    var Peso = valorCtrl("txtPeso");
    var Estatura = valorCtrl("txtEstatura");
    if (Peso == "") {
        return true
    }
    if (Estatura == "") {
        return true;
    }
    var valIMC = MetodosAjax.validaIMC(Peso, Estatura);
    if (valIMC.error == null) {
        if (valIMC != null && valIMC.value != null) {
            var MarcaValidacion = valIMC.value.p_mca_valido;
            if (MarcaValidacion == "S")
                return true //Emite (Poliza)
            else
                return false //Cotiza (Solicitud)
        }
    }
    else {
        return false;
    }
}

function validarCumulosFirma() {
    //------------------->C14<-------------------

    var Edad = document.getElementById("txtEdad").value;

    var ramo = document.getElementById("HiddenRamoRequest").value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = getNumContrato();
    var moneda = document.getElementById("drpMoneda").value;
    var nombre = valorCtrl("UscAsegCLM_lblNombre");
    var apellidoPat = valorCtrl("UscAsegCLM_lblApellidoPaterno");
    var apellidoMat = valorCtrl("UscAsegCLM_lblApellidoMaterno");
    var fecNac = valorCtrl("UscAsegCLM_lblNacimiento");
    var sumAseg = 0;
    var tbCoberturas = document.getElementById("Coberturas");
    var sumaValor = 0;

    /* Solo se toma en cuenta la cobertura básica*/
    if (document.getElementById("chk1") != null) {
        if (document.getElementById("chk1").checked) {
            var CodCob = document.getElementById("chk1").value;
            if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                sumAseg = parseFloat(document.getElementById("txtSuma" + CodCob).value);
            }
        }
    }
    var Cumulos = MetodosAjax.validaCumulos(ramo, modalidad, contrato, moneda, Edad, nombre, apellidoPat, apellidoMat, fecNac, sumAseg);

    if (Cumulos.error == null) {
        if (Cumulos != null && Cumulos.value != null) {
            var MarcaValidacion = Cumulos.value.p_mca_valido;
            if (MarcaValidacion == "S")
                return true; //Emite (Poliza)
            else

                return false;  //Cotiza (Solicitud)
        }
    }
    else {
        return false;

    }
}

function validarImprimePolizaSolicitudFirma() {
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = getNumContrato();
    var MarcaValidacion;

    var imprimePolizaSolicitud = MetodosAjax.validaImprimePolizaSolicitud(ramo, modalidad, contrato);

    if (imprimePolizaSolicitud.error == null) {
        if (imprimePolizaSolicitud != null && imprimePolizaSolicitud.value != null) {
            MarcaValidacion = imprimePolizaSolicitud.value.p_poli_soli;

            if (MarcaValidacion == "S")
                return true //Emite (Poliza)
            else
                return false //Cotiza (Solicitud)
        }
    }
    else {
        return false;
    }
}

function validarSumaAseguradaBasicaFirma() {
    //----------------->C13<-----------------
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = getNumContrato();

    var Moneda = selValorCtrl("drpMoneda");
    var SumaAsegBasica;



    try {
        SumaAsegBasica = document.getElementById("txtSuma1000").value;
    }
    catch (err) {

        if (document.getElementById("chk1") != null) {
            if (document.getElementById("chk1").checked) {
                var CodCob = document.getElementById("chk1").value;
                if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                    sumAseg = sumAseg + parseFloat(document.getElementById("txtSuma" + CodCob).value);
                }
            }

            if (document.getElementById("chk2").checked) {
                var CodCob = document.getElementById("chk2").value;
                if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                    sumAseg = sumAseg + parseFloat(document.getElementById("txtSuma" + CodCob).value);
                }
            }
            if (document.getElementById("chk3").checked) {
                var CodCob = document.getElementById("chk3").value;
                if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                    sumAseg = sumAseg + parseFloat(document.getElementById("txtSuma" + CodCob).value);
                }
            }
            if (document.getElementById("chk4").checked) {
                var CodCob = document.getElementById("chk4").value;
                if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                    sumAseg = sumAseg + parseFloat(document.getElementById("txtSuma" + CodCob).value);
                }
            }

        }
    }
    var SumaBasica;
    try {
        SumaBasica = MetodosAjax.validaSumaBasica(ramo, modalidad, contrato, Moneda, SumaAsegBasica);
    }
    catch (err) { }
    if (SumaBasica.error == null) {
        if (SumaBasica != null && SumaBasica.value != null) {
            var MarcaValidacion = SumaBasica.value.p_mca_valido;
            if (MarcaValidacion == "S")
                return true; //Emite (Poliza)
            else {
                //------->C25<-------
                return false;  //Cotiza (Solicitud)
            }
        }
    }
    else {
        return false;
    }
}
//--->C5<---
function EnviarCorreoAAgente(Asunto, EmailTo) {
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = getNumContrato();

    MetodosAjax.EnviarCorreo(ramo, modalidad, contrato, Asunto, EmailTo);
}

function PreguntaDeportes(objCheck) {
    if (objCheck.id == "chkboxSi")
        document.getElementById("chkboxNo").checked = false;
    else
        document.getElementById("chkboxSi").checked = false;
}

function PreguntasSiNo(objCheck, chkSi, chkNo) {
    if (objCheck.id == chkSi) {
        document.getElementById(chkNo).checked = false;
    }
    else {
        document.getElementById(chkSi).checked = false;
    }

    if (objCheck.id == "chkSiRiesgo") {
        alert('Por favor solicite el cuestionario correspondiente');
    }

    if (objCheck.id == "chkSiOtraOcupacion") {
        $("#divConsiste").removeAttr('hidden');
        LlenarOcupacion("txtOtraOcupacion");
    } else if (objCheck.id == "chkNoOtraOcupacion") {
        $("#divConsiste").attr('hidden', true);
    }

    if (objCheck.id == "chkSiViajar") {
        $("#divTipoTransporte").removeAttr('hidden');
    } else if (objCheck.id == "chkNoViajar") {
        $("#divTipoTransporte").attr('hidden', true);
        $('#divAeronaves').attr('hidden', true);
    }

    if (objCheck.id == "chkSiAParticular") {
        $('#divEspecifiqueAeronave').removeAttr('hidden');
    } else if (objCheck.id == "chkNoAParticular") {
        $('#divEspecifiqueAeronave').attr('hidden', true);
    }

    if (objCheck.id == "chkSiMotocicleta") {
        $('#divMotoFrecuencia').removeAttr('hidden');
    } else if (objCheck.id == "chkNoMotocicleta") {
        $('#divMotoFrecuencia').attr('hidden', true);
    }

    if (objCheck.id == "chkSiAlturas") {
        $('#divIndicarAltura').removeAttr('hidden');
    } else if (objCheck.id == "chkNoAlturas") {
        $('#divIndicarAltura').attr('hidden', true);
    }

    if (objCheck.id == "chkSiDroga") {
        $('#divTipoFrecuencia').removeAttr('hidden');
    } else if (objCheck.id == "chkNoDroga") {
        $('#divTipoFrecuencia').attr('hidden', true);
    }

    if (objCheck.id == "chk7Si") {
        $('#txt7Causa').removeAttr('hidden');
        $('#divtxtNomDomMedico').removeAttr('hidden');
        $('#divtxtNHospital').removeAttr('hidden');
        $('#divtblRefPersonales').removeAttr('hidden');
        $('#idRefPersonales').removeAttr('hidden');
    } else if (objCheck.id == "chk7No") {
        $('#txt7Causa').attr('hidden', true);
        $('#divtxtNomDomMedico').attr('hidden', true);
        $('#divtxtNHospital').attr('hidden', true);
        $('#divtblRefPersonales').attr('hidden', true);
        $('#idRefPersonales').attr('hidden', true);
    }

    if (objCheck.id == "chk1Si") {
        $('#txt1Causa').removeAttr('disabled');
    } else if (objCheck.id == "chk1No") {
        $('#txt1Causa').attr('disabled', true);
    }

    if (objCheck.id == "chk2Si") {
        $('#txt2Causa').removeAttr('disabled');
        $('#txt2Cuando').removeAttr('disabled');
    } else if (objCheck.id == "chk2No") {
        $('#txt2Causa').attr('disabled', true);
        $('#txt2Cuando').attr('disabled', true);
    }

    if (objCheck.id == "chk3Si") {
        $('#txt3Causa').removeAttr('disabled');
        $('#txt3Cuando').removeAttr('disabled');
    } else if (objCheck.id == "chk3No") {
        $('#txt3Causa').attr('disabled', true);
        $('#txt3Cuando').attr('disabled', true);
    }

    if (objCheck.id == "chk4Si") {
        $('#txt4Causa').removeAttr('disabled');
        $('#txt4Cuando').removeAttr('disabled');
    } else if (objCheck.id == "chk2No") {
        $('#txt4Causa').attr('disabled', true);
        $('#txt4Cuando').attr('disabled', true);
    }

    if (objCheck.id == "chk5Si") {
        $('#txtKgAumentados').removeAttr('disabled');
        $('#txtKgDisminuidos').removeAttr('disabled');
    } else if (objCheck.id == "chk5No") {
        $('#txtKgAumentados').attr('disabled', true);
        $('#txtKgDisminuidos').attr('disabled', true);
    }
}

function ValidaMeses() {
    var meses = parseInt(document.getElementById("txt8Meses").value);
    if (meses > 9) {
        alert("El embarazo no puede ser mayor a 9 meses");
        document.getElementById("txt8Meses").value = "";
    }
}

function EstaEmbarazada(objCheck, chkSi, chkNo) {
    if (objCheck.id == chkSi) {
        document.getElementById(chkNo).checked = false;
        document.getElementById("txt8Meses").disabled = false;
        $('#divtxtNomDomMedico').removeAttr('hidden');
        $('#divtxtNHospital').removeAttr('hidden');
        $('#divtblRefPersonales').removeAttr('hidden');
        $('#idRefPersonales').removeAttr('hidden');
    }
    else {
        document.getElementById(chkSi).checked = false;
        document.getElementById("txt8Meses").disabled = true;
        $('#divtxtNomDomMedico').attr('hidden', true);
        $('#divtxtNHospital').attr('hidden', true);
        $('#divtblRefPersonales').attr('hidden', true);
        $('#idRefPersonales').attr('hidden', true);
    }
}

function PreguntaTrabajo(objCheck, chkOficina, chkFabrica, chkTaller, chkCalle) {
    switch (objCheck.id) {
        case chkOficina:
            document.getElementById(chkFabrica).checked = false;
            document.getElementById(chkTaller).checked = false;
            document.getElementById(chkCalle).checked = false;
            break;
        case chkFabrica:
            document.getElementById(chkOficina).checked = false;
            document.getElementById(chkTaller).checked = false;
            document.getElementById(chkCalle).checked = false;
            break;
        case chkTaller:
            document.getElementById(chkFabrica).checked = false;
            document.getElementById(chkOficina).checked = false;
            document.getElementById(chkCalle).checked = false;
            break;
        case chkCalle:
            document.getElementById(chkFabrica).checked = false;
            document.getElementById(chkTaller).checked = false;
            document.getElementById(chkOficina).checked = false;
            break;
    }

}

function PreguntaFormaDeporte(objCheck, chkDProfesional, chkDAficionado, chkDAmateur) {
    switch (objCheck.id) {
        case chkDProfesional:
            document.getElementById(chkDAficionado).checked = false;
            document.getElementById(chkDAmateur).checked = false;
            break;
        case chkDAficionado:
            document.getElementById(chkDProfesional).checked = false;
            document.getElementById(chkDAmateur).checked = false;
            break;
        case chkDAmateur:
            document.getElementById(chkDAficionado).checked = false;
            document.getElementById(chkDProfesional).checked = false;
            break;
    }

}
function PreguntaTipoFumar(objCheck, chkCigarros, chkPuro, chkPipa) {
    switch (objCheck.id) {
        case chkCigarros:
            document.getElementById(chkPuro).checked = false;
            document.getElementById(chkPipa).checked = false;
            break;
        case chkPuro:
            document.getElementById(chkCigarros).checked = false;
            document.getElementById(chkPipa).checked = false;
            break;
        case chkPipa:
            document.getElementById(chkPuro).checked = false;
            document.getElementById(chkCigarros).checked = false;
            break;
    }

}

function ActualizarEstadoRAM() {
    var modoEmision = document.getElementById("HiddenModoEmision").value;
    if (modoEmision == "P")
        MetodosAjax.setEstadoRAMCapturado();
    else {
        //verificar que ya exista el estatus de suscripción
    }
}

function testImprimirPoliza() {
    var Poliza = "1000010002312";
    var sector = 1;
    var usuario = document.getElementById("HiddenUsuario").value;
    var agente = document.getElementById("HiddenAgente").value;
    var correo = manejoLabel("UscAsegCLM_lblCorreo");
    var urlPoliza = '/impresionSeGA/TWImpPolizaMarco.aspx?noPoliza=' + Poliza + '&sector=' + sector + '&simpol=n&usuario=' + usuario + '&agente=' + agente + '&eMail=' + correo;
    document.getElementById("frmImpresionArchivo").src = urlPoliza;
    //window.open('/impresionSeGA/TWImpPolizaMarco.aspx?noPoliza=' + Poliza + '&sector=' + sector + '&simpol=n&usuario=' + usuario + '&agente=' + agente + '&eMail=' + correo, 'POLIZA', 'toolbar=false,scrollbars=1,resizable=0,width=800,height=680,left=30,top=30');
}

//function ConstruyeCuestionarioMillon() {
//    MetodosAjax.devuelveCuestionarioMillon(cuestionarioMillon_CallBack);
//}

//function cuestionarioMillon_CallBack(res) {
//    if (res.error == null) {
//        if (res != null && res.value != null) {
//            var newdiv = document.createElement("div");
//            newdiv.className = "col-12";
//            newdiv.innerHTML = res.value;
//            var container = document.getElementById("divCuestionarioMillon");
//            container.innerHTML = "";
//            container.appendChild(newdiv);

//            if (document.getElementById("divCuestionarioMillon").innerHTML == "")
//                document.getElementById("divCuestionarioMillon").innerHTML = res.value;

//            AjustarFrame();
//        }
//    }
//}

function FirmaElectronica(oper, ModoCotizacion) {
    if (ModoCotizacion = "Firma") {
        if (validaPaginaFirma("P")) {
            Cargando(true);
            var Modo = ValidarEmision();

            if (Modo != "C") {
                armaCadenaFirma(Modo, "SOLICITUD");
            }
            else {

                Cargando(false);
                alert("Las validaciones no son satisfactorias, favor de continuar el proceso por oficina, ¡gracias!");
                return;
            }
        }
    }
}

function OpenWindowWithPost(url, windowoption, name, params) {
    var form = document.createElement("form");
    form.setAttribute("method", "post");
    form.setAttribute("action", url);
    form.setAttribute("target", name);
    for (var i in params) {
        if (params.hasOwnProperty(i)) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = i;
            input.value = params[i];
            form.appendChild(input);
        }
    }

    document.body.appendChild(form);
    //note I am using a post.htm page since I did not want to make double request to the page 
    //it might have some Page_Load call which might screw things up.
    window.open(url, name, windowoption);
    form.submit();
    document.body.removeChild(form);
}

function envFirma(oper, ModoCotizacion, numCotizacion, nomContratante, nomAsegurado,nomMancomunado, cod_agt, ramo) {
    if (validaEnviarFirma()) {
        Cargando2(true);
        var mailContratante = document.getElementById("txtMailContratante").value;
        var mailAsegurado = "";
        if (nomAsegurado != "") {
            mailAsegurado = document.getElementById("txtMailAsegurado").value;
        }
        
        var mailMancomunado = "";
        if (nomMancomunado != "") {
            mailMancomunado = document.getElementById("txtMailAseguradoMancomunado").value;
        }
        var mailAgente = document.getElementById("txtMailAgente").value;
        MetodosAjax.EnviaFirma105(numCotizacion, nomContratante, nomAsegurado, nomAseguradoMancomunado, cod_agt, ramo, mailContratante, mailAsegurado, mailMancomunado, mailAgente, EnviaFirma_callback);
    }
}

function EnviaFirma_callback(res) {
    if (res.error == null) {
        if (res != null && res.value != null) {
            if (res.value.length > 0) {
                //Proceso exitoso
                document.getElementById("tdFolio").innerHTML = res.value.split('|')[1];
                document.getElementById("tdSolicitud").innerHTML = res.value.split('|')[0];
                document.getElementById("divMensaje").style.display = "block";
                document.getElementById("divPDF").style.display = "none";
            }
            else {
                //proceso fallido
                alert("Se produjo un error al intentar firmar, intentar nuevamente");
                document.getElementById("divPDF").style.display = "block";
                document.getElementById("divMensaje").style.display = "none";
            }
        }
        else {
            //proceso fallido
            alert("Se produjo un error al intentar firmar, intentar nuevamente");
            document.getElementById("divPDF").style.display = "block";
            document.getElementById("divMensaje").style.display = "none";
        }
    }
    else {
        //proceso fallido
        alert("Se produjo un error al intentar firmar, intentar nuevamente");
        document.getElementById("divPDF").style.display = "block";
        document.getElementById("divMensaje").style.display = "none";
    }

    Cargando2(false);
}

function validaEnviarFirma() {
    if (document.getElementById("txtMailContratante").value == "") {
        alert("DEBES CAPTURAR CORREO CONTRATANTE");
        focusCtrl("txtMailContratante");
        return false;
    }
    else {
        if (validarEmailCtrl("txtMailContratante")) {
            alert("El correo electrónico del contratante ingresado, no cuenta con el formato correcto");
            focusCtrl("txtMailContratante");
            return false;
        }
    }

    if (document.getElementById("txtMailAsegurado").value == "") {
        alert("DEBES CAPTURAR CORREO ASEGURADO");
        focusCtrl("txtMailAsegurado");
        return false;
    }
    else {
        if (validarEmailCtrl("txtMailAsegurado")) {
            alert("El correo electrónico del asegurado ingresado, no cuenta con el formato correcto");
            focusCtrl("txtMailAsegurado");
            return false;
        }
    }

    if (document.getElementById("txtMailAgente").value == "") {
        alert("DEBES CAPTURAR CORREO AGENTE");
        focusCtrl("txtMailAgente");
        return false;
    }
    else {
        if (validarEmailCtrl("txtMailAgente")) {
            alert("El correo electrónico del agente ingresado, no cuenta con el formato correcto");
            focusCtrl("txtMailAgente");
            return false;
        }
    }
    return true;

}

function btnCerrarFirma() {
    window.close();
}

function validarEmailCtrl(ctrl) {
    var email = document.getElementById(ctrl).value;
    expr = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!expr.test(email)) {
        return true;
    }
    return false;
}

function Cerrar() {
    window.close();
}

function desactivaBtnAgregaAsegurado(numAseg) {
    if (AseguradosType()[numAseg] === undefined) {
        document.getElementById("btnInserta").style.display = "none";
        document.getElementById("insertaMenor").style.display = "none";
    }
}

function InsertarAsegurtado() {
    var numAseg = getNumAsegurado();
    if (AseguradosType()[numAseg] === undefined) {
        alert("Ya inserto todo los asegurados, o ha expirado la sesion");
        return;
    }
    // edad | parentesco | cobertura | suma asegurada | Prima
    var datosCotizacionAsegurado = AseguradosType()[numAseg].split("|");
    var cod_parent = "";
    switch (datosCotizacionAsegurado[1]) {
        case "MENOR":
            cod_parent = "38";
            break;
        case "TITULAR":
            cod_parent = "4";
            break;
        case "MANCOMUNADO":
            cod_parent = "37";
            break;
        default:
            break;
    }
    var parentesco = datosCotizacionAsegurado[1];
    var nombre = valorCtrl("UscAsegCLM_lblNombre");
    var apellidoPaterno = valorCtrl("UscAsegCLM_lblApellidoPaterno");
    var apellidoMaterno = valorCtrl("UscAsegCLM_lblApellidoMaterno");
    var edad = valorCtrl("UscAsegCLM_lblEdad");
    var cod_docum = valorCtrl("UscAsegCLM_lblCLM");
    var fec_nac = valorCtrl("UscAsegCLM_lblNacimiento");
    var sexo = valorCtrl("UscAsegCLM_lblSexo") == "femenino" ? 0 : 1;
    var Ocupacion = selValorCtrl("drpOcupacion");
    var Peso = valorCtrl("txtPeso") == undefined ? "": valorCtrl("txtPeso");
    var Estatura = valorCtrl("txtEstatura") == undefined ? "" : valorCtrl("txtEstatura");
    var num_riesgo = numAseg + 1;
    var fuma = (valorCtrl("drpFuma") == 0) || (valorCtrl("drpFuma") == undefined) ? "false": "true";
    var Ingreso_Mensual = (document.getElementById("txtIngresoM").value == undefined) ? "0" : document.getElementById("txtIngresoM").value;
    var CargoPublico = "";
    if (document.getElementById("chkSiCargoP").checked) {
        CargoPublico = document.getElementById("txtCargoP").value;
    }

    var nombreCompleto = nombre + " " + apellidoPaterno + " " + apellidoMaterno;

    MetodosAjax.AgregaAsegurado(parentesco, nombre, apellidoPaterno, apellidoMaterno, num_riesgo, edad, Ocupacion, Peso, Estatura, cod_parent, cod_docum, fec_nac, sexo, fuma, Ingreso_Mensual, CargoPublico);
    setCoberturaAsegurado(numAseg, cod_docum);
    console.log(MetodosAjax.setAsegurados());
    setNumAsegurado();
    desactivaBtnAgregaAsegurado(getNumAsegurado());
    borraElementoBenef();
    limpiaCLM("UscAsegCLM_");
    document.getElementById("UscAsegCLM_txtRFC").focus();

    if (cod_parent == "4" || cod_parent == "37") {
        CuestionarioTitularMancomunado(nombreCompleto);
    }
    
    // LOS BENEFICIARIOS SE CARGAN INMEDIATAMENTE DESPUES DE INSERTAR AL ASEGURADO
}


function CuestionarioTitularMancomunado(nombreCompleto) {
    var nombre = nombreCompleto;
    var TipoPersona="";
    var chkCorazonSi="";
    var chkHipertesionArterialSi="";
    var chkCrebroVasculadresSI="";
    var chkPsiquiatricasNerviosasSi="";
    var chkEndocrinasSI="";
    var chkInsuficienciaRenalSi="";
    var chkSangreSi="";
    var chkCirrosisHeptitisSi="";
    var chkPulmonaresRespiratoriasSi="";
    var chkConsumoDrogasSI="";
    var chkSidaSI="";
    var chkArtritisSI="";
    var chkAparatoDigestivoSi = "";
    var chkSiPregunta1 = "";
    var chkSiPregunta2 = "";
    var chkSiPregunta3 = "";
    var chkSiPregunta4 = "";
    var chkSiPregunta5 = "";
    var chkSiPregunta5_1 = "";
    var chkSiPregunta6 = "";
    var chkSiPregunta7 = "";
    var chkSiPregunta8 = "";
    var chkSiPregunta9 = "";
    var chkSiPregunta10 = "";
    var chkSiPregunta11 = "";
    var chkSiPregunta12 = "";
    var chkSiPregunta13 = "";
    if (document.getElementById("rdoTitularCuestionario").checked) {
        TipoPersona = "4";
    } else if (document.getElementById("rdoMancomunadoCuestionario").checked) {
        TipoPersona = "37"
    }

    if (!validarCuestionarioFirma()) {
        if (document.getElementById('chkSi1').checked) {
            chkCorazonSi = "Yes";
        }
        if (document.getElementById('chkSi2').checked) {
            chkHipertesionArterialSi = "Yes";
        }

        if (document.getElementById('chkSi3').checked) {
            chkCrebroVasculadresSI = "Yes";;
        }
        if (document.getElementById('chkSi4').checked) {
            chkPsiquiatricasNerviosasSi = "Yes";
        }
        if (document.getElementById('chkSi5').checked) {
            chkEndocrinasSI = "Yes";
        }
        if (document.getElementById('chkSi6').checked) {
            chkInsuficienciaRenalSi = "Yes";
        }
        if (document.getElementById('chkSi7').checked) {
            chkSangreSi = "Yes";
        }
        if (document.getElementById('chkSi8').checked) {
            chkCirrosisHeptitisSi = "Yes";
        }
        if (document.getElementById('chkSi9').checked) {
            chkPulmonaresRespiratoriasSi = "Yes";
        }
        if (document.getElementById('chkSi10').checked) {
            chkConsumoDrogasSI = "Yes";
        }
        if (document.getElementById('chkSi11').checked) {
            chkSidaSI = "Yes";
        }
        if (document.getElementById('chkSi12').checked) {
            chkArtritisSI = "Yes";
        }

        if (document.getElementById('chkSi13').checked) {
            chkAparatoDigestivoSi = "Yes";
        }
        
         /*1*/if (document.getElementById("chkSi14").checked) {
              chkSiPregunta1 = "Yes";
        }
        /*2*/if (document.getElementById("chkSi15").checked) {
            chkSiPregunta2 = "Yes";
        }
        /*3*/if (document.getElementById("chkSi16").checked) {
            chkSiPregunta3 = "Yes";
        }
        /*4*/if (document.getElementById("chkSi17").checked) {
            chkSiPregunta4 = "Yes";
        }
        /*5*/if (document.getElementById("chkSi18").checked) {
            chkSiPregunta5 = "Yes";
        }
        /*6*/if (document.getElementById("chkSi19").checked) {
            chkSiPregunta5_1 = "Yes";
        }
        /*7*/if (document.getElementById("chkSi20").checked) {
            chkSiPregunta6 = "Yes";
        }
        /*8*/if (document.getElementById("chkSi21").checked) {
            chkSiPregunta7 = "Yes";
        }
        /*9*/if (document.getElementById("chkSi22").checked) {
            chkSiPregunta8 = "Yes";
        }
        /*10*/if (document.getElementById("chkSi23").checked) {
            chkSiPregunta9 = "Yes";
        }
        } /*11*/if (document.getElementById("chkSi24").checked) {
            chkSiPregunta10 = "Yes";
        }
        /*12*/if (document.getElementById("chkSi25").checked) {
            chkSiPregunta11 = "Yes";
        }
         /*13*/if (document.getElementById("chkSi26").checked) {
             chkSiPregunta12 = "Yes";
        }


           MetodosAjax.CuestionarioTitularMancomunado(TipoPersona, chkCorazonSi, chkHipertesionArterialSi, chkCrebroVasculadresSI, chkPsiquiatricasNerviosasSi,
            chkEndocrinasSI, chkInsuficienciaRenalSi, chkSangreSi, chkCirrosisHeptitisSi, chkPulmonaresRespiratoriasSi, chkConsumoDrogasSI, chkSidaSI, chkArtritisSI, chkAparatoDigestivoSi,
            chkSiPregunta1, chkSiPregunta2, chkSiPregunta3, chkSiPregunta4, chkSiPregunta5, chkSiPregunta5_1, chkSiPregunta6, chkSiPregunta7, chkSiPregunta8, chkSiPregunta9,
            chkSiPregunta10, chkSiPregunta11, chkSiPregunta12, nombre)
}

function setCoberturaAsegurado(asegurado, cod_docum) {
    var datosAsegurado = AseguradosType();
    // edad | parentesco | cobertura | suma asegurada | Prima
    var coberturas = datosAsegurado[asegurado].split("|")[2];
    var sumasAseguradas = datosAsegurado[asegurado].split("|")[3].replace(",", "").split(" ");
    var parentesco;
    switch (datosAsegurado[asegurado].split("|")[1]) {
        case "MENOR":
            parentesco = "38";
            break;
        case "TITULAR":
            parentesco = "4";
            break;
        case "MANCOMUNADO":
            parentesco = "37";
            break;
        default:
            break;
    }
    //var asegurado = getNumAsegurado();
    var num_riesgo = asegurado + 1;
    var cobertura;
    var sumaAseg;
    if (typeof coberturas == "string" && !coberturas.includes(",")) {
        cobertura = coberturas;
        sumaAseg = sumasAseguradas == "AMPARADA" ? 0 : sumasAseguradas;
        MetodosAjax.setCoberturas(cobertura, parseInt(sumaAseg), cod_docum, parentesco, num_riesgo);
    } else {
        nombreCobertura = coberturas.split(",");
        for (var i = 0; i < coberturas.split(",").length; i++) {
            cobertura = nombreCobertura[i].trim();
            sumaAseg = sumasAseguradas[i];
            if (sumaAseg == "AMPARADA" || sumaAseg == undefined) {
                sumaAseg = 0;
            } else {
                if (sumaAseg.includes(",")) {
                    sumaAseg = sumaAseg.replace(",", "");
                }
            }
            MetodosAjax.setCoberturas(cobertura, parseInt(sumaAseg), cod_docum, parentesco, num_riesgo);
        }
    }
}


function ProcesoFirma(objCheck) {
    if (objCheck.id == "chkboxSiFirma" || objCheck.id == "chkboxSiFirma2") { //Mostrar botón firma, en caso de aplicar, divCuestionario 1.5 millones y ocultar emisión
        document.getElementById("chkboxNoFirma").checked = false;
        document.getElementById("chkboxNoFirma2").checked = false;
        document.getElementById("divFirma").style.display = "block";
        document.getElementById("divEmite").style.display = "none";
        document.getElementById("divEmiteTxt").style.display = "none";
        document.getElementById("divEmiteAdj").style.display = "none";
        document.getElementById("divDivDocumentosAdjuntar2").style.visibility = "hidden";

        var SumaAsegBasica = document.getElementById("hdnSumaAseg").value;
        var moneda = selValorCtrl("drpMoneda");
        var ValSumaAseg = MetodosAjax.ValidaSAAnexo(SumaAsegBasica, moneda);
        document.getElementById("hdnValCuestMillon").value = ValSumaAseg.value;
        if (ValSumaAseg.value) {
            //Mostrar div Preguntas millon y medio
            //ConstruyeCuestionarioMillon();
        }
        else {
            //document.getElementById("divCuestionarioMillon").innerHTML = "";
        }
    }
    else { //Mostrar emisión y ocultar botón firma + divCuestionario 1.5 millones
        document.getElementById("chkboxSiFirma").checked = false;
        document.getElementById("chkboxSiFirma2").checked = false;
        document.getElementById("divFirma").style.display = "none";
        //document.getElementById("divCuestionarioMillon").innerHTML = "";
        document.getElementById("divEmite").style.display = "block";
        document.getElementById("divEmiteTxt").style.display = "block";
        document.getElementById("divEmiteAdj").style.display = "block";
        if (document.getElementById("hdnDivAdj2").value == "1") { document.getElementById("divDivDocumentosAdjuntar2").style.visibility = "visible"; }
        else { document.getElementById("divDivDocumentosAdjuntar2").style.visibility = "hidden"; }
    }
}
//Modificaciones Mejoras Firma Digital Vida
function refreshWindow() {
    window.opener.location.href = window.opener.location.href;
}

function ModificarCorreos() {
    //Habilitar los controles para la edición.
    document.getElementById("txtMailContratante").removeAttribute("disabled");
    document.getElementById("txtMailAsegurado").removeAttribute("disabled");
    document.getElementById("txtMailAgente").removeAttribute("disabled");
    document.getElementById("txtTelefono").removeAttribute("disabled");
    //Ocultar el botón de modificar.
    document.getElementById("btnModificar").setAttribute("hidden", "");
    //Mostrar el botón de guardar.
    document.getElementById("envFirmaMod").removeAttribute("hidden");
}

function EditarCorreos(cotizacion, transaccion, folio) {
    //Editar los correos en MetodosAjax
    if (validaEnviarFirma()) {
        Cargando2(true);
        var mailContratante = document.getElementById("txtMailContratante").value;
        var mailAsegurado = document.getElementById("txtMailAsegurado").value;
        var mailAgente = document.getElementById("txtMailAgente").value;
        var telefono = document.getElementById("txtTelefono").value;
        //Ya que se validaron los correos se envian de nuevo a firma.
        MetodosAjax.EnviaFirmaMod(cotizacion, transaccion, folio, mailContratante, mailAsegurado, mailAgente, telefono, EditarCorreos_callback)
    }
}

function EditarCorreos_callback(res) {
    if (res.error == null) {
        if (res != null && res.value != null) {
            if (res.value.split('|')[3] == "true") {
                //Proceso exitoso
                //Inhabilitar los controles de captura de correos.
                document.getElementById("txtMailContratante").setAttribute('disabled', '');
                document.getElementById("txtMailAsegurado").setAttribute('disabled', '');
                document.getElementById("txtMailAgente").setAttribute('disabled', '');
                document.getElementById("txtTelefono").setAttribute('disabled', '');
                //Habilitar el botón de envíar a firma
                document.getElementById("envFirmaMod").setAttribute('hidden', '');
                //Mostrar el mensaje con los datos de la nueva solicitud
                document.getElementById("tdFolio").innerHTML = res.value.split('|')[2];
                document.getElementById("tdSolicitud").innerHTML = res.value.split('|')[0];
                document.getElementById("hdnTransaccion").value = res.value.split('|')[1];
                document.getElementById("hdnURL").value = res.value.split('|')[4];
                document.getElementById("divMensaje").style.display = "block";
                document.getElementById("divPDF").style.display = "none";
                alert("Correos actualizados y enviados a firma correctamente. \n Debes actualizar la busqueda para que se reflejen los cambios.");
            }
            else {
                //proceso fallido
                alert("Se produjo un error al modificar los correos, intentar nuevamente");
                document.getElementById("divPDF").style.display = "block";
                document.getElementById("divMensaje").style.display = "none";
            }
        }
        else {
            //proceso fallido
            alert("Se produjo un error al modificar los correos, intentar nuevamente");
            document.getElementById("divPDF").style.display = "block";
            document.getElementById("divMensaje").style.display = "none";
        }
    }
    else {
        //proceso fallido
        alert("Se produjo un error al modificar los correos, intentar nuevamente");
        document.getElementById("divPDF").style.display = "block";
        document.getElementById("divMensaje").style.display = "none";
    }

    Cargando2(false);
}

function redirectGestion2008() {
    var transaccion = document.getElementById("hdnTransaccion").value;
    var folio = document.getElementById("tdFolio").innerHTML;
    var solicitud = document.getElementById("tdSolicitud").innerHTML;

    var url = document.getElementById("hdnURL").value + "?transaccion=" + transaccion + "&folio=" + folio + "&Solicitud=" + solicitud
    window.parent.opener.location = url;
    window.close();
}

function modificaAsegurado(fila) {
    document.all("hdnFilaSelec").value = fila;
    document.getElementById("btnActualizar").style.display = "inline";
    document.getElementById("btnCancelar").style.display = "inline";
    document.getElementById("btnAgregar1").style.display = "none";

    for (var i = 1; i <= 7; i++) {
        if (document.getElementById("Renglon" + i).style.display == "table-row") {
            if (i != fila) { document.all("Renglon" + i).disabled = false }
        }
    }

    /*if(document.all("lblSexo"+fila).innerText=="M"){
        document.all("rbnMasculino").checked = true;
    }
    else if(document.all("lblSexo"+fila).innerText=="F"){
        document.all("rbnFemenino").checked = true;
    }*/
    /*if(document.all("hdnFuma"+fila).value==1){
        document.all("rbnSiFuma").checked = true;
    }
    else if(document.all("hdnFuma"+fila).value==0){
        document.all("rbnNoFuma").checked = true;
    }*/
    setSelFindByValueText("drpParentesco1", document.getElementById("lblParentesco" + fila).innerText);
    document.all("txtNombre").value = document.all("lblNombre" + fila).innerText;
    document.all("txtEdad").value = parseInt(document.all("lblEdad" + fila).innerText);
    document.all("Renglon" + fila).disabled = true;
    document.getElementById("btnCotizar").disabled = true;
    var Tip_plan = document.getElementById("HiddenTipoPlanRequest").value;

    modifica = "modificar";
    var cia = "1";
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var contrato = document.getElementById("HiddenContratoGenerico").value
    var modalidad = document.getElementById("HiddenModalidad").value;
    var moneda = selIndex("drpMoneda");
    var edad = document.all("txtEdad").value;
    //var fecha = document.getElementById("hidFechaSistema").value;
    //fecha = fecha.replace(new RegExp('/', 'g'), "");
    MetodosAjax.getCoberturasEdad(ramo, contrato, modalidad, document.getElementById("txtEdad").value, selIndex("drpMoneda"), Tip_plan, Coberturas_CallBack);
    //MetodosAjax.getDatosCobUL(1, document.getElementById("HiddenRamoRequest").value, document.getElementById("HiddenTipoPlanRequest").value, document.all("txtEdad").value, "", "", Coberturas_CallBack, "");
}

function isMenor() {
    if (document.getElementById("rdoMenor").checked == true) {
        HabilitaFirmaMenor(true);
        document.getElementById("InsertarMenor").style.display = "inline-block";
        document.getElementById("divCuestionario").style.display = "none";
        document.getElementById("tipoPersona").style.display = "none";
        document.getElementById("Peso").style.display = "none";
        document.getElementById("Estatura").style.display = "none";
        document.getElementById("DeportePeligroso").style.display = "none";
        $("#UscAsegCLM_btnEnviaDatos").removeAttr('disabled');
    } else if (document.getElementById("rdoMancomunado").checked) {
        HabilitaFirmaMenor(false);
        document.getElementById("InsertarMenor").style.display = "none";
        document.getElementById("divCuestionario").style.display = "inline-block";
        document.getElementById("tipoPersona").style.display = "inline-block";
        document.getElementById("Peso").style.display = "inline-block";
        document.getElementById("Estatura").style.display = "inline-block";
        document.getElementById("DeportePeligroso").style.display = "inline-block";
        $("#UscAsegCLM_btnEnviaDatos").removeAttr('disabled');
        $("#UscAsegCLM_txtRFC").removeAttr('disabled');

        devuelveCuestionario();
    }else {
        HabilitaFirmaMenor(false);
        document.getElementById("InsertarMenor").style.display = "none";
        document.getElementById("divCuestionario").style.display = "inline-block";
        document.getElementById("tipoPersona").style.display = "inline-block";
        document.getElementById("Peso").style.display = "inline-block";
        document.getElementById("Estatura").style.display = "inline-block";
        document.getElementById("DeportePeligroso").style.display = "inline-block";
        devuelveCuestionario();
    }

    if (document.getElementById("rdoTitular").checked == true) {

        limpiaCLM("UscAsegCLM_");

        document.getElementById("UscAsegCLM_chkContSol").style.display = "inline-block";
        document.querySelector("label[for='UscAsegCLM_chkContSol']").style.display = "inline-block";
    } else {
        document.getElementById("UscAsegCLM_chkContSol").style.display = "none";
        document.querySelector("label[for='UscAsegCLM_chkContSol']").style.display = "none";
    }

    /*habilitarCheckbox(radioButton, checkbox);*/
}



function Coberturas_CallBack(res) {
    if (res.error == null) {
        if (res != null && res.value != null) {
            document.getElementById('DivCoberturas').innerHTML = res.value;
            numTotalCob = document.all('hdnTotalCob').value;
            for (var i = 1; i <= numTotalCob; i++) {
                if (modifica != "") {
                    var indice = document.all('hdnFilaSelec').value;
                    obtenerCobRiesgo(i, indice);
                }
            }
            modifica = "";
            AjustarFrame();
            CotizaBasePrima("none");

        }
    }
    if (selIndex("drpParentesco1") == 37) {
        document.getElementById("1011").style.display = "none";
        document.getElementById("1012").style.display = "none";
        document.getElementById("1013").style.display = "none";

        for (var t = 1; t <= 7; t++) {
            if (document.getElementById("lblParentesco" + t)?.value == 4)
                obtenerCobRiesgo(1, t)
        }
        document.getElementById('txtSuma1014').disabled = true;
        document.getElementById('chk1').disabled = true;
    }
}

function NuevaEmision() {
    window.location.href = "../appAcceso.aspx?app=EmisionGeneral/EmisionGeneralVida1053.aspx?codRamo=" + document.getElementById("HiddenRamoRequest").value;
    //focusCtrl("drpAgente");
}


// Funcion para obtener las coberturas del asegurado
function obtenerCobRiesgo(iCob, iAse) {
    var hdnCobRef = [1000, 1019, 1011, 1012, 1013, 1014];
    var cob = Array();
    var suma = Array();
    cob = document.getElementById('lblCoberturas' + iAse).value.split(',');
    suma = document.getElementById('lblSumaAseg' + iAse).innerText.split(' ');
    if (document.getElementById('chk' + iCob)) {
        document.getElementById('chk' + iCob).checked = false;
        for (var j = 0; j < cob.length; j++) {
            if (document.getElementById('chk' + iCob).value == cob[j]) {
                document.getElementById('chk' + iCob).checked = true;
                if (suma[j] != null) {
                    if (suma[j] != 'AMPARADA') {
                        document.getElementById('txtSuma' + cob[j]).value = formatCurrency(suma[j]);
                    } else {
                        document.getElementById('txtSuma' + cob[j]).value = suma[j];
                    }
                }
            }
        }
        seleccionaCobertura(iCob);
    }
}

// Funcion para seleccion de coberturas
function seleccionaCobertura(indice) {
    limpiaImportes();
    if (document.getElementById('chk' + indice).checked == true) {
        var cobRef = Array();
        cobRef = document.getElementById('hdnCobRef').value.split(',');
        document.getElementById('txtSuma' + document.getElementById('chk' + indice).value).disabled = false;
        for (var i = 0; i < cobRef.length; i++) {
            if (cobRef[i] != '1012') {
                if (document.getElementById('chk' + indice).value == cobRef[i]) {
                    document.getElementById('txtSuma' + document.getElementById('chk' + indice).value).value = 'AMPARADA';
                    document.getElementById('txtSuma' + document.getElementById('chk' + indice).value).disabled = true;
                }
            }//if ((cobRef[i]!='1011') && (cobRef[i]!='1012') && (cobRef[i]!='1013')){
        }//Termina iteracion
        if (document.getElementById('chk' + indice).value == 1012) {
            var numeroDecimal = Array();
            numeroDecimal = document.getElementById('txtSuma1012').value.split('.');
            //var valor1012 = numeroDecimal[0].replace(/\$|\,/g,'');
            var valor = numeroDecimal[0].replace(/\$|\,/g, '');
            if (selIndex("drpMoneda") == 2) {
                if (parseInt(valor) > 500000) {
                    //alert('La suma asegurada del BIPA tiene que ser menor o igual a la del temporal Individual y Mancomunado, pero no debe ser mayor a 500,000 dll');
                    document.getElementById('txtSuma' + document.getElementById('chk' + indice).value).value = "500,000.00";

                }
                else {
                    if (document.getElementById('txtSuma1012').value != "") {
                        document.getElementById('txtSuma' + document.getElementById('chk' + indice).value).value = formatCurrency(valor);
                    }
                }
            }
            else {
                if (parseInt(valor) > "1400000.00") {
                    //alert('La suma asegurada del BIPA tiene que ser menor o igual a la del temporal Individual y Mancomunado, pero no debe ser mayor a 1,400,000 udis');
                    document.getElementById('txtSuma' + document.getElementById('chk' + indice).value).value = "1,400,000.00";
                }
                else {
                    document.getElementById('txtSuma' + document.getElementById('chk' + indice).value).value = formatCurrency(valor);
                }
            }//drpMoneda
        }//else if 1012
    }
    else {
        document.getElementById('txtSuma' + document.getElementById('chk' + indice).value).disabled = true;
        document.getElementById('txtSuma' + document.getElementById('chk' + indice).value).value = "";
    }
}

// Funcion que actualiza los datos del asegurado en la tabla
function actualizarAsegurado() {
    var indice = document.all("hdnFilaSelec").value;
    var n = document.getElementById("DropDownList1").value;
    var aseg = document.getElementById("hdnIndice").value;
    if (validaDatosAseg(indice)) {
        agregarDatos(indice);
        document.getElementById("btnActualizar").style.display = "none";
        document.getElementById("btnCancelar").style.display = "none";
        document.getElementById("btnAgregar1").style.display = "inline";
        document.all("Renglon" + indice).disabled = false;
        if (parseInt(aseg) == (parseInt(n) + 1)) document.getElementById('btnObtenerPrimas').disabled = false;
        //numAsegCompleto();
        limpiaImportes();
        document.all("hdnFilaSelec").value = "";
        //document.all("hdnActualiza").value = "";				
    }
}

function agregarAsegurado() {
    //validaNoAsegurados();
    var indice = document.getElementById("hdnIndice").value;
    var n = document.getElementById("DropDownList1").value;
    //if (n == indice && selIndexText("drpParentesco1") != "MANCOMUNADO") {
    //    document.getElementById("btnAgregar1").disabled = true;
    //}
    if (parseInt(indice) > parseInt(n) && selIndexText("drpParentesco1") != "MANCOMUNADO") {
        alert("Ha excedido el total de asegurados.");
    }
    else if (parseInt(indice) <= parseInt(n) || selIndexText("drpParentesco1") == "MANCOMUNADO") {
        if (validaDatosAseg(indice)) {
            document.getElementById("Renglon" + indice).style.display = "table-row";
            agregarDatos(indice);
            indice++;
            document.getElementById("hdnIndice").value = indice;
            if (indice == 2 || indice == 1) document.getElementById("Header").style.display = "table-row";
            if (parseInt(indice) == (parseInt(n) + 1)) document.getElementById('btnCotizar').disabled = false;
            //numAsegCompleto();			
            document.getElementById("drpParentesco").focus();
        }
        else {
            document.getElementById("btnAgregar1").disabled = false;
        }
    }
}


//Funcion para agregar datos
function agregarDatos(indice) {
    document.getElementById("lblParentesco" + indice).innerText = selIndexText("drpParentesco1");
    document.getElementById("lblParentesco" + indice).value = selIndex("drpParentesco1");
    document.getElementById("lblNombre" + indice).innerText = document.getElementById("txtNombre").value;
    document.getElementById("lblEdad" + indice).innerText = document.getElementById("txtEdad").value;
    document.getElementById("lblIngresoAnual" + indice).innerText = formatCurrencyEx(document.getElementById("txtIngresoM").value);
    document.getElementById("hdnSexo" + indice).innerText = selIndexText("drpSexo");
    document.getElementById("hdnFuma" + indice).value = 0;
    /*if(document.getElementById("rbnNoFuma").checked == true){
        document.getElementById("hdnFuma" + indice).value = 0;
    }
    else if(document.getElementById("rbnSiFuma").checked == true) {
        document.getElementById("hdnFuma" + indice).value = 1;
    }*/

    var strCob = "";
    var strCobAmp = "";
    var strSum = "";
    var strSumAmp = "";
    var strCodCob = "";
    var strCodCobAmp = "";
    numTotalCob = parseInt(document.all('hdnTotalCob').value);
    for (var i = 1; i <= numTotalCob; i++) {
        if ((document.getElementById('Coberturas').style.display == "table-row") && document.getElementById('chk' + i)) {
            if (document.getElementById('chk' + i).checked == true) {
                var flag = false;
                var cobRef = Array();
                document.getElementById('hdnCobRef').value = '1019,1011,1013';
                cobRef = document.getElementById('hdnCobRef').value.split(",");
                //cobRef = document.getElementById('hdnCobRef').value.split(',');
                for (var j = 0; j < cobRef.length; j++) {
                    if (document.getElementById('chk' + i).value == cobRef[j])
                        flag = true;
                }
                if (flag) {
                    if (selIndex("drpParentesco1") != "37") {
                        if (strCobAmp != "") strCobAmp += ",";
                        if (document.getElementById('chk' + i).value == 1019) {
                            strCobAmp += 'SF';

                        }
                        else if (document.getElementById('Coberturas' + document.getElementById('chk' + i).value)) {
                            strCobAmp += document.getElementById('Coberturas' + document.getElementById('chk' + i).value).innerText;
                        }
                        strSumAmp = "AMPARADA";
                        if (strCodCobAmp != "") strCodCobAmp += ",";
                        if (document.getElementById('chk' + i)) {
                            strCodCobAmp += document.getElementById('chk' + i).value;
                        }
                    }
                }
                else {
                    if ((i == "3") && (selIndex("drpParentesco1") == "37")) {
                        null;
                    }
                    else {
                        if (strCob != "") strCob += ", ";
                        if (document.getElementById('Coberturas' + document.getElementById('chk' + i).value)) {
                            strCob += document.getElementById('Coberturas' + + document.getElementById('chk' + i).value).innerText;
                        } else {
                            strCob += "";
                        }

                        if (strSum != "") strSum += " ";
                        if (document.getElementById('txtSuma' + document.getElementById('chk' + i).value)) {
                            strSum += formatCurrencyEx(document.getElementById('txtSuma' + document.getElementById('chk' + i).value).value);
                        } else {
                            strSum += "";
                        }
                        if (strCodCob != "") strCodCob += ",";
                        if (document.getElementById('chk' + i)) {
                            strCodCob += document.getElementById('chk' + i).value;
                        } else {
                            strCodCob += "";
                        }


                    }
                }
            }
        }
        else i = numTotalCob + 1;
    }

    if (strCobAmp != "") {
        if (strCob != "") strCob += ",\n";
        strCob += strCobAmp;
        if (strSum != "") strSum += " ";
        strSum += strSumAmp;
        if (strCodCob != "") strCodCob += ",";
        strCodCob += strCodCobAmp;
    }

    if (selIndex("drpParentesco1") == "4") {
        numTotalCob = document.all('hdnTotalCob').value;
        for (var i = 1; i <= numTotalCob; i++) {
            if (document.getElementById("Coberturas").style.display == "table-row") {
                if (document.getElementById('chk' + i)?.checked == true) {
                    document.getElementById('chk' + i).disabled = true;
                    document.getElementById('txtSuma' + document.getElementById('chk' + i).value).disabled = true;
                }
            }
        }
    }
    if (selIndex("drpParentesco1") == "37") {
        document.getElementById("btnAgregar1").disabled = true;
    }

    document.getElementById('lblCoberturas' + indice).innerText = strCob;
    document.getElementById('lblSumaAseg' + indice).innerText = strSum;
    document.getElementById('lblCoberturas' + indice).value = strCodCob;
    limpiarControles();
    limpiaImportes();
    limpiaCoberturas();
}

//Funcion para seleccionar un elemento de un combo por su texto
function setSelFindByValueText(nameSelect, valueToFind) {
    dropDown = eval('document.forms[0].' + nameSelect);
    for (zzz = 0; zzz < dropDown.options.length; zzz++) {
        if (dropDown.options[zzz].text == valueToFind) {
            dropDown.options[zzz].selected = true;
            return;
        }
    }
}


// Funcion que valida el orden del parentesco
function validaParentesco() {
    var parentesco = selIndex("drpParentesco1");
    var numRiesgos = document.getElementById("DropDownList1").value;
    if (document.getElementById("hdnFilaSelec").value == "")
        indice = document.getElementById("hdnIndice").value;
    else indice = document.getElementById("hdnFilaSelec").value;

    if (parseInt(indice) > parseInt(numRiesgos) && selIndexText("drpParentesco1") != "MANCOMUNADO") {
        alert("Ha excedido el total de asegurados.");
        return false;
    }

    if (selIndex("drpParentesco1") != 38) {
        var parentesco = selIndex("drpParentesco1");
        var valida1014 = "";
        for (var i = 1; i <= 7; i++) {
            //Comienza Validacion Mancomunado
            var datos = Array();
            if (document.getElementById('lblCoberturas' + i).value !== undefined) {
                datos = document.getElementById('lblCoberturas' + i).value.split(',');
            } else {
                datos.push(document.getElementById('lblCoberturas' + i).value);
            }
            if (parseInt(parentesco) == 37) {
                for (var j = 0; j < datos.length; j++) {
                    if (datos[j]?.toString() === "1014") {
                        valida1014 = 1;
                    }
                }
            }//Mancomunado        

            if (i != indice) {
                if (document.getElementById("Renglon" + i).style.display == "table-row") {
                    if (document.getElementById("lblParentesco" + i).value == parentesco) {
                        alert("El parentesco " + document.getElementById("lblParentesco" + i).innerText + " ya existe.");
                        document.getElementById("drpParentesco1").focus();
                        return false;
                    }
                }
                else i = 8;
            }
        }
        if ((parentesco == 37) && (valida1014 != 1)) {
            alert('Para asegurar al MACOMUNADO debe amparar la cobertura de TEMPORAL con el TITULAR');
            document.getElementById("btnCotizar").disabled = true;
            return false;
        }//Termina mancomunado        
    }
    else {
        var edad = document.getElementById("txtEdad").value;
        for (var i = 1; i <= 7; i++) {
            if (i != indice) {
                if (document.getElementById("Renglon" + i).style.display == "table-row") {
                    if (parseInt(document.getElementById("lblEdad" + i).innerHTML) > parseInt(edad)) {
                        if (document.getElementById('btnActualizar').style.display != "inline") {
                            alert("Los asegurados menores deben ser capturados del MENOR al MAS GRANDE, favor de verificar");
                            document.getElementById("drpParentesco1").focus();
                            return false;
                        }
                    }
                }
                else i = 8;
            }
        }
    }

    //if (indice > 5) {
    //    if (selIndex("drpParentesco1") == 38) {
    //        alert("Solo se puede amparar a cinco MENORES, seleccione otro parentesco.");
    //        document.getElementById("drpParentesco1").focus();
    //        return false;
    //    }
    //}
    if ((indice < (numRiesgos - 1)) || (numRiesgos == 1) || ((numRiesgos == 2) && (indice == (numRiesgos - 1)))) {
        if (selIndex("drpParentesco1") != 38) {
            alert("Debe ingresar primero todos los asegurados con el parentesco de: HIJO/A.");
            document.getElementById("drpParentesco1").focus();
            return false;
        }
    }
    else if (indice == (numRiesgos - 1)) {
        if (selIndex("drpParentesco1") == 37) {
            alert("Debe ingresar primero el asegurado con el parentesco de: TITULAR.");
            document.getElementById("drpParentesco1").focus();
            return false;
        }
    }
    else if ((indice == numRiesgos) && (numRiesgos > 1)) {
        if (document.getElementById("lblParentesco" + (indice - 1)).value != 4) {
            if (selIndex("drpParentesco1") == 37) {
                alert("Debe ingresar primero el asegurado con el parentesco de: TITULAR.");
                document.getElementById("drpParentesco1").focus();
                return false;
            }
        }
        else if (selIndex("drpParentesco1") == 38) {
            alert("Debe ingresar todos los MENORES antes del TITULAR.");
            document.getElementById("drpParentesco1").focus();
            return false;
        }
    }


    return true;
}


function NuevaEmision1053() {
    window.location.href = "../appAcceso.aspx?app=EmisionGeneral/EmisionGeneralVida1053.aspx?codRamo=" + document.getElementById("HiddenRamoRequest").value +"&codTipoPlan=16";
    //focusCtrl("drpAgente");
}

function HabilitaFirmaMenor(isMenor){
    if (isMenor) {
        document.getElementById("divChkConf2").style.visibility = "visible";
        document.getElementById("divChkConf2").style.display = "inline";
        document.getElementById("chkboxSiFirma2").checked = false;
        document.getElementById("chkboxNoFirma2").checked = false;
        document.getElementById("chkboxSiFirma2").style.display = "inline";
        document.getElementById("chkboxNoFirma2").style.display = "inline";
        document.getElementById("accordionCuestionario").style.display = "none";
        document.getElementById("accordionCuestionarioRed").style.display = "none";
    } else {
        document.getElementById("divChkConf").style.visibility = "visible";
        document.getElementById("chkboxSiFirma").checked = false;
        document.getElementById("chkboxNoFirma").checked = false;
        document.getElementById("accordionCuestionario").style.display = "block";
        document.getElementById("accordionCuestionarioRed").style.display = "block";
        document.getElementById("divChkConf2").style.display = "none";
        document.getElementById("chkboxSiFirma2").checked = false;
        document.getElementById("chkboxNoFirma2").checked = false;
        document.getElementById("chkboxSiFirma2").style.display = "none";
        document.getElementById("chkboxNoFirma2").style.display = "none";
    }
}

function limpiaImportesFinales() {
    if (document.getElementById("pnlCotizacion").style.display == "inline") {
        if (document.getElementById("btnActualizar").style.display != "inline") {
            if (document.getElementById("hdnActualiza").value != "1") {
                document.getElementById("lblPrimaneta").innerText = "";
                document.getElementById("lblDerechos").innerText = "";
                document.getElementById("lblRecargos").innerText = "";
                document.getElementById("lblPrimatotal").innerText = "";

                document.getElementById("pnlCotizacion").style.display = "none";
                document.getElementById("btnImprimir").disabled = true;
                document.getElementById("btnNuevaCotizacion1").disabled = true;
                impresion("none");
                CotizaBasePrima("none");
                document.getElementById("hdnActualiza").value = "";
                document.getElementById("btnCotizar").disabled = true;
            }
        }
        else {
            document.getElementById("hdnActualiza").value = "1";
        }
    }
}


function validaDatosAseg(indice) {
    if (document.getElementById("drpParentesco1").selectedIndex == 0) {
        alert("Es necesario introducir el Parentesco.");
        document.getElementById("drpParentesco1").focus();
        return false;
    }
    else if (!validaParentesco()) return false;

    if (document.all["txtNombre"].value == "") {
        alert("Es necesario introducir Nombre.");
        document.getElementById("txtNombre").focus();
        return false;
    }

    if (document.all["txtEdad"].value == "") {
        alert("Es necesario introducir Edad.");
        document.getElementById("txtEdad").focus();
        return false;
    }
    if (document.all["txtIngresoM"].value == "" && document.getElementById("drpParentesco1").value != 38) {
        alert("Es necesario introducir Ingreso Anual.");
        document.getElementById("txtIngresoM").focus();
        return false;
    }

    var flag = true;

    numTotalCob = document.all('hdnTotalCob').value;
    hdnCobRef = [1000, 1019, 1011, 1012, 1013, 1014];
    document.getElementById("Coberturas").style.display == "table-row";
    for (var i = 1; i <= numTotalCob; i++) {
        if (document.getElementById("Coberturas").style.display == "table-row") {
            if (document.getElementById('chk' + i)) {
                if (document.getElementById('chk' + i).checked == true) {
                    flag = false;
                    if (document.getElementById('txtSuma' + document.getElementById('chk' + i).value)?.value == "" || document.getElementById('txtSuma' + document.getElementById('chk' + i).value)?.value == "$0.00") {
                        alert("Es necesario ingresar la Suma Asegurada.");
                        document.getElementById('txtSuma' + parseInt(hdnCobRef[i - 1])).focus();
                        return false;
                    }
                    return true;
                }
            }

        }
        else i = numTotalCob + 1;
    }
    if (flag) {
        alert("Se debe seleccionar por lo menos una cobertura");
        return false;
    }

    return true;
}




function limpiaImportes() {
    if (document.getElementById("pnlCotizacion").style.display == "inline") {
        if (document.getElementById("btnActualizar").style.display != "inline") {
            if (document.getElementById("hdnActualiza").value != "1") {
                for (var i = 1; i <= 7; i++) {
                    document.getElementById("lblSumaAseg" + i).innerText = "";
                    document.getElementById("lblCoberturas" + i).innerText = "";
                    document.getElementById("lblCoberturas" + i).value = "";
                    document.getElementById("lblPrima" + i).innerText = "";
                }
                document.getElementById("lblPrimaneta").innerText = "";
                document.getElementById("lblDerechos").innerText = "";
                document.getElementById("lblRecargos").innerText = "";
                document.getElementById("lblPrimatotal").innerText = "";

                document.getElementById("pnlCotizacion").style.display = "none";
                document.getElementById("btnImprimir").disabled = true;
                document.getElementById("btnNuevaCotizacion1").disabled = true;
                impresion("none");
                document.getElementById("hdnActualiza").value = "";
                document.getElementById("btnCotizar").disabled = true;

                for (var j = 1; j <= 7; j++) {
                    document.getElementById("Renglon" + j).style.display = "none";
                    document.getElementById("lblParentesco" + j).innerText = "";
                    document.getElementById("lblNombre" + j).innerText = "";
                    document.getElementById("lblEdad" + j).innerText = "";
                    document.getElementById("lblSumaAseg" + j).innerText = "";
                    document.getElementById("lblCoberturas" + j).innerText = "";
                    document.getElementById("lblPrima" + j).innerText = "";
                    document.getElementById("lblIngresoAnual" + j).innerText = "";
                    document.getElementById("Header").style.display = "none";
                    document.getElementById("hdnIndice").value = 1;

                }
            }
        }
        else {
            document.getElementById("hdnActualiza").value = "1";
        }
    }
    else {
        var counter = 0;
        for (var i = 1; i <= 7; i++) {
            if (document.getElementById("lblSumaAseg" + i).innerText != "") {
                counter++;
            }

        }
        if ((document.getElementById("DropDownList1").value != "") && (document.getElementById("DropDownList1").value == counter)) {
            document.getElementById("btnCotizar").disabled = false;
        }
        CotizaBasePrima("none");

    }
}

function obtenerCoberturas() {

    document.getElementById('DivCoberturas').innerHTML = "";

    var Ramo = document.getElementById("HiddenRamoRequest").value;
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }
    var Modalidad = document.getElementById("HiddenModalidad").value;
    var Tip_plan = document.getElementById("HiddenTipoPlanRequest").value;
    var edad = document.getElementById("txtEdad").value;

    if (document.getElementById("drpParentesco1").value == 37 && edad > 55) {
        edad = 55;
    }

    MetodosAjax.getCoberturasEdad(Ramo, contrato, Modalidad, edad, selIndex("drpMoneda"), Tip_plan, Coberturas_CallBack);
    MetodosAjax.getDctoSexoFuma(Ramo, Modalidad, 1000, getDctoSexoFuma_CallBack);

}

function formatCurrencyEx(num) {
    num = num.toString().replace(/\$|\,/g, '');
    if (selIndex('drpMoneda') == 2) {
        var moneda = " USD";
    }
    else {
        var moneda = " UDIS";
    }
    if (isNaN(num))
        num = "0";
    sign = (num == (num = Math.abs(num)));
    num = Math.floor(num * 100 + 0.50000000001);
    cents = num % 100;
    num = Math.floor(num / 100).toString();
    if (cents < 10)
        cents = "0" + cents;
    for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++)
        num = num.substring(0, num.length - (4 * i + 3)) + ',' + num.substring(num.length - (4 * i + 3));
    //return (num + '.' + moneda);
    //return (num + ' ' + moneda);
    return (num);
}

function limpiarControles() {
    document.getElementById("drpParentesco1").value = 38;
    document.getElementById("txtNombre").value = "";
    document.getElementById("txtEdad").value = "";
    document.getElementById("txtIngresoM").value = "";
    //document.getElementById("rbnMasculino").checked = true;
    //document.getElementById("rbnFemenino").checked = false;
    //document.getElementById("rbnNoFuma").checked = true;
    //document.getElementById("rbnSiFuma").checked = false;
}


// Funcion que limpia la Tabla de Coberturas
function limpiaCoberturas() {
    numTotalCob = document.all('hdnTotalCob').value;
    for (var i = 1; i <= numTotalCob; i++) {
        if (document.getElementById('chk' + i) && document.getElementById('Coberturas' + hdnCobRef[i - 1]) && document.getElementById('txtSuma' + hdnCobRef[i - 1]) && document.getElementById('txtSuma' + hdnCobRef[i - 1])) {
            document.getElementById('chk' + i).checked = false;
            document.getElementById('chk' + i).disabled = true;
            document.getElementById('chk' + i).value = 0;
            document.getElementById('Coberturas' + hdnCobRef[i - 1]).innerText = "";
            document.getElementById('txtSuma' + hdnCobRef[i - 1]).value = "";
            document.getElementById('txtSuma' + hdnCobRef[i - 1]).disabled = true;
        }

        //document.getElementById('hdnDatosCob' + i).value = "";
        document.getElementById("Coberturas").style.display = "none";
    }
}

// Funcion que cancela el modificar los datos de un asegurado
function cancelarModificar() {
    var indice = document.all("hdnFilaSelec").value;
    limpiarControles();
    document.getElementById("btnActualizar").style.display = "none";
    document.getElementById("btnCancelar").style.display = "none";
    document.getElementById("btnAgregar1").style.display = "inline";
    document.all("Renglon" + indice).disabled = false;
    document.getElementById("btnCotizar").disabled = false;
    document.all("hdnFilaSelec").value = "";
}

//Capturar todos los asegurados
function AseguradosType() {
    var aseg = document.getElementById("Table6").rows;
    var asegEdad = [];
    var cod_cob = 0;
    // edad | parentesco | cobertura | suma Asegurada | Prima | sexo |
    for (var i = 1; i < aseg.length; i++) {
        if (aseg[i].cells[0].children[0].innerText != "") {
            asegEdad.push(aseg[i].cells[2].innerText.trim() + "|" + aseg[i].cells[0].children[0].innerText.trim() + "|" + aseg[i].cells[4].innerText.trim() + "|" + aseg[i].cells[3].innerText.trim() + "|PRIMA:" + aseg[i].cells[5].innerText.trim() + "|" + aseg[i].cells[9].children[1].innerText.trim());
        }
    }
    return asegEdad;

}

// Funcion que borra asegurado de la lista
function borrarAsegurado(fila) {
    if (document.all("Renglon" + fila).disabled == true) { cancelarModificar() }
    var indice = document.getElementById("hdnIndice").value;
    var n = document.getElementById("DropDownList1").value;
    if (fila < 7) {
        var j = fila;
        for (var i = fila; i < 7; i++) {
            j++;
            document.getElementById("Renglon" + i).style.display = document.getElementById("Renglon" + j).style.display;
            document.getElementById("Renglon" + i).disabled = document.getElementById("Renglon" + j).disabled;
            document.getElementById("lblParentesco" + i).innerText = document.getElementById("lblParentesco" + j).innerText;
            document.getElementById("lblParentesco" + i).value = document.getElementById("lblParentesco" + j).value;
            document.getElementById("lblNombre" + i).innerText = document.getElementById("lblNombre" + j).innerText;
            document.getElementById("lblEdad" + i).innerText = document.getElementById("lblEdad" + j).innerText;
            document.getElementById("hdnSexo" + i).innerText = document.getElementById("hdnSexo" + j).innerText;
            document.getElementById("lblSumaAseg" + i).innerText = document.getElementById("lblSumaAseg" + j).innerText;
            document.getElementById("lblIngresoAnual" + i).innerText = document.getElementById("lblSumaAseg" + j).innerText;
            document.getElementById("lblCoberturas" + i).innerText = document.getElementById("lblCoberturas" + j).innerText;
            document.getElementById("lblCoberturas" + i).value = document.getElementById("lblCoberturas" + j).value;
            document.getElementById("hdnFuma" + i).value = document.getElementById("hdnFuma" + j).value;
            if (document.getElementById("Renglon" + j).style.display == "none") { i = 7 }
        }
    }
    document.getElementById("Renglon7").style.display = "none";
    document.getElementById("lblParentesco7").innerText = "";
    document.getElementById("lblParentesco7").value = "";
    document.getElementById("lblNombre7").innerText = "";
    document.getElementById("lblEdad7").innerText = "";
    document.getElementById("hdnSexo7").innerText = "";
    document.getElementById("lblSumaAseg7").innerText = "";
    document.getElementById("lblIngresoAnual7").innerText = "";
    document.getElementById("lblCoberturas7").innerText = "";
    document.getElementById("lblCoberturas7").value = "";
    document.getElementById("hdnFuma7").value = "";
    indice--;
    if (indice == 1) document.getElementById("Header").style.display = "none";
    document.getElementById("hdnIndice").value = indice;
    if (parseInt(indice) != (parseInt(n) + 1)) document.getElementById('btnCotizar').disabled = true;
    //numAsegCompleto();
    limpiaImportes();
    document.getElementById("btnAgregar1").disabled = false;
}