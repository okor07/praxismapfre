var PATRON_NUMERICO          = /(^([0-9]|\xD|\xA)+)$/;

function PaintAgente(txtId)
{
	//Pintamos primero el renglon anterior del agente en caso de existir
	if(document.getElementById("txtId").value!='')
		paintWhiteAgente(document.getElementById("txtId").value);
	
	id = txtId.charAt(19) + txtId.charAt(20);
	id = parseInt(id);

	var color = 'silver';
	var index = ((id < 10) ? "0"+id : id);
	if (document.getElementById("dtgReferencias_ctl" + index + "_txtgrdNomAgente").value == '')
	{
		color = 'white';
		document.getElementById("txtId").value = '';
	}
	else
	{
		ExtraeGrdAgente(id)
		document.getElementById("txtId").value = id;
	}
		
	document.getElementById("dtgReferencias_ctl" + index + "_txtgrdNomAgente").style.background = color;
	document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave").style.background = color;
	document.getElementById("dtgReferencias_ctl" + index + "_txtgrdPorcentaje").style.background = color;
	
	return false;
}

function InsertaAgentecedentes()
{
	var TotalAgen = 0;
	EnabledValidaAgente(true);	
	if(Page_ClientValidate("TablaAgentes") && ValidaRepAgente(''))
	{	
		TotalAgen = parseInt(document.all("HidTotalAgentes").value)	
		if(TotalAgen < 4)
		{
			for (i=0;i < 10;i++)
			{
			    var index = ((parseInt(i) < 10) ? "0"+i : i);
				if (document.getElementById("dtgReferencias_ctl" + index + "_txtgrdNomAgente")!= null)
				{
					if (document.getElementById("dtgReferencias_ctl" + index + "_txtgrdNomAgente").value=='')
					{
						if (!validatePartAgente())
							return false;

						InsertaGrdAgente(i);
						CleanTxtsAgente();
						if(document.getElementById("txtId").value!='')
							paintWhiteAgente(document.getElementById("txtId").value);
						paintWhiteAgente(i);
						document.all("HidTotalAgentes").value = parseInt(document.all("HidTotalAgentes").value) + 1;
						
						//
						return false;
					}//if
				}//if
			}//for
		}//if
		else
		{
			window.alert("No se pueden insertar mas de 4 agentes");
			CleanTxtsAgente();
			return false;
		}
		alert('No existen renglones.');
		EnabledValidaAgente(false);		
	}	
	return false;
}

function ModificaAgentecedentes()
{
	var i = document.getElementById("txtId").value;
	if (i == '')
		alert('No existe un renglon seleccionado.');
	else
	{
		EnabledValidaAgente(true);
		if(Page_ClientValidate("TablaAgentes") && ValidaRepAgente(i) && validatePartAgente())
		{
			InsertaGrdAgente(i);
			CleanTxtsAgente();
			paintWhiteAgente(i);
			EnabledValidaAgente(false);
			//
		}
	}
	return false;
}

function VerPago()
{
	Opcion=document.getElementById("wucDatGralContratante_ddlTipoPago").options[document.getElementById("wucDatGralContratante_ddlTipoPago").selectedIndex].value;//WUCPoliza2_ddlTipoPago
	switch(Opcion)
	{
		case "BA":AuxBanco = window.open("Bancos2.aspx?Opcion=CUENTA DE CHEQUES", "tinyWindow", 'width=700,height=500,toolbar=0,resizable=0');break;
		case "TA":AuxBanco = window.open("Bancos2.aspx?Opcion=TARJETA DE CREDITO", "tinyWindow", 'width=700,height=500,toolbar=0,resizable=0');break;
		case "OF":AuxBanco = window.open("Bancos2.aspx?Opcion=MESES SIN INTERESES", "tinyWindow", 'width=700,height=500,toolbar=0,resizable=0');break;
	}
	return false;
}

function BorrarAgentecedentes()
{
	var i = document.getElementById("txtId").value;
	if (i == '')
		alert('No existe un rengl�n seleccionado.');
	else if (document.getElementById("txtClaveA").value  == document.getElementById("txtClaveAgen").value)
		alert('El registro no puede ser borrado.');
	else
	{
		CleanTxtsAgente();
		CleanGrdAgente(i);
		document.all("HidTotalAgentes").value = parseInt(document.all("HidTotalAgentes").value) - 1;
		
	}
	return false;
}

function CleanTxtsAgente(){
	document.getElementById("txtClaveA").value = '';
	document.getElementById("txtNombreAgente").value = '';	
	document.getElementById("txtPorcentaje").value = '';
	document.getElementById("hidCveGestor").value = '';
}

function ExtraeGrdAgente(i)
{
	ActivaAdicional();
	var index = ((parseInt(i) < 10) ? "0"+i : i);
	document.getElementById("txtClaveA").value = document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave").value;
	if (document.getElementById("txtClaveA").value  == document.getElementById("txtClaveAgen").value)
		document.getElementById("txtClaveA").disabled = true;
	
	document.getElementById("txtNombreAgente").value = document.getElementById("dtgReferencias_ctl" + index + "_txtgrdNomAgente").value;
	document.getElementById("txtPorcentaje").value = document.getElementById("dtgReferencias_ctl" + index + "_txtgrdPorcentaje").value;
	document.getElementById("hidCveGestor").value = document.getElementById("dtgReferencias_ctl" + index + "_hidgrdCveGestor").value;
	
	if(document.getElementById("drpAgente") != null && i == "2")
	{
		if(selIndex("drpIntMasDeUnAgente") == "0")
		{
			document.getElementById("txtPorcentaje").disabled = true;
		}
	}
}

//Inserta el 1er. Agente
function InsertaGrd_1erAgente(i){
    var index = ((parseInt(i) < 10) ? "0"+i : i);
	document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave").value = document.getElementById("txtClaveA").value;
	document.getElementById("dtgReferencias_ctl" + index + "_txtgrdNomAgente").value = document.getElementById("txtAgente").value;
	document.getElementById("dtgReferencias_ctl" + index + "_txtgrdPorcentaje").value = document.getElementById("txtPorcentaje").value;	
	document.getElementById("dtgReferencias_ctl" + index + "_hidgrdCveGestor").value = document.getElementById("hidCveGestor").value;	
	document.getElementById("txtTotPor").value = document.getElementById("txtPorcentaje").value; //parseFloat(document.getElementById("WUCInfAgente_txtPorcentaje").value) + parseFloat(document.getElementById("WUCInfAgente_txtTotPor").value);
	//Desactivamos algunos campos
	document.getElementById("txtClaveA").disabled = true;		
	document.getElementById("txtPorcentaje").disabled = true;				
}

function InsertaGrdAgente(i){
    var index = ((parseInt(i) < 10) ? "0"+i : i);
	document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave").value = document.getElementById("txtClaveA").value;
	document.getElementById("dtgReferencias_ctl" + index + "_txtgrdNomAgente").value = document.getElementById("txtNombreAgente").value;	
	document.getElementById("dtgReferencias_ctl" + index + "_txtgrdPorcentaje").value = document.getElementById("txtPorcentaje").value;	
	document.getElementById("dtgReferencias_ctl" + index + "_hidgrdCveGestor").value = document.getElementById("hidCveGestor").value;	
	document.all("HidTotalPorcentaje").value = parseFloat(document.getElementById("txtPorcentaje").value) + parseFloat(document.all("HidTotalPorcentaje").value);	

	//window.alert("************** Total Participacion *********** " + docuemtn.getElementById("WUCPoliza2_HidTotalPorcentaje").value);	
	//window.alert(document.all("WUCPoliza2_HidTotalPorcentaje").value);
	
	//activamos la clave del agente si Combo es SI
	if(document.all("drpIntMasDeUnAgente").selectedIndex == 1)
	{document.getElementById("txtClaveA").disabled = false;}	
}

function CleanNomAgente(){
	//document.getElementById("txtAgente").value = '';
}
function CleanGrdAgente(i){
    var index = ((parseInt(i) < 10) ? "0"+i : i);
	if (document.getElementById("dtgReferencias_ctl" + index + "_txtgrdPorcentaje").value != ''){
		document.all("HidTotalPorcentaje").value = parseFloat(document.all("HidTotalPorcentaje").value) - parseFloat(document.getElementById("dtgReferencias_ctl" + index + "_txtgrdPorcentaje").value);		
	}
	
	document.getElementById("dtgReferencias_ctl" + index + "_txtgrdNomAgente").value = '';
	document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave").value = '';
	document.getElementById("dtgReferencias_ctl" + index + "_txtgrdPorcentaje").value = '';
	paintWhiteAgente(i);
}

function paintWhiteAgente(id){
	color = 'white';
	var index = ((parseInt(id) < 10) ? "0"+id : id);
	document.getElementById("dtgReferencias_ctl" + index + "_txtgrdNomAgente").style.background = color;
	document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave").style.background = color;
	document.getElementById("dtgReferencias_ctl" + index + "_txtgrdPorcentaje").style.background = color;
	document.getElementById("txtId").value = '';
}

function ValidaRepAgente(idMod){
	Agente = document.form1.txtClaveA.value;
	for (id=0;id < 10; id++){
	    var index = ((parseInt(id) < 10) ? "0"+id : id);
		if (document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave")!= null){
			obj = document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave");
			if (obj.value == Agente && idMod != id){
				//alert('El agente ya ha sido insertado en el grid');
				alert('En la lista, verifique si desea modificar');
				return(false);
			}
		}	
	}	
	return(true);
}

function validatePartAgente(){
	var totPart = 0;	          	
	var id = document.getElementById("txtId").value;		
	
	if (parseFloat(document.getElementById("txtPorcentaje").value) > 100){
		CleanTxtsAgente();
		RegresaValoresDefault();
		alert('La participacion no puede exceder el 100%');		
		return(false);
	}
	else{	    
		var id = document.getElementById("txtId").value;			
		//si es modificacion checamos que la no se exceda el 100% 
		//si es menor se elimina el monto anterior de la participacion total
		if (id != ''){
		    var index = ((parseInt(id) < 10) ? "0"+id : id);
			if (document.getElementById("dtgReferencias_ctl" + index + "_txtgrdPorcentaje").value != '' && parseFloat(document.getElementById("txtPorcentaje").value) > 0){
				actPart = parseFloat(document.all("HidTotalPorcentaje").value) - parseFloat(document.getElementById("dtgReferencias_ctl" + index + "_txtgrdPorcentaje").value);
				totPart = actPart + parseFloat(document.getElementById("txtPorcentaje").value);
				if (parseFloat(totPart) <= 100)
				{					
					document.all("HidTotalPorcentaje").value = actPart;				
				}
			}
		}
		else{					
			totPart = parseFloat(document.getElementById("txtPorcentaje").value) + parseFloat(document.all("HidTotalPorcentaje").value);
		}
	}			
	if(parseFloat(totPart) > 100){
		CleanTxtsAgente();
		RegresaValoresDefault();
		alert('La participacion no puede exceder el 100%');
		return(false);
	}	
	return(true);
}

function EnabledValidaAgente(blnActiva){	
	ValidatorEnable(document.all("rfvCveAgente"), blnActiva);
	ValidatorEnable(document.all("rfvPorcentaje"), blnActiva);
}


function AsignaCveA()
{
	if (document.all("drpIntMasDeUnAgente").selectedIndex == 1)//Cuando interviene m�s de un agente es SI
	{
		document.form1.txtClaveA.disabled = false;
		document.form1.txtPorcentaje.disabled = false;
		//Limpia Campos
		document.form1.txtPorcentaje.value ="";
		
		
		//Modificaci�n para tron web
		document.form1.txtClaveA.value = "";
		//document.form1.WUCPoliza2_txtNombreAgente.value = "";
		document.form1.txtPorcentaje.value = "";
	}
	else
	{
		document.form1.txtClaveA.disabled = true;
		//document.form1.WUCPoliza2_txtNombreAgente.disabled = true;
		document.form1.txtPorcentaje.disabled = true;
		
		//Limpia Campos
		document.form1.txtPorcentaje.value ="";
		
		//Modificaci�n para tron web
		document.form1.txtClaveA.value = "";
		//document.form1.WUCPoliza2_txtNombreAgente.value = "";
		document.form1.txtPorcentaje.value = "";
	}
	if(document.getElementById("txtId").value!='')
		paintWhiteAgente(document.getElementById("txtId").value);
	document.getElementById("txtId").value = '';
}

function ActivaAdicional()
{	
	document.getElementById("txtClaveA").disabled=false;
	document.getElementById("txtPorcentaje").disabled=false;
}

function RegresaValoresDefault()
{
	document.getElementById("drpIntMasDeUnAgente").selectedIndex = 1;
	document.getElementById("txtClaveA").disabled = true;
	document.getElementById("txtNombreAgente").disabled = true;	
	document.getElementById("txtPorcentaje").disabled = true;	
}

//Valida que la captura de datos sea correcta
//de acuerdo a un patron de captura.
function ValidaCaptura(ExpReg)
{	
	gExp = ExpReg; //gExp es una variable global que se utiliza para validar.
	
	if (!(navigator.appName == 'Netscape'))
	{
		var Ev = window.event;
		//El "event.srcElement.id" de IE es equivalente a "event.target.id" de NS.	

		if ( (Ev) && (Ev.keyCode) ){
			var newKey = Ev.keyCode; 
			var teclaReal = String.fromCharCode(newKey);

			if(newKey==13)
				Ev.keyCode = 13;
			else
			{
				if (!(ExpReg.test(teclaReal)))
				{
					newKey = 0;
				}
				Ev.keyCode = newKey; 
			}
		}
    }
}