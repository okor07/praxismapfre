﻿//'****************************************************************************
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2010
//'Name of the file              : LlenadoDeDrops.js
//'Creation/Modification History :
//'Modification                  : emontoya  Indra SWLabs
//'C1                            : emontoya - 30-12-2012
//                               : Se agrega el método LlenarParentesco.
//'C2                            : emontoya - 30-12-2012
//                               : Se agrega el método obtenerPrimeraModalidad.
//                               : Así mismo se agrega el llamado del método en la función
//                               : LlenarDropFormaPago.
//'C3                            : emontoya - 30-12-2012
//                               : Se agregan los parámetros:Ramo, Modalidad
//                               : y contrato al método getTipoPago.
//'C4                            : emontoya - 30-12-2012
//                               : Se crea el método LlenarOcupacion
//'C5                            : jchuertas - 14-11-2013
//                               : Se crea el cuestionario por medio de llamado ajax
//								   después del calculo de la modalidad
//'C6                            : jchuertas - 19-11-2013
//                               : Corrección de mensaje mostrado de forma incorrecta (repetidamente)
//'C7                            : jglopezh - 20-11-2013
//                               : Se crea la variable tipoPlan y se envia como parámetro
//                               : al método getDuracion
//'C8                            : jchuertas - 20-11-2013
//03052018
//                               : Solamente se marca para meridiano y preferente
//                               : Adicional se crea la variable tipoPLan
//'C9                            : HEAQUINO
//fecha                          : 30/01/2019
//clave proyecto                 : MU-2019-002177
//nombre proyecto                : MX_NC_VID RE TARIFICACIÓN DEL PRODUCTO JUBILACIÓN
//desc                           : Se crea funcion para validar la edad del ramo 101 dependiendo la moneda
//								 : Cuestionario Enfermedades respiratorias
//'*****************************************************************************
function limpiaCtrlsConAgente() {
    setPolizaConContrato(false);
}

function LlenarPlanyMoneda(pcomboFill) {
    var Ramo = document.getElementById("HiddenRamoRequest").value;

    limpiaCtrlsConMoneda();

    comboFill = pcomboFill;
    valFill = 'COD_MON';
    txtFill = 'NOM_MON';
    NombreFuncionDrop = 'LlenarDropCrecimiento';
    comboFillAuto = 'drpCrecimiento';
    bdrContinuar = true;

    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    var tipoPlan = document.getElementById("HiddenTipoPlanRequest").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked && !(document.getElementById("drpContrato").value === undefined)) {
        contrato = selIndex("drpContrato");
    }
    MetodosAjax.getMoneda(Ramo, contrato, tipoPlan, llenaCombo_CallBack);
}

function LlenarDropCrecimiento(pcomboFill) {
    limpiaCtrlsConMoneda();

    comboFill = pcomboFill;

    //Se valida el plan en el que se trabaja para llenar el Crecimiento, ya 
    //que para jubilación los nombres de los campos son diferentes.
    if (document.getElementById("HiddenRamoRequest").value != "101") {
        valFill = 'TIP_REGULARIZA_SUMA|PCT_REGULARIZA_SUMA';
        txtFill = 'NOM_CRECIMIENTO';
    }
    else {
        valFill = 'TIP_REGULARIZA_PRIMA|PCT_REGULARIZA_PRIMA';
        txtFill = 'NOM_CRECIMIENTO_PRIMA';
    }
    NombreFuncionDrop = 'LlenarDropDeducible';
    comboFillAuto = 'drpDeducible';
    bdrContinuar = true;

    var PlanRamo = document.getElementById("HiddenRamoRequest").value;

    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Crecimiento.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    var tipoPlan = document.getElementById("HiddenTipoPlanRequest").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    MetodosAjax.getCrecimiento(PlanRamo, contrato, selIndex("drpMoneda"), tipoPlan, llenaCombo_CallBack);
}

function limpiaCtrlsConMoneda() {
    limpiaCombo("drpCrecimiento");
    //Se valida que control se limpiará al Momento de cambiar el DropMoneda
    //ya que en los planes que no sean jubilación el drpDeducible aparecerá oculto y no podrá ser encontrado.
    if (document.getElementById("HiddenRamoRequest").value == "101")
        limpiaCombo("drpDeducible");
    else
        document.getElementById("HiddenDeducible").value = "";

    limpiaCombo("drpPlazo");
    limpiaCombo("drpComision");

    limpiaCombo("drpFormaPago");
    limpiaCombo("drpTipoPago");

    //MGM_MSI
    document.getElementById("chkMSI").checked = false;
    document.getElementById("trMSI").style.display = 'none';

    document.getElementById('DivCoberturas').innerHTML = "";
    document.getElementById('divPrimas').innerHTML = "";

    LimpiarDatosDelSeguro(false);
}

function LlenarDropDeducible(pcomboFill) {
    limpiaCtrlsConCrecimiento();

    comboFill = pcomboFill;
    valFill = 'TIP_DEDUCIBLE';
    txtFill = 'NOM_VALOR';
    NombreFuncionDrop = 'LlenarDropDuracion';
    comboFillAuto = 'drpPlazo';
    bdrContinuar = true;

    var PlanRamo = document.getElementById("HiddenRamoRequest").value;
    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    //Se valida como se llenará el Combo de deducible para el Caso de Jubilación a través del drpDeducible
    //para los demás casos se llenará por el control "HiddenDeducible".
    //La función "getDeducibleNoJubilación" deberá regresar solo un valor.
    if (document.getElementById("HiddenRamoRequest").value == "101")
        MetodosAjax.getDeducible(PlanRamo, contrato, selIndex("drpMoneda"), selValorCtrl("drpCrecimiento", 0), llenaCombo_CallBack);
    else
        MetodosAjax.getDeducibleNoJubilacion(PlanRamo, contrato, selIndex("drpMoneda"), selValorCtrl("drpCrecimiento", 0), llenaDuracion_CallBack);
}

function ValidarEdadNM() {
    var edad = document.getElementById("txtEdad").value;
    var plazo = document.getElementById("drpPlazo").value;
    var edad_maxima;



    if (edad < 18) {
        alert("La edad minima permitida para este plan es: 18 años");
        limpiaCtrlsConDuracion();
        limpiaCtrlsConCrecimiento();
        document.getElementById("drpMoneda").value = 0;
        document.getElementById("txtEdad").value = "";
        document.getElementById("txtEdad").focus();
    }
    else {
        edad_maxima = parseInt(plazo) - 5;
        if (edad > edad_maxima) {
            alert("La edad máxima permitida para este plan es: " + edad_maxima.toString() + " años");
            limpiaCtrlsConDuracion();
            limpiaCtrlsConCrecimiento();
            document.getElementById("drpMoneda").value = 0;
            document.getElementById("txtEdad").value = "";
            document.getElementById("txtEdad").focus();
        }
    }
}

function llenaDuracion_CallBack(res) {
    if (res.error == null) {
        if (res != null && res.value != null) {
            document.getElementById("HiddenDeducible").value = res.value;

            var FunctionDuracion = "LlenarDropDuracion('drpPlazo');";
            eval(FunctionDuracion);
        }
    }
}

function limpiaCtrlsConCrecimiento() {
    //Se valida que control se limpiará al Momento de cambiar el drpCrecimiento
    //ya que en los planes que no sean jubilación el drpDeducible aparecerá oculto y no podrá ser encontrado.
    if (document.getElementById("HiddenRamoRequest").value == "101")
        limpiaCombo("drpDeducible");
    else
        document.getElementById("HiddenDeducible").value = "";

    limpiaCombo("drpPlazo");
    limpiaCombo("drpComision");
    limpiaCombo("drpFormaPago");
    limpiaCombo("drpTipoPago");
}

function LlenarDropDuracion(pcomboFill) {
    limpiaCtrlsConDuracion();

    comboFill = pcomboFill;
    valFill = 'DURACION_HASTA';
    txtFill = 'DURACION_HASTA';
    NombreFuncionDrop = 'LlenarDropComision';
    comboFillAuto = 'drpComision';
    bdrContinuar = true;

    var PlanRamo = document.getElementById("HiddenRamoRequest").value;
    // <---- C7 ---->
    var tipoPlan = document.getElementById("HiddenTipoPlanRequest").value;
    // <------------>
    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Duración.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    var Deducible = "-1"
    if (document.getElementById("HiddenRamoRequest").value == "101")
        Deducible = selIndex("drpDeducible");
    else
        Deducible = document.getElementById("HiddenDeducible").value;


    if (tipoPlan == "12" && Deducible == "3") {
        tipoPlan = "12002";
    } else if (tipoPlan == "12003" || tipoPlan == "12004") {
        if (Deducible == 1 || Deducible == 2) {
            tipoPlan = "12004";
            document.getElementById("HiddenTipoPlanRequest").value = "12004";
        } else if (Deducible == 3) {
            tipoPlan = "12003";
            document.getElementById("HiddenTipoPlanRequest").value = "12003";
        }
    }


    // <---- C7 ---->
    MetodosAjax.getDuracion(PlanRamo, contrato, selIndex("drpMoneda"), selValorCtrl("drpCrecimiento", 0), Deducible, tipoPlan, llenaCombo_CallBack);
}

function limpiaCtrlsConDuracion() {
    limpiaCombo("drpComision");
    limpiaCombo("drpFormaPago");
    limpiaCombo("drpTipoPago");
}

function LlenarDropComision(pcomboFill) {
    comboFill = pcomboFill;
    valFill = 'TIP_COMISION';
    txtFill = 'NOM_VALOR';
    NombreFuncionDrop = 'LlenarDropComision';
    comboFillAuto = 'drpFormaPago';
    bdrContinuar = true;

    //MGM_MSI
    document.getElementById("trMSI").style.display = 'none';
    document.getElementById("chkMSI").checked = false;

    var PlanRamo = document.getElementById("HiddenRamoRequest").value;
    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }
    var tipoPlan = document.getElementById("HiddenTipoPlanRequest").value;

    var Deducible = "-1"
    if (document.getElementById("HiddenRamoRequest").value == "101")
        Deducible = selIndex("drpDeducible");
    else
        Deducible = document.getElementById("HiddenDeducible").value;

    if (PlanRamo == "101" && tipoPlan == "12" && Deducible == "3") {
        tipoPlan = "12002"
    }

    MetodosAjax.getComision(PlanRamo, contrato, selIndex("drpMoneda"), selValorCtrl("drpCrecimiento", 0), Deducible, selIndex("drpPlazo"), tipoPlan, llenaComboComision_CallBack);
}


function LlenarDropPolizaGrupo(pcomboFill) {
    limpiaCtrlsConPolizaGrupo();

    comboFill = pcomboFill;
    valFill = 'NUM_POLIZA_GRUPO';
    txtFill = 'NUM_POLIZA_GRUPO';
    NombreFuncionDrop = 'LlenarDropContrato';
    comboFillAuto = 'drpContrato';
    bdrContinuar = true;

    var Ramo = document.getElementById("HiddenRamoRequest").value;

    MetodosAjax.getPolizaGrupo(Ramo, selIndex("drpAgente"), llenaCombo_CallBack);
}

function limpiaCtrlsConPolizaGrupo() {
    limpiaCombo("drpContrato");
    limpiaCtrlsConMoneda();
}

function LlenarDropContrato(pcomboFill) {
    limpiaCtrlsConMoneda();

    comboFill = pcomboFill;
    valFill = 'NUM_CONTRATO';
    txtFill = 'NUM_CONTRATO';
    NombreFuncionDrop = 'LlenarPlanyMoneda';
    comboFillAuto = 'drpMoneda';
    bdrContinuar = true;

    var Ramo = document.getElementById("HiddenRamoRequest").value;

    MetodosAjax.getContratos(Ramo, selIndex("drpPolizaGrupo"), selIndex("drpAgente"), llenaCombo_CallBack);
}

function LlenarFormaPago(pcomboFill, bdrLlenado) {
    comboFill = pcomboFill;
    valFill = 'COD_FRACC_PAGO';
    txtFill = 'NOM_FRACC_PAGO';
    NombreFuncionDrop = '';
    comboFillAuto = '';
    bdrContinuar = false;

    var Ramo = document.getElementById("HiddenRamoRequest").value;
    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    var Modalidad = document.getElementById("HiddenModalidad").value;

    if (bdrLlenado)
        MetodosAjax.getFormasPago(Ramo, Modalidad, contrato, llenaComboFormaPago_CallBack);
    else
        MetodosAjax.getFormasPago(Ramo, Modalidad, contrato, llenaCombo_CallBack);

}

/// <summary>
///     Este método se encarga de llenar el combo drpFormaPago según la modalidad y 
///     el contrato.
/// </summary>
function LlenarDropFormaPago(pcomboFill) {
    limpiaCtrlsConFormaPago();

    comboFill = pcomboFill;
    valFill = 'COD_VALOR';
    txtFill = 'NOM_VALOR';
    NombreFuncionDrop = 'LlenarDropTipoPago';
    comboFillAuto = 'drpTipoPago';
    bdrContinuar = false;

    var Ramo = document.getElementById("HiddenRamoRequest").value;
    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    // var Modalidad = document.getElementById("HiddenModalidad").value;
    // <--- C2 --->
    var Modalidad = obtenerModalidadSencilla();

    if (Modalidad.error == null) {
        if (Modalidad != null && Modalidad.value != null) {
            var arrModalidadEdad = new Array();
            arrModalidadEdad = Modalidad.value.split('|');
            var ModalidadSencilla = arrModalidadEdad[0];
        }
    }
    // -----------

    MetodosAjax.getFormasPago(Ramo, ModalidadSencilla, contrato, llenaCombo_CallBack);
}

// <--- C2 --->
/// <summary>
///     Método que obtiene la modalidad.
/// </summary>
function obtenerModalidadSencilla() {
    var PlanRamo = document.getElementById("HiddenRamoRequest").value;
    // <--- C7 --->
    var tipoPlan = document.getElementById("HiddenTipoPlanRequest").value;
    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    var Deducible = "-1"
    if (document.getElementById("HiddenRamoRequest").value == "101")
        Deducible = selIndex("drpDeducible");
    else
        Deducible = document.getElementById("HiddenDeducible").value;

    var Comision = 1;
    if (document.getElementById("drpComision").selectedIndex > 0) {
        Comision = selIndex("drpComision");
    }

    var marMerPref = "N";

    // <--- C8 --->
    if (tipoPlan == "2" || tipoPlan == "4") {
        if (document.getElementById("chkBxMeridianoPrefe").checked == true)
            marMerPref = "S";
    }

    return MetodosAjax.getModalidad(PlanRamo, contrato, selIndex("drpMoneda"), selValorCtrl("drpCrecimiento", 0),
        Deducible, Comision, selIndex("drpPlazo"), marMerPref, tipoPlan);
}
// -----------

function limpiaCtrlsConFormaPago() {
    limpiaCombo("drpTipoPago");
}

/// <summary>
///     Este método se encarga de llenar el combo drpTipoPago según la modalidad, 
///     el contrato y forma de pago seleccionados.
/// </summary>
function LlenarDropTipoPago(pcomboFill) {
    comboFill = pcomboFill;
    valFill = 'TIP_GESTOR';
    txtFill = 'NOM_TIP_GESTOR';
    NombreFuncionDrop = 'ConsultaOcupacion';
    comboFillAuto = 'drpOcupacion';
    bdrContinuar = false;

    // <--- C3 --->
    var Ramo = document.getElementById("HiddenRamoRequest").value;
    var Modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = document.getElementById("HiddenContratoGenerico").value;

    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    //MGM_MSI
    if (document.getElementById("rbtnListPolizaContrato_0").checked) {
        if (selIndex("drpFormaPago") == "1") {
            document.getElementById("trMSI").style.display = 'block';
            //document.getElementById("chkMSI").checked = false; 

        }
        else {
            document.getElementById("trMSI").style.display = 'none';
            document.getElementById("chkMSI").checked = false;
        }
    }
    else {
        document.getElementById("trMSI").style.display = 'none';
        document.getElementById("chkMSI").checked = false;
    }

    MetodosAjax.getTipoPago(Ramo, Modalidad, contrato, selIndex("drpFormaPago"), llenaCombo_CallBack);
    // <---------->
}

function ObtenerModalidad() {
    var PlanRamo = document.getElementById("HiddenRamoRequest").value;
    // <--- C7 --->
    var tipoPlan = document.getElementById("HiddenTipoPlanRequest").value;
    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    var Deducible = "-1"
    if (document.getElementById("HiddenRamoRequest").value == "101")
        Deducible = selIndex("drpDeducible");
    else
        Deducible = document.getElementById("HiddenDeducible").value;

    var Comision = "";
    if (document.getElementById("drpComision").selectedIndex > 0) {
        Comision = selIndex("drpComision");
    }

    var marMerPref = "N";

    // <--- C8 --->
    if (tipoPlan == "2" || tipoPlan == "4") {
        if (document.getElementById("chkBxMeridianoPrefe").checked == true)
            marMerPref = "S";

    }

    if (PlanRamo == "101" && tipoPlan == "12" && Deducible == "3") {
        tipoPlan = "12002";
    }

    var Modalidad = MetodosAjax.getModalidad(PlanRamo, contrato, selIndex("drpMoneda"), selValorCtrl("drpCrecimiento", 0), Deducible, Comision, selIndex("drpPlazo"), marMerPref, tipoPlan);


    if (Modalidad.error == null) {
        if (Modalidad != null && Modalidad.value != null) {
            var arrModalidadEdad = new Array();
            arrModalidadEdad = Modalidad.value.split('|');
            document.getElementById("HiddenModalidad").value = arrModalidadEdad[0];
            document.getElementById("HiddenEdadTopeMin").value = arrModalidadEdad[1];
            document.getElementById("HiddenEdadTopeMax").value = arrModalidadEdad[2];

            if (parseInt(document.getElementById("txtEdad").value) < parseInt(document.getElementById("HiddenEdadTopeMin").value) || parseInt(document.getElementById("txtEdad").value) > parseInt(document.getElementById("HiddenEdadTopeMax").value)) {
                if (document.getElementById("HiddenRamoRequest").value == "105") {
                    if (parseInt(selIndex("drpParentesco1")) != 4 || parseInt(selIndex("drpParentesco1")) != 37) {
                        //---C6---
                        if (document.getElementById("hdnBanderaModalidad").value == 0) {
                            document.getElementById("hdnBanderaModalidad").value = 1;
                            alert("Edad de Aceptación de " + arrModalidadEdad[1] + " a " + arrModalidadEdad[2]);
                        }

                        document.getElementById("txtEdad").value = "";
                        focusCtrl("txtEdad");
                    }
                } else {
                    if (document.getElementById("hdnBanderaModalidad").value == 0) {
                        document.getElementById("hdnBanderaModalidad").value = 1;
                        alert("Edad de Aceptación de " + arrModalidadEdad[1] + " a " + arrModalidadEdad[2]);
                    }

                    document.getElementById("txtEdad").value = "";
                    focusCtrl("txtEdad");
                }

            }
            else {
                obtenerCoberturas();
            }

            LlenarDropFormaPago('drpFormaPago')
            //----C5-----
            devuelveCuestionario();
        }
    }

}

///----C5-----
/// <summary>
///     Este método se encarga de hacer el llamado para la carga del cuestionario 
///     el contrato.
/// </summary>
function devuelveCuestionario() {
    var Ramo = document.getElementById("HiddenRamoRequest").value;
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    var Modalidad = document.getElementById("HiddenModalidad").value;

    MetodosAjax.devuelveCuestionario(Ramo, Modalidad, contrato, cuestionario_CallBack);
}

function cuestionario_CallBack(res) {
    if (res.error == null) {
        if (res != null && res.value != null) {
            var newdiv = document.createElement("div");
            newdiv.innerHTML = res.value;
            var container = document.getElementById("divCuestionario");
            container.innerHTML = "";
            container.appendChild(newdiv);

            if (document.getElementById("divCuestionario").innerHTML == "")
                document.getElementById("divCuestionario").innerHTML = res.value;

            AjustarFrame();
            setMaxDate();
        }
    }
}



function ValidarEdad() {
    var plazo
    if (document.getElementById("HiddenRamoRequest").value == "105") {
        plazo = selValorCtrl("drpPlazo");
        if (document.getElementById("HiddenModalidad").value != "-1")
            var topeMinimo = parseInt(selIndex("drpParentesco1")) == 4 || parseInt(selIndex("drpParentesco1")) == 37 ? 17 : parseInt(document.getElementById("HiddenEdadTopeMin").value);
            if (parseInt(document.getElementById("txtEdad").value) < topeMinimo || parseInt(document.getElementById("txtEdad").value) > 10) {
                if (parseInt(selIndex("drpParentesco1")) != 4 && parseInt(selIndex("drpParentesco1")) != 37) {
                    switch (plazo) {
                        case "15":
                            alert("Edad de Aceptación de " + document.getElementById("HiddenEdadTopeMin").value + " a 10 años para el plazo " + plazo);
                            document.getElementById("txtEdad").value = "";
                            focusCtrl("txtEdad");
                            break;
                        case "18":
                            if (parseInt(document.getElementById("txtEdad").value) > 13) {
                                alert("Edad de Aceptación de " + document.getElementById("HiddenEdadTopeMin").value + " a 13 años para el plazo " + plazo);
                                document.getElementById("txtEdad").value = "";
                                focusCtrl("txtEdad");
                            }
                            break;
                        case "22":
                            if (parseInt(document.getElementById("txtEdad").value) > 17) {
                                alert("Edad de Aceptación de " + document.getElementById("HiddenEdadTopeMin").value + " a 17 años para el plazo " + plazo);
                                document.getElementById("txtEdad").value = "";
                                focusCtrl("txtEdad");
                            }
                            break
                        default:
                            alert("Edad de Aceptación de " + document.getElementById("HiddenEdadTopeMin").value + " a " + document.getElementById("HiddenEdadTopeMax").value + "Para el plazo " + plazo);
                            document.getElementById("txtEdad").value = "";
                            focusCtrl("txtEdad");
                    }


                } else {
                    if (parseInt(document.getElementById("txtEdad").value) < 18 || parseInt(document.getElementById("txtEdad").value) > 70) {
                        alert("Edad de Aceptación de " + 18 + " a " + 70 + " para Titular y Mancomunado ");
                        document.getElementById("txtEdad").value = "";
                        focusCtrl("txtEdad");
                    }
                }
            }
    } else {
        if (document.getElementById("HiddenModalidad").value != "-1")
            if (parseInt(document.getElementById("txtEdad").value) < parseInt(document.getElementById("HiddenEdadTopeMin").value) || parseInt(document.getElementById("txtEdad").value) > parseInt(document.getElementById("HiddenEdadTopeMax").value)) {
                alert("Edad de Aceptación de " + document.getElementById("HiddenEdadTopeMin").value + " a " + document.getElementById("HiddenEdadTopeMax").value);
                document.getElementById("txtEdad").value = "";
                focusCtrl("txtEdad");
            }
    }

    if (document.getElementById("HiddenRamoRequest").value == "101") {
        if (parseInt(document.getElementById("txtEdad").value) < parseInt(18)) {
            alert("La edad mínima es de 18 años");
            document.getElementById("txtEdad").value = "";
            focusCtrl("txtEdad");
        }
    }
}

// <--- C1 --->
/// <summary>
///     Este método se encarga de llenar el combo drpParentesco según el tipo de seguro que 
///     el usuario seleccione.
/// </summary>
function LlenarParentesco(pcomboFill, tipoSeguro) {
    comboFill = pcomboFill;
    valFill = 'COD_VALOR';
    txtFill = 'NOM_VALOR';
    NombreFuncionDrop = '';
    comboFillAuto = '';
    bdrContinuar = false;

    var Ramo = document.getElementById("HiddenRamoRequest").value;
    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var Modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = document.getElementById("HiddenContratoGenerico").value;

    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    MetodosAjax.getParentescoSeguro(Ramo, Modalidad, contrato, tipoSeguro, selIndex("drpTipBenef"), llenaCombo_CallBack);
}

/// <summary>
///     Este método se encarga de llenar el combo drpOcupacion según el código del Ramo,
///     modalidad y número de contrato.
/// </summary>
function LlenarOcupacion(pcomboFill) {
    comboFill = pcomboFill;
    valFill = 'COD_PROFESION';
    txtFill = 'NOM_PROFESION';
    NombreFuncionDrop = '';
    comboFillAuto = '';
    bdrContinuar = false;

    var Ramo = document.getElementById("HiddenRamoRequest").value;
    //Se valida que contrato se pasará como parámetro para el Llenado del tipo de Moneda.
    //Si en la sección de "Poliza Contrato" se encuentra seleccionado el Botón "No"
    //se tomará el valor del Contrato genérico de lo contrario el valor del contrato seleccionado
    //en el drpContrato.
    var Modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = document.getElementById("HiddenContratoGenerico").value;

    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    MetodosAjax.getOcupacion(Ramo, Modalidad, contrato, llenaCombo_CallBack);
}

//MGM_MSI
function mesesSI() {
    if (document.getElementById("chkMSI").checked == true) {
        var Ramo = document.getElementById("HiddenRamoRequest").value;
        var REsBanMSI = MetodosAjax.ObtieneBancosMSI(Ramo, selIndex("drpFormaPago"));
        if (REsBanMSI.error == null && REsBanMSI.value != "") {
            //alert("Las tarjetas participantes para Meses Sin Intereses son: " + REsBanMSI.value);
            alert("El cargo en l\u00EDnea podr\u00E1 realizarse con las tarjetas HSBC, Santander y Scotiabank. Para Banamex y AMEX la emisi\u00F3n deber\u00E1 solicitarse en la oficina de Servicio y el cargo a trav\u00E9s de SI24.");
            document.getElementById("drpTipoPago").selectedIndex = 3;
            document.getElementById("drpTipoPago").disabled = true;
        }
        else {
            alert("No hay tarjetas que tengan la promocion de Meses Sin Interes");
            document.getElementById("chkMSI").checked = false;
        }
    }
    else {
        document.getElementById("drpTipoPago").disabled = false;
    }
}
//C9
function ValidaEdadJubilacion() {
    var edad = document.getElementById("txtEdad").value;
    var moneda = document.getElementById("drpMoneda").value;
    var plazo = document.getElementById("drpPlazo").value;
    var edad_maxima;

    //    if (moneda == "1") 
    //        edad_maxima = parseInt(plazo) - 10;    
    //    else
    //        edad_maxima = parseInt(plazo) - 15;
    //    if (edad > edad_maxima) {        
    //        alert("La edad máxima permitida para este plan es: " + edad_maxima.toString()+" años");
    //        limpiaCtrlsConDuracion();
    //        limpiaCtrlsConCrecimiento();
    //        document.getElementById("drpMoneda").value = 0;
    //        document.getElementById("txtEdad").value = "";
    //        document.getElementById("txtEdad").focus();
    //    }
}

function setMaxDate() {

    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1;
    var yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }

    today = yyyy + '-' + mm + '-' + dd;

    var inputs = document.querySelectorAll('input[type="date"]');
    inputs.forEach(item => {
        if (item.id != 'txt23a' && item.id != 'txt23b')
            item.setAttribute("max", today);

    });
}





