﻿function validaAgente() {
    var result = true;
    if (document.getElementById("drpAgente").options.length > 1) {
        if (selIndiceCtrl("drpAgente") < 1) {
            alert("DEBES SELECCIONAR UN AGENTE.");
            focusCtrl("drpAgente");
            result = false;
        }
    }
    return result;
}

function validaDatosAsegurado() {
    var result = true;
    var noCapturados = "";
    if (document.getElementById("txtEdad").value == "") {
        if (document.getElementById("HiddenRamoRequest").value == "105") {

        } else {
            focusCtrl("txtEdad");
        }
        noCapturados = "EDAD.";
        result = false;

    }

    if (result == true && document.getElementById("txtIngresoM").value == "") {
        focusCtrl("txtIngresoM");
        noCapturados = "INGRESO MENSUAL.";
        result = false;
    }

    //Valida Edad Tope
    if (result == true && parseInt(document.getElementById("txtEdad").value) < parseInt(document.getElementById("HiddenEdadTopeMin").value) || parseInt(document.getElementById("txtEdad").value) > parseInt(document.getElementById("HiddenEdadTopeMax").value)) {
        noCapturados = " EDAD DE ACEPTACI\u00d3N DE " + document.getElementById("HiddenEdadTopeMin").value + " A " + document.getElementById("HiddenEdadTopeMax").value;
        document.getElementById("txtEdad").value = "";
        focusCtrl("txtEdad");
        result = false;
    }
    if (result) {
        $("#imgDatAseg").attr("src", "../Common/Images/icn_check.png");
    }
    else {
        $("#imgDatAseg").attr("src", "../Common/Images/icn_cross.png");
        alert("DEBES CAPTURAR " + noCapturados);
    }
    return result;
}
function validaDatosAseguradoDS() {
    var result = true;
    if (document.getElementById("HiddenRamoRequest").value == "105") {
        var TblAsegurados = document.getElementById("Table6").rows;

        if (TblAsegurados[1].cells[1].childNodes[1].innerHTML == "") {
            result = false;
        }
        for (var i = 1; i < TblAsegurados.length; i++) {
            if ((document.getElementById("lblParentesco" + i).innerText == "TITULAR" || document.getElementById("lblParentesco" + i).innerText == "MANCOMUNADO") && document.getElementById("lblIngresoAnual" + i).innerText == "") {
                result = false;
            }
        }
    } else {
        if (document.getElementById("txtEdad").value == "") {
            result = false;
        }

        if (result == true && document.getElementById("txtIngresoM").value == "") {
            result = false;
        }
    }
    //Valida Edad Tope
    if (result == true && parseInt(document.getElementById("txtEdad").value) < parseInt(document.getElementById("HiddenEdadTopeMin").value) || parseInt(document.getElementById("txtEdad").value) > parseInt(document.getElementById("HiddenEdadTopeMax").value)) {
        result = false;
    }
    if (result) {
        $("#imgDatAseg").attr("src", "../Common/Images/icn_check.png");
    }
    else {
        $("#imgDatAseg").attr("src", "../Common/Images/icn_cross.png");
    }
}

function AllCross() {
    $("#imgDatAseg").attr("src", "../Common/Images/icn_cross.png");
    $("#imgPolizaContrato").attr("src", "../Common/Images/icn_cross.png");
    $("#imgPlSol").attr("src", "../Common/Images/icn_cross.png");
    $("#imgSolicitudPoliza").attr("src", "../Common/Images/icn_cross.png");
    $("#imgDatosContratante").attr("src", "../Common/Images/icn_cross.png");
    $("#imgDatosAsegurado").attr("src", "../Common/Images/icn_cross.png");
    $("#imgDesigBeneficiarios").attr("src", "../Common/Images/icn_cross.png");
    $("#imgCoberturasAContratar").attr("src", "../Common/Images/icn_cross.png");
    $("#imgDatosSeguro").attr("src", "../Common/Images/icn_cross.png");
    $("#imgCuestionario").attr("src", "../Common/Images/icn_cross.png");
}

function validaPolizaContrato() {
    var result = true;
    var noCapturados = "";
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        if (selIndiceCtrl("drpPolizaGrupo") < 1) {
            //alert("DEBES SELECCIONAR UNA P\u00d3LIZA GRUPO");
            noCapturados = "P\u00d3LIZA GRUPO.";
            focusCtrl("drpPolizaGrupo");
            result = false;
        }
        if (result == true && selIndiceCtrl("drpContrato") < 1) {
            //alert("DEBES SELECCIONAR UN CONTRATO");
            noCapturados = "CONTRATO."
            focusCtrl("drpContrato");
            result = false;
        }
    }
    if (result) {
        $("#imgPolizaContrato").attr("src", "../Common/Images/icn_check.png");
    }
    else {
        $("#imgPolizaContrato").attr("src", "../Common/Images/icn_cross.png");
        alert("DEBES SELECCIONAR " + noCapturados);
    }
    return result;
}
function validaPolizaContratoDS() {
    var result = true;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        if (selIndiceCtrl("drpPolizaGrupo") < 1) {
            result = false;
        }
        if (result == true && selIndiceCtrl("drpContrato") < 1) {
            result = false;
        }
    }
    if (result) {
        $("#imgPolizaContrato").attr("src", "../Common/Images/icn_check.png");
    }
    else {
        $("#imgPolizaContrato").attr("src", "../Common/Images/icn_cross.png");
    }
    return result;
}

function validaPlanSolicitado() {
    var result = true;
    var noCapturados = "";
    if (selIndiceCtrl("drpMoneda") < 1) {
        //alert("DEBES SELECCIONAR UNA MONEDA");
        noCapturados = "MONEDA.";
        focusCtrl("drpMoneda");
        result = false;
    }

    if (result == true && selIndiceCtrl("drpCrecimiento") < 1) {
        //alert("DEBES SELECCIONAR EL CRECIMIENTO");
        noCapturados = "CRECIMIENTO.";
        focusCtrl("drpCrecimiento");
        result = false;
    }

    if (result == true && document.getElementById("HiddenRamoRequest").value == "101") {
        if (selIndiceCtrl("drpDeducible") < 1) {
            //alert("DEBES SELECCIONAR EL DEDUCIBLE.");
            noCapturados = "DEDUCIBLE.";
            focusCtrl("drpDeducible");
            result = false;
        }
    }
    else {
        console.log(result);
        if (result == true && (document.getElementById("HiddenDeducible").value == "-1" || document.getElementById("HiddenDeducible").value == "")) {
            //alert("EXISTE UN PROBLEMA Y NO PUDO SER OBTENIDO EL DEDUCIBLE CON EL CRECIMIENTO SELECCIONADO");
            noCapturados = "EXISTE UN PROBLEMA Y NO PUDO SER OBTENIDO EL DEDUCIBLE CON EL CRECIMIENTO SELECCIONADO.";
            result = false;
        }
    }

    if (result == true && selIndiceCtrl("drpPlazo") < 1) {
        //alert("DEBES SELECCIONAR EL PLAZO");
        noCapturados = "PLAZO.";
        focusCtrl("drpPlazo");
        result = false;
    }

    if (result == true && selIndiceCtrl("drpPlazoPrima") < 1) {
        //alert("DEBES SELECCIONAR EL PLAZO PRIMA");
        noCapturados = "PLAZO PRIMA.";
        focusCtrl("drpPlazoPrima");
        result = false;
    }

    if (result) {
        $("#imgPlSol").attr("src", "../Common/Images/icn_check.png");
    }
    else {
        $("#imgPlSol").attr("src", "../Common/Images/icn_cross.png");
        alert("DEBES SELECCIONAR " + noCapturados);
    }
    return result;
}
function validaPlanSolicitadoDS() {
    var result = true;
    if (selIndiceCtrl("drpMoneda") < 1) {
        result = false;
    }

    if (result == true && selIndiceCtrl("drpCrecimiento") < 1) {
        result = false;
    }

    if (result == true && document.getElementById("HiddenRamoRequest").value == "101") {
        if (selIndiceCtrl("drpDeducible") < 1) {
            result = false;
        }
    }
    else {
        console.log(result);
        if (result == true && (document.getElementById("HiddenDeducible").value == "-1" || document.getElementById("HiddenDeducible").value == "")) {
            result = false;
        }
    }

    if (result == true && selIndiceCtrl("drpPlazo") < 1) {
        result = false;
    }

    if (result == true && selIndiceCtrl("drpPlazoPrima") < 1) {
        result = false;
    }

    if (result) {
        $("#imgPlSol").attr("src", "../Common/Images/icn_check.png");
    }
    else {
        $("#imgPlSol").attr("src", "../Common/Images/icn_cross.png");
    }
    return result;
}

function validaDatosDeLaSolicitud() {
    var result = true;
    var noCapturados = "";
    if (selIndiceCtrl("drpComision") < 1) {
        //alert("DEBES SELECCIONAR LA COMISI\u00d3N.");
        noCapturados = "DEBES SELECCIONAR LA COMISI\u00d3N.";
        focusCtrl("drpComision");
        result = false;
    }

    if (result == true && selIndiceCtrl("drpFormaPago") < 1) {
        //alert("DEBES SELECCIONAR UNA FORMA DE PAGO");
        noCapturados = "DEBES SELECCIONAR UNA FORMA DE PAGO.";
        focusCtrl("drpFormaPago");
        result = false;
    }

    if (result == true && selIndiceCtrl("drpTipoPago") < 1) {
        //alert("DEBES SELECCIONAR UN TIPO DE PAGO.");
        noCapturados = "DEBES SELECCIONAR UN TIPO DE PAGO.";
        focusCtrl("drpTipoPago");
        result = false;
    }
    var totPart = document.all("HidTotalPorcentaje").value;
    if (result == true && (parseFloat(totPart) < 100)) {
        //alert("EL PORCENTAJE DE AGENTES DEBE SUMAR 100%.");
        noCapturados = "EL PORCENTAJE DE AGENTES DEBE SUMAR 100%.";
        result = false;
    }

    if (result) {
        $("#imgSolicitudPoliza").attr("src", "../Common/Images/icn_check.png");
    }
    else {
        $("#imgSolicitudPoliza").attr("src", "../Common/Images/icn_cross.png");
        alert(noCapturados);
    }
    return result;
}
function validaDatosDeLaSolicitudDS() {
    var result = true;
    if (selIndiceCtrl("drpComision") < 1) {
        result = false;
    }

    if (result == true && selIndiceCtrl("drpFormaPago") < 1) {
        result = false;
    }

    if (result == true && selIndiceCtrl("drpTipoPago") < 1) {
        result = false;
    }
    var totPart = document.all("HidTotalPorcentaje").value;
    if (result == true && (parseFloat(totPart) < 100)) {
        result = false;
    }

    if (result) {
        $("#imgSolicitudPoliza").attr("src", "../Common/Images/icn_check.png");
    }
    else {
        $("#imgSolicitudPoliza").attr("src", "../Common/Images/icn_cross.png");
    }
    return result;
}

function validaCoberturas() {
    var result = true;
    var noCapturados = "";
    if (document.getElementById("DivCoberturas").innerHTML == "") {
        //alert("NO SE HAN DEFINIDO LAS COBERTURAS");
        noCapturados = "NO SE HAN DEFINIDO LAS COBERTURAS.";
        result = false;
    }

    if (result == true && ValidarUnaCobMarcada()) {
        //alert("DEBES SELECCIONAR POR LO MENOS UNA COBERTURA");
        noCapturados = "DEBES SELECCIONAR POR LO MENOS UNA COBERTURA.";
        result = false;
    }

    var ctrlTxtSuma = ValidarVaciosEnSumasConCobMarcadas();
    if (result == true && ctrlTxtSuma != "") {
        //alert("DEBE CAPTURAR UNA SUMA PARA LA COBERTURA MARCADA.");
        noCapturados = "DEBE CAPTURAR UNA SUMA PARA LA COBERTURA MARCADA.";
        focusCtrl(ctrlTxtSuma);
        result = false;
    }
    //if (oper == "P") {
    if (document.getElementById("HiddenRamoRequest").value == "105") {
        if (result == true && document.getElementById("lblPrimaneta").innerHTML == "") {
            //alert("DEBES DE OBTENER PRIMAS ANTES DE EMITIR");
            noCapturados = "DEBES DE OBTENER PRIMAS ANTES DE EMITIR.";
            result = false;
        }
    } else {
        if (result == true && document.getElementById("divPrimas").innerHTML == "") {
            //alert("DEBES DE OBTENER PRIMAS ANTES DE EMITIR");
            noCapturados = "DEBES DE OBTENER PRIMAS ANTES DE EMITIR.";
            result = false;
        }
    }
    //}
    if (result) {
        $("#imgCoberturasAContratar").attr("src", "../Common/Images/icn_check.png");
    }
    else {
        $("#imgCoberturasAContratar").attr("src", "../Common/Images/icn_cross.png");
        alert(noCapturados);
    }
    return result;

}
function validaCoberturasDS() {
    var result = true;
    if (document.getElementById("HiddenRamoRequest").value == "105") {
        if (document.getElementById("Table6").innerHTML == "") {
            result = false;
        }
    } else {
        if (document.getElementById("DivCoberturas").innerHTML == "") {
            result = false;
        }
    }


    if (result == true && ValidarUnaCobMarcada()) {
        result = false;
    }

    var ctrlTxtSuma = ValidarVaciosEnSumasConCobMarcadas();
    if (result == true && ctrlTxtSuma != "") {
        result = false;
    }
    //if (oper == "P") {
    if (document.getElementById("HiddenRamoRequest").value == "105") {
        if (result == true && document.getElementById("lblPrimaneta").innerHTML == "") {
            result = false;
        }
    } else {
        if (result == true && document.getElementById("divPrimas").innerHTML == "") {
            result = false;
        }
    }
    //}
    if (result) {
        $("#imgCoberturasAContratar").attr("src", "../Common/Images/icn_check.png");
    }
    else {
        $("#imgCoberturasAContratar").attr("src", "../Common/Images/icn_cross.png");
    }
    return result;

}

function validaContratante() {
    var result = true;
    if (valorCtrl("UscContCLM_lblRFC") == "") {
        result = false;
    }

    if (result) {
        $("#imgDatosContratante").attr("src", "../Common/Images/icn_check.png");
    }
    else {
        $("#imgDatosContratante").attr("src", "../Common/Images/icn_cross.png");
        //alert("DEBES INDICAR UN CONTRATANTE.");
    }
    return result;

}

function validaAsegurado() {
    var result = true;
    if (document.getElementById("HiddenRamoRequest").value == "105") {

    } else {
        if (valorCtrl("UscAsegCLM_lblRFC") == "") {
            result = false;
        }
    }
    if (result) {
        $("#imgDatosAsegurado").attr("src", "../Common/Images/icn_check.png");
    }
    else {
        $("#imgDatosAsegurado").attr("src", "../Common/Images/icn_cross.png");
        if (document.getElementById("HiddenRamoRequest").value == "105") {
            alert("DEBES INDICAR UN ASEGURADO.");
        }
    }
    return result;
}

function validaBeneficiarios() {
    var result = true;
    var noCapturados = "";
    // Valida captura de los beneficiarios
    var gridView = document.getElementById("grdBeneficiarios").firstChild;
    if (gridView == null) {
        //if (oper == "P") {
        //alert("DEBES INGRESAR POR LO MENOS UN BENEFICIARIO");
        noCapturados = "DEBES INGRESAR POR LO MENOS UN BENEFICIARIO.";
        result = false;
        //}
    }
    else {
        // Valida la suma de porcentaje de los beneficiarios
        var tblBenef = MetodosAjax.obtieneTablaBenef();
        if (result == true && (!validaPorcentaje(tblBenef, "beneficiarios")))
            result = false;
    }
    if (result) {
        $("#imgDesigBeneficiarios").attr("src", "../Common/Images/icn_check.png");
    }
    else {
        $("#imgDesigBeneficiarios").attr("src", "../Common/Images/icn_cross.png");
        if (noCapturados != "")
            alert(noCapturados);
    }
    return result;
}

function validaBeneficiariosDS() {
    var result = true;
    // Valida captura de los beneficiarios
    var gridView = document.getElementById("grdBeneficiarios").firstChild;
    if (gridView == null) {
        //if (oper == "P") {
        result = false;
        //}
    }
    else {
        // Valida la suma de porcentaje de los beneficiarios
        var tblBenef = MetodosAjax.obtieneTablaBenef();
        if (result == true && (!validaPorcentaje(tblBenef, "beneficiarios")))
            result = false;
    }
    if (result) {
        $("#imgDesigBeneficiarios").attr("src", "../Common/Images/icn_check.png");
    }
    else {
        $("#imgDesigBeneficiarios").attr("src", "../Common/Images/icn_cross.png");
    }
    return result;
}
function validaCoberturasAContratar2() {
    var result = true;
    if (result) {
        $("#imgCobAContratar").attr("src", "../Common/Images/icn_check.png");
    }
    else {
        $("#imgCobAContratar").attr("src", "../Common/Images/icn_cross.png");
    }
    return result;

}
function validaDatosDelSeguro() {
    var result = true;
    if (valorCtrl("lblPlan") == "") {
        //alert("Los datos del seguro se encuentran incompletos")
        result = false
    }
    if (result) {
        $("#imgDatosSeguro").attr("src", "../Common/Images/icn_check.png");
    }
    else {
        $("#imgDatosSeguro").attr("src", "../Common/Images/icn_cross.png");
    }
    return result;

}


//function validaCuestionario() {
//    var result = true;
//    var noCapturados = "";
//    if (document.getElementById("txtPeso").value == "") {
//        //alert("DEBES CAPTURAR EL PESO");
//        noCapturados = "DEBES CAPTURAR EL PESO.";
//        focusCtrl("txtPeso");
//        result = false;
//    }

//    if (result == true && document.getElementById("txtEstatura").value == "") {
//        //alert("DEBES CAPTURAR LA ESTATURA");
//        noCapturados = "DEBES CAPTURAR LA ESTATURA.";
//        focusCtrl("txtEstatura");
//        result = false;
//    }

//    if (result == true && document.getElementById("chkboxNo").checked == false && document.getElementById("chkboxSi").checked == false) {
//        //alert("DEBES CONTESTAR LA PREGUNTA DEL DEPORTE Y/O AFICI\u00d3N PELIGROSA");
//        noCapturados = "DEBES CONTESTAR LA PREGUNTA DEL DEPORTE Y/O AFICI\u00d3N PELIGROSA.";
//        result = false;
//    }

//    if (result == true && (!validaCuest())) {
//        //alert("DEBES CONTESTAR TODO EL CUESTIONARIO");
//        noCapturados = "DEBES CONTESTAR TODO EL CUESTIONARIO.";
//        result = false;
//    }

//    if (result == true && (!validaCuestResp())) {
//        //alert("DEBES CONTESTAR TODO EL CUESTIONARIO");
//        noCapturados = "DEBES CONTESTAR TODO EL CUESTIONARIO.";
//        result = false;
//    }
//    if (result == true && ValidaServFune()) {
//        result = false;
//    }

//    if (result) {
//        $("#imgCuestionario").attr("src", "../Common/Images/icn_check.png");
//    }
//    else {
//        $("#imgCuestionario").attr("src", "../Common/Images/icn_cross.png");
//        alert(noCapturados);
//    }
//    return result;
//}



function ValidarUnaCobMarcada() {
    var bdrValidacion = false;
    var ContadorChecados;
    if (document.getElementById("HiddenRamoRequest").value == "105") {
        ContadorChecados = Array();
        var tbAsegurados = document.getElementById("Table6");
        for (var i = 1; i <= tbAsegurados.rows.length; i++) {
            if (document.getElementById('lblCoberturas' + i).value) {
                ContadorChecados = document.getElementById('lblCoberturas' + i)?.value.split(',');
            } else {
                i = 8;
            }
        }
        if (ContadorChecados.length == 0) {
            bdrValidacion = true;
        }
    } else {
        ContadorChecados = 0;
        var tbCoberturas = document.getElementById("Coberturas");
        for (var i = 1; i <= tbCoberturas.rows.length; i++) {
            if (document.getElementById("chk" + i) != null) {
                if (document.getElementById("chk" + i).checked) {
                    ContadorChecados = ContadorChecados + 1;
                }
            }
        }
        if (ContadorChecados == 0) {
            bdrValidacion = true;
        }
    }
    return bdrValidacion;
}

function ValidarVaciosEnSumasConCobMarcadas() {
    var CtrltxtSuma = "";
    var tbAsegurados;
    if (document.getElementById("HiddenRamoRequest").value == "105") {
        tbAsegurados = document.getElementById("Table6");
        var cob = Array();
        for (var i = 1; i < tbAsegurados.rows.length; i++) {
            if (document.getElementById('lblCoberturas' + i)?.value) {
                cob = cob.push(document.getElementById('lblCoberturas' + i).value.split(','));
            } else {
                i = 8;
            }
        }
    } else {
        var tbCoberturas = document.getElementById("Coberturas");
        for (var i = 1; i <= tbCoberturas.rows.length; i++) {
            if (document.getElementById("chk" + i) != null) {
                if (document.getElementById("chk" + i).checked) {
                    var CodCob = document.getElementById("chk" + i).value;
                    if (document.getElementById("txtSuma" + CodCob).value == "") {
                        CtrltxtSuma = "txtSuma" + CodCob;
                        return CtrltxtSuma;
                    }
                }
            }
        }
    }

    return CtrltxtSuma;
}
function focusCk(nombreCtrl) {
    var control = document.getElementById(nombreCtrl);
    if (control != null) {
        try {
            var objControl = new clsControl(control);
            objControl.focus();
        }
        catch (ex) { }
    }
}