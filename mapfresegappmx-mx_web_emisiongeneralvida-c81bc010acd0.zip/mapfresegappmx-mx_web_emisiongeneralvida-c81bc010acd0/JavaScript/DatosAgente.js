
function wsObtieneAgente()
{	
	LimpiaGrid();
	DesactivaAdicional();
	LimpiaCamposAgentes();
	
	//Llena los datos del Agente	
	COD_AGE = window.document.getElementById("txtClaveAgen").value;
	MetodosAjax.ObtenerDatosAGE(COD_AGE, MuestraDatosAgente);
}

function MuestraDatosAgente(Valor)
{
   var auxArr = new Array();
   var Datos  = Valor.value;
   auxArr = Datos.split("|");
	
	Valida=auxArr[5];
	if(Valida == "OK")
	{
			/////////////////////////////////////////////////////////
			///// Asigna el Cuadro de Comisi�n del Agente ///////////
			///// "PRINCIPAL" para despu�s mandarlo al NODO de la ///
	        ///// tabla P2000030 ////////////////////////////////////
	    //MV Cuadros de Comisi�n INI
        if (auxArr[4] == "") {
            alert("El Agente no cuenta con Cuadro de Comisi\u00F3n para este producto.");
            document.getElementById("txtEdad").disabled = true;
            document.getElementById("HidCuadroCom").value = auxArr[4];
        }
        else {
            document.getElementById("txtEdad").disabled = false;
        }
	    document.getElementById("HidCuadroCom").value = auxArr[4];
//	    if (document.getElementById("HiddenRamoRequest").value != "111") {
//	        document.getElementById("HidCuadroCom").value = auxArr[4];
//	    }
	    //MV Cuadros de Comisi�n FIN
			//window.alert(document.getElementById("HidCuadroCom").value);
		
		    //document.getElementById("txtAgente").value=auxArr[0];

			//--------------------------------------------------------------
			//Llenando los datos de la secci�n Adicional de Agentes 
			//(otros agentes)
					
			/*document.form1.txtClaveA.value=document.getElementById("txtClaveAgen").value;
			document.form1.txtNombreAgente.value= auxArr[1];
			document.form1.txtPorcentaje.value= "";	*/
			//--------------------------------------------------------------

			//-------------- Llena los datos del 1er. Agente en el GRID ----------------
			document.getElementById("dtgReferencias_ctl02_txtgrdClave").value = document.getElementById("txtClaveAgen").value;
			//document.getElementById("dtgReferencias_ctl02_txtgrdAgente").value = auxArr[1];
			document.getElementById("dtgReferencias_ctl02_txtgrdNomAgente").value = auxArr[0];
			document.getElementById("dtgReferencias_ctl02_txtgrdPorcentaje").value = "100"

			document.getElementById("dtgReferencias_ctl02_hidgrdCveGestor").value = document.getElementById("hidCveGestor").value;	
			document.getElementById("txtTotPor").value = document.getElementById("txtPorcentaje").value; //parseFloat(document.getElementById("WUCInfAgente_txtPorcentaje").value) + parseFloat(document.getElementById("WUCInfAgente_txtTotPor").value);

			//En este paso se ingresa el 1er. Agente por lo tanto 
			//el valor del total del PORCENTAJE INGRESADO DEBE SER 
			//el 100%
			document.all("HidTotalPorcentaje").value = "100";

			//Desactivamos algunos campos
			document.getElementById("txtClaveA").disabled = true;		
			document.getElementById("txtPorcentaje").disabled = true;			
			document.getElementById("drpIntMasDeUnAgente").disabled=false;

			document.all("HidTotalAgentes").value = 1;						


	}
	else
	{		
		window.alert(Valida);
		document.getElementById("drpAgente").selectedIndex = 0;
		document.getElementById("drpAgente").focus();
	}		
}

function wsObtieneAgente2()
{
	Valor=document.getElementById("txtClaveA").value;
	if(Valor!="")
	{	
		COD_AGE = window.document.getElementById("txtClaveA").value;
		MetodosAjax.ObtenerDatosAGE(COD_AGE, MuestraDatosAgente2);
	}
}

function MuestraDatosAgente2(Valor)
{
	if(Valor.error == null)
	{
		if(Valor != null && Valor.value != null && Valor.value != "")
		{
			var auxArr = new Array();
			var Datos  = Valor.value;
			auxArr = Datos.split("|");

			Valida=auxArr[5];
			if(Valida == "OK")
			{
				LimpiaDatosAgente();
				document.getElementById("txtNombreAgente").disabled=false;
				document.getElementById("txtPorcentaje").disabled=false;
				
				document.getElementById("txtNombreAgente").value=auxArr[0];
				
				//TerminaProceso();
			}
			else
			{
				window.alert(Valida);
				LimpiaDatosAgente();
				document.getElementById("txtNombreAgente").disabled=true;
				document.getElementById("txtPorcentaje").disabled=true;
				document.getElementById("txtClaveA").focus();			
				document.getElementById("txtClaveA").value="";
				//TerminaProceso();
			}
		}
	}
	else alert(Valor.error.description);
}

function LimpiaDatosAgente()
{
	document.getElementById("txtNombreAgente").value="";
	document.getElementById("txtPorcentaje").value="";
}

function LimpiaGrid()
{
	for(i=2;i<=5;i++)
	{
	    var index = ((parseInt(i) < 10) ? "0"+i : i);
		if(document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave") != null)
		{
			document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave").value = "";
			//document.getElementById("dtgReferencias_ctl" + index + "_txtgrdAgente").value = "";
			document.getElementById("dtgReferencias_ctl" + index + "_txtgrdNomAgente").value = "";
			document.getElementById("dtgReferencias_ctl" + index + "_txtgrdPorcentaje").value = "";
		}
	}
}

function DesactivaAdicional()
{
	document.getElementById("drpIntMasDeUnAgente").selectedIndex=0;
	document.getElementById("txtClaveA").value="";
	document.getElementById("txtPorcentaje").value="";
	
	document.getElementById("txtNombreAgente").value="";
	
	document.getElementById("txtClaveA").disabled=true;
	document.getElementById("txtPorcentaje").disabled=true;
}

function LimpiaCamposAgentes()
{		
	/*document.getElementById("txtAgente").value="";
	document.getElementById("txtAgente").disabled=true;*/
}