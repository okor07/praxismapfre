﻿var modifica = "";

function Init() {
    AjustarFrame();
    limpiaCtrlsConMoneda();
    cambiaAgente(document.getElementById("drpAgente"));

    habilitarCtrl("btnEmite", false);

    habilitarCtrl("btnImprimeSolicitud", false);
    habilitarCtrl("btnImprimePoliza", false);
    ///habilitarCtrl("btnNuevaSolicitud",false);      

    habilitarCtrl("btnEnviar", false);

    Cargando(false);
}

function AjustarFrame() {
    var IFrameAAjustar = document.getElementById("HiddenIFrameAAjustar").value;
    var frmPrincipal = parent.document.getElementById(IFrameAAjustar);
    if (frmPrincipal != null)
        autofitIframe(IFrameAAjustar);
}

function Cargando(bdrCargando) {
    if (bdrCargando)
        document.getElementById('divCargando').style.display = 'block';
    else
        document.getElementById('divCargando').style.display = 'none';
}

function cambiaAgente(cmbAgt) {
    if (!(cmbAgt.selectedIndex == 0 && cmbAgt.options.length > 1)) {
        document.getElementById("txtClaveAgen").value = selIndex("drpAgente");
        document.getElementById("txtClaveAgen").disabled = true;
        wsObtieneAgente();
    }
}

function OcultarMostrarDivsConContrato() {
    if (document.getElementById("rbtnListPolizaContrato_0").checked) {
        document.getElementById("divPolizaGrupo").style.visibility = "hidden";
        document.getElementById("divContrato").style.visibility = "hidden";

        limpiaCtrlsConMoneda();
        //Con ésta función se llena la forma de pago y con el parámetro "true" le indicamos que 
        //una vez que haya llenado el drpFormaPago se llenará el drpMoneda.
        LlenarFormaPago('drpFormaPago', true);
    }
    else {
        document.getElementById("divPolizaGrupo").style.visibility = "visible";
        document.getElementById("divContrato").style.visibility = "visible";

        //Se limpian Drops desde Moneda.
        limpiaCombo('drpMoneda');
        limpiaCtrlsConMoneda();
        LlenarDropPolizaGrupo('drpPolizaGrupo');

    }
}


//AEP BWMEILL. Para ocultar pasarela de pago. Millón Vida Fase 2
function OcultarMostrarPasarelaPago() {
    if (document.getElementById("rbtMetodoPago_0").checked) {
        LlenarPlanyMoneda('drpMoneda');
        document.getElementById("btnPagar").style.visibility = "visible";
        document.getElementById("btnRferenciaBancaria").style.visibility = "hidden";
        document.getElementById("divPasarelaCobro").style.visibility = "visible";
        document.getElementById("datosPoliza").style.visibility = "visible";
        MetodosAjax.OcultaPasarela(1);
    }
    else {
        LlenarPlanyMoneda('drpMoneda');
        document.getElementById("btnRferenciaBancaria").style.visibility = "visible";
        document.getElementById("btnPagar").style.visibility = "hidden";
        document.getElementById("divPasarelaCobro").style.visibility = "hidden";
        document.getElementById("datosPoliza").style.visibility = "hidden";
        MetodosAjax.OcultaPasarela(2);




    }
}



function setPolizaConContrato(bdrHabilitar) {
    HabilitarPolConContrato(bdrHabilitar);

    document.getElementById("rbtnListPolizaContrato_0").checked = true;
    limpiaCombo("drpPolizaGrupo");
    limpiaCombo("drpContrato");

    OcultarMostrarDivsConContrato();
}

function HabilitarPolConContrato(bdrHabilitar) {
    document.getElementById("rbtnListPolizaContrato_0").disabled = bdrHabilitar;
    document.getElementById("rbtnListPolizaContrato_1").disabled = bdrHabilitar;
}

function LlenadoEspecialDeDrop(comboALlenar, NoRegistros, pBdrContinuar, pNombreFuncionDrop, pComboFillAuto) {
    if (NoRegistros == 1 && pBdrContinuar) {
        document.getElementById(comboALlenar).selectedIndex = 1;
        document.getElementById(comboALlenar).disabled = true;

        //Recursión.
        var FuncionDinamica = pNombreFuncionDrop + "('" + pComboFillAuto + "');";
        eval(FuncionDinamica);
    }
    else {
        return;
    }
}


function LimpiaCamposConEdad() {
    document.getElementById("rbtnListPolizaContrato_0").checked = true;
    limpiaCombo("drpPolizaGrupo");
    limpiaCombo("drpContrato");
    document.getElementById("divPolizaGrupo").style.visibility = "hidden";
    document.getElementById("divContrato").style.visibility = "hidden";

    if (selIndiceCtrl("drpAgente") < 1) {
        limpiaCtrlsConMoneda();
        //Con ésta función se llena la forma de pago y con el parámetro "true" le indicamos que 
        //una vez que haya llenado el drpFormaPago se llenará el drpMoneda.
        LlenarFormaPago('drpFormaPago', true);
    }
}

function obtenerCoberturas() {
    document.getElementById('DivCoberturas').innerHTML = "";

    var Ramo = document.getElementById("HiddenRamoRequest").value;
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }
    var Modalidad = document.getElementById("HiddenModalidad").value;
    var Tip_plan = document.getElementById("HiddenTipoPlanRequest").value;
    MetodosAjax.getCoberturasEdad(Ramo, contrato, Modalidad, document.getElementById("txtEdad").value, selIndex("drpMoneda"), Tip_plan, Coberturas_CallBack);

    MetodosAjax.getDctoSexoFuma(Ramo, Modalidad, 1000, getDctoSexoFuma_CallBack);

}

function Coberturas_CallBack(res) {
    if (res.error == null) {
        if (res != null && res.value != null) {
            document.getElementById('DivCoberturas').innerHTML = res.value;
            if (document.getElementById("HiddenRamoRequest").value == "105") {
                if (modifica != "") {
                    var indice = document.all('hdnFilaSelec').value;
                    obtenerCobRiesgo(i, indice)
                }
            }

            AjustarFrame();
        }
    }
}

function ObtieneSumaMV() {
    Cargando(true);

    var CadCob = "1000";	//Recupera cad. de cob. seleccionadas 	
    //CadCob += window.frames["ifCoberturas"].document.forms["frmCoberturas"].elements['repCobGrales_ctl_ChkCob'].value;	
    var cod_cia = 1;
    var cod_ramo = document.getElementById("HiddenRamoRequest").value;
    //var duracion_hasta = selIndex("drpPlazo");
    var duracion_hasta = document.getElementById("hdnPlazo").value;
    var cod_modalidad = document.getElementById("HiddenModalidad").value;
    var cod_mon = document.all("drpMoneda").value;
    var cob = CadCob;
    var fecha_emision = document.getElementById("hidFechaSistema").value;
    var fecha_fin = document.getElementById("hdnFecVcto").value;
    var prima_a_calcular = document.getElementById("txtPrima1000").value;
    var edad = document.getElementById("txtEdad").value;
    var sexo = selIndex("drpSexo");
    MetodosAjax.fnCotizaSumasMV(cod_cia, cod_ramo, duracion_hasta, cod_modalidad, cod_mon, CadCob,
        fecha_emision, fecha_fin, prima_a_calcular, edad, sexo, fnCotizaSumas_CallBack)

    Cargando(false);

}


function fnCotizaSumas_CallBack(res) {
    if (res.error == null) {
        if (res != null && res.value != "") {
            var cadSumas = res.value;
            if (ValidaSumaAseg(cadSumas)) {
                document.getElementById("txtSuma1000").value = cadSumas;
                document.getElementById("btnObtenerPrimas").disabled = false;
            }
        } else {
            alert("No recuperaron las Sumas Aseguradas");
        }
    }
    else {
        alert(res.error.description);
    }
}


function ValidaSumaAseg(monto) {
    var SumaAsegBasica = monto;
    var SumaPDesde = parseInt(document.getElementById("HdnSumaPMinMV").value);
    var SumaDDesde = parseInt(document.getElementById("HdnSumaDMinMV").value);
    var SumaHasta = parseInt(document.getElementById("hdnSumaMaxMV").value);
    //AEP BWMEILL. Cambio en límites de sumas aseguradas para millón vida fase 2
    var cod_modalidadMV = document.getElementById("HiddenModalidad").value;
    if (cod_modalidadMV == "11102" && selIndex("drpMoneda") == "2") {
        SumaDDesde = 500;
        SumaHasta = 900000000;
    }
    if (cod_modalidadMV == "11102" && selIndex("drpMoneda") == "6") {
        SumaDDesde = 1800;
        SumaHasta = 900000000;
    }
    if (cod_modalidadMV == "11101" && selIndex("drpMoneda") == "2") {
        SumaDDesde = 1000;
        SumaHasta = 900000000;
    }
    if (cod_modalidadMV == "11101" && selIndex("drpMoneda") == "6") {
        SumaDDesde = 4000;
        SumaHasta = 900000000;
    }

    if (selIndex("drpMoneda") == "1") {
        if (!(SumaAsegBasica >= SumaPDesde && SumaAsegBasica <= SumaHasta)) {
            alert("Rango fuera del permitido, la suma debe estar dentro de: " + SumaPDesde + " hasta " + SumaHasta);
            return false;
        }
    }
    else {
        if (!(SumaAsegBasica >= SumaDDesde && SumaAsegBasica <= SumaHasta)) {
            alert("Rango fuera del permitido, la suma debe estar dentro de: " + SumaDDesde + " hasta " + SumaHasta);
            return false;
        }
    }

    return true;
}


function ValidaFechaVen(Plazo) {
    var f = new Date();
    var anio = parseInt(f.getFullYear()) + parseInt(Plazo);
    var fecplazo = f.getDate() + "/" + (f.getMonth() + 1) + "/" + anio;
    document.getElementById("hdnFecVcto").value = fecplazo;
}


function getDctoSexoFuma_CallBack(res) {
    if (res.error == null) {
        if (res != null && res.value != null && res.value.Rows.length != 0) {
            document.getElementById("HiddenDctoSex").value = res.value.Rows[0].NUM_DIF_MUJER;
            document.getElementById("HiddenDctoFuma").value = res.value.Rows[0].NUM_DIF_FUMADOR;
        }
    }
    else alert(res.error);
}

function validaCopia() {
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var agente = selValorCtrl("drpAgente");
    var cod_docum = document.getElementById(usrCtrl + 'hdnCLM').value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var edad = document.getElementById("txtEdad").value;
    var contrato = "";
    var polizaGpo = "";
    contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
        polizaGpo = textoCtrl("drpPolizaGrupo");
    }

    var validaCLM = CLM.validaCopia(parseInt(ramo), agente, "2", cod_docum, "", polizaGpo, contrato, modalidad, edad, "", "", "");
    if (validaCLM.error != null) {
        alert(validaCLM.error.description);
        return false;
    }
    return true;
}

function actSumaAseg(codCob, ctrlTxtSuma) {

    LimpiarPrimas();

    if (codCob != 1000) {
        if (document.getElementById("txtSuma1000").value != "") {
            var ramo = document.getElementById("HiddenRamoRequest").value;
            var modalidad = document.getElementById("HiddenModalidad").value;
            var suma_basica = document.getElementById("txtSuma1000").value;
            var suma = document.getElementById(ctrlTxtSuma).value;
            if (suma != "") {
                var Validacion = MetodosAjax.validaCoberturas(codCob, ramo, modalidad, selIndex("drpMoneda"), suma_basica, suma);
                if (Validacion.error == null) {
                    if (Validacion != null && Validacion.value != null) {
                        var Marca = Validacion.value.p_mca_valido;
                        var MensajeError = Validacion.value.p_error;
                        var Suma = Validacion.value.p_suma_aseg;
                        if (Marca != 'S') {
                            alert(MensajeError);
                            document.getElementById(ctrlTxtSuma).value = "";
                        }
                        else
                            document.getElementById(ctrlTxtSuma).value = Suma;
                    }
                }
            }
        }
        else {
            alert("Primero debe capturar la suma Basica");
            document.getElementById(ctrlTxtSuma).value = "";
        }
    }
    else {

        if (document.getElementById("HiddenRamoRequest").value == "111") {
            var modalidad = document.getElementById("HiddenModalidad").value;
            var prima_basica = document.getElementById("txtSuma1000");
        }

        if (document.getElementById("txtSuma1000").value != "") {
            //Se valida Suma asegurada Básica.
            var ramo = document.getElementById("HiddenRamoRequest").value;
            var modalidad = document.getElementById("HiddenModalidad").value;
            var suma_basica = document.getElementById("txtSuma1000").value;
            var suma = document.getElementById(ctrlTxtSuma).value;
            if (suma != "") {
                var Validacion = MetodosAjax.validaCoberturas(codCob, ramo, modalidad, selIndex("drpMoneda"), suma_basica, suma);
                if (Validacion.error == null) {
                    if (Validacion != null && Validacion.value != null) {
                        var Marca = Validacion.value.p_mca_valido;
                        var MensajeError = Validacion.value.p_error;
                        var Suma = Validacion.value.p_suma_aseg;
                        if (Marca != 'S') {
                            alert(MensajeError);
                            document.getElementById(ctrlTxtSuma).value = "";
                        }
                        else {

                            // INICIO BWM-LDN
                            // A17547
                            // Primero valida la cobertura con MetodosAjax.validaCoberturas,
                            // despues se validan los importes maximos y minimos.

                            //validacion no necesaria para el ramo 111 (Millon Vida)
                            var SumaAsegBasica = parseInt(document.getElementById(ctrlTxtSuma).value);
                            var SumaDesde = parseInt(document.getElementById("hdnSumaAsegDesde" + codCob).value);
                            var SumaHasta = parseInt(document.getElementById("hdnSumaAsegHasta" + codCob).value);

                            if (!(SumaAsegBasica >= SumaDesde && SumaAsegBasica <= SumaHasta)) {
                                alert("Rango fuera del permitido, la suma debe estar dentro de: " + SumaDesde + " hasta " + SumaHasta);
                                document.getElementById(ctrlTxtSuma).value = "";
                            }

                            else {
                                document.getElementById(ctrlTxtSuma).value = Suma;
                                ReObtenerConBasica();
                            }
                            // FINAL BWM-LDN
                        }
                    }
                }
            }
        }

        else {
            LimpCobConBasica();
        }

    }

}

function actMarcaCobertura(codCob, ctrlCbxCob, ctrlTxtSuma) {
    LimpiarPrimas();
    var CodigoRamo = document.getElementById("HiddenRamoRequest").value;
    var Modalidad = document.getElementById("HiddenModalidad").value;
    var Moneda = selIndex("drpMoneda");

    if ((document.getElementById("txtSuma1000") && document.getElementById("txtSuma1000").value != "") || (CodigoRamo == "100" && Modalidad == "10007" && codCob == "1019")) {

        if (document.getElementById("hdnMarcaAcc" + codCob).value == "S") {
            DesmAccidentes(codCob);
        }

        if (document.getElementById("hdnSumaAsegDesde" + codCob).value == "0" && document.getElementById("hdnSumaAsegHasta" + codCob).value == "0") {
            if (document.getElementById(ctrlCbxCob).checked) {
                document.getElementById(ctrlTxtSuma).disabled = true;
                document.getElementById(ctrlTxtSuma).value = "AMPARADA";
            }
            else {
                document.getElementById(ctrlTxtSuma).disabled = true;
                document.getElementById(ctrlTxtSuma).value = "";
            }
        }
        else {
            if (document.getElementById(ctrlCbxCob).checked) {
                document.getElementById(ctrlTxtSuma).disabled = false;
                var SumaAseg = MetodosAjax.SumaAseguradaBasica(CodigoRamo, codCob, Modalidad, Moneda, document.getElementById("txtSuma1000").value);

                if (SumaAseg.error == null) {
                    if (SumaAseg != null && SumaAseg.value != null) {

                        // <---- apl 05122014 Se limpian la suma asegurada para los controles tipos RadioButton---->
                        var rds = document.getElementsByName('rbCobertura');
                        for (var s = 0; s < rds.length; s++) {
                            if (!rds[s].checked) {
                                document.getElementById("txtSuma" + rds[s].value).value = "";
                            }
                        }

                        var Suma = SumaAseg.value.p_suma_aseg;
                        var McaModifica = SumaAseg.value.p_mca_modifica;
                        document.getElementById(ctrlTxtSuma).value = Suma;
                        if (McaModifica != "S") {
                            document.getElementById(ctrlTxtSuma).disabled = true;
                        }

                    }
                }
            }
            else {
                document.getElementById(ctrlTxtSuma).disabled = true;
                document.getElementById(ctrlTxtSuma).value = "";
            }
        }
    }
    else {
        alert("Primero debe capturar la suma Basica");
        document.getElementById(ctrlCbxCob).checked = false;
    }
}

function DesmAccidentes(codCob) {
    var tbCoberturas = document.getElementById("Coberturas");
    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            if (document.getElementById("chk" + i).checked) {
                var cod_cob = document.getElementById("chk" + i).value;
                if (codCob != cod_cob) {
                    if (document.getElementById("hdnMarcaAcc" + cod_cob).value == "S") {
                        document.getElementById("chk" + i).checked = false;
                        document.getElementById("txtSuma" + cod_cob).disabled = true;
                        document.getElementById("txtSuma" + cod_cob).value = "";
                    }
                }
            }
        }
    }
}

//Calcula la fecha de Nacimiento en base a la edad
function calcula_fechaNac(edad) {
    if (document.all("txtEdad").value.length != 0) {
        //calculo la fecha de hoy 
        hoy = new Date()
        //resto los años de las dos fechas 
        anio = hoy.getFullYear()
        anioAseg = parseInt(anio) - parseInt(edad)
        fecha = "01/01/" + anioAseg
        document.all("hidFechaNac").value = fecha;
    } else {
        document.all("hidFechaNac").value = "";
    }
}

function DatosSeguroCLM(ctrlChk) {
    if (document.getElementById(ctrlChk.id).checked) {
        LlenarDatosDelSeguro();
        validarBotonEmite();
    }
    else {
        LimpiarDatosDelSeguro(true);
        habilitarCtrl("btnEmite", false);
    }

    valOcupacion();
}

function DatosSeguroCLMCarga(ctrlChk) {
    if (document.getElementById(ctrlChk).checked) {
        LlenarDatosDelSeguro();
        validarBotonEmite();
    }
    else {
        LimpiarDatosDelSeguro(true);
        habilitarCtrl("btnEmite", false);
    }

    valOcupacion();
}

function valOcupacion() {
    document.getElementById("drpOcupacion").selectedIndex = 0;
    document.getElementById("drpOcupacion").disabled = false;

    var ocu = document.getElementById("UscAsegCLM_hdnProfesion").value;
    if (ocu != "") {
        if (ocu == "-1")
            document.getElementById("drpOcupacion").selectedIndex = 0;
        else {
            selEnDrop("drpOcupacion", ocu);
            document.getElementById("drpOcupacion").disabled = true;
        }
    }
}

function selEnDrop(Drop, valor) {
    var combo = document.getElementById(Drop);
    var cantidad = combo.length;
    for (i = 0; i < cantidad; i++) {
        if (combo[i].value == valor) {
            combo[i].selected = true;
        }
    }
}

function validarBotonEmite() {
    if (document.getElementById("divPrimas").innerHTML != "")
        habilitarCtrl("btnEmite", true);
}

function LlenarDatosDelSeguro() {
    document.getElementById("lblPlan").innerText = document.getElementById("HiddenRamoDescripcion").value + " MONEDA " + textoCtrl("drpMoneda");
    document.getElementById("lblFormaPago").innerText = textoCtrl("drpFormaPago");
    document.getElementById("lblTipoPago").innerText = textoCtrl("drpTipoPago");
    document.getElementById("lblAsegurado").innerText = valorCtrl("UscAsegCLM_lblNombre") + " " + valorCtrl("UscAsegCLM_lblApellidoPaterno") + " " + valorCtrl("UscAsegCLM_lblApellidoMaterno");
    document.getElementById("lblFechaNac").innerText = valorCtrl("UscAsegCLM_lblNacimiento");
    document.getElementById("lblDomicilio").innerText = valorCtrl("UscAsegCLM_lblDireccion") + " " + valorCtrl("UscAsegCLM_lblColonia") + " " + valorCtrl("UscAsegCLM_lblEdo") + " " + valorCtrl("UscAsegCLM_lblCP");
    document.getElementById("lblPrimaTotal").innerText = formatCurrency(document.getElementById('HiddenPrimaTotal').value);
}

function LimpiarDatosDelSeguro(bdrDatosCLM) {
    document.getElementById("lblPlan").innerText = "";
    document.getElementById("lblFormaPago").innerText = "";
    document.getElementById("lblTipoPago").innerText = "";
    document.getElementById("lblPrimaTotal").innerText = "";

    if (bdrDatosCLM) {
        document.getElementById("lblAsegurado").innerText = "";
        document.getElementById("lblFechaNac").innerText = "";
        document.getElementById("lblDomicilio").innerText = "";
    }
}

//Funciones de Impresión Nuevo Modelo.
function ImpSolicitud() {
    var strNombre = prompt('Ingresa el nombre del Cliente', '');
    if (strNombre == null) return;

    var Ramo = document.getElementById("HiddenRamoRequest").value;

    var vParametros = "Cliente=" + strNombre
        + "&Ramo=" + Ramo;

    window.open("../Impresion/TWImpSolicitud.aspx?" + vParametros, "VistaPrevia", "toolbar=false,scrollbars=1,resizable=0,width=800,height=680,left=0,top=0");

}

function ImpPoliza() {
    var strNombre = prompt('Ingresa el nombre del Cliente', '');
    if (strNombre == null) return;

    var Ramo = document.getElementById("HiddenRamoRequest").value;

    var vParametros = "Cliente=" + strNombre
        + "&Ramo=" + Ramo;

    window.open("../Impresion/TWImpPoliza.aspx?" + vParametros, "VistaPrevia", "toolbar=false,scrollbars=1,resizable=0,width=800,height=680,left=0,top=0");

}

//Funciones de Impresión Viejo Modelo
//Contenido.aspx?img=bannervida&bnn=vida&CodMenu=20305&cod_App=16&RutaApp=/EmisionGeneralVida/appAcceso.aspx?app=EmisionGeneral/EmisionGeneralVida.aspx?codRamo=100&codTipoPlan=6
var wnventanasol;
function MM_ImprimirSolicitud() {
    var lblpoliza = document.getElementById("lblNoPoliza").innerHTML;
    document.getElementById("btnImprimePoliza").disabled = false;
    //Datos de la Impresión.
    var poliza = document.getElementById("lblNoPoliza").innerText;
    var sector = 1;
    var usuario = document.getElementById("HiddenUsuario").value;
    var agente = document.getElementById("HiddenAgente").value;
    var boton = 'N';

    var relacion = "";

    var nacionalidad = manejoLabel("UscAsegCLM_lblNacionalidad");
    var Fuma = selValorCtrl("drpFuma");
    var Ocupacion = selValorCtrl("drpOcupacion");
    var RamoDesc = document.getElementById("HiddenRamoDescripcion").value;
    var Plazo = document.getElementById("hdnPlazo").value;
    var Peso = document.getElementById("txtPeso").value;
    var Estatura = document.getElementById("txtEstatura").value;
    var Edad = document.getElementById("txtEdad").value;

    var RelSol = Array();
    RelSol[0] = nacionalidad + "|" +
        Fuma + "|" +
        Ocupacion + "|" +
        RamoDesc + " " + Plazo + "|" +
        Peso + "|" +
        Estatura + "|" +
        Edad + "|";

    relacion = RelSol[0];

    var correo = manejoLabel("UscAsegCLM_lblCorreo");

    if (lblpoliza.substring(0, 2) != 10) {
        //Validamos si es una impresión de solicitud de Emisión General Vida apl 08.12.2014
        // Agregamos parametro EGVImpSol = Emisión General Vida Impresión Solicitud
        wnventanasol = window.open('/impresionSeGA/TWImpSolicitudMarco.aspx?noPoliza=' + poliza + '&sector=' + sector + '&usuario=' + usuario + '&agente=' + agente + "&eMail=" + correo + "&btnPoliza=" + boton + "&RelSol=" + relacion + "&EGVImpSol=1", 'SOLICITUD', 'toolbar=false,scrollbars=1,resizable=0,width=800,height=680,left=0,top=0');
    }
    else {
        wnventanasol = window.open('/impresionSeGA/TWImpSolicitudMarco.aspx?noPoliza=' + poliza + '&sector=' + sector + '&usuario=' + usuario + '&agente=' + agente + "&eMail=" + correo + "&btnPoliza=" + boton + "&RelSol=" + relacion, 'SOLICITUD', 'toolbar=false,scrollbars=1,resizable=0,width=800,height=680,left=0,top=0');
    }
}

function MM_ImprimirPoliza() {
    document.getElementById("btnNuevaSolicitud").disabled = false;

    var poliza = document.getElementById("lblNoPoliza").innerText;
    var sector = 1;
    var usuario = document.getElementById("HiddenUsuario").value;
    var agente = document.getElementById("HiddenAgente").value;
    var correo = manejoLabel("UscAsegCLM_lblCorreo");

    if (!confirm(unescape("Si desea obtener la p%f3liza a traves de la oficina en donde usted imprime sus p%f3lizas y endosos de vida presione ACEPTAR, \nde lo contrario presione CANCELAR para impirmirla en este momento")))
        window.open('/impresionSeGA/TWImpPolizaMarco.aspx?noPoliza=' + poliza + '&sector=' + sector + '&simpol=n&usuario=' + usuario + '&agente=' + agente + '&eMail=' + correo, 'POLIZA', 'toolbar=false,scrollbars=1,resizable=0,width=800,height=680,left=30,top=30');

}

function getEmailAgente() {
    var EmailAgente = MetodosAjax.getCorreoAgente(selValorCtrl("drpAgente"));
    document.getElementById("HiddenEmailAgente").value = EmailAgente;
}

// Valida la seleccion de un checkbox de la tabla de preguntas
function selCheckBox(i, sel) {
    if (sel == "Si") {
        document.getElementById("chkNo" + i).checked = false;
    }
    else if (sel == "No")
        document.getElementById("chkSi" + i).checked = false;
}

// Valida el cuestionario
function validaCuest() {
    var numPreg = document.getElementById("gvCuestionario").rows.length - 1;
    for (var preg = 1; preg <= numPreg; preg++) {
        var chkSi;
        var chkNo;
        try {
            if (document.getElementById("chkSi" + preg) != null)
                chkSi = document.getElementById("chkSi" + preg).checked;
            if (document.getElementById("chkNo" + preg) != null)
                chkNo = document.getElementById("chkNo" + preg).checked;
        }
        catch (e) { alert(e); }

        if (chkSi == false && chkNo == false) {
            document.getElementById("chkNo" + preg).focus();
            return false;
        }
    }
    return true;
}

function ValidaServFune() {
    var MarcaSF = false;
    var tbCoberturas = document.getElementById("Coberturas");
    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            if (document.getElementById("chk" + i).checked) {
                if (document.getElementById("chk" + i).value == "1019")
                    MarcaSF = true;
            }
        }
    }

    if (MarcaSF) {
        var valorCLM = valorCtrl("UscAsegCLM_hdnCLM");
        var validaCLM = MetodosAjax.validaCLMServFun(valorCLM);
        if (validaCLM.error == null) {
            if (validaCLM != null && validaCLM.value != null) {
                var MarcaVal = validaCLM.value.p_mca_valido;
                var Mensaje = validaCLM.value.p_valida;
                if (MarcaVal == 'S')
                    return false; //No cuenta con servicios funerarios debe dejar pasar.
                else {
                    alert(Mensaje);
                    DesmarcarServFun();
                    return true; //Ya cuenta con servicios funerarios No debe dejar Pasar
                }
            }
        }
        else {
            alert(validaCLM.error.description);
            return true; //No debe dejar pasar.
        }
    }
    else
        return false; //No aparece Servicios Funerarios. Debe dejar Pasar .
}

function DesmarcarServFun() {

    document.getElementById('divPrimas').innerHTML = "";

    var tbCoberturas = document.getElementById("Coberturas");
    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            var cod_cob = document.getElementById("chk" + i).value;
            if (cod_cob == "1019") {
                if (document.getElementById("chk" + i).checked) {
                    document.getElementById("chk" + i).checked = false;
                    document.getElementById("txtSuma" + cod_cob).disabled = true;
                    document.getElementById("txtSuma" + cod_cob).value = "";
                    document.getElementById("txtPrima" + cod_cob).value = "";
                }
            }
        }
    }
}

function NuevaEmision() {
    window.location.href = "../appAcceso.aspx?app=EmisionGeneral/EmisionGeneralVida.aspx?codRamo=" + document.getElementById("HiddenRamoRequest").value;
    //focusCtrl("drpAgente");
}

function EsperaImpPoliza() {
    Cargando(true);
    setTimeout("EjecutarImpPoliza();", document.getElementById("HiddenTiempoRetardo").value)
}

function EjecutarImpPoliza() {
    Cargando(false);
    var modalidad = document.getElementById("HiddenModalidad").value;
    if (modalidad != 11103) {
        MM_ImprimirPoliza();
    }
    else {
        MM_ImprimeContrato();
    }

}

function LimpiarPrimas() {
    document.getElementById('divPrimas').innerHTML = "";
}

function LimpCobConBasica() {
    var tbCoberturas = document.getElementById("Coberturas");
    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            if (document.getElementById("chk" + i).checked) {
                if (document.getElementById("chk" + i).value != "1000") {
                    var cod_cob = document.getElementById("chk" + i).value;
                    if (document.getElementById("chk" + i).disabled != true) {
                        document.getElementById("chk" + i).checked = false;
                        document.getElementById("txtSuma" + cod_cob).disabled = true;
                        document.getElementById("txtSuma" + cod_cob).value = "";
                    }
                    else
                        document.getElementById("txtSuma" + cod_cob).value = "";
                }
            }
        }
    }
}

function ReObtenerConBasica() {
    Cargando(true);
    var tbCoberturas = document.getElementById("Coberturas");
    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            if (document.getElementById("chk" + i).checked) {
                if (document.getElementById("chk" + i).value != "1000") {
                    var cod_cob = document.getElementById("chk" + i).value;
                    if (document.getElementById("txtSuma1000").value != "") {
                        var ramo = document.getElementById("HiddenRamoRequest").value;
                        var modalidad = document.getElementById("HiddenModalidad").value;
                        var suma_basica = document.getElementById("txtSuma1000").value;
                        var sumaCob = document.getElementById("txtSuma" + cod_cob).value;
                        if (sumaCob != "") {
                            if (isNaN(sumaCob))
                                document.getElementById("txtSuma" + cod_cob).value = "AMPARADA";
                            else {
                                var Validacion = MetodosAjax.validaCoberturas(cod_cob, ramo, modalidad, selIndex("drpMoneda"), suma_basica, sumaCob);
                                if (Validacion.error == null) {
                                    if (Validacion != null && Validacion.value != null) {
                                        var Marca = Validacion.value.p_mca_valido;
                                        var MensajeError = Validacion.value.p_error;
                                        var Suma = Validacion.value.p_suma_aseg;
                                        if (Marca != 'S') {
                                            document.getElementById("txtSuma" + cod_cob).value = "";
                                        }
                                        else
                                            document.getElementById("txtSuma" + cod_cob).value = Suma;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    Cargando(false);
}

function ValidaNumeros() {
    numero = document.getElementById("txtNumTarjeta").value;
    if (!/^([0-9])*$/.test(numero)) {
        alert("El valor " + numero + " no es un número");
    }
}

function ValidaTarjeta() {
    var numTarjeta = document.getElementById("txtNumTarjeta").value;
    var codBanco = selIndex("ddlBanco");
    var result = MetodosAjax.ValidaTarjeta(numTarjeta, codBanco);
    if (result.value != "") {
        alert(result.value);
        document.getElementById("txtNumTarjeta").value = "";
    }
}


function PlazoEdad(Edad) {
    var e = Edad;
}


function LlenaSobrevivencia(control) {
    if (control == "12") {
        document.getElementById("txtNombreBenef").value = document.getElementById("UscAsegCLM_lblNombre").textContent;
        document.getElementById("txtPaternoBenef").value = document.getElementById("UscAsegCLM_lblApellidoPaterno").textContent;
        document.getElementById("txtMaternoBenef").value = document.getElementById("UscAsegCLM_lblApellidoMaterno").textContent;
        document.getElementById("txtPctBenef").value = "100";
        document.getElementById("txtFecNac").value = document.getElementById("UscAsegCLM_lblNacimiento").textContent;
        document.getElementById("txtDomicilio").value = document.getElementById("UscAsegCLM_lblDireccion").textContent;

        document.getElementById("txtNombreBenef").disabled = true;
        document.getElementById("txtPaternoBenef").disabled = true;
        document.getElementById("txtMaternoBenef").disabled = true;
        document.getElementById("txtPctBenef").disabled = true;
        document.getElementById("txtFecNac").disabled = true;
        document.getElementById("txtDomicilio").disabled = true;
    }
    else {
        document.getElementById("txtNombreBenef").value = "";
        document.getElementById("txtPaternoBenef").value = "";
        document.getElementById("txtMaternoBenef").value = "";
        document.getElementById("txtPctBenef").value = "";
        document.getElementById("txtFecNac").value = "";
        document.getElementById("txtDomicilio").value = "";

        document.getElementById("txtNombreBenef").disabled = false;
        document.getElementById("txtPaternoBenef").disabled = false;
        document.getElementById("txtMaternoBenef").disabled = false;
        document.getElementById("txtPctBenef").disabled = false;
        document.getElementById("txtFecNac").disabled = false;
        document.getElementById("txtDomicilio").disabled = false;
    }
}

function FecVenJub() {
    var e = document.all("txtEdad").value;
    var p = document.all("drpPlazo").value;
    var r = (p - e);
    document.getElementById("hdnPlazo").value = r.toString();

    var f = new Date();
    var anio = parseInt(f.getFullYear()) + parseInt(r);
    var fecplazo = f.getDate() + "/" + (f.getMonth() + 1) + "/" + anio;
    document.getElementById("hdnFecVcto").value = fecplazo;
}

//MU-080082 Valida que la SA de la cobertura temporal no se pase del maximo establecido INI
function validaSAtemporal() {
    if (document.getElementById("chk2").checked == false) {
        //Limpia campos
        document.getElementById("txtSuma1000").value = "";
        document.getElementById("txtPrima1000").value = "";
        document.getElementById("txtSuma1500").value = "";
        document.getElementById("txtPrima1500").value = "";
    }

    var SumaSA = document.getElementById("txtSuma1000").value;
    var maxSA = document.getElementById("hdntopeSA").value;

    if (document.getElementById("chk2").checked == true) {
        if (selIndex("drpMoneda") == 2) {
            var auxUSD = ""
            var auxUSD1 = ""
            var resUSD = ""
            var FactorUSD = (document.getElementById("hdnUSD").value) * (SumaSA);
            if (FactorUSD != null) {
                auxUSD = FactorUSD.toString().split('.')[0];
                auxUSD1 = FactorUSD.toString().split('.')[1];
                resUSD = auxUSD + "." + auxUSD1.substring(0, 2);
                if (parseFloat(resUSD) > parseFloat(maxSA)) {
                    alert("La Suma Asegurada excede el l\u00EDmite establecido");
                    topaSAalcanza(maxSA);
                    return false;
                }
            }
        }
        if (selIndex("drpMoneda") == 6) {
            var auxUDIS = ""
            var auxUDIS1 = ""
            var resUDIS = ""
            var FactorUDIS = (document.getElementById("hdnUDIS").value) * (SumaSA);
            auxUDIS = FactorUDIS.toString().split('.')[0];
            auxUDIS1 = FactorUDIS.toString().split('.')[1];
            resUDIS = auxUDIS + "." + auxUDIS1.substring(0, 2);
            if (parseFloat(resUDIS) > parseFloat(maxSA)) {
                alert("La Suma Asegurada excede el l\u00EDmite establecido");
                topaSAalcanza(maxSA);
                return false;
            }
        }
    }
    document.getElementById("txtSuma1500").disabled = true;
    document.getElementById("txtPrima1500").disabled = true;
    return true;
}
//MU-080082 Valida que la SA de la cobertura temporal no se pase del maximo establecido FIN
//MU-080082 Se topa la SA de la cobertura temporal al maximo establecido INI
function topaSAalcanza(maxSA) {
    if (selIndex("drpMoneda") == 2) {
        var resUSD = ""
        var auxUSD = ""
        var auxUSD1 = ""
        var res = ""
        var FactorUSD = (maxSA) / (document.getElementById("hdnUSD").value);
        auxUSD = FactorUSD.toString().split('.')[0];
        auxUSD1 = FactorUSD.toString().split('.')[1];
        resUSD = auxUSD + "." + auxUSD1.substring(0, 2);
        document.getElementById("txtSuma1500").value = resUSD;
        document.getElementById("txtSuma1500").disabled = true;
        document.getElementById("txtPrima1500").disabled = true;
    }
    else if (selIndex("drpMoneda") == 6) {
        var resUDIS = ""
        var auxUDIS = ""
        var auxUDIS1 = ""
        var FactorUDIS = (maxSA) / (document.getElementById("hdnUDIS").value);
        auxUDIS = FactorUDIS.toString().split('.')[0];
        auxUDIS1 = FactorUDIS.toString().split('.')[1];
        resUDIS = auxUDIS + "." + auxUDIS1.substring(0, 2);
        document.getElementById("txtSuma1500").value = resUDIS;
        document.getElementById("txtSuma1500").disabled = true;
        document.getElementById("txtPrima1500").disabled = true;
    }
}
//MU-080082 Se topa la SA de la cobertura temporal al maximo establecido FIN

function selectTranspote() {
    if ($('#txtTipoTransporte').val() == "AEREO") {
        $('#divAeronaves').removeAttr('hidden');
    } else {
        $('#divAeronaves').attr('hidden', true);
    }
}

function selectLugarTrabajo() {
    if ($('#txtLugarTrabajo').val() == "OTRO") {
        $('#divOtro').removeAttr('hidden');
    } else {
        $('#divOtro').attr('hidden', true);
    }
}

function selectDeporte() {
    if ($('#txtDeporte').val() == "NINGUNO" || $('#txtDeporte').val() == "SELECCIONE") {
        $('#divCubrirRiesgo').attr('hidden', true);
    } else {
        $('#divCubrirRiesgo').removeAttr('hidden');
    }
}

function selectCopas() {
    if ($('#txtCantBebida').val() == "0" || $('#txtCantBebida').val() == "SELECCIONE") {
        $('#divFrecuencia').attr('hidden', true);
    } else {
        $('#divFrecuencia').removeAttr('hidden');
    }
}

function selectFuma() {
    if ($('#txtFuma').val() == "NINGUNO" || $('#txtFuma').val() == "SELECCIONE") {
        $('#divCantidadFumar').attr('hidden', true);
        $('#divFrecuenciaFumar').attr('hidden', true);
    } else {
        $('#divCantidadFumar').removeAttr('hidden');
        $('#divFrecuenciaFumar').removeAttr('hidden');
    }
}

function selectViveMadre() {
    if ($('#txtViveMadre').val() == "NO") {
        $('#txtEdadMuerteMadre').removeAttr('disabled');
        $('#txtMotivosMadre').removeAttr('disabled');
    } else {
        $('#txtEdadMuerteMadre').attr('disabled', true);
        $('#txtMotivosMadre').attr('disabled', true);
    }
}

function selectVivePadre() {
    if ($('#txtVivePadre').val() == "NO") {
        $('#txtEdadMuertePadre').removeAttr('disabled');
        $('#txtMotivosPadre').removeAttr('disabled');
    } else {
        $('#txtEdadMuertePadre').attr('disabled', true);
        $('#txtMotivosPadre').attr('disabled', true);
    }
}

function selectViveHermanos() {
    if ($('#txtViveHermanos').val() == "NO") {
        $('#txtEdadMuerteHermanos').removeAttr('disabled');
        $('#txtMotivosHermanos').removeAttr('disabled');
    } else {
        $('#txtEdadMuerteHermanos').attr('disabled', true);
        $('#txtMotivosHermanos').attr('disabled', true);
    }
}

function selectViveHijos() {
    if ($('#txtViveHijos').val() == "NO") {
        $('#txtEdadMuerteHijos').removeAttr('disabled');
        $('#txtMotivosHijos').removeAttr('disabled');
    } else {
        $('#txtEdadMuerteHijos').attr('disabled', true);
        $('#txtMotivosHijos').attr('disabled', true);
    }
}

function selectQuienCardiaca() {
    if ($('#txtQuienCardiaca').val() != "NINGUNO") {
        $('#txtEvolucionCardiaca').removeAttr('disabled');
    } else {
        $('#txtEvolucionCardiaca').attr('disabled', true);
    }
}

function selectQuienCancer() {
    if ($('#txtQuienCancer').val() != "NINGUNO") {
        $('#txtEvolucionCancer').removeAttr('disabled');
    } else {
        $('#txtEvolucionCancer').attr('disabled', true);
    }
}

function selectQuienPresion() {
    if ($('#txtQuienPresion').val() != "NINGUNO") {
        $('#txtEvolucionPresion').removeAttr('disabled');
    } else {
        $('#txtEvolucionPresion').attr('disabled', true);
    }
}

function selectQuienDiabetes() {
    if ($('#txtQuienDiabetes').val() != "NINGUNO") {
        $('#txtEvolucionDiabetes').removeAttr('disabled');
    } else {
        $('#txtEvolucionDiabetes').attr('disabled', true);
    }
}

function valNumero() {
    var pattern = new RegExp('^[A-Z]+$', 'i');
    if (!(pattern.test(document.getElementById('txtGiro').value))) {
        document.getElementById('txtGiro').value = "";
        alert("Campo Giro de la empresa no puede tener numeros");
    }
}