﻿//'****************************************************************************
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2010
//'Name of the file              : Beneficiarios.js
//'Creation/Modification History :
//'Modification                  : emontoya  Indra SWLabs
//'C1                            : emontoya - 30-12-2012
//                               : Se agrega validación para insertar y mostrar los
//                               : benefiarios por tipo.
//'C2                            : emontoya - 30-12-2012
//                               : Se crea función para actualizar el grid Fallecimiento y el
//                               : grid Remanente respectivamente.
//'C3                            : emontoya - 30-12-2012
//                               : Se agrega al método el parámetro tip_benef para mostrar
//                               : los beneficiarios adicionales por tipo de beneficiario
//                               : agregando validación para cada tipo.
//'C4                            : emontoya - 30-12-2012
//                               : Se modifica el método eliminaBenef, con el fin que se
//                               : eliminen los beneficiarios según el tipo de beneficiario en el
//                               : grid Fallecimiento y grid Remanente.
//'C5                            : Se agrega funcionalidad de requerimiento A27840 Segunda Fase Expediente Cliente 
//03052018
//'*****************************************************************************

////////////////////////////////////////////////////////////////
/******** FUNCIONES PARA LLENAR TABLA DE BENEFICIARIOS ********/
////////////////////////////////////////////////////////////////

// Limpia los campos de captura
function limpiaBenef()
{
    selIndiceCtrl("drpTipBenef", 0);
    selIndiceCtrl("drpParentesco", 0);
    valorCtrl("txtNombreBenef", "");
    valorCtrl("txtPaternoBenef", "");
    valorCtrl("txtMaternoBenef", "");
    valorCtrl("txtPctBenef", "");
    valorCtrl("hdnCodBenef", "");
    valorCtrl("hdnTipBenef", "");
    //'C5
    valorCtrl("txtFecNac", "");
    valorCtrl("txtDomicilio", "");
     valorCtrl("txtTel", "");
    valorCtrl("txtMail", "");
    //'C5F
    //MU-2017-052841 INI
    valorCtrl("txtTel","");
    valorCtrl("txtMail","");
    //MU-2017-052841 FIN
}

// 
/// <summary>
///     Inserta un beneficiario al grid
/// </summary>

//debugger;
function insertaBenef() {
    document.getElementById("grdBeneficiarios").style.display = "block";
    document.getElementById("grdFallecimiento").style.display = "block";
    document.getElementById("grdRemanente").style.display = "block";

    if (Page_ClientValidate("InsBenef")) {

        if (valorCtrl("txtNombreBenef").length < 4) {
            alert(unescape("El Nombre del Beneficiario, debe tener una longitud mínima de 4 caracteres"));
            focusCtrl("txtNombreBenef");
            //return false;
            return;
        }

        if (valorCtrl("txtDomicilio").length < 6) {
            alert(unescape("El Domicilio del Beneficiario, debe tener una longitud mínima de 6 caracteres"));
            focusCtrl("txtDomicilio");
            //return false;
            return;
        }

        if (valorCtrl("txtPaternoBenef").length < 3) {
            alert(unescape("El Apellido paterno del Beneficiario, debe tener una longitud mínima de 3 caracteres"));
            focusCtrl("txtPaternoBenef");
            //return false;
            return;
        }

        if (valorCtrl("drpParentescoAseg") == 37) {
            alert(unescape("No se puden insertar beneficiarios en mancomunados."));

            return;
        }

        //        var cod_benef = valorCtrl("hdnCodBenef");
        var Ramo = document.getElementById("HiddenRamoRequest").value;
        var asegurado = document.getElementById("UscAsegCLM_lblCLM").innerHTML;
        var cod_benef;
        if (Ramo == 105) {
            cod_benef = valorCtrl("drpTipBenef");
        }
        else {
            cod_benef = valorCtrl("hdnCodBenef");
        }
        var nombre = valorCtrl("txtNombreBenef");
        var paterno = valorCtrl("txtPaternoBenef");
        var materno = valorCtrl("txtMaternoBenef");
        var porcentaje = valorCtrl("txtPctBenef");
        var cod_parent = valorCtrl("drpParentesco");
        var nom_parent = textoCtrl("drpParentesco");
        var tip_benef = valorCtrl("drpTipBenef");
        var existe = false;
        //'C5
        var fecnac = valorCtrl("txtFecNac");
        var domicilio = valorCtrl("txtDomicilio");
        var telefono = valorCtrl("txttelbenef");
        var correo = valorCtrl("txtcorreobenef");
        //'C5F
        //MU-2017-052841 INI
        //var telefono = valorCtrl("txtTel");
        //var email = valorCtrl("txtMail");
        var telefono = "";
        var email = "";
        //MU-2017-052841 FIN

        if (cod_benef == "" || (tip_benef == "6" && textoCtrl("lnkInserBenef") == "Insertar"))
            cod_benef = 0;
        if (textoCtrl("lnkInserBenef") == "Modificar")
            existe = true;
        //  <--- C1 --->

        if (Ramo == "105") {
            switch (parseInt(tip_benef)) {
                case 6:
                    // 'C5 Se agregaron parámetros fecnac, domicilio
                    MetodosAjax.insertaBenef105(parseFloat(cod_benef), nombre, paterno, materno, porcentaje, cod_parent,
                                             nom_parent, parseInt(tip_benef), existe, fecnac, domicilio, asegurado, actualizaBenef_CallBack);

                    break;
                    //AEP BWMEILL. Millón Vida Fase 2. Para nuevo beneficiario: Sobreviviente 
                case 12:
                    MetodosAjax.insertaBenef105(parseFloat(cod_benef), nombre, paterno, materno, porcentaje,
                                             cod_parent, nom_parent, parseInt(tip_benef), existe, fecnac, domicilio, asegurado, actualizaSobreviviente_CallBack);



                    break;
                case 13:
                    MetodosAjax.insertaBenef105(parseFloat(cod_benef), nombre, paterno, materno, porcentaje,
                                              cod_parent, nom_parent, parseInt(tip_benef), existe, fecnac, domicilio, asegurado, actualizaFallecimiento_CallBack);



                    break;
                case 15:
                    MetodosAjax.insertaBenef105(parseFloat(cod_benef), nombre, paterno, materno, porcentaje,
                                             cod_parent, nom_parent, parseInt(tip_benef), existe, fecnac, domicilio, asegurado, actualizaRemanente_CallBack);

                    // 'C5F
                    break;
                default:
                    break;
                    // ------------
            }
        }
        else {
            switch (parseInt(tip_benef)) {
                case 6:
                    //MU-2017-052841 INI
                    // 'C5 Se agregaron parámetros fecnac, domicilio                
                    MetodosAjax.insertaBenef(parseFloat(cod_benef), nombre, paterno, materno, porcentaje, cod_parent,
                                             nom_parent, parseInt(tip_benef), existe, fecnac, domicilio, telefono, email, actualizaBenef_CallBack);

                    break;
                    //AEP BWMEILL. Millón Vida Fase 2. Para nuevo beneficiario: Sobreviviente 
                case 12:
                    MetodosAjax.insertaBenef(parseFloat(cod_benef), nombre, paterno, materno, porcentaje,
                                             cod_parent, nom_parent, parseInt(tip_benef), existe, fecnac, domicilio, telefono, email,
                                             function () {
                                                 muestraDetalle(parseFloat(cod_benef), parseInt(tip_benef), actualizaSobreviviente_CallBack);
                                             }
                                            );

                    break;
                case 13:
                    MetodosAjax.insertaBenef(parseFloat(cod_benef), nombre, paterno, materno, porcentaje,
                                              cod_parent, nom_parent, parseInt(tip_benef), existe, fecnac, domicilio, telefono, email,
                                              function () {
                                                  muestraDetalle(parseFloat(cod_benef), parseInt(tip_benef), actualizaFallecimiento_CallBack);
                                              }
                                             );

                    break;
                case 15:
                    MetodosAjax.insertaBenef(parseFloat(cod_benef), nombre, paterno, materno, porcentaje,
                                             cod_parent, nom_parent, parseInt(tip_benef), existe, fecnac, domicilio, telefono, email, function () {
                                                 muestraDetalle(parseFloat(cod_benef), parseInt(tip_benef), actualizaRemanente_CallBack);
                                             });
                    // 'C5F
                    //MU-2017-052841 FIN
                    break;
                default:
                    break;
                    // ------------
            }
        }

    }
}

function borraElementoBenef() {
    var gridView = document.getElementById("grdBeneficiarios").firstChild.firstChild.nextElementSibling.rows;
    if (gridView != null) {
        for (var i = 0; i < gridView.length; i++) {
            if (i != 0) {
                gridView[i].cells[0].innerText = "";
                gridView[i].cells[1].innerText = "";
                gridView[i].cells[2].innerText = "";
                gridView[i].cells[3].innerText = "";
                gridView[i].cells[4].innerText = "";
                gridView[i].cells[5].innerText = "";
            }
               
        }
    }
    return;
}

/// <summary>
///     Método que borra un beneficiario del grid
/// </summary>
function borraBenef()
{
    // Cancela la actualizacion de datos del beneficiario
    if(textoCtrl("lnkBorraBenef") == "Cancelar")
    {
        textoCtrl("lnkBorraBenef", "Borrar");
        if(textoCtrl("lnkInserBenef") == "Modificar")
            textoCtrl("lnkInserBenef", "Insertar");

        limpiaBenef();
        var gridView = document.getElementById("grdBeneficiarios").firstChild.firstChild;
        if(gridView != null)
        {
            for(var i = 0; i < gridView.rows.length; i++)
            {
                if(i != 0)
                    gridView.rows[i].style.backgroundColor = "";
            }
        }
        return;
    }

    // Borra el beneficiario seleccionado
    var tip_benef = valorCtrl("hdnTipBenef");
    var cod_benef = valorCtrl("hdnCodBenef");

    if(cod_benef != "" && cod_benef != undefined)
    {
        // <--- C4 ---->
        //Eliminación por tipo de beneficiario
        switch (parseInt(tip_benef)) {
            //AEP BWMEILL. Millón Vida Fase 2. Para nuevo beneficiario: Sobreviviente 
            case 12:
                MetodosAjax.eliminaBenef(parseFloat(cod_benef), tip_benef, function () {
                    muestraDetalle(parseFloat(cod_benef), parseInt(tip_benef), actualizaSobreviviente_CallBack);
                });
                break;
            case 13:
                MetodosAjax.eliminaBenef(parseFloat(cod_benef), tip_benef, function () {
                    muestraDetalle(parseFloat(cod_benef), parseInt(tip_benef), actualizaRemanente_CallBack);
                });
                break;
            case 15:
                MetodosAjax.eliminaBenef(parseFloat(cod_benef), tip_benef, function () {
                    muestraDetalle(parseFloat(cod_benef), parseInt(tip_benef), actualizaFallecimiento_CallBack);
                });
                break;
            default:
                MetodosAjax.eliminaBenef(parseFloat(cod_benef), parseInt(tip_benef), actualizaBenef_CallBack);
                break;
        }
        // <---------->
    }
    else alert("Debes seleccionar un beneficiario");
}

function actualizaBenef_CallBack(response)
{
    if (response.error != null)
    {
        alert(response.error.description);
        return;
    }
    document.getElementById("grdBeneficiarios").innerHTML = response.value;
    limpiaBenef();
    if(textoCtrl("lnkInserBenef") == "Modificar")
        textoCtrl("lnkInserBenef", "Insertar");
    if(textoCtrl("lnkBorraBenef") == "Cancelar")
        textoCtrl("lnkBorraBenef", "Borrar");
    visibleCtrl("checkEndoso", true);
    
    //Agregado.
    AjustarFrame();
    focusCtrl("btnModDatos");
}

//  <--- C2 --->
/// <summary>
///     Método que actualiza el grid Fallecimiento
/// </summary>
function actualizaFallecimiento_CallBack(response) 
{
    if (response.error != null) 
    {
        alert(response.error.description);
        return;
    }

    document.getElementById("grdFallecimiento").innerHTML = response.value;
    limpiaBenef();

    if (textoCtrl("lnkInserBenef") == "Modificar")
        textoCtrl("lnkInserBenef", "Insertar");

    if (textoCtrl("lnkBorraBenef") == "Cancelar")
        textoCtrl("lnkBorraBenef", "Borrar");

    visibleCtrl("checkEndoso", true);
 
    //Agregado.
    AjustarFrame();
    focusCtrl("btnModDatos");
}
//AEP BWMEILL.Millón Vida Fase 2. Nuevo beneficiario: sobreviviente

function actualizaSobreviviente_CallBack(response) {
    if (response.error != null) {
        alert(response.error.description);
        return;
    }

//    document.getElementById("grdSobreviviente").innerHTML = response.value;
    document.getElementById("grdRemanente").innerHTML = response.value;
    limpiaBenef();

    if (textoCtrl("lnkInserBenef") == "Modificar")
        textoCtrl("lnkInserBenef", "Insertar");

    if (textoCtrl("lnkBorraBenef") == "Cancelar")
        textoCtrl("lnkBorraBenef", "Borrar");

    visibleCtrl("checkEndoso", true);

    //Agregado.
    AjustarFrame();
    focusCtrl("btnModDatos");
}

/// <summary>
///     Método que actualiza el grid Remanente
/// </summary>
function actualizaRemanente_CallBack(response)
{
    if (response.error != null) 
    {
        alert(response.error.description);
        return;
    }

    document.getElementById("grdRemanente").innerHTML = response.value;
    limpiaBenef();

    if (textoCtrl("lnkInserBenef") == "Modificar")
        textoCtrl("lnkInserBenef", "Insertar");

    if (textoCtrl("lnkBorraBenef") == "Cancelar")
        textoCtrl("lnkBorraBenef", "Borrar");

    visibleCtrl("checkEndoso", true);

    //Agregado.
    AjustarFrame();
    focusCtrl("btnModDatos");
}

// ------------

// Recupera los datos del beneficiario para modificarlos
function modificarBenef(cod_benef, tip_benef)
{
    limpiaBenef();
    var benef = MetodosAjax.obtieneBenef(parseFloat(cod_benef), parseInt(tip_benef));
    if(benef.error == null)
    {
        if(benef != null && benef.value != null)
        {
            valorCtrl("hdnCodBenef", cod_benef);
            valorCtrl("hdnTipBenef", benef.value.tip_benef);
            valorCtrl("drpTipBenef", benef.value.tip_benef);
            valorCtrl("drpParentesco", benef.value.cod_parent);
            valorCtrl("txtNombreBenef", benef.value.nombre);
            valorCtrl("txtPaternoBenef", benef.value.paterno);
            valorCtrl("txtMaternoBenef", benef.value.materno);
            valorCtrl("txtPctBenef", benef.value.porcentaje);
            //'C5
            valorCtrl("txtFecNac", benef.value.fecnac);
            valorCtrl("txtDomicilio", benef.value.domicilio);
            //'C5F

            if(textoCtrl("lnkInserBenef") == "Insertar")
                textoCtrl("lnkInserBenef", "Modificar");
            if(textoCtrl("lnkBorraBenef") == "Borrar")
                textoCtrl("lnkBorraBenef", "Cancelar");
        }
    }
    else alert(benef.error.description);
}

// Seleccion un beneficiario
function seleccionaBenef(cod_benef, tip_benef, rowId)
{
    limpiaBenef();
    valorCtrl("hdnTipBenef", tip_benef);
    valorCtrl("hdnCodBenef", cod_benef);
    var gridView = document.getElementById("grdBeneficiarios").firstChild.firstChild;
    if(gridView != null)
    {
        for(var i = 0; i < gridView.rows.length; i++)
        {
            if(gridView.rows[i].id != rowId)
            {
                if(i != 0)
                    gridView.rows[i].style.backgroundColor = "";
            }
        }
    }
}

// <--- C3 --->
/// <summary>
///     Método que muestra los beneficiarios adicionales
/// </summary>
function muestraDetalle(cod_benef, tip_benef)
{
    var gridView = document.getElementById("grdBeneficiarios").firstChild.firstChild.nextElementSibling;

    if(gridView != null)
    {
        for(var i = 0; i < gridView.rows.length; i++)
        {
            if(i != 0)
                gridView.rows[i].style.backgroundColor = "";
        }
    }
    
    switch (parseInt(tip_benef)) 
    {
        case 13:
            MetodosAjax.muestraBenef(parseFloat(cod_benef), parseInt(tip_benef), actualizaFallecimiento_CallBack);
            break;
            //AEP BWMEILL. Millón Vida Fase 2. Para nuevo beneficiario: Sobreviviente
        case 12:
            MetodosAjax.muestraBenef(parseFloat(cod_benef), parseInt(tip_benef), actualizaSobreviviente_CallBack);
            break;
        case 15:
            MetodosAjax.muestraBenef(parseFloat(cod_benef), parseInt(tip_benef), actualizaRemanente_CallBack);
        break;
    }
}

// Valida que la suma del porcentaje de participacion sea del 100%
function validaPorcentaje(tblTercero, tercero)
{
    if(tblTercero.error == null)
    {
	    if(tblTercero != null && tblTercero.value != null && tblTercero.value.Rows.length != 0)
	    {
	        var totalAgt = tblTercero.value.Rows.length;
	        var totalPct = 0;

	        for(var i=0; i<totalAgt; i++)
	            totalPct += parseInt(tblTercero.value.Rows[i].porcentaje);

	        if((totalPct % 100) > 0)
            {
                var msj = "";
                if(tercero != "" && tercero != undefined)
                    msj =  "de los " + tercero;
                alert("La suma del porcentaje de participacion " + msj + " debe ser igual a 100%");
                return false;
            }
        }
    }
    else
    {
        alert(tblTercero.error.description);
        return false;
    }
    return true;
}