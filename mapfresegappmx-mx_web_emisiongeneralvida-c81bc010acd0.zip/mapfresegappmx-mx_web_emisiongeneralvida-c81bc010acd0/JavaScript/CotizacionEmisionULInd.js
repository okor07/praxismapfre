﻿//'****************************************************************************
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2010
//'Name of the file              : CotizacionEmision.js
//'Creation/Modification History :
//'Modification                  : jdgomezc  Indra SWLabs
//                               : jchuertas Indra SWLabs
//                               : emontoya  Indra SWLabs
//'C1                            : jdgomezc - 30-12-2012
//                                 Originalmente la prima minima valida se
//                                 calculaba a partir la prima neta + recargos
//                                 y derechos. Segun el proyecto A16742 este
//                                 calculo solo se hace a partir de la primaNeta
//'C2                            : jdgomezc - 30-12-2012
//                                 Se incluye la validación de la politica de
//                                 lavado de dinero
//'C3                            : jchuertas - 30-12-2012
//                                 Se captura el tipo de seguro seleccionado y
//                                 se agrega al arreglo de datos variables.
//'C4                            : jchuertas - 30-12-2012
//                                 Se agrega la validación de antecedentes OII para
//                                 saber si es debe generar poliza o solicitud.
//'C5                            : jchuertas - 30-12-2012
//                                 Se cambian los parametros que se envian al procedimiento
//                                 eliminando el campo mensaje ya que este se obtendrá de la BD
//'C6                            : jchuertas - 30-12-2012
//                                 Se agrega el metodo getNumContrato
//'C7                            : emontoya - 30-12-2012
//                                 se agrega la validación para saber si se realiza póliza o solicitud.
//'C8                            : emontoya - 30-12-2012
//                                 se agrega validación para habilitar el botón imprime solicitud.
//'C10                           : jdgomezc - 30-12-2012
//                                 Se envia por defecto una N en la variable endosoEdu
//'C11                           : jchuertas - 30-12-2012
//                                 Se habilita el botón Adjuntar cuando se realiza el cálculo de las primas.
//'C12                           : jchuertas - 30-12-2012
//'                                Envío de los nuevos parámetros de consulta al método MetodosAjax.validaPrimaMinima.
//'C13                           : jchuertas - 30-12-2012
//'                                Envío de los nuevos parámetros de consulta al método MetodosAjax.validaSumaBasica.
//'C14                           : jchuertas - 30-12-2012
//'                                Se modificó el método validarCumulos cambiando los parámetros de envío al método
//                                 MetodosAjax.validaCumulos
//'C15                           : jchuertas - 04-01-2013
//'                                Cuando se genera la solicitud de emisión se llama al metodo AgregarFolioDocumentum en
//                                 metodosAjax para que se actualice en documentum con el numero de folio ram.
//'C16                           : jdgomezc - 27-02-2012
//'                                Se habilita el botón de imprimir poliza siempre que haya una emisión
//'C17                           : jchuertas - 30-12-2012
//                               : Se agregaron los métodos obtenerTipoSeguros() y Seguros_CallBack
//'C18                           : jchuertas - 28-02-2013
//                                 Obtiene las coberturas seleccionadas para enviarlas al procedimiento que retorna
//                                 los tipos de seguro
//'C19                             jchuertas - 28-02-2013
//                                 Se hace el llamado para obtener los tipos de seguro
//'C20                             jchuertas - 01-03-2013
//                                 Se inicializa el tipo de seguro en patrimonial para que no salga la validación
//                                 de datos obligatorios a la hora de armar la cadena de datos variables.
//'C21                             emontoya - 04-03-2013
//                                 Se agrega el llamado de la función OcultarMostrarBeneficiario.
//'C22                             jhuertas - 01-10-2013
//                                 Se agrega el llamado de la función de validación de exámenes.
//'C23                             jhuertas - 01-11-2013
//                                 Se cambia el mensaje de error de la suma asegurada minima en dolares. 
//'C24                             jhuertas - 06-11-2013
//                                 Si no existen mensajes de exámenes configurados se muestra una alerta y no se realiza
//								   ni solicitud ni póliza.
//'C25                             jglopezh - 21-11-2013
//                                 Se agrega el mensaje de validación de suma asegurada.
//'C26                             Se manda la prima a un hidden para expediente cliente.                                                                                                                             ni solicitud ni póliza.
//'C27                             apl 09-12-2014
//                                 Modificación a 'C20. Se quita valor por default de Seguro Patromonial y se deja selección de acuerdo a RadioButton.
//'C28                             AEP Se agrega funcionalidad de requerimiento A27840 Segunda Fase Expediente Cliente 
// C2:		 					   26-08-2019
//   		                       MU-2019-050447 - MX_NC_VID Incremento de sumas aseguradas
//'C29							   Modificacion para la validacion de la Tarjeta.
//'*****************************************************************************

var tipcobro = "";

function Cotiza() {
    // <--- C19 --->
    obtenerTipoSeguros();       //Validar que manda en MV

    //obtenerDocumentosAdjuntar();
    if (validaPagina("C"))
        armaCadena("C", "PRIMAS");
    // <--- C11 --->
    document.getElementById("btnAdjuntar").disabled = false;
    // <----------->        
	var SumaAsegBasica = parseInt($('#txtSuma1000').val());
    var TipoCambioDlls = parseFloat(document.getElementById("Footer_lblUSD").innerHTML);
    var TipoCambioUdis = parseFloat(document.getElementById("Footer_lblUDIS").innerHTML);
    var TipoMoneda = $('#drpMoneda').val();

    switch (TipoMoneda) {
        case '1':
            if (SumaAsegBasica > 1500000) {
                ConstruyeCuestionarioMillon();
            } else {
                document.getElementById("divCuestionarioMillon").innerHTML = "";
            }
            break;
        case '2':
            if ((TipoCambioDlls * SumaAsegBasica) > 1500000) {
                ConstruyeCuestionarioMillon();
            } else {
                document.getElementById("divCuestionarioMillon").innerHTML = "";
            }
            break;
        case '6':
            if ((TipoCambioUdis * SumaAsegBasica) > 1500000) {
                ConstruyeCuestionarioMillon();
            } else {
                document.getElementById("divCuestionarioMillon").innerHTML = "";
            }
            break;
        default:
            document.getElementById("divCuestionarioMillon").innerHTML = ""
            break;
    }
    //Validacion de moneda para pasarela

    //Habilita o Deshabilita Pasarela
    var primaini = document.all("txtMontoIni").value;
    var primafracc = formatNumber(document.all("lblPrimFrac").innerHTML);
    var res1 = parseFloat(primafracc) + parseFloat(primaini);
    var moneda = document.getElementById("drpMoneda").value;
    var res = "";
    if (moneda == "2") {
        var totres = MetodosAjax.getfactorconv(res1);
        res = totres.value;
        MetodosAjax.setSession("TotDol", res);
    }
    else {
        res = res1;
    }

    if (parseFloat(res) > parseFloat(document.all("hdnlimitepasarela").value)) {
        //document.getElementById("btnRferenciaBancaria").style.visibility = "visible";
        document.getElementById("PasarelaBTn").value = 1;
        tipcobro = "R";
    }
    else {
        //document.getElementById("divPasarelaCobro").style.visibility = "visible";
        //document.getElementById("btnPagar").style.visibility = "visible";
        //document.getElementById("datosPoliza").style.visibility = "visible";
        document.getElementById("PasarelaBTn").value = 2;
        tipcobro = "L";
    }
    devuelveCuestionario();

}

//------->C17<-------
/// <summary>
///     Este método se encarga de obtener el codigo html generado con los tipos de seguro para beneficiarios
///     y agregarlos en el formulario de emision.
/// </summary>

function obtenerTipoSeguros() {
    document.getElementById("DivTipoSeguros").innerHTML = "";

    var Ramo = document.getElementById("HiddenRamoRequest").value;
    var contrato = document.getElementById("HiddenContratoGenerico").value;
    var Modalidad = document.getElementById("HiddenModalidad").value;
    var Cobertura = "9999";

    //----------------->C18<--------------------

    //var coberturas = "";
    //var coberturaRadio = document.getElementsByName("rbCobertura");
    //var coberturaCheck = document.getElementsByName("chkCobertura");

    //for (j = 0; j < coberturaRadio.length; j++) {
    //    if (coberturaRadio[j].checked == true) {
    //        coberturas = coberturaRadio[j].value;
    //    }
    //}

    //for (k = 0; k < coberturaCheck.length; k++) {
    //    if (coberturaCheck[k].checked == true) {
    //        if (coberturas == "") {
    //            coberturas = coberturaCheck[k].value;
    //        }
    //        else {
    //            coberturas = coberturas + "," + coberturaCheck[k].value;
    //        }
    //    }
    //}
    //----------------------------------------

    //if (document.getElementById("rbtnListPolizaContrato_1").checked) {
    //    contrato = selIndex("drpContrato");
    //}

    MetodosAjax.getObtieneTipoSeguros(Ramo, contrato, Modalidad, Cobertura, Seguros_CallBack);

}

//------->C17<-------
/// <summary>
///     Este método se encarga de agregar el codigo html generado con los tipos de seguros en el formulario de emision.
/// </summary>

function Seguros_CallBack(res) {
    if (res.error == null) {
        if (res != null && res.value != null) {
            if (res.value != "") {
                document.getElementById("DivTipoSeguros").innerHTML = res.value;
                //<--- C21 --->
                //OcultarMostrarBeneficiario();
                //<----------->
                AjustarFrame();
            }
            else {
                alert("NO SE ENCONTRARON TIPOS DE SEGUROS CONFIGURADOS, DEBE CAMBIAR LOS PAR\u00c1METROS INGRESADOS PARA PODER EMITIR.");
            }

        }
    }
    else {
        alert("NO SE PUDO OBTENER LOS TIPOS DE SEGUROS, SI EL PROBLEMA PERSISTE COMUN\u00cdQUESE CON EL ADMINISTRADOR.");
    }
}

function Emite() {
    if (validaPagina("P")) {
        Cargando(true);
        var Modo = ValidarEmision();
        if (Modo != "E") {
            armaCadena(Modo, "SOLICITUD");
        }
        else {
            Cargando(false);
            return;
        }
    }
}

function validaPagina(oper) {
    var gridViewArch = document.getElementById("grdAdjuntarArchivo");

    if (gridViewArch == null && oper == "P") {
        alert("SE DEBE ADJUNTAR LA SOLICITUD FIRMADA POR EL CLIENTE, AS\u00cd COMO SU IDENTIFICACI\u00d3N OFICIAL.");
        return false;
    }

    if (document.getElementById("drpAgente").options.length > 1) {
        if (selIndiceCtrl("drpAgente") < 1) {
            alert("DEBES SELECCIONAR UN AGENTE");
            focusCtrl("drpAgente");
            return false;
        }
    }

    if (document.getElementById("txtEdad").value == "") {
        alert("DEBES CAPTURAR LA EDAD");
        focusCtrl("txtEdad");
        return false;
    }

    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        if (selIndiceCtrl("drpPolizaGrupo") < 1) {
            alert("DEBES SELECCIONAR UNA P\u00d3LIZA GRUPO");
            focusCtrl("drpPolizaGrupo");
            return false;
        }
        if (selIndiceCtrl("drpContrato") < 1) {
            alert("DEBES SELECCIONAR UN CONTRATO");
            focusCtrl("drpContrato");
            return false;
        }
    }

    if (document.getElementById("DivCoberturas").innerHTML == "") {
        alert("NO SE HAN DEFINIDO LAS COBERTURAS");
        return false;
    }

    //if (ValidarUnaCobMarcada()) {
    //    alert("DEBES SELECCIONAR POR LO MENOS UNA COBERTURA");
    //    return false;
    //}

    var totPart = document.all("HidTotalPorcentaje").value;
    if (parseFloat(totPart) < 100) {
        alert("EL PORCENTAJE DE AGENTES DEBE SUMAR 100%.");
        return false;
    }

    if (oper == "P") {

        // Valida captura de los beneficiarios
        var gridView = document.getElementById("grdBeneficiarios").firstChild;
        if (gridView == null) {
            if (oper == "P") {
                alert("DEBES INGRESAR POR LO MENOS UN BENEFICIARIO");
                return false;
            }
        }
        else {
            // Valida la suma de porcentaje de los beneficiarios
            var tblBenef = MetodosAjax.obtieneTablaBenef();
            if (!validaPorcentaje(tblBenef, "beneficiarios"))
                return false;
        }
    }



    if (oper == "P") {
        if (document.getElementById("txtPeso").value == "") {
            alert("DEBES CAPTURAR EL PESO");
            focusCtrl("txtPeso");
            return false;
        }

        if (document.getElementById("txtEstatura").value == "") {
            alert("DEBES CAPTURAR LA ESTATURA");
            focusCtrl("txtEstatura");
            return false;
        }
        if (document.getElementById("HiddenRamoRequest").value != "112") {
            if (document.getElementById("chkboxNo").checked == false && document.getElementById("chkboxSi").checked == false) {
                alert("DEBES CONTESTAR LA PREGUNTA DEL DEPORTE Y/O AFICI\u00d3N PELIGROSA");
                return false;
            }

            if (!validaCuest()) {
                alert("DEBES CONTESTAR TODO EL CUESTIONARIO");
                return false;
            }
            if (ValidaServFune()) {
                return false;
            }
        }
		
		if (document.getElementById("divCuestionario").innerHTML != "") {
             if (ValidarCuestionarioEnfRespiratorias()) {
                alert('DEBES CONTESTAR TODO EL CUESTIONARIO');
                return false;
              }
        }
		
		if (document.getElementById("divCuestionarioMillon").innerHTML != "") {
			if (ValidarCuestionarioMillon()) {
				return false;
			}
		}
    }
    

    return true;
}

function ValidarCuestionarioEnfRespiratorias() {

    if ($('#HiddenRamoRequest').val() == '101') {
         if ($('#txtPeso').val() == '') {
            alert('DEBES AGREGAR PESO');
            focusCtrl("txtPeso");
            return true;
          }

        if ($('#txtEstatura').val() == '') {
            alert('DEBES AGREGAR ESTATURA');
            focusCtrl("txtEstatura");
            return true;
        }
    }

    if (!document.getElementById("chkSi14").checked) {
        if (!document.getElementById("chkNo14").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi14");
            return true;
        }
    } else {
        if ($('#txt14').val() == '') {
            alert('DEBES ESCRIBIR ENFERMEDAD RESPIRATORIA');
            focusCtrl("txt14");
            return true;
        }
    }

    if (!document.getElementById("chkSi15").checked) {
        if (!document.getElementById("chkNo15").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi15");
            return true;
        }
    } else {
        if ($('#txt15').val() == '') {
            alert('DEBES ESCRIBIR ENFERMEDAD RESPIRATORIA');
            focusCtrl("txt15");
            return true;
        }
    }

    if (!document.getElementById("chkSi16").checked) {
        if (!document.getElementById("chkNo16").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi16");
            return true;
        }
    } else {
        if (!document.getElementById("chk16a").checked) {
            if (!document.getElementById("chk16b").checked) {
                if (!document.getElementById("chk16c").checked) {
                    if (!document.getElementById("chk16d").checked) {
                        if (!document.getElementById("chk16e").checked) {
                            if (!document.getElementById("chk16f").checked) {
                                if (!document.getElementById("chk16g").checked) {
                                    if (!document.getElementById("chk16h").checked) {
                                        alert('DEBES SELECCIONAR ALGUN SINTOMA');
                                        focusCtrl("chk16a");
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (!document.getElementById("chkSi17").checked) {
        if (!document.getElementById("chkNo17").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi17");
            return true;
        }
    } else {
        if ($('#txt17a').val() == 'Seleccione') {
            alert('DEBES SELECCIONAR EL TIPO DE PRUEBA');
            focusCtrl("txt17a");
            return true;
        } else {
            if ($('#txt17b').val() == '') {
                alert('DEBES SELECCIONAR LA FECHA DE LA PRUEBA');
                focusCtrl("txt17b");
                return true;
            }
        }
    }

    if (!document.getElementById("chkSi18").checked) {
        if (!document.getElementById("chkNo18").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi18");
            return true;
        }
    } else {
        if ($('#txt18a').val() == '') {
            alert('DEBES SELECCIONAR LA FECHA');
            focusCtrl("txt18a");
            return true;
        } else {
            if ($('#txt18b').val() == 'SELECCIONE') {
                alert('DEBES SELECCIONAR TIPO DE ATENCIÓN');
                focusCtrl("txt18b");
                return true;
            } else {
                if ($('#txt18c').val() == '') {
                    alert('DEBES AGREGAR EL TRATAMIENTO');
                    focusCtrl("txt18c");
                    return true;
                }
            }
        }
    }

    if (!document.getElementById("chkSi19").checked) {
        if (!document.getElementById("chkNo19").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi19");
            return true;
        }
    } else {
        if ($('#txt19a').val() == 'Seleccione') {
            alert('DEBES SELECCIONAR EL TIPO DE PRUEBA');
            focusCtrl("txt19a");
            return true;
        } else {
            if ($('#txt19b').val() == '') {
                alert('DEBES SELECCIONAR LA FECHA DE LA PRUEBA');
                focusCtrl("txt19b");
                return true;
            }
        }
    }

    if (!document.getElementById("chkSi20").checked) {
        if (!document.getElementById("chkNo20").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi20");
            return true;
        }
    } else {
        if ($('#txt20a').val() == '') {
            alert('DEBES ESCRIBIR EL TIPO DE SECUELA');
            focusCtrl("txt20a");
            return true;
        } else {
            if ($('#txt20b').val() == '') {
                alert('DEBES ESCRIBIR TRATAMIENTO MEDICO');
                focusCtrl("txt20b");
                return true;
            } else {
                if ($('#txt20c').val() == '') {
                    alert('DEBES ESCRIBIR ESTADO ACTUAL');
                    focusCtrl("txt20c");
                    return true;
                }
            }
        }
    }

    if (!document.getElementById("chkSi21").checked) {
        if (!document.getElementById("chkNo21").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi21");
            return true;
        }
    } else {
        if ($('#txt21').val() == '') {
            alert('DEBES SELECCIONAR LA FECHA QUE ESTUVISTE EN CUARENTENA');
            focusCtrl("txt21");
            return true;
        }
    }

    if (!document.getElementById("chkSi22").checked) {
        if (!document.getElementById("chkNo22").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi22");
            return true;
        }
    } else {
        if ($('#txt22a').val() == '') {
            alert('DEBES SELECCI0NAR LA FECHA QUE VIAJO');
            focusCtrl("txt22a");
            return true;
        } else {
            if ($('#txt22b').val() == 'SELECCIONE') {
                alert('DEBES SELECCI0NAR MEDIO DE TRANSPORTE');
                focusCtrl("txt22b");
                return true;
            } else {
                if ($('#txt22c').val() == 'SELECCIONE') {
                    alert('DEBES SELECCIONAR DESTINO');
                    focusCtrl("txt22c");
                    return true;
                }
            }
        }
    }

    if (!document.getElementById("chkSi23").checked) {
        if (!document.getElementById("chkNo23").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi23");
            return true;
        }
    } else {
        if ($('#txt23a').val() == '') {
            alert('DEBES SELECCIONAR LA FECHA DE INICIO DE TU VIAJE');
            focusCtrl("txt23a");
            return true;
        } else {
            if ($('#txt23b').val() == '') {
                alert('DEBES SELECCIONAR LA FECHA DE TERMINO DE TU VIAJE');
                focusCtrl("txt23b");
                return true;
            } else {
                if ($('#txt23c').val() == 'SELECCIONE') {
                    alert('DEBES SELECCIONAR DESTINO');
                    focusCtrl("txt23c");
                    return true;
                } else {
                    if ($('#txt23d').val() == 'SELECCIONE') {
                        alert('DEBES SELECCIONAR MEDIO DE TRANSPORTE');
                        focusCtrl("txt23d");
                        return true;
                    }
                }
            }
        }
    }

    if (!document.getElementById("chkSi24").checked) {
        if (!document.getElementById("chkNo24").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi24");
            return true;
        }
    } else {
        if ($('#txt24a').val() == '') {
            alert('DEBES ESCRIBIR LAS FECHAS');
            focusCtrl("txt24a");
            return true;
        } else {
            if ($('#txt24b').val() == '') {
                alert('DEBES ESCRIBIR LOS LUGARES');
                focusCtrl("txt24b");
                return true;
            }
        }
    }

    if (!document.getElementById("chkSi25").checked) {
        if (!document.getElementById("chkNo25").checked) {
            alert('DEBES MARCAR ALGUNA CASILLA');
            focusCtrl("chkSi25");
            return true;
        }
    }

}


function ValidarCuestionarioMillon() {
    if (document.getElementById("chkSiOtraOcupacion").checked) {
        if ($('#txtOtraOcupacion').val() == '0') {
            alert('DEBES SELECCIONAR EN QUE CONSISTE TU OTRA OCUPACION');
            focusCtrl("txtOtraOcupacion");
            return true;
        }
    }

    if (document.getElementById("chkSiViajar").checked) {
        if ($('#txtTipoTransporte').val() == 'SELECCIONE') {
            alert('DEBES SELECCIONAR TIPO DE TRANSPORTE');
            focusCtrl("txtTipoTransporte");
                return true;
        }
    }

    if ($('#txtTipoTransporte').val() == 'AEREO') {
        if (document.getElementById("chkSiAParticular").checked) {
            if ($('#txtTipoAeronave').val() == '') {
                alert('DEBES AGREGAR TIPO DE AERONAVE Y HORAS DE VUELO');
                focusCtrl("txtTipoAeronave");
                    return true;
                }
            }
        }

    if (document.getElementById("chkSiMotocicleta").checked) {
        if ($('#txtFMotocicleta').val() == '') {
            alert('DEBES AGREGAR LA FRECUENCIA Y PARA QUE USAS LA MOTOCICLETA');
            focusCtrl("txtFMotocicleta");
            return true;
        }
    }

    if (document.getElementById("chkSiAlturas").checked) {
        if ($('#txtAlturas').val() == '') {
            alert('DEBES AGREGAR PROMEDIO EN METROS');
            focusCtrl("txtAlturas");
            return true;
        }
    }

    if ($('#txtLugarTrabajo').val() == 'OTRO') {
        if ($('#txtOtroLugarTrabajo').val() == '') {
            alert('DEBES AGREGAR EL OTRO LUGAR DE TRABAJO');
            focusCtrl("txtOtroLugarTrabajo");
            return true;
        }
    }

    if ($('#txtCantBebida').val() != '0') {
        if ($('#txtFrecuenciaBebida').val() == 'SELECCIONE') {
            alert('DEBES SELECCIONAR LA FRECUENCIA');
            focusCtrl("txtFrecuenciaBebida");
            return true;
        }
    }

    if ($('#drpFuma').val() == '1') {
        if ($('#txtFuma').val() == 'SELECCIONE') {
            alert('DEBES SELECCIONAR QUE TIPO ES LO QUE FUMAS');
            focusCtrl("txtFuma");
            return true;
        }
    }

    if ($('#drpFuma').val() == '1') {
        if ($('#txtFuma').val() != 'SELECCIONE') {
            if ($('#txtFuma').val() == 'NINGUNO') {
                alert('DEBES SELECCIONAR OTRA APARTE DE NINGUNO EN FUMADOR');
                focusCtrl("txtFuma");
                return true;
            }
        }
    }

    if ($('#drpFuma').val() == '1') {
        if ($('#txtFuma').val() != 'SELECCIONE') {
            if ($('#txtFuma').val() != 'NINGUNO') {
                if ($('#txtCantidadFumar').val() == 'SELECCIONE') {
                    alert('DEBES SELECCIONAR LA CANTIDAD QUE FUMA');
                    focusCtrl("txtCantidadFumar");
                    return true;
                }
            }
        }
    }

    if ($('#drpFuma').val() == '1') {
        if ($('#txtFuma').val() != 'SELECCIONE') {
            if ($('#txtFuma').val() != 'NINGUNO') {
                if ($('#txtCantidadFumar').val() == '0') {
                    alert('DEBES SELECCIONAR LA CANTIDAD QUE FUMA');
                    focusCtrl("txtCantidadFumar");
                    return true;
                }
            }
        }
    }

    if ($('#drpFuma').val() == '1') {
        if ($('#txtFuma').val() != 'SELECCIONE') {
            if ($('#txtFuma').val() != 'NINGUNO') {
                if ($('#txtCantidadFumar').val() != '0') {
                    if ($('#txtCantidadFumar').val() != 'SELECCIONE') {
                        if ($('#txtFrecuenciaFumar').val() == 'SELECCIONE') {
                            alert('DEBES SELECCIONAR LA FRECUENCIA QUE FUMA');
                            focusCtrl("txtFrecuenciaFumar");
                            return true;
                        }
                    }
                }
            }
        }
    }

    if (document.getElementById("chkSiDroga").checked) {
        if ($('#txtTipoFrecuenciaDroga').val() == '') {
            alert('DEBES AGREGAR FRECUENCIA DE CONSUMO DE DROGA');
            focusCtrl("txtTipoFrecuenciaDroga");
            return true;
        }
    }

    if ($('#txtViveMadre').val() == 'NO') {
        if ($('#txtEdadMuerteMadre').val() == '' || $('#txtMotivosMadre').val() == '') {
            alert('DEBES AGREGAR EDAD DE MUERTE Y MOTIVOS');
            focusCtrl("txtEdadMuerteMadre");
            return true;
        }
    }

    if ($('#txtVivePadre').val() == 'NO') {
        if ($('#txtEdadMuertePadre').val() == '' || $('#txtMotivosPadre').val() == '') {
            alert('DEBES AGREGAR EDAD DE MUERTE Y MOTIVOS');
            focusCtrl("txtEdadMuertePadre");
            return true;
        }
    }

    if ($('#txtViveHermanos').val() == 'NO') {
        if ($('#txtEdadMuerteHermanos').val() == '' || $('#txtMotivosHermanos').val() == '') {
            alert('DEBES AGREGAR EDAD DE MUERTE Y MOTIVOS');
            focusCtrl("txtEdadMuerteHermanos");
            return true;
        }
    }

    if ($('#txtViveHijos').val() == 'NO') {
        if ($('#txtEdadMuerteHijos').val() == '' || $('#txtMotivosHijos').val() == '') {
            alert('DEBES AGREGAR EDAD DE MUERTE Y MOTIVOS');
            focusCtrl("txtEdadMuerteHijos");
            return true;
        }
    }

    if (document.getElementById("chk1Si").checked) {
        if ($('#txt1Causa').val() == '') {
            alert('DEBES AGREGAR LA CAUSA');
            focusCtrl("txt1Causa");
            return true;
        }
    }

    if (document.getElementById("chk2Si").checked) {
        if ($('#txt2Causa').val() == '' || $('#txt2Cuando').val() == '') {
            alert('DEBES AGREGAR LA CAUSA Y CUANDO');
            focusCtrl("txt2Causa");
            return true;
        }
    }

    if (document.getElementById("chk3Si").checked) {
        if ($('#txt3Causa').val() == '' || $('#txt3Cuando').val() == '') {
            alert('DEBES AGREGAR LA CAUSA Y CUANDO');
            focusCtrl("txt3Causa");
            return true;
        }
    }

    if (document.getElementById("chk4Si").checked) {
        if ($('#txt4Causa').val() == '' || $('#txt4Cuando').val() == '') {
            alert('DEBES AGREGAR LA CAUSA Y CUANDO');
            focusCtrl("txt4Causa");
            return true;
        }
    }

    if (document.getElementById("chk5Si").checked) {
        if ($('#txtKgAumentados').val() == '' || $('#txtKgDisminuidos').val() == '') {
            alert('DEBES AGREGAR KILOS AUMENTADOS Y DISMINUIDOS');
            focusCtrl("txtKgAumentados");
            return true;
        }
    }

    if (document.getElementById("chk7Si").checked) {
        if ($('#txt7Causa').val() == '') {
            alert('DEBES AGREGAR CAUSA');
            focusCtrl("txt7Causa");
            return true;
        }
    }

    if (document.getElementById("chk8Si").checked) {
        if ($('#txt8Meses').val() == '') {
            alert('DEBES AGREGAR MESES');
            focusCtrl("txt8Meses");
            return true;
        }
    }

    if ($('#txtTiempoConocer').val() == '') {
        alert('DEBES AGREGAR TIEMPO DE CONOCER AL SOLICITANTE');
        focusCtrl("txtTiempoConocer");
        return true;
    }

    if ($('#txtCapitalEstimado').val() == '') {
        alert('DEBES AGREGAR CAPITAL ESTIMADO');
        focusCtrl("txtCapitalEstimado");
        return true;
    }

    if ($('#txtRiesgoPeligroso').val() == '') {
        alert('DEBES AGREGAR ALGUN RIESGO DENTRO DE SU OCUPACION');
        focusCtrl("txtRiesgoPeligroso");
        return true;
    }

    if ($('#txtSaludRiesgo').val() == '') {
        alert('DEBES AGREGAR SI CONOCES ALGO SU SALUD O HABITOS');
        focusCtrl("txtSaludRiesgo");
        return true;
    }

    if ($('#txtIngresos').val() == '') {
        alert('DEBES AGREGAR EN CUANTO ESTIMAS SUS INGRESOS');
        focusCtrl("txtIngresos");
        return true;
    }
}


function ValidarUnaCobMarcada() {
    var bdrValidacion = false;

    var ContadorChecados = 0;
    var tbCoberturas = document.getElementById("Coberturas");
    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            if (document.getElementById("chk" + i).checked) {
                ContadorChecados = ContadorChecados + 1;
            }
        }
    }
    if (ContadorChecados == 0) {
        bdrValidacion = true;
    }
    return bdrValidacion;
}

function ValidarVaciosEnSumasConCobMarcadas() {
    var CtrltxtSuma = "";

    var tbCoberturas = document.getElementById("Coberturas");
    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            if (document.getElementById("chk" + i).checked) {
                var CodCob = document.getElementById("chk" + i).value;
                if (document.getElementById("txtSuma" + CodCob).value == "") {
                    CtrltxtSuma = "txtSuma" + CodCob;
                    return CtrltxtSuma;
                }
            }
        }
    }

    return CtrltxtSuma;
}

function armaCadena(oper, ModoCotizacion) {

    Cargando(true);

    var token = document.getElementById("UscAsegCLM_hdnToken").value;
    var agente = selValorCtrl("drpAgente");
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var moneda = selValorCtrl("drpMoneda");
    if (document.getElementById("HiddenRamoRequest").value == "111") {
        var tip_regulariza = document.getElementById("HiddenCrecimiento").value;
        var pct_regulariza = document.getElementById("HiddenCrecimiento").value;
    }
    else {
        var tip_regulariza = selValorCtrl("drpCrecimiento", 0);
        var pct_regulariza = selValorCtrl("drpCrecimiento", 1);
    }
    var deducible = "";

    var comision = selValorCtrl("drpComision");
    var duracion = document.getElementById("hdnPlazo").value;
    var modalidad = document.getElementById("hdnmodalidadul").value;

    var envio = 1; //Agente
    var formaPago = selValorCtrl("drpFormaPago");
    var tipoPago = document.getElementById("drpTipoPago").value;

    var cod_gestor = valorCtrl("UscContCLM_hdnCodEntidad");
    var zona = valorCtrl("UscContCLM_hdnEdo"); //Estado del Contratante
    var localidad = valorCtrl("UscContCLM_hdnPoblacion"); //Poblacion del Contratante

    //-------->C3<--------
    var tipo_seguro = "";
    var tip_seguros = document.getElementsByName("rblTipoSeguro");

    for (i = 0; i < tip_seguros.length; i++) {
        if (tip_seguros[i].checked == true) {
            tipo_seguro = tip_seguros[i].value;
        }
    }

    //Parte para el Envío de la Fecha de Nacimiento.
    var fecNac = "";
    //Si es una marca "C" de contización se debe preguntar si es solo la Cotización Inicial
    //o se trata de una "SOLICITUD" en caso de que no sea "C" es una "P" y deberá enviar la fecha del CLM
    //del Asegurado.
    if (oper == "C") {
        //Si solo se quieren obtener las primas Se obtiene la fecha obtenida a través de la edad.
        //Y si es una "Solicitud" entonces se envía la fecha del CLM.
        if (ModoCotizacion == "PRIMAS") {
            fecNac = document.getElementById("hidFechaNac").value;

            //------>C27<------
            //------>C20<------
            //tipo_seguro = "P";
        }
        else
            fecNac = valorCtrl("UscAsegCLM_lblNacimiento");
    }
    else
        fecNac = valorCtrl("UscAsegCLM_lblNacimiento");

    var fecEfecto = valorCtrl("txtFechaEfecto");
    var fecEfectoMas1Anio = MetodosAjax.sumarUnAnioAFecha(fecEfecto);
    //UL
    var f = new Date();
    var edad = document.getElementById("txtEdad").value;
    var dur = selValorCtrl("drpDuracion");
    var resduracion = "";
    if (modalidad == "11204") {
        resduracion = dur;
    }
    else {
        resduracion = parseFloat(dur) - parseFloat(document.all("txtEdad").value)
    }
    var anio = parseInt(f.getFullYear() + parseFloat(resduracion));
    var fecVcto = f.getDate() + "/" + (f.getMonth() + 1) + "/" + anio;

    //var fecVcto = document.getElementById("hdnFecVcto").value;
    //UL
    var CLM_Cont = valorCtrl("UscContCLM_hdnCLM");
    var CLM_Aseg = valorCtrl("UscAsegCLM_hdnCLM");
    var tip_docum = "CLM";
    var nombre_riesgo = "";

    if (oper == "C") {
        if (ModoCotizacion == "PRIMAS")
            nombre_riesgo = "RIESGO COTIZACION";
        else
            nombre_riesgo = valorCtrl("UscAsegCLM_lblNombre") + " " + valorCtrl("UscAsegCLM_lblApellidoPaterno") + " " + valorCtrl("UscAsegCLM_lblApellidoMaterno");
    }
    else
        nombre_riesgo = valorCtrl("UscAsegCLM_lblNombre") + " " + valorCtrl("UscAsegCLM_lblApellidoPaterno") + " " + valorCtrl("UscAsegCLM_lblApellidoMaterno");

    //Se inicializa la variable sexo como 1 [Masculino]
    var mca_sexo = 1;
    if (document.getElementById("HiddenRamoRequest").value == "112") {
        mca_sexo = selValorCtrl("drpSexo");
    }
    else {
        if (oper == "C") {
            if (ModoCotizacion == "PRIMAS")
                mca_sexo = selValorCtrl("drpSexo");
            else {
                if (manejoLabel("UscAsegCLM_lblSexo") == "Femenino")
                    mca_sexo = 0;
            }
        }
        else {
            if (manejoLabel("UscAsegCLM_lblSexo") == "Femenino")
                mca_sexo = 0;
        }
    }


    var fuma = "";

    fuma = "0";

    var dctoSexo = document.getElementById("HiddenDctoSex").value;
    var dctoAgente = selValorCtrl("drpAgente");
    var dctoFuma = document.getElementById("HiddenDctoFuma").value;
    //MU-2017-064392
    var polizaGrupo = document.getElementById("hdnpolgpo").value;
    var contrato = document.getElementById("hdncontrato").value;
    //MU-2017-064392

    if (oper == "C") {
        if (ModoCotizacion == "PRIMAS")
            CLM_Cont = "PRUEBA";
        else
            CLM_Cont = valorCtrl("UscContCLM_hdnCLM");
    }
    else
        CLM_Cont = valorCtrl("UscContCLM_hdnCLM");

    if (tipoPago == "AG")
        cod_gestor = agente;

    //Esto es solo para que siempre deje Cotizar en caso de que el tipo
    //de Pago sea diferente de "AG" ya que la variable "cod_gestor"
    //al momento de obtener primas no tiene un valor y genera un error.
    if (ModoCotizacion == "PRIMAS") {
        tipoPago = "AG";
        cod_gestor = agente;
    }

    //Esto es para que al Obtener Primas siempre mande los valores correctos
    //en la Prima de cada Cobertura.
    if (ModoCotizacion == "PRIMAS")
        formaPago = 1;

    //C10
    var endosoEdu = "N";
    //C10

    if (oper == "C") {
        var Ocupacion = "";
        var Peso = "";
        var Estatura = "";
    }
    else {
        var Ocupacion = selValorCtrl("drpOcupacion");
        var Peso = valorCtrl("txtPeso");
        var Estatura = valorCtrl("txtEstatura");
    }

    //Validación de Vicente García Sepulveda.
    var codRiesgo = "0";
    var tipRiesgo = "0";

    ///////////////////////////////////
    // Arreglo de datos de la poliza //
    ///////////////////////////////////
    var arrDatosPoliza = new Array();

    var cuadroCom111;
    cuadroCom111 = document.getElementById("HidCuadroCom").value;

    arrDatosPoliza.push("TIP_DURACION=2");          //Unit Linked
    arrDatosPoliza.push("COD_RAMO=" + ramo);
    arrDatosPoliza.push("COD_AGT=" + agente);
    arrDatosPoliza.push("ANIOS_MAX_DURACION=" + resduracion);    //Unit Linked
    arrDatosPoliza.push("COD_ENVIO=" + envio);
    arrDatosPoliza.push("COD_FRACC_PAGO=1");        //Unit Linked
    arrDatosPoliza.push("COD_GESTOR=" + cod_gestor);
    arrDatosPoliza.push("COD_MON=" + selValorCtrl("drpMoneda"));               //Unit Linked
    arrDatosPoliza.push("TIP_GESTOR=" + tipoPago);
    arrDatosPoliza.push("COD_CUADRO_COM=" + cuadroCom111);
    arrDatosPoliza.push("TIP_DOCUM=" + tip_docum);
    arrDatosPoliza.push("COD_DOCUM=" + CLM_Cont);
    arrDatosPoliza.push("TXT_MOTIVO_SPTO=" + oper);
    arrDatosPoliza.push("MCA_IMPRESION=N");
    arrDatosPoliza.push("COD_MODALIDAD=" + modalidad);
    arrDatosPoliza.push("FEC_EFEC_POLIZA=" + fecEfecto);
    arrDatosPoliza.push("FEC_VCTO_POLIZA=" + fecVcto);
    arrDatosPoliza.push("FEC_EFEC_SPTO=" + fecEfecto);
    arrDatosPoliza.push("FEC_VCTO_SPTO=" + fecVcto);
    arrDatosPoliza.push("FEC_EFEC_RIESGO=" + fecEfecto);
    arrDatosPoliza.push("FEC_VCTO_RIESGO=" + fecVcto);
    arrDatosPoliza.push("NOM_RIESGO=" + nombre_riesgo);
    //MU-2017-064392
    if (polizaGrupo != "") {
        arrDatosPoliza.push("NUM_POLIZA_GRUPO=" + polizaGrupo);
        arrDatosPoliza.push("NUM_CONTRATO=" + contrato);
    }
    else {
        arrDatosPoliza.push("NUM_POLIZA_GRUPO=");
        arrDatosPoliza.push("NUM_CONTRATO=");
    }
    //MU-2017-064392

    arrDatosPoliza.push("TIP_REGULARIZA=0");        //Unit Linked
    arrDatosPoliza.push("PCT_REGULARIZA=0");        //Unit Linked

    var indAgt = 2;
    for (i = 2; i <= 5; i++) {
        var index = ((parseInt(i) < 10) ? "0" + i : i);
        if (document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave").value != "") {
            var codAgt = document.getElementById("dtgReferencias_ctl" + index + "_txtgrdClave").value
            var pctAgt = document.getElementById("dtgReferencias_ctl" + index + "_txtgrdPorcentaje").value
            if (i == 2)
                arrDatosPoliza.push("PCT_AGT=" + pctAgt);
            else {
                arrDatosPoliza.push("COD_AGT" + indAgt + "=" + codAgt);
                arrDatosPoliza.push("PCT_AGT" + indAgt + "=" + pctAgt);
                indAgt++;
            }
        }
    }
    //Unit Linked Datos Complementarios
    ///////////////////////////////
    // Arreglo de datos p2000025 //
    ///////////////////////////////
    var arrDatosComplementarios = new Array();

    var cod_listaFondos = "600";
    var cod_listaOtros = "601";
    var cf = 0;
    var cp = 0;
    var ocu = 0;
    var totaux = document.all("numfondos").value;

    //Asigna el consecutivo para los nodos de Fondo y Porcentaje
    for (var aux = 0; aux < totaux; aux++) {
        cp = cp + 1;

        if (document.all("txtpctfondo_" + cp).value != "0") {
            ocu = ocu + 1;
            //arrDatosComplementarios.push("COD_CAMPO=CODIGO_FUNDO=|NUM_RIESGO=1|NUM_PERIODO=1|VAL_CAMPO=" + document.all("fondo_" + cp).value + "|NUM_OCURRENCIA=" + ocu.toString() + "|TXT_CAMPO=|NUM_SECU=1|COD_LISTA=" + cod_listaFondos);
            arrDatosComplementarios.push("COD_CAMPO=CODIGO_FUNDO=|NUM_RIESGO=1|NUM_PERIODO=1|VAL_CAMPO=" + document.all("idfondo_" + cp).value + "|NUM_OCURRENCIA=" + ocu.toString() + "|TXT_CAMPO=|NUM_SECU=1|COD_LISTA=" + cod_listaFondos);
            cf++;
            if ((document.all("txtpctfondo_" + cp).value != "" || document.all("txtpctfondo_" + cp).value != null)) {
                arrDatosComplementarios.push("COD_CAMPO=PERCENTAGEM_FUNDO|NUM_RIESGO=1|NUM_PERIODO=1|VAL_CAMPO=" + document.all("txtpctfondo_" + cp).value + "|NUM_OCURRENCIA=" + ocu.toString() + "|TXT_CAMPO=|NUM_SECU=2|COD_LISTA=" + cod_listaFondos);
                cf++;
            }
        }
    }
    var total_fondos_contratados = cf / 2;

    //Prima Inicial
    arrDatosComplementarios.push("COD_CAMPO=TIP_PRIMA|NUM_RIESGO=1|NUM_PERIODO=1|VAL_CAMPO=UI|NUM_OCURRENCIA=1|TXT_CAMPO=UNICA INICIAL|NUM_SECU=1|COD_LISTA=" + cod_listaOtros);
    arrDatosComplementarios.push("COD_CAMPO=FORMA_PAGO|NUM_RIESGO=1|NUM_PERIODO=1|VAL_CAMPO=1|TXT_CAMPO=1|NUM_OCURRENCIA=1|NUM_SECU=2|COD_LISTA=" + cod_listaOtros);  //Contado
    arrDatosComplementarios.push("COD_CAMPO=IMP_PREMIO_VIDA|NUM_RIESGO=1|NUM_PERIODO=1|VAL_CAMPO=" + document.all("txtMontoIni").value + "|NUM_OCURRENCIA=1|TXT_CAMPO=|NUM_SECU=4|COD_LISTA=" + cod_listaOtros);

    if (document.all("txtMontoPro").value == "0" || document.all("txtMontoPro").value == "") {
    }
    else {
        //Primas Adicionales
        arrDatosComplementarios.push("COD_CAMPO=TIP_PRIMA|NUM_RIESGO=1|NUM_PERIODO=1|VAL_CAMPO=AD|NUM_OCURRENCIA=2|TXT_CAMPO=ADICIONALES|NUM_SECU=1|COD_LISTA=" + cod_listaOtros);
        arrDatosComplementarios.push("COD_CAMPO=FORMA_PAGO_AD|NUM_RIESGO=1|NUM_PERIODO=1|VAL_CAMPO=" + selValorCtrl("drpPeriodos") + "|NUM_OCURRENCIA=2|TXT_CAMPO=1|NUM_SECU=3|COD_LISTA=" + cod_listaOtros);
        arrDatosComplementarios.push("COD_CAMPO=IMP_PREMIO_VIDA_AD|NUM_RIESGO=1|NUM_PERIODO=1|VAL_CAMPO=" + document.all("txtMontoPro").value + "|NUM_OCURRENCIA=2|TXT_CAMPO=|NUM_SECU=5|COD_LISTA=" + cod_listaOtros);
        //Fechas Primas Adicionales
        var diacobro = new Date;
        arrDatosComplementarios.push("COD_CAMPO=FEC_EFEC_PRIMA_ADI|NUM_RIESGO=1|NUM_PERIODO=1|VAL_CAMPO=" + diacobro.getDate() + "|NUM_OCURRENCIA=2|TXT_CAMPO=|NUM_SECU=9|COD_LISTA=" + cod_listaOtros);
        //Validar Fecha de periodicidad
        var periodo = selValorCtrl("drpPeriodos");
        var fechacobro = MetodosAjax.getfecaportacion(periodo, diacobro.getDate());
        arrDatosComplementarios.push("COD_CAMPO=FEC_EFEC_PRIMA_AD|NUM_RIESGO=1|NUM_PERIODO=1|VAL_CAMPO=" + fechacobro.value + "|TXT_CAMPO=|NUM_SECU=7|NUM_OCURRENCIA=2|COD_LISTA=" + cod_listaOtros);

    }

    ////////////////////////////////
    // Arreglo de datos variables //
    ////////////////////////////////
    var arrDatosVariables = new Array();
    var secu = 1;


    arrDatosVariables.push("COD_CAMPO=ID_PROMOTOR|VAL_CAMPO=" + agente + "|VAL_COR_CAMPO=" + agente + "|TIP_NIVEL=1|NUM_RIESGO=0|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo);   //Unit Linked
    arrDatosVariables.push("COD_CAMPO=TIPO_SEGURO|VAL_CAMPO=P|VAL_COR_CAMPO=P|TIP_NIVEL=1|NUM_RIESGO=0|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo); //Unit Linked
    arrDatosVariables.push("COD_CAMPO=TIP_COMISION|VAL_CAMPO=1|VAL_COR_CAMPO=1|TIP_NIVEL=1|NUM_RIESGO=0|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=TIP_IMPRESION|VAL_CAMPO=N|VAL_COR_CAMPO=N|TIP_NIVEL=1|NUM_RIESGO=0|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo);   //Unit Linked
    arrDatosVariables.push("COD_CAMPO=TIP_DEDUCIBLE|VAL_CAMPO=1|VAL_COR_CAMPO=1|TIP_NIVEL=1|NUM_RIESGO=0|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=COD_MODALIDAD|VAL_CAMPO=" + modalidad + "|VAL_COR_CAMPO=" + modalidad + "|TIP_NIVEL=2|NUM_RIESGO=1|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=VAL_FOLIO_SOLICITUD|VAL_CAMPO=1|VAL_COR_CAMPO=1|TIP_NIVEL=1|NUM_RIESGO=0|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo); //Unit Linked
    arrDatosVariables.push("COD_CAMPO=FEC_NACIMIENTO|VAL_CAMPO=" + fecNac.replace(/\/|\,/g, "") + "|VAL_COR_CAMPO=" + fecNac.replace(/\/|\,/g, "") + "|TIP_NIVEL=2|NUM_RIESGO=1|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=MCA_SEXO|VAL_CAMPO=" + mca_sexo + "|VAL_COR_CAMPO=" + mca_sexo + "|TIP_NIVEL=2|NUM_RIESGO=1|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=DTO_AGENTE_DIR|VAL_CAMPO=" + agente + "|VAL_COR_CAMPO=" + agente + "|TIP_NIVEL=3|NUM_RIESGO=1|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=ANIOS_DURACION_POLIZA|VAL_CAMPO=" + resduracion + "|VAL_COR_CAMPO=" + resduracion + "|TIP_NIVEL=1|NUM_RIESGO=1|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo);
    arrDatosVariables.push("COD_CAMPO=TIP_PERFIL_INV|VAL_CAMPO=" + selValorCtrl("drpPerfil") + "|VAL_COR_CAMPO=" + selValorCtrl("drpPerfil") + "|TIP_NIVEL=2|NUM_RIESGO=1|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo);  //Unit Linked
    arrDatosVariables.push("COD_CAMPO=NUM_FUNDOS|VAL_CAMPO=" + total_fondos_contratados + "|VAL_COR_CAMPO=" + total_fondos_contratados + "|TIP_NIVEL=2|NUM_RIESGO=1|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo);  //Unit Linked
    arrDatosVariables.push("COD_CAMPO=TIP_PRIMAS|VAL_CAMPO=2|VAL_COR_CAMPO=2|TIP_NIVEL=2|NUM_RIESGO=1|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo); //Verificar si hay que hacer validaciones en base a si existen primas adicionales    //Unit Linked
    arrDatosVariables.push("COD_CAMPO=PRIMA_COB_1000|VAL_CAMPO=" + formatNumber(document.all("txtPrima1000").value) + "|VAL_COR_CAMPO=" + formatNumber(document.all("txtPrima1000").value) + "|TIP_NIVEL=2|NUM_RIESGO=1|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo);
    var tablacobs = document.getElementById('Coberturas');
    for (i = 1; i < tablacobs.children[0].rows.length; i++) {
        if (tablacobs.children[0].rows[i].childNodes[0].firstChild.checked == true) {
            switch (tablacobs.children[0].rows[i].childNodes[0].firstChild.value) {
                case "1004":
                    arrDatosVariables.push("COD_CAMPO=PRIMA_COB_1004|VAL_CAMPO=" + formatNumber(document.all("txtPrima1004").value) + "|VAL_COR_CAMPO=" + formatNumber(document.all("txtPrima1004").value) + "|TIP_NIVEL=2|NUM_RIESGO=1|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo);
                    break;
                case "1095":
                    arrDatosVariables.push("COD_CAMPO=PRIMA_COB_1095|VAL_CAMPO=" + formatNumber(document.all("txtPrima1095").value) + "|VAL_COR_CAMPO=" + formatNumber(document.all("txtPrima1095").value) + "|TIP_NIVEL=2|NUM_RIESGO=1|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo);
                    break;
                case "1096":
                    arrDatosVariables.push("COD_CAMPO=PRIMA_COB_1096|VAL_CAMPO=" + formatNumber(document.all("txtPrima1096").value) + "|VAL_COR_CAMPO=" + formatNumber(document.all("txtPrima1095").value) + "|TIP_NIVEL=2|NUM_RIESGO=1|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo);
                    break;
                case "1003":
                    arrDatosVariables.push("COD_CAMPO=PRIMA_COB_1003|VAL_CAMPO=" + formatNumber(document.all("txtPrima1003").value) + "|VAL_COR_CAMPO=" + formatNumber(document.all("txtPrima1003").value) + "|TIP_NIVEL=2|NUM_RIESGO=1|COD_CIA=1|NUM_POLIZA=|NUM_APLI=0|NUM_SPTO_APLI=0|NUM_PERIODO=1|MCA_BAJA_RIESGO=N|MCA_VIGENTE=S|MCA_VIGENTE_APLI=S|NUM_SPTO=0|COD_RAMO=" + ramo);
                    break;
            }
        }
    }

    var suma_aseg0 = "";

    // Arreglo con datos de las coberturas
    var arrDatosCoberturas = new Array();
    var tbCoberturas = document.getElementById("Coberturas");
    var cadena;
    var ExisteBIT = false;
    var EstaMarcadaBIT = false;
    var ContSumas = 0;

    var Cod_CobBit = "";

    secu = 1

    var mcaSF = "N";
    var porcentaje = "";


    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        cadena = "";
        if (document.getElementById("chk" + i) != null) {
            if (document.getElementById("chk" + i).value == "1095") {
                ExisteBIT = true;
                Cod_CobBit = document.getElementById("chk" + i).value;
            } 

            if (document.getElementById("chk" + i).checked) {
                if (ExisteBIT) {
                    if (document.getElementById("chk" + i).value == "1095" && document.getElementById("chk" + i).checked)
                    EstaMarcadaBIT = true;
                }

                var cod_cob = document.getElementById("chk" + i).value;
                var sumaAseg = document.getElementById("txtSuma" + cod_cob).value;

                /////Parte para suma_aseg0
                if (ContSumas == 0) {
                    suma_aseg0 = sumaAseg

                    ContSumas++;
                }
                //////////////////////////
                if (isNaN(sumaAseg)) {
                    sumaAseg = "0";
                }
                //Caso especial para la Cobertura [1095] BIT si la Cobertura está Marcada, entonces no debe
    	        //de Enviarse.
                if (cod_cob != "1095") {
                    cadena = "";
                    cadena += "COD_COB=" + cod_cob;
                    cadena += "|SUMA_ASEG=" + sumaAseg;
                    cadena += "|SUMA_ASEG_SPTO=" + sumaAseg;
                    cadena += "|NUM_SECU=" + secu++;
                    cadena += "|COD_RAMO=" + ramo;
                    cadena += "|MCA_BAJA_COB=N";
                    arrDatosCoberturas.push(cadena);
                }
            }
        }

    }

    //Cuando la cobertura [1095] BIT exista pero no se haya marcado deberá enviarse con suma Asegurada igual a Cero.
    if (ExisteBIT) {
        if (!EstaMarcadaBIT) {
            var codCobBit = Cod_CobBit;
            cadena = "";
            cadena += "COD_COB=" + codCobBit;
            cadena += "|SUMA_ASEG=0";
            cadena += "|SUMA_ASEG_SPTO=0";
            cadena += "|NUM_SECU=" + secu++;
            cadena += "|COD_RAMO=" + ramo;
            cadena += "|MCA_BAJA_COB=N";
            arrDatosCoberturas.push(cadena);
        }
    }

    arrDatosPoliza.push("MCA_SF=" + mcaSF);

    //////////////////////////////
    // Arreglo de datos titular //
    //////////////////////////////
    var arrDatosTitular = new Array();
    if (oper == "C") {
        if (ModoCotizacion == "PRIMAS")
            arrDatosTitular.push("COD_DOCUM=PRUEBA");
        else
            arrDatosTitular.push("COD_DOCUM=" + CLM_Aseg);
    }
    else
        arrDatosTitular.push("COD_DOCUM=" + CLM_Aseg);
    arrDatosTitular.push("TIP_DOCUM=CLM");
    arrDatosTitular.push("TIP_BENEF=2");
    arrDatosTitular.push("NUM_SECU=1");
    arrDatosTitular.push("FEC_NACIMIENTO=" + fecNac);

    //////////////////////////////////
    // Arreglo de datos contratante //
    //////////////////////////////////

    //Datos que son proporcionados por el Contratante de la persona que desea Asegurar.
    var arrDatosContratante = new Array();
    if (oper == "C") {
        arrDatosContratante.push("FEC_NACIMIENTO=" + fecNac);
        arrDatosContratante.push("MCA_SEXO=" + mca_sexo);
        arrDatosContratante.push("MCA_FUMA=" + fuma);
    }

    ///////////////////////////////////
    // Arreglo de datos beneficiario //
    ///////////////////////////////////
    var arrDatosBenef = new Array();
    if (ModoCotizacion == "SOLICITUD")
    //if(oper == "P")
    {
        var tblBenef = MetodosAjax.generaCodDocumBENEF();
        if (tblBenef.error == null) {
            if (tblBenef != null && tblBenef.value != null && tblBenef.value.Rows.length != 0) {
                secu = 0;
                var prim = 0;
                for (var i = 0; i < tblBenef.value.Rows.length; i++) {
                    secu++;
                    var tip_benef = tblBenef.value.Rows[i].tip_benef;
                    if (tip_benef == 6) {
                        prim++;
                        secu = 0;
                    }

                    cadena = "";
                    cadena += "TIP_DOCUM=" + tblBenef.value.Rows[i].tip_docum;
                    cadena += "|COD_DOCUM=" + tblBenef.value.Rows[i].cod_docum;
                    cadena += "|PCT_PARTICIPACION=" + tblBenef.value.Rows[i].porcentaje;
                    cadena += "|TIP_BENEF=" + tip_benef;

                    if (tip_benef == 6)
                        cadena += "|NUM_SECU=" + prim;
                    else cadena += "|NUM_SECU=" + secu;

                    arrDatosBenef[arrDatosBenef.length] = cadena;
                }
            }
        }
        else alert(tblBenef.error.description);
    }

    var arrDatosBanco = new Array();

    if (ModoCotizacion == "SOLICITUD") {
        MetodosAjax.setSession("COD_AGT", agente);
        MetodosAjax.setSession("CodigoMoneda", moneda);
        MetodosAjax.setSession("EdadTitular", manejoLabel("UscAsegCLM_lblEdad"));
        MetodosAjax.setSession("SumaAsegurada", suma_aseg0);
        MetodosAjax.setSession("COD_RAMO", ramo);
        MetodosAjax.setSession("COD_DOCUMT", CLM_Aseg);
        MetodosAjax.setSession("NOM_TERCEROT", valorCtrl("UscAsegCLM_lblNombre"));
        MetodosAjax.setSession("COD_ESTADOT", zona);
    }

    if ($('#UscContCLM_rdoFacturarSi').is(":checked")) { //Facturacion 4.0
        arrDatosPoliza[arrDatosPoliza.length] = "RegFiscal=" + document.all["UscContCLM_hdnRegFiscal"].value;
        arrDatosPoliza[arrDatosPoliza.length] = "CodPostalFiscal=" + document.all["UscContCLM_hdnCodPostalFiscal"].value;
        arrDatosPoliza[arrDatosPoliza.length] = "RegSocietario=" + document.all["UscContCLM_hdnRegSocietario"].value;
        arrDatosPoliza[arrDatosPoliza.length] = "RfcStr=" + document.getElementById('UscContCLM_lblRFC').textContent;
    }
    if (oper == "C") {
        if (ModoCotizacion == "PRIMAS")
            MetodosAjax.getCotizacionUL(oper, arrDatosPoliza, arrDatosVariables, arrDatosCoberturas, arrDatosContratante, arrDatosTitular, arrDatosBenef, arrDatosBanco, arrDatosComplementarios, token, getCot_CallBack);
        else {
            MetodosAjax.getSolicitudUL(oper, arrDatosPoliza, arrDatosVariables, arrDatosCoberturas, arrDatosContratante, arrDatosTitular, arrDatosBenef, arrDatosBanco, arrDatosComplementarios, token, getSolicitud_CallBack);
        }
    }
    else {
        MetodosAjax.getEmisionUL(oper, arrDatosPoliza, arrDatosVariables, arrDatosCoberturas, arrDatosContratante, arrDatosTitular, arrDatosBenef, arrDatosBanco, arrDatosComplementarios, token, 'N', getEmision_CallBack);
        ActualizarEstadoRAM();
    }

}

function getCot_CallBack(cotiza) {
    //document.getElementById("divPrimas").innerHTML = "";

    if (cotiza.error == null) {
        if (cotiza != null && cotiza.value != null && cotiza.value.Tables.length != 0) {

            //C1 Se evalua la prima Minima en base de la prima neta 
            if (cotiza.value.Tables[0].Rows[0].PRIMAS = ! "") {

                document.getElementById('UscContCLM_hdnNumCotizacion').value = cotiza.value.Tables[4].Rows[0].COTIZACION;
                //Unit
                var distri_fondo = MetodosAjax.getDistFondos(document.getElementById('UscContCLM_hdnNumCotizacion').value);
                var tabla = document.getElementById("Fondos");
                var fond;
                var porcentaje;
                for (i = 1; i < tabla.children[0].rows.length - 1; i++) {
                    fond = tabla.children[0].rows[i].childNodes[3].children[0].id;
                    fond = fond.replace("txtdistini_", "");
                    porcentaje = tabla.children[0].rows[i].childNodes[2].children[0].id;

                    if (document.getElementById(porcentaje).value != "0") {
                        for (j = 0; j < distri_fondo.value.Rows.length; j++) {
                            if (fond == distri_fondo.value.Rows[j].CODIGO_FONDO) {
                                tabla.children[0].rows[i].childNodes[3].children[0].value = formatCurrency(distri_fondo.value.Rows[j].DISTRIBUCION_INICIAL);
                            }
                        }
                    }
                    else {
                        tabla.children[0].rows[i].childNodes[3].children[0].value = "0";
                    }
                }

                var deducciones = getdeducciones(document.getElementById('UscContCLM_hdnNumCotizacion').value);

                //C2
                validaPoliticaLavadoDeDinero(cotiza.value.Tables[0].Rows[0].PRIMAS);
                habilitarCtrl("btnCotiza", false);
                habilitarCtrl("btnPrimas", false);
                habilitarCtrl("drpPeriodos", false);
                habilitarCtrl("txtMontoIni", false);
                habilitarCtrl("txtMontoPro", false);
				habilitarCtrl("btnlimpiaprim", false);
                obtienebeneficiarios();
            }
            else
                habilitarCtrl("btnEmite", false);				
        }
    }
    else {
        //-----C23------
        if (cotiza.error.description.indexOf("RANGO NO VALIDO, MAXIMO") != -1) {
            if (cotiza.error.description.indexOf("RANGO NO VALIDO, MAXIMO POR DEP.") != -1) {
                alert(cotiza.error.description);
            }
            else
                alert("EL MONTO MINIMO DE SUMA ASEGURADA ES DE 150,000 DLLS.");
        }
        else
            alert(cotiza.error.description);
    }
    Cargando(false);
        
    AjustarFrame();
    focusCtrl("UscContCLM_txtRFC");
}

//C2
/// <summary>
///     Muestra el mensaje según la pólitica lavado de dinero
/// </summary

function validaPoliticaLavadoDeDinero(prima) {
    if (document.getElementById("rbtnListPolizaContrato_0").checked) {
        var Moneda = selValorCtrl("drpMoneda");
        var FormaPago = selValorCtrl("drpFormaPago");
        var ramo = document.getElementById("HiddenRamoRequest").value;
        var modalidad = document.getElementById("HiddenModalidad").value;
        var contrato = getNumContrato();

        var valPolitica = MetodosAjax.validaPoliticaLavadoDeDinero("2", "1", ramo, modalidad, contrato, Moneda, prima);

        if (valPolitica.error == null) {
            if (valPolitica != null && valPolitica.value != null) {
                var Mensaje = valPolitica.value.p_mensaje;
                alert(Mensaje);
                return true;
            }
        }
        else {
            return false;
        }
    }
    else
        return true;
}

function validaPrimaMinima(prima) {
    if (document.getElementById("rbtnListPolizaContrato_0").checked) {
        var Moneda = selValorCtrl("drpMoneda");
        var FormaPago = selValorCtrl("drpFormaPago");

        //-----------------> C12 <----------------
        var edad = document.getElementById("txtEdad").value;
        var ramo = document.getElementById("HiddenRamoRequest").value;
        var modalidad = document.getElementById("HiddenModalidad").value;
        var contrato = getNumContrato();

        var valPrima = MetodosAjax.validaPrimaMinima(prima, Moneda, FormaPago, "2", "1", ramo, modalidad, contrato);
        if (valPrima.error == null) {
            if (valPrima != null && valPrima.value != null) {
                var MarcaValidacion = valPrima.value.p_mca_valido;
                var Mensaje = valPrima.value.p_error;
                if (MarcaValidacion == "S")
                    return true;
                else {
                    alert(Mensaje);
                    return false;
                }
            }
        }
        else {
            alert(valPrima.error.description);
            return false;
        }
    }
    else
        return true;

}

function getSolicitud_CallBack(cotiza) {
    document.getElementById("HiddenFolioRAM").value = "";
    //document.getElementById("HiddenIDSistemaRAM").value = "";
    if (cotiza.error == null) {
        if (cotiza != null && cotiza.value != null && cotiza.value.Tables.length != 0) {
            var arrFolioRAM = new Array();
            arrFolioRAM = cotiza.value.Tables[5].Rows[0].FOLIO_RAM.split('|');
            var FolioRAM = arrFolioRAM[0];
            var IdSistemaRAM = arrFolioRAM[1];
            var Mensaje = "SU N\u00daMERO DE SOLICITUD ES: " + cotiza.value.Tables[4].Rows[0].COTIZACION + " Y EL FOLIO RAM ES : " + FolioRAM;
            alert(Mensaje);

            //agregar la ram
            MetodosAjax.AgregarDictamenMedicoDocumentumARam(FolioRAM, cotiza.value.Tables[4].Rows[0].COTIZACION, IdSistemaRAM);

            //------------------> C15 <------------ documentum folio ram
            var documentos = document.getElementById("grdAdjuntarArchivo");
            var archivos = "";

            if (documentos != null) {
                for (var i = 1; i < documentos.rows.length; i++) {
                    archivos = archivos + documentos.rows[i].cells[0].innerHTML + ",";
                }
            }

            MetodosAjax.AgregarFolioDocumentum(archivos, FolioRAM, cotiza.value.Tables[4].Rows[0].COTIZACION, IdSistemaRAM);
            //--------------------

            habilitarCtrl("btnEmite", false);
            habilitarCtrl("btnModDatos", false);
            document.getElementById("HiddenFolioRAM").value = FolioRAM;
            document.getElementById("HiddenIDSistemaRAM").value = IdSistemaRAM;
            document.getElementById("lblEncPoliza").innerText = "Solicitud"//
            document.getElementById("lblPolizaSoli").innerText = "Su Número de Solicitud es:"
            document.getElementById("lblNoPoliza").innerText = cotiza.value.Tables[4].Rows[0].COTIZACION;
            document.getElementById("HiddenNoSolPol").innerText = cotiza.value.Tables[4].Rows[0].COTIZACION;

            // <--- C8 --->

            if (document.getElementById("rbtnListPolizaContrato_0").checked)
                habilitarCtrl("btnImprimeSolicitud", true);

            habilitarCtrl("btnImprimePoliza", false);
            habilitarCtrl("btnImprimeSolicitud", false);
            habilitarCtrl("btnNuevaSolicitud", true);
            // <---------->

            var Asunto = "SOLICITUD " + document.getElementById("lblNoPoliza").innerText;
            var EmailTo = document.getElementById("HiddenEmailAgente").value;

            //--->C5<---
            var funcionEmail = "EnviarCorreoAAgente('" + Asunto + "','" + EmailTo + "');";
            eval(funcionEmail);

            //ToDo: aqui va la parte de la solicitud(dictamen)

            setRespuestasCuestionario();
            var cuestionarioRespuestas = document.getElementById("HiddenRespuestasCuestionario").value;
            var hiddenNoSolPol = document.getElementById("HiddenNoSolPol").value;
            //HHAC 20/01/2015 se comenta para que no adjunte el cuestionario
            //MetodosAjax.AnexarDocRamC(cuestionarioRespuestas, hiddenNoSolPol, IdSistemaRAM);
        }
    }
    else alert(cotiza.error.description);
    //alert("No se ha realizado ningun cargo a su tarjeta.");
    Cargando(false);
}

function getEmision_CallBack(poliza) {
    //AEP BWMEILL. Millón Vida Fase 2. Para dejar al página cargando mientras procesa la información
    Cargando(true);

    if (poliza.error == null) {
        if (poliza != null && poliza.value != null) {
            var str = poliza.value;
            var n = str.split("|");

            //var arrEmision = new Array();
            var Poliza = n[0];
            var FolioRAM = n[1];
            var IdSistemaRAM = n[2];
            var ramo = document.getElementById("HiddenRamoRequest").value;
            var strControles = n[3];
            var strUrlExpCli = n[4];
            var strMensajeControles = "";

            try {
                var arrControles = strControles.split(",");


                if (arrControles.length > 0) {
                    if (arrControles[0] != "") {
                        strMensajeControles = "SE HA EMITIDO LA PÓLIZA " + Poliza + " CON CONTROLES TÉCNICOS RELACIONADOS A LA PREVENCIÓN DE LAVADO DE DINERO: <br><br>";
                    }
                }


                for (i = 0; i < arrControles.length; i++) {
                    if (arrControles[i] == "9002") {
                        strMensajeControles = strMensajeControles + "- ESTIMADO ALIADO, DETECTAMOS QUE EL EXPEDIENTE DE CLIENTE TIENE INFORMACIÓN DE DATOS O DOCUMENTOS FALTANTES, POR FAVOR ES NECESARIO VERIFICAR Y COMPLETAR LA INFORMACIÓN DE ACUERDO CON EL RÉGIMEN DE IDENTIFICACIÓN (9002). <br>";
                    }
                    else if (arrControles[i] == "9003") {
                        strMensajeControles = strMensajeControles + "- ESTIMADO ALIADO, ES NECESARIO PROPORCIONAR CUESTIONARIO KYC Y CUESTIONARIO(S) ADICIONAL(ES) (9003). <br>";
                    }
                    else if (arrControles[i] == "9004") {
                        strMensajeControles = strMensajeControles + "- ESTIMADO ALIADO, MAPFRE MÉXICO AGRADECE SU PROPUESTA DE ASEGURAMIENTO, LA CUAL ESTÁ SIENDO ANALIZADA, EN BREVE NOS CONTACTAREMOS CON USTED (9004). <br>";
                    }
                    else if (arrControles[i] == "9005") {
                        strMensajeControles = strMensajeControles + "- ESTIMADO ALIADO, ES NECESARIO PROPORCIONAR CUESTIONARIO KYC Y CUESTIONARIO(S) DE PERSONA POLITICAMENTE EXPUESTA Y ASIMILADOS (9005). <br>";
                    }
                }

                if (strMensajeControles != "") {
                    strMensajeControles = strMensajeControles + "<br> PARA COMPLEMENTAR EL EXPEDIENTE DEL CLIENTE ES NECESARIO QUE VAYA AL SIGUIENTE MÓDULO EN EL MENÚ DE ZONALIADOS: <br>";
                    strMensajeControles = strMensajeControles + "<a href='" + strUrlExpCli + Poliza + "' target='_blank'>ZONA DE TRABAJO|Cliente MAPFRE|Expediente Cliente</a> <br> O DA CLIC EN EL BOTÓN: IR A PANTALLA DE EXPEDIENTE CLIENTE";

                    $("#butAbrirExpediente").attr("onclick", "window.open('" + strUrlExpCli + Poliza + "');");
                    $("#lblMensajePLD").html("SU NÚMERO DE PÓLIZA ES: " + Poliza + " Y EL FOLIO RAM ES : " + FolioRAM + "<br><br>" + strMensajeControles);
                    $('#modalPLD').modal('show');
                }
            }
            catch (err) {
            }


            //------------------> C15 <------------ documentum folio ram
            //var documentos = document.getElementById("grdAdjuntarArchivo");
            document.getElementById("HiddenIDSistemaRAM").value = IdSistemaRAM;
            //--------------------

            document.getElementById("HiddenFolioRAM").value = FolioRAM;
            document.getElementById("HiddenNoSolPol").innerText = Poliza;
            document.getElementById("HiddenNoSolPol").value = Poliza;//C29

            //agregar la poliza a ram
            MetodosAjax.AgregarPolizaDocumentumARam(Poliza, '', 'n', FolioRAM, Poliza, IdSistemaRAM);

            //setRespuestasCuestionario();
            //var cuestionarioRespuestas = document.getElementById("HiddenRespuestasCuestionario").value;
            var hiddenNoSolPol = document.getElementById("HiddenNoSolPol").value;
            //MetodosAjax.AgregarSolicitud(Poliza, relacion, FolioRAM,IdSistemaRAM);

            //AEP BWMEILL. Para eliminar pago en Domiciliación Bancaria. Millón Vida Fase2
            if (tipcobro == "L") {
                if (document.getElementById("hdnmodalidadul").value != "11206") {
                    var pago = MetodosAjax.cobranza(document.getElementById("HiddenNoSolPol").value, selIndex("ddlBanco"),
                        document.getElementById("txtNTitular").value, document.getElementById("txtAPTitular").value,
                        document.getElementById("txtAMTitular").value, selIndex("ddlAnioTarjeta"), selIndex("ddlMesTarjeta"),
                        document.getElementById("txtNumTarjeta").value, document.getElementById("txtCodTarjeta").value,
                        selIndex("ddlTipoTarjeta"), "UL");

                    if (pago.value.split('|')[0] == "1") {
                        alert('**********************\nPoliza Cobrada: ' + document.getElementById("HiddenNoSolPol").value + ' Autorizacion: ' + pago.value.split('|')[1] + '\n**********************\n');
                        document.getElementById("lblNoPoliza").innerText = Poliza;
                        EmisionFinal();
                    }
                    else {
                        alert('Estimado(a) Aliado(a):\nLa emisi\u00f3n de su p\u00f3liza no pudo ser realizada debido a que el  cobro no fue satisfactorio. Favor de verificar los datos bancarios ingresados.\n**********************\n Error en Cobro : ' + pago.value.split('|')[1] + '\n**********************\n');
                    }
                }
                else {
                    MM_ImprimeContrato(Poliza)
                }
            }
            else {
                if (document.getElementById("hdnmodalidadul").value != "11206") {
                    var prima = document.getElementById("lblPrimaTotal").innerText;
                    var Poliza = document.getElementById("HiddenNoSolPol").value;
                    var urlPD = document.getElementById("hdnUrlPagoDo").value;
                    alert('Estimado(a) Aliado(a):\nPara que la p\u00f3liza quede habilitada se deber\u00e1 realizar el dep\u00f3sito por la prima ' + prima.toString() + ', antes de 48 hrs. ');
                    var url = urlPD.toString() + "?tipo=LC&lcpoliza=" + Poliza + "&lccodsistema=01&lcurl=prueba.aspx&lcagentecentel=99998&Terminal=SEGA&terminalFPB=0101SEGA&bandera=1";

                    var wnventanacob = window.open(url, "_blank", "width=850px,height=800px, menubar=off, scrollbars=yes, resizable=no, top=0, left=0");
                    EmisionFinal();
                }
                else {
                    MM_ImprimeContrato(Poliza);
                }
            }
        }
    }
    else alert(poliza.error.description);
    Cargando(false);
}

function ValidarEmision() {

    if (!validarSumaAseguradaBasica()) {
        return "C";
    }

    if (!validarOcupacion()) {
        return "C";
    }
    if (!validarIMC()) {
        return "C";
    }
    if (!validarCuestionario()) {
        return "C";
    }

    if (document.getElementById("divCuestionarioMillon").innerHTML != "") {
        /*Validacion nuevas RAM*/
        if (validarRAM()) {
            return "C";
        }
    }
	
	//Validacion Funcion Publica
    if (validarFuncionPublica()) {
        return "C";
    }
	
    return "P";
}


function validarFuncionPublica() {
    var funcionPublica = document.getElementById('chkSiCargoP').checked;
    if (funcionPublica) {
        return true;
    }
}


//Validaciones nuevas suscripcion
function validarRAM() {
    //Validacion Función Pública
    var funcionPublica = document.getElementById('chkSiCargoP').checked;
    if (funcionPublica) {
        return true;
    }
    //Validaciones Maq, Herra, Sust, Vehi
    var maq = $('#txtTipoMaquinas').val();
    if ((maq != 'SELECCIONE')) {
        if (maq != 'NINGUNA DE LAS ANTERIORES') {
            return true;
        }

    }
    //Validaciones otra ocupacion
    var ocupacion = document.getElementById('chkSiOtraOcupacion').checked;
    if (ocupacion) {
        return true;
    }
    //Validaciones aeronaves particulares
    var aeronaves = document.getElementById('chkSiAParticular').checked;
    if (aeronaves) {
        return true;
    }
    //Validaciones motocicleta
    var moto = document.getElementById('chkSiMotocicleta').checked;
    if (moto) {
        return true;
    }
    //Validaciones trabaja altura
    var altura = document.getElementById('chkSiAlturas').checked;
    if (altura) {
        return true;
    }
    //Validaciones lugar de trabajo
    var lugarTrabajo = $('#txtLugarTrabajo').val();
    if (lugarTrabajo == 'TALLER' || lugarTrabajo == 'FABRICA' || lugarTrabajo == 'OTRO') {
            return true;        
    }
    //Validaciones practica deporte o aficion
    var deporte = $('#txtDeporte').val();
    if (deporte != 'NINGUNO') {
        return true;
    }
    //Validaciones bebida alcoholicas
    var cantidad = $('#txtCantBebida').val();
    var frecuencia = $('#txtFrecuenciaBebida').val();
    if (frecuencia == 'DIARIA') {
        if (parseInt(cantidad) >= 8) {
            return true;
        }

    } else if (frecuencia == "SEMANAL") {
        if (parseInt(cantidad) >= 56) {
            return true;
        }
    } else if (frecuencia == "MENSUAL") {
        if (parseInt(cantidad) >= 240) {
            return true;
        }
    }
    //Validaciones cantidad fumar
    var cantidadFumar = $('#txtCantidadFumar').val();
    if (cantidadFumar != "SELECCIONE") {
        if (parseInt(cantidadFumar) > 20) {
            return true;
        }
    }
    //Validaciones drogas
    var drogas = document.getElementById('chkSiDroga').checked;
    if (drogas) {
        return true;
    }
    //Validaciones pregunta 1
    var pregunta1 = document.getElementById('chk1Si').checked;
    if (pregunta1) {
        return true;
    }
    //Validaciones pregunta 3
    var pregunta3 = document.getElementById('chk3Si').checked;
    if (pregunta3) {
        return true;
    }
    //Validaciones pregunta 5
    var pregunta5 = document.getElementById('chk5Si').checked;
    if (pregunta5) {
        return true;
    }

}
//<--- C7 --->
/// <summary>
///     Método que valida si se realiza una póliza o una solicitud.
/// </summary>
function validarImprimePolizaSolicitud() {
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = getNumContrato();
    var MarcaValidacion;

    var imprimePolizaSolicitud = MetodosAjax.validaImprimePolizaSolicitud(ramo, modalidad, contrato);

    if (imprimePolizaSolicitud.error == null) {
        if (imprimePolizaSolicitud != null && imprimePolizaSolicitud.value != null) {
            MarcaValidacion = imprimePolizaSolicitud.value.p_poli_soli;

            if (MarcaValidacion == "S")
                return true //Emite (Poliza)
            else
                return false //Cotiza (Solicitud)
        }
    }
    else {
        alert(imprimePolizaSolicitud.error.description);
        return false;
    }
}

function validarSumaAseguradaBasica() {
    //----------------->C13<-----------------
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var modalidad = document.getElementById("hdnmodalidadul").value;
    var contrato = getNumContrato();

    var Moneda = selValorCtrl("drpMoneda");
    var SumaAsegBasica = document.getElementById("txtSuma1000").value;

    var SumaBasica = MetodosAjax.validaSumaBasica(ramo, modalidad, contrato, Moneda, SumaAsegBasica);
    if (SumaBasica.error == null) {
        if (SumaBasica != null && SumaBasica.value != null) {
            var MarcaValidacion = SumaBasica.value.p_mca_valido;
            if (MarcaValidacion == "S")
                return true; //Emite (Poliza)
            else {
                //------->C25<-------
                alert(SumaBasica.value.p_error);
                return false;  //Cotiza (Solicitud)
            }
        }
    }
    else {
        alert(SumaBasica.error.description);
        return false;
    }
}

//--->C6<---
/// <summary>
///     Obtiene el numero del contrato seleccionado o el numero genérico si no se ha seleccionado alguno.
/// </summary>
function getNumContrato() {
    var contrato = document.getElementById("HiddenContratoGenerico").value;

    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
    }

    return contrato;
}

function validarCumulos() {
    //------------------->C14<-------------------
    var Edad = document.getElementById("txtEdad").value;

    var ramo = document.getElementById("HiddenRamoRequest").value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = getNumContrato();
    var moneda = document.getElementById("drpMoneda").value;
    var nombre = valorCtrl("UscAsegCLM_lblNombre");
    var apellidoPat = valorCtrl("UscAsegCLM_lblApellidoPaterno");
    var apellidoMat = valorCtrl("UscAsegCLM_lblApellidoMaterno");
    var fecNac = valorCtrl("UscAsegCLM_lblNacimiento");
    var sumAseg = 0;
    var tbCoberturas = document.getElementById("Coberturas");
    var sumaValor = 0;

    /* Se realiza cambio a petición de usuario apl-09122014
       La suma asegurada tiene que ser igual a la cobertura básica.
       Texto original de petición : "ya podemos emitir la mayoría de los ramos, está pendiente que nos corrijan la parte de cúmulos ya que el sistema esta sumando las SA de todas las coberturas adicionales"
 
    for (var i = 1; i <= tbCoberturas.rows.length; i++) 
    {
        if (document.getElementById("chk" + i) != null) 
        {
            if (document.getElementById("chk" + i).checked) 
            {
                var CodCob = document.getElementById("chk" + i).value;
 
                if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) 
                {
                    sumaValor = parseFloat(document.getElementById("txtSuma" + CodCob).value);
                    sumAseg = sumAseg + sumaValor; 
                }  
            }
        }
    }
    */

    //MU-080082 Se cambia la validacion de los cumulos a la cobertura temporal INI
    /* Solo se toma en cuenta la cobertura básica*/
    /*if (document.getElementById("chk1") != null) {
        if (document.getElementById("chk1").checked) {
            var CodCob = document.getElementById("chk1").value;
            if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                sumAseg = parseFloat(document.getElementById("txtSuma" + CodCob).value);
            }
        }
    }*/

    if (document.getElementById("chk1004") != null) {
        if (document.getElementById("chk1004").checked) {
            var CodCob = document.getElementById("chk1004").value;
            if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                sumAseg = parseFloat(document.getElementById("txtSuma" + CodCob).value);
            }
        }
    }
    //MU-080082 Se cambia la validacion de los cumulos a la cobertura temporal FIN

    var Cumulos = MetodosAjax.validaCumulos(ramo, modalidad, contrato, moneda, Edad, nombre, apellidoPat, apellidoMat, fecNac, sumAseg);

    if (Cumulos.error == null) {
        if (Cumulos != null && Cumulos.value != null) {
            var MarcaValidacion = Cumulos.value.p_mca_valido;
            if (MarcaValidacion == "S")
                return true; //Emite (Poliza)
            else

                return false;  //Cotiza (Solicitud)
        }
    }
    else {
        alert(Cumulos.error.description);
        return false;
    }
}

//----->C22<-----
/// <summary>
///     Obtiene los exámenes que se deben realizar.
/// </summary>
function validarExamen() {

    var Edad = document.getElementById("txtEdad").value;

    var ramo = document.getElementById("HiddenRamoRequest").value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = getNumContrato();
    var moneda = document.getElementById("drpMoneda").value;
    var nombre = valorCtrl("UscAsegCLM_lblNombre");
    var apellidoPat = valorCtrl("UscAsegCLM_lblApellidoPaterno");
    var apellidoMat = valorCtrl("UscAsegCLM_lblApellidoMaterno");
    var fecNac = valorCtrl("UscAsegCLM_lblNacimiento");

    var sumAseg = 0;
    var tbCoberturas = document.getElementById("Coberturas");
    var sumaValor = 0;

    /* Se realiza cambio a petición de usuario apl-09122014
       La suma asegurada tiene que ser igual a la cobertura básica.
       Texto original de petición : "ya podemos emitir la mayoría de los ramos, está pendiente que nos corrijan la parte de cúmulos ya que el sistema esta sumando las SA de todas las coberturas adicionales"
 
    for (var i = 1; i <= tbCoberturas.rows.length; i++) {
        if (document.getElementById("chk" + i) != null) {
            if (document.getElementById("chk" + i).checked) {
                var CodCob = document.getElementById("chk" + i).value;
 
                if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                    sumaValor = parseFloat(document.getElementById("txtSuma" + CodCob).value);
                    sumAseg = sumAseg + sumaValor;
                }  
            }
        }
    }
*/
    /* Solo se toma en cuenta la cobertura básica*/
    if (document.getElementById("chk1000") != null) {
        if (document.getElementById("chk1000").checked) {
            var CodCob = document.getElementById("chk1000").value;
            if (!isNaN(parseFloat(document.getElementById("txtSuma" + CodCob).value))) {
                sumAseg = parseFloat(document.getElementById("txtSuma" + CodCob).value);
            }
        }
    }
    var examenes = MetodosAjax.validaExamenes(ramo, modalidad, contrato, moneda, Edad, sumAseg, nombre, apellidoMat, apellidoPat, fecNac);

    if (examenes.error == null) {
        if (examenes != null && examenes.value != null) {
            var examen = examenes.value.p_mensaje;
            if (examen != "") {
                //------->C24<-------
                if (examen.indexOf("NO SE ENCUENTRA INFORMACIÓN") != -1) {
                    alert("NO EXISTEN DATOS CONFIGURADOS PARA EL TIPO DE EXAMEN SEGUN LOS PAR\u00c1METROS INGRESADOS.");
                    return true;
                }
                else {
                    alert("DE ACUERDO AL MONTO DE SUMA ASEGURADA, LE CORRESPONDE UN EXAMEN TIPO: " + examenes.value.p_mensaje);
                    var aux = examenes.value.p_mensaje;
                    if (aux.substring(0, 1) == "A")
                        return true;
                    else
                        return false;
                }
            }
            else {
                alert("NO EXISTEN DATOS CONFIGURADOS PARA EL TIPO DE EXAMEN");
                return false;
            }
        }
    }
    else {
        alert(examenes.error.description);
        return false;
    }
}

function validarOcupacion() {
    var Ocupacion = selValorCtrl("drpOcupacion");
    var valOcupacion = MetodosAjax.validaOcupacion(Ocupacion);

    if (valOcupacion.error == null) {
        if (valOcupacion != null && valOcupacion.value != null) {
            var MarcaValidacion = valOcupacion.value.p_mca_valido;
            if (MarcaValidacion == "S")
                return true //Emite (Poliza)
            else
                return false //Cotiza (Solicitud)
        }
    }
    else {
        alert(valOcupacion.error.description);
        return false;
    }
}

function validarIMC() {

    var Peso = valorCtrl("txtPeso");
    var Estatura = valorCtrl("txtEstatura");

    var valIMC = MetodosAjax.validaIMC(Peso, Estatura);
    if (valIMC.error == null) {
        if (valIMC != null && valIMC.value != null) {
            var MarcaValidacion = valIMC.value.p_mca_valido;
            if (MarcaValidacion == "S")
                return true //Emite (Poliza)
            else
                return false //Cotiza (Solicitud)
        }
    }
    else {
        alert(valIMC.error.description);
        return false;
    }
}

function validarDeporte() {
    if (document.getElementById("chkboxSi").checked == true) {
        return false;//Cotiza (Solicitud)
    }
    return true;//Emite (Poliza)
}

function validarCuestionario() {
    if (valCuestionario()) {
        return false;//Cotiza (Solicitud)
    }
    return true;//Emite (Poliza)
}

function valCuestionario() {
	var adicionales = false;
	for (var i = 2; i < 12; i++) {
		if (document.getElementById('chk' + i) != null) {
			if (document.getElementById('chk' + i).checked) {
				adicionales = true;
				break;
			}
		}
	}
    var numPreg = document.getElementById("gvCuestionario").rows.length - 1;
    for (var preg = 1; preg <= numPreg; preg++) {
        
		if (preg > 13) {
            if (document.getElementById("chkSi" + preg).checked) {
                return false;
            }
            if (document.getElementById("chkNo" + preg).checked) {
                return false;
            }
        }
		
		if ($('#HiddenRamoRequest').val() == '101' && adicionales) {
			if (document.getElementById("chkSi" + preg).checked) {
				return true;
			}
		}
		if ($('#HiddenRamoRequest').val() != '101') {
			if (document.getElementById("chkSi" + preg).checked) {
				return true;
			}
		}
    }
    return false;
}

//--->C5<---
function EnviarCorreoAAgente(Asunto, EmailTo) {
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = getNumContrato();

    MetodosAjax.EnviarCorreo(ramo, modalidad, contrato, Asunto, EmailTo);
}

function PreguntaDeportes(objCheck) {
    if (objCheck.id == "chkboxSi")
        document.getElementById("chkboxNo").checked = false;
    else
        document.getElementById("chkboxSi").checked = false;
}

function ActualizarEstadoRAM() {
    var modoEmision = document.getElementById("HiddenModoEmision").value;
    if (modoEmision == "P")
        MetodosAjax.setEstadoRAMCapturado();
    else {
        //verificar que ya exista el estatus de suscripción
    }
}

function testImprimirPoliza() {
    var Poliza = "1000010002312";
    var sector = 1;
    var usuario = document.getElementById("HiddenUsuario").value;
    var agente = document.getElementById("HiddenAgente").value;
    var correo = manejoLabel("UscAsegCLM_lblCorreo");
    var urlPoliza = '/impresionSeGA/TWImpPolizaMarco.aspx?noPoliza=' + Poliza + '&sector=' + sector + '&simpol=n&usuario=' + usuario + '&agente=' + agente + '&eMail=' + correo;
    document.getElementById("frmImpresionArchivo").src = urlPoliza;
    //window.open('/impresionSeGA/TWImpPolizaMarco.aspx?noPoliza=' + Poliza + '&sector=' + sector + '&simpol=n&usuario=' + usuario + '&agente=' + agente + '&eMail=' + correo, 'POLIZA', 'toolbar=false,scrollbars=1,resizable=0,width=800,height=680,left=30,top=30');
}


function EmisionFinal() {
    Poliza = document.getElementById("HiddenNoSolPol").value;
    FolioRAM = document.getElementById("HiddenFolioRAM").value;
    IdSistemaRAM = document.getElementById("HiddenIDSistemaRAM").value;

    var Mensaje1 = "“Hago constar que el cliente act\u00faa en nombre y cuenta propia o con las facultades suficientes otorgadas por su representada(do); y  que los recursos utilizados en la o las operaciones provienen de actividades l\u00edcitas”.";
    alert(Mensaje1);

    var documentos = document.getElementById("grdAdjuntarArchivo");
    var archivos = "";

    if (documentos != null) {
        for (var i = 1; i < documentos.rows.length; i++) {
            archivos = archivos + documentos.rows[i].cells[0].innerHTML + ",";
        }
    }

    MetodosAjax.AgregarFolioDocumentum(archivos, FolioRAM, Poliza, IdSistemaRAM);

    var Mensaje = "SU N\u00daMERO DE P\u00d3LIZA ES: " + Poliza + " Y EL FOLIO RAM ES : " + FolioRAM;
    alert(Mensaje);
    habilitarCtrl("btnEmite", false);

    var relacion = "";
    var nacionalidad = manejoLabel("UscAsegCLM_lblNacionalidad");
    var Fuma = 0;
    var Ocupacion = selValorCtrl("drpOcupacion");
    var RamoDesc = document.getElementById("HiddenRamoDescripcion").value;
    //var Plazo = selValorCtrl("drpPlazo");
    var Plazo = document.getElementById("hdnPlazo").value;
    var Peso = document.getElementById("txtPeso").value;
    var Estatura = document.getElementById("txtEstatura").value;
    var Edad = document.getElementById("txtEdad").value;

    var RelSol = Array();
    RelSol[0] = nacionalidad + "|" +
        Fuma + "|" +
        Ocupacion + "|" +
        RamoDesc + " " + Plazo + "|" +
        Peso + "|" +
        Estatura + "|" +
        Edad + "|";

    relacion = RelSol[0];
    MetodosAjax.AgregarSolicitud(Poliza, relacion, FolioRAM, IdSistemaRAM);

    habilitarCtrl("btnImprimePoliza", true);
    habilitarCtrl("btnImprimeSolicitud", false);

}

function MM_ImprimeContrato(pol) {
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var poliza = pol;
    var fecha = document.getElementById("txtFechaEfecto").value;
    var ciudad = document.getElementById("UscContCLM_lblEdo").innerHTML;
    var cob = tipcobro;

    window.open("../Impresion/ImpCont.aspx?ramo=" + ramo + "&poliza=" + poliza + "&fec_emis=" + fecha + "&ciudad=" + ciudad + "&cobro=" + cob, "Contrato", "toolbar=no,scrollbars=yes,resizable=0,width=760,height=600,left=350,top=50");
}
//Unit Linked Deducciones INI
function getdeducciones(cotizacion) {
    var PrimaIni = document.getElementById("txtMontoIni").value;
    var Pfrac = formatNumber(document.all("lblPrimFrac").innerText);
    MetodosAjax.deduccionesULIND(cotizacion, PrimaIni, Pfrac, deducciones_callback);
}

function deducciones_callback(res) {
    if (res != null || res != "") {
        document.getElementById("tbldeducciones").innerHTML = res.value;
        document.all("Total1").value = formatCurrency(document.all("Total1").value);
        document.all("Total2").value = formatCurrency(document.all("Total2").value);
        document.all("Total3").value = formatCurrency(document.all("Total3").value);
        LlenarDatosDelSeguro();
    }
    else {
        document.getElementById("tbldeducciones").hidden = true;
    }
}

//Unit Linked Deducciones FIN

function pagolinea() {
    var pago = MetodosAjax.cobranza(document.getElementById("HiddenNoSolPol").value, selIndex("ddlBanco"),
        document.getElementById("txtNTitular").value, document.getElementById("txtAPTitular").value,
        document.getElementById("txtAMTitular").value, selIndex("ddlAnioTarjeta"), selIndex("ddlMesTarjeta"),
        document.getElementById("txtNumTarjeta").value, document.getElementById("txtCodTarjeta").value,
        selIndex("ddlTipoTarjeta"), "UL");

    if (pago.value.split('|')[0] == "1") {
        alert('**********************\nPoliza Cobrada: ' + document.getElementById("HiddenNoSolPol").value + ' Autorizacion: ' + pago.value.split('|')[1] + '\n**********************\n');
        document.getElementById("lblNoPoliza").innerText = document.getElementById("HiddenNoSolPol").value;
        EmisionFinal();
        constanciaUL();
    }
    else {
        alert('Estimado(a) Aliado(a):\nLa emisi\u00f3n de su p\u00f3liza no pudo ser realizada debido a que el  cobro no fue satisfactorio. Favor de verificar los datos bancarios ingresados.\n**********************\n Error en Cobro : ' + pago.value.split('|')[1] + '\n**********************\n');
    }
}

function pagoref() {
    var prima = document.getElementById("lblPrimaTotal").innerText;
    var Poliza = document.getElementById("HiddenNoSolPol").value;
    var urlPD = document.getElementById("hdnUrlPagoDo").value;
    alert('Estimado(a) Aliado(a):\nPara que la p\u00f3liza quede habilitada se deber\u00e1 realizar el dep\u00f3sito por la prima ' + prima.toString() + ', antes de 48 hrs. ');
    var url = urlPD.toString() + "?tipo=LC&lcpoliza=" + Poliza + "&lccodsistema=01&lcurl=prueba.aspx&lcagentecentel=99998&Terminal=SEGA&terminalFPB=0101SEGA&bandera=1";
    var wnventanacob = window.open(url, "_blank", "width=850px,height=800px, menubar=off, scrollbars=yes, resizable=no, top=0, left=0");

    EmisionFinal();
}

function constanciaUL() {
    var ramo = document.getElementById("HiddenRamoRequest").value;
    var moda = document.getElementById("hdnmodalidadul").value;
   var poliza = document.getElementById("HiddenNoSolPol").value;

    window.open("../Impresion/ImpConstancia.aspx?ramo=" + ramo + "&poliza=" + poliza, "Constancia", "toolbar=no,scrollbars=yes,resizable=0,width=760,height=600,left=350,top=50");
}

function activapago(mensaje) {
    if (mensaje.value != "No pudo ser adjuntado el archivo en Documentum.") {
        if (document.getElementById("PasarelaBTn").value == 2) {
            document.getElementById("datosPoliza").style.visibility = "visible";
            document.getElementById("divPasarelaCobro").style.visibility = "visible";
            document.getElementById("btnPagar").style.visibility = "visible";
        }
        else {
            document.getElementById("btnRferenciaBancaria").style.visibility = "visible";
        }
    }
}

function PreguntasSiNo(objCheck, chkSi, chkNo) {
    if (objCheck.id == chkSi) {
        document.getElementById(chkNo).checked = false;
    }
    else {
        document.getElementById(chkSi).checked = false;
    }
	
	if (objCheck.id == "chkSiRiesgo") {
        alert('Por favor solicite el cuestionario correspondiente');
    }

    if (objCheck.id == "chkSiOtraOcupacion") {
        $("#divConsiste").removeAttr('hidden');
        LlenarOcupacion("txtOtraOcupacion");
    } else if (objCheck.id == "chkNoOtraOcupacion") {
        $("#divConsiste").attr('hidden', true);
    }

    if (objCheck.id == "chkSiViajar") {
        $("#divTipoTransporte").removeAttr('hidden');
    } else if (objCheck.id == "chkNoViajar") {
        $("#divTipoTransporte").attr('hidden', true);
        $('#divAeronaves').attr('hidden', true);
    }

    if (objCheck.id == "chkSiAParticular") {
        $('#divEspecifiqueAeronave').removeAttr('hidden');
    } else if (objCheck.id == "chkNoAParticular") {
        $('#divEspecifiqueAeronave').attr('hidden', true);
    }

    if (objCheck.id == "chkSiMotocicleta") {
        $('#divMotoFrecuencia').removeAttr('hidden');
    } else if (objCheck.id == "chkNoMotocicleta") {
        $('#divMotoFrecuencia').attr('hidden', true);
    }

    if (objCheck.id == "chkSiAlturas") {
        $('#divIndicarAltura').removeAttr('hidden');
    } else if (objCheck.id == "chkNoAlturas") {
        $('#divIndicarAltura').attr('hidden', true);
    }

    if (objCheck.id == "chkSiDroga") {
        $('#divTipoFrecuencia').removeAttr('hidden');
    } else if (objCheck.id == "chkNoDroga") {
        $('#divTipoFrecuencia').attr('hidden', true);
    }

    if (objCheck.id == "chk7Si") {
		$('#txt7Causa').removeAttr('hidden');
        $('#divtxtNomDomMedico').removeAttr('hidden');
        $('#divtxtNHospital').removeAttr('hidden');
        $('#divtblRefPersonales').removeAttr('hidden');
        $('#idRefPersonales').removeAttr('hidden');
    } else if (objCheck.id == "chk7No") {
        $('#txt7Causa').attr('hidden', true);
        $('#divtxtNomDomMedico').attr('hidden', true);
        $('#divtxtNHospital').attr('hidden', true);
        $('#divtblRefPersonales').attr('hidden', true);
        $('#idRefPersonales').attr('hidden', true);
    }

    if (objCheck.id == "chk1Si") {
        $('#txt1Causa').removeAttr('disabled');
    } else if (objCheck.id == "chk1No") {
        $('#txt1Causa').attr('disabled', true);
    }

    if (objCheck.id == "chk2Si") {
        $('#txt2Causa').removeAttr('disabled');
        $('#txt2Cuando').removeAttr('disabled');
    } else if (objCheck.id == "chk2No") {
        $('#txt2Causa').attr('disabled', true);
        $('#txt2Cuando').attr('disabled', true);
    }

    if (objCheck.id == "chk3Si") {
        $('#txt3Causa').removeAttr('disabled');
        $('#txt3Cuando').removeAttr('disabled');
    } else if (objCheck.id == "chk3No") {
        $('#txt3Causa').attr('disabled', true);
        $('#txt3Cuando').attr('disabled', true);
    }

    if (objCheck.id == "chk4Si") {
        $('#txt4Causa').removeAttr('disabled');
        $('#txt4Cuando').removeAttr('disabled');
    } else if (objCheck.id == "chk2No") {
        $('#txt4Causa').attr('disabled', true);
        $('#txt4Cuando').attr('disabled', true);
    }

    if (objCheck.id == "chk5Si") {
        $('#txtKgAumentados').removeAttr('disabled');
        $('#txtKgDisminuidos').removeAttr('disabled');
    } else if (objCheck.id == "chk5No") {
        $('#txtKgAumentados').attr('disabled', true);
        $('#txtKgDisminuidos').attr('disabled', true);
    }
}
