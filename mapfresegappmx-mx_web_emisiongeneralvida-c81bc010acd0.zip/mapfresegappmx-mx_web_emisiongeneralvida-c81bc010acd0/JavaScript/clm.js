﻿//'****************************************************************************
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2008
//'Name of the file              : clm.js
//'Creation/Modification History :
//'Description                   :          
//'Modification                  : Marco A. Navarrete C. Indra SWLabs
//'C1                            : 12-05-2014
//                               : Se agregaron los datos FATCA.  
//'*****************************************************************************
//13032018

// JScript File
var tipBnf;
var usrCtrl; //Prefijo del control de usuario
var manco = 0;
var asegurados = 0;
//debugger;
function getGUIDCLM(tipBenef) {
    usrCtrl = "Usc" + tipBenef + "CLM_";
    tipBnf = tipBenef;
    if (document.getElementById("HiddenRamoRequest").value == "105") {

        if (tipBenef == "Aseg" && !document.getElementById("rdoMenor").checked && !document.getElementById("rdoMancomunado").checked && !document.getElementById("rdoTitular").checked) {
            alert("Debes seleccionar el tipo de persona");
            return;
        }

        if (tipBenef == "Aseg" && document.getElementById("rdoMenor").checked) {
            alert("Los asegurados menores deberán ser capturados en el siguiente orden: de acuerdo a su fecha de nacimiento del menor al de mayor edad");
            manco = 0;
        } else if (tipBenef == "Aseg" && document.getElementById("rdoMancomunado").checked) {
            manco = 1;
        } else {
            manco = -1;
        }
    }

    /*==========================================================================================
    * En esta funcion se recuperan los datos de la pagina de emision de cada aplicacion,
    * los cuales se envian por metodo ajax junto con el TOKEN para validar la captura en
    * la pantalla de Cliente Mapfre.
    * Por lo tanto, este codigo puede variar para cada emisor (ramo).
    ==========================================================================================*/

    if (document.getElementById("drpTipoPago").selectedIndex == 0) {
        alert("Seleccione el tipo de pago");
        document.getElementById("drpTipoPago").focus();
        return;
    }
    if (document.getElementById("HiddenRamoRequest").value == "") {
        alert("Existe un problema y no ha podido ser obtenido el Ramo");
        return;
    }
    if (document.getElementById("drpAgente").options.length > 1) {
        if (selIndiceCtrl("drpAgente") == 0) {
            alert("Seleccione un agente");
            focusCtrl("drpAgente");
            return;
        }
    }
    if (document.getElementById("HiddenModalidad").value == "") {
        alert("Existe un problema y no ha podido ser obtenida la Modalidad, seleccione un tipo de Comisión.");
        return;
    }
    if (document.getElementById("HiddenTipoPlanRequest").value != "16") {
        if (document.getElementById("txtEdad").value == "") {
            alert("Capture la Edad");
            document.getElementById("txtEdad").focus();
            return;
        }
    }
    else {
        if (document.getElementById("HiddenRamoRequest").value == "105" && tipBenef == "Cont") {
        }
        else {
            if (document.getElementById("HiddenRamoRequest").value != "105") {
                if (document.getElementById("txtEdadParentesco").value == "") {
                    alert("Capture la Edad");
                    document.getElementById("txtEdadParentesco").focus();
                    return;
                }
            }
        }

    }
    var edad;
    if (document.getElementById("HiddenRamoRequest").value == "105") {
        datosAsegurados = AseguradosType();
        if (asegurados > datosAsegurados.length) {
            asegurados = 0;
            alert("Ya ingreso a todos los asegurados");
        }
        if (tipBenef != "Aseg") {
            asegurados = 0;
        }

        //var edad = document.getElementById("txtEdad").value;
        if (datosAsegurados[asegurados] != null) {
            var datosAsegurado = datosAsegurados[asegurados].split("|");
        } else {
            alert("Ya ingreso a todos los asegurados");
            return;
        }
        if (parseInt(datosAsegurado[0]) > 17) {
            edad = parseInt(datosAsegurado[0]);
        }
        if (document.getElementById("HiddenTipoPlanRequest").value == "16")
            edad = parseInt(datosAsegurado[0]);
    } else {
        edad = document.getElementById("txtEdad").value;
        if (document.getElementById("HiddenTipoPlanRequest").value == "16")
            edad = document.getElementById("txtEdadParentesco").value
    }

    var modalidad = document.getElementById("HiddenModalidad").value;
    var contrato = "";
    var polizaGpo = "";
    contrato = document.getElementById("HiddenContratoGenerico").value;
    if (document.getElementById("rbtnListPolizaContrato_1").checked) {
        contrato = selIndex("drpContrato");
        polizaGpo = textoCtrl("drpPolizaGrupo");
    }

    //------- En esta seccion se debe asignar el tipo de gestor y el codigo del ramo directamente
    //------- del control que lo contenga en cada aplicacion, si es el caso.
    //------- 
    //------- Si la aplicacion maneja solo un tipo de gestor y/o un solo ramo, éste se podra asignar
    //------- como una propiedad del control al momento de inicializarlo y se deberan comentar o
    //------- eliminar las lineas que correspondan de esta seccion.
    document.getElementById(usrCtrl + "hdnGestor").value = selValorCtrl("drpTipoPago");
    document.getElementById(usrCtrl + "hdnRamo").value = document.getElementById("HiddenRamoRequest").value;
    document.getElementById(usrCtrl + "hdnAgente").value = selValorCtrl("drpAgente");
    document.getElementById(usrCtrl + "hdnCodModalidad").value = modalidad; //C1
    //--------------------------------------------------------------------------------

    var token = document.getElementById(usrCtrl + "hdnToken").value;
    var gestor = document.getElementById(usrCtrl + "hdnGestor").value;
    var benef = document.getElementById(usrCtrl + "hdnCodBenef").value;
    var ramo = document.getElementById(usrCtrl + "hdnRamo").value;
    var agente = document.getElementById(usrCtrl + "hdnAgente").value;

    var parametros = Array();
    parametros.push("TIP_GESTOR=" + gestor);
    parametros.push("TIP_BENEF=" + benef);
    parametros.push("COD_RAMO=" + ramo);
    parametros.push("COD_AGT=" + agente);
    /*==========================================================================================
    * En este segmento se introducen las variables para validaciones en Cliente Mapfre        */
    parametros.push("EDAD=" + edad);
    parametros.push("COD_MODALIDAD=" + modalidad);
    if (contrato != "")
        parametros.push("NUM_CONTRATO=" + contrato);
    if (polizaGpo != "")
        parametros.push("NUM_POLIZA_GRUPO=" + polizaGpo);
    /*========================================================================================*/
    CLM.setToken(token, parametros, openCLM_CallBack);
}

function openCLM_CallBack(res) {
    if (res.error == null) {
        var tip_clm = "CLM";
        var facturar = 0;
        if (document.getElementById(usrCtrl + "rdoBusca_0") != null) {
            if (document.getElementById(usrCtrl + "rdoBusca_0").checked)
                tip_clm = "RFC";
        }
        if (document.getElementById(usrCtrl + "rdoFacturarSi") != null) {
            if (document.getElementById(usrCtrl + "rdoFacturarSi").checked)
                facturar = 1;
        }

        var cod_ramo = document.getElementById(usrCtrl + "hdnRamo").value;
        var cod_bnf = document.getElementById(usrCtrl + "hdnCodBenef").value;
        var cod_origen = document.getElementById(usrCtrl + "hdnOrigen").value;
        var cod_docum = document.getElementById(usrCtrl + "txtRFC").value.toUpperCase();
        var cod_clm = document.getElementById(usrCtrl + "hdnCLM").value.toUpperCase();
        var tip_gestor = document.getElementById(usrCtrl + "hdnGestor").value;
        var cotizacion = document.getElementById(usrCtrl + "hdnNumCotizacion").value;

        /***C1***/
        var modalidad = document.getElementById(usrCtrl + "hdnCodModalidad").value;

        if (cod_clm != "")
            tip_clm = "CLM";
        else cod_clm = cod_docum;
        /***C1***/
        if (cod_ramo != "111" && cod_ramo != "112") {
            var Params = "&cia=1&rmo=" + cod_ramo + "&gst=" + tip_gestor + "&bnf=" + cod_bnf + "&tip=" + tip_clm + "&clm=" + cod_clm + "&org=" + cod_origen + "&cot=" + cotizacion + "&lng=esp" + "&mod=" + modalidad + "&fact=" + facturar;
        }
        else {
            if (cod_ramo != "112") {
                var Params = "&cia=1&rmo=" + cod_ramo + "&gst=AG&bnf=1&tip=" + tip_clm + "&clm=" + cod_clm + "&org=" + cod_origen + "&cot=" + cotizacion + "&lng=esp" + "&mod=" + modalidad + "&fact=" + facturar;
            }
            else {
                var modalidadul = document.getElementById("hdnmodalidadul").value;
                if ((cod_ramo == "112" && (modalidadul == "11201" || modalidadul == "11202" || modalidadul == "11203"))) {
                    var Params = "&cia=1&rmo=" + cod_ramo + "&gst=AG&bnf=" + cod_bnf + "&tip=" + tip_clm + "&clm=" + cod_clm + "&org=" + cod_origen + "&cot=" + cotizacion + "&lng=esp" + "&fact=" + facturar;
                }
                else {
                    var Params = "&cia=1&rmo=" + cod_ramo + "&gst=" + tip_gestor + "&bnf=0&tip=" + tip_clm + "&clm=" + cod_clm + "&org=" + cod_origen + "&cot=" + cotizacion + "&lng=esp" + "&fact=" + facturar;
                }
            }
        }
        MM_loadCLM(Params);
    }
    else alert(res.error.description);
}

var wndCLM;
function MM_loadCLM(vPARAMS) {
    var urlCLM = document.getElementById(usrCtrl + "hdnURLCLM").value;
    var token = document.getElementById(usrCtrl + "hdnToken").value;
    var usuario = document.getElementById(usrCtrl + "hdnUsrLogin").value;
    var tipoUsuario = document.getElementById(usrCtrl + "hdnUsrTypeLogin").value;
    var vURL;
    if (document.getElementById("HiddenRamoRequest").value == "105") {
        vURL = "/clm/ClienteMMX1.aspx" + "?usr=" + usuario + "&usrT=" + tipoUsuario + "&manco=" + manco + vPARAMS;
    } else {
        vURL = urlCLM + "?usr=" + usuario + "&usrT=" + tipoUsuario + vPARAMS;
    }
    //window.showModalDialog(vURL, 'clienteMapfre', 'dialogWidth:807px;dialogHeight:690px;toolbars:no;scrollbars:no;status:no;resizable:no');
    window.open(vURL, 'clienteMapfre', 'width=807px,height=690px,toolbars=no,scrollbars=yes,status=no,resizable=no');
    //CLM.getDatosContexto(token, DocumCLM_CallBack);
}

function obtenDatosContexto(regFiscal, codFiscal, regSocietario) {
    var token = document.getElementById(usrCtrl + "hdnToken").value;
    if (regSocietario == undefined) {
        regSocietario = "";
    }
    if (regFiscal.split('|')[0] == "-1") {
        regFiscal = "";
    } else {
        regFiscal = regFiscal.split('|')[0];
    }
    if (regSocietario.split('|')[0] == "-1") {
        regSocietario = "";
    } else {
        regSocietario = regSocietario.split('|')[0]
    }
    document.getElementById(usrCtrl + "hdnRegFiscal").value = regFiscal;
    document.getElementById(usrCtrl + "hdnCodPostalFiscal").value = codFiscal;
    document.getElementById(usrCtrl + "hdnRegSocietario").value = regSocietario;
    CLM.getDatosContexto(token, DocumCLM_CallBack);
}

function getDatosCLM_CallBack(datosCLM) {

    if (datosCLM.error == null) {
        if (datosCLM.value != null && datosCLM.value != "") {
            var aux = document.getElementById(usrCtrl + "hdnCodEntidad").value;
            limpiaCLM(usrCtrl);
            document.getElementById(usrCtrl + "hdnCodEntidad").value = aux;
            var arrDatos = Array();
            arrDatos = datosCLM.value;

            document.getElementById(usrCtrl + "hdnCLM").value = arrDatos[1];

            // Validacion para los datos que se recuperan en la consulta
            //---
            var continua = eval(document.getElementById(usrCtrl + "hdnValidaConsulta").value);
            if (continua == false) {
                document.getElementById(usrCtrl + "hdnCLM").value = "";
                limpiaCLM(usrCtrl);
                return;
            }
            //---

            manejoLabel(usrCtrl + "lblCLM", arrDatos[1]);
            if (arrDatos[2] == "S") {
                document.getElementById(usrCtrl + "rdoFisica").checked = true;
                document.getElementById(usrCtrl + "rdoMoral").checked = false;
                manejoLabel(usrCtrl + "lblNombreT", "Nombre:");
                manejoLabel(usrCtrl + "lblEdoCivil", arrDatos[8].split('|')[1]);
                document.getElementById(usrCtrl + "hdnEdoCivil").value = arrDatos[8].split('|')[0];
                manejoLabel(usrCtrl + "lblProfesion", arrDatos[9].split('|')[1]);
                document.getElementById(usrCtrl + "hdnProfesion").value = arrDatos[9].split('|')[0];
                manejoLabel(usrCtrl + "lblParentesco", arrDatos[10].split('|')[1]);
                document.getElementById(usrCtrl + "hdnParentesco").value = arrDatos[10].split('|')[0];
                manejoLabel(usrCtrl + "lblNacionalidad", arrDatos[14].split('|')[1]);
                document.getElementById(usrCtrl + "hdnNacionalidad").value = arrDatos[14].split('|')[0];

            }
            else {
                document.getElementById(usrCtrl + "rdoFisica").checked = false;
                document.getElementById(usrCtrl + "rdoMoral").checked = true;
                manejoLabel(usrCtrl + "lblNombreT", "Razón Social:");
                manejoLabel(usrCtrl + "lblActividad", arrDatos[8].split('|')[1]);
                document.getElementById(usrCtrl + "hdnActividad").value = arrDatos[8].split('|')[0];
                manejoLabel(usrCtrl + "lblRepresentante", arrDatos[9]);
                manejoLabel(usrCtrl + "lblCargo", arrDatos[10].split('|')[1]);
                document.getElementById(usrCtrl + "hdnCargo").value = arrDatos[10].split('|')[0];

            }
            manejoLabel(usrCtrl + "lblNombre", arrDatos[3]);
            manejoLabel(usrCtrl + "lblApellidoPaterno", arrDatos[4]);
            manejoLabel(usrCtrl + "lblApellidoMaterno", arrDatos[5]);
            manejoLabel(usrCtrl + "lblNacimiento", arrDatos[6].split('|')[0]);
            manejoLabel(usrCtrl + "lblEdad", arrDatos[6].split('|')[1]);
            manejoLabel(usrCtrl + "lblSexo", arrDatos[7]);
            manejoLabel(usrCtrl + "lblRFC", arrDatos[12]);
            manejoLabel(usrCtrl + "lblCURP", arrDatos[13]);

            manejoLabel(usrCtrl + "lblDireccion", arrDatos[15]);
            manejoLabel(usrCtrl + "lblColonia", arrDatos[16]);
            manejoLabel(usrCtrl + "lblEdo", arrDatos[17].split('|')[1]);
            document.getElementById(usrCtrl + "hdnEdo").value = arrDatos[17].split('|')[0];
            manejoLabel(usrCtrl + "lblPoblacion", arrDatos[18].split('|')[1]);
            document.getElementById(usrCtrl + "hdnPoblacion").value = arrDatos[18].split('|')[0];
            manejoLabel(usrCtrl + "lblCP", arrDatos[19]);
            manejoLabel(usrCtrl + "lblTelefono", arrDatos[20]);
            manejoLabel(usrCtrl + "lblCorreo", arrDatos[21]);
            manejoLabel(usrCtrl + "lblCelular", arrDatos[11]);

            //Cambio Millón Vida
            if (document.getElementById("HiddenRamoRequest").value == "111" || (document.getElementById("HiddenRamoRequest").value == "112" && (document.getElementById("hdnmodalidadul").value == "11204" || document.getElementById("hdnmodalidadul").value == "11205" || document.getElementById("hdnmodalidadul").value == "11206"))) {
                document.getElementById("txtNTitular").value = arrDatos[3];
                document.getElementById("txtAPTitular").value = arrDatos[4];
                document.getElementById("txtAMTitular").value = arrDatos[5];

                document.getElementById("txtNTitular").Enabled = false;
                document.getElementById("txtAPTitular").Enabled = false;
                document.getElementById("txtAMTitular").Enabled = false;


            }

            //C1
            if (arrDatos[23] == 'S') {
                manejoLabel(usrCtrl + "lblPaisRef", arrDatos[24].split('|')[1]);
                manejoLabel(usrCtrl + "lblPaisNacimiento", arrDatos[25].split('|')[1]);
                manejoLabel(usrCtrl + "lblPaisRepresentanteLegal", arrDatos[26].split('|')[1]);
                manejoLabel(usrCtrl + "lblPaisTransferencia", arrDatos[30].split('|')[1]);
                manejoLabel(usrCtrl + "lblPaisResidenciaFiscal", arrDatos[27].split('|')[1]);
                manejoLabel(usrCtrl + "lblPaisResidenciaFiscal2", arrDatos[28].split('|')[1]);
                manejoLabel(usrCtrl + "lblPaisResidenciaFiscal3", arrDatos[29].split('|')[1]);
                manejoLabel(usrCtrl + "lblTin", arrDatos[31]);

            }
            else {
                document.getElementById(usrCtrl + "tbCLM4").setAttribute('style', 'display: none');

            }

            document.getElementById(usrCtrl + "btnEnviaDatos").value = "Modificar";
            document.getElementById(usrCtrl + "txtRFC").value = "";
        }
        else {
            limpiaCLM(usrCtrl);
            alert("No se encontraron datos");
        }
    }
    else {
        limpiaCLM(usrCtrl);
        alert(datosCLM.error.description);
    }
    eval(document.getElementById(usrCtrl + "hdnFuntion").value);

    if (document.getElementById("HiddenRamoRequest").value == "111" || document.getElementById("HiddenRamoRequest").value == "112") {
        document.getElementById("UscAsegCLM_chkContSol").checked = true;
        document.getElementById("UscAsegCLM_chkContSol").disabled = true;
        copiaContUS('Cont', 'Aseg');
        DatosSeguroCLMCarga('UscAsegCLM_chkContSol');


    }
}


function limpiaCLM(uCtrl) {
    if (tipBnf == "Cont")
        document.getElementById(uCtrl + "hdnCodEntidad").value = "";

    document.getElementById(uCtrl + "btnEnviaDatos").value = "Buscar";
    document.getElementById(uCtrl + "rdoFisica").checked = true;
    document.getElementById(uCtrl + "rdoMoral").checked = false;
    manejoLabel(uCtrl + "lblCLM", "");
    document.getElementById(uCtrl + "hdnCLM").value = "";
    manejoLabel(uCtrl + "lblNombreT", "Nombre:");
    manejoLabel(uCtrl + "lblNombre", "");
    manejoLabel(uCtrl + "lblApellidoPaterno", "");
    manejoLabel(uCtrl + "lblApellidoMaterno", "");
    manejoLabel(uCtrl + "lblRFC", "");
    manejoLabel(uCtrl + "lblCURP", "");
    manejoLabel(uCtrl + "lblNacimiento", "");
    manejoLabel(uCtrl + "lblEdad", "");
    manejoLabel(uCtrl + "lblSexo", "");

    manejoLabel(uCtrl + "lblEdoCivil", "");
    document.getElementById(uCtrl + "hdnEdoCivil").value = "";
    manejoLabel(uCtrl + "lblProfesion", "");
    document.getElementById(uCtrl + "hdnProfesion").value = "";
    manejoLabel(uCtrl + "lblParentesco", "");
    document.getElementById(uCtrl + "hdnParentesco").value = "";
    manejoLabel(uCtrl + "lblNacionalidad", "");
    document.getElementById(uCtrl + "hdnNacionalidad").value = "";

    manejoLabel(uCtrl + "lblActividad", "");
    document.getElementById(uCtrl + "hdnActividad").value = "";
    manejoLabel(uCtrl + "lblRepresentante", "");
    manejoLabel(uCtrl + "lblCargo", "");
    document.getElementById(uCtrl + "hdnCargo").value = "";

    manejoLabel(uCtrl + "lblDireccion", "");
    manejoLabel(uCtrl + "lblColonia", "");
    manejoLabel(uCtrl + "lblEdo", "");
    document.getElementById(uCtrl + "hdnEdo").value = "";
    manejoLabel(uCtrl + "lblPoblacion", "");
    document.getElementById(uCtrl + "hdnPoblacion").value = "";
    manejoLabel(uCtrl + "lblCP", "");
    manejoLabel(uCtrl + "lblTelefono", "");
    manejoLabel(uCtrl + "lblCorreo", "");
    manejoLabel(uCtrl + "lblCelular", "");

    //C1
    manejoLabel(uCtrl + "lblPaisNacimiento", "");
    manejoLabel(uCtrl + "lblPaisRef", "");
    manejoLabel(uCtrl + "lblPaisRepresentanteLegal", "");
    manejoLabel(uCtrl + "lblPaisTransferencia", "");
    manejoLabel(uCtrl + "lblPaisResidenciaFiscal", "");
    manejoLabel(uCtrl + "lblPaisResidenciaFiscal2", "");
    manejoLabel(uCtrl + "lblPaisResidenciaFiscal3", "");
    manejoLabel(uCtrl + "lblTin", "");
}

function tipBusqueda(tipBenef) {
    tipBnf = tipBenef;
    usrCtrl = "Usc" + tipBenef + "CLM_";
    limpiaCLM(usrCtrl);
}

function DocumCLM_CallBack(datos) {
    if (document.getElementById("HiddenRamoRequest").value == "105") {
        isMenor();
    }

    if (datos.error == null) {
        if (datos.value != null && datos.value != "") {
            var arrDatos = Array();
            arrDatos = datos.value.split("|");

            if (tipBnf == "Cont" && document.getElementById(usrCtrl + "hdnGestor").value != "AG") {
                //if (document.getElementById(usrCtrl + "hdnRamo").value != "111" && document.getElementById(usrCtrl + "hdnRamo").value != "112")
                if (document.getElementById(usrCtrl + "hdnRamo").value != "111") {
                    if (arrDatos[1] == undefined || arrDatos[1] == "") {
                        alert("DEBE ASIGNAR UNA CUENTA PARA CONTINUAR");
                        return;
                    }
                    document.getElementById(usrCtrl + "hdnCodEntidad").value = arrDatos[1] + arrDatos[1];
                }
            }

            if (arrDatos[0] != "") {
                var bnf = document.getElementById(usrCtrl + "hdnCodBenef").value;
                CLM.getDatosCLM(arrDatos[0], bnf, "CLM", getDatosCLM_CallBack);
            }
        }
    }
    else alert(datos.error.description);
}

// Copia datos de un Uc a otro
// Origen --> UC origen de los datos
// Destino --> UC donde se copiaran los datos
function copiaContUS(strOrigen, strDestino) {
    tipBnf = strDestino;
    var UCOrigen = "Usc" + strOrigen + "CLM_";
    var UCDestino = "Usc" + strDestino + "CLM_";

    // Validacion para utilizar mismo cliente
    //---
    usrCtrl = UCOrigen;
    var continua = eval(document.getElementById(UCDestino + "hdnValidaCopia").value);
    if (continua == false) {
        document.getElementById(UCDestino + "chkContSol").checked = false;
        InhabilitaBusqueda(UCDestino, false);
        limpiaCLM(UCDestino);
        return;
    }
    //---

    if (document.getElementById(UCDestino + "chkContSol").checked) {
        InhabilitaBusqueda(UCDestino, true);
        document.getElementById(UCDestino + "txtRFC").value = document.getElementById(UCOrigen + "txtRFC").value
        document.getElementById(UCDestino + "rdoBusca_0").checked = document.getElementById(UCOrigen + "rdoBusca_0").checked;
        document.getElementById(UCDestino + "rdoBusca_1").checked = document.getElementById(UCOrigen + "rdoBusca_1").checked;

        document.getElementById(UCDestino + "hdnCLM").value = document.getElementById(UCOrigen + "hdnCLM").value;
        document.getElementById(UCDestino + "rdoFisica").checked = document.getElementById(UCOrigen + "rdoFisica").checked;
        document.getElementById(UCDestino + "rdoMoral").checked = document.getElementById(UCOrigen + "rdoMoral").checked;
        manejoLabel(UCDestino + "lblCLM", manejoLabel(UCOrigen + "lblCLM"));
        manejoLabel(UCDestino + "lblApellidoPaterno", manejoLabel(UCOrigen + "lblApellidoPaterno"));
        manejoLabel(UCDestino + "lblApellidoMaterno", manejoLabel(UCOrigen + "lblApellidoMaterno"));
        manejoLabel(UCDestino + "lblNombre", manejoLabel(UCOrigen + "lblNombre"));
        manejoLabel(UCDestino + "lblRFC", manejoLabel(UCOrigen + "lblRFC"));
        manejoLabel(UCDestino + "lblCURP", manejoLabel(UCOrigen + "lblCURP"));
        manejoLabel(UCDestino + "lblNacimiento", manejoLabel(UCOrigen + "lblNacimiento"));
        manejoLabel(UCDestino + "lblEdad", manejoLabel(UCOrigen + "lblEdad"));

        manejoLabel(UCDestino + "lblSexo", manejoLabel(UCOrigen + "lblSexo"));
        manejoLabel(UCDestino + "lblEdoCivil", manejoLabel(UCOrigen + "lblEdoCivil"));
        document.getElementById(UCDestino + "hdnEdoCivil").value = document.getElementById(UCOrigen + "hdnEdoCivil").value;
        manejoLabel(UCDestino + "lblProfesion", manejoLabel(UCOrigen + "lblProfesion"));
        document.getElementById(UCDestino + "hdnProfesion").value = document.getElementById(UCOrigen + "hdnProfesion").value;
        manejoLabel(UCDestino + "lblParentesco", manejoLabel(UCOrigen + "lblParentesco"));;
        document.getElementById(UCDestino + "hdnParentesco").value = document.getElementById(UCOrigen + "hdnParentesco").value;
        manejoLabel(UCDestino + "lblNacionalidad", manejoLabel(UCOrigen + "lblNacionalidad"));;
        document.getElementById(UCDestino + "hdnNacionalidad").value = document.getElementById(UCOrigen + "hdnNacionalidad").value;

        manejoLabel(UCDestino + "lblActividad", manejoLabel(UCOrigen + "lblActividad"));
        document.getElementById(UCDestino + "hdnActividad").value = document.getElementById(UCOrigen + "hdnActividad").value;
        manejoLabel(UCDestino + "lblRepresentante", manejoLabel(UCOrigen + "lblRepresentante"));
        manejoLabel(UCDestino + "lblCargo", manejoLabel(UCOrigen + "lblCargo", ""));
        document.getElementById(UCDestino + "hdnCargo").value = document.getElementById(UCOrigen + "hdnCargo").value;

        manejoLabel(UCDestino + "lblDireccion", manejoLabel(UCOrigen + "lblDireccion"));
        manejoLabel(UCDestino + "lblColonia", manejoLabel(UCOrigen + "lblColonia"));
        manejoLabel(UCDestino + "lblEdo", manejoLabel(UCOrigen + "lblEdo"));
        document.getElementById(UCDestino + "hdnEdo").value = document.getElementById(UCOrigen + "hdnEdo").value;
        manejoLabel(UCDestino + "lblPoblacion", manejoLabel(UCOrigen + "lblPoblacion"));
        document.getElementById(UCDestino + "hdnPoblacion").value = document.getElementById(UCOrigen + "hdnPoblacion").value;
        manejoLabel(UCDestino + "lblCP", manejoLabel(UCOrigen + "lblCP"));
        manejoLabel(UCDestino + "lblTelefono", manejoLabel(UCOrigen + "lblTelefono"));
        manejoLabel(UCDestino + "lblCorreo", manejoLabel(UCOrigen + "lblCorreo"));
        manejoLabel(UCDestino + "lblCelular", manejoLabel(UCOrigen + "lblCelular"));

        //C1
        manejoLabel(UCDestino + "lblPaisNacimiento", manejoLabel(UCOrigen + "lblPaisNacimiento"));
        manejoLabel(UCDestino + "lblPaisRef", manejoLabel(UCOrigen + "lblPaisRef"));
        manejoLabel(UCDestino + "lblPaisRepresentanteLegal", manejoLabel(UCOrigen + "lblPaisRepresentanteLegal"));
        manejoLabel(UCDestino + "lblPaisTransferencia", manejoLabel(UCOrigen + "lblPaisTransferencia"));
        manejoLabel(UCDestino + "lblPaisResidenciaFiscal", manejoLabel(UCOrigen + "lblPaisResidenciaFiscal"));
        manejoLabel(UCDestino + "lblPaisResidenciaFiscal2", manejoLabel(UCOrigen + "lblPaisResidenciaFiscal2"));
        manejoLabel(UCDestino + "lblPaisResidenciaFiscal3", manejoLabel(UCOrigen + "lblPaisResidenciaFiscal3"));
        manejoLabel(UCDestino + "lblTin", manejoLabel(UCOrigen + "lblTin"));

        document.getElementById(UCDestino + "btnEnviaDatos").value = "Modificar";
        if (document.getElementById("HiddenRamoRequest").value == "105") {
            valida_Edad105();
        }

    }
    else {
        InhabilitaBusqueda(UCDestino, false);
        limpiaCLM(UCDestino);
    }
}

function getNumAsegurado() {
    return asegurados;
}

function setNumAsegurado() {
    asegurados = asegurados + 1;
}

// Funcion que manipula los controles label para funcionalidad en Internet Explorer,
// Mozilla, Safari, etc
function manejoLabel(nombreLabel, asignar) {
    var control;
    control = eval(document.getElementById(nombreLabel));
    if (control.tagName == "SPAN" || control.tagName == "DIV" || control.tagName == "A") {
        if (asignar != undefined) {
            if (typeof (asignar) != "string" && typeof (asignar) != "number")
                return alert("El tipo de dato no es válido");
            for (var j = 0; j < control.childNodes.length; j++)
                control.removeChild(control.childNodes[j]);
            control.appendChild(document.createTextNode(asignar));
            return;
        }
        m_texto = "";
        for (var i = 0; i < control.childNodes.length; i++) {
            if (control.childNodes[i].nodeName == "#text")
                m_texto += control.childNodes[i].nodeValue;
            else
                m_texto += control.childNodes[i].firstChild.nodeValue;
        }
    }
    return m_texto;
}

function InhabilitaBusqueda(uCtrl, bolAux) {
    document.getElementById(uCtrl + "btnEnviaDatos").disabled = bolAux;
    document.getElementById(uCtrl + "txtRFC").disabled = bolAux;
    document.getElementById(uCtrl + "rdoBusca").disabled = bolAux;
}

function LimpiaDependientes(strOrigen, strDestino) {
    var chk = document.getElementById("Usc" + strDestino + "CLM_chkContSol");
    if (chk != null) {
        if (chk.checked) {
            chk.checked = false;
            copiaContUS(strOrigen, strDestino);
        }
    }
}

//Funcion para abrir el pop up con el mensaje de ayuda y guajillo
function fnAyuda(mensaje, left, top, tipo) {
    document.getElementById('divGuajillo').style.display = "inline";
    document.getElementById('divGuajillo').style.left = left;
    document.getElementById('divGuajillo').style.top = top;
    document.getElementById('guajillo').src = '/AyudasWeb/Ayuda' + tipo + '.aspx?msg=' + unescape(mensaje);
}

function fnCierraAyuda() {
    document.getElementById('divGuajillo').style.display = "none";
}