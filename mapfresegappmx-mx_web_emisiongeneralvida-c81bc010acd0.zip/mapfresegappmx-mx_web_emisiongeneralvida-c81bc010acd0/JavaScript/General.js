﻿// JScript File
//03052018
var ALFANUMERICOSINESPACIOS = /(^([a-z]|[A-Z]|[0-9])+)$/;
var ALFANUMERICO_ESPANIOL = /^([a-z]|[A-Z]|\xD1|\xDC|\xF1|\xFC|\s|\.|-|[0-9])+$/;
var NOMBRE = /^([a-z]|[A-Z]|\xD1|\xDC|\xF1|\xFC|\s|\.|-)+|^$/;
var NUMERICO = /(^([0-9]|\xD|\xA)+)$/;
var NUMERICO_PUNTO = /(^([0-9]|\.|\xD|\xA)+)$/;
var NUMERICO_FECHAS = /(^([0-9]|\/)+)$/;
var aMAYUSCULAS = 0;
var aMINUSCULAS = 1;
var funcionExtra;	 // se creó para enviar el llenado de estado a la par de polizas
var comboFill;		// contiene el nombre del combo que se llenará con llenaCombo_CallBack
var valFill;		// contiene el nombre de la columna de la tabla que representa el valor en el combo que se llenará con llenaCombo_CallBack
var txtFill;		// contiene el nombre de la columna de la tabla representa el texto en el combo que se llenará con llenaCombo_CallBack

var NombreFuncionDrop;    //Contiene el nombre de la función que llena un Combo que se llena de manera automática posteriormente al llenado de un Combo que cuenta solo con un Elemento.
var comboFillAuto;        //Contiene el nombre del combo que se llena de manera automática posteriormente al llenado de un Combo que cuenta solo con un Elemento.
var bdrContinuar = false; //Sirve como bandera para indicar si se llenara de manera automática o no.

// Funcion que valida que tipo de explorador se esta utilizando
function validaBrowser() {
    var mz = document.getElementById && !document.all;
    if (mz) {
        return 'mz';
    } else {
        return 'ie';
    }
}

//funciones para autoajuste de un iframe version multibrowser
function getWindowData(n, i) {
    var ifr = parent.document.getElementById(i).contentWindow.document || parent.document.getElementById(i).contentDocument;
    var widthViewport, heightViewport, xScroll, yScroll, widthTotal, heightTotal;
    if (typeof ifr.documentElement != 'undefined' && typeof ifr.documentElement.clientWidth != 'undefined' && ifr.documentElement.clientWidth != 0) {
        widthViewport = ifr.documentElement.clientWidth;
        heightViewport = ifr.documentElement.clientHeight;
    } else {
        widthViewport = ifr.getElementsByTagName('body')[0].clientWidth;
        heightViewport = ifr.getElementsByTagName('body')[0].clientHeight;
    }
    xScroll = (ifr.documentElement.scrollLeft + ifr.body.scrollLeft);
    yScroll = (ifr.documentElement.scrollTop + ifr.body.scrollTop);
    widthTotal = Math.max(ifr.documentElement.scrollWidth, ifr.body.scrollWidth, widthViewport);
    heightTotal = Math.max(ifr.documentElement.scrollHeight, ifr.body.scrollHeight, heightViewport);
    return [widthViewport, heightViewport, xScroll, yScroll, widthTotal, heightTotal];
}
function resizeIframe(ID, NOMBRE) {
    window.location = '#';//necesario para safari
    var m = getWindowData(NOMBRE, ID);
    parent.document.getElementById(ID).height = m[5];
    parent.document.getElementById(ID).style.height = m[5] + "px";
}

function autofitIframe(id) {
    resizeIframe(id, id);
}

/***** VALIDACION DE CAPTURA *****/
//Valida la entrada de caracteres
function ValidaCaptura(evento, ExpReg) {
    var newKey;
    var valida = true;

    // El "event.srcElement.id" de IE es equivalente a "event.target.id" de NS.
    // obtiene el numero de la tecla dependiendo del tipo de navegador (keycode o which)
    if (evento.keyCode)
        newKey = evento.keyCode;
    else
        newKey = evento.which;

    // Valida el caracter que se esta ingresando
    if (!(navigator.appName == 'Netscape'))
        valida = validaCapturaIE(newKey, ExpReg);
    else
        valida = validaCapturaMZ(newKey, ExpReg);

    // Si no es valido, cancela el evento
    if (!valida) {
        // sentencias para cancelar el evento dependiendo del tipo de navegador
        if (evento.preventDefault) {
            evento.stopPropagation();
            evento.preventDefault();
        }
        else {
            evento.cancelBubble = true;
            evento.returnValue = false;
        }
    }
}
//Valida la entrada de caracteres en IE
function validaCapturaIE(newKey, ExpReg) {
    if (newKey != 13) {
        var teclaReal = String.fromCharCode(newKey);
        if (!(ExpReg.test(teclaReal)))
            return false;
    }
    return true;
}
//Valida la entrada de caracteres en Mozilla
function validaCapturaMZ(newKey, ExpReg) {
    // Se ignoran las teclas de Enter, Izquierda, Derecha, Suprimir, Tabulador y BackSpace
    if (newKey != 13 && newKey != 37 && newKey != 39 && newKey != 46 && newKey != 9 && newKey != 8) {
        var teclaReal = String.fromCharCode(newKey);
        if (!(ExpReg.test(teclaReal)))
            return false;
    }
    return true;
}

/***** VALIDACION DE CAPTURA *****/
//Convierte un caracter a Mayusculas o Minusculas
//function Convert(Evento, Convertir)
//{
//	if (!(navigator.appName == 'Netscape'))
//		ConvertIE(Evento, Convertir); // evento onKeyPress
//	else
//		ConvertMZ(Evento, Convertir); // evento onKeyUp
//}
function Convert(Convertir) {
    if (!(navigator.appName == 'Netscape')) {
        var Ev = window.event;

        if ((Ev) && (Ev.keyCode)) {
            var newKey = Ev.keyCode;

            if ((Convertir == aMAYUSCULAS) && ((newKey > 96) && (newKey < 123)) || (newKey == 225) || (newKey == 233) || (newKey == 237) || (newKey == 241) || (newKey == 243) || (newKey == 250) || (newKey == 252))
                newKey -= 32;  //Convierte un caracter a Mayusculas.
            else if ((Convertir == aMINUSCULAS) && ((newKey > 64) && (newKey < 91)) || (newKey == 193) || (newKey == 201) || (newKey == 205) || (newKey == 209) || (newKey == 211) || (newKey == 218) || (newKey == 220))
                newKey += 32;  //Convierte un caracter a Minusculas.

            Ev.keyCode = newKey;
        }
    }
    else {
        //if (Evento && Net) {
        //    var objCtrl = eval('document.' + document.forms[0].id + '.' + Evento.target.id);
        //    Cambiar(objCtrl, Convertir);
        //}
    }
}

//Convierte un caracter a Mayusculas o Minusculas en IE
function ConvertIE(evento, convertir) {
    var newKey;
    if (evento.keyCode)
        newKey = evento.keyCode;
    else
        newKey = evento.which;

    if ((convertir == aMAYUSCULAS) && ((newKey > 96) && (newKey < 123)) || (newKey == 225) || (newKey == 233) || (newKey == 237) || (newKey == 241) || (newKey == 243) || (newKey == 250) || (newKey == 252))
        newKey -= 32;  //Convierte un caracter a Mayusculas.
    else if ((convertir == aMINUSCULAS) && ((newKey > 64) && (newKey < 91)) || (newKey == 193) || (newKey == 201) || (newKey == 205) || (newKey == 209) || (newKey == 211) || (newKey == 218) || (newKey == 220))
        newKey += 32;  //Convierte un caracter a Minusculas.

    if (evento.keyCode)
        evento.keyCode = newKey;
    else
        evento.which = newKey;
}
//Convierte un caracter a Mayusculas o Minusculas en Mozilla
function ConvertMZ(control, convertir) {
    if (convertir == aMAYUSCULAS)
        control.value = control.value.toUpperCase();
    else if (convertir == aMINUSCULAS)
        control.value = control.value.toLowerCase();
}

var bPuntoPeso = true;
var bPuntoEstatura = true;
var valPeso = "";
var valPuntoEstatura = "";
function esNumero(evt, ctrl) {
    var charCode = (evt.which) ? evt.which : event.keyCode;

    if (ctrl.name == "txtPeso") {
        if ((charCode == 8 || (charCode > 47 && charCode < 58)) || (charCode == 46 && bPuntoPeso)) {
            if (charCode == 46 && bPuntoPeso) {
                bPuntoPeso = false;
            }
            return true;
        }
    }
    if (ctrl.name == "txtEstatura") {
        if ((charCode == 8 || (charCode > 47 && charCode < 58)) || (charCode == 46 && bPuntoEstatura)) {
            if (charCode == 46 && bPuntoEstatura) {
                bPuntoEstatura = false;
            }
            return true;
        }
    }

    return false;
}

function ValNumero(ctrl) {
    if (ctrl.name == "txtPeso") {
        var cadena = ctrl.value;
        if (cadena.indexOf(".") > -1) { bPuntoPeso = false; }
        else { bPuntoPeso = true; }
        //if (valor.includes('.')) {
        //    bPuntoPeso = false;
        //}
        //else {
        //    bPuntoPeso = true;
        //}
    }
    if (ctrl.name == "txtEstatura") {
        var cadena = ctrl.value;
        if (cadena.indexOf(".") > -1) { bPuntoEstatura = false; }
        else { bPuntoEstatura = true; }
        //var valor = ctrl.value;
        //if (valor.includes('.')) {
        //    bPuntoEstatura = false;
        //}
        //else {
        //    bPuntoEstatura = true;
        //}
    }
}

//Valida si representa una fecha
function isDate(day, month, year) {
    if (day.toString() != "" && month.toString() != "" && year.toString() != "") {
        month--;
        year = y2k(year);
        var fecha = new Date(year, month, day);
        if (day == fecha.getDate() && month == fecha.getMonth() && year == fecha.getFullYear())
            return true;
        else
            return false;
    }
    else
        return false;
}

//Valida el año de la fecha a verificar
function y2k(number) {
    var today = new Date();
    var year = today.getFullYear().toString().substring(2, 4);
    if (number.toString().length <= 2) {
        if (parseFloat(number) > parseFloat(year))
            number = parseFloat(number) + 1900;
        else number = parseFloat(number) + 2000;
    }
    return number;
}

// Función que recibe una tabla (res) y llena el combo indicado en las variables globales
function llenaCombo_CallBack(res) {
    limpiaCombo(comboFill);
    if (res.error == null) {
        if (res != null && res.value != null && res.value.Rows.length != 0) {
            oArray = new Array();
            oArray = valFill.split("|");
            var separador = "";

            if (oArray.length > 1)
                separador = ",";

            document.getElementById(comboFill).disabled = false;
            document.getElementById(comboFill).options[0] = new Option('Selecciona', 0, '', '');
            Ramo = document.all("HiddenRamoRequest").value;
            var c = 1;
            for (var i = 0; i < res.value.Rows.length; i++) {
                var valor = "";
                for (var j = 0; j < oArray.length; j++) {
                    var dato = '';
                    dato = eval("res.value.Rows[i]." + oArray[j]);
                    valor += dato + separador;
                }
                texto = eval("res.value.Rows[i]." + txtFill);
                //AEP BWMEILL. Modificación Millón Vida. Nuevo para los plazo de PPR.
                if (Ramo == "111" && comboFill == "drpPlazo") {
                    if ((document.getElementById("hdnPPR") != null || document.getElementById("hdnPPR") != undefined) && document.getElementById("hdnPPR").value == "S") {
                        if (texto == "5" || texto == "10") {
                            document.all[comboFill].options[c] = new Option(texto, valor, '', '');
                            c++;
                        }
                    }
                    else if (document.getElementById("hdnJubilacion") != null || document.getElementById("hdnJubilacion") != undefined) {
                        if (texto == "5" || texto == "10") {
                            document.all[comboFill].options[c] = new Option(texto, valor, '', '');
                            c++;
                        }
                    }
                    else {

                        //AEP BWMEILL. Modificación Millón Vida. Mostrar los plazos de años 5 y 10, antes estaba 1,3 y 5.
                        if (texto == "5" || texto == "10") {
                            document.all[comboFill].options[c] = new Option(texto, valor, '', '');
                            c++;
                        }
                    }
                }
                else if (Ramo == "111" && comboFill == "drpMoneda") {
                    //document.all[comboFill].nodeValue(6).disabled = true;
                    //AEP BWMEILL. Millón Vida Fase 2. Para eliminar monedas de UDIS de Domiciliación Bancaria
                    if (texto != "UNIDADES DE INVERSION" && texto != "PESOS" && document.getElementById("rbtMetodoPago_1").checked) {
                        document.all[comboFill].options[c] = new Option(texto, valor, '', '');
                        c++;
                    }
                    else if (texto != "UNIDADES DE INVERSION" && texto != "PESOS" && document.getElementById("rbtMetodoPago_0").checked) {
                        document.all[comboFill].options[c] = new Option(texto, valor, '', '');
                        c++;
                    }
                }
                else {
                    document.getElementById(comboFill).options[i + 1] = new Option(texto, valor, '', '');
                }
            }
            //cambiaCombo(comboFill);
        }
    }
    else alert(res.error);

    funcionExtra = "LlenadoEspecialDeDrop('" + comboFill + "'," + res.value.Rows.length + "," + bdrContinuar + ",'" + NombreFuncionDrop + "','" + comboFillAuto + "');";
    eval(funcionExtra);
    funcionExtra = "";
}


// Función que recibe una tabla (res) y llena el combo de Forma de Pago para el negocio de Millon Vida.
function llenaFormaPago_CallBack(res) {
    limpiaCombo(comboFill);
    if (res.error == null) {
        //Cambio para millon vida.
        var PlanRamo = document.getElementById("HiddenRamoRequest").value;

        if (res != null && res.value != null && res.value.Rows.length != 0) {
            oArray = new Array();
            oArray = valFill.split("|");
            var separador = "";

            if (oArray.length > 1)
                separador = ",";

            document.getElementById(comboFill).disabled = false;
            document.getElementById(comboFill).options[0] = new Option('Selecciona', 0, '', '');
            for (var i = 0; i < res.value.Rows.length; i++) {
                var valor = "";
                for (var j = 0; j < oArray.length; j++) {
                    var dato = '';
                    dato = eval("res.value.Rows[i]." + oArray[j]);
                    valor += dato + separador;
                }
                texto = eval("res.value.Rows[i]." + txtFill);
                if (PlanRamo == "111") {
                    if (texto == "CONTADO") {
                        document.getElementById(comboFill).options[1] = new Option(texto, valor, '', '');
                    }
                }
                else {
                    document.getElementById(comboFill).options[i + 1] = new Option(texto, valor, '', '');
                }
            }
        }
    }
    else alert(res.error);

    funcionExtra = "LlenadoEspecialDeDrop('" + comboFill + "'," + res.value.Rows.length + "," + bdrContinuar + ",'" + NombreFuncionDrop + "','" + comboFillAuto + "');";
    eval(funcionExtra);
    funcionExtra = "";

}


// Función que recibe una tabla (res) y llena el combo de Tipo de Pago según el negocio.
function llenaComboTipoPago_CallBack(res) {
    limpiaCombo(comboFill);
    var aux = 0;
    if (res.error == null) {
        //Cambio para millon vida.
        var PlanRamo = document.getElementById("HiddenRamoRequest").value;


        if (res != null && res.value != null && res.value.Rows.length != 0) {
            oArray = new Array();
            oArray = valFill.split("|");
            var separador = "";

            if (oArray.length > 1) {
                separador = ",";
            }

            document.getElementById(comboFill).disabled = false;
            document.getElementById(comboFill).options[0] = new Option('Selecciona', 0, '', '');
            for (var i = 0; i < res.value.Rows.length; i++) {
                var valor = "";
                for (var j = 0; j < oArray.length; j++) {
                    var dato = '';
                    dato = eval("res.value.Rows[i]." + oArray[j]);
                    valor += dato + separador;
                }
                texto = eval("res.value.Rows[i]." + txtFill);
                if (PlanRamo == "111") {
                    //AEP BWMEILL. Para seleccionar el tipo de agente de cobro dependiendo de la forma de pago. Millón Vida Fase 2
                    if (texto == "AGENTE" && document.getElementById("rbtMetodoPago_1").checked == true) {
                        document.getElementById(comboFill).options[1] = new Option(texto, valor, '', '');
                    }
                    if (texto == "BANCO CUENTA CLABE/DEBITO" && document.getElementById("rbtMetodoPago_0").checked == true) {
                        document.getElementById(comboFill).options[1] = new Option(texto, valor, '', '');
                    }
                }
                else if (PlanRamo == "112") {
                    var contrato = document.getElementById("hdncontrato").value;
                    //MU-2017-064392
                    if (contrato == "99999" || contrato == "19999")//UL Individual
                    //MU-2017-064392
                    {
                        if (texto == "BANCO CUENTA CLABE/DEBITO") {
                            aux = aux + 1;
                            document.getElementById(comboFill).options[aux] = new Option(texto, valor, '', '');
                        }
                        else if (texto == "TARJETA DE CREDITO") {
                            document.getElementById(comboFill).options[aux + 1] = new Option(texto, valor, '', '');
                        }
                        //if (texto == "AGENTE") {
                        //    document.getElementById(comboFill).options[1] = new Option(texto, valor, '', '');
                        //}
                    }
                    else {
                        if (texto == "AGENTE") {
                            document.getElementById(comboFill).options[1] = new Option(texto, valor, '', '');
                        }
                    }
                }
                //else
                //{
                //    document.getElementById(comboFill).options[i + 1] = new Option(texto, valor, '', '');
                //}
            }
        }
    }
    else alert(res.error);

    funcionExtra = "LlenadoEspecialDeDrop('" + comboFill + "'," + res.value.Rows.length + "," + bdrContinuar + ",'" + NombreFuncionDrop + "','" + comboFillAuto + "');";
    eval(funcionExtra);
    funcionExtra = "";

}


// Función que recibe una tabla (res) y llena el combo de Comisión (de acuerdo a su negocio) indicado en las variables globales
function llenaComboComision_CallBack(res) {
    limpiaCombo(comboFill);
    if (res.error == null) {
        //Cambio para millon vida.
        var PlanRamo = document.getElementById("HiddenRamoRequest").value;

        if (res != null && res.value != null && res.value.Rows.length != 0) {
            oArray = new Array();
            oArray = valFill.split("|");
            var separador = "";

            if (oArray.length > 1)
                separador = ",";

            document.getElementById(comboFill).disabled = false;
            document.getElementById(comboFill).options[0] = new Option('Selecciona', 0, '', '');

            for (var i = 0; i < res.value.Rows.length; i++) {
                var valor = "";
                for (var j = 0; j < oArray.length; j++) {
                    var dato = '';
                    dato = eval("res.value.Rows[i]." + oArray[j]);
                    valor += dato + separador;
                }
                texto = eval("res.value.Rows[i]." + txtFill);
                if (PlanRamo == "111") {
                    if (texto == "NIVELADA") {
                        document.getElementById(comboFill).options[1] = new Option(texto, valor, '', '');
                    }
                }
                else {
                    document.getElementById(comboFill).options[i + 1] = new Option(texto, valor, '', '');
                }
            }
            //cambiaCombo(comboFill);
        }
    }
    else alert(res.error);


    funcionExtra = "LlenadoEspecialDeDrop('" + comboFill + "'," + res.value.Rows.length + "," + bdrContinuar + ",'" + NombreFuncionDrop + "','" + comboFillAuto + "');";
    eval(funcionExtra);
    funcionExtra = "";

    var funcionExtraModalidad = "ObtenerModalidad();"
    eval(funcionExtraModalidad);
}

// Función que recibe una tabla (res) y llena el combo de Forma de Pago (de acuerdo a su negocio) indicado en las variables globales
function llenaComboFormaPago_CallBack(res) {
    limpiaCombo(comboFill);
    if (res.error == null) {
        if (res != null && res.value != null && res.value.Rows.length != 0) {
            oArray = new Array();
            oArray = valFill.split("|");
            var separador = "";

            if (oArray.length > 1)
                separador = ",";

            document.getElementById(comboFill).disabled = false;
            document.getElementById(comboFill).options[0] = new Option('Selecciona', 0, '', '');
            for (var i = 0; i < res.value.Rows.length; i++) {
                var valor = "";
                for (var j = 0; j < oArray.length; j++) {
                    var dato = '';
                    dato = eval("res.value.Rows[i]." + oArray[j]);
                    valor += dato + separador;
                }
                texto = eval("res.value.Rows[i]." + txtFill);
                document.getElementById(comboFill).options[i + 1] = new Option(texto, valor, '', '');
            }
            //cambiaCombo(comboFill);
        }
    }
    else alert(res.error);

    funcionExtra = "LlenarPlanyMoneda('drpMoneda');";
    eval(funcionExtra);
    funcionExtra = "";
}

// Limpia combo
//Vacia los resultados anteriores en el combo
function limpiaCombo(combo) {
    for (i = document.getElementById(combo).options.length; i >= 0; i--) {
        document.getElementById(combo).options[i] = null;
    }
    document.getElementById(combo).disabled = true;
}

// Devuelve el valor seleccionado de un DropDownList
function selIndex(nameSelect) {
    val = document.getElementById(nameSelect).options[document.getElementById(nameSelect).selectedIndex].value;
    return val;
}

function selIndexText(nameSelect) {
    val = document.getElementById(nameSelect).options[document.getElementById(nameSelect).selectedIndex].text;
    return val;
}

// Permite autoseleccionar el elemento existente cuando el combo solo tiene un elemento
function cambiaCombo(nombreCtrl) {
    var combo = document.getElementById(nombreCtrl);
    var ind = combo.length;
    if (ind == 2) {
        if (combo.selectedIndex == 0) {
            combo.selectedIndex = 1;
            var FunChange = combo.onchange;

            try {
                if (FunChange != null)
                    FunChange();
            }
            catch (e) { }
        }
    }
}


///// Funciones Validadores /////
// Valida que este seleccionado algun item en la lista desplegable
function validaCombo(source, arguments) {
    if (selIndiceCtrl(source.controltovalidate) <= 0)
        arguments.IsValid = false;
    else arguments.IsValid = true;
}

// Funcion para presentar cantidades con formato de moneda
function formatCurrency(num) {
    num = num.toString().replace(/\$|\,/g, '');
    if (isNaN(num))
        num = "0";
    sign = (num == (num = Math.abs(num)));
    num = Math.floor(num * 100 + 0.50000000001);
    cents = num % 100;
    num = Math.floor(num / 100).toString();
    if (cents < 10)
        cents = "0" + cents;
    for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++)
        num = num.substring(0, num.length - (4 * i + 3)) + ',' + num.substring(num.length - (4 * i + 3));
    return (((sign) ? '' : '-') + '$' + num + '.' + cents);
}

// Funcion para redondear un numero
function Redondear(num, dec) {
    num = parseFloat(num);
    dec = parseFloat(dec);
    dec = (!dec ? 2 : dec);
    return Math.round(num * Math.pow(10, dec)) / Math.pow(10, dec);
}

/***********************************************
   FUNCIONES GENERALES PARA MOSTRAR TOOLTIPS
***********************************************/
// Muestra cuadro de ayuda con mensaje
function tip(msg, backC, borderC, fontC) {
    var content = "<table width=300 border=1 bordercolor=" + borderC + " cellpadding=2 cellspacing=0 bgcolor=" + backC + ">" +
        "<tr><td align=center><table width='95%'><tr>" +
        "<td style='text-align:justify'><font color=" + fontC + ">" + msg + "</font></td></tr></table></td></tr></table>";//style="font-weight:bold"
    yyy = Yoffset;
    if (ns4) { skn.document.write(content); skn.document.close(); skn.visibility = "visible"; }
    if (ns6) { document.getElementById("dek").innerHTML = content; skn.display = ''; }
    if (ie4) { document.all("dek").innerHTML = content; skn.display = ''; }
}

// Obtiene posicion del mouse
function get_mouse(e) {
    var x = (ns4 || ns6) ? e.pageX : event.x + document.body.scrollLeft;
    if (parseInt(x) > parseInt(document.body.scrollWidth / 2))
        Xoffset = -350;
    else Xoffset = -50;
    skn.left = x + Xoffset;
    var y = (ns4 || ns6) ? e.pageY : event.y + document.body.scrollTop;
    skn.top = y + yyy;
}

// Quita el cuadro de ayuda
function termina() {
    yyy = -1000;
    if (ns4) { skn.visibility = "hidden"; }
    else if (ns6 || ie4)
        skn.display = "none";
}

// Función que manipúla los controles label para funcionalidad en Internet Explorer,
// Mozilla, Safari, etc 
function manejoLabel(nombreLabel, asignar) {
    var control;
    control = eval(document.getElementById(nombreLabel));
    if (control.tagName == "SPAN" || control.tagName == "DIV" || control.tagName == "A") {
        if (asignar != undefined) {
            if (typeof (asignar) != "string" && typeof (asignar) != "number")
                return alert("El tipo de dato no es válido");
            for (var j = 0; j < control.childNodes.length; j++)
                control.removeChild(control.childNodes[j]);
            control.appendChild(document.createTextNode(asignar));
            return;
        }
        m_texto = "";
        for (var i = 0; i < control.childNodes.length; i++) {
            if (control.childNodes[i].nodeName == "#text") {
                m_texto += control.childNodes[i].nodeValue;
            }
            else {
                m_texto += control.childNodes[i].firstChild.nodeValue;
            }
        }
    }
    return m_texto;
}

//Funcion que valida que solo se puedan accesar numeros
function KeyNumber(myfield, e) {
    if (((event.keyCode >= 48) && (event.keyCode <= 57))) { return true; }
    else return false;
}

//Abre el calendario y envia el nombre del control al cual se le pasará la fecha
function GetDate(CtrlName, CtrlName2, CtrlName3, meses, BackForward, ValFec, ValParte, anioAnt) {
    ChildWindow = window.open('../general/calendario/TWcalendario.aspx?FormName=' + document.forms[0].name + '&CtrlName=' + CtrlName + '&CtrlName2=' + CtrlName2 + '&CtrlName3=' + CtrlName3 + '&Meses=' + meses + '&BackForward=' + BackForward + '&ValFec=' + ValFec + '&ValParte=' + ValParte + '&anioAnt=' + anioAnt, "PopUpCalendar", "width=180,height=180,top=200,left=250, toolbars=no,scrollbars=no,status=no,resizable=no");
    ChildWindow.focus();
    AjustarFrame();
}


/***********************************************************/
/////////////////////////////////////////////////////////////
///// CLASE PARA ACCEDER A LAS PROPIEDADES DE CONTROLES /////
/////////////////////////////////////////////////////////////
/***********************************************************/
function clsControl(control) {
    // variables privadas
    var m_valor = "";
    var m_texto = "";
    var m_habilitado = true;
    var m_visible = true;
    var m_display = true;
    var m_checked = true;
    var m_indice = 0;

    // metodos publicos
    this.valor = function (asignar) {
        switch (control.type) {
            case undefined:
            case "undefined":
                if (control.tagName == "SPAN") {
                    if (asignar != undefined) {
                        if (typeof (asignar) != "string" && typeof (asignar) != "number")
                            return alert("El tipo de dato no es válido");
                        control.innerText = asignar;
                    }
                    m_valor = control.innerText;
                }
                break;
            case "select-one":
                if (asignar != undefined) {
                    if (typeof (asignar) != "string" && typeof (asignar) != "number")
                        return alert("El tipo de dato no es válido");
                    for (i = 0; i < control.options.length; i++) {
                        if (control.options[i].value == asignar) {
                            control.options[i].selected = true;
                            return;
                        }
                    }
                }
                m_valor = control.options[control.selectedIndex].value;
                break;
            default:
                if (asignar != undefined) {
                    if (typeof (asignar) != "string" && typeof (asignar) != "number")
                        return alert("El tipo de dato no es válido");
                    control.value = asignar;
                }
                m_valor = control.value;
                break;
        }

        return m_valor;
    }

    this.texto = function (asignar) {
        switch (control.type) {
            case undefined:
            case "":
                if (control.tagName == "SPAN" || control.tagName == "A") {
                    if (asignar != undefined) {
                        if (typeof (asignar) != "string" && typeof (asignar) != "number")
                            return alert("El tipo de dato no es válido");
                        for (var j = 0; j < control.childNodes.length; j++)
                            control.removeChild(control.childNodes[j]);
                        control.appendChild(document.createTextNode(asignar));
                    }
                    m_texto = "";
                    for (var i = 0; i < control.childNodes.length; i++) {
                        if (control.childNodes[i].nodeName == "#text")
                            m_texto += control.childNodes[i].nodeValue;
                        else m_texto += control.childNodes[i].firstChild.nodeValue;
                        //m_texto = control.textContent; // solo mozzilla
                        //m_texto = control.innerText;
                    }
                }
                break;
            case "select-one":
                if (asignar != undefined) {
                    if (typeof (asignar) != "string" && typeof (asignar) != "number")
                        return alert("El tipo de dato no es válido");
                    for (i = 0; i < control.options.length; i++) {
                        if (control.options[i].text == asignar) {
                            control.options[i].selected = true;
                            return;
                        }
                    }
                }
                m_texto = control.options[control.selectedIndex].text;
                break;
            case "checkbox":
                if (asignar != undefined) {
                    if (typeof (asignar) != "string" && typeof (asignar) != "number")
                        return alert("El tipo de dato no es válido");
                    m_texto = control.textContent = asignar;
                }
                m_texto = control.innerText;
                break;
            default:
                if (asignar != undefined) {
                    if (typeof (asignar) != "string" && typeof (asignar) != "number")
                        return alert("El tipo de dato no es válido");
                    control.value = asignar;
                }
                m_texto = control.value;
                break;
        }

        return m_texto;
    }

    this.selValor = function (posicion) {
        switch (control.type) {
            case "select-one":
                m_valor = this.valor();
                if (posicion != undefined) {
                    if (isNaN(parseInt(posicion)))
                        return alert("El tipo de dato no es válido");
                    var arrValor = new Array();
                    arrValor = m_valor.split(",");
                    m_valor = arrValor[posicion];
                }
                break;
            default:
                return alert("El control '" + control.id + "' no puede acceder a esta propiedad");
                break;
        }
        return m_valor;
    }

    this.selIndice = function (indice) {
        switch (control.type) {
            case "select-one":
                if (indice != undefined) {
                    if (typeof (indice) != "number")
                        return alert("El tipo de dato no es válido");
                    control.selectedIndex = indice;
                }
                m_indice = control.selectedIndex;
                break;
            default:
                return alert("El control '" + control.id + "' no puede acceder a esta propiedad");
                break;
        }
        return m_indice;
    }

    this.habilitar = function (asignar) {
        if (asignar != undefined) {
            if (typeof (asignar) != "boolean")
                return alert("El tipo de dato no es válido");
            control.disabled = !asignar;
        }
        m_habilitado = !control.disabled;

        return m_habilitado;
    }

    this.visible = function (asignar) {
        if (asignar != undefined) {
            var mostrar = "";
            if (asignar == true)
                mostrar = "visible";
            else if (asignar == false)
                mostrar = "hidden";
            else return alert("El tipo de dato no es válido");
            control.style.visibility = mostrar;
        }
        if (control.style.visibility == "hidden")
            m_visible = false;
        else m_visible = true;

        return m_visible;
    }

    this.display = function (asignar) {
        if (asignar != undefined) {
            var mostrar = "";
            if (asignar == true)
                mostrar = "inline";
            else if (asignar == false)
                mostrar = "none";
            else return alert("El tipo de dato no es válido");
            control.style.display = mostrar;
        }
        if (control.style.display == "none")
            m_display = false;
        else m_display = true;

        return m_display;
    }

    this.checked = function (asignar) {
        if (control.type == "checkbox" || control.type == "radio") {
            if (asignar != undefined) {
                if (typeof (asignar) != "boolean")
                    return alert("El tipo de dato no es válido");
                control.checked = asignar;
            }
            m_checked = control.checked;
        }
        else return alert("El control '" + control.id + "' no puede acceder a esta propiedad");

        return m_checked;
    }

    this.focus = function () {
        if (control.focus != undefined) {
            control.focus();
        }
    }
}

////////////////////////////////////////////////////
///// FUCNIONES PARA MODIFICAR LAS PROPIEDADES /////
////////////////////////////////////////////////////

// Obtiene y asigna el valor a un control
function valorCtrl(nombreCtrl, valor) {
    var control = document.getElementById(nombreCtrl);
    if (control != null) {
        try {
            var objControl = new clsControl(control);
            if (valor == undefined)
                return objControl.valor();
            else objControl.valor(valor);
        }
        catch (ex) {
            alert(ex.name + " valorCtrl(): " + ex.description);
        }
    }
}

// Obtiene y asigna el texto a un control
function textoCtrl(nombreCtrl, valor) {
    var control = document.getElementById(nombreCtrl);
    if (control != null) {
        try {
            var objControl = new clsControl(control);
            if (valor == undefined)
                return objControl.texto();
            else objControl.texto(valor);
        }
        catch (ex) {
            alert(ex.name + " textoCtrl(): " + ex.description);
        }
    }
}

// Obtiene uno de los valores de un combo mediante un indice
function selValorCtrl(nombreCtrl, valor) {
    var control = document.getElementById(nombreCtrl);
    if (control != null) {
        try {
            var objControl = new clsControl(control);
            return objControl.selValor(valor);
        }
        catch (ex) {
            alert(ex.name + " selValorCtrl(): " + ex.description);
        }
    }
}

function selIndiceCtrl(nombreCtrl, indice) {
    var control = document.getElementById(nombreCtrl);
    if (control != null) {
        try {
            var objControl = new clsControl(control);
            if (indice == undefined)
                return objControl.selIndice();
            else objControl.selIndice(indice);
        }
        catch (ex) {
            alert(ex.name + " selIndiceCtrl(): " + ex.description);
        }
    }
}

// Habilita o inhabilita un control
function habilitarCtrl(nombreCtrl, valor) {
    var control = document.getElementById(nombreCtrl);
    if (control != null) {
        try {
            var objControl = new clsControl(control);
            if (valor == undefined)
                return objControl.habilitar();
            else objControl.habilitar(valor);
        }
        catch (ex) {
            alert(ex.name + " habilitarCtrl(): " + ex.description);
        }
    }
}

// Hace visible o invisible un control
function visibleCtrl(nombreCtrl, valor) {
    var control = document.getElementById(nombreCtrl);
    if (control != null) {
        try {
            var objControl = new clsControl(control);
            if (valor == undefined)
                return objControl.visible();
            else objControl.visible(valor);
        }
        catch (ex) {
            alert(ex.name + " visibleCtrl(): " + ex.description);
        }
    }
}

// Muestra u oculta un control
function displayCtrl(nombreCtrl, valor) {
    var control = document.getElementById(nombreCtrl);
    if (control != null) {
        try {
            var objControl = new clsControl(control);
            if (valor == undefined)
                return objControl.display();
            else objControl.display(valor);
        }
        catch (ex) {
            alert(ex.name + " displayCtrl(): " + ex.description);
        }
    }
}

// Selecciona o un checkbox o un radio
function checkCtrl(nombreCtrl, valor) {
    var control = document.getElementById(nombreCtrl);
    if (control != null) {
        try {
            var objControl = new clsControl(control);
            if (valor == undefined)
                return objControl.checked();
            else objControl.checked(valor);
        }
        catch (ex) {
            alert(ex.name + " checkCtrl(): " + ex.description);
        }
    }
}

// Manda el foco al control
function focusCtrl(nombreCtrl) {
    var control = document.getElementById(nombreCtrl);
    if (control != null) {
        try {
            var objControl = new clsControl(control);
            objControl.focus();
        }
        catch (ex) { }
    }
}

/////////////////////////////////////////////////////////////////////////////
//MU-2017-052841 INI
function validateEmail(sEmail) {
    var reEmail = /^(?:[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+\.)*[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+@(?:(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!\.)){0,61}[a-zA-Z0-9]?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!$)){0,61}[a-zA-Z0-9]?)|(?:\[(?:(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\.){3}(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\]))$/;
    if (sEmail != "") {
        if (!sEmail.match(reEmail)) {
            alert("Direccion de Email Invalida");
            focusCtrl("txtMail");
            return false;
        }
    }
    return true;
}
//MU-2017-052841 FIN

//Convierte a dia mes y año

function formatDate(inputDate) {

    return `${inputDate.split('-')[2]}/${inputDate.split('-')[1]}/${inputDate.split('-')[0]}`;
}