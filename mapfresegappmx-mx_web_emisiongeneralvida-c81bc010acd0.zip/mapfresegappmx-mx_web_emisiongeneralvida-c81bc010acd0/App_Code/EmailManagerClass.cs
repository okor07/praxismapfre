﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net.Mail;


/// <summary>
/// Clase para el envío de Correo electrónico.
/// </summary>
public class EmailManagerClass
{
	
    #region Constructor

        public EmailManagerClass()
        {

        }

    #endregion

    #region Methods

        /// <summary>
        /// Método para enviar Correo Sin Archivo Adjunto.
        /// </summary>
        /// <param name="from">Parámetro de tipo cadena para almacenar quien envía el correo.</param>
        /// <param name="to">Parámetro de tipo cadena para almacenar a quien estará dirigido el correo.</param>
        /// <param name="cc">Parámetro de tipo cadena para almacenar a quien se le enviará copia.</param>
        /// <param name="subject">Parámetro de tipo cadena para almacenar el Asunto.</param>
        /// <param name="body">Parámetro de tipo cadena para almacenar el Contenido del Correo.</param>
        /// <returns>Regresa un campo de tipo bool que funciona como bandera para indicar si el correo pudo ser enviado o no.</returns>
        public bool SendEmail(string from, string to, string cc, string subject, string body)
        {
            return SendEmailWithAttachment(from, to, cc, subject, body, String.Empty);
        }

        /// <summary>
        /// Método para enviar Correo sin copia y sin archivo Adjunto.
        /// </summary>
        /// <param name="from">Parámetro de tipo cadena para almacenar quien envía el correo.</param>
        /// <param name="to">Parámetro de tipo cadena para almacenar a quien estará dirigido el correo.</param>
        /// <param name="subject">Parámetro de tipo cadena para almacenar el Asunto.</param>
        /// <param name="body">Parámetro de tipo cadena para almacenar el Contenido del Correo.</param>
        /// <returns>Regresa un campo de tipo bool que funciona como bandera para indicar si el correo pudo ser enviado o no.</returns>
        public bool SendEmail(string from, string to, string subject, string body)
        {
            return SendEmailWithAttachment(from, to, String.Empty, subject, body, String.Empty);
        }

        /// <summary>
        /// Método para enviar correo sin copia con archivo Adjunto.
        /// </summary>
        /// <param name="from">Parámetro de tipo cadena para almacenar quien envía el correo.</param>
        /// <param name="to">Parámetro de tipo cadena para almacenar a quien estará dirigido el correo.</param>
        /// <param name="subject">Parámetro de tipo cadena para almacenar el Asunto.</param>
        /// <param name="body">Parámetro de tipo cadena para almacenar el Contenido del Correo.</param>
        /// <param name="attachment">Parámetro de tipo cadena para almacenar la ruta del archivo que será Adjuntado.</param>
        /// <returns>Regresa un campo de tipo bool que funciona como bandera para indicar si el correo pudo ser enviado o no.</returns>
        public bool SendEmailWithAttachment(string from, string to, string subject, string body, string attachment)
        {
            return SendEmailWithAttachment(from, to, String.Empty, subject, body, attachment);
        }
        
        /// <summary>
        /// Método para enviar Correo con copia y con archivo Adjunto.
        /// </summary>
        /// <param name="from">Parámetro de tipo cadena para almacenar quien envía el correo.</param>
        /// <param name="to">Parámetro de tipo cadena para almacenar a quien estará dirigido el correo.</param>
        /// <param name="cc">Parámetro de tipo cadena para almacecar a quien se le enviará copia.</param>
        /// <param name="subject">Parámetro de tipo cadena para almacenar el Asunto.</param>
        /// <param name="body">Parámetro de tipo cadena para almacenar el Contenido del Correo.</param>
        /// <param name="attachment">Parámetro de tipo cadena para almacenar la ruta del archivo que será Adjuntado.</param>
        /// <returns>Regresa un campo de tipo bool que funciona como bandera para indicar si el correo pudo ser enviado o no.</returns>
        public bool SendEmailWithAttachment(string from, string to, string cc, string subject, string body, string attachment)
        {
            MailMessage correo = new MailMessage();
            try
            {
                correo.From = new MailAddress(from);
                correo.To.Add(new MailAddress(to));

                if (!String.IsNullOrEmpty(cc))
                    correo.CC.Add(new MailAddress(cc));

                correo.Subject = subject;
                correo.Body = body;
                correo.IsBodyHtml = true;

                if (!String.IsNullOrEmpty(attachment))
                    correo.Attachments.Add(new Attachment(attachment));

                string resultadoServicio = string.Empty;

                try
                {
                    SmtpClient sender1 = new SmtpClient(ConfigurationManager.AppSettings["ServidorSMTP"].ToString());
                    sender1.Send(correo);

                    correo = null;

                    return true;
                }
                catch(Exception ex)
                {
                    MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
                    correo = null;
                    _ErrorMessage = ex.Message;
                    return false;
                }
            }
            catch(Exception ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
                _ErrorMessage = ex.Message;
                return false;
            }
        }

    #endregion

    #region Fields

    private string _ErrorMessage;

    #endregion

    #region Properties

    public string ErrorMessage
    {
        get { return _ErrorMessage; }
        set { _ErrorMessage = value; }
    }

    #endregion

}

