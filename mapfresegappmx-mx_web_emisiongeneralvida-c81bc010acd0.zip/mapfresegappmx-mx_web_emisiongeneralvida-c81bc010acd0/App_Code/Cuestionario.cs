//'********************************************************************************************************************
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2010
//'Name of the file              : clsDocumentum.cs
//'Creation/Modification History :
//'Modification                  : 
//                               
//'********************************************************************************************************************

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Oracle.DataAccess.Client;
using MapfreMMX.oracle;

/// <summary>
/// Summary description for Cuestionario
/// </summary>
public class Cuestionario
{


    public static DataTable getPreguntas(int cod_formulario)
    {
        DataSet objDS = new DataSet();
        MCommand cmd = new MCommand();
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "EV_K_VALIDA_EMI_VIDASEGA.P_RECUPERA_CUESTIONARIO";

                cmd.agregarINParametro("p_cod_cia", OracleDbType.Double, 1);
                cmd.agregarINParametro("p_cod_formulario", OracleDbType.Double, cod_formulario);
                cmd.agregarOUTParametro("p_val_preguntas", OracleDbType.RefCursor, 0);

                objDS = cmd.ejecutarRefCursorSP();
            }

            if (objDS.Tables[0].Rows.Count < 1)
                throw new Exception("No hay datos");

            return objDS.Tables[0];

        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR EV_K_VALIDA_EMI_VIDASEGA.P_RECUPERA_CUESTIONARIO: " + ex.Message);
        }
    }
}
