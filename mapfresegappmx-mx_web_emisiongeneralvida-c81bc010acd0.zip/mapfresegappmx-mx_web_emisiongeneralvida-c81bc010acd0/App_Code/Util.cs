﻿////Agregado de recuperacion de telefono del usuario loggeado

using MapfreMMX.oracle;
using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Util
/// </summary>
public class Util
{
    public Util()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public string getTelefono (int COD_USUARIO)
    {
        MCommand cmd = new MCommand();
        string objDR = null;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionSeGA"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "TS_K_SEGA_GENERAL.P_LEE_USUARIO2";

                cmd.agregarINParametro("COD_USUARIO", OracleDbType.Int32, COD_USUARIO);
                cmd.agregarOUTParametro("p_telefono", OracleDbType.Varchar2, 10);
                cmd.agregarOUTParametro("p_error", OracleDbType.Varchar2, 255);

                DataRow dataRow = cmd.ejecutarRegistroSP();
                if (dataRow["p_error"] == DBNull.Value)
                {
                    objDR = dataRow["p_telefono"].ToString();
                }

            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Util.getTelefono() : " + ex.Message);
        }
        return objDR;
    }
}