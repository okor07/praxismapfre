﻿//'********************************************************************************************************************
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2010
//'Name of the file              : FolioRAM.cs
//'Creation/Modification History :
//'Modification                  : 
//09052018                               
//'********************************************************************************************************************

using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MapfreMMX.util;

/// <summary>
/// Summary description for FolioRAM
/// </summary>
public class FolioRAM:Page
{
    private DatosVidaClass ObjVida = new DatosVidaClass();
    
    public FolioRAM()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public string crearFolioRAMCotizacion(string strNoSolicitud, string COD_DOCUMT, string NOM_TERCEROT, string COD_ESTADOT)
    {
        try
        {

            //Primero Insertaremos los Beneficiarios en un Arreglo.
            try
            {
                MetodosAjax objMetodosAjax = new MetodosAjax();
                DataTable dtBenef = objMetodosAjax.generaCodDocumBENEF();
                Catalogos objCatalogos = new Catalogos();

                int Secu = 0;
                int prim = 0;

                foreach (DataRow dr in dtBenef.Rows)
                {
                    Secu++;
                    string strTipBenef = dr["tip_benef"].ToString();
                    if (strTipBenef == "6")
                    {
                        prim++;
                        Secu = 0;
                    }

                    string tipDocum = dr["tip_docum"].ToString();
                    string codDocum = dr["cod_docum"].ToString();
                    string porcentaje = dr["porcentaje"].ToString();
                    int numSecu = 0;
                    if (strTipBenef == "6")
                        numSecu = prim;
                    else
                        numSecu = Secu;


                    DataRow drMsg = objCatalogos.InsertarBenefEnSol(strNoSolicitud, tipDocum, codDocum, strTipBenef, porcentaje, numSecu);
                    string strMensaje = drMsg[0].ToString();

                    if (strMensaje != "S")
                        throw new Exception("No se Pudo insertar el Beneficiario");
                }
            }
            catch (Exception ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
                throw new Exception(ex.Message);
            }

            
            
            string FolioRAM = "";
            string strIDSistema = "";
            string objFolio = "";

            //Asigna Agente
            ObjVida.CodAgt = Session["COD_AGT"].ToString();

            //Obtiene el ID WF_ALTA_OT
            ObjVida.AltaFolioRam();

            // Agregar a sesión el RFC del titular para la obtención del tipo de examen médico.
            Session["RFCTitular"] = COD_DOCUMT;

            //Con el ID WF_ALTA_OT Obtengo el Folio en MSP_ALTA_FOLIO_SI24
            objFolio = ObjVida.GrabaFolioyOficinaSol();

            //Con el Folio Grabo en TronWeb
            ObjVida.GrabaFolioTW(strNoSolicitud);

            //Con el Folio Grabo en Tabla Fol008
            ObjVida.fnGrabaFol008(NOM_TERCEROT, strNoSolicitud, COD_ESTADOT);

            //Con el Folio Grabo en Tabla MSP_TRASPASO_FOLVIDA
            ObjVida.MSP_TRASPASO_FOLVIDA();

            if(Session["FolioRAM"] != null)
                FolioRAM = Session["FolioRAM"].ToString();
            if (Session["p_wf_ot_m_ot"] != null)
                strIDSistema = Session["p_wf_ot_m_ot"].ToString();

            return FolioRAM + "|" + strIDSistema;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }

    }

    public string crearFolioRAMPoliza(string strNoPoliza, string COD_DOCUMT, string NOM_TERCEROT, string COD_ESTADOT, 
        string codRamo)
    {
        try
        {

            //Primero Insertaremos los Beneficiarios en un Arreglo.
            try
            {
                MetodosAjax objMetodosAjax = new MetodosAjax();
                DataTable dtBenef = objMetodosAjax.generaCodDocumBENEF();
                Catalogos objCatalogos = new Catalogos();

                int Secu = 0;
                int prim = 0;

                foreach (DataRow dr in dtBenef.Rows)
                {
                    Secu++;
                    string strTipBenef = dr["tip_benef"].ToString();
                    if (strTipBenef == "6")
                    {
                        prim++;
                        Secu = 0;
                    }

                    string tipDocum = dr["tip_docum"].ToString();
                    string codDocum = dr["cod_docum"].ToString();
                    string porcentaje = dr["porcentaje"].ToString();
                    int numSecu = 0;
                    if (strTipBenef == "6")
                        numSecu = prim;
                    else
                        numSecu = Secu;


                    DataRow drMsg = objCatalogos.InsertarBenefEnSol(strNoPoliza, tipDocum, codDocum, strTipBenef, porcentaje, numSecu);
                    string strMensaje = drMsg[0].ToString();

                    if (codRamo == "105")
                    {
                    }
                    else
                    {
                        if (strMensaje != "S")
                            throw new Exception("No se Pudo insertar el Beneficiario");
                    }
                }
            }
            catch (Exception ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
                throw new Exception(ex.Message);
            }



            string FolioRAM = "";
            string strIDSistema = "";
            string objFolio = "";

            ObjVida.CodAgt = Session["COD_AGT"].ToString();

            //Obtiene el ID WF_ALTA_OT
            ObjVida.AltaFolioRam();

            // Agregar a sesión el RFC del titular para la obtención del tipo de examen médico.
            Session["RFCTitular"] = COD_DOCUMT;

            //Con el ID WF_ALTA_OT Obtengo el Folio en MSP_ALTA_FOLIO
            objFolio = ObjVida.GrabaFolioyOficinaPol();

            //Con el Folio Grabo en TronWeb tabla P2000020
            ObjVida.ActualizarFolio(strNoPoliza, "0", objFolio);

            //Con el Folio Grabo en Tabla Fol008
            //ObjVida.fnGrabaFol008(objFolio, NOM_TERCEROT, strNoPoliza, COD_ESTADOT);

            //Con el Folio Grabo en Tabla MSP_ALTA_POL_VIDA
            ObjVida.grabaMSP_ALTA_FOLIO_VIDA(codRamo, NOM_TERCEROT, COD_DOCUMT,strNoPoliza);

            if (Session["FolioRAM"] != null)
                FolioRAM = Session["FolioRAM"].ToString();
            if (Session["p_wf_ot_m_ot"] != null)
                strIDSistema = ObjVida.NumOT;

            return FolioRAM + "|" + strIDSistema;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }

    }    
}
