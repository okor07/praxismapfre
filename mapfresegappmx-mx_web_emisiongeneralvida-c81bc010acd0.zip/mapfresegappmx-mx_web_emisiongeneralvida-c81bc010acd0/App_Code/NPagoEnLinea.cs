﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml;
using System.Text;
using System.Collections;
using Oracle.DataAccess.Client;
using MapfreMMX.oracle;
using MapfreMMX.emision;
using MapfreMMX.util;

/// <summary>
/// Summary description for NPagoEnLinea
/// </summary>
public class NPagoEnLinea
{
    private string num_poliza;
    private McaAutorizaRechaza mca_autoriza_rechaza;
    private StringBuilder xml_cobranza;
    private XmlNode xml_respuesta;
    private string num_autorizacion;
    private string txt_rechazo;
    private string cod_entidad;
    private string nom_tercero;
    private string nombre, paterno, materno;
    private int mes_exp_tarjeta;
    private int anio_exp_tarjeta;
    private string num_tarjeta;
    private string cod_tarjeta;
    private double monto;
    private string tip_tarjeta;
    private string num_referencia;
    private string msi;
    //AEP Cambio MV
    private string facfinal;

    public string Msi
    {
        get { return msi; }
        set { msi = value; }
    }

    public enum McaAutorizaRechaza
    {
        Autoriza,
        Rechaza
    }

    //AEP Cambio MV
    /// <summary>Factor de conversión</summary>
    public string factor
    {
        get { return facfinal; }
        set { facfinal = value; }
    }

    /// <summary>Número de póliza</summary>
    public string NumPoliza
    {
        get { return num_poliza; }
        set { num_poliza = value; }
    }

    /// <summary>Marca para Autorizar o Rechazar la póliza</summary>
    public McaAutorizaRechaza MarcaAR
    {
        get { return mca_autoriza_rechaza; }
        set { mca_autoriza_rechaza = value; }
    }

    /// <summary>XML para que se envía al web service y generar el pago en línea.</summary>
    public StringBuilder XML_Pago
    {
        get { return xml_cobranza; }
        set { xml_cobranza = value; }
    }

    /// <summary>Número de autorización que regresa el banco.</summary>
    public string NumAutorizacion
    {
        get { return num_autorizacion; }
        set { num_autorizacion = value; }
    }

    /// <summary>Mensaje de rechazo que regresa el banco.</summary>
    public string MsgRechazo
    {
        get { return txt_rechazo; }
        set { txt_rechazo = value; }
    }

    /// <summary>Código del Banco.</summary>
    public string CodBanco
    {
        get { return cod_entidad; }
        set { cod_entidad = value; }
    }

    /// <summary>Nombre completo del Propietario de la tarjeta de crédito.</summary>
    public string NomTercero
    {
        get { return nom_tercero; }
        set { nom_tercero = value; }
    }

    /// <summary>Nombre del tutular para después armar el Nombre completo del Propietario de la tarjeta de crédito'<b>NomTercero</b>'.</summary>
    public string NombreTitular
    {
        get { return nombre; }
        set
        {
            nombre = value;
            nom_tercero = value + " " + paterno + " " + materno;
        }
    }

    /// <summary>Apellido paterno del tutular para después armar el nombre completo del Propietario de la tarjeta de crédito'<b>NomTercero</b>'.</summary>
    public string APaternoTitular
    {
        get { return paterno; }
        set
        {
            paterno = value;
            nom_tercero = nombre + " " + value + " " + materno;
        }
    }

    /// <summary>Apellido materno del tutular para después armar el nombre completo del Propietario de la tarjeta de crédito'<b>NomTercero</b>'.</summary>
    public string AMaternoTitular
    {
        get { return materno; }
        set
        {
            materno = value;
            nom_tercero = nombre + " " + paterno + " " + value;
        }
    }

    /// <summary>Mes en el cual expira la tarjeta con la cual se efectúa el pago. El dato se debe enviar en formato de 2 dígitos “mm”. Ejemplo: 02</summary>
    public string MesExpTarjeta
    {
        get { return mes_exp_tarjeta.ToString("0#"); }
        set { mes_exp_tarjeta = Convert.ToInt32(value); }
    }

    /// <summary>Año en el cual expira la tarjeta con la cual se efectúa el pago. El dato se debe enviar en formato de 2 dígitos “yy”. Ejemplo: 10</summary>
    public string AnioExpTarjeta
    {
        get { return anio_exp_tarjeta.ToString(); }
        set { anio_exp_tarjeta = Convert.ToInt32(value); }
    }

    /// <summary>Número de la tarjeta con la cual se desea efectuar el pago.</summary>
    public string NumTarjeta
    {
        get { return num_tarjeta; }
        set { num_tarjeta = value; }
    }

    /// <summary>Código de seguridad de la tarjeta con la cual se desea efectuar el pago.</summary>
    public string CodTarjeta
    {
        get { return cod_tarjeta; }
        set { cod_tarjeta = value; }
    }

    /// <summary>Monto del pago. No usar comas y siempre se debe manejar con 2 decimales. Ejemplo: 1270.00</summary>
    public string Monto
    {
        get { return monto.ToString("###0.00"); }
        set { monto = Convert.ToDouble(value); }
    }

    /// <summary>Identificador del tipo de tarjeta de crédito. Puede tomar los siguientes valores: 1 (VISA) - 2 (MASTER CARD) - 3 (AMERICAN EXPRESS)</summary>
    public string TipTarjeta
    {
        get { return tip_tarjeta; }
        set { tip_tarjeta = value; }
    }

    /// <summary>Número de Referencia para control de datos. Por default, se manda la póliza como número de referencia.</summary>
    public string NumReferencia
    {
        get
        {
            if (num_referencia == null || (num_referencia != null && num_referencia.Equals(string.Empty)))
                num_referencia = num_poliza;
            return num_referencia;
        }
        set { num_referencia = value; }
    }



    public NPagoEnLinea()
    {

    }

    public NPagoEnLinea(string[] arrDatos)
    {
        foreach (string datos in arrDatos)
        {
            string[] dato = datos.Split('=');
            switch (dato[0])
            {
                case "COD_ENTIDAD":
                    cod_entidad = dato[1];
                    break;
                case "NOM_TITULAR":
                    NombreTitular = dato[1];
                    break;
                case "APE1_TITULAR":
                    APaternoTitular = dato[1];
                    break;
                case "APE2_TITULAR":
                    AMaternoTitular = dato[1];
                    break;
                case "MES_VCTO_TARJETA":
                    MesExpTarjeta = dato[1];
                    break;
                case "ANO_VCTO_TARJETA":
                    AnioExpTarjeta = dato[1];
                    break;
                case "NUM_CUENTA":
                    num_tarjeta = dato[1];
                    break;
                case "COD_SEGURIDAD":
                    cod_tarjeta = dato[1];
                    break;
                case "TIP_TARJETA":
                    tip_tarjeta = dato[1];
                    break;
            }
        }
    }

    public NPagoEnLinea(Hashtable hashDatos)
    {
        cod_entidad = hashDatos["COD_ENTIDAD"].ToString();
        NombreTitular = hashDatos["NOM_TITULAR"].ToString();
        APaternoTitular = hashDatos["APE1_TITULAR"].ToString();
        AMaternoTitular = hashDatos["APE2_TITULAR"].ToString();
        MesExpTarjeta = hashDatos["MES_VCTO_TARJETA"].ToString();
        AnioExpTarjeta = hashDatos["ANO_VCTO_TARJETA"].ToString();
        num_tarjeta = hashDatos["NUM_CUENTA"].ToString();
        cod_tarjeta = hashDatos["COD_SEGURIDAD"].ToString();
        tip_tarjeta = hashDatos["TIP_TARJETA"].ToString();
    }

    private void autorizaRechazaPol()
    {
        MCommand cmd = new MCommand();
        DataRow outRow = null;
        if (mca_autoriza_rechaza == McaAutorizaRechaza.Rechaza)
        {
            try
            {
                using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
                {
                    cmd.Connection = conexion;
                    cmd.CommandText = "trn_k_global.asigna";
                    cmd.agregarINParametro("p_variable", OracleDbType.Varchar2, "cod_cia");
                    cmd.agregarINParametro("p_valor", OracleDbType.Varchar2, "1");
                    cmd.ejecutarSP();
                    cmd.removeAll();
                    cmd.CommandText = "trn_k_global.asigna";
                    cmd.agregarINParametro("p_variable", OracleDbType.Varchar2, "num_poliza");
                    cmd.agregarINParametro("p_valor", OracleDbType.Varchar2, num_poliza);
                    cmd.ejecutarSP();
                    cmd.removeAll();
                    cmd.CommandText = "em_k_rechaza.p_poliza";
                    cmd.agregarINParametro("p_cod_cia", OracleDbType.Int16, 1);
                    cmd.agregarINParametro("p_cod_sector", OracleDbType.Int16, 1);
                    cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, num_poliza);
                    cmd.agregarINParametro("p_num_spto", OracleDbType.Int16, 0);
                    cmd.agregarINParametro("p_num_apli", OracleDbType.Int16, 0);
                    cmd.agregarINParametro("p_num_spto_apli", OracleDbType.Int16, 0);
                    cmd.agregarINParametro("p_obs_rechazo", OracleDbType.Varchar2, "S");
                    cmd.agregarINParametro("p_mca_suspende", OracleDbType.Varchar2, "S");
                    cmd.agregarINParametro("p_cod_error_rechazo", OracleDbType.Int16, null);
                    cmd.agregarINParametro("p_num_riesgo_rechazo", OracleDbType.Int16, null);
                    outRow = cmd.ejecutarRegistroSP();
                    cmd.removeAll();
                    //cmd.CommandText = "commit";
                    //cmd.ejecutarSP();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("ERROR autorizaRechazaPol: " + ex.Message, ex);
            }
        }
    }

    public void pagoEnLinea()
    {
        try
        {
            mca_autoriza_rechaza = McaAutorizaRechaza.Rechaza;
            getImporte();
            generaXML();
            wsvidatw.WSVidaTW wsCobranza = new wsvidatw.WSVidaTW();
            wsCobranza.Url = ConfigurationManager.AppSettings["wscobranza.service"];
            /**********
            System.Net.WebProxy miProxy = new System.Net.WebProxy("10.0.2.11", 8080);
            System.Net.NetworkCredential misCredenciales = new System.Net.NetworkCredential("HERAMIRE", "sHRR2106", "MAPFRE");
            miProxy.Credentials = misCredenciales;
            wsCobranza.Proxy = miProxy;
            **********/
            if (ConfigurationManager.AppSettings["MCA_PAGO_ENLINEA"].Equals("S"))
            {
                xml_respuesta = wsCobranza.WM_CobranzaLinea(xml_cobranza.ToString());
                validaRespuesta();
            }
            else
            {
                //Se simula que el cobro es exitoso
                num_autorizacion = "0000";
                mca_autoriza_rechaza = McaAutorizaRechaza.Autoriza;
                txt_rechazo = "";
            }

            autorizaRechazaPol();
            //xml_respuesta = wsCobranza.WM_CobranzaLinea(xml_cobranza.ToString());
            //validaRespuesta();
        }
        catch (Exception ex)
        {
            throw new Exception("Poliza: " + num_poliza + " RespuestaWS: " + ((xml_respuesta == null) ? string.Empty : xml_respuesta.OuterXml) + " Error: " + ex.Message);
        }
    }

    private void generaXML()
    {
        xml_cobranza = new StringBuilder();
        xml_cobranza.Append("<DATOS_BANCARIOS ");
        xml_cobranza.Append("COD_ENTIDAD='" + cod_entidad + "' ");
        xml_cobranza.Append("NOM_TERCERO='" + nom_tercero + "' ");
        xml_cobranza.Append("MES_EXP_TARJETA='" + MesExpTarjeta + "' ");
        xml_cobranza.Append("ANIO_EXP_TARJETA='" + AnioExpTarjeta.Substring(AnioExpTarjeta.Length - 2) + "' ");
        xml_cobranza.Append("NUM_TARJETA='" + num_tarjeta + "' ");
        xml_cobranza.Append("COD_TARJETA='" + cod_tarjeta + "' ");
        //AEP Cambio MV
        //String[] monto = factor.Split('.');
        //monto[1] = monto[1].Substring(0, 2);
        //monto[0] = monto[0] +"."+ monto[1];
        if (num_poliza.Substring(0, 3) == "112")
        {
            xml_cobranza.Append("MONTO='" + Monto + "' ");
        }
        else
        {
            String[] monto = factor.Split('.');
            monto[1] = monto[1].Substring(0, 2);
            monto[0] = monto[0] + "." + monto[1];
            xml_cobranza.Append("MONTO='" + monto[0] + "' ");
        }
        xml_cobranza.Append("TIP_TARJETA='" + tip_tarjeta + "' ");
        xml_cobranza.Append("NUM_REFERENCIA='" + NumReferencia + "' ");
        xml_cobranza.Append("MESES_SIN_INTERESES='" + Msi + "' />");
    }

    private void validaRespuesta()
    {
        txt_rechazo = "";
        num_autorizacion = "";
        /********************
         * Se agregó la llave ValidarPago en el web.config para no realizar el pago en línea en el ambiente de pruebas.
         * S : Realiza la validación de la respuesta del web service.
         * N : Autoriza la póliza sin validar la respuesta del web service.
         ********************/
        bool noValidarPago = (ConfigurationManager.AppSettings["ValidarPago"] != null);
        if (noValidarPago)
            noValidarPago = ConfigurationManager.AppSettings["ValidarPago"].Equals("N");
        /********************/
        XmlNode node = xml_respuesta.SelectSingleNode("//result");
        if (node != null || noValidarPago)
        {
            if (node.InnerText == "true" || noValidarPago)
            {
                XmlNode autorizacion = xml_respuesta.SelectSingleNode("//cobro");
                if (autorizacion != null || noValidarPago)
                {
                    if (autorizacion != null && autorizacion.Attributes["NUM_AUTORIZACION"] != null)
                        num_autorizacion = autorizacion.Attributes["NUM_AUTORIZACION"].InnerText;
                    else if (noValidarPago)
                        num_autorizacion = "NoValidarPago";
                    else num_autorizacion = xml_respuesta.OuterXml;
                    mca_autoriza_rechaza = McaAutorizaRechaza.Autoriza;
                }
                else txt_rechazo = "Poliza: " + num_poliza + " Error validaRespuesta(): " + xml_respuesta.OuterXml;
            }
            else
            {
                if (xml_respuesta.SelectSingleNode("//error") != null)
                    txt_rechazo = "Poliza: " + num_poliza + " Error: " + xml_respuesta.SelectSingleNode("//error").InnerText;
                else txt_rechazo = "Poliza: " + num_poliza + " Error validaRespuesta(): " + xml_respuesta.OuterXml;
            }
        }
        else txt_rechazo = "Poliza: " + num_poliza + " Error validaRespuesta(): " + xml_respuesta.OuterXml;
    }

    private void getImporte()
    {
        CDConsulta objConsulta = new CDConsulta();
        MCommand cmd = new MCommand();
        DataTable objDT = new DataTable();
        Monto = "1";
        try
        {
            //using (OracleConnection con = MConnection.getConexion(ConfigurationManager.ConnectionStrings["ConnectionTW"].ConnectionString))
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                objDT = objConsulta.getImportePol(num_poliza, conexion);
                if (objDT != null && objDT.Rows.Count > 0)
                {
                    if (!objDT.Rows[0].IsNull("Total"))
                    {
                        if (!objDT.Rows[0]["Total"].ToString().Equals(string.Empty))
                            Monto = objDT.Rows[0]["Total"].ToString();
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception("Error: NPagoEnLinea.getImporte() : " + ex.Message);
        }
    }
}
