﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MapfreMMX.util;
using Oracle.DataAccess.Client;
using MapfreMMX.oracle;


/// <summary>
/// Summary description for UtilFile
/// </summary>
public class UtilFile
{
    #region Campos privados
    private string _xprFile = "";
    private string _sector;
    private string _ramo;
    private string _contato = "";
    private string ramo
    {
        get
        {
            if (_contato.Equals(""))
                return _ramo;
            else return _contato;
        }
    }
    private string agente;
    private string xprFile
    {
        set { _xprFile = value; }
        get
        {
            if (_xprFile.Equals(""))
            {
                _xprFile = WebUtils.getAppSetting("xpr" + _sector);
            }

            if (agente.Trim() == WebUtils.getAppSetting("AgtPrueba"))
            {
                if (!_xprFile.Contains(WebUtils.getAppSetting("xprMarcaAgua")))
                    _xprFile += WebUtils.getAppSetting("xprMarcaAgua");
            }

            return _xprFile;
        }
    }
    
    #endregion

    #region Constructores
    public UtilFile()
	{
    }
    #endregion

    #region Metodos

    public void creaPDF(string noPoliza, string endoso, string sector, string simpol, string origen, string contrato, string ruta)
    {
        try
        {
            if (endoso == "")
            {
                endoso = "0";
            }
            
            ArrayList Hojas = new ArrayList();
            string strXML;
            bool imprimeRecibo = true;

            if (noPoliza != "")
                _ramo = noPoliza.Substring(0, 3);

            _sector = sector;
            DisImpClass.Impresion DSXML = new DisImpClass.Impresion();

            // Para Negocios Especiales se usa como parametro de validacion el contrato
            if (contrato != "")
                _contato = contrato;

            using (OracleConnection cn = MConexion.getConexion("ConnectionTW"))
            {
                // Ejecuta el reporte con Recibos
                switch (ramo)
                {
                    case "244":
                        // Se obtiene el XML para generar el PDF especifico para polizas de AP (SeGA)
                        strXML = DSXML.Poliza_AP(noPoliza, cn);
                        break;
                    default:
                        // Se obtiene el XML para generar el PDF de la poliza
                        strXML = DSXML.ImprimePolizasSeGA(noPoliza, endoso, "1", "999", 0, cn, true, noPoliza, 1, 1);
                        break;
                }

                // Recupera el agente del XML y lo asigna a la propiedad Agente
                agente = getValorXML(strXML, "cod_agt");

                // Validacion para el sector Vida
                if (sector == "1")
                {
                    // Recupera el nombre para el archivo xpr del XML y lo asigna a la propiedad xprFile
                    xprFile = getValorXML(strXML, "xpr");
                }

                WebUtils.PDF_RUN(strXML, "", ruta);

                if (simpol.Equals("n"))
                    DSXML.MarcaPoliza(noPoliza, Convert.ToInt16(endoso), cn);
            }

        }
        catch (Exception ex)
        {
            throw new Exception("TWImpPoliza(" + noPoliza + ") : " + ex.Message);
        }
    }

    private string getValorXML(string XML, string nom_campo)
    {
        try
        {
            XMLRead objXML = new XMLRead(XML);
            if (objXML.getNode(nom_campo) != null)
            {
                if (objXML.getNode(nom_campo).InnerText != "")
                    return objXML.getNode(nom_campo).InnerText;
            }
        }
        catch
        {
            if (XML.Contains("falseValidaImpresion"))
            {
                throw new Exception(XML.Replace("falseValidaImpresion", ""));
            }
        }
        return string.Empty;
    }
    #endregion
}