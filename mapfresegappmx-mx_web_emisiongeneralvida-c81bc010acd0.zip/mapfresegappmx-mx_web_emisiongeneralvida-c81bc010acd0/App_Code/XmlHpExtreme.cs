﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Xml;

/// <summary>
/// Summary description for XmlHpExtreme
/// </summary>
public class XmlHpExtreme
{
    public string XmlHpExtremeSolicitud(string xml, string strNombre)
    {
        //string sector = "REFERENCIAS,/mnt/HP_Exstream/pubs/EMISION_VIDA/REFERENCIAS.ini";

        string sector = "REFERENCIAS,/mnt/HP_Exstream/pubs/EMISION_VIDA/REFERENCIAS.ini";
        string pubFile = "EMISION_VIDA_SOLICITUD_INDIVIDUAL.pub";
        string RutaImp = ConfigurationSettings.AppSettings["RutaImpresionArchivo"];
        string sFileOutput;
        byte[] yourByteArray = null;
        byte[] byt = System.Text.Encoding.UTF8.GetBytes(xml);
        xml = Convert.ToBase64String(byt);
        //MLogFile2.getInstance().writeText("XMLHpExtreamGenera.cs" + xml);
        string userHPExstream = ConfigurationSettings.AppSettings["UserHp"];
        string paswHPExstream = ConfigurationSettings.AppSettings["PassHp"];
        string RutaURL = ConfigurationSettings.AppSettings["URLWSHpExtream"];

        HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(RutaURL);
        webRequest.Headers.Add(@"SOAP:Action");
        webRequest.ContentType = "text/xml;charset=\"utf-8\"";
        webRequest.Accept = "text/xml";
        webRequest.Method = "POST";
        HttpWebRequest request = webRequest;

        XmlDocument soapEnvelopeXml = new XmlDocument();
        //MLogFile2.getInstance().writeText("conecte");
        soapEnvelopeXml.LoadXml(@"<soapenv:Envelope xmlns:eng=""urn:hpexstream-services/Engine"" xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"">
                                       <soapenv:Header>
                                          <wsse:Security soapenv:mustUnderstand=""0"" xmlns:wsse=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"" xmlns:wsu=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"">
                                            <wsse:UsernameToken wsu:Id=""UsernameToken-1"">
                                                <wsse:Username>" + ConfigurationManager.AppSettings["userHP"] + @"</wsse:Username>
                                                <wsse:Password Type=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText"">" + ConfigurationManager.AppSettings["passHP"] + @"</wsse:Password>
                                                <wsse:Nonce EncodingType=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary"">9XbhOoet06M5XXD83sgM7Q==</wsse:Nonce>
                                                <wsu:Created>2015-07-21T08:23:30.207Z</wsu:Created>
                                             </wsse:UsernameToken>
                                          </wsse:Security>
                                       </soapenv:Header>
                                       <soapenv:Body>
                                          <eng:Compose>
                                             <EWSComposeRequest>
                                                <driver>
                                                   <!--Fichero de datos en Base64-->
                                                   <driver>" + xml + @"</driver>
                                                   <fileName>INPUT</fileName>
                                                </driver>
                                                <engineOptions>
                                                   <name>IMPORTDIRECTORY</name>
                                                   <value>/var/opt/exstream/pubs</value>
                                                </engineOptions>
                                                <engineOptions>
                                                   <!--Ruta donde se encuentra fichero de referencias-->
                                                   <!--A su vez, el fichero contiene ruta a recursos-->
                                                   <name>FILEMAP</name>
                                                   <value>" + sector + @"</value>
                                                </engineOptions>
                                                <!--Optional:-->
                                                <pubFile>" + pubFile + @"</pubFile>
                                             </EWSComposeRequest>
                                          </eng:Compose>
                                       </soapenv:Body>
                                    </soapenv:Envelope>");

        //MLogFile2.getInstance().writeText("servicio soap = " + soapEnvelopeXml);
        using (Stream stream = request.GetRequestStream())
        {
            soapEnvelopeXml.Save(stream);
        }
        //MLogFile2.getInstance().writeText("saliendo de xml web service  ");
        using (WebResponse response = request.GetResponse())
        {
            using (StreamReader rd = new StreamReader(response.GetResponseStream()))
            {
                string soapResult = rd.ReadToEnd();
                int iCadenaIni = soapResult.IndexOf("<fileOutput>") + 12;
                int iCadenaFin = soapResult.IndexOf("</fileOutput>");
                sFileOutput = soapResult.Substring(iCadenaIni, (iCadenaFin - iCadenaIni));
                yourByteArray = Convert.FromBase64String(sFileOutput);
                //strNomPref = ConfigurationSettings.AppSettings["PrefijoPolizaNombre"];
                WriteArrayToPdf(sFileOutput, RutaImp, "sv_" + strNombre + ".pdf");
            }
        }
        return RutaImp + "sv_" + strNombre + ".pdf";
    }
    public string XmlHpExtremeCuestionario(string xml, string strNombre)
    {
        string RutaImp = ConfigurationSettings.AppSettings["RutaImpresionArchivo"];
        string sector = "REFERENCIAS,/mnt/HP_Exstream/pubs/EMISION_VIDA/REFERENCIAS.ini";
        string pubFile = "EMISION_VIDA_CUESTIONARIO_ER.pub";
        
        string sFileOutput;
        byte[] yourByteArray = null;
        byte[] byt = System.Text.Encoding.UTF8.GetBytes(xml);
        xml = Convert.ToBase64String(byt);
        //MLogFile2.getInstance().writeText("XMLHpExtreamGenera.cs" + xml);
        string userHPExstream = ConfigurationSettings.AppSettings["UserHp"];
        string paswHPExstream = ConfigurationSettings.AppSettings["PassHp"];
        string RutaURL = ConfigurationSettings.AppSettings["URLWSHpExtream"];

        HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(RutaURL);
        webRequest.Headers.Add(@"SOAP:Action");
        webRequest.ContentType = "text/xml;charset=\"utf-8\"";
        webRequest.Accept = "text/xml";
        webRequest.Method = "POST";
        HttpWebRequest request = webRequest;

        XmlDocument soapEnvelopeXml = new XmlDocument();
        //MLogFile2.getInstance().writeText("conecte");
        soapEnvelopeXml.LoadXml(@"<soapenv:Envelope xmlns:eng=""urn:hpexstream-services/Engine"" xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"">
                                       <soapenv:Header>
                                          <wsse:Security soapenv:mustUnderstand=""0"" xmlns:wsse=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"" xmlns:wsu=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"">
                                            <wsse:UsernameToken wsu:Id=""UsernameToken-1"">
                                                <wsse:Username>" + ConfigurationManager.AppSettings["userHP"] + @"</wsse:Username>
                                                <wsse:Password Type=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText"">" + ConfigurationManager.AppSettings["passHP"] + @"</wsse:Password>
                                                <wsse:Nonce EncodingType=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary"">9XbhOoet06M5XXD83sgM7Q==</wsse:Nonce>
                                                <wsu:Created>2015-07-21T08:23:30.207Z</wsu:Created>
                                             </wsse:UsernameToken>
                                          </wsse:Security>
                                       </soapenv:Header>
                                       <soapenv:Body>
                                          <eng:Compose>
                                             <EWSComposeRequest>
                                                <driver>
                                                   <!--Fichero de datos en Base64-->
                                                   <driver>" + xml + @"</driver>
                                                   <fileName>INPUT</fileName>
                                                </driver>
                                                <engineOptions>
                                                   <name>IMPORTDIRECTORY</name>
                                                   <value>/var/opt/exstream/pubs</value>
                                                </engineOptions>
                                                <engineOptions>
                                                   <!--Ruta donde se encuentra fichero de referencias-->
                                                   <!--A su vez, el fichero contiene ruta a recursos-->
                                                   <name>FILEMAP</name>
                                                   <value>" + sector + @"</value>
                                                </engineOptions>
                                                <!--Optional:-->
                                                <pubFile>" + pubFile + @"</pubFile>
                                             </EWSComposeRequest>
                                          </eng:Compose>
                                       </soapenv:Body>
                                    </soapenv:Envelope>");

        //MLogFile2.getInstance().writeText("servicio soap = " + soapEnvelopeXml);
        using (Stream stream = request.GetRequestStream())
        {
            soapEnvelopeXml.Save(stream);
        }
        //MLogFile2.getInstance().writeText("saliendo de xml web service  ");
        using (WebResponse response = request.GetResponse())
        {
            using (StreamReader rd = new StreamReader(response.GetResponseStream()))
            {
                string soapResult = rd.ReadToEnd();
                int iCadenaIni = soapResult.IndexOf("<fileOutput>") + 12;
                int iCadenaFin = soapResult.IndexOf("</fileOutput>");
                sFileOutput = soapResult.Substring(iCadenaIni, (iCadenaFin - iCadenaIni));
                yourByteArray = Convert.FromBase64String(sFileOutput);
                WriteArrayToPdf(sFileOutput, RutaImp, "cer_" + strNombre + ".pdf");
            }
        }
        return RutaImp + "cer_" + strNombre + ".pdf";
    }

    public string XmlHpExtremeMonto(string xml, string strNombre)
    {
        string RutaImp = ConfigurationSettings.AppSettings["RutaImpresionArchivo"];
        string sector = "REFERENCIAS,/mnt/HP_Exstream/pubs/EMISION_VIDA/REFERENCIAS.ini";
        string pubFile = "EMISION_VIDA_MONTO_SA.pub";
        string strNomPref = "";

        string sFileOutput;
        byte[] yourByteArray = null;
        byte[] byt = System.Text.Encoding.UTF8.GetBytes(xml);
        xml = Convert.ToBase64String(byt);
        //MLogFile2.getInstance().writeText("XMLHpExtreamGenera.cs" + xml);
        string userHPExstream = ConfigurationSettings.AppSettings["UserHp"];
        string paswHPExstream = ConfigurationSettings.AppSettings["PassHp"];
        string RutaURL = ConfigurationSettings.AppSettings["URLWSHpExtream"];

        HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(RutaURL);
        webRequest.Headers.Add(@"SOAP:Action");
        webRequest.ContentType = "text/xml;charset=\"utf-8\"";
        webRequest.Accept = "text/xml";
        webRequest.Method = "POST";
        HttpWebRequest request = webRequest;

        XmlDocument soapEnvelopeXml = new XmlDocument();
        //MLogFile2.getInstance().writeText("conecte");
        soapEnvelopeXml.LoadXml(@"<soapenv:Envelope xmlns:eng=""urn:hpexstream-services/Engine"" xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"">
                                       <soapenv:Header>
                                          <wsse:Security soapenv:mustUnderstand=""0"" xmlns:wsse=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"" xmlns:wsu=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"">
                                            <wsse:UsernameToken wsu:Id=""UsernameToken-1"">
                                                <wsse:Username>" + ConfigurationManager.AppSettings["userHP"] + @"</wsse:Username>
                                                <wsse:Password Type=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText"">" + ConfigurationManager.AppSettings["passHP"] + @"</wsse:Password>
                                                <wsse:Nonce EncodingType=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary"">9XbhOoet06M5XXD83sgM7Q==</wsse:Nonce>
                                                <wsu:Created>2015-07-21T08:23:30.207Z</wsu:Created>
                                             </wsse:UsernameToken>
                                          </wsse:Security>
                                       </soapenv:Header>
                                       <soapenv:Body>
                                          <eng:Compose>
                                             <EWSComposeRequest>
                                                <driver>
                                                   <!--Fichero de datos en Base64-->
                                                   <driver>" + xml + @"</driver>
                                                   <fileName>INPUT</fileName>
                                                </driver>
                                                <engineOptions>
                                                   <name>IMPORTDIRECTORY</name>
                                                   <value>/var/opt/exstream/pubs</value>
                                                </engineOptions>
                                                <engineOptions>
                                                   <!--Ruta donde se encuentra fichero de referencias-->
                                                   <!--A su vez, el fichero contiene ruta a recursos-->
                                                   <name>FILEMAP</name>
                                                   <value>" + sector + @"</value>
                                                </engineOptions>
                                                <!--Optional:-->
                                                <pubFile>" + pubFile + @"</pubFile>
                                             </EWSComposeRequest>
                                          </eng:Compose>
                                       </soapenv:Body>
                                    </soapenv:Envelope>");

        //MLogFile2.getInstance().writeText("servicio soap = " + soapEnvelopeXml);
        using (Stream stream = request.GetRequestStream())
        {
            soapEnvelopeXml.Save(stream);
        }
        //MLogFile2.getInstance().writeText("saliendo de xml web service  ");
        using (WebResponse response = request.GetResponse())
        {
            using (StreamReader rd = new StreamReader(response.GetResponseStream()))
            {
                string soapResult = rd.ReadToEnd();
                int iCadenaIni = soapResult.IndexOf("<fileOutput>") + 12;
                int iCadenaFin = soapResult.IndexOf("</fileOutput>");
                sFileOutput = soapResult.Substring(iCadenaIni, (iCadenaFin - iCadenaIni));
                yourByteArray = Convert.FromBase64String(sFileOutput);
                WriteArrayToPdf(sFileOutput, RutaImp, "cSA_" + strNombre + ".pdf");
            }
        }
        return RutaImp + "cSA_" + strNombre + ".pdf";
    }

    private void WriteArrayToPdf(string inPDFByteArrayStream, string pdflocation, string fileName)
    {
        byte[] data = Convert.FromBase64String(inPDFByteArrayStream);

        if (Directory.Exists(pdflocation))
        {
            pdflocation = pdflocation + fileName;

            using (FileStream Writer = new System.IO.FileStream(pdflocation, FileMode.Create, FileAccess.Write))
            {
                Writer.Write(data, 0, data.Length);
            }
        }
        else
        {
            throw new System.Exception("PDF Shared Location not found");
        }
    }
}