﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Net.Sockets;
using System.Diagnostics;
using System.Net;
using System.IO;

public class FTPClient
{
    #region "Constructor"

    /// <summary>
    /// Default contructor
    /// </summary>
    public FTPClient()
    {
    }

    #endregion

    #region "Variables"

    private static string iFtpServer;
    private static string iFtpUser;
    private static string iFtpPass;
    private static string iPath;

    private static int BUFFER_SIZE = 512;
    private static Encoding ASCII = Encoding.ASCII;
    private bool verboseDebugging = false;
    private string server = "";
    private string remotePath = PathRemoto;
    private string username = "";
    private string password = "";
    private string message = null;
    private string result = null;
    private int port = 21;
    private int bytes = 0;
    private int resultCode = 0;
    private bool loggedin = false;
    private bool binMode = false;
    private Byte[] buffer = new Byte[BUFFER_SIZE];
    private Socket clientSocket = null;
    private int timeoutSeconds = 180;

    #endregion

    #region "Propiedades"

    public static string FtpServer
    {
        get
        {
            return iFtpServer;
        }
        set
        {
            iFtpServer = value;
        }
    }

    public static string FtpUser
    {
        get
        {
            return iFtpUser;
        }
        set
        {
            iFtpUser = value;
        }
    }

    public static string FtpPass
    {
        get
        {
            return iFtpPass;
        }
        set
        {
            iFtpPass = value;
        }
    }

    public static string PathRemoto
    {
        get
        {
            return iPath;
        }
        set
        {
            iPath = value;
        }
    }

    /// <summary>
    /// Display all communications to the debug log
    /// </summary>
    public bool VerboseDebugEnseging
    {
        get
        {
            return this.verboseDebugging;
        }
        set
        {
            this.verboseDebugging = value;
        }
    }

    /// <summary>
    /// Puerto TCP 21
    /// </summary>
    public int Port
    {
        get
        {
            return this.port;
        }
        set
        {
            this.port = value;
        }
    }

    /// <summary>
    /// Timeout waiting for a response from server, in seconds.
    /// </summary>
    public int Timeout
    {
        get
        {
            return this.timeoutSeconds;
        }
        set
        {
            this.timeoutSeconds = value;
        }
    }

    /// <summary>
    /// Gets and Sets the name of the FTP server.
    /// </summary>
    /// <returns></returns>
    public string Server
    {
        get
        {
            return this.server;
        }
        set
        {
            this.server = value;
        }
    }

    /// <summary>
    /// Gets and Sets the port number.
    /// </summary>
    /// <returns></returns>
    public int RemotePort
    {
        get
        {
            return this.port;
        }
        set
        {
            this.port = value;
        }
    }

    /// <summary>
    /// GetS and Sets the remote directory.
    /// </summary>
    public string RemotePath
    {
        get
        {
            return this.remotePath;
        }
        set
        {
            this.remotePath = value;
        }

    }

    /// <summary>
    /// Gets , Sets  username.
    /// </summary>
    public string Username
    {
        get
        {
            return this.username;
        }
        set
        {
            this.username = value;
        }
    }

    /// <summary>
    /// Gets, Set  password.
    /// </summary>
    public string Password
    {
        get
        {
            return this.password;
        }
        set
        {
            this.password = value;
        }
    }

    /// <summary>
    /// If the value of mode is true, set binary mode for downloads, else, Ascii mode.
    /// </summary>
    public bool BinaryMode
    {
        get
        {
            return this.binMode;
        }
        set
        {
            if (this.binMode == value) return;

            if (value)
                sendCommand("TYPE I");

            else
                sendCommand("TYPE A");

            if (this.resultCode != 200) throw new FtpException(result.Substring(4));
        }
    }

    #endregion

    #region "Metodos"

    /// <summary>
    /// 
    /// </summary>
    /// <param name="server"></param>
    /// <param name="username"></param>
    /// <param name="password"></param>
    public void FtpClient1(string server, string username, string password)
    {
        this.server = server;
        this.username = username;
        this.password = password;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="server"></param>
    /// <param name="username"></param>
    /// <param name="password"></param>
    /// <param name="timeoutSeconds"></param>
    /// <param name="port"></param>
    public void FtpClient1(string server, string username, string password, int timeoutSeconds, int port)
    {
        this.server = server;
        this.username = username;
        this.password = password;
        this.timeoutSeconds = timeoutSeconds;
        this.port = port;
    }

    /// <summary>
    /// Logeo al servidor.
    /// </summary>
    public void Login()
    {
        if (this.loggedin) this.Close();

        Debug.WriteLine("Opening connection to " + this.server, "FtpClient");

        IPAddress addr = null;
        IPEndPoint ep = null;

        try
        {
            this.clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            addr = Dns.Resolve(this.server).AddressList[0];
            ep = new IPEndPoint(addr, this.port);
            this.clientSocket.Connect(ep);
        }
        catch (Exception ex)
        {

            if (this.clientSocket != null && this.clientSocket.Connected) this.clientSocket.Close();

            throw new FtpException("NO se puede conectar al servidor", ex);
        }

        this.readResponse();

        if (this.resultCode != 220)
        {
            this.Close();
            throw new FtpException(this.result.Substring(4));
        }

        this.sendCommand("USER " + username);

        if (!(this.resultCode == 331 || this.resultCode == 230))
        {
            this.cleanup();
            throw new FtpException(this.result.Substring(4));
        }

        if (this.resultCode != 230)
        {
            this.sendCommand("PASS " + password);

            if (!(this.resultCode == 230 || this.resultCode == 202))
            {
                this.cleanup();
                throw new FtpException(this.result.Substring(4));
            }
        }

        this.loggedin = true;

        Debug.WriteLine("Conectado con " + this.server, "FtpClient");

        this.ChangeDir(this.remotePath);
    }

    /// <summary>
    /// Cierra conexion  FTP
    /// </summary>
    public void Close()
    {
        Debug.WriteLine("Cerrando conexion con " + this.server, "FtpClient");

        if (this.clientSocket != null)
        {
            this.sendCommand("QUIT");
        }

        this.cleanup();
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public string[] GetFileList()
    {
        return this.GetFileList("*.*");
    }

    /// <summary>
    /// devuelve un string qie contienes el directorio remoto
    /// </summary>
    /// <param name="mask"></param>
    /// <returns></returns>
    public string[] GetFileList(string mask)
    {
        if (!this.loggedin) this.Login();

        Socket cSocket = createDataSocket();

        this.sendCommand("NLST " + mask);

        if (!(this.resultCode == 150 || this.resultCode == 125)) throw new FtpException(this.result.Substring(4));

        this.message = "";

        DateTime timeout = DateTime.Now.AddSeconds(this.timeoutSeconds);

        while (timeout > DateTime.Now)
        {
            int bytes = cSocket.Receive(buffer, buffer.Length, 0);
            this.message += ASCII.GetString(buffer, 0, bytes);

            if (bytes < this.buffer.Length) break;
        }

        string[] msg = this.message.Replace("\r", "").Split('\n');

        cSocket.Close();

        if (this.message.IndexOf("No se ha hecho el directorio") != -1)
            msg = new string[] { };

        this.readResponse();

        if (this.resultCode != 226)
            msg = new string[] { };
        return msg;
    }

    /// <summary>
    /// Regresa el tamaño del archivo
    /// </summary>
    /// <param name="fileName"></param>
    /// <returns></returns>
    public long GetFileSize(string fileName)
    {
        if (!this.loggedin) this.Login();

        this.sendCommand("SIZE " + fileName);
        long size = 0;

        if (this.resultCode == 213)
            size = long.Parse(this.result.Substring(4));

        else
            throw new FtpException(this.result.Substring(4));

        return size;
    }

    public void Download(string remFileName)
    {
        this.Download(remFileName, "", false);
    }

    public void Download(string remFileName, Boolean resume)
    {
        this.Download(remFileName, "", resume);
    }

    public void Download(string remFileName, string locFileName)
    {
        this.Download(remFileName, locFileName, false);
    }

    public void Download(string remFileName, string locFileName, Boolean resume)
    {
        if (!this.loggedin) this.Login();

        this.BinaryMode = true;

        Debug.WriteLine("Downloading file " + remFileName + " from " + server + "/" + remotePath, "FtpClient");

        if (locFileName.Equals(""))
        {
            locFileName = remFileName;
        }

        FileStream output = null;

        if (!File.Exists(locFileName))
            output = File.Create(locFileName);

        else
            output = new FileStream(locFileName, FileMode.Open);

        Socket cSocket = createDataSocket();

        long offset = 0;

        if (resume)
        {
            offset = output.Length;

            if (offset > 0)
            {
                this.sendCommand("REST " + offset);
                if (this.resultCode != 350)
                {
                    offset = 0;
                    Debug.WriteLine("No soportado:" + result.Substring(4), "FtpClient");
                }
                else
                {
                    Debug.WriteLine("Resuming at offset " + offset, "FtpClient");
                    output.Seek(offset, SeekOrigin.Begin);
                }
            }
        }

        this.sendCommand("RETR " + remFileName);

        if (this.resultCode != 150 && this.resultCode != 125)
        {
            throw new FtpException(this.result.Substring(4));
        }

        DateTime timeout = DateTime.Now.AddSeconds(this.timeoutSeconds);

        while (timeout > DateTime.Now)
        {
            this.bytes = cSocket.Receive(buffer, buffer.Length, 0);
            output.Write(this.buffer, 0, this.bytes);

            if (this.bytes <= 0)
            {
                break;
            }
        }

        output.Close();

        if (cSocket.Connected) cSocket.Close();

        this.readResponse();

        if (this.resultCode != 226 && this.resultCode != 250)
            throw new FtpException(this.result.Substring(4));
    }

    /// <summary>
    /// Sube archivo
    /// </summary>
    /// <param name="fileName"></param>
    public void Upload(string fileName)
    {
        this.Upload(fileName, false);
    }

    /// <summary>
    /// Sube el archivo
    /// </summary>
    /// <param name="fileName"></param>
    /// <param name="resume"></param>
    public void Upload(string fileName, bool resume)
    {
        if (!this.loggedin) this.Login();

        Socket cSocket = null;
        long offset = 0;

        if (resume)
        {
            try
            {
                this.BinaryMode = true;

                offset = GetFileSize(Path.GetFileName(fileName));
            }
            catch (Exception)
            {
                // no existe archivo
                offset = 0;
            }
        }

        // abre y revisa el archivo
        try
        {
            FileStream input = new FileStream(fileName, FileMode.Open);

            if (resume && input.Length < offset)
            {
                // tamaño del archivo
                Debug.WriteLine("Overwriting " + fileName, "FtpClient");
                offset = 0;
            }
            else if (resume && input.Length == offset)
            {
                input.Close();
                Debug.WriteLine("Brincado completo " + fileName + " - turn resume off to not detect.", "FtpClient");
                return;
            }
            cSocket = this.createDataSocket();

            if (offset > 0)
            {
                //rest Comando ftp
                this.sendCommand("REST " + offset);
                if (this.resultCode != 350)
                {
                    Debug.WriteLine("No Soportado", "FtpClient");
                    offset = 0;
                }
            }

            // stor comando ftp
            this.sendCommand("STOR " + Path.GetFileName(fileName));

            if (this.resultCode != 125 && this.resultCode != 150) throw new FtpException(result.Substring(4));

            if (offset != 0)
            {
                Debug.WriteLine("Resuming at offset " + offset, "FtpClient");

                input.Seek(offset, SeekOrigin.Begin);
            }

            Debug.WriteLine("Subiedo archivo " + fileName + " to " + remotePath, "FtpClient");

            while ((bytes = input.Read(buffer, 0, buffer.Length)) > 0)
            {
                cSocket.Send(buffer, bytes, 0);
            }

            input.Close();

            if (cSocket.Connected)
            {
                cSocket.Close();
            }

            this.readResponse();

            if (this.resultCode != 226 && this.resultCode != 250) throw new FtpException(this.result.Substring(4));
        }
        catch (Exception ex)
        {
            throw new Exception("Error en upload Ftp" + ex.Message);
        }
    }

    /// <summary>
    /// Sube el archivo
    /// </summary>
    /// <param name="path"></param>
    /// <param name="recurse">Whether to recurse sub directories</param>
    public void UploadDirectory(string path, bool recurse)
    {
        this.UploadDirectory(path, recurse, "*.*");
    }

    /// <summary>
    /// actualiza el directorio
    /// </summary>
    /// <param name="path"></param>
    /// <param name="recurse">Whether to recurse sub directories</param>
    /// <param name="mask">Only upload files of the given mask - everything is '*.*'</param>
    public void UploadDirectory(string path, bool recurse, string mask)
    {
        string[] dirs = path.Replace("/", @"\").Split('\\');
        string rootDir = dirs[dirs.Length - 1];

        if (this.GetFileList(rootDir).Length < 1) this.MakeDir(rootDir);

        this.ChangeDir(rootDir);

        foreach (string file in Directory.GetFiles(path, mask))
        {
            this.Upload(file, true);
        }
        if (recurse)
        {
            foreach (string directory in Directory.GetDirectories(path))
            {
                this.UploadDirectory(directory, recurse, mask);
            }
        }

        this.ChangeDir("..");
    }

    /// <summary>
    /// borra el archivo
    /// </summary>
    /// <param name="fileName"></param>
    public void DeleteFile(string fileName)
    {
        if (!this.loggedin) this.Login();

        this.sendCommand("DELE " + fileName);

        if (this.resultCode != 250) throw new FtpException(this.result.Substring(4));

        Debug.WriteLine("Deleted file " + fileName, "FtpClient");
    }

    /// <summary>
    /// renombra el archivo
    /// </summary>
    /// <param name="oldFileName"></param>
    /// <param name="newFileName"></param>
    public void RenameFile(string oldFileName, string newFileName, bool overwrite)
    {
        if (!this.loggedin) this.Login();

        this.sendCommand("RNFR " + oldFileName);

        if (this.resultCode != 350) throw new FtpException(this.result.Substring(4));

        if (!overwrite && this.GetFileList(newFileName).Length > 0) throw new FtpException("File already exists");

        this.sendCommand("RNTO " + newFileName);

        if (this.resultCode != 250) throw new FtpException(this.result.Substring(4));

        Debug.WriteLine("Renamed file " + oldFileName + " to " + newFileName, "FtpClient");
    }

    /// <summary>
    /// crea directorio remoto
    /// </summary>
    /// <param name="dirName"></param>
    public void MakeDir(string dirName)
    {
        if (!this.loggedin) this.Login();

        this.sendCommand("MKD " + dirName);

        if (this.resultCode != 250 && this.resultCode != 257) throw new FtpException(this.result.Substring(4));

        Debug.WriteLine("Created directory " + dirName, "FtpClient");
    }

    /// <summary>
    /// Borra el directorio remoto
    /// </summary>
    /// <param name="dirName"></param>
    public void RemoveDir(string dirName)
    {
        if (!this.loggedin) this.Login();

        this.sendCommand("RMD " + dirName);

        if (this.resultCode != 250) throw new FtpException(this.result.Substring(4));

        Debug.WriteLine("Removed directory " + dirName, "FtpClient");
    }

    /// <summary>
    /// Cambia el directorio donde sesta trabajando el servidor ftp.
    /// </summary>
    /// <param name="dirName"></param>
    public void ChangeDir(string dirName)
    {
        if (dirName == null || dirName.Equals(".") || dirName.Length == 0)
        {
            return;
        }

        if (!this.loggedin) this.Login();

        this.sendCommand("CWD " + dirName);

        if (this.resultCode != 250) throw new FtpException(result.Substring(4));

        this.sendCommand("PWD");

        if (this.resultCode != 257) throw new FtpException(result.Substring(4));
        this.remotePath = this.message.Split('"')[1];

        Debug.WriteLine("Current directory is " + this.remotePath, "FtpClient");
    }

    /// <summary>
    /// 
    /// </summary>
    private void readResponse()
    {
        this.message = "";
        this.result = this.readLine();

        if (this.result.Length > 3)
            this.resultCode = int.Parse(this.result.Substring(0, 3));
        else
            this.result = null;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    private string readLine()
    {
        while (true)
        {
            this.bytes = clientSocket.Receive(this.buffer, this.buffer.Length, 0);
            this.message += ASCII.GetString(this.buffer, 0, this.bytes);

            if (this.bytes < this.buffer.Length)
            {
                break;
            }
        }

        string[] msg = this.message.Split('\n');

        if (this.message.Length > 2)
            this.message = msg[msg.Length - 2];

        else
            this.message = msg[0];


        if (this.message.Length > 4 && !this.message.Substring(3, 1).Equals(" ")) return this.readLine();

        if (this.verboseDebugging)
        {
            for (int i = 0; i < msg.Length - 1; i++)
            {
                Debug.Write(msg[i], "FtpClient");
            }
        }

        return message;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="command"></param>
    private void sendCommand(String command)
    {
        if (this.verboseDebugging) Debug.WriteLine(command, "FtpClient");

        Byte[] cmdBytes = Encoding.ASCII.GetBytes((command + "\r\n").ToCharArray());
        clientSocket.Send(cmdBytes, cmdBytes.Length, 0);
        this.readResponse();
    }

    /// <summary>
    /// para tranferis se necesita un nuevo socket
    /// </summary>
    /// <returns>Connected socket</returns>
    private Socket createDataSocket()
    {
        this.sendCommand("PASV");

        if (this.resultCode != 227) throw new FtpException(this.result.Substring(4));

        int index1 = this.result.IndexOf('(');
        int index2 = this.result.IndexOf(')');

        string ipData = this.result.Substring(index1 + 1, index2 - index1 - 1);

        int[] parts = new int[6];

        int len = ipData.Length;
        int partCount = 0;
        string buf = "";

        for (int i = 0; i < len && partCount <= 6; i++)
        {
            char ch = char.Parse(ipData.Substring(i, 1));

            if (char.IsDigit(ch))
                buf += ch;

            else if (ch != ',')
                throw new FtpException("Malformed PASV result: " + result);

            if (ch == ',' || i + 1 == len)
            {
                try
                {
                    parts[partCount++] = int.Parse(buf);
                    buf = "";
                }
                catch (Exception ex)
                {
                    throw new FtpException("Malformed PASV result (not supported?): " + this.result, ex);
                }
            }
        }

        string ipAddress = parts[0] + "." + parts[1] + "." + parts[2] + "." + parts[3];

        int port = (parts[4] << 8) + parts[5];

        Socket socket = null;
        IPEndPoint ep = null;

        try
        {
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            ep = new IPEndPoint(Dns.Resolve(ipAddress).AddressList[0], port);
            socket.Connect(ep);
        }
        catch (Exception ex)
        {
            // doubtfull....
            if (socket != null && socket.Connected) socket.Close();

            throw new FtpException("Can't connect to remote server", ex);
        }

        return socket;
    }

    /// <summary>
    /// Revisa los sockets
    /// </summary>
    private void cleanup()
    {
        if (this.clientSocket != null)
        {
            this.clientSocket.Close();
            this.clientSocket = null;
        }
        this.loggedin = false;
    }

    #endregion

    #region "Excepciones"

    public class FtpException : Exception
    {
        public FtpException(string message) : base(message) { }
        public FtpException(string message, Exception innerException) : base(message, innerException) { }
    }

    #endregion

    #region "Destructor"

    /// <summary>
    /// Destuctor
    /// </summary>
    ~FTPClient()
    {
        this.cleanup();
    }

    #endregion

    #region Async methods (auto generated)

    /*
				WinInetApi.FtpClient ftp = new WinInetApi.FtpClient();

				MethodInfo[] methods = ftp.GetType().GetMethods(BindingFlags.DeclaredOnly|BindingFlags.Instance|BindingFlags.Public);

				foreach ( MethodInfo method in methods )
				{
					string param = "";
					string values = "";
					foreach ( ParameterInfo i in  method.GetParameters() )
					{
						param += i.ParameterType.Name + " " + i.Name + ",";
						values += i.Name + ",";
					}
					

					Debug.WriteLine("private delegate " + method.ReturnType.Name + " " + method.Name + "Callback(" + param.TrimEnd(',') + ");");

					Debug.WriteLine("public System.IAsyncResult Begin" + method.Name + "( " + param + " System.AsyncCallback callback )");
					Debug.WriteLine("{");
					Debug.WriteLine("" + method.Name + "Callback ftpCallback = new " + method.Name + "Callback(" + values + " this." + method.Name + ");");
					Debug.WriteLine("return ftpCallback.BeginInvoke(callback, null);");
					Debug.WriteLine("}");
					Debug.WriteLine("public void End" + method.Name + "(System.IAsyncResult asyncResult)");
					Debug.WriteLine("{");
					Debug.WriteLine(method.Name + "Callback fc = (" + method.Name + "Callback) ((AsyncResult)asyncResult).AsyncDelegate;");
					Debug.WriteLine("fc.EndInvoke(asyncResult);");
					Debug.WriteLine("}");
					//Debug.WriteLine(method);
				}
*/


    private delegate void LoginCallback();
    public System.IAsyncResult BeginLogin(System.AsyncCallback callback)
    {
        LoginCallback ftpCallback = new LoginCallback(this.Login);
        return ftpCallback.BeginInvoke(callback, null);
    }
    private delegate void CloseCallback();
    public System.IAsyncResult BeginClose(System.AsyncCallback callback)
    {
        CloseCallback ftpCallback = new CloseCallback(this.Close);
        return ftpCallback.BeginInvoke(callback, null);
    }
    private delegate String[] GetFileListCallback();
    public System.IAsyncResult BeginGetFileList(System.AsyncCallback callback)
    {
        GetFileListCallback ftpCallback = new GetFileListCallback(this.GetFileList);
        return ftpCallback.BeginInvoke(callback, null);
    }
    private delegate String[] GetFileListMaskCallback(String mask);
    public System.IAsyncResult BeginGetFileList(String mask, System.AsyncCallback callback)
    {
        GetFileListMaskCallback ftpCallback = new GetFileListMaskCallback(this.GetFileList);
        return ftpCallback.BeginInvoke(mask, callback, null);
    }
    private delegate Int64 GetFileSizeCallback(String fileName);
    public System.IAsyncResult BeginGetFileSize(String fileName, System.AsyncCallback callback)
    {
        GetFileSizeCallback ftpCallback = new GetFileSizeCallback(this.GetFileSize);
        return ftpCallback.BeginInvoke(fileName, callback, null);
    }
    private delegate void DownloadCallback(String remFileName);
    public System.IAsyncResult BeginDownload(String remFileName, System.AsyncCallback callback)
    {
        DownloadCallback ftpCallback = new DownloadCallback(this.Download);
        return ftpCallback.BeginInvoke(remFileName, callback, null);
    }
    private delegate void DownloadFileNameResumeCallback(String remFileName, Boolean resume);
    public System.IAsyncResult BeginDownload(String remFileName, Boolean resume, System.AsyncCallback callback)
    {
        DownloadFileNameResumeCallback ftpCallback = new DownloadFileNameResumeCallback(this.Download);
        return ftpCallback.BeginInvoke(remFileName, resume, callback, null);
    }
    private delegate void DownloadFileNameFileNameCallback(String remFileName, String locFileName);
    public System.IAsyncResult BeginDownload(String remFileName, String locFileName, System.AsyncCallback callback)
    {
        DownloadFileNameFileNameCallback ftpCallback = new DownloadFileNameFileNameCallback(this.Download);
        return ftpCallback.BeginInvoke(remFileName, locFileName, callback, null);
    }
    private delegate void DownloadFileNameFileNameResumeCallback(String remFileName, String locFileName, Boolean resume);
    public System.IAsyncResult BeginDownload(String remFileName, String locFileName, Boolean resume, System.AsyncCallback callback)
    {
        DownloadFileNameFileNameResumeCallback ftpCallback = new DownloadFileNameFileNameResumeCallback(this.Download);
        return ftpCallback.BeginInvoke(remFileName, locFileName, resume, callback, null);
    }
    private delegate void UploadCallback(String fileName);
    public System.IAsyncResult BeginUpload(String fileName, System.AsyncCallback callback)
    {
        UploadCallback ftpCallback = new UploadCallback(this.Upload);
        return ftpCallback.BeginInvoke(fileName, callback, null);
    }
    private delegate void UploadFileNameResumeCallback(String fileName, Boolean resume);
    public System.IAsyncResult BeginUpload(String fileName, Boolean resume, System.AsyncCallback callback)
    {
        UploadFileNameResumeCallback ftpCallback = new UploadFileNameResumeCallback(this.Upload);
        return ftpCallback.BeginInvoke(fileName, resume, callback, null);
    }
    private delegate void UploadDirectoryCallback(String path, Boolean recurse);
    public System.IAsyncResult BeginUploadDirectory(String path, Boolean recurse, System.AsyncCallback callback)
    {
        UploadDirectoryCallback ftpCallback = new UploadDirectoryCallback(this.UploadDirectory);
        return ftpCallback.BeginInvoke(path, recurse, callback, null);
    }
    private delegate void UploadDirectoryPathRecurseMaskCallback(String path, Boolean recurse, String mask);
    public System.IAsyncResult BeginUploadDirectory(String path, Boolean recurse, String mask, System.AsyncCallback callback)
    {
        UploadDirectoryPathRecurseMaskCallback ftpCallback = new UploadDirectoryPathRecurseMaskCallback(this.UploadDirectory);
        return ftpCallback.BeginInvoke(path, recurse, mask, callback, null);
    }
    private delegate void DeleteFileCallback(String fileName);
    public System.IAsyncResult BeginDeleteFile(String fileName, System.AsyncCallback callback)
    {
        DeleteFileCallback ftpCallback = new DeleteFileCallback(this.DeleteFile);
        return ftpCallback.BeginInvoke(fileName, callback, null);
    }
    private delegate void RenameFileCallback(String oldFileName, String newFileName, Boolean overwrite);
    public System.IAsyncResult BeginRenameFile(String oldFileName, String newFileName, Boolean overwrite, System.AsyncCallback callback)
    {
        RenameFileCallback ftpCallback = new RenameFileCallback(this.RenameFile);
        return ftpCallback.BeginInvoke(oldFileName, newFileName, overwrite, callback, null);
    }
    private delegate void MakeDirCallback(String dirName);
    public System.IAsyncResult BeginMakeDir(String dirName, System.AsyncCallback callback)
    {
        MakeDirCallback ftpCallback = new MakeDirCallback(this.MakeDir);
        return ftpCallback.BeginInvoke(dirName, callback, null);
    }
    private delegate void RemoveDirCallback(String dirName);
    public System.IAsyncResult BeginRemoveDir(String dirName, System.AsyncCallback callback)
    {
        RemoveDirCallback ftpCallback = new RemoveDirCallback(this.RemoveDir);
        return ftpCallback.BeginInvoke(dirName, callback, null);
    }
    private delegate void ChangeDirCallback(String dirName);
    public System.IAsyncResult BeginChangeDir(String dirName, System.AsyncCallback callback)
    {
        ChangeDirCallback ftpCallback = new ChangeDirCallback(this.ChangeDir);
        return ftpCallback.BeginInvoke(dirName, callback, null);
    }

    #endregion
}