//'********************************************************************************************************************
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2010
//'Name of the file              : JDocum.cs
//'Creation/Modification History :
//'Modification                  : 
//                               
//'********************************************************************************************************************

using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Configuration;
using System.Data;
using System.IO;
using MapfreMMX.docum;

public class JDocum
{
    // Methods
    public void getContentToLocalFolder(string r_object_id, string LocalFolder)
    {
        string dOCBASE = ConfigurationSettings.AppSettings["DocBase"];
        try
        {
            DmPersistentSession session = DmPersistentSession.getInstance();
            if (!session.hasIdentity())
            {
                session.User = ConfigurationSettings.AppSettings["DocUsr"];
                session.Password = ConfigurationSettings.AppSettings["DocPass"];
            }
            new DmContent().getContentToLocalFolder(r_object_id, LocalFolder, session.getSession(dOCBASE));
        }
        catch (Exception exception)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", exception);
            throw new Exception("JDocum.viewDocument() : " + exception.Message);
        }
    }

    public string[] getObjIDPolizaEndoso(string num_poliza, string num_spto, string tipo_doc)
    {
        DmSearch search = null;
        DataTable table = null;
        string dOCBASE  = ConfigurationSettings.AppSettings["DocBase"];
        
        try
        {
            DmPersistentSession session = DmPersistentSession.getInstance();
            if (!session.hasIdentity())
            {
                session.User = ConfigurationSettings.AppSettings["DocUsr"];
                session.Password = ConfigurationSettings.AppSettings["DocPass"];
            }
            search = new DmSearch();
            search.Session = session.getSession(dOCBASE);
            search.CommandText = "select * from mmx_poliza where num_poliza = '" + num_poliza + "' and num_spto = '" + num_spto + "' and tipo_doc = '" + tipo_doc + "'";
            table = search.execute();

            if (((table != null) && (table.Rows.Count > 0)) && (table.Rows[0][0] != DBNull.Value))
            {
                string[] datos = new string[2] { Convert.ToString(table.Rows[0][0]), Convert.ToString(table.Rows[0][1]) };
                return datos;
            }
        }
        catch (Exception exception)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", exception);
            throw new Exception("JDocum.getObjIDPolizaEndoso() : " + exception.Message);
        }
        return null;
    }

    public string importDocument(string FileName, string FilePath, string ObjectTypeName, Hashtable Attributes)
    {
        DmContent content = null;
        string strObjectID = "";
        string dOCBASE = ConfigurationSettings.AppSettings["DocBase"];
        string destinationFolder = ConfigurationSettings.AppSettings["PathCabinet"] + "/" + DateTime.Today.ToString("yyyy");
        try
        {
            DmPersistentSession session = DmPersistentSession.getInstance();
            if (!session.hasIdentity())
            {
                session.User = ConfigurationSettings.AppSettings["DocUsr"];
                session.Password = ConfigurationSettings.AppSettings["DocPass"];
            }
            content = new DmContent();
            FilePath = FilePath + @"\" + FileName;
            FileInfo info = new FileInfo(FilePath);
            string strFormat = content.getFormat(info.Extension.Replace(".", ""), DmFormatType.Extension, session.getSession(dOCBASE));
            strObjectID = content.importContentSingleObject(FileName, ObjectTypeName, FilePath, strFormat, destinationFolder, session.getSession(dOCBASE));
            if (strObjectID != null)
            {
                content.setObjectAttributes(strObjectID, Attributes, session.getSession(dOCBASE));
                info.Delete();
            }
        }
        catch (Exception exception)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", exception);
            throw new Exception("JDocum.importDocument() : " + exception.Message);
        }
        return strObjectID;
    }

    public void viewDocument(string r_object_id, System.Web.HttpResponse resp)
    {
        string dOCBASE = ConfigurationSettings.AppSettings["DocBase"];
        try
        {
            DmPersistentSession session = DmPersistentSession.getInstance();
            if (!session.hasIdentity())
            {
                session.User = ConfigurationSettings.AppSettings["DocUsr"];
                session.Password = ConfigurationSettings.AppSettings["DocPass"];
            }
            new DmContent().getContentToWebView(resp, r_object_id, "", session.getSession(dOCBASE));
        }
        catch (Exception exception)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", exception);
            throw new Exception("JDocum.viewDocument() : " + exception.Message);
        }
    }

    public string getObjIDPolizaEndosoNew(string num_poliza, string num_spto, string tipo_doc)
    {
        DmSearch search = null;
        DataTable table = null;
        string dOCBASE = ConfigurationSettings.AppSettings["DocBase"];
        try
        {
            DmPersistentSession session = DmPersistentSession.getInstance();
            if (!session.hasIdentity())
            {
                session.User = ConfigurationSettings.AppSettings["DocUsr"];
                session.Password = ConfigurationSettings.AppSettings["DocPass"];
            }
            search = new DmSearch();
            search.Session = session.getSession(dOCBASE);
            search.CommandText = "select r_object_id from mmx_poliza where num_poliza = '" + num_poliza + "' and num_spto = '" + num_spto + "' and tipo_doc = '" + tipo_doc + "'";
            table = search.execute();
            if (((table != null) && (table.Rows.Count > 0)) && (table.Rows[0][0] != DBNull.Value))
            {
                return Convert.ToString(table.Rows[0][0]);
            }
        }
        catch (Exception exception)
        {
            throw new Exception("JDocum.getObjIDPolizaEndoso() : " + exception.Message);
        }
        return null;
    }
}