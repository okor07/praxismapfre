﻿using System;
using System.Text;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Oracle.DataAccess.Client;
using MapfreMMX.emision;
using MapfreMMX.oracle;
using MapfreMMX.util;
using MapfreMMX.emision.tabla;
using System.Net;
using System.Xml;
using System.IO;
using System.Collections.Generic;
using System.Xml.Linq;

/// <summary> 
/// Summary description for FirmaDigital
/// </summary>
public class FirmaDigital : Page
{
    public FirmaDigital()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public string EnviaFirma105(string numCotizacion, string nomContratante, string nomAsegurado, string nomAseguradoMancomunado, string agente, string ramo, string mailContratante, string mailAsegurado, string mailAseguradoMancomunado, string mailAgente)
    {
        XmlDocument soapEnvelopeXml = new XmlDocument();
        XmlDocument XmlDoc = new XmlDocument();
        string res = "";
        string file = string.Empty;
        string editado = "N";
        try
        {
            string formKey = "PDF_" + DateTime.Now.ToString("yyyyMMddHHmmss");
            string INIT_Date = DateTime.Today.ToString("dd/MM/yyyy");

            Byte[] bytes = File.ReadAllBytes("C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Firma\\" + numCotizacion + ".pdf");
            file = Convert.ToBase64String(bytes);

            if (nomAsegurado != "" && nomAseguradoMancomunado != "")
            {
                soapEnvelopeXml.LoadXml(@"<ThirdPartyFormUpdateRQ>
	                <Security_Data>
		                <Unique_Data>
			                <Login_Data>
				                <Login_Id>" + ConfigurationManager.AppSettings["LoginId"] + @"</Login_Id>
				                <Application_Code>" + ConfigurationManager.AppSettings["AppCode"] + @"</Application_Code>
			                </Login_Data>
		                </Unique_Data>
		                <Password>" + ConfigurationManager.AppSettings["PasswordSd"] + @"</Password>
		                <Merchant_Id>" + ConfigurationManager.AppSettings["MerchantId"] + @"</Merchant_Id>
	                </Security_Data>
	                <FormDetails>
		                <FormKey>" + formKey + @"</FormKey>
		                <ProductId>" + ConfigurationManager.AppSettings["ProductId"] + @"</ProductId>
		                <PDF_Certification>
			                <User_Validation>
				                <INIT_DOCUMENT_TO_CERTIFICATE>
					                <INIT_Date>" + INIT_Date + @"</INIT_Date>
					                <Number_of_Signers>4</Number_of_Signers>
					                <Signature_Counter>2</Signature_Counter>
					                <PDF_Name>" + numCotizacion + @"</PDF_Name>
					                <PDF_to_Certificate>{""isImageControlData"":""N"",
					                ""formKey"":""MTU3NDQ1OTkyNDI2NGNhcmxvcw"",""name"":""Form280420.pdf"",
					                ""isFileData"":""Y"",""fileUploadType"":""Y"",
                                    ""type"":""application/pdf"",
					                ""preservedValue"":""true"",
					                ""fileContent"":""" + file + @"""}</PDF_to_Certificate>
				                </INIT_DOCUMENT_TO_CERTIFICATE>
                                <Signers_Information>
					                <Email_User>" + mailContratante + @"</Email_User>
                                    <Type_of_Signer>Contratante</Type_of_Signer>
					                <Position_to_Sign>2</Position_to_Sign>
				                </Signers_Information>
				                <Signers_Information>
					                <Email_User>" + mailAsegurado + @"</Email_User>
                                    <Type_of_Signer>Asegurado</Type_of_Signer>
					                <Position_to_Sign>3</Position_to_Sign>
				                </Signers_Information>
                                <Signers_Information>
					                <Email_User>" + mailAseguradoMancomunado + @"</Email_User>
                                    <Type_of_Signer>Asegurado</Type_of_Signer>
					                <Position_to_Sign>3</Position_to_Sign>
				                </Signers_Information>
				                <Signers_Information>
					                <Email_User>" + mailAgente + @"</Email_User>
                                    <Type_of_Signer>Agente</Type_of_Signer>
					                <Position_to_Sign>4</Position_to_Sign>
				                </Signers_Information>
			                </User_Validation>
		                </PDF_Certification>
		                <Transition>
			                <Name>" + ConfigurationManager.AppSettings["TransitionName"] + @"</Name>
		                </Transition>
		                <SearchName>" + ConfigurationManager.AppSettings["SearchName"] + @"</SearchName>
                        <PersistenceFormat>XML</PersistenceFormat>
	                </FormDetails>
                </ThirdPartyFormUpdateRQ>");

                MapfreMMX.util.MLogFile.getInstance().writeText("<Login_Id>" + ConfigurationManager.AppSettings["LoginId"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Application_Code>" + ConfigurationManager.AppSettings["AppCode"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Password>" + ConfigurationManager.AppSettings["PasswordSd"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Merchant_Id>" + ConfigurationManager.AppSettings["MerchantId"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<FormKey>" + formKey);
                MapfreMMX.util.MLogFile.getInstance().writeText("<ProductId>" + ConfigurationManager.AppSettings["ProductId"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<INIT_Date>" + INIT_Date);
                MapfreMMX.util.MLogFile.getInstance().writeText("<PDF_Name>" + numCotizacion);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Email_User>" + mailContratante);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Type_of_Signer>Contratante");
                MapfreMMX.util.MLogFile.getInstance().writeText("<Position_to_Sign>2");
                MapfreMMX.util.MLogFile.getInstance().writeText("<Email_User>" + mailAsegurado);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Type_of_Signer>Asegurado");
                MapfreMMX.util.MLogFile.getInstance().writeText("<Position_to_Sign>3");
                MapfreMMX.util.MLogFile.getInstance().writeText("<Email_User>" + mailAseguradoMancomunado);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Type_of_Signer>Mancomunado");
                MapfreMMX.util.MLogFile.getInstance().writeText("<Position_to_Sign>4");
                MapfreMMX.util.MLogFile.getInstance().writeText("<Email_User>" + mailAgente);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Type_of_Signer>Agente");
                MapfreMMX.util.MLogFile.getInstance().writeText("<Position_to_Sign>4");
                MapfreMMX.util.MLogFile.getInstance().writeText("<TransitionName>" + ConfigurationManager.AppSettings["TransitionName"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<SearchName>" + ConfigurationManager.AppSettings["SearchName"]);
            }
            else if (nomAsegurado != "")
            {
                soapEnvelopeXml.LoadXml(@"<ThirdPartyFormUpdateRQ>
	                <Security_Data>
		                <Unique_Data>
			                <Login_Data>
				                <Login_Id>" + ConfigurationManager.AppSettings["LoginId"] + @"</Login_Id>
				                <Application_Code>" + ConfigurationManager.AppSettings["AppCode"] + @"</Application_Code>
			                </Login_Data>
		                </Unique_Data>
		                <Password>" + ConfigurationManager.AppSettings["PasswordSd"] + @"</Password>
		                <Merchant_Id>" + ConfigurationManager.AppSettings["MerchantId"] + @"</Merchant_Id>
	                </Security_Data>
	                <FormDetails>
		                <FormKey>" + formKey + @"</FormKey>
		                <ProductId>" + ConfigurationManager.AppSettings["ProductId"] + @"</ProductId>
		                <PDF_Certification>
			                <User_Validation>
				                <INIT_DOCUMENT_TO_CERTIFICATE>
					                <INIT_Date>" + INIT_Date + @"</INIT_Date>
					                <Number_of_Signers>4</Number_of_Signers>
					                <Signature_Counter>2</Signature_Counter>
					                <PDF_Name>" + numCotizacion + @"</PDF_Name>
					                <PDF_to_Certificate>{""isImageControlData"":""N"",
					                ""formKey"":""MTU3NDQ1OTkyNDI2NGNhcmxvcw"",""name"":""Form280420.pdf"",
					                ""isFileData"":""Y"",""fileUploadType"":""Y"",
                                    ""type"":""application/pdf"",
					                ""preservedValue"":""true"",
					                ""fileContent"":""" + file + @"""}</PDF_to_Certificate>
				                </INIT_DOCUMENT_TO_CERTIFICATE>
                                <Signers_Information>
					                <Email_User>" + mailContratante + @"</Email_User>
                                    <Type_of_Signer>Contratante</Type_of_Signer>
					                <Position_to_Sign>2</Position_to_Sign>
				                </Signers_Information>
				                <Signers_Information>
					                <Email_User>" + mailAsegurado + @"</Email_User>
                                    <Type_of_Signer>Asegurado</Type_of_Signer>
					                <Position_to_Sign>3</Position_to_Sign>
				                </Signers_Information>
				                <Signers_Information>
					                <Email_User>" + mailAgente + @"</Email_User>
                                    <Type_of_Signer>Agente</Type_of_Signer>
					                <Position_to_Sign>4</Position_to_Sign>
				                </Signers_Information>
			                </User_Validation>
		                </PDF_Certification>
		                <Transition>
			                <Name>" + ConfigurationManager.AppSettings["TransitionName"] + @"</Name>
		                </Transition>
		                <SearchName>" + ConfigurationManager.AppSettings["SearchName"] + @"</SearchName>
                        <PersistenceFormat>XML</PersistenceFormat>
	                </FormDetails>
                </ThirdPartyFormUpdateRQ>");

                MapfreMMX.util.MLogFile.getInstance().writeText("<Login_Id>" + ConfigurationManager.AppSettings["LoginId"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Application_Code>" + ConfigurationManager.AppSettings["AppCode"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Password>" + ConfigurationManager.AppSettings["PasswordSd"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Merchant_Id>" + ConfigurationManager.AppSettings["MerchantId"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<FormKey>" + formKey);
                MapfreMMX.util.MLogFile.getInstance().writeText("<ProductId>" + ConfigurationManager.AppSettings["ProductId"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<INIT_Date>" + INIT_Date);
                MapfreMMX.util.MLogFile.getInstance().writeText("<PDF_Name>" + numCotizacion);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Email_User>" + mailContratante);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Type_of_Signer>Contratante");
                MapfreMMX.util.MLogFile.getInstance().writeText("<Position_to_Sign>2");
                MapfreMMX.util.MLogFile.getInstance().writeText("<Email_User>" + mailAsegurado);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Type_of_Signer>Asegurado");
                MapfreMMX.util.MLogFile.getInstance().writeText("<Position_to_Sign>3");
                MapfreMMX.util.MLogFile.getInstance().writeText("<Email_User>" + mailAgente);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Type_of_Signer>Agente");
                MapfreMMX.util.MLogFile.getInstance().writeText("<Position_to_Sign>4");
                MapfreMMX.util.MLogFile.getInstance().writeText("<TransitionName>" + ConfigurationManager.AppSettings["TransitionName"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<SearchName>" + ConfigurationManager.AppSettings["SearchName"]);
            }
            else
            {
                soapEnvelopeXml.LoadXml(@"<ThirdPartyFormUpdateRQ>
	                <Security_Data>
		                <Unique_Data>
			                <Login_Data>
				                <Login_Id>" + ConfigurationManager.AppSettings["LoginId"] + @"</Login_Id>
				                <Application_Code>" + ConfigurationManager.AppSettings["AppCode"] + @"</Application_Code>
			                </Login_Data>
		                </Unique_Data>
		                <Password>" + ConfigurationManager.AppSettings["PasswordSd"] + @"</Password>
		                <Merchant_Id>" + ConfigurationManager.AppSettings["MerchantId"] + @"</Merchant_Id>
	                </Security_Data>
	                <FormDetails>
		                <FormKey>" + formKey + @"</FormKey>
		                <ProductId>" + ConfigurationManager.AppSettings["ProductId"] + @"</ProductId>
		                <PDF_Certification>
			                <User_Validation>
				                <INIT_DOCUMENT_TO_CERTIFICATE>
					                <INIT_Date>" + INIT_Date + @"</INIT_Date>
					                <Number_of_Signers>4</Number_of_Signers>
					                <Signature_Counter>2</Signature_Counter>
					                <PDF_Name>" + numCotizacion + @"</PDF_Name>
					                <PDF_to_Certificate>{""isImageControlData"":""N"",
					                ""formKey"":""MTU3NDQ1OTkyNDI2NGNhcmxvcw"",""name"":""Form280420.pdf"",
					                ""isFileData"":""Y"",""fileUploadType"":""Y"",
                                    ""type"":""application/pdf"",
					                ""preservedValue"":""true"",
					                ""fileContent"":""" + file + @"""}</PDF_to_Certificate>
				                </INIT_DOCUMENT_TO_CERTIFICATE>
                                <Signers_Information>
					                <Email_User>" + mailContratante + @"</Email_User>
                                    <Type_of_Signer>Contratante</Type_of_Signer>
					                <Position_to_Sign>2</Position_to_Sign>
				                </Signers_Information>
				                <Signers_Information>
					                <Email_User>" + mailAgente + @"</Email_User>
                                    <Type_of_Signer>Agente</Type_of_Signer>
					                <Position_to_Sign>4</Position_to_Sign>
				                </Signers_Information>
			                </User_Validation>
		                </PDF_Certification>
		                <Transition>
			                <Name>" + ConfigurationManager.AppSettings["TransitionName"] + @"</Name>
		                </Transition>
		                <SearchName>" + ConfigurationManager.AppSettings["SearchName"] + @"</SearchName>
                        <PersistenceFormat>XML</PersistenceFormat>
	                </FormDetails>
                </ThirdPartyFormUpdateRQ>");

                MapfreMMX.util.MLogFile.getInstance().writeText("<Login_Id>" + ConfigurationManager.AppSettings["LoginId"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Application_Code>" + ConfigurationManager.AppSettings["AppCode"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Password>" + ConfigurationManager.AppSettings["PasswordSd"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Merchant_Id>" + ConfigurationManager.AppSettings["MerchantId"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<FormKey>" + formKey);
                MapfreMMX.util.MLogFile.getInstance().writeText("<ProductId>" + ConfigurationManager.AppSettings["ProductId"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<INIT_Date>" + INIT_Date);
                MapfreMMX.util.MLogFile.getInstance().writeText("<PDF_Name>" + numCotizacion);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Email_User>" + mailContratante);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Type_of_Signer>Contratante");
                MapfreMMX.util.MLogFile.getInstance().writeText("<Position_to_Sign>2");
                MapfreMMX.util.MLogFile.getInstance().writeText("<Email_User>" + mailAgente);
                MapfreMMX.util.MLogFile.getInstance().writeText("<Type_of_Signer>Agente");
                MapfreMMX.util.MLogFile.getInstance().writeText("<Position_to_Sign>4");
                MapfreMMX.util.MLogFile.getInstance().writeText("<TransitionName>" + ConfigurationManager.AppSettings["TransitionName"]);
                MapfreMMX.util.MLogFile.getInstance().writeText("<SearchName>" + ConfigurationManager.AppSettings["SearchName"]);
            }



            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            HttpWebRequest request = CreateWebRequest();

            using (Stream stream = request.GetRequestStream())
            {
                soapEnvelopeXml.Save(stream);
            }


            //MapfreMMX.util.MLogFile.getInstance().writeText("XML:" + soapEnvelopeXml.InnerXml);
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                Stream receiveStream = response.GetResponseStream();
                StreamReader rdStream = new StreamReader(receiveStream);
                string resqService = rdStream.ReadToEnd();
                MapfreMMX.util.MLogFile.getInstance().writeText("ResponseService: " + resqService);

                XmlDoc.LoadXml(resqService);
            }
        }
        catch (WebException ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("WebException: " + ex.Message);
        }
        try
        {
            string formId = XmlDoc.SelectSingleNode("ThirdPartyFormUpdateRS/FormDetails/FormId").InnerText;
            string formKey = XmlDoc.SelectSingleNode("ThirdPartyFormUpdateRS/FormDetails/FormKey").InnerText;

            MapfreMMX.util.MLogFile.getInstance().writeText("formId: " + formId);
            MapfreMMX.util.MLogFile.getInstance().writeText("formKey: " + formKey);

            res = formId + "|" + formKey;

            //20230822: Agregar llamada a SP para insertar los correos de los intervinientes de la póliza en una tabla para poder editarse.
            MetodosAjax objMetodosAjax = new MetodosAjax();
            bool inserta = objMetodosAjax.insertarCorreos(numCotizacion, formId, formKey, ramo, mailContratante, mailAsegurado, mailAgente, "", file, editado);
        }
        catch (Exception ex1)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Exception EnviaFirma: " + ex1.Message);
            throw new Exception("Error EnviaFirma105():  " + ex1.Message);
        }
        return res;
    }

    public Usuario GetDatosAgente(int agente)
    {
        DataTable tableAgente;
        Usuario objUSUARIO = new Usuario();

        Catalogos objCatalogos = new Catalogos();
        tableAgente = objCatalogos.getDATOS_AGENTE(agente);

        if (tableAgente != null && tableAgente.Rows.Count > 0)
        {
            DataRow datosAgente = tableAgente.Rows[0];

            objUSUARIO.NOMBRE = datosAgente["NOM_TERCERO"].ToString();
            objUSUARIO.PATERNO = datosAgente["APE1_TERCERO"].ToString();
            objUSUARIO.MATERNO = datosAgente["APE2_TERCERO"].ToString();
        }
        return objUSUARIO;
    }

    public string EnviaFirma(string numCotizacion, string nomContratante, string nomAsegurado, string agente, string ramo, string mailContratante, string mailAsegurado, string mailAgente, string fecNacAseg)
    {
        XmlDocument soapEnvelopeXml = new XmlDocument();
        XmlDocument XmlDoc = new XmlDocument();
        string res = "";
        string file = string.Empty;
        string editado = "N";

        try
        {
            Usuario datosAgente = GetDatosAgente(Convert.ToInt32(agente));

            string[] nombreContratante = nomContratante.Split('|');
            var dictContratante = new Dictionary<string, string>();
            dictContratante.Add("nombre", nombreContratante[0]);
            dictContratante.Add("apellido_paterno", nombreContratante[1]);
            dictContratante.Add("apellido_materno", nombreContratante[2]);

            string[] nombreAsegurado = nomAsegurado.Split('|');
            var dictAsegurado = new Dictionary<string, string>();
            dictAsegurado.Add("nombre", nombreAsegurado[0]);
            dictAsegurado.Add("apellido_paterno", nombreAsegurado[1]);
            dictAsegurado.Add("apellido_materno", nombreAsegurado[2]);

            string formKey = "PDF_" + DateTime.Now.ToString("yyyyMMddHHmmss");
            string INIT_Date = DateTime.Today.ToString("dd/MM/yyyy");

            //Se valida que el mail del contratante y el asegurado sea el mismo
            bool contratanteYasegurado = (mailContratante.Trim() == mailAsegurado.Trim()) ? true : false;

            Byte[] bytes = File.ReadAllBytes("C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Firma\\" + numCotizacion + ".pdf");
            file = Convert.ToBase64String(bytes);
            soapEnvelopeXml.LoadXml(@"<ThirdPartyFormUpdateRQ>
	                                    <Security_Data>
		                                    <Unique_Data>
			                                    <Login_Data>
				                                    <Login_Id>" + ConfigurationManager.AppSettings["LoginId"] + @"</Login_Id>
				                                    <Application_Code>" + ConfigurationManager.AppSettings["AppCode"] + @"</Application_Code>
			                                    </Login_Data>
		                                    </Unique_Data>
		                                    <Password>" + ConfigurationManager.AppSettings["PasswordSd"] + @"</Password>
		                                    <Merchant_Id>" + ConfigurationManager.AppSettings["MerchantId"] + @"</Merchant_Id>
	                                    </Security_Data>
	                                    <FormDetails>
		                                    <FormKey>" + formKey + @"</FormKey>
		                                    <ProductId>" + ConfigurationManager.AppSettings["ProductId"] + @"</ProductId>
		                                    <PDF_Certification>
			                                    <User_Validation>
				                                    <INIT_DOCUMENT_TO_CERTIFICATE>
					                                    <INIT_Date>" + INIT_Date + @"</INIT_Date>
					                                    <Number_of_Signers>" + ((contratanteYasegurado) ? "3" : "4") + @"</Number_of_Signers>
					                                    <Signature_Counter>2</Signature_Counter>
					                                    <PDF_Name>" + numCotizacion + @"</PDF_Name>
                                                        <PDF_Password>" + fecNacAseg + @"</PDF_Password>
					                                    <PDF_to_Certificate>{""isImageControlData"":""N"",
					                                    ""formKey"":""MTU3NDQ1OTkyNDI2NGNhcmxvcw"",""name"":""Form280420.pdf"",
					                                    ""isFileData"":""Y"",""fileUploadType"":""Y"",
                                                        ""type"":""application/pdf"",
					                                    ""preservedValue"":""true"",
					                                    ""fileContent"":""" + file + @"""}</PDF_to_Certificate>
				                                    </INIT_DOCUMENT_TO_CERTIFICATE>"
                                                    + ((contratanteYasegurado) ?
                                                    @"
                                                    <Signers_Information>
					                                    <Email_User>" + mailContratante + @"</Email_User>
                                                        <Type_of_Signer>Contratante y Asegurado</Type_of_Signer>
					                                    <Position_to_Sign>2</Position_to_Sign>
                                                        <SignerId>2</SignerId>
					                                    <Signer_Name>" + dictContratante["nombre"] + @"</Signer_Name>
					                                    <Signer_Paternal_Name>" + dictContratante["apellido_paterno"] + @"</Signer_Paternal_Name>
					                                    <Signer_Maternal_Name>" + dictContratante["apellido_materno"] + @"</Signer_Maternal_Name>
				                                    </Signers_Information>
                                                    <Signers_Information>
					                                    <Email_User>" + mailAgente + @"</Email_User>
                                                        <Type_of_Signer>Agente</Type_of_Signer>
					                                    <Position_to_Sign>3</Position_to_Sign>
					                                    <SignerId>3</SignerId>
					                                    <Signer_Name>" + datosAgente.NOMBRE + @"</Signer_Name>
					                                    <Signer_Paternal_Name>" + datosAgente.PATERNO + @"</Signer_Paternal_Name>
					                                    <Signer_Maternal_Name>" + datosAgente.MATERNO + @"</Signer_Maternal_Name>
				                                    </Signers_Information>"
                                                    : @"
                                                    <Signers_Information>
					                                    <Email_User>" + mailContratante + @"</Email_User>
                                                        <Type_of_Signer>Contratante</Type_of_Signer>
					                                    <Position_to_Sign>2</Position_to_Sign>
                                                        <SignerId>2</SignerId>
					                                    <Signer_Name>" + dictContratante["nombre"] + @"</Signer_Name>
					                                    <Signer_Paternal_Name>" + dictContratante["apellido_paterno"] + @"</Signer_Paternal_Name>
					                                    <Signer_Maternal_Name>" + dictContratante["apellido_materno"] + @"</Signer_Maternal_Name>
				                                    </Signers_Information>
				                                    <Signers_Information>
					                                    <Email_User>" + mailAsegurado + @"</Email_User>
                                                        <Type_of_Signer>Asegurado</Type_of_Signer>
					                                    <Position_to_Sign>3</Position_to_Sign>
                                                        <SignerId>3</SignerId>
					                                    <Signer_Name>" + dictAsegurado["nombre"] + @"</Signer_Name>
					                                    <Signer_Paternal_Name>" + dictAsegurado["apellido_paterno"] + @"</Signer_Paternal_Name>
					                                    <Signer_Maternal_Name>" + dictAsegurado["apellido_materno"] + @"</Signer_Maternal_Name>
				                                    </Signers_Information>
				                                    <Signers_Information>
					                                    <Email_User>" + mailAgente + @"</Email_User>
                                                        <Type_of_Signer>Agente</Type_of_Signer>
					                                    <Position_to_Sign>4</Position_to_Sign>
					                                    <SignerId>4</SignerId>
					                                    <Signer_Name>" + datosAgente.NOMBRE + @"</Signer_Name>
					                                    <Signer_Paternal_Name>" + datosAgente.PATERNO + @"</Signer_Paternal_Name>
					                                    <Signer_Maternal_Name>" + datosAgente.MATERNO + @"</Signer_Maternal_Name>
				                                    </Signers_Information>")
                                                + @"
			                                    </User_Validation>
		                                    </PDF_Certification>
		                                    <Transition>
			                                    <Name>" + ConfigurationManager.AppSettings["TransitionName"] + @"</Name>
		                                    </Transition>
		                                    <SearchName>" + ConfigurationManager.AppSettings["SearchName"] + @"</SearchName>
                                            <PersistenceFormat>XML</PersistenceFormat>
	                                    </FormDetails>
                                    </ThirdPartyFormUpdateRQ>");

            MapfreMMX.util.MLogFile.getInstance().writeText("<Login_Id>" + ConfigurationManager.AppSettings["LoginId"]);
            MapfreMMX.util.MLogFile.getInstance().writeText("<Application_Code>" + ConfigurationManager.AppSettings["AppCode"]);
            MapfreMMX.util.MLogFile.getInstance().writeText("<Password>" + ConfigurationManager.AppSettings["PasswordSd"]);
            MapfreMMX.util.MLogFile.getInstance().writeText("<Merchant_Id>" + ConfigurationManager.AppSettings["MerchantId"]);
            MapfreMMX.util.MLogFile.getInstance().writeText("<FormKey>" + formKey);
            MapfreMMX.util.MLogFile.getInstance().writeText("<ProductId>" + ConfigurationManager.AppSettings["ProductId"]);
            MapfreMMX.util.MLogFile.getInstance().writeText("<INIT_Date>" + INIT_Date);
            MapfreMMX.util.MLogFile.getInstance().writeText("<PDF_Name>" + numCotizacion);
            MapfreMMX.util.MLogFile.getInstance().writeText("<Email_User>" + mailContratante);
            MapfreMMX.util.MLogFile.getInstance().writeText("<Type_of_Signer>Contratante");
            MapfreMMX.util.MLogFile.getInstance().writeText("<Position_to_Sign>2");
            MapfreMMX.util.MLogFile.getInstance().writeText("<Email_User>" + mailAsegurado);
            MapfreMMX.util.MLogFile.getInstance().writeText("<Type_of_Signer>Asegurado");
            MapfreMMX.util.MLogFile.getInstance().writeText("<Position_to_Sign>3");
            MapfreMMX.util.MLogFile.getInstance().writeText("<Email_User>" + mailAgente);
            MapfreMMX.util.MLogFile.getInstance().writeText("<Type_of_Signer>Agente");
            MapfreMMX.util.MLogFile.getInstance().writeText("<Position_to_Sign>4");
            MapfreMMX.util.MLogFile.getInstance().writeText("<TransitionName>" + ConfigurationManager.AppSettings["TransitionName"]);
            MapfreMMX.util.MLogFile.getInstance().writeText("<SearchName>" + ConfigurationManager.AppSettings["SearchName"]);

            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            HttpWebRequest request = CreateWebRequest();

            using (Stream stream = request.GetRequestStream())
            {
                soapEnvelopeXml.Save(stream);
            }


            //MapfreMMX.util.MLogFile.getInstance().writeText("XML:" + soapEnvelopeXml.InnerXml);
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                Stream receiveStream = response.GetResponseStream();
                StreamReader rdStream = new StreamReader(receiveStream);
                string resqService = rdStream.ReadToEnd();
                MapfreMMX.util.MLogFile.getInstance().writeText("ResponseService: " + resqService);

                XmlDoc.LoadXml(resqService);
            }
        }
        catch (WebException ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("WebException: " + ex.Message);
        }
        try
        {
            string formId = XmlDoc.SelectSingleNode("ThirdPartyFormUpdateRS/FormDetails/FormId").InnerText;
            string formKey = XmlDoc.SelectSingleNode("ThirdPartyFormUpdateRS/FormDetails/FormKey").InnerText;

            MapfreMMX.util.MLogFile.getInstance().writeText("formId: " + formId);
            MapfreMMX.util.MLogFile.getInstance().writeText("formKey: " + formKey);

            res = formId + "|" + formKey;

            //20230822: Agregar llamada a SP para insertar los correos de los intervinientes de la póliza en una tabla para poder editarse.
            MetodosAjax objMetodosAjax = new MetodosAjax();
            bool inserta = objMetodosAjax.insertarCorreos(numCotizacion, formId, formKey, ramo, mailContratante, mailAsegurado, mailAgente, "", file, editado);
        }
        catch (Exception ex1)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Exception EnviaFirma: " + ex1.Message);
            throw new Exception("Error EnviaFirma():  " + ex1.Message);
        }
        return res;
    }

    public static HttpWebRequest CreateWebRequest()
    {
        var _url = ConfigurationManager.AppSettings["UrlRest"].ToString();
        MapfreMMX.util.MLogFile.getInstance().writeText("UrlRequest:" + ConfigurationManager.AppSettings["UrlRest"].ToString());
        //var _action = "IDS/service/integ/idm/thirdparty/upsert";
        HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(_url);
        webRequest.Headers.Add(@"SOAP:Action");
        webRequest.ContentType = "application/xml;charset=utf-8";
        //webRequest.ContentLength= 1786784;
        webRequest.Timeout = 1000000000;
        webRequest.Accept = "application/xml;";
        webRequest.Method = "POST";
        return webRequest;
    }

    public bool InsertaDatos(string cod_cia, string cod_ramo, string id_transaccion, string num_folio, string num_poliza,
        string nom_contratante, string nom_aseg, string fec_ini_tramite, string cod_agt, string txt_solicitud, string txt_estatus,
        string fec_efec, string fec_vcto)
    {
        MCommand cmd = new MCommand();
        bool resp = false;
        DataRow dr;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "tron2000.em_k_gen_firma_digital_mmx.p_inserta";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, Convert.ToInt32(cod_cia));
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, Convert.ToInt32(cod_ramo));
                cmd.agregarINParametro("p_id_transaccion", OracleDbType.Varchar2, id_transaccion);
                cmd.agregarINParametro("p_num_folio", OracleDbType.Varchar2, num_folio);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, num_poliza);
                cmd.agregarINParametro("p_nom_contratante", OracleDbType.Varchar2, nom_contratante);
                cmd.agregarINParametro("p_nom_aseg", OracleDbType.Varchar2, nom_contratante);
                cmd.agregarINParametro("p_fec_ini_tramite", OracleDbType.Varchar2, fec_ini_tramite);
                cmd.agregarINParametro("p_cod_agt", OracleDbType.Int32, cod_agt);
                cmd.agregarINParametro("p_txt_solicitud", OracleDbType.Clob, txt_solicitud);
                cmd.agregarINParametro("p_txt_estatus", OracleDbType.Varchar2, txt_estatus);
                cmd.agregarINParametro("p_fec_efec_poliza", OracleDbType.Varchar2, fec_efec);
                cmd.agregarINParametro("p_fec_vcto_poliza", OracleDbType.Varchar2, fec_vcto);

                dr = cmd.ejecutarRegistroSP();
                resp = true;

            }
        }
        catch (Exception ex)
        {
            resp = false;
            {
                throw new Exception("Error EnviarFirmaElectronica.InsertaDatos():  " + ex.Message);
                MapfreMMX.util.MLogFile.getInstance().writeText("Error EnviarFirmaElectronica.InsertaDatos():  " + ex.Message);
            }
        }
        return resp;
    }

    public string EnviaFirmaMod(string numCotizacion, string transaccionAnt, string folioAnt, string mailContratante, string mailAsegurado, string mailAgente, string telefono)
    {
        XmlDocument soapEnvelopeXml = new XmlDocument();
        XmlDocument XmlDoc = new XmlDocument();
        string res = "";
        string ramo = string.Empty;
        string file = string.Empty;
        string editado = "S";
        string xmlSolicitud = "";
        MetodosAjax objMetodosAjax = new MetodosAjax();
        try
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Entra a FirmaDigital.cs->EnviaFirmaMod:");
            string formKey = "PDF_" + DateTime.Now.ToString("yyyyMMddHHmmss");
            string INIT_Date = DateTime.Today.ToString("dd/MM/yyyy");

            //Obtener el codigo base 64 de la tabla TRON2000.A2300817_MMX.
            DataRow drCorreos = objMetodosAjax.consultaCorreos(numCotizacion, transaccionAnt, folioAnt);
            file = drCorreos["PDFBase64"].ToString();
            ramo = drCorreos["COD_RAMO"].ToString();

            string codAgente = drCorreos["COD_AGT"].ToString();
            Usuario datosAgente = GetDatosAgente(Convert.ToInt32(codAgente));

            xmlSolicitud = drCorreos["TXT_SOLICITUD"].ToString();

            var clmAseguradoContratante = ObtenerCLMAseguradoContratante(xmlSolicitud);
            DataRow drContratante = objMetodosAjax.ConsultaInfoCLM(clmAseguradoContratante["clmContratante"].ToString());
            DataRow drAsegurado = objMetodosAjax.ConsultaInfoCLM(clmAseguradoContratante["clmAsegurado"].ToString());

            //Se valida que el mail del contratante y el asegurado sea el mismo
            bool contratanteYasegurado = (mailContratante.Trim() == mailAsegurado.Trim()) ? true : false;


            soapEnvelopeXml.LoadXml(@"<ThirdPartyFormUpdateRQ>
	                                    <Security_Data>
		                                    <Unique_Data>
			                                    <Login_Data>
				                                    <Login_Id>" + ConfigurationManager.AppSettings["LoginId"] + @"</Login_Id>
				                                    <Application_Code>" + ConfigurationManager.AppSettings["AppCode"] + @"</Application_Code>
			                                    </Login_Data>
		                                    </Unique_Data>
		                                    <Password>" + ConfigurationManager.AppSettings["PasswordSd"] + @"</Password>
		                                    <Merchant_Id>" + ConfigurationManager.AppSettings["MerchantId"] + @"</Merchant_Id>
	                                    </Security_Data>
	                                    <FormDetails>
		                                    <FormKey>" + formKey + @"</FormKey>
		                                    <ProductId>" + ConfigurationManager.AppSettings["ProductId"] + @"</ProductId>
		                                    <PDF_Certification>
			                                    <User_Validation>
				                                    <INIT_DOCUMENT_TO_CERTIFICATE>
					                                    <INIT_Date>" + INIT_Date + @"</INIT_Date>
					                                    <Number_of_Signers>" + ((contratanteYasegurado) ? "3" : "4") + @"</Number_of_Signers>
					                                    <Signature_Counter>2</Signature_Counter>
					                                    <PDF_Name>" + numCotizacion + @"</PDF_Name>
                                                        <PDF_Password>" + Convert.ToDateTime(drAsegurado["fec_nacimiento"]).ToString("ddMMyyyy") + @"</PDF_Password>
					                                    <PDF_to_Certificate>{""isImageControlData"":""N"",
					                                    ""formKey"":""MTU3NDQ1OTkyNDI2NGNhcmxvcw"",""name"":""Form280420.pdf"",
					                                    ""isFileData"":""Y"",""fileUploadType"":""Y"",
                                                        ""type"":""application/pdf"",
					                                    ""preservedValue"":""true"",
					                                    ""fileContent"":""" + file + @"""}</PDF_to_Certificate>
				                                    </INIT_DOCUMENT_TO_CERTIFICATE>"
                                                    + ((contratanteYasegurado) ?
                                                    @"
                                                    <Signers_Information>
					                                    <Email_User>" + mailContratante + @"</Email_User>
                                                        <Type_of_Signer>Contratante y Asegurado</Type_of_Signer>
					                                    <Position_to_Sign>2</Position_to_Sign>
                                                        <SignerId>2</SignerId>
					                                    <Signer_Name>" + drContratante["nom_tercero"] + @"</Signer_Name>
					                                    <Signer_Paternal_Name>" + drContratante["ape1_tercero"] + @"</Signer_Paternal_Name>
					                                    <Signer_Maternal_Name>" + drContratante["ape2_tercero"] + @"</Signer_Maternal_Name>
				                                    </Signers_Information>
                                                    <Signers_Information>
					                                    <Email_User>" + mailAgente + @"</Email_User>
                                                        <Type_of_Signer>Agente</Type_of_Signer>
					                                    <Position_to_Sign>3</Position_to_Sign>
					                                    <SignerId>3</SignerId>
					                                    <Signer_Name>" + datosAgente.NOMBRE + @"</Signer_Name>
					                                    <Signer_Paternal_Name>" + datosAgente.PATERNO + @"</Signer_Paternal_Name>
					                                    <Signer_Maternal_Name>" + datosAgente.MATERNO + @"</Signer_Maternal_Name>
				                                    </Signers_Information>"
                                                    : @"
                                                    <Signers_Information>
					                                    <Email_User>" + mailContratante + @"</Email_User>
                                                        <Type_of_Signer>Contratante</Type_of_Signer>
					                                    <Position_to_Sign>2</Position_to_Sign>
                                                        <SignerId>2</SignerId>
					                                    <Signer_Name>" + drContratante["nom_tercero"] + @"</Signer_Name>
					                                    <Signer_Paternal_Name>" + drContratante["ape1_tercero"] + @"</Signer_Paternal_Name>
					                                    <Signer_Maternal_Name>" + drContratante["ape2_tercero"] + @"</Signer_Maternal_Name>
				                                    </Signers_Information>
				                                    <Signers_Information>
					                                    <Email_User>" + mailAsegurado + @"</Email_User>
                                                        <Type_of_Signer>Asegurado</Type_of_Signer>
					                                    <Position_to_Sign>3</Position_to_Sign>
                                                        <SignerId>3</SignerId>
					                                    <Signer_Name>" + drAsegurado["nom_tercero"] + @"</Signer_Name>
					                                    <Signer_Paternal_Name>" + drAsegurado["ape1_tercero"] + @"</Signer_Paternal_Name>
					                                    <Signer_Maternal_Name>" + drAsegurado["ape2_tercero"] + @"</Signer_Maternal_Name>
				                                    </Signers_Information>
				                                    <Signers_Information>
					                                    <Email_User>" + mailAgente + @"</Email_User>
                                                        <Type_of_Signer>Agente</Type_of_Signer>
					                                    <Position_to_Sign>4</Position_to_Sign>
					                                    <SignerId>4</SignerId>
					                                    <Signer_Name>" + datosAgente.NOMBRE + @"</Signer_Name>
					                                    <Signer_Paternal_Name>" + datosAgente.PATERNO + @"</Signer_Paternal_Name>
					                                    <Signer_Maternal_Name>" + datosAgente.MATERNO + @"</Signer_Maternal_Name>
				                                    </Signers_Information>")
                                                + @"
			                                    </User_Validation>
		                                    </PDF_Certification>
		                                    <Transition>
			                                    <Name>" + ConfigurationManager.AppSettings["TransitionName"] + @"</Name>
		                                    </Transition>
		                                    <SearchName>" + ConfigurationManager.AppSettings["SearchName"] + @"</SearchName>
                                            <PersistenceFormat>XML</PersistenceFormat>
	                                    </FormDetails>
                                    </ThirdPartyFormUpdateRQ>");

            MapfreMMX.util.MLogFile.getInstance().writeText("<Login_Id>" + ConfigurationManager.AppSettings["LoginId"]);
            MapfreMMX.util.MLogFile.getInstance().writeText("<Application_Code>" + ConfigurationManager.AppSettings["AppCode"]);
            MapfreMMX.util.MLogFile.getInstance().writeText("<Password>" + ConfigurationManager.AppSettings["PasswordSd"]);
            MapfreMMX.util.MLogFile.getInstance().writeText("<Merchant_Id>" + ConfigurationManager.AppSettings["MerchantId"]);
            MapfreMMX.util.MLogFile.getInstance().writeText("<FormKey>" + formKey);
            MapfreMMX.util.MLogFile.getInstance().writeText("<ProductId>" + ConfigurationManager.AppSettings["ProductId"]);
            MapfreMMX.util.MLogFile.getInstance().writeText("<INIT_Date>" + INIT_Date);
            MapfreMMX.util.MLogFile.getInstance().writeText("<PDF_Name>" + numCotizacion);
            MapfreMMX.util.MLogFile.getInstance().writeText("<Email_User>" + mailContratante);
            MapfreMMX.util.MLogFile.getInstance().writeText("<Type_of_Signer>Contratante");
            MapfreMMX.util.MLogFile.getInstance().writeText("<Position_to_Sign>2");
            MapfreMMX.util.MLogFile.getInstance().writeText("<Email_User>" + mailAsegurado);
            MapfreMMX.util.MLogFile.getInstance().writeText("<Type_of_Signer>Asegurado");
            MapfreMMX.util.MLogFile.getInstance().writeText("<Position_to_Sign>3");
            MapfreMMX.util.MLogFile.getInstance().writeText("<Email_User>" + mailAgente);
            MapfreMMX.util.MLogFile.getInstance().writeText("<Type_of_Signer>Agente");
            MapfreMMX.util.MLogFile.getInstance().writeText("<Position_to_Sign>4");
            MapfreMMX.util.MLogFile.getInstance().writeText("<TransitionName>" + ConfigurationManager.AppSettings["TransitionName"]);
            MapfreMMX.util.MLogFile.getInstance().writeText("<SearchName>" + ConfigurationManager.AppSettings["SearchName"]);
            MapfreMMX.util.MLogFile.getInstance().writeText("XML Generado" + soapEnvelopeXml.InnerXml.ToString());

            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            HttpWebRequest request = CreateWebRequest();

            using (Stream stream = request.GetRequestStream())
            {
                soapEnvelopeXml.Save(stream);
            }


            //MapfreMMX.util.MLogFile.getInstance().writeText("XML:" + soapEnvelopeXml.InnerXml);
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                Stream receiveStream = response.GetResponseStream();
                StreamReader rdStream = new StreamReader(receiveStream);
                string resqService = rdStream.ReadToEnd();
                MapfreMMX.util.MLogFile.getInstance().writeText("ResponseService: " + resqService);

                XmlDoc.LoadXml(resqService);
            }
        }
        catch (WebException ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("WebException: " + ex.Message);
        }
        try
        {
            string formId = XmlDoc.SelectSingleNode("ThirdPartyFormUpdateRS/FormDetails/FormId").InnerText;
            string formKey = XmlDoc.SelectSingleNode("ThirdPartyFormUpdateRS/FormDetails/FormKey").InnerText;

            MapfreMMX.util.MLogFile.getInstance().writeText("formId: " + formId);
            MapfreMMX.util.MLogFile.getInstance().writeText("formKey: " + formKey);

            res = formId + "|" + formKey;

            //20230824: Agregar llamada a SP para insertar los nuevos correos de los intervinientes que ya no se podrán editar.
            bool inserta = objMetodosAjax.insertarCorreos(numCotizacion, formId, formKey, ramo, mailContratante, mailAsegurado, mailAgente, telefono, file, editado);
        }
        catch (Exception ex1)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Exception EnviaFirmaMod: " + ex1.Message);
            throw new Exception("Error EnviaFirmaMod():  " + ex1.Message);
        }
        return res;
    }

    public Dictionary<string, string> ObtenerCLMAseguradoContratante(string _xmlSolicitud)
    {
        string clmAsegurado = "";
        string clmContratante = "";
        string xmlString = "";
        var dictCLMAseguradoContratante = new Dictionary<string, string>();
        try
        {
            // Si se encuentra al menos un pipe, extrae la subcadena hasta el último pipe// Si no se encuentra ningún pipe, asigna el valor completo de _xmlSolicitud
            int lastPipeIndex = _xmlSolicitud.LastIndexOf('|');
            xmlString = (lastPipeIndex >= 0) ? _xmlSolicitud.Substring(0, lastPipeIndex) : _xmlSolicitud;

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xmlString);            

            // Seleccionar todos los elementos ROW bajo TABLE NAME="P2000030" donde TIP_DOCUM es CLM
            XmlNodeList rowsP2000030 = xmlDoc.SelectNodes("/XML/TABLE[@NAME='P2000030']/ROWSET/ROW[TIP_DOCUM='CLM']");

            // Iterar sobre cada elemento ROW
            foreach (XmlNode row in rowsP2000030)
            {
                // Obtener el valor del nodo <COD_DOCUM>
                XmlNode codDocumNode = row.SelectSingleNode("COD_DOCUM");
                if (codDocumNode != null)
                {
                    clmContratante = codDocumNode.InnerText;
                }
            }

            // Seleccionar todos los elementos ROW bajo TABLE NAME="P2000060" donde TIP_BENEF es 2 y TIP_DOCUM es CLM 
            XmlNodeList rowsP2000060 = xmlDoc.SelectNodes("/XML/TABLE[@NAME='P2000060']/ROWSET/ROW[TIP_BENEF='2' and TIP_DOCUM='CLM']");

            // Iterar sobre cada elemento ROW
            foreach (XmlNode row in rowsP2000060)
            {
                // Obtener el valor del nodo <COD_DOCUM>
                XmlNode codDocumNode = row.SelectSingleNode("COD_DOCUM");
                if (codDocumNode != null)
                {
                    clmAsegurado = codDocumNode.InnerText;
                }
            }

            dictCLMAseguradoContratante.Add("clmAsegurado", clmAsegurado);
            dictCLMAseguradoContratante.Add("clmContratante", clmContratante);

        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("ERROR FirmaDigital.ObtenerCLMAseguradoContratante() : " + ex.Message);
            throw new Exception("ERROR FirmaDigital.ObtenerCLMAseguradoContratante() : " + ex.Message);
        }
        return dictCLMAseguradoContratante;
    }
}