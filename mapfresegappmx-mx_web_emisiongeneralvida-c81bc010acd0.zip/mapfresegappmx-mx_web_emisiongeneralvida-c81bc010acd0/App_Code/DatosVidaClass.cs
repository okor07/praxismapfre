//'********************************************************************************************************************
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2010
//'Name of the file              : DatosVidaClass.cs
//'Creation/Modification History :
//'Modification                  : 21-01-2013 jdgomezc Indra SWL 
//                                 Obtiene el IDsistema basado en lo que se realizaba en AltaFolioRam
//26042018                          
//'********************************************************************************************************************

using System;
using System.IO;
using MapfreMMX.oracle;
using Oracle.DataAccess.Client;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Text;
using System.Security.Cryptography;
using System.Web;
using System.Web.SessionState;
using MapfreMMX.emision;
using MapfreMMX.util;
    /// <summary>
    /// Descripci�n breve de DatosVidaClass.
    /// </summary>
public class DatosVidaClass : System.Web.UI.Page
{
    private int SistemaID = 0;

    public DatosVidaClass()
    {
        //Constructor
    }

    private string mDivisional;

    public string Divisional
    {
        get { return mDivisional; }
    }

    private string mRegional;

    public string Regional
    {
        get { return mRegional; }
    }

    private string mNumOT;

    public string NumOT
    {
        get { return mNumOT; }
    }

    private string mFolioRAM;

    public string FolioRAM
    {
        get { return mFolioRAM; }
    }

    private string mCodUsuarioTron = WebUtils.getAppSetting("codUsuario");

    public string CodUsuarioTron
    {
        get { return mCodUsuarioTron; }
    }

    private string mCodUsuarioSeGARAM = WebUtils.getAppSetting("usuarioSeGARAM");

    public string CodUsuarioSeGARAM
    {
        get { return mCodUsuarioSeGARAM; }
    }
    

    private string mCodAgt;

    public string CodAgt
    {
        get { return mCodAgt; }
        set { mCodAgt = value; }
    }

    private void ConsultaEstComercial()
    {
        using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
        {
            DataRow objOficina = getFolioyOficina(conexion, mCodAgt);
            if (objOficina != null)
            {
                mDivisional = objOficina["P_COD_NIVEL1"].ToString();
                mRegional = objOficina["P_COD_NIVEL2"].ToString();
            }
        }
    }

    public DataTable getConsultaBenef(OracleConnection Conexion, string RFC)
    {
        MCommand Comando = new MCommand();
        DataSet objDS = new DataSet();

        try
        {
            Comando.Connection = Conexion;
            Comando.CommandText = "ev_k_solicitudes_web.p_consulta_benef";

            Comando.agregarINParametro("p_cod_cia", OracleDbType.Int16, 1);
            Comando.agregarINParametro("p_tip_docum", OracleDbType.Varchar2, "RFC");
            Comando.agregarINParametro("p_cod_docum", OracleDbType.Varchar2, RFC);
            Comando.agregarOUTParametro("p_persona_fisico", OracleDbType.Varchar2, 80);
            Comando.agregarOUTParametro("p_curp", OracleDbType.Varchar2, 80);

            Comando.agregarOUTParametro("p_nombre_tercero", OracleDbType.Varchar2, 80);
            Comando.agregarOUTParametro("p_ape1_tercero", OracleDbType.Varchar2, 80);
            Comando.agregarOUTParametro("p_ape2_tercero", OracleDbType.Varchar2, 80);
            Comando.agregarOUTParametro("p_domicilio1", OracleDbType.Varchar2, 80);
            Comando.agregarOUTParametro("p_domicilio2", OracleDbType.Varchar2, 80);
            Comando.agregarOUTParametro("p_domicilio3", OracleDbType.Varchar2, 80);
            Comando.agregarOUTParametro("p_cod_postal", OracleDbType.Varchar2, 80);
            Comando.agregarOUTParametro("p_cod_estado", OracleDbType.Int32, 80);

            Comando.agregarOUTParametro("p_nom_estado", OracleDbType.Varchar2, 80);
            Comando.agregarOUTParametro("p_cod_prov", OracleDbType.Int32, 80);
            Comando.agregarOUTParametro("p_nom_prov", OracleDbType.Varchar2, 80);
            Comando.agregarOUTParametro("p_telefono", OracleDbType.Varchar2, 80);
            Comando.agregarOUTParametro("p_email", OracleDbType.Varchar2, 80);
            Comando.agregarOUTParametro("p_cod_ocupacion", OracleDbType.Int32, 80);
            Comando.agregarOUTParametro("p_mca_sexo", OracleDbType.Varchar2, 80);

            objDS = Comando.ejecutarRefCursorSP();

        }//try
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR DatosVidaClass.getConsultaBenef() : " + ex.Message);
        }//catch
        return objDS.Tables[0];
    }//getConsultaBenef

    public DataRow getConsultaAge(OracleConnection Conexion, int COD_AGE)
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataRow objDR;

        try
        {
            cmd.Connection = Conexion;
            cmd.CommandText = "ev_k_solicitudes_web.p_verifica_agente";

            cmd.agregarINParametro("p_cod_cia", OracleDbType.Int16, 1);
            cmd.agregarINParametro("p_cod_agente", OracleDbType.Int32, COD_AGE);
            cmd.agregarOUTParametro("p_nom_agte", OracleDbType.Varchar2, 80);
            cmd.agregarOUTParametro("p_nom_div", OracleDbType.Varchar2, 80);
            cmd.agregarOUTParametro("p_tel_agte", OracleDbType.Varchar2, 80);
            cmd.agregarOUTParametro("p_mail_agte", OracleDbType.Varchar2, 80);
            cmd.agregarOUTParametro("p_cuadro_com", OracleDbType.Int16, 80);
            cmd.agregarOUTParametro("p_valida", OracleDbType.Varchar2, 80);

            objDR = cmd.ejecutarRegistroSP();

            return objDR;
        }//try
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR DatosVidaClass.getConsultaAge() : " + ex.Message);
        }//catch
    }//getConsultaAge

    public string ActualizaP2000020(OracleConnection Conexion, string NumSolicitud, int NumSpto, int NumApli, int SptoApli, 
        int NumRiesgo, int NumPeriodo, string CodCampo, string ValCampo, int CodRamo, int CodCia)
    {
        MCommand cmd = new MCommand();
        string Result = "OK";

        try
        {
            cmd.Connection = Conexion;
            cmd.CommandText = "ev_k_solicitudes_web.p_actualiza_datosvar";
            cmd.agregarINParametro("p_cod_cia", OracleDbType.Int16, CodCia);
            cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, NumSolicitud);
            cmd.agregarINParametro("p_num_spto", OracleDbType.Int16, NumSpto);
            cmd.agregarINParametro("p_num_apli", OracleDbType.Int16, NumApli);
            cmd.agregarINParametro("p_num_spto_apli", OracleDbType.Int16, SptoApli);
            cmd.agregarINParametro("p_num_riesgo", OracleDbType.Int16, NumRiesgo);
            cmd.agregarINParametro("p_num_periodo", OracleDbType.Int16, NumPeriodo);
            cmd.agregarINParametro("p_cod_campo", OracleDbType.Varchar2, CodCampo);
            cmd.agregarINParametro("p_val_campo", OracleDbType.Varchar2, ValCampo);
            cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int16, CodRamo);

            cmd.ejecutarSP();

        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string strError = "Ocurrieron problemas en los procedimientos que graban y/o traspasan el Folio RAM, el mensaje del sistema es: " + Error.Message.ToString() + "Procedimiento ev_k_solicitudes_web.p_actualiza_datosvar";
            Session.Add("Error", strError);

        }

        return Result;

    }
    public DataRow ActualizarFolio(string numPoliza, string numeroendoso, string folio)
    {
        DataRow outRow;
        MCommand cmd = new MCommand();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                string strPaqueteParaWM = ConfigurationManager.AppSettings["PaqueteParaWM"].ToString();

                cmd.Connection = conexion;
                cmd.CommandText = strPaqueteParaWM + ".p_act_folio_ram";
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, numPoliza);
                cmd.agregarINParametro("p_spto", OracleDbType.Varchar2, numeroendoso);
                cmd.agregarINParametro("p_folio_ram", OracleDbType.Varchar2, mFolioRAM);
                cmd.agregarOUTParametro("p_error", OracleDbType.Varchar2, 2000);

                outRow = cmd.ejecutarRegistroSP();

            }
            return outRow;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("Error: cGenerales.getCatalogoPorUsuario() - ", ex);
        }

    }

    public void fnGrabaFol008(string NOM_ASEGURADO, string NUM_POLIZA, string COD_ESTADO)
    {
        try
        {
            MCommand cmd = new MCommand();
            DataRow objDR;

            if (mFolioRAM == "") mFolioRAM = "0";
            string NUM_ANIO_FOLIO = DateTime.Now.Date.ToString("yyyy");
            //string COD_AGT = Session["COD_AGT"].ToString();
            string COD_RAMO = Session["COD_RAMO"].ToString();
            //string USR_CAPTURA_TRON = Session["Usuario"].ToString();
            //string mCodUsuarioTron = WebUtils.getAppSetting("codUsuario");

            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "ev_k_solicitudes_web.p_inserta_folio";

                cmd.agregarINParametro("p_num_folio", OracleDbType.Double, Convert.ToDouble(mFolioRAM));
                cmd.agregarINParametro("p_num_anio_folio", OracleDbType.Varchar2, NUM_ANIO_FOLIO);
                cmd.agregarINParametro("p_cod_agt", OracleDbType.Varchar2, mCodAgt);
                cmd.agregarINParametro("p_fec_cap_div", OracleDbType.Date, DateTime.Today);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, NUM_POLIZA);
                cmd.agregarINParametro("p_fec_captura", OracleDbType.Date, DateTime.Today);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Varchar2, COD_RAMO);
                cmd.agregarINParametro("p_nom_asegurado", OracleDbType.Varchar2, NOM_ASEGURADO);
                cmd.agregarINParametro("p_usr_captura_tron", OracleDbType.Varchar2, mCodUsuarioTron);
                cmd.agregarOUTParametro("p_result", OracleDbType.Varchar2, 200);

                objDR = cmd.ejecutarRegistroSP();
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string strError = "Ocurrieron problemas en los procedimientos que graban y/o traspasan el Folio RAM, el mensaje del sistema es: " + Error.Message.ToString() + "Procedimiento fnGrabaFol008";
            Session.Add("Error", strError);
        }
    }

    //C1
    /// <summary>
    /// Obtiene el IDsistema basado en lo que se realizaba en AltaFolioRam
    /// </summary>
    /// <returns></returns>
    public string ObtenerIDSistema()
    {
        string p_wf_ot_m_ot = "";
        try
        {
            using (OracleConnection Conexion = MConexion.getConexion("ConnectionSEGA"))
            {
                p_wf_ot_m_ot = get_p_wf_ot_m_ot(Conexion);
                return p_wf_ot_m_ot;
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string strError = "Ocurrieron problemas en los procedimientos que graban y/o traspasan el Folio RAM, el mensaje del sistema es: " + Error.Message.ToString() + "Procedimiento WF_ALTA_OT";
            return "0";
        }
    }


    public void AltaFolioRam()
    {
        try
        {
            using (OracleConnection Conexion = MConexion.getConexion("ConnectionSEGA"))
            {
                mNumOT = get_p_wf_ot_m_ot(Conexion);
                Session.Add("p_wf_ot_m_ot", mNumOT);
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string strError = "Ocurrieron problemas en los procedimientos que graban y/o traspasan el Folio RAM, el mensaje del sistema es: " + Error.Message.ToString() + "Procedimiento WF_ALTA_OT";
            Session.Add("Error", strError);
        }
    }//AltaFolioRam

    public string GrabaFolioyOficinaSol()
    {
        string Folio = "";
        DataRow objDR;

        try
        {
            //Consulta estructura comercial
            ConsultaEstComercial();

            using (OracleConnection Conexion = MConexion.getConexion("ConnectionSEGA"))
            {
                string p_wf_ot_m_ot = Session["p_wf_ot_m_ot"].ToString();
                // Recuperar los datos necesarios para examen m�dico.
                string tpoExamenMedico;
                int moneda = int.Parse(Session["CodigoMoneda"].ToString());
                string rfcTitular = Session["RFCTitular"].ToString();
                double sumaAsegurada = 0;
                double edadAsegurado = 0;
                try
                {
                    sumaAsegurada = double.Parse(Session["SumaAsegurada"].ToString());
                }
                catch
                {
                    sumaAsegurada = 0;
                }

                try
                {
                    edadAsegurado = double.Parse(Session["EdadTitular"].ToString());
                }
                catch
                {
                    edadAsegurado = 0;
                }

                

                // Recuperar el tipo de examen m�dico.
                tpoExamenMedico = getTipoExamenMedico(1,
                                                        moneda,
                                                        "RFC",
                                                        rfcTitular,
                                                        sumaAsegurada,
                                                        edadAsegurado);

                objDR = grabaMSP_ALTA_FOLIO_SI24(Conexion, Divisional, Regional, p_wf_ot_m_ot, tpoExamenMedico);

                if (objDR != null)
                {
                    if (objDR["p_num_folio"].ToString() != "")
                    {
                        mFolioRAM = objDR["p_num_folio"].ToString();
                        Session.Add("FolioRAM", mFolioRAM);
                    }
                    else if (objDR["p_cod_error"].ToString() != "0")
                        throw new Exception(objDR["p_cod_error"].ToString());
                    else if (objDR["p_err_mensaje"].ToString() != "")
                        throw new Exception(objDR["p_err_mensaje"].ToString());
                }
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string strError = "Ocurrieron problemas en los procedimientos que graban y/o traspasan el Folio RAM, el mensaje del sistema es: " + Error.Message.ToString() + "Procedimiento MSP_ALTA_FOLIO_SI24";
            Session.Add("Error", strError);
        }

        return Folio;

    }//GrabaFolioyOficina

    public string GrabaFolioyOficinaPol()
    {
        string Folio = "";
        DataRow objDR;

        try
        {
            //Consulta estructura comercial
            ConsultaEstComercial();

            using (OracleConnection Conexion = MConexion.getConexion("ConnectionSEGA"))
            {
                //string p_wf_ot_m_ot = Session["p_wf_ot_m_ot"].ToString();
                // Recuperar los datos necesarios para examen m�dico.
                string tpoExamenMedico;
                int moneda = int.Parse(Session["CodigoMoneda"].ToString());
                string rfcTitular = Session["RFCTitular"].ToString();
                double sumaAsegurada = 0;
                double edadAsegurado = 0;
                try
                {
                    sumaAsegurada = double.Parse(Session["SumaAsegurada"].ToString());
                }
                catch
                {
                    sumaAsegurada = 0;
                }
                try
                {
                     edadAsegurado = double.Parse(Session["EdadTitular"].ToString());
                }
                catch
                {
                    edadAsegurado = 0;
                }

                
                

                // Recuperar el tipo de examen m�dico.
                tpoExamenMedico = getTipoExamenMedico(1,
                                                        moneda,
                                                        "RFC",
                                                        rfcTitular,
                                                        sumaAsegurada,
                                                        edadAsegurado);

                objDR = grabaMSP_ALTA_FOLIO(Conexion, tpoExamenMedico);

                if (objDR != null)
                {
                    if (objDR["p_num_folio"].ToString() != "")
                    {
                        mFolioRAM = objDR["p_num_folio"].ToString();
                        Session.Add("FolioRAM", mFolioRAM);
                    }
                    else if (objDR["p_cod_error"].ToString() != "0")
                        throw new Exception(objDR["p_cod_error"].ToString());
                    else if (objDR["p_err_mensaje"].ToString() != "")
                        throw new Exception(objDR["p_err_mensaje"].ToString());
                }
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string strError = "Ocurrieron problemas en los procedimientos que graban y/o traspasan el Folio RAM, el mensaje del sistema es: " + Error.Message.ToString() + "Procedimiento MSP_ALTA_FOLIO_SI24";
            Session.Add("Error", strError);
        }

        return Folio;

    }

    public void GrabaFolioTW(string NumSol)
    {
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                string FolioRAM = Session["FolioRAM"].ToString();
                int CodRamo = Int32.Parse(Session["COD_RAMO"].ToString());
                ActualizaP2000020(conexion, NumSol, 0, 0, 0, 0, 1, "VAL_FOLIO_SOLICITUD", FolioRAM, CodRamo, 1);
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string strError = "Ocurrieron problemas en los procedimientos que graban y/o traspasan el Folio RAM, el mensaje del sistema es: " + Error.Message.ToString() + "Procedimiento ev_k_solicitudes_web.p_actualiza_datosvar";
            Session.Add("Error", strError);
        }
    }//GrabaFolioTW				

    public string TipoSeguro(string p_num_poliza, int p_cod_benef, OracleConnection Conexion)
    {
        MCommand cmd = new MCommand();
        DataRow objDR;

        try
        {
            cmd.Connection = Conexion;
            cmd.CommandText = "ev_k_solicitudes_web.p_desc_tipseguro";

            cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
            cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, p_num_poliza);
            cmd.agregarINParametro("p_num_spto", OracleDbType.Int32, 0);
            cmd.agregarINParametro("p_num_apli", OracleDbType.Int32, 0);
            cmd.agregarINParametro("p_num_spto_apli", OracleDbType.Int32, 0);
            cmd.agregarINParametro("p_cod_benef", OracleDbType.Varchar2, p_cod_benef);
            cmd.agregarOUTParametro("p_etiqueta", OracleDbType.Varchar2, 2000);

            objDR = cmd.ejecutarRegistroSP();

            return objDR["p_etiqueta"].ToString();
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR DatosVidaClass.TipoSeguro() : " + ex.Message);
        }
    }

    public string ConsultaRegistro(int CodCia, string p_num_poliza, int p_num_spto, int p_num_apli, int p_num_spto_apli, 
        OracleConnection Conexion)
    {
        OracleCommand Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandText = "ev_k_reportes_vida.p_verif_pol";
        Comando.CommandType = CommandType.StoredProcedure;
        ConsultaRegistroA(ref Comando, 1, p_num_poliza, 0, 0, 0);
        Comando.ExecuteScalar();

        return Comando.Parameters["p_num_poliza"].Value.ToString();


        //			MCommand Comando = new MCommand();			
        //			Comando.CommandText = "ususolvi.ev_k_solicitudes_web_mmx.p_desc_tipseguro";			
        //			Comando.agregarINParametro("p_cod_cia",OracleDbType.Int32,CodCia);
        //			Comando.agregarINParametro("p_num_poliza",OracleDbType.Varchar2,p_num_poliza);
        //			Comando.agregarINParametro("p_num_spto",OracleDbType.Int32,p_num_spto);
        //			Comando.agregarINParametro("p_num_apli",OracleDbType.Int32,p_num_apli);
        //			Comando.agregarINParametro("p_num_spto_apli",OracleDbType.Int32,p_num_spto_apli);
        //			Comando.agregarINParametro("p_cod_benef",OracleDbType.Int32,p_cod_benef);
        //			Comando.agregarOUTParametro("p_etiqueta",OracleDbType.Varchar2,200);
        //			DataRow myRow = Comando.ejecutarRegistro();
        //			return myRow["p_etiqueta"].ToString();			
    }

    public void InsertaP1001398(int p_cod_cia, string p_tip_docum, string p_cod_docum, string p_cod_curp, OracleConnection Conexion)
    {
        MCommand Comando = new MCommand();
        Comando.Connection = Conexion;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p1001398";

        Comando.agregarINParametro("p_cod_cia", OracleDbType.Int32, p_cod_cia);
        Comando.agregarINParametro("p_tip_docum", OracleDbType.Varchar2, p_tip_docum);
        Comando.agregarINParametro("p_cod_docum", OracleDbType.Varchar2, p_cod_docum);
        Comando.agregarINParametro("p_cod_curp", OracleDbType.Varchar2, p_cod_curp);

        Comando.ejecutarSP();
    }

    public string ValidaUsuario(OracleConnection Conexion, string CodUsr)
    {
        MCommand Comando = new MCommand();
        DataRow rwValido;
        try
        {
            Comando.Connection = Conexion;
            Comando.CommandText = "ev_k_solicitudes_web.p_valida_usuario";
            Comando.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
            Comando.agregarINParametro("p_cod_usr", OracleDbType.Varchar2, CodUsr);
            Comando.agregarOUTParametro("p_valida_usr", OracleDbType.Varchar2, 2000);
            rwValido = Comando.ejecutarRegistroSP();
            return rwValido["p_valida_usr"].ToString();
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR DatosVidaClass.ValidaUsuario() : " + ex.Message);
        }
    }

    public bool FechaValida30Dias(string FechaUsuario)
    {
        System.DateTime FechaComparar;
        System.DateTime Fecha = System.DateTime.Now.Date;
        System.TimeSpan Incremento = new TimeSpan(30, 0, 0, 0, 0);
        System.TimeSpan Decremento = new TimeSpan(30, 0, 0, 0, 0);

        System.DateTime FechaDespues = Fecha.Add(Incremento);
        System.DateTime FechaAntes = Fecha.Subtract(Decremento);

        try
        {
            FechaComparar = Convert.ToDateTime(FechaUsuario);
        }
        catch(Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            return false;
        }

        if (FechaComparar > FechaDespues)
        {
            return false;
        }
        else
        {
            if (FechaComparar < FechaAntes)
            {
                return false;
            }
        }
        return true;
    }

    //Regresa si una fecha es mayor o menor a la fecha del Sitema
    //mayor
    //menor

    public string FechaValidaConSys(string FechaUsuario)
    {
        System.DateTime FechaComparar;
        System.DateTime Fecha = System.DateTime.Now.Date;

        try
        {
            FechaComparar = Convert.ToDateTime(FechaUsuario);
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            return Error.Message;
        }

        if (Fecha > FechaComparar)
        {
            return "menor";
        }
        else
        {
            if (Fecha < FechaComparar)
            {
                return "mayor";
            }
        }
        return "igual";
    }//public bool FechaValida30Dias

    public DataSet LlenaBancos(OracleConnection Conexion)
    {
        DataSet dsBancos = new DataSet();
        OracleCommand Comando = new OracleCommand();
        OracleParameter Param = new OracleParameter();

        Comando.Connection = Conexion;
        Comando.CommandText = "ev_k_solicitudes_web.p_datos_banco";
        Comando.CommandType = CommandType.StoredProcedure;

        Param.ParameterName = "p_cursor";
        Param.Direction = ParameterDirection.Output;
        Param.OracleDbType = OracleDbType.RefCursor;
        Comando.Parameters.Add(Param);

        OracleDataAdapter AdapterBancos = new OracleDataAdapter(Comando);
        //AdapterBancos.SelectCommand = Comando;

        AdapterBancos.Fill(dsBancos);

        return dsBancos;

    } //LlenaBancos

    public DataSet EjecutaDatosLiberacionSol(OracleConnection Conexion, string Tipo_Sol, string Oficina, string Fecha_Ini, 
        string Fecha_Fin, string Mes, string Mes2)
    {
        DataSet ds3 = new DataSet();
        OracleCommand Comando = new OracleCommand();
        OracleParameter Param = new OracleParameter();

        Comando.Connection = Conexion;
        Comando.CommandText = "ev_k_genera_listastw.p_genera_listadouno";
        Comando.CommandType = CommandType.StoredProcedure;

        Param = new OracleParameter();
        Param.ParameterName = "p_fecha_de";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = Fecha_Ini;
        Comando.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_fecha_a";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = Fecha_Fin;
        Comando.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_listadouno";
        Param.Direction = ParameterDirection.Output;
        Param.OracleDbType = OracleDbType.RefCursor;
        Comando.Parameters.Add(Param);

        OracleDataAdapter AdapterBancos = new OracleDataAdapter(Comando);
        //AdapterBancos.SelectCommand = Comando;

        AdapterBancos.Fill(ds3);

        return ds3;

    } //EjecutaDatosLiberacionSol

    public DataSet EjecutaDatosLiberacionSol2(OracleConnection Conexion, string Tipo_Sol, string Oficina, string Fecha_Ini,
        string Fecha_Fin, string Mes, string Mes2)
    {
        DataSet ds3 = new DataSet();
        OracleCommand Comando = new OracleCommand();
        OracleParameter Param = new OracleParameter();

        Comando.Connection = Conexion;
        Comando.CommandText = "ev_k_genera_listastw.p_genera_listadocua";
        Comando.CommandType = CommandType.StoredProcedure;

        Param = new OracleParameter();
        Param.ParameterName = "p_fecha_de";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = Fecha_Ini;
        Comando.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_fecha_a";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = Fecha_Fin;
        Comando.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_listadouno";
        Param.Direction = ParameterDirection.Output;
        Param.OracleDbType = OracleDbType.RefCursor;
        Comando.Parameters.Add(Param);

        OracleDataAdapter AdapterBancos = new OracleDataAdapter(Comando);
        //AdapterBancos.SelectCommand = Comando;

        AdapterBancos.Fill(ds3);

        return ds3;

    } //EjecutaDatosLiberacionSol2

    public DataSet EjecutaDatosLiberacionSol3(OracleConnection Conexion, string Tipo_Sol, string Oficina, 
        string Fecha_Ini, string Fecha_Fin, string Mes, string Mes2)
    {
        DataSet ds3 = new DataSet();
        OracleCommand Comando = new OracleCommand();
        OracleParameter Param = new OracleParameter();

        Comando.Connection = Conexion;
        Comando.CommandText = "ev_k_genera_listastw.p_genera_listadodos";
        Comando.CommandType = CommandType.StoredProcedure;

        Param = new OracleParameter();
        Param.ParameterName = "p_fecha_de";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = Mes;
        Comando.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_fecha_a";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = Mes2;
        Comando.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_oficina";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Decimal;
        Param.Value = Oficina;
        Comando.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_listadouno";
        Param.Direction = ParameterDirection.Output;
        Param.OracleDbType = OracleDbType.RefCursor;
        Comando.Parameters.Add(Param);

        OracleDataAdapter AdapterBancos = new OracleDataAdapter(Comando);
        //AdapterBancos.SelectCommand = Comando;

        AdapterBancos.Fill(ds3);

        return ds3;

    } //EjecutaDatosLiberacionSol3

    public DataSet EjecutaDatosLiberacionSol4(OracleConnection Conexion, string Tipo_Sol, string Oficina, 
        string Fecha_Ini, string Fecha_Fin, string Mes, string Mes2)
    {
        DataSet ds3 = new DataSet();
        OracleCommand Comando = new OracleCommand();
        OracleParameter Param = new OracleParameter();

        Comando.Connection = Conexion;
        Comando.CommandText = "ev_k_genera_listastw.p_genera_listadotres";
        Comando.CommandType = CommandType.StoredProcedure;

        Param = new OracleParameter();
        Param.ParameterName = "p_fecha_de";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = Mes;
        Comando.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_fecha_a";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = Mes2;
        Comando.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_oficina";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Decimal;
        Param.Value = Oficina;
        Comando.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_listadouno";
        Param.Direction = ParameterDirection.Output;
        Param.OracleDbType = OracleDbType.RefCursor;
        Comando.Parameters.Add(Param);

        OracleDataAdapter AdapterBancos = new OracleDataAdapter(Comando);
        //AdapterBancos.SelectCommand = Comando;

        AdapterBancos.Fill(ds3);

        return ds3;

    } //EjecutaDatosLiberacionSol4

    /// <summary>
    /// Procedimiento para validar la edad m�xima y m�nima con respecto 
    /// a la cobertura b�sica, para determinar si puede contratar el plan
    /// � NO
    /// </summary>
    /// <param name="iCia"></param>
    /// C�digo de la compa��a
    /// <param name="sNumSol"></param>
    /// N�mero de Solicitud
    /// <param name="inum_spto"></param>
    /// N�mero de Suplemento
    /// <param name="inum_apli"></param>
    /// N�mero de Aplicaci�n
    /// <param name="inum_spto_apli"></param>
    /// <returns></returns>

    public string ValidaEdadPlan(OracleConnection Conexion, int CodCia, int CodRamo, int CodModalidad, int CodCob, 
        string FechaValidez, int Edad, int duracion, int moneda, int comision, int crecimiento, int deducible, int tip_prima, int contrato)
    {

        MCommand Comando = new MCommand();
        DataRow auxRow;
        string Resultado;
        Comando.Connection = Conexion;
        Comando.CommandText = "ev_k_solicitudes_web.p_valida_edad_plan";
        Comando.agregarINParametro("p_cod_cia", OracleDbType.Int32, CodCia);

        Comando.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodRamo);
        Comando.agregarINParametro("p_cod_modalidad", OracleDbType.Int32, CodModalidad);
        Comando.agregarINParametro("p_cod_cob", OracleDbType.Int32, CodCob);
        Comando.agregarINParametro("p_fec_validez", OracleDbType.Varchar2, FechaValidez);
        Comando.agregarINParametro("p_edad", OracleDbType.Int32, Edad);
        Comando.agregarINParametro("p_duracion", OracleDbType.Int32, duracion);
        Comando.agregarINParametro("p_cod_mon", OracleDbType.Int32, moneda);
        Comando.agregarINParametro("p_tip_comision", OracleDbType.Int32, comision);
        Comando.agregarINParametro("p_tip_regulariza_suma", OracleDbType.Int32, crecimiento);
        Comando.agregarINParametro("p_tip_deducible", OracleDbType.Int32, deducible);
        Comando.agregarINParametro("p_tip_prima", OracleDbType.Int32, tip_prima);
        Comando.agregarINParametro("p_num_contrato", OracleDbType.Int32, contrato);
        Comando.agregarOUTParametro("p_valida_edad", OracleDbType.Varchar2, 200);

        auxRow = Comando.ejecutarRegistroSP();
        Resultado = auxRow["p_valida_edad"].ToString();
        return Resultado;
    }

    public void EliminaRFCP1001331(OracleConnection Conexion, string RFC)
    {
        MCommand cmd = new MCommand();
        cmd.Connection = Conexion;
        cmd.CommandText = "ev_k_solicitudes_web.p_borra_cod_docum_31";

        cmd.agregarINParametro("p_cod_docum", OracleDbType.Varchar2, RFC);
        cmd.agregarOUTParametro("p_result", OracleDbType.Varchar2, 250);

        DataRow objDR = cmd.ejecutarRegistroSP();
    }

    public void EliminaRFCP2000060(OracleConnection Conexion, string RFC, string NumSolicitud)
    {
        MCommand cmd = new MCommand();
        cmd.Connection = Conexion;
        cmd.CommandText = "ev_k_solicitudes_web.p_borra_cod_docum_60";

        cmd.agregarINParametro("p_cod_docum", OracleDbType.Varchar2, RFC);
        cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, NumSolicitud);
        cmd.agregarOUTParametro("p_result", OracleDbType.Varchar2, 250);

        DataRow objDR = cmd.ejecutarRegistroSP();
    }

    /// <summary>
    /// Procedimiento que permite la inserci�n de los beneficiarios
    /// en las tablas P1001331 y A1001331, para con ello poder observar
    /// los datos en Tron Web
    /// </summary>
    /// <param name="Conexion"></param>
    /// <param name="CadenaInsercion"></param>
    /// <returns></returns>
    private string p_graba_terceros(OracleConnection Conexion, string CadenaInsercion)
    {
        DataRow Row = null;
        MCommand Comando = new MCommand();
        Comando.Connection = Conexion;
        Comando.CommandText = "tron2000.em_k_gen_ws_mmx.p_graba_terceros";
        Comando.agregarINParametro("p_cadena", OracleDbType.Varchar2, CadenaInsercion);
        Comando.agregarOUTParametro("p_estado", OracleDbType.Varchar2, 2000);

        try
        {
            Row = Comando.ejecutarRegistroSP();
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string strError = "Ocurrieron problemas en los procedimientos que graban p_graba_terceros, el mensaje del sistema es: " + Error.Message.ToString();
            Session.Add("Error", strError);
        }
        return Row["p_estado"].ToString();
    }

    public void InsertaP2000060(Hashtable DatosTercero)
    {
        try
        {
            string poliza = DatosTercero["NUM_POLIZA"].ToString();
            string tip_benef = DatosTercero["TIP_BENEF"].ToString();
            string secu = DatosTercero["NUM_SECU"].ToString();
            string tip_docum = DatosTercero["TIP_DOCUM"].ToString();
            string cod_docum = DatosTercero["COD_DOCUM"].ToString();
            string pct = DatosTercero["PCT_PARTICIPACION"].ToString();

            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                MCommand cmd = new MCommand();
                cmd.Connection = conexion;
                cmd.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2000060";

                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, poliza);
                cmd.agregarINParametro("p_num_spto", OracleDbType.Int32, 0);
                cmd.agregarINParametro("p_num_apli", OracleDbType.Int32, 0);
                cmd.agregarINParametro("p_num_spto_apli", OracleDbType.Int32, 0);
                cmd.agregarINParametro("p_num_riesgo", OracleDbType.Int32, 1);
                //El tip benef = 10 es de Servicios Funerarios
                cmd.agregarINParametro("p_tip_benef", OracleDbType.Varchar2, tip_benef);
                cmd.agregarINParametro("p_num_secu", OracleDbType.Int32, secu);
                cmd.agregarINParametro("p_tip_docum", OracleDbType.Varchar2, tip_docum);
                cmd.agregarINParametro("p_cod_docum", OracleDbType.Varchar2, cod_docum);
                cmd.agregarINParametro("p_mca_principal", OracleDbType.Varchar2, "N");
                cmd.agregarINParametro("p_mca_calculo", OracleDbType.Varchar2, "N");
                cmd.agregarINParametro("p_mca_baja", OracleDbType.Varchar2, "N");
                cmd.agregarINParametro("p_mca_vigente", OracleDbType.Varchar2, "S");
                cmd.agregarINParametro("p_pct_participacion", OracleDbType.Decimal, pct != "" ? (object)pct : DBNull.Value);
                cmd.agregarINParametro("p_fec_vcto_cesion", OracleDbType.Varchar2, DBNull.Value);
                cmd.agregarINParametro("p_imp_cesion", OracleDbType.Decimal, DBNull.Value);

                cmd.ejecutarSP();
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR DatosVidaClass.InsertaP2000060() : " + ex.Message);
        }
    }

    public string InsertaP1001331Adicionales(OracleConnection Connection, Hashtable hashBenef)
    {
        Hashtable Tabla = new Hashtable();
        string Fec_Tratamiento = System.DateTime.Now.ToShortDateString();
        string Tip_Mvto_Batch = "3";
        string Cod_Cia = "1";
        string tip_docum = hashBenef["TIP_DOCUM"].ToString();
        string cod_docum = hashBenef["COD_DOCUM"].ToString();
        string cod_act_tercero = "1";
        string cod_idioma = "ES";
        string cod_ramo = hashBenef["COD_RAMO"].ToString();
        string Mca_Fisico = hashBenef["MCA_FISICO"].ToString();
        string Cod_Ocupacion = hashBenef["COD_PARENTESCO"].ToString(); //C�digo del Parentesco
        string Nom_Tercero = hashBenef["NOM_TERCERO"].ToString();
        string Ape1_Tercero = hashBenef["APE1_TERCERO"].ToString();
        string ape2_tercero = hashBenef["APE2_TERCERO"].ToString();
        string FEC_NACIMIENTO = hashBenef["FEC_NACIMIENTO"].ToString();

        string TXT_AUX1 = "NR";
        string TIP_ETIQUETA = "1";
        string COD_NACIONALIDAD = "MEX";
        string COD_PAIS = "MEX";
        string COD_PAIS_COM = "MEX";
        string COD_PAIS_ETIQUETA = "MEX";
        string COD_USR = Session["Usuario"].ToString();//"AGENTETW"; Se sustituy� por el usuario de la pantalla de logeo 27 Dic 2005
        string FEC_ACTU = System.DateTime.Now.ToShortDateString();
        /*string OBS_ASEGURADO     = hashBenef["COD_DOCUM_BN"].ToString(); <---- Se coment� porque con la nueva tabla P2300031_MMX Ya no se necesita
                                                      Grabar en el campo NOM_LOCALIDAD */

        Tabla.Add("Fec_Tratamiento", Fec_Tratamiento);

        Tabla.Add("Tip_Mvto_Batch", Tip_Mvto_Batch);

        Tabla.Add("Cod_Cia", Cod_Cia);
        Tabla.Add("tip_docum", tip_docum);
        Tabla.Add("cod_docum", cod_docum);
        Tabla.Add("cod_act_tercero", cod_act_tercero);
        Tabla.Add("cod_idioma", cod_idioma);
        Tabla.Add("Mca_Fisico", Mca_Fisico);
        Tabla.Add("Cod_Ocupacion", Cod_Ocupacion);
        Tabla.Add("Nom_Tercero", Nom_Tercero);
        Tabla.Add("Ape1_Tercero", Ape1_Tercero);
        Tabla.Add("ape2_tercero", ape2_tercero);
        Tabla.Add("TXT_AUX1", TXT_AUX1);
        Tabla.Add("TIP_ETIQUETA", TIP_ETIQUETA);
        Tabla.Add("COD_NACIONALIDAD", COD_NACIONALIDAD);
        Tabla.Add("COD_PAIS", COD_PAIS);
        Tabla.Add("COD_PAIS_COM", COD_PAIS_COM);
        Tabla.Add("COD_PAIS_ETIQUETA", COD_PAIS_ETIQUETA);
        Tabla.Add("COD_USR", COD_USR);
        Tabla.Add("FEC_ACTU", FEC_ACTU);
        Tabla.Add("FEC_NACIMIENTO", FEC_NACIMIENTO);
        /*Tabla.Add("NOM_LOCALIDAD",OBS_ASEGURADO); <---- Se coment� porque con la nueva tabla P2300031_MMX Ya no se necesita
                                                          Grabar en el campo NOM_LOCALIDAD */

        string CadenaP1001331 = CadenaXMLTerceros(Tabla, cod_ramo);
        string Resultado = p_graba_terceros(Connection, CadenaP1001331);

        return Resultado;
    }//private string InsertaP1001331Adicionales()

    private string CadenaXMLTerceros(Hashtable HsTblDatos, string cod_ramo)
    {
        string Clave;
        string Valor;
        StringBuilder Cadena = new StringBuilder();

        Cadena.Append("<XML COD_RAMO=\"" + cod_ramo + "\">");
        Cadena.Append(@"<TABLE NAME=""P1001331"">");
        Cadena.Append("<ROWSET>");
        Cadena.Append(@"<ROW num=""1"">");

        foreach (DictionaryEntry myDic in HsTblDatos)
        {
            Clave = myDic.Key.ToString();
            Valor = myDic.Value.ToString();
            Cadena.Append("<" + Clave.ToUpper() + ">");
            Cadena.Append(Valor.ToUpper());
            Cadena.Append("</" + Clave.ToUpper() + ">");
        }

        Cadena.Append("</ROW>");
        Cadena.Append("</ROWSET>");
        Cadena.Append("</TABLE>");
        Cadena.Append("</XML>");

        return Cadena.ToString();
    }

    public DataSet fnObtieneCoberturas(string CodCia, string CodRamo, string Modalidad, string Edad)                   
    {
        OracleCommand cmd = new OracleCommand();
        DataSet DS = new DataSet();
        DataTable DT = new DataTable();
        string[] Coberturas, valores;
        try
        {
            DT.Columns.Add("DES_COB");
            DT.Columns.Add("COD_COB");
            DT.Columns.Add("COD_AGRUP2");
            DT.Columns.Add("MCA_OBLIGA");
            DT.Columns.Add("COD_REAS");
            DT.Columns.Add("DESCTO_SEXO");
            DT.Columns.Add("DESCTO_FUMA");
            DT.Columns.Add("DESCTO_AGTE");

            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.CommandText = "EV_K_SOLICITUDES_WEB.P_OBTIENE_DATOSCOB";
                cmd.CommandType = CommandType.StoredProcedure;
                ParamObtieneCoberturas(ref cmd, CodCia, CodRamo, Modalidad, Edad);
                cmd.Connection = conexion;
                cmd.ExecuteNonQuery();

                string Coberturas1 = cmd.Parameters["P_DATOSCOB"].Value.ToString();
                Coberturas = Coberturas1.Split(new char[] { '|' });
                for (int i = 0; i <= Coberturas.Length - 2; i++)
                {
                    string valores1 = Coberturas[i].ToString();
                    valores = valores1.Split(new char[] { ':' });
                    if (!(valores[0] == ""))
                    {
                        DT.Rows.Add(new object[] { valores[0], valores[1], valores[2], valores[3], valores[4], valores[5], valores[6], valores[7] });
                    }
                }
                DS.Tables.Add(DT);
            }
        }
        catch(Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
        }
        return DS;
    }

    private void ParamObtieneCoberturas(ref OracleCommand cmdTemp, string CodCia, string CodRamo, string Modalidad, string Edad)
    {
        OracleParameter Param = new OracleParameter();
        Param.ParameterName = "P_COD_CIA";
        Param.OracleDbType = OracleDbType.Int32;
        Param.Direction = ParameterDirection.Input;
        Param.Value = Convert.ToInt32(CodCia);
        cmdTemp.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "P_COD_RAMO";
        Param.OracleDbType = OracleDbType.Int32;
        Param.Direction = ParameterDirection.Input;
        Param.Value = Convert.ToInt32(CodRamo);
        cmdTemp.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "P_COD_MODALIDAD";
        Param.OracleDbType = OracleDbType.Int32;
        Param.Direction = ParameterDirection.Input;
        Param.Value = Convert.ToInt32(Modalidad);
        cmdTemp.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "P_EDAD";
        Param.OracleDbType = OracleDbType.Int32;
        Param.Direction = ParameterDirection.Input;
        Param.Value = Convert.ToInt32(Edad);
        cmdTemp.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "P_DATOSCOB";
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Direction = ParameterDirection.Output;
        Param.Size = 2000;
        cmdTemp.Parameters.Add(Param);
    }

    public string InsertaP2300061_MMX(Hashtable hashBenef)
    {
        // int codCia, string numPol, int numRiesgo, string codBenef, int numSecu, int tipBenef, string codDocum, string txtAdicional)
        MCommand Comando = new MCommand();
        DataRow auxRow;
        string Resultado = "";

        try
        {
            string numPol = hashBenef["NUM_POLIZA"].ToString();
            string codBenef = hashBenef["COD_DOCUM_BN"].ToString();
            string tipDocum = hashBenef["TIP_DOCUM"].ToString();
            string codDocum = hashBenef["COD_DOCUM"].ToString();
            string txtAdicional = hashBenef["TXT_ADICIONAL"].ToString();
            int numSecu = Convert.ToInt32(hashBenef["NUM_SECU"]);
            int tipBenef = Convert.ToInt32(hashBenef["TIP_BENEF"]);

            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                Comando.Connection = conexion;
                Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300061";

                Comando.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                Comando.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, numPol);
                Comando.agregarINParametro("p_num_spto", OracleDbType.Int32, 0);
                Comando.agregarINParametro("p_num_apli", OracleDbType.Int32, 0);
                Comando.agregarINParametro("p_num_spto_apli", OracleDbType.Int32, 0);
                Comando.agregarINParametro("p_num_riesgo", OracleDbType.Int32, 1);
                Comando.agregarINParametro("p_cod_benef", OracleDbType.Varchar2, codBenef);
                Comando.agregarINParametro("p_num_secu", OracleDbType.Int32, numSecu);
                Comando.agregarINParametro("p_tip_benef", OracleDbType.Varchar2, tipBenef);
                Comando.agregarINParametro("p_tip_docum", OracleDbType.Varchar2, tipDocum);
                Comando.agregarINParametro("p_cod_docum", OracleDbType.Varchar2, codDocum);
                Comando.agregarINParametro("p_txt_adicional", OracleDbType.Varchar2, txtAdicional);
                Comando.agregarOUTParametro("p_result", OracleDbType.Varchar2, 75);

                auxRow = Comando.ejecutarRegistroSP();
                Resultado = auxRow["p_result"].ToString();
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
        return Resultado;
    }

    public DataTable GetContrato(int COD_CIA, string COD_RAMO, OracleConnection conexion)
    {
        CDListaValor objListaValor = new CDListaValor();
        Hashtable objDatos = new Hashtable();
        string strNOM_TABLA = "A2000010";
        int iVERSION = 5;
        try
        {
            objDatos.Add("cod_cia", "'" + COD_CIA + "'");
            objDatos.Add("cod_ramo", "'" + COD_RAMO + "'");
            return objListaValor.getListaValores(null, strNOM_TABLA, iVERSION, objDatos, conexion);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR CDListaValor.getCUADRO_COMISIONES() : " + ex.Message);
        }
    }

    public string ValidaContrato(string COD_CIA, string COD_RAMO, string COD_MODALIDAD, string NUM_CONTRATO, 
        string TIP_REGULARIZA_SUMA, string COD_MON, string TIP_DEDUCIBLE, string TIP_COMISION, string DURACION_HASTA)
    {
        MCommand Comando = new MCommand();
        DataRow auxRow;
        string Resultado = "";
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                Comando.Connection = conexion;
                Comando.CommandText = "ev_k_solicitudes_web.p_valida_contrato_modalidad";

                Comando.agregarINParametro("p_cod_cia", OracleDbType.Int32, COD_CIA);
                Comando.agregarINParametro("p_cod_ramo", OracleDbType.Int32, COD_RAMO);
                Comando.agregarINParametro("p_cod_modalidad", OracleDbType.Int32, COD_MODALIDAD);
                Comando.agregarINParametro("p_num_contrato", OracleDbType.Int32, NUM_CONTRATO);
                Comando.agregarINParametro("p_tip_suma", OracleDbType.Varchar2, TIP_REGULARIZA_SUMA);
                Comando.agregarINParametro("p_cod_mon", OracleDbType.Int32, COD_MON);
                Comando.agregarINParametro("p_tip_deducible", OracleDbType.Int32, TIP_DEDUCIBLE);
                Comando.agregarINParametro("p_tip_comision", OracleDbType.Int32, TIP_COMISION);
                Comando.agregarINParametro("p_duraci�n_hasta", OracleDbType.Int32, DURACION_HASTA);
                Comando.agregarOUTParametro("p_resultado", OracleDbType.Varchar2, 75);

                //ParamContrato(ref Comando, COD_CIA, COD_RAMO, COD_MODALIDAD, NUM_CONTRATO, TIP_REGULARIZA_SUMA, COD_MON, TIP_DEDUCIBLE, TIP_COMISION, DURACION_HASTA);
                auxRow = Comando.ejecutarRegistroSP();
                Resultado = auxRow["p_resultado"].ToString();
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            string Retorno = ex.Message;
        }
        return Resultado;
    }

    public DataTable getESTCIVIL(OracleConnection conexion)
    {
        Hashtable objDatos = new Hashtable();
        CDListaValor ObjLstValor = new CDListaValor();
        string strNOM_TABLA = "G1010031";
        int iVERSION = 1;
        try
        {
            objDatos.Add("cod_idioma", "'ES'");
            objDatos.Add("cod_campo", "'COD_EST_CIVIL'");
            return ObjLstValor.getListaValores(null, strNOM_TABLA,
                iVERSION, objDatos,
                conexion);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR CDListaValor.getESTCIVIL() : " + ex.Message);
        }
    }//public DataTable getGESTOR(OracleConnection conexion)

    public string get_p_wf_ot_m_ot(OracleConnection Conexion)
    {
        MCommand cmd = new MCommand();
        DataRow objDR;
        string strDato = "";

        try
        {

            cmd.Connection = Conexion;
            cmd.CommandText = "USRWORKF.WF_ALTA_OT";

            cmd.agregarINParametro("p_cod_secc", OracleDbType.Int32, 1);
            cmd.agregarINParametro("p_wf_sis_c_fluj", OracleDbType.Int32, 3);
            cmd.agregarINParametro("p_wf_sis_c_prod", OracleDbType.Int32, 25);
            cmd.agregarINParametro("p_wf_sis_c_esta", OracleDbType.Int32, 102);
            cmd.agregarINParametro("p_ntseg_c_acceso", OracleDbType.Int32, Convert.ToInt32(Session["UsuarioRAM"]));
            cmd.agregarINParametro("p_wf_sis_c_estt", OracleDbType.Int32, 0);
            cmd.agregarINParametro("p_observaciones", OracleDbType.Varchar2, DBNull.Value);
            cmd.agregarINParametro("p_planti_plan_int", OracleDbType.Int32, 0);
            cmd.agregarINParametro("p_wf_sis_c_docu", OracleDbType.Int32, 60);
            cmd.agregarOUTParametro("p_wf_ot_m_ot", OracleDbType.Int32, 200);

            objDR = cmd.ejecutarRegistroSP();

            strDato = objDR["p_wf_ot_m_ot"].ToString();

        }//try
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string strError = "Ocurrieron problemas en los procedimientos que graban y/o traspasan el Folio RAM, el mensaje del sistema es: " + Error.Message.ToString() + "Procedimiento WF_ALTA_OT";
            Session.Add("Error", strError);
        }//catch

        return strDato;

    }//get_p_wf_ot_m_ot

    public DataRow getFolioyOficina(OracleConnection Conexion, string codAgt)
    {
        MCommand Comando = new MCommand();
        DataRow objDR;
        try
        {
            Comando.Connection = Conexion;
            Comando.CommandText = "EV_K_SOLICITUDES_WEB.P_RECUPERA_DIVISIONAL_AGENTE";

            Comando.agregarINParametro("P_COD_CIA", OracleDbType.Int16, 1);
            Comando.agregarINParametro("P_COD_AGT", OracleDbType.Int32, codAgt);
            Comando.agregarOUTParametro("P_COD_NIVEL1", OracleDbType.Varchar2, 20);
            Comando.agregarOUTParametro("P_COD_NIVEL2", OracleDbType.Varchar2, 20);
            objDR = Comando.ejecutarRegistroSP();
            return objDR;

        }//try
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string e = Error.Message.ToString();
        }//catch
        return null;
    }//getFolioyOficina

    private void ParamFolioyOficina(ref OracleCommand cmd, System.Int16 CodCia, string codAgt)
    {

    }
 
    /// <summary>
    /// Procedimiento que guarda los datos b�sicos para un Folio RAM, se usar� en caso de que se genere una p�liza
    /// </summary>
    /// <param name="Conexion"></param>
    /// <param name="codRamo"></param>
    /// <param name="divisional"></param>
    /// <param name="regional"></param>
    /// <param name="p_wf_ot_m_ot"></param>
    /// <param name="nomAsegurado"></param>
    /// <param name="rfc"></param>
    /// <param name="codUsuario"></param>
    /// <param name="codAgente"></param>
    /// <param name="codDivisional"></param>
    /// <param name="codRegional"></param>
    /// <returns></returns>
    public DataRow grabaMSP_ALTA_FOLIO_VIDA(string codRamo, string nomAsegurado, string rfc,string num_poliza)
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataRow objDR = null;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionSEGA"))
            {
                cmd.Connection = conexion;


                cmd.CommandText = "USRWORKF.MSP_ALTA_POL_VIDA_EG";

                cmd.agregarINParametro("p_wf_ot_m_ot", OracleDbType.Double, mNumOT);
                cmd.agregarINParametro("p_tseguro_vida_int", OracleDbType.Double, 1);
                cmd.agregarINParametro("p_pool_vida_str", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_fec_ini_vig", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_fec_fin_vig", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_cod_texto", OracleDbType.Double, codRamo);
                cmd.agregarINParametro("p_fpago_vida_int", OracleDbType.Double, null);
                cmd.agregarINParametro("p_ofpago_vida_str", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_dividendo_vida_int", OracleDbType.Double, null);
                cmd.agregarINParametro("p_comision_vida_int", OracleDbType.Double, null);
                cmd.agregarINParametro("p_formula_vida_int", OracleDbType.Double, null);
                cmd.agregarINParametro("p_oformula_vida_str", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_regla_vida_int", OracleDbType.Double, null);
                cmd.agregarINParametro("p_oregla_vida_str", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_accidente_vida_int", OracleDbType.Double, null);
                cmd.agregarINParametro("p_invalidez_vida_int", OracleDbType.Double, null);
                cmd.agregarINParametro("p_colectividad_vida_str", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_nombre_aseg_str", OracleDbType.Varchar2, nomAsegurado);
                cmd.agregarINParametro("p_giro_aseg_str", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_rfc_aseg_str", OracleDbType.Varchar2, rfc);
                cmd.agregarINParametro("p_calle_aseg", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_colonia_aseg", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_cod_postal", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_cod_edo", OracleDbType.Double, null);
                cmd.agregarINParametro("p_cod_pob", OracleDbType.Double, null);
                cmd.agregarINParametro("p_cod_agente", OracleDbType.Double, mCodAgt);
                cmd.agregarINParametro("p_div_destino", OracleDbType.Double, Divisional);
                cmd.agregarINParametro("p_reg_destino", OracleDbType.Double, Regional);
                cmd.agregarINParametro("p_ntseg_c_acceso", OracleDbType.Double, mCodUsuarioSeGARAM);
                cmd.agregarINParametro("p_wf_sis_c_esta", OracleDbType.Double, 103);
                cmd.agregarINParametro("p_wf_sis_c_estt", OracleDbType.Double, 101);
                cmd.agregarINParametro("p_planti_plan_int", OracleDbType.Double, 1);
                cmd.agregarINParametro("p_observaciones", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, num_poliza);

                cmd.agregarOUTParametro("p_cod_error", OracleDbType.Double, 20);
                cmd.agregarOUTParametro("p_err_mensaje", OracleDbType.Varchar2, 255);

                objDR = cmd.ejecutarRegistroSP();
            }

        }//try
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string strError = "Ocurrieron problemas en los procedimientos que graban y/o traspasan el Folio RAM, el mensaje del sistema es: " + Error.Message.ToString() + "Procedimiento MSP_ALTA_FOLIO_SI24";
            Session.Add("Error", strError);
        }//catch

        return objDR;

    }//grabaMSP_ALTA_FOLIO_VIDA

    public DataRow grabaMSP_ALTA_FOLIO_SI24(OracleConnection Conexion, string divisional, string regional, string p_wf_ot_m_ot,
        string tipo_examen_medico)
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataRow objDR = null;

        try
        {
            double p_req_examen = (tipo_examen_medico.ToUpper() == "NA" ? 0 : 1);
            string p_tipo_examen = (tipo_examen_medico.ToUpper() == "NA" ? "" : tipo_examen_medico.ToUpper());

            cmd.Connection = Conexion;
            cmd.CommandText = "USRWORKF.MSP_ALTA_FOLIO_SI24";

            cmd.agregarINParametro("p_wf_ot_m_ot", OracleDbType.Double, p_wf_ot_m_ot);
            cmd.agregarINParametro("p_cod_secc", OracleDbType.Double, 1);
            cmd.agregarINParametro("p_tipo_mov", OracleDbType.Double, 1);
            cmd.agregarINParametro("p_divisional", OracleDbType.Double, divisional);
            cmd.agregarINParametro("p_regional", OracleDbType.Double, regional);
            cmd.agregarINParametro("p_req_examen", OracleDbType.Double, p_req_examen);
            //cmd.agregarINParametro("p_req_examen", OracleDbType.Double, 0);
            cmd.agregarINParametro("p_tipo_examen", OracleDbType.Varchar2, p_tipo_examen);
            cmd.agregarINParametro("p_cod_usr", OracleDbType.Double, Convert.ToInt32(Session["UsuarioRAM"]));
            cmd.agregarOUTParametro("p_num_folio", OracleDbType.Varchar2, 15);
            cmd.agregarOUTParametro("p_cod_error", OracleDbType.Double, 20);
            cmd.agregarOUTParametro("p_err_mensaje", OracleDbType.Varchar2, 255);

            objDR = cmd.ejecutarRegistroSP();

        }//try
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string strError = "Ocurrieron problemas en los procedimientos que graban y/o traspasan el Folio RAM, el mensaje del sistema es: " + Error.Message.ToString() + "Procedimiento MSP_ALTA_FOLIO_SI24";
            Session.Add("Error", strError);
        }//catch

        return objDR;

    }//grabaMSP_ALTA_FOLIO_SI24

    /// <summary>
    /// Procedimiento para dar de alta el Folio RAM, s�lo en caso de generar una p�liza.
    /// </summary>
    /// <param name="Conexion"></param>
    /// <param name="divisional"></param>
    /// <param name="regional"></param>
    /// <param name="p_wf_ot_m_ot"></param>
    /// <param name="tipo_examen_medico"></param>
    /// <returns></returns>
    public DataRow grabaMSP_ALTA_FOLIO(OracleConnection Conexion, string tipo_examen_medico)
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataRow objDR = null;

        try
        {

            cmd.Connection = Conexion;
            cmd.CommandText = "USRWORKF.MSP_ALTA_FOLIO";

            cmd.agregarINParametro("p_wf_ot_m_ot", OracleDbType.Double, mNumOT);
            cmd.agregarINParametro("p_cod_secc", OracleDbType.Double, 1);
            cmd.agregarINParametro("p_tipo_mov", OracleDbType.Double, 1);
            cmd.agregarINParametro("p_divisional", OracleDbType.Double, mDivisional);
            cmd.agregarINParametro("p_regional", OracleDbType.Double, mRegional);

            cmd.agregarOUTParametro("p_num_folio", OracleDbType.Varchar2, 15);
            cmd.agregarOUTParametro("p_cod_error", OracleDbType.Double, 20);
            cmd.agregarOUTParametro("p_err_mensaje", OracleDbType.Varchar2, 255);

            objDR = cmd.ejecutarRegistroSP();

        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string strError = "Ocurrieron problemas en los procedimientos que graban y/o traspasan el Folio RAM, el mensaje del sistema es: " + Error.Message.ToString() + "Procedimiento MSP_ALTA_FOLIO_SI24";
            Session.Add("Error", strError);
        }

        return objDR;

    }

    public void MSP_TRASPASO_FOLVIDA()
    {
        MCommand Comando = new MCommand();
        try
        {
            string p_wf_ot_m_ot = Session["p_wf_ot_m_ot"].ToString(); ;
            string FolioRAM = Session["FolioRAM"].ToString();

            using (OracleConnection Conexion = MConexion.getConexion("ConnectionSEGA"))
            {
                Comando.Connection = Conexion;
                Comando.CommandText = "USRWORKF.MSP_TRASPASO_FOLVIDA";

                Comando.agregarINParametro("p_IDOT", OracleDbType.Decimal, p_wf_ot_m_ot);
                Comando.agregarINParametro("p_FOLIO", OracleDbType.Varchar2, FolioRAM);

                Comando.ejecutarSP();
            }
        }
        catch (Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string strError = "Ocurrieron problemas en los procedimientos que graban y/o traspasan el Folio RAM, el mensaje del sistema es: " + Error.Message.ToString() + " Procedimiento MSP_TRASPASO_FOLVIDA";
            Session.Add("Error", strError);
        }
    }

    public OracleCommand getNombreContrato(OracleConnection Conexion, string contrato)
    {
        OracleCommand Comando = new OracleCommand();

        try
        {
            Comando.Connection = Conexion;
            Comando.CommandText = "ev_k_solicitudes_web.p_recupera_nombre_contrato";
            Comando.CommandType = CommandType.StoredProcedure;

            ParamNombreContrato(ref Comando, contrato);

            Comando.ExecuteNonQuery();
        }//try
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string e = Error.Message.ToString();
        }//catch
        return Comando;
    }//getNombreContrato

    private void ParamNombreContrato(ref OracleCommand cmd, string contrato)
    {
        OracleParameter Param = new OracleParameter();
        Param.ParameterName = "p_cod_cia";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Int32;
        Param.Value = 1;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_num_contrato";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Int32;
        Param.Value = contrato;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_nom_contrato";
        Param.Direction = ParameterDirection.Output;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Size = 2000;
        cmd.Parameters.Add(Param);
    }

    public OracleCommand GrabaA1000802(OracleConnection Conexion, string COD_DOCUM, string NOM_DOMICILIO1, string NOM_DOMICILIO2, 
        string NOM_DOMICILIO3, string COD_POSTAL, string COD_ESTADO, string TXT_ETIQUETA4, string COD_LOCALIDAD, string TXT_ETIQUETA5, string TLF_NUMERO, string TXT_EMAIL, string NUM_POLIZA, string NUM_RIESGO)
    {
        OracleCommand Comando = new OracleCommand();

        try
        {
            Comando.Connection = Conexion;
            Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_a1000802";
            Comando.CommandType = CommandType.StoredProcedure;

            ParamGrabaA1000802(ref Comando, COD_DOCUM, NOM_DOMICILIO1, NOM_DOMICILIO2, NOM_DOMICILIO3, COD_POSTAL, COD_ESTADO, 
                TXT_ETIQUETA4, COD_LOCALIDAD, TXT_ETIQUETA5, TLF_NUMERO, TXT_EMAIL, NUM_POLIZA, NUM_RIESGO);

            Comando.ExecuteNonQuery();
        }//try
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string e = Error.Message.ToString();
        }//catch
        return Comando;
    }//GrabaA1000802

    private void ParamGrabaA1000802(ref OracleCommand cmd, string COD_DOCUM, string NOM_DOMICILIO1, string NOM_DOMICILIO2,
        string NOM_DOMICILIO3, string COD_POSTAL, string COD_ESTADO, string TXT_ETIQUETA4, string COD_LOCALIDAD, 
        string TXT_ETIQUETA5, string TLF_NUMERO, string TXT_EMAIL, string NUM_POLIZA, string NUM_RIESGO)
    {
        OracleParameter Param = new OracleParameter();
        Param.ParameterName = "p_cod_cia";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Int32;
        Param.Value = 1;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_num_poliza";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = NUM_POLIZA;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_num_spto";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Int32;
        Param.Value = 0;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_num_riesgo";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Int32;
        Param.Value = NUM_RIESGO;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_tip_docum";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = "RFC";
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_cod_docum";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = COD_DOCUM;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_nom_domicilio1";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = NOM_DOMICILIO1;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_nom_domicilio2";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = NOM_DOMICILIO2;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_nom_domicilio3";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = NOM_DOMICILIO3;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "nom_localidad";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = TXT_ETIQUETA5;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "cod_pais";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = "MEX";
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "cod_prov";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Int32;
        Param.Value = COD_LOCALIDAD;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "cod_postal";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = COD_POSTAL;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "txt_etiqueta1";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = NOM_DOMICILIO1;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "txt_etiqueta2";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = NOM_DOMICILIO2;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "txt_etiqueta3";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = NOM_DOMICILIO3;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "txt_etiqueta4";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = COD_POSTAL + " " + TXT_ETIQUETA5;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "txt_etiqueta5";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = TXT_ETIQUETA4;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "tlf_numero";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = TLF_NUMERO;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "email";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = TXT_EMAIL;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "cod_estado";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Int32;
        Param.Value = COD_ESTADO;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "txt_email";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = TXT_EMAIL;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "cod_pais_etiqueta";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = "MEX";
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "cod_estado_etiqueta";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Int32;
        Param.Value = COD_ESTADO;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "cod_prov_etiqueta";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Int32;
        Param.Value = COD_LOCALIDAD;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "cod_postal_etiqueta";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = COD_POSTAL;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "cod_localidad";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Int32;
        Param.Value = COD_LOCALIDAD;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "cod_localidad_etiqueta";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Int32;
        Param.Value = COD_LOCALIDAD;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "nom_localidad_etiqueta";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = TXT_ETIQUETA5;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "tip_etiqueta";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Int32;
        Param.Value = "1";
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_result";
        Param.Direction = ParameterDirection.Output;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Size = 200;
        cmd.Parameters.Add(Param);
    }

    public OracleCommand BorraPoliza(OracleConnection Conexion, string Poliza)
    {
        OracleCommand Comando = new OracleCommand();

        try
        {
            Comando.Connection = Conexion;
            Comando.CommandText = "Ev_K_Solicitudes_Web.p_validar_solicitud_si24";
            Comando.CommandType = CommandType.StoredProcedure;

            ParamBorraPoliza(ref Comando, Poliza);

            Comando.ExecuteNonQuery();
        }//try
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string e = Error.Message.ToString();
        }//catch
        return Comando;
    }//BorraPoliza

    private void ParamBorraPoliza(ref OracleCommand cmd, string Poliza)
    {
        OracleParameter Param = new OracleParameter();
        Param.ParameterName = "p_cod_cia";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Int16;
        Param.Value = 1;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_num_poliza";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = Poliza;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_num_spto";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Int16;
        Param.Value = 0;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_num_apli";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Int16;
        Param.Value = 0;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_num_spto_apli";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Int16;
        Param.Value = 0;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_result";
        Param.Direction = ParameterDirection.Output;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Size = 2000;
        cmd.Parameters.Add(Param);
    }

    public OracleCommand DepuraSF_familiar(OracleConnection Conexion, string RFC)
    {
        OracleCommand Comando = new OracleCommand();

        try
        {
            Comando.Connection = Conexion;
            Comando.CommandText = "ev_k_solicitudes_web.p_depuraSF_familiar";
            Comando.CommandType = CommandType.StoredProcedure;

            ParamDepuraSF_familiar(ref Comando, RFC);

            Comando.ExecuteNonQuery();
        }//try
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string e = Error.Message.ToString();
        }//catch
        return Comando;
    }//DepuraSF_familiar

    private void ParamDepuraSF_familiar(ref OracleCommand cmd, string RFC)
    {
        OracleParameter Param = new OracleParameter();
        Param.ParameterName = "p_cod_cia";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Int16;
        Param.Value = 1;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_tip_docum";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = "RFC";
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_cod_docum";
        Param.Direction = ParameterDirection.Input;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Value = RFC;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_result";
        Param.Direction = ParameterDirection.Output;
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Size = 2000;
        cmd.Parameters.Add(Param);
    }

    // ********* DEFINICION DE FUNCIONES PARA INSERCION EN TRONWEB CON AJAX ********
    #region FUNCIONES PARA INSERCION EN TRONWEB CON AJAX

    public bool InsertaP2300205Titular(OracleConnection Conexion, string EV_PR07A_01_01, string EV_PR07A_02_01, string EV_PR07A_04_01, string EV_PR07A_06_01, string EV_PR07A_07_01, string EV_PR07A_08_01, string EV_PR07A_09_01, string EV_PR07A_10_01, string EV_PR07A_11_01, string EV_PR07A_11_02, string EV_PR07A_12_01, string EV_PR07A_12_02, string EV_PR07A_13_01, string EV_PR07A_14_01, string EV_PR07A_14_02, string EV_PR07A_15_01, string EV_PR07A_15_02, string EV_PR07A_15_03, string EV_PR07A_15_04, string EV_PR07A_15_05, string EV_PR07A_16_01, string EV_PR07A_16_02, string NumPoliza, string EV_PRO7A_17_01)
    {
        OracleCommand Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_01_01", EV_PR07A_01_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_02_01", EV_PR07A_02_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_04_01", EV_PR07A_04_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_06_01", EV_PR07A_06_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_02_01", EV_PR07A_02_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_07_01", EV_PR07A_07_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_08_01", EV_PR07A_08_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_09_01", EV_PR07A_09_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_10_01", EV_PR07A_10_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_11_01", EV_PR07A_11_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_11_02", EV_PR07A_11_02);
        Comando.ExecuteNonQuery();


        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_12_01", EV_PR07A_12_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_12_02", EV_PR07A_12_02);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_13_01", EV_PR07A_13_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        // Se cambi� el dato de EV_PR07A_14_02 por el del EV_PR07A_14_01
        // debido a un error que marcaba en Tron Web y que corrigio Adela			
        //ParamP2300205(ref Comando,1,NumPoliza,0,1,71,"EV_PR07A_14_01",EV_PR07A_14_01);
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_14_01", EV_PR07A_14_02);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        // Se cambi� el dato de EV_PR07A_14_02 por el del EV_PR07A_14_01
        // debido a un error que marcaba en Tron Web y que corrigio Adela
        //ParamP2300205(ref Comando,1,NumPoliza,0,1,71,"EV_PR07A_14_02",EV_PR07A_14_02);
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_14_02", EV_PR07A_14_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_15_01", EV_PR07A_15_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_15_02", EV_PR07A_15_02);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_15_03", EV_PR07A_15_03);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_15_04", EV_PR07A_15_04);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_15_05", EV_PR07A_15_05);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_16_01", EV_PR07A_16_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_16_02", EV_PR07A_16_02);
        Comando.ExecuteNonQuery();

        //// Dato de Relaci�n con el Contratante
        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 71, "EV_PR07A_17_01", EV_PRO7A_17_01);
        Comando.ExecuteNonQuery();


        return true;
    }

    private void ParamP2300205(ref OracleCommand Cmd, int p_cod_cia, string p_num_poliza, int p_num_spto, int p_num_riesgo, int p_cod_formulario, string p_cod_campo, string p_val_campo)
    {
        OracleParameter Param = new OracleParameter();
        Param.ParameterName = "p_cod_cia";
        Param.OracleDbType = OracleDbType.Int32;
        Param.Direction = ParameterDirection.Input;
        Param.Value = p_cod_cia;
        Cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_num_poliza";
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Direction = ParameterDirection.Input;
        Param.Value = p_num_poliza;
        Cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_num_spto";
        Param.OracleDbType = OracleDbType.Int32;
        Param.Direction = ParameterDirection.Input;
        Param.Value = p_num_spto;
        Cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_num_riesgo";
        Param.OracleDbType = OracleDbType.Int32;
        Param.Direction = ParameterDirection.Input;
        Param.Value = p_num_riesgo;
        Cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_cod_formulario";
        Param.OracleDbType = OracleDbType.Int32;
        Param.Direction = ParameterDirection.Input;
        Param.Value = p_cod_formulario;
        Cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_cod_campo";
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Direction = ParameterDirection.Input;
        Param.Value = p_cod_campo;
        Cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_val_campo";
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Direction = ParameterDirection.Input;
        Param.Value = p_val_campo;
        Cmd.Parameters.Add(Param);
    }

    public void InsertaP2300205RefPersonales(OracleConnection Conexion, string EV_PR02A_04_01, string EV_PR02A_04_02, string EV_PR02A_04_03, string EV_PR02A_04_04, string CadRefPersonales, string NumPoliza)
    {
        string[] auxOtrosSeg = CadRefPersonales.Split(new char[] { '|' });
        string[] strAux;
        System.Int16 NumRiesgo1 = 0;
        System.Int16 NumRiesgo2 = 0;

        OracleCommand Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR02A_04_01", EV_PR02A_04_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR02A_04_02", EV_PR02A_04_02);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR02A_04_03", EV_PR02A_04_03);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR02A_04_04", EV_PR02A_04_04);
        Comando.ExecuteNonQuery();

        ////////////////////////////////////////////////////////////////////////////
        ///// Cadena de Referencias Personales,  ///////////////////////////////////
        ///// Corresponde a los datos que est�n en el Grid /////////////////////////
        ////////////////////////////////////////////////////////////////////////////


        foreach (string Datos in auxOtrosSeg)
        {
            if (Datos != "")
            {
                NumRiesgo1++;
                NumRiesgo2 = 0;
                strAux = Datos.Split(new char[] { ':' });
                foreach (string Dat in strAux)
                {
                    //						if(Dat != "")
                    //						{
                    NumRiesgo2++;
                    Comando = new OracleCommand();
                    Comando.Connection = Conexion;
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                    if (Dat == "0")
                    {
                        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 21, "EV_PR02A_0" + NumRiesgo1.ToString() + "_0" + NumRiesgo2.ToString(), "");
                    }
                    else
                    {
                        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 21, "EV_PR02A_0" + NumRiesgo1.ToString() + "_0" + NumRiesgo2.ToString(), Dat);
                    }
                    Comando.ExecuteNonQuery();
                    //						}
                }


            }
        }
    }

    public void InsertaP2300205AntFamiliares(OracleConnection Conexion, string CadenaAntFamiliares, string NumPoliza)
    {
        string[] strAntFamiliares = CadenaAntFamiliares.Split(new char[] { '|' });
        string[] strAux;
        int Indice1 = 0;
        OracleCommand Comando;


        foreach (string Datos in strAntFamiliares)
        {
            if (Datos != "")
            {
                strAux = Datos.Split(new char[] { ':' });

                /*if(strAux[0]!="")
                {*/
                Indice1++;
                Comando = new OracleCommand();
                Comando.Connection = Conexion;
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 51, "EV_PR05A_0" + Indice1 + "_01", strAux[0]); //Parentesco
                Comando.ExecuteNonQuery();

                Comando = new OracleCommand();
                Comando.Connection = Conexion;
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 51, "EV_PR05A_0" + Indice1 + "_02", ""); //Otro Parentesco
                Comando.ExecuteNonQuery();

                Indice1++;

                Comando = new OracleCommand();
                Comando.Connection = Conexion;
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 51, "EV_PR05A_0" + Indice1 + "_01", strAux[3]); //Vive
                Comando.ExecuteNonQuery();

                Comando = new OracleCommand();
                Comando.Connection = Conexion;
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 51, "EV_PR05A_0" + Indice1 + "_51", strAux[4]); //Edad de la Muerte
                Comando.ExecuteNonQuery();

                Comando = new OracleCommand();
                Comando.Connection = Conexion;
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 51, "EV_PR05A_0" + Indice1 + "_52", strAux[5]); //Causa de la muerte
                Comando.ExecuteNonQuery();

                Comando = new OracleCommand();
                Comando.Connection = Conexion;
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 51, "EV_PR05A_0" + Indice1 + "_02", strAux[1]); //Edad
                Comando.ExecuteNonQuery();

                Comando = new OracleCommand();
                Comando.Connection = Conexion;
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 51, "EV_PR05A_0" + Indice1 + "_03", strAux[2]); //Estado de Salud
                Comando.ExecuteNonQuery();

                Comando = new OracleCommand();
                Comando.Connection = Conexion;
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 51, "EV_PR05A_0" + Indice1 + "_04", strAux[6]); //Enfermedad
                Comando.ExecuteNonQuery();

                Comando = new OracleCommand();
                Comando.Connection = Conexion;
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 51, "EV_PR05A_0" + Indice1 + "_05", strAux[7]); //Evoculci�n
                Comando.ExecuteNonQuery();
                //}//If
            }//If
        }//Foreach
    }

    public void InsertaP2300205Cuestionario(OracleConnection Conexion, string CadCuestionario, string EV_PR04A_06_01, string EV_PR04A_07_01, string EV_PR04A_39_01, string EV_PR04A_40_01, string EV_PR04A_40_02, string NumPoliza)
    {
        string[] auxCuestionario = CadCuestionario.Split(new char[] { '|' });
        string[] strAux;
        int Indice1 = 0;
        int Indice2 = 0;
        System.Int16 aux = 0;
        OracleCommand Comando;

        ////// Insertando las preguntas 
        ////// Distitas (Nombre M�dico, Hospital, etc)

        //// Modificaci�n 14 de Dic, 
        //// 
        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR04A_06_01", EV_PR04A_06_01); //ESTATURA
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR04A_07_01", EV_PR04A_07_01); //PESO
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR04A_39_01", EV_PR04A_39_01); //NOMBRE DEL MEDICO
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR04A_40_01", EV_PR04A_40_01); //DIRECCION DE SU MEDICO
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        //// Se cambi� por el c�digo EV_PR04A_41_01 15 Ene 2006
        //// antes: EV_PR04A_40_02
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR04A_41_01", EV_PR04A_40_02); //NOMBRE DEL HOSPITAL
        Comando.ExecuteNonQuery();

        foreach (string Cadena in auxCuestionario)
        {
            if (Cadena != "")
            {
                strAux = Cadena.Split(new char[] { ':' });
                if (Cadena != "")
                {
                    Indice1++;
                    Indice2 = 0;
                    foreach (string Data in strAux)
                    {
                        // Se agrego el indice 12 para mostrarlo en los reportes 18/Sep/2007
                        if ((Indice1 != 10) && (Indice1 != 11) && (Indice1 != 6) && (Indice1 != 7) && (Indice1 != 39) && (Indice1 != 40) && (Indice1 != 41))
                        {
                            Indice2++;
                            Comando = new OracleCommand();
                            Comando.Connection = Conexion;
                            Comando.CommandType = CommandType.StoredProcedure;
                            Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                            if (Indice1 <= 9)
                            {
                                switch (Data)
                                {
                                    case "true": ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR04A_0" + Indice1.ToString() + "_0" + Indice2.ToString(), "S");
                                        break;
                                    case "false": ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR04A_0" + Indice1.ToString() + "_0" + Indice2.ToString(), "N");
                                        break;
                                    default: ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR04A_0" + Indice1.ToString() + "_0" + Indice2.ToString(), Data);
                                        break;
                                }
                            }
                            else
                            {
                                switch (Data)
                                {
                                    case "true": ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR04A_" + Indice1.ToString() + "_0" + Indice2.ToString(), "S");
                                        break;
                                    case "false": ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR04A_" + Indice1.ToString() + "_0" + Indice2.ToString(), "N");
                                        break;
                                    default: ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR04A_" + Indice1.ToString() + "_0" + Indice2.ToString(), Data);
                                        break;
                                }
                            }

                            Comando.ExecuteNonQuery();
                        }
                        else
                        {
                            Indice2++;
                            ////a).En caso de ser mujer, Has tenido alguna enfermedad propia de la mujer?     
                            //// Y b).En caso de ser mujer, (Esta actualmente enbarazada?, en caso afirmativo: c)
                            if ((Indice1 == 10) || (Indice1 == 11))
                            {

                                Comando = new OracleCommand();
                                Comando.Connection = Conexion;
                                Comando.CommandType = CommandType.StoredProcedure;
                                Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                                //aux = Convert.ToInt16(Indice2 + 1);
                                aux = Convert.ToInt16(Indice2);

                                switch (Data)
                                {
                                    case "true": ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR04M_" + Indice1.ToString() + "_0" + aux.ToString(), "S");
                                        break;
                                    case "false": ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR04M_" + Indice1.ToString() + "_0" + aux.ToString(), "N");
                                        break;
                                    default: ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 41, "EV_PR04M_" + Indice1.ToString() + "_0" + aux.ToString(), Data);
                                        break;
                                }
                                Comando.ExecuteNonQuery();

                            }//If
                            //// 9. Padece o ha padecido: a. Enfermedad cardiaca?
                            /* Se comento esta parte, para mostrar el indice 12 (Enfermedad Cardiaca)
                             * en los reportes
                            if(Indice1 == 12)
                            {
                                Comando = new OracleCommand();
                                Comando.Connection    = Conexion;
                                Comando.CommandType   = CommandType.StoredProcedure;
                                Comando.CommandText   = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                                //aux = Convert.ToInt16(Indice2 + 1);
                                aux = Convert.ToInt16(Indice2);
									
                                switch(Data)
                                {
                                    case "true":ParamP2300205(ref Comando,1,NumPoliza,0,1,41,"EV_PR04A_43_0" + aux.ToString(),"S");
                                        break;
                                    case "false":ParamP2300205(ref Comando,1,NumPoliza,0,1,41,"EV_PR04A_43_0" + aux.ToString(),"N");
                                        break;	
                                    default:ParamP2300205(ref Comando,1,NumPoliza,0,1,41,"EV_PR04A_43_0" + aux.ToString(),Data);
                                        break;
                                }											
                                Comando.ExecuteNonQuery();
									
                            }*/
                        }//Else
                    } // foreach
                }// If
            }//If
        } //Foreach			
    }//funci�n

    public void InsertaP2300205InfAgente(OracleConnection Conexion, string EV_PR06A_01_01, string EV_PR06A_02_01, string EV_PR06A_03_01, string EV_PR06A_04_01, string EV_PR06A_05_01, string EV_PR06A_06_01, string EV_PR06A_12_01, string EV_PR06A_08_01, string EV_PR06A_07_01, string EV_PR06A_09_01, string EV_PR06A_13_01, string EV_PR06A_10_01, string NumPoliza)
    {
        ////--- Variables para Observaciones
        string EV_PR06A_14_01;
        string EV_PR06A_15_01;
        string EV_PR06A_16_01;
        string EV_PR06A_17_01;
        string EV_PR06A_18_01;
        string EV_PR06A_19_01;
        string EV_PR06A_20_01;
        string EV_PR06A_21_01;
        string EV_PR06A_22_01;
        string Observaciones1;
        int RangoFaltante = 0;


        OracleCommand Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_01_01", EV_PR06A_01_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_02_01", EV_PR06A_02_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_03_01", EV_PR06A_03_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_04_01", EV_PR06A_04_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_05_01", EV_PR06A_05_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_06_01", EV_PR06A_06_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_12_01", EV_PR06A_12_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_08_01", EV_PR06A_08_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_07_01", EV_PR06A_07_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_09_01", EV_PR06A_09_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_13_01", EV_PR06A_13_01);
        Comando.ExecuteNonQuery();

        //Observaciones, se le agreg� el % para cumplir los 150 caracteres
        //requeridos
        //EV_PR06A_10_01 = EV_PR06A_10_01.Replace(" ","_");
        if (EV_PR06A_10_01.Length < 300)
        {
            RangoFaltante = 300 - EV_PR06A_10_01.Length;
            for (int i = 0; i <= RangoFaltante; i++)
                EV_PR06A_10_01 = EV_PR06A_10_01 + "%";

        }
        else
        {
            if (EV_PR06A_10_01.Length > 300)
            {
                EV_PR06A_10_01 = EV_PR06A_10_01.Substring(0, 300);
            }
        }

        try
        {
            Observaciones1 = EV_PR06A_10_01.Substring(0, 30);
        }
        catch
        {
            Observaciones1 = "";
        }

        try
        {
            EV_PR06A_14_01 = EV_PR06A_10_01.Substring(30, 30);
        }
        catch
        {
            EV_PR06A_14_01 = "";
        }

        try
        {
            EV_PR06A_15_01 = EV_PR06A_10_01.Substring(60, 30);
        }
        catch
        {
            EV_PR06A_15_01 = "";
        }

        try
        {
            EV_PR06A_16_01 = EV_PR06A_10_01.Substring(90, 30);
        }
        catch
        {
            EV_PR06A_16_01 = "";
        }

        try
        {
            EV_PR06A_17_01 = EV_PR06A_10_01.Substring(120, 30);
        }
        catch
        {
            EV_PR06A_17_01 = "";
        }


        try
        {
            EV_PR06A_18_01 = EV_PR06A_10_01.Substring(150, 30);
        }
        catch
        {
            EV_PR06A_18_01 = "";
        }


        try
        {
            EV_PR06A_19_01 = EV_PR06A_10_01.Substring(180, 30);
        }
        catch
        {
            EV_PR06A_19_01 = "";
        }


        try
        {
            EV_PR06A_20_01 = EV_PR06A_10_01.Substring(210, 30);
        }
        catch
        {
            EV_PR06A_20_01 = "";
        }


        try
        {
            EV_PR06A_21_01 = EV_PR06A_10_01.Substring(240, 30);
        }
        catch
        {
            EV_PR06A_21_01 = "";
        }


        try
        {
            EV_PR06A_22_01 = EV_PR06A_10_01.Substring(270, 30);
        }
        catch
        {
            EV_PR06A_22_01 = "";
        }


        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_10_01", Observaciones1.Replace("%", ""));
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_14_01", EV_PR06A_14_01.Replace("%", ""));
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_15_01", EV_PR06A_15_01.Replace("%", ""));
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_16_01", EV_PR06A_16_01.Replace("%", ""));
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_17_01", EV_PR06A_17_01.Replace("%", ""));
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_18_01", EV_PR06A_18_01.Replace("%", ""));
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_19_01", EV_PR06A_19_01.Replace("%", ""));
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_20_01", EV_PR06A_20_01.Replace("%", ""));
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_21_01", EV_PR06A_21_01.Replace("%", ""));
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 61, "EV_PR06A_22_01", EV_PR06A_22_01.Replace("%", ""));
        Comando.ExecuteNonQuery();
    }

    public void InsertaP2300205Habitos(OracleConnection Conexion, string EV_PR03A_01_01, string EV_PR03A_01_02, string EV_PR03A_01_04, string EV_PR03A_01_05, string EV_PR03A_01_06, string EV_PR03A_01_07, string EV_PR03A_01_08, string EV_PR03A_02_01, string EV_PR03A_02_02, string EV_PR03A_02_03, string EV_PR03A_02_04, string EV_PR03A_02_05, string EV_PR03A_02_06, string EV_PR03A_02_07, string EV_PR03A_03_01, string EV_PR03A_03_02, string EV_PR03A_03_03, string EV_PR03A_03_04, string EV_PR03A_03_05, string EV_PR03A_03_06, string EV_PR03A_03_07, string NumPoliza)
    {
        string EV_PR03A_01_03 = "";
        OracleCommand Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_01_01", EV_PR03A_01_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_01_02", EV_PR03A_01_02);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_01_03", EV_PR03A_01_03);  //En caso de OTROS como no se contemplo se manda valor nulo
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_01_04", EV_PR03A_01_04);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_01_05", EV_PR03A_01_05);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_01_06", EV_PR03A_01_06);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_01_07", EV_PR03A_01_07);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_01_08", EV_PR03A_01_08);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_02_01", EV_PR03A_02_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_02_02", EV_PR03A_02_02);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_02_03", EV_PR03A_02_03);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_02_04", EV_PR03A_02_04);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_02_05", EV_PR03A_02_05);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_02_06", EV_PR03A_02_06);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_02_07", EV_PR03A_02_07);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_03_01", EV_PR03A_03_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_03_02", EV_PR03A_03_02);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_03_03", EV_PR03A_03_03);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_03_04", EV_PR03A_03_04);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_03_05", EV_PR03A_03_05);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_03_06", EV_PR03A_03_06);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 31, "EV_PR03A_03_07", EV_PR03A_03_07);
        Comando.ExecuteNonQuery();
    }

    public void InsertaP2300205OtrosSeguros(OracleConnection Conexion, string EV_PR01A_01_01, string EV_PR01A_01_02, string EV_PR01A_01_03, string EV_PR01A_02_01, string EV_PR01A_02_02, string CadOtrosSeguros, string NumPoliza)
    {
        string[] auxOtrosSeg = CadOtrosSeguros.Split(new char[] { '|' });
        string[] strAux;
        System.Int16 NumRiesgo = 0;

        OracleCommand Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205"; //Compa��a
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 11, "EV_PR01A_01_01", EV_PR01A_01_01);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 11, "EV_PR01A_01_02", EV_PR01A_01_02);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 11, "EV_PR01A_01_03", EV_PR01A_01_03);
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 11, "EV_PR01A_02_01", EV_PR01A_02_01);  //Le han rechazado
        Comando.ExecuteNonQuery();

        Comando = new OracleCommand();
        Comando.Connection = Conexion;
        Comando.CommandType = CommandType.StoredProcedure;
        Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 11, "EV_PR01A_02_02", EV_PR01A_02_02);
        Comando.ExecuteNonQuery();

        ////////////////////////////////////////////////////////////////////////////
        ///// Cadena de Otros Seguros, Corresponde a los datos que est�n en el Grid
        ////////////////////////////////////////////////////////////////////////////

        foreach (string Datos in auxOtrosSeg)
        {
            if (Datos != "")
            {
                strAux = Datos.Split(new char[] { ':' });

                if (strAux[0] != "")
                {
                    NumRiesgo++;
                    Comando = new OracleCommand();
                    Comando.Connection = Conexion;
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                    if (strAux[0] == "0")
                        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 11, "EV_PR01A_01_01", ""); //Compa��a
                    else
                        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 11, "EV_PR01A_01_01", strAux[0]); //Compa��a
                    Comando.ExecuteNonQuery();

                    Comando = new OracleCommand();
                    Comando.Connection = Conexion;
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                    if (strAux[0] == "0")
                        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 11, "EV_PR01A_01_07", ""); //Prima Anual
                    else
                        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 11, "EV_PR01A_01_07", strAux[1]); //Prima Anual
                    Comando.ExecuteNonQuery();

                    Comando = new OracleCommand();
                    Comando.Connection = Conexion;
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                    if (strAux[0] == "0")
                        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 11, "EV_PR01A_01_06", ""); //Moneda
                    else
                        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 11, "EV_PR01A_01_06", strAux[2]); //Moneda
                    Comando.ExecuteNonQuery();

                    Comando = new OracleCommand();
                    Comando.Connection = Conexion;
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                    if (strAux[0] == "0")
                        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 11, "EV_PR01A_01_04", ""); //Plan Solicitado
                    else
                        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 11, "EV_PR01A_01_04", strAux[3]); //Plan Solicitado
                    Comando.ExecuteNonQuery();

                    Comando = new OracleCommand();
                    Comando.Connection = Conexion;
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.CommandText = "ev_k_inserta_solicitudes.p_inserta_p2300205";
                    if (strAux[0] == "0")
                        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 11, "EV_PR01A_01_05", ""); //Estado Actual
                    else
                        ParamP2300205(ref Comando, 1, NumPoliza, 0, 1, 11, "EV_PR01A_01_05", strAux[4]); //Estado Actual
                    Comando.ExecuteNonQuery();
                }// If
            } // If
        }// For Each
    }

    #endregion

    // ********* DEFINICION DE PROCEDIMIENTOS PARA CONSULTAS DE SOLICITUDES VIDA ********
    #region Procedimientos para consulta de datos

    public DataRow ConsultaContratante(int iCia, string sNumSol, int inum_spto, int inum_apli, int inum_spto_apli)
    {
        MCommand cmd = new MCommand();
        DataRow objDR;
        string strError;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "Ev_K_Consulta_Solicitud.p_consulta_contrate";

                //input
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, iCia);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, sNumSol);
                cmd.agregarINParametro("p_num_spto", OracleDbType.Int32, inum_spto);
                cmd.agregarINParametro("p_num_apli", OracleDbType.Int32, inum_apli);
                cmd.agregarINParametro("p_num_spto_apli", OracleDbType.Int32, inum_spto_apli);
                //output
                cmd.agregarOUTParametro("p_cod_ramo", OracleDbType.Int32, 5);
                cmd.agregarOUTParametro("p_nom_ramo", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_cod_mon", OracleDbType.Int32, 3);
                cmd.agregarOUTParametro("p_nom_mon", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_tip_regulariza", OracleDbType.Varchar2, 80);
                cmd.agregarOUTParametro("p_nom_regulariza", OracleDbType.Varchar2, 80);
                cmd.agregarOUTParametro("p_tip_deducible", OracleDbType.Varchar2, 80);
                cmd.agregarOUTParametro("p_nom_deducible", OracleDbType.Varchar2, 80);
                cmd.agregarOUTParametro("p_tip_comision", OracleDbType.Varchar2, 80);
                cmd.agregarOUTParametro("p_nom_comision", OracleDbType.Varchar2, 80);
                cmd.agregarOUTParametro("p_duracion_hasta", OracleDbType.Varchar2, 80);
                cmd.agregarOUTParametro("p_cod_modalidad", OracleDbType.Int32, 6);
                cmd.agregarOUTParametro("p_nom_modalidad", OracleDbType.Varchar2, 50);
                cmd.agregarOUTParametro("p_fec_nacimiento", OracleDbType.Varchar2, 10);
                cmd.agregarOUTParametro("p_fec_emision", OracleDbType.Varchar2, 10);
                cmd.agregarOUTParametro("p_num_poliza_grupo", OracleDbType.Varchar2, 13);
                cmd.agregarOUTParametro("p_num_contrato", OracleDbType.Int32, 6);
                cmd.agregarOUTParametro("p_nom_contrato", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_cve_empleado", OracleDbType.Varchar2, 80);
                cmd.agregarOUTParametro("p_rfc", OracleDbType.Varchar2, 20);
                cmd.agregarOUTParametro("p_mca_fisico", OracleDbType.Varchar2, 2);
                cmd.agregarOUTParametro("p_curp", OracleDbType.Varchar2, 20);
                cmd.agregarOUTParametro("p_nombres", OracleDbType.Varchar2, 60);
                cmd.agregarOUTParametro("p_ap_paterno", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_ap_materno", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_calle", OracleDbType.Varchar2, 40);
                cmd.agregarOUTParametro("p_numero", OracleDbType.Varchar2, 40);
                cmd.agregarOUTParametro("p_colonia", OracleDbType.Varchar2, 40);
                cmd.agregarOUTParametro("p_cp", OracleDbType.Varchar2, 15);
                cmd.agregarOUTParametro("p_cod_estado", OracleDbType.Int32, 3);
                cmd.agregarOUTParametro("p_nom_estado", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_cod_municipio", OracleDbType.Int32, 6);
                cmd.agregarOUTParametro("p_nom_municipio", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_telefono", OracleDbType.Varchar2, 10);
                cmd.agregarOUTParametro("p_email", OracleDbType.Varchar2, 60);
                cmd.agregarOUTParametro("p_mca_dom_primas", OracleDbType.Varchar2, 80);
                cmd.agregarOUTParametro("p_calle_primas", OracleDbType.Varchar2, 40);
                cmd.agregarOUTParametro("p_numero_primas", OracleDbType.Varchar2, 40);
                cmd.agregarOUTParametro("p_colonia_primas", OracleDbType.Varchar2, 40);
                cmd.agregarOUTParametro("p_cp_primas", OracleDbType.Varchar2, 15);
                cmd.agregarOUTParametro("p_cod_estado_primas", OracleDbType.Int32, 3);
                cmd.agregarOUTParametro("p_nom_estado_primas", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_cod_municipio_primas", OracleDbType.Int32, 6);
                cmd.agregarOUTParametro("p_nom_municipio_primas", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_telefono_primas", OracleDbType.Varchar2, 10);
                cmd.agregarOUTParametro("p_rel_solicte", OracleDbType.Varchar2, 30);

                objDR = cmd.ejecutarRegistroSP();

                return objDR;
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            strError = Error.Message + " - No se recuperaron Datos del Contratante";
            return null;
        }
    }//ConsultaContratante

    public OracleCommand ConsultaContrato(int iCia, string sNumSol, int inum_spto, int inum_apli, int inum_spto_apli)
    {
        OracleCommand Comando = new OracleCommand();
        string strError;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                Comando.CommandText = "ev_k_consulta_solicitud.p_consulta_poliza_gpo";
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Connection = conexion;

                //Declaraci�n de par�metros
                OracleParameter Param = new OracleParameter();
                Param.ParameterName = "p_cod_cia";
                Param.OracleDbType = OracleDbType.Int16;
                Param.Direction = ParameterDirection.Input;
                Param.Value = iCia;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_poliza";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 13;
                Param.Direction = ParameterDirection.Input;
                Param.Value = sNumSol;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto";
                Param.OracleDbType = OracleDbType.Int16;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_apli";
                Param.OracleDbType = OracleDbType.Int16;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto_apli";
                Param.OracleDbType = OracleDbType.Int16;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_contrato";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 2000;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_poliza_grupo";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 2000;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_nom_contrato";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 2000;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                //Asigna Par�metros de Entrada
                Comando.Parameters["p_cod_cia"].Value = iCia;
                Comando.Parameters["p_num_poliza"].Value = sNumSol;
                Comando.Parameters["p_num_spto"].Value = inum_spto;
                Comando.Parameters["p_num_apli"].Value = inum_apli;
                Comando.Parameters["p_num_spto_apli"].Value = inum_spto_apli;

                Comando.ExecuteNonQuery();
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            strError = Error.Message + " - No se recuperaron Datos del Contratante";
        }

        return Comando;
    }//ConsultaContrato

    public DataRow ConsultaSolicitante(int iCia, string sNumSol, int iNumSpto, int iNumApli, int iNumSptoApli)
    {
        MCommand cmd = new MCommand();
        DataRow objDR;
        string strError;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "Ev_K_Consulta_Solicitud.p_consulta_solicte";

                //input
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, iCia);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, sNumSol);
                cmd.agregarINParametro("p_num_spto", OracleDbType.Int32, iNumSpto);
                cmd.agregarINParametro("p_num_apli", OracleDbType.Int32, iNumApli);
                cmd.agregarINParametro("p_num_spto_apli", OracleDbType.Int32, iNumSptoApli);
                //output
                cmd.agregarOUTParametro("p_cte_solicte", OracleDbType.Varchar2, 80);
                cmd.agregarOUTParametro("p_rfc", OracleDbType.Varchar2, 20);
                cmd.agregarOUTParametro("p_mca_fisico", OracleDbType.Varchar2, 1);
                cmd.agregarOUTParametro("p_curp", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_sexo", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_desc_sexo", OracleDbType.Varchar2, 150);
                cmd.agregarOUTParametro("p_fumador", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_fec_nacimiento", OracleDbType.Varchar2, 10);
                cmd.agregarOUTParametro("p_nombres", OracleDbType.Varchar2, 60);
                cmd.agregarOUTParametro("p_ap_paterno", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_ap_materno", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_edad", OracleDbType.Int16, 0);//size
                cmd.agregarOUTParametro("p_estado_nac", OracleDbType.Int16, 0);//size
                cmd.agregarOUTParametro("p_nom_estado_nac", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_municipio_nac", OracleDbType.Int16, 0);//size
                cmd.agregarOUTParametro("p_nom_municipio_nac", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_cod_pais_nac", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_nom_pais_nac", OracleDbType.Varchar2, 60);
                cmd.agregarOUTParametro("p_edo_civil", OracleDbType.Varchar2, 1);
                cmd.agregarOUTParametro("p_desc_edo_civil", OracleDbType.Varchar2, 150);
                cmd.agregarOUTParametro("p_calle", OracleDbType.Varchar2, 40);
                cmd.agregarOUTParametro("p_numero", OracleDbType.Varchar2, 40);
                cmd.agregarOUTParametro("p_colonia", OracleDbType.Varchar2, 40);
                cmd.agregarOUTParametro("p_cp", OracleDbType.Varchar2, 14);
                cmd.agregarOUTParametro("p_estado", OracleDbType.Int16, 0);//size
                cmd.agregarOUTParametro("p_nom_estado", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_municipio", OracleDbType.Int16, 0);//size
                cmd.agregarOUTParametro("p_nom_municipio", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_telefono", OracleDbType.Varchar2, 10);
                cmd.agregarOUTParametro("p_email", OracleDbType.Varchar2, 60);
                cmd.agregarOUTParametro("p_ocupacion", OracleDbType.Int64, 0);//size
                cmd.agregarOUTParametro("p_desc_ocupacion", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_especifique", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_empresa", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_tel_oficina", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_puesto", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_ing_anual", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_giro_empresa", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_desc_giro_empresa", OracleDbType.Varchar2, 150);
                cmd.agregarOUTParametro("p_esp_giro_empresa", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_herramientas", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_tipo_herr", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_licencia", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_certif_med", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_fecha_expiracion", OracleDbType.Varchar2, 10);
                cmd.agregarOUTParametro("p_viaja", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_viaja_extranjero", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_tipo_transporte", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_desc_tipo_transporte", OracleDbType.Varchar2, 150);
                cmd.agregarOUTParametro("p_otro_transporte", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_trabaja_alturas", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_altura_prom", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_lugar_trabajo", OracleDbType.Varchar2, 30);
                cmd.agregarOUTParametro("p_desc_lugar_trabajo", OracleDbType.Varchar2, 150);
                cmd.agregarOUTParametro("p_esp_lugar_trabajo", OracleDbType.Varchar2, 30);

                objDR = cmd.ejecutarRegistroSP();

                return objDR;
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            strError = Error.Message + " - No se recuperaron Datos del Solicitante";
            return null;
        }
    }//ConsultaSolicitante


    public OracleCommand ConsultaDatosPoliza(int iCia, string sNumSol, int inum_spto, int inum_apli, int inum_spto_apli)
    {
        OracleCommand Comando = new OracleCommand();
        string strError;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                Comando.CommandText = "Ev_K_Consulta_Solicitud.p_consulta_poliza";
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Connection = conexion;

                //Declaraci�n de par�metros
                OracleParameter Param = new OracleParameter();
                Param.ParameterName = "p_cod_cia";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = iCia;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_poliza";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 13;
                Param.Direction = ParameterDirection.Input;
                Param.Value = sNumSol;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_forma_pago";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_desc_forma_pago";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 200;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_tipo_pago";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 200;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_desc_tipo_pago";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 200;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cod_envio";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 200;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_desc_cod_envio";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 200;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_clave_agte";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_interven_agtes";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 200;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cadena_agtes";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 2000;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cadena_cob";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 2000;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                //Asigna Par�metros de Entrada
                Comando.Parameters["p_cod_cia"].Value = iCia;
                Comando.Parameters["p_num_poliza"].Value = sNumSol;
                Comando.Parameters["p_num_spto"].Value = inum_spto;
                Comando.Parameters["p_num_apli"].Value = inum_apli;
                Comando.Parameters["p_num_spto_apli"].Value = inum_spto_apli;

                Comando.ExecuteNonQuery();
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            strError = Error.Message + " - No se recuperaron Datos de la P�liza";
        }

        return Comando;
    }//ConsultaPoliza


    public OracleCommand ConsultaBeneficiarios(int iCia, string sNumSol, int inum_spto, int inum_apli, int inum_spto_apli)
    {
        OracleCommand Comando = new OracleCommand();
        string strError;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                Comando.CommandText = "Ev_K_Consulta_Solicitud.p_consulta_benef";
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Connection = conexion;

                //Declaraci�n de par�metros
                OracleParameter Param = new OracleParameter();
                Param.ParameterName = "p_cod_cia";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = iCia;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_poliza";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 13;
                Param.Direction = ParameterDirection.Input;
                Param.Value = sNumSol;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_total_benef";
                Param.OracleDbType = OracleDbType.Int16;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cadena_benef";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 2000;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_mca_benefmen";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 20;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                //Asigna Par�metros de Entrada
                Comando.Parameters["p_cod_cia"].Value = iCia;
                Comando.Parameters["p_num_poliza"].Value = sNumSol;
                Comando.Parameters["p_num_spto"].Value = inum_spto;
                Comando.Parameters["p_num_apli"].Value = inum_apli;
                Comando.Parameters["p_num_spto_apli"].Value = inum_spto_apli;

                Comando.ExecuteNonQuery();
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            strError = Error.Message + " - No se recuperaron Datos de Beneficiarios";
        }

        return Comando;
    }//ConsultaBeneficiarios


    public OracleCommand ObtieneCasoBenef(int iCia, string sNumSol, int inum_spto, int inum_apli, int inum_spto_apli,
        int iNoBenef, string sTipoBenef)
    {
        OracleCommand Comando = new OracleCommand();
        string strError;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                Comando.CommandText = "Ev_K_Consulta_Solicitud.p_obtiene_benef";
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Connection = conexion;

                //Declaraci�n de par�metros
                OracleParameter Param = new OracleParameter();
                Param.ParameterName = "p_cod_cia";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = iCia;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_poliza";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 13;
                Param.Direction = ParameterDirection.Input;
                Param.Value = sNumSol;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_benef";
                Param.OracleDbType = OracleDbType.Int16;
                Param.Direction = ParameterDirection.Input;
                Param.Value = iNoBenef;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_tip_benef";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 2;
                Param.Direction = ParameterDirection.Input;
                Param.Value = sTipoBenef;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_total_benef";
                Param.OracleDbType = OracleDbType.Int64;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cadena_benef";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 2000; //32767;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                //Asigna Par�metros de Entrada
                Comando.Parameters["p_cod_cia"].Value = iCia;
                Comando.Parameters["p_num_poliza"].Value = sNumSol;
                Comando.Parameters["p_num_spto"].Value = inum_spto;
                Comando.Parameters["p_num_apli"].Value = inum_apli;
                Comando.Parameters["p_num_spto_apli"].Value = inum_spto_apli;
                Comando.Parameters["p_num_benef"].Value = iNoBenef;
                Comando.Parameters["p_tip_benef"].Value = sTipoBenef;

                Comando.ExecuteNonQuery();
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            strError = Error.Message + " - No se recuperaron Datos de Beneficiarios";
        }

        return Comando;
    }//ObtieneCasoBenef


    public OracleCommand ConsultaOtrosSeg(int iCia, string sNumSol, int inum_spto, int inum_apli, int inum_spto_apli)
    {
        OracleCommand Comando = new OracleCommand();
        string strError;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                Comando.CommandText = "Ev_K_Consulta_Solicitud.p_consulta_otrosseg";
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Connection = conexion;

                //Declaraci�n de par�metros
                OracleParameter Param = new OracleParameter();
                Param.ParameterName = "p_cod_cia";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = iCia;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_poliza";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 13;
                Param.Direction = ParameterDirection.Input;
                Param.Value = sNumSol;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_otros_seg";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_desc_otros_seg";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 150;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_compania";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_suma_aseg";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_rechazado_seg";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_desc_rechazado_seg";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_motivo";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 150;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_seguros_exp";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 2000;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                //Asigna Par�metros de Entrada
                Comando.Parameters["p_cod_cia"].Value = iCia;
                Comando.Parameters["p_num_poliza"].Value = sNumSol;
                Comando.Parameters["p_num_spto"].Value = inum_spto;
                Comando.Parameters["p_num_apli"].Value = inum_apli;
                Comando.Parameters["p_num_spto_apli"].Value = inum_spto_apli;

                Comando.ExecuteNonQuery();
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            strError = Error.Message + " - No se recuperaron Datos Otros Seguros";
        }

        return Comando;
    }//ConsultaOtrosSeg


    public OracleCommand ConsultaRefPer(int iCia, string sNumSol, int inum_spto, int inum_apli, int inum_spto_apli)
    {
        OracleCommand Comando = new OracleCommand();
        string strError;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                Comando.CommandText = "Ev_K_Consulta_Solicitud.p_consulta_refer";
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Connection = conexion;

                //Declaraci�n de par�metros
                OracleParameter Param = new OracleParameter();
                Param.ParameterName = "p_cod_cia";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = iCia;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_poliza";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 13;
                Param.Direction = ParameterDirection.Input;
                Param.Value = sNumSol;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cadena_refer";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 2000;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_practica_deporte";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_desc_practica_deporte";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 150;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cuales";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_forma";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_desc_forma";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 150;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cubrir_riesgo";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_desc_cubrir_riesgo";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 150;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                //Asigna Par�metros de Entrada
                Comando.Parameters["p_cod_cia"].Value = iCia;
                Comando.Parameters["p_num_poliza"].Value = sNumSol;
                Comando.Parameters["p_num_spto"].Value = inum_spto;
                Comando.Parameters["p_num_apli"].Value = inum_apli;
                Comando.Parameters["p_num_spto_apli"].Value = inum_spto_apli;

                Comando.ExecuteNonQuery();
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            strError = Error.Message + " - No se recuperaron Datos Consulta Refer";
        }

        return Comando;
    }


    public OracleCommand ConsultaHabitos(int iCia, string sNumSol, int inum_spto, int inum_apli, int inum_spto_apli)
    {
        OracleCommand Comando = new OracleCommand();
        string strError;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                Comando.CommandText = "Ev_K_Consulta_Solicitud.p_consulta_habitos";
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Connection = conexion;

                //Declaraci�n de par�metros
                OracleParameter Param = new OracleParameter();
                Param.ParameterName = "p_cod_cia";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = iCia;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_poliza";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 13;
                Param.Direction = ParameterDirection.Input;
                Param.Value = sNumSol;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cadena_bebidas";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 2000;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cadena_fumador";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 2000;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cadena_drogas";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 2000;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_tipo_droga";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 2000;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                //Asigna Par�metros de Entrada
                Comando.Parameters["p_cod_cia"].Value = iCia;
                Comando.Parameters["p_num_poliza"].Value = sNumSol;
                Comando.Parameters["p_num_spto"].Value = inum_spto;
                Comando.Parameters["p_num_apli"].Value = inum_apli;
                Comando.Parameters["p_num_spto_apli"].Value = inum_spto_apli;

                Comando.ExecuteNonQuery();
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            strError = Error.Message + " - No se recuperaron Datos Habitos";
        }

        return Comando;
    }


    public OracleCommand ConsultaCuestionario(int iCia, string sNumSol, int inum_spto, int inum_apli, int inum_spto_apli)
    {
        OracleCommand Comando = new OracleCommand();
        string strError;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                Comando.CommandText = "Ev_K_Consulta_Solicitud.p_consulta_cuestnario";
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Connection = conexion;

                //Declaraci�n de par�metros
                OracleParameter Param = new OracleParameter();
                Param.ParameterName = "p_cod_cia";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = iCia;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_poliza";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 13;
                Param.Direction = ParameterDirection.Input;
                Param.Value = sNumSol;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cadena_resp";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 200000;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                //Asigna Par�metros de Entrada
                Comando.Parameters["p_cod_cia"].Value = iCia;
                Comando.Parameters["p_num_poliza"].Value = sNumSol;
                Comando.Parameters["p_num_spto"].Value = inum_spto;
                Comando.Parameters["p_num_apli"].Value = inum_apli;
                Comando.Parameters["p_num_spto_apli"].Value = inum_spto_apli;

                Comando.ExecuteNonQuery();
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            strError = Error.Message + " - No se recuperaron Datos Cuestionario";
        }

        return Comando;
    }


    public DataRow ConsultaAntFamil(int iCia, string sNumSol, int inum_spto, int inum_apli, int inum_spto_apli)
    {
        MCommand cmd = new MCommand();
        DataRow objDR;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "Ev_K_Consulta_Solicitud.p_consulta_antfamil";

                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, iCia);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, sNumSol);
                cmd.agregarINParametro("p_num_spto", OracleDbType.Int32, inum_spto);
                cmd.agregarINParametro("p_num_apli", OracleDbType.Int32, inum_apli);
                cmd.agregarINParametro("p_num_spto_apli", OracleDbType.Int32, inum_spto_apli);
                cmd.agregarOUTParametro("p_ant_familiares", OracleDbType.Varchar2, 2000);

                objDR = cmd.ejecutarRegistroSP();

                return objDR;
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string strError = Error.Message + " - No se recuperaron Datos Consulta Antecedentes Familiares";
            return null;
        }
    }


    public OracleCommand ConsultaInfAge(int iCia, string sNumSol, int inum_spto, int inum_apli, int inum_spto_apli)
    {
        OracleCommand Comando = new OracleCommand();
        string strError;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                Comando.CommandText = "Ev_K_Consulta_Solicitud.p_consulta_infagentes";
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Connection = conexion;

                //Declaraci�n de par�metros
                OracleParameter Param = new OracleParameter();
                Param.ParameterName = "p_cod_cia";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = iCia;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_poliza";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 13;
                Param.Direction = ParameterDirection.Input;
                Param.Value = sNumSol;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_tiemposolicte";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_capital_contrate";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_ing_mensuales";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_salud_solictes";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_conocer_habitos";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_riesgo_peligroso";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cliente_firmo_sol";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_firma_contrate";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_firma_sol_princ";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_firma_agentes";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 30;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_lug_fecha";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 75;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_folio";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 75;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_observaciones";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 750;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                //Asigna Par�metros de Entrada
                Comando.Parameters["p_cod_cia"].Value = iCia;
                Comando.Parameters["p_num_poliza"].Value = sNumSol;
                Comando.Parameters["p_num_spto"].Value = inum_spto;
                Comando.Parameters["p_num_apli"].Value = inum_apli;
                Comando.Parameters["p_num_spto_apli"].Value = inum_spto_apli;

                Comando.ExecuteNonQuery();
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            strError = Error.Message + " - No se recuperaron Datos Consulta Inf. Agentes";
        }

        return Comando;
    }

    public OracleCommand ConsultaDatosBanco(int iCia, string sNumSol, int inum_spto, int inum_apli, int inum_spto_apli)
    {
        OracleCommand Comando = new OracleCommand();
        string strError;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                Comando.CommandText = "Ev_K_Consulta_Solicitud.p_consulta_datosbanco";
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Connection = conexion;

                //Declaraci�n de par�metros
                OracleParameter Param = new OracleParameter();
                Param.ParameterName = "p_cod_cia";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = iCia;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_poliza";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 13;
                Param.Direction = ParameterDirection.Input;
                Param.Value = sNumSol;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_tip_cuenta";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 70;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cod_entidad";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 70;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_nom_entidad";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 70;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cod_oficina";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 70;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_plaza";
                Param.OracleDbType = OracleDbType.Int64;
                Param.Size = 70;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cuenta_cte";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 70;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cod_tarjeta";
                Param.OracleDbType = OracleDbType.Int64;
                Param.Size = 70;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_tarjeta";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 70;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_nom_tercero";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 70;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_ape1_tercero";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 70;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_ape2_tercero";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 75;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_fec_efec_poliza";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 75;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_fec_vcto_poliza";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 70;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_fec_efec_spto";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 70;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_fec_vcto_spto";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 70;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_fec_corte";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 70;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_fec_vcto_tarjeta";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 70;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_fec_validez";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 70;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_tip_tarjeta";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Size = 2;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);


                Param = new OracleParameter();
                Param.ParameterName = "p_email";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 60;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                //Asigna Par�metros de Entrada
                Comando.Parameters["p_cod_cia"].Value = iCia;
                Comando.Parameters["p_num_poliza"].Value = sNumSol;
                Comando.Parameters["p_num_spto"].Value = inum_spto;
                Comando.Parameters["p_num_apli"].Value = inum_apli;
                Comando.Parameters["p_num_spto_apli"].Value = inum_spto_apli;

                Comando.ExecuteNonQuery();
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            strError = Error.Message + " - No se recuperaron Datos Consulta Inf. Agentes";
        }

        return Comando;
    }

    public OracleCommand ConsultaBeneficiariosFallec(int iCia, string sNumSol, int inum_spto, int inum_apli, 
        int inum_spto_apli)
    {
        OracleCommand Comando = new OracleCommand();
        string strError;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                Comando.CommandText = "Ev_K_Consulta_Solicitud.p_consulta_fallec";
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Connection = conexion;

                //Declaraci�n de par�metros
                OracleParameter Param = new OracleParameter();
                Param.ParameterName = "p_cod_cia";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = iCia;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_poliza";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 13;
                Param.Direction = ParameterDirection.Input;
                Param.Value = sNumSol;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_num_spto_apli";
                Param.OracleDbType = OracleDbType.Int32;
                Param.Direction = ParameterDirection.Input;
                Param.Value = inum_spto_apli;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_total_benef";
                Param.OracleDbType = OracleDbType.Int16;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                Param = new OracleParameter();
                Param.ParameterName = "p_cadena_benef";
                Param.OracleDbType = OracleDbType.Varchar2;
                Param.Size = 2000;
                Param.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(Param);

                //Asigna Par�metros de Entrada
                Comando.Parameters["p_cod_cia"].Value = iCia;
                Comando.Parameters["p_num_poliza"].Value = sNumSol;
                Comando.Parameters["p_num_spto"].Value = inum_spto;
                Comando.Parameters["p_num_apli"].Value = inum_apli;
                Comando.Parameters["p_num_spto_apli"].Value = inum_spto_apli;

                Comando.ExecuteNonQuery();
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            strError = Error.Message + " - No se recuperaron Datos de Beneficiarios";
        }

        return Comando;
    }//ConsultaBeneficiariosFallec

    private void ConsultaRegistroA(ref OracleCommand cmd, int iCia, string sNumSol, int inum_spto, 
        int inum_apli, int inum_spto_apli)
    {
        //Declaraci�n de par�metros
        OracleParameter Param = new OracleParameter();
        Param.ParameterName = "p_cod_cia";
        Param.OracleDbType = OracleDbType.Int32;
        Param.Direction = ParameterDirection.Input;
        Param.Value = iCia;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_num_presup";
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Size = 13;
        Param.Direction = ParameterDirection.Input;
        Param.Value = sNumSol;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_num_spto";
        Param.OracleDbType = OracleDbType.Int32;
        Param.Direction = ParameterDirection.Input;
        Param.Value = inum_spto;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_num_apli";
        Param.OracleDbType = OracleDbType.Int32;
        Param.Direction = ParameterDirection.Input;
        Param.Value = inum_apli;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_num_spto_apli";
        Param.OracleDbType = OracleDbType.Int32;
        Param.Size = 1;
        Param.Direction = ParameterDirection.Input;
        Param.Value = inum_spto_apli;
        cmd.Parameters.Add(Param);

        Param = new OracleParameter();
        Param.ParameterName = "p_num_poliza";
        Param.OracleDbType = OracleDbType.Varchar2;
        Param.Size = 70;
        Param.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(Param);

    }//ConsultaRegistroA

    #endregion //Consulta de Datos

    public string ValidaRFC(string RFC)
    {
        MCommand cmd = new MCommand();
        string Retorno = "";
        DataRow objDR;
        try
        {
            using (OracleConnection Conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = Conexion;
                cmd.CommandText = "ev_k_solicitudes_web.p_valida_rfcsf_soloas";

                cmd.agregarINParametro("p_rfc", OracleDbType.Varchar2, RFC);
                cmd.agregarOUTParametro("p_valida", OracleDbType.Varchar2, 255);

                objDR = cmd.ejecutarRegistroSP();
                Retorno = objDR["p_valida"].ToString();
            }
        }
        catch (Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            Retorno = Error.Message;
        }
        return Retorno;
    }

    #region XMLPDF

    ///// <summary>
    ///// Adjunta el archivo PDF al folio RAM.
    ///// </summary>
    ///// <param name="NumPol">N�mero de p�liza.</param>
    //public void envioPDF(string NumPol)
    //{
    //    //Session["p_wf_ot_m_ot"]="1894926";
    //    //Session["FolioRAM"]="10913104000237";

    //    string strXML;
    //    string xprFile = "DictamenMedico";
    //    string rutaXpr = "xprSolicitudesTw\\";
    //    string strPath = ConfigurationSettings.AppSettings["pathlocal"];
    //    string strPathWeb = ConfigurationSettings.AppSettings["pathweb"];
    //    string strNombreArchivo = "Asegurados.pdf";
    //    xmlPDFVida objXML = new xmlPDFVida();

    //    // Obtener XML.
    //    strXML = objXML.xmlSolicitudesVida(NumPol);

    //    // Generar PDF.
    //    MapfreMMX.util.WebUtils.PDF_RUN(strXML, xprFile, rutaXpr);

    //    // Enviar a documentum
    //    clsDocumentum objClsTramite = new clsDocumentum();
    //    CArchivo objArchivo = new CArchivo();
    //    objArchivo.IDSISTEMA = int.Parse(Session["p_wf_ot_m_ot"].ToString());
    //    objArchivo.IDUSUARIO = int.Parse(MapfreMMX.util.WebUtils.getAppSetting("usuarioSeGARAM"));
    //    objArchivo.IDESTACION = 1;
    //    objArchivo.NOMBRE = strNombreArchivo;
    //    objArchivo.RUTA = strPath;
    //    objArchivo.RUTAWEB = strPathWeb;
    //    objArchivo.TIPO = int.Parse(MapfreMMX.util.WebUtils.getAppSetting("tipoArchivo"));
    //    // Almacena el archivo en BD v�a FTP 
    //    objClsTramite.guardaDoc(objArchivo);
    //    // Almacena el archivo en documentum
    //    objClsTramite.subeDocumentum(Session["FolioRAM"].ToString(), objArchivo);
    //    // Elimina el archivo del servidor local.
    //    objClsTramite.eliminaArchivoLocal(objArchivo);
    //}


    /// <summary>
    /// Sube el archivo a Documentum
    /// </summary>
    /// <param name="NumPol">Numero de Poliza</param>
    /// <param name="strFolioRAM">N�mero de Folio Ram</param>
    /// <param name="IDSistema"></param>
    /// <param name="strPath">Path de carga</param>
    /// <param name="strNombreArchivo">Nombre del archivo</param>
    /// <returns>Mensaje de exito o error de la subida de archivos</returns>
    public string SubirArchivo(string NumPol, string strFolioRAM, string strPath, string strNombreArchivo, string strSistRAM)
    {
        string strMensaje = "";
        clsDocumentum.CArchivo objArchivo = null;
        clsDocumentum objClsTramite = new clsDocumentum();
        string strPathWeb = ConfigurationSettings.AppSettings["pathweb"];

        try
        {
            //Enviar a Documentum            
            objArchivo = new clsDocumentum.CArchivo();
            //objArchivo.IDSISTEMA = this.SistemaID;
            objArchivo.IDSISTEMA = int.Parse(strSistRAM); //----> REVISAR
            objArchivo.IDUSUARIO = int.Parse(MapfreMMX.util.WebUtils.getAppSetting("usuarioSeGARAM"));
            objArchivo.IDESTACION = 1;
            objArchivo.NOMBRE = strNombreArchivo;
            objArchivo.RUTA = strPath;
            objArchivo.RUTAWEB = strPathWeb;
            objArchivo.TIPO = int.Parse(MapfreMMX.util.WebUtils.getAppSetting("tipoArchivo"));			
            //Almacena el archivo en BD v�a FTP 
            //objClsTramite.guardaDoc(objArchivo);
            //Almacena el archivo en documentum
            if (ConfigurationManager.AppSettings["MCA_DOCUMENTUM"] == "S")
                 objClsTramite.subeDocumentum(strFolioRAM, objArchivo);
            //Elimina el archivo del servidor local.
            //objClsTramite.eliminaArchivoLocal(objArchivo);

            strMensaje = "Archivo adjuntado satisfactoriamente.";
        }
        catch(Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            strMensaje = "No pudo ser adjuntado el archivo en Documentum.";
        }
        return strMensaje;
    }



    /// <summary>
    /// Sube el archivo a Documentum Dos
    /// </summary>
    /// <param name="NumPol">Numero de Poliza</param>
    /// <param name="strFolioRAM">N�mero de Folio Ram</param>
    /// <param name="IDSistema"></param>
    /// <param name="strPath">Path de carga</param>
    /// <param name="strNombreArchivo">Nombre del archivo</param>
    /// <returns>Mensaje de exito o error de la subida de archivos</returns>
    public string SubirArchivoDos(string NumPol, string strFolioRAM, string strPath, string strNombreArchivo, string strSistRAM)
    {
        string strMensaje = "";
        clsDocumentum.CArchivo objArchivo = null;
        clsDocumentum objClsTramite = new clsDocumentum();
        string strPathWeb = ConfigurationSettings.AppSettings["pathweb"];

        try
        {
            //Se renombra el archivo pues el primer SubirArchivos borra el primer archivo
            //Renombrar el archivo que se va a procesar
            strNombreArchivo = "2" + strNombreArchivo;
            File.Copy(strPath+strNombreArchivo, strPath+strNombreArchivo.Substring(1));
            File.Delete(strPath+strNombreArchivo);
            strNombreArchivo = strNombreArchivo.Substring(1);

            //Enviar a Documentum            
            objArchivo = new clsDocumentum.CArchivo();
            objArchivo.IDSISTEMA = int.Parse(strSistRAM);
            objArchivo.IDUSUARIO = int.Parse(MapfreMMX.util.WebUtils.getAppSetting("usuarioSeGARAM"));
            objArchivo.IDESTACION = 1;
            objArchivo.NOMBRE = strNombreArchivo;
            objArchivo.RUTA = strPath;
            objArchivo.RUTAWEB = strPathWeb;
            objArchivo.TIPO = int.Parse(MapfreMMX.util.WebUtils.getAppSetting("tipoArchivo"));
			//Se comenta l�nea Attribute
            //Attribute.Add("num_folio", strFolioRAM); Se comenta la l�nea error al compilar no se necesita en el metodo
            //Almacena el archivo en BD v�a FTP 
            //objClsTramite.guardaDoc(objArchivo); // Se comenta la linea ya que se detecta ambiguedad con la carga que hace. Folio IM889776
            //Almacena el archivo en documentum
            if (ConfigurationManager.AppSettings["MCA_DOCUMENTUM"] == "S")
                objClsTramite.subeDocumentum(strFolioRAM, objArchivo);
            //Elimina el archivo del servidor local.
            //objClsTramite.eliminaArchivoLocal(objArchivo);

            strMensaje = "Archivo adjuntado satisfactoriamente.";
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            strMensaje = "No pudo ser adjuntado el archivo en Documentum.";
        }
        return strMensaje;
    }
    /// <summary>
    /// Retorna el tipo de examen m�dico.
    /// </summary>
    /// <param name="CodCia">C�digo de la compa�ia.</param>
    /// <param name="CodMoneda">C�digo de la moneda.</param>
    /// <param name="TipDocum">Tipo de documento (RFC).</param>
    /// <param name="CodDocum">RFC del asegurado.</param>
    /// <param name="SumaAsegurada">Suma asegurada.</param>
    /// <param name="EdadAsegurado">Edad del asegurado.</param>
    /// <returns></returns>
    public string getTipoExamenMedico(int CodCia,
        int CodMoneda,
        string TipDocum,
        string CodDocum,
        double SumaAsegurada,
        double EdadAsegurado)
    {
        try
        {
            MCommand cmd = new MCommand();
            DataRow objDR;

            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "ev_k_solicitudes_web.p_tipo_examen_medico";

                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, CodCia);
                cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, CodMoneda);
                cmd.agregarINParametro("p_tip_docum", OracleDbType.Varchar2, TipDocum);
                cmd.agregarINParametro("p_cod_docum", OracleDbType.Varchar2, CodDocum);
                cmd.agregarINParametro("p_sa_actual", OracleDbType.Decimal, SumaAsegurada);
                cmd.agregarINParametro("p_edad_aseg", OracleDbType.Decimal, EdadAsegurado);
                cmd.agregarOUTParametro("p_tipo_examen", OracleDbType.Varchar2, 10);

                objDR = cmd.ejecutarRegistroSP();

                return objDR["p_tipo_examen"].ToString();
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            string strError = Error.Message.ToString() + " Procedimiento getTipoExamenMedico";
            Session.Add("Error", strError);
        }

        return "";
    }

    #endregion
}