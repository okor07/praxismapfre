﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for clsRuta
/// </summary>
public class clsRuta
{
    private string m_cotizacion;
    private string m_directorio;
    private string m_nombreArchivo;
    private string m_permiteRecibo;
    private string m_poliza;
    private string m_tipoDocum;
    private string m_ruta;
    private string m_recibo;
    private string m_sector;
    private string m_periodo;
    private string m_endoso;


    private Boolean m_solicitaRecibo;

    public string cotizacion
    {
        set { m_cotizacion = value; }
    }

    public string permiteRecibo
    {
        set { m_permiteRecibo = value; }
    }

    public string poliza
    {
        set { m_poliza = value; }
    }

    public string tipoDocum
    {
        set { m_tipoDocum = value; }
    }

    public string ruta
    {
        get { return m_ruta; }
    }

    public string recibo
    {
        get { return m_recibo; }
    }

    public string directorio
    {
        get { return m_directorio; }
    }

    public string nombreArchivo
    {
        get { return m_nombreArchivo; }
    }

    public string sector
    {
        set { m_sector = value; }
    }

    public bool solicitaRecibo
    {
        set { m_solicitaRecibo = value; }
    }

    public string periodo
    {
        set { m_periodo = value; }
    }

    public string endoso
    {
        set { m_endoso = value; }
    }

    public void getRuta()
    {
        string ruta = "";
        string nombreArchivo = "";
        m_recibo = "";
        switch (m_tipoDocum)
        {
            case "C":
                nombreArchivo = m_cotizacion;
                ruta = "RutaCotizacionArchivo";
                break;
            case "P":
                if (m_solicitaRecibo == false && m_permiteRecibo == "True")
                {
                    m_recibo = "SR";
                }
                nombreArchivo = m_recibo + m_poliza;
                ruta = "RutaPolizaArchivo";
                break;
            case "R":
                nombreArchivo = m_poliza;
                ruta = "RutaCartaRenov";
                break;
            case "S":
                nombreArchivo = m_poliza;
                ruta = "RutaSolicitudArchivo";
                break;
            case "E":
                nombreArchivo = m_poliza + "-0-" + DateTime.Today.Year.ToString() + "-" + m_periodo;
                ruta = "RutaPolizaArchivo";
                m_recibo = "EC";
                break;
            case "B":
                nombreArchivo = "Bono_" + m_poliza + "-0-" + DateTime.Today.AddYears(-1).Year.ToString();
                ruta = "RutaPolizaArchivo";
                m_recibo = "EC";
                break;
        }
        m_ruta = MapfreMMX.util.WebUtils.getAppSetting(ruta + m_sector) + nombreArchivo + m_endoso + ".pdf";
        // Variables para documentum 
        m_directorio = MapfreMMX.util.WebUtils.getAppSetting(ruta + m_sector);
        if (m_tipoDocum == "S")
        {
            if (m_sector == "1")
                nombreArchivo = "solicituduno" + nombreArchivo;
            else
                nombreArchivo = "Solicitud" + nombreArchivo;
        }
        m_nombreArchivo = nombreArchivo + m_endoso + ".pdf";

    }
}