﻿//'********************************************************************************************************************
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2010
//'Name of the file              : clsDocumentum.cs
//'Creation/Modification History : jchuertas 30-12-2012 - Indra SWLabs
//'Modification                  : 
//                               
//'********************************************************************************************************************

using Ajax;
using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Text;
using System.Collections;
using Oracle.DataAccess.Client;
using MapfreMMX.oracle;
using System.IO;

/// <summary>
/// Clase que contiene los datos para generar el reporte. Y metodos para el tratamiento
/// de los mismos y la generación del reporte.
/// </summary>
public class ImpresionReportes : Page
{
    //Prellenada o no
    public static string prellenado;
    
    //Datos del contratante
    public static string Poliza ;
    public static int Sector ;
    public static string usuario ;
    public static string rfcC;
    public static string curpC ;
    public static string nombreC ;
    public static string apellidoMC ;
    public static string apellidoPC ;
    public static string calleNoContratante ;
    public static string coloniaContratante ;
    public static string cpContratante ;
    public static string estadoContratante ;
    public static string poblacionContratante ;
    public static string telefonoContratante ;
    public static string correoContratante ;
    public static string folio;
    
    //Datos del asegurado    
    public static string rfcA ;
    public static string curpA ;
    public static int sexoA ;
    public static int Fuma ;
    public static string nombreA ;
    public static string apellidoMA ;
    public static string apellidoPA ;
    public static string fechaNacA ;
    public static string estadoCivilA ;
    public static string calleNoA ;
    public static string coloniaA ;
    public static string cpA ;
    public static string estadoA ;
    public static string poblacionA ;
    public static string telefonoA ;
    public static string correoA ;
    
    //Datos relacion
    public static string nacionalidad;
    public static string Ocupacion;
    public static string RamoDesc;
    public static string Peso ;
    public static string Estatura ;
    public static string Edad ;

    //Datos Póliza
    public static string formaPago ;
    public static string tipoPago;
    public static string agente ;
    public static string crecimiento;

    //Beneficiarios
    public static DataTable beneficiarios;

    //Coberturas
    public static string monedaPago;
    public static string Plazo;
    public static string ramoPlan;
    public static string basica;
    public static string accidentes;
    public static string bit;
    public static string bipa;
    public static string enfermedadesG;
    public static string servFun;

    //Cuestionario
    public static string deporsi;
    public static string deporno;
    public static DataTable cuestionario;

    public ImpresionReportes()
    {
        //
        // Constructor
        //
    }


    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void generaDatosContratantes(string poliza, string rfcCo, string curpCo, string nombreCo, string apellidoMCo,
                                        string apellidoPCo, string calleNoCo, string coloniaCo, string cpCo,
                                        string estadoCo, string poblacionCo, string telefonoCo, string correoCo,
                                        string rfcAs, string curpAs, int sexoAs, int FumaAs, string nombreAs, string apellidoMAs,
                                        string apellidoPAs, string fechaNacAs, string estadoCAs, string calleNoAs,
                                        string coloniaAs, string cpAs, string estadoAs, string poblacionAs, string telefonoAs,
                                        string correoAs, string nacionalidadR, int FumaR, string OcupacionR, string RamoDescR,
                                        string PlazoR, string PesoR, string EstaturaR, string EdadR, string agenteP,
                                        string formaPagoP, string tablaBenef, string moneda, string plan, string coberturas, 
                                        string deporteSi, string deporteNo, string preguntas, string Folio, string solicitudPrellenada,
                                        string tipoPagoP, string crecimientoP)
    {
        string[] cobertura;
        string[] datosCobertura;
        try
        {
            prellenado = solicitudPrellenada;
            Poliza = poliza;
            folio = Folio;
            //Contratante
            rfcC = rfcCo;
            curpC = curpCo;
            nombreC = nombreCo;
            apellidoMC = apellidoMCo;
            apellidoPC = apellidoPCo;
            calleNoContratante = calleNoCo;
            coloniaContratante = coloniaCo;
            cpContratante = cpCo;
            estadoContratante = estadoCo;
            poblacionContratante = poblacionCo;
            telefonoContratante = telefonoCo;
            correoContratante = correoCo;

            //Asegurado
            rfcA = rfcAs;
            curpA = curpAs;
            sexoA = sexoAs;
            Fuma = FumaAs;
            nombreA = nombreAs;
            apellidoMA = apellidoMAs;
            apellidoPA = apellidoPAs;
            fechaNacA = fechaNacAs;
            estadoCivilA = estadoCAs;
            calleNoA = calleNoAs;
            coloniaA = coloniaAs;
            cpA = cpAs;
            estadoA = estadoAs;
            poblacionA = poblacionAs;
            telefonoA = telefonoAs;
            correoA = correoAs;

            //datos de Relacion
            nacionalidad = nacionalidadR;
            Fuma = FumaR;
            Ocupacion = OcupacionR;
            RamoDesc = RamoDescR;
            Plazo = PlazoR;
            Peso = PesoR;
            Estatura = EstaturaR;
            Edad = EdadR;
            agente = agenteP;
            formaPago = formaPagoP;
            tipoPago = tipoPagoP;
            crecimiento = crecimientoP;
            
            //Datos de los beneficiarios
            beneficiarios = convertirBeneficiariosDatatable(tablaBenef);

            //Coberturas
            monedaPago = moneda;
            ramoPlan = plan;
            cobertura = coberturas.Split(',');
            
            for (int i = 0; i < cobertura.Length; i++)
            {
                datosCobertura = cobertura[i].Split('-');
                switch (datosCobertura[0])
                { 
                    case "1000":
                        basica = datosCobertura[1].ToString();
                        break;
                    case "1003":
                        enfermedadesG = datosCobertura[1].ToString();
                        break;
                    case "1004":
                        accidentes = datosCobertura[1].ToString();
                        break;
                    case "1005":
                        accidentes = datosCobertura[1].ToString();
                        break;
                    case "1006":
                        accidentes = datosCobertura[1].ToString();
                        break;
                    case "1007":
                        accidentes = datosCobertura[1].ToString();
                        break;
                    case "1008":
                        accidentes = datosCobertura[1].ToString();
                        break;
                    case "1009":
                        accidentes = datosCobertura[1].ToString();
                        break;
                    case "1019":
                        servFun = datosCobertura[1].ToString();
                        break;
                    case "1095":
                        bit = datosCobertura[1].ToString();
                        break;
                    case "1096":
                        bipa = datosCobertura[1].ToString();
                        break;
                }
            }

            deporsi = deporteSi;
            deporno = deporteNo;
            cuestionario = convertirCuestionarioDatatable(preguntas);

        }

        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR ImpresionReportes.generaDatosContratantes(): " + ex.Message);
        }
    }

    /// <summary>
    /// Convierte la cadena de beneficiarios en un Datatable
    /// </summary>
    /// <param name="cadena">Cadena de Beneficiarios separadas por | (pipe) </param>
    /// <returns>Datatable de Beneficiarios</returns>
    public DataTable convertirBeneficiariosDatatable(string cadena)
    {
        DataTable tabla = new DataTable("tabla");
        DataRow movRow  = null;

        try
        {
            tabla.Columns.Add("Nombre", typeof(string));
            tabla.Columns.Add("Parentesco", typeof(string));
            tabla.Columns.Add("Porcentaje", typeof(string));

            string[] fila;
            fila = cadena.Split('|');

            for (int i = 0; i < fila.Length - 1; i++)
            {
                string[] columna;
                columna = fila[i].Split('-');

                movRow = tabla.NewRow();
                movRow[0] = columna[0];
                movRow[1] = columna[1];
                movRow[2] = columna[2];

                tabla.Rows.Add(movRow);
            }
            return tabla;  

        }

        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR ImpresionReportes.convertirBeneficiariosDatatable(): " + ex.Message);
        }
    }

    /// <summary>
    /// Convierte la cadena del cuestionario en un Datatable
    /// </summary>
    /// <param name="cadena">Cadena con la información del cuestionario, 
    /// las preguntas separadas por | (pipe) y las columnas por @ (arroba)</param>
    /// <returns>Datatable de Cuestionario</returns>
    public DataTable convertirCuestionarioDatatable(string cadena)
    {
        DataTable tabla = new DataTable("tabla");
        DataRow movRow = null;

        try
        {
            tabla.Columns.Add("Numero", typeof(string));
            tabla.Columns.Add("Pregunta", typeof(string));
            tabla.Columns.Add("Si", typeof(string));
            tabla.Columns.Add("No", typeof(string));

            string[] fila;
            fila = cadena.Split('|');

            for (int i = 0; i < fila.Length - 1; i++)
            {
                string[] columna;
                columna = fila[i].Split('@');

                movRow = tabla.NewRow();
                movRow[0] = columna[0];
                movRow[1] = columna[1];
                movRow[2] = columna[2];
                movRow[3] = columna[3];

                tabla.Rows.Add(movRow);
            }
            return tabla;

        }

        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR ImpresionReportes.convertirCuestionarioDatatable(): " + ex.Message);
        }
    }
}
