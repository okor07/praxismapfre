//'********************************************************************************************************************
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2010
//'Name of the file              : Emision.cs
//'Creation/Modification History :
//'Modification                  : 
//                               
//C1                             : MU-2017-041348  "MX_NC_IMPLEM PROD ZA BASE EVENT"
//Fecha                          : 14-09-2017
//Autor                          : HHAC
//Descripci�n                    : Se agrega registro de eventos por producto
//03052018  
//'********************************************************************************************************************

using System;
using System.Text;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Oracle.DataAccess.Client;
using MapfreMMX.emision;
using MapfreMMX.oracle;
using MapfreMMX.util;
using MapfreMMX.emision.tabla;
using System.Net;

/// <summary>
/// Summary description for Emision
/// </summary>
public class Emision : Page
{
    private bool checkSF = false;
    private string m_accion;
    public string token;

    public Emision(string accion)
    {
        m_accion = accion;
    }

    public DataRow setCotizacion(String[] DATOS_POLIZA, String[] DATOS_VARIABLES, String[] BENEFICIARIOS, String[] COBERTURAS, String[] DATOS_ASEGURADOS, String[] DATOS_FUNERARIOS, String[] DATOS_MANCOMUNADO, OracleConnection conexion)
    {
        Hashtable hashDATOS_POLIZA = new Hashtable();
        ArrayList arrDATOS_VARIABLES = new ArrayList();
        ArrayList arrDATOS_BENEFICIARIOS = new ArrayList();
        ArrayList arrDATOS_COBERTURAS = new ArrayList();
        ArrayList arrDATOS_ACCESORIOS = new ArrayList();
        ArrayList arrDATOS_ASEGURADOS = new ArrayList();
        ArrayList arrDATOS_FUNERARIOS = new ArrayList();
        ArrayList arrDATOS_MANCOMUNADO = new ArrayList();
        Hashtable hashCOBERTURA;
        Hashtable hashBENEFICIARIO;
        Hashtable hashVARIABLES = new Hashtable();
        Hashtable hashASEGURADO;
        Hashtable hashFUNERARIO;
        Hashtable hashMANCOMUNADO;
        String[] arrAUX;
        String[] arrVAL_AUX;
        ArrayList arrPOR_ASEGURADO = new ArrayList();

        try
        {
            foreach (string DATO in DATOS_POLIZA)
            {
                arrAUX = DATO.Split('=');
                hashDATOS_POLIZA.Add(arrAUX[0], arrAUX[1]);
            }

            for (int index = 0; index <= Convert.ToInt32(hashDATOS_POLIZA["NUM_RIESGOS"]); index++)
            {
                arrPOR_ASEGURADO = new ArrayList();
                foreach (string DATO in DATOS_VARIABLES)
                {
                    hashVARIABLES = new Hashtable();
                    arrVAL_AUX = DATO.Split('|');
                    foreach (string DATO_VAR in arrVAL_AUX)
                    {
                        arrAUX = DATO_VAR.Split('=');
                        hashVARIABLES.Add(arrAUX[0], arrAUX[1]);
                    }
                    if (Convert.ToInt32(hashVARIABLES["NUM_RIESGO"]) == index)
                        arrPOR_ASEGURADO.Add(hashVARIABLES);
                }
                if (arrPOR_ASEGURADO.Count != 0)
                    arrDATOS_VARIABLES.Add(arrPOR_ASEGURADO);

            }

            for (int index = 0; index <= Convert.ToInt32(hashDATOS_POLIZA["NUM_RIESGOS"]); index++)
            {
                if (BENEFICIARIOS != null)
                {
                    arrPOR_ASEGURADO = new ArrayList();
                    foreach (string DATO in BENEFICIARIOS)
                    {
                        hashBENEFICIARIO = new Hashtable();
                        arrVAL_AUX = DATO.Split('|');
                        foreach (string DATOS_BEN in arrVAL_AUX)
                        {
                            arrAUX = DATOS_BEN.Split('=');
                            hashBENEFICIARIO.Add(arrAUX[0], arrAUX[1]);
                        }
                        if (Convert.ToInt32(hashBENEFICIARIO["NUM_RIESGO"]) == index)
                            arrPOR_ASEGURADO.Add(hashBENEFICIARIO);
                    }
                    if (arrPOR_ASEGURADO.Count != 0)
                        arrDATOS_BENEFICIARIOS.Add(arrPOR_ASEGURADO);
                }
            }

            for (int index = 0; index <= Convert.ToInt32(hashDATOS_POLIZA["NUM_RIESGOS"]); index++)
            {
                if (COBERTURAS != null)
                {
                    arrPOR_ASEGURADO = new ArrayList();
                    foreach (string DATO in COBERTURAS)
                    {
                        hashCOBERTURA = new Hashtable();
                        arrVAL_AUX = DATO.Split('|');
                        foreach (string DATOS_COB in arrVAL_AUX)
                        {
                            arrAUX = DATOS_COB.Split('=');
                            hashCOBERTURA.Add(arrAUX[0], arrAUX[1]);
                        }
                        if (Convert.ToInt32(hashCOBERTURA["NUM_RIESGO"]) == index)
                            arrPOR_ASEGURADO.Add(hashCOBERTURA);
                    }
                    if (arrPOR_ASEGURADO.Count != 0)
                        arrDATOS_COBERTURAS.Add(arrPOR_ASEGURADO);
                }
            }

            foreach (string DATO in DATOS_ASEGURADOS)
            {
                hashASEGURADO = new Hashtable();
                arrVAL_AUX = DATO.Split('|');
                foreach (string DATO_VAR in arrVAL_AUX)
                {
                    arrAUX = DATO_VAR.Split('=');
                    hashASEGURADO.Add(arrAUX[0], arrAUX[1]);
                }
                arrDATOS_ASEGURADOS.Add(hashASEGURADO);
            }

            foreach (string DATO in DATOS_FUNERARIOS)
            {
                hashFUNERARIO = new Hashtable();
                arrVAL_AUX = DATO.Split('|');
                foreach (string DATO_VAR in arrVAL_AUX)
                {
                    arrAUX = DATO_VAR.Split('=');
                    hashFUNERARIO.Add(arrAUX[0], arrAUX[1]);
                }
                arrDATOS_FUNERARIOS.Add(hashFUNERARIO);
            }

            foreach (string DATO in DATOS_MANCOMUNADO)
            {
                hashMANCOMUNADO = new Hashtable();
                arrVAL_AUX = DATO.Split('|');
                foreach (string DATO_VAR in arrVAL_AUX)
                {
                    arrAUX = DATO_VAR.Split('=');
                    hashMANCOMUNADO.Add(arrAUX[0], arrAUX[1]);
                }
                arrDATOS_MANCOMUNADO.Add(hashMANCOMUNADO);
            }

            return setCotizacion(hashDATOS_POLIZA, arrDATOS_VARIABLES, arrDATOS_BENEFICIARIOS, arrDATOS_COBERTURAS, arrDATOS_ASEGURADOS, arrDATOS_FUNERARIOS, arrDATOS_MANCOMUNADO, conexion);

        }
        catch (Exception ex)
        {
            throw new Exception("ERROR Cotizacion.setCotizacionEmision(1) : " + ex.Message);
        }
    }

    public DataRow setCotizacion(Hashtable DATOS_POLIZA, ArrayList DATOS_VARIABLES, ArrayList DATOS_BENEFICIARIOS, ArrayList DATOS_COBERTURAS, ArrayList ASEGURADOS, ArrayList FUNERARIOS, ArrayList MANCOMUNADO, OracleConnection conexion)
    {
        int ROW_NUM;
        StringBuilder objXML = new StringBuilder();
        Hashtable DATOS_AUX = new Hashtable();
        P2000030 objP2000030 = new P2000030(); // esta tabla se adaptó para el Cotizador Superación (clase propia)
        P2000031 objP2000031 = new P2000031();
        MapfreMMX.emision.tabla.P2000020 objP2000020 = new MapfreMMX.emision.tabla.P2000020();
        P2000060 objP2000060 = new P2000060();
        P2000040 objP2000040 = new P2000040();
        P2300060 objP2300060_MMX = new P2300060();

        try
        {
            objXML.Append("<XML ACCION=\"C\" COD_RAMO=\"");
            objXML.Append(DATOS_POLIZA["COD_RAMO"]);
            objXML.Append("\" NUM_POLIZA=\"\" COD_ORIGEN=\"");
            objXML.Append(WebUtils.getAppSetting("codOrigen"));
            objXML.Append("\">");

            DATOS_POLIZA.Add("COD_USR", WebUtils.getAppSetting("codUsuario"));


            ROW_NUM = 1;
            objP2000030.setDatos(DATOS_POLIZA);
            objXML.Append("<TABLE NAME=\"P2000030\"><ROWSET>");
            objXML.Append(objP2000030.getXML(ROW_NUM));
            objXML.Append("</ROWSET></TABLE>");
            ROW_NUM = 1;

            objXML.Append("<TABLE NAME=\"P2000031\"><ROWSET>");
            foreach (Hashtable hashDATO in MANCOMUNADO)
            {
                DATOS_AUX = new Hashtable();
                DATOS_AUX.Add("NOM_RIESGO", hashDATO["NOMBRE"]);
                DATOS_AUX.Add("NUM_RIESGO", hashDATO["NUM_RIESGO"]);
                DATOS_AUX.Add("COD_MODALIDAD", hashDATO["COD_MODALIDAD"]);
                DATOS_AUX.Add("FEC_EFEC_RIESGO", hashDATO["FEC_EFEC_RIESGO"]);
                DATOS_AUX.Add("FEC_VCTO_RIESGO", hashDATO["FEC_VCTO_RIESGO"]);
                objP2000031.setDatos(DATOS_AUX);
                objXML.Append(objP2000031.getXML(ROW_NUM));
                ROW_NUM++;
            }
            objXML.Append("</ROWSET></TABLE>");



            /* Las Tablas P2000020 y P2000040 se repiten por asegurado para
             * desminuir la longitud de la cadena XML ya que esta se hace
             * muy extensa al aunmentar el número de asegurados.
             * El metodo que manda llamar a este, es el que realiza el 
             * ordenamiento por tabla.
             */

            // TABLA P2000020 por asegurado
            foreach (ArrayList VARIABLES in DATOS_VARIABLES)
            {
                // TABLA P2000020
                ROW_NUM = 1;
                objXML.Append("<TABLE NAME=\"P2000020\"><ROWSET>");
                foreach (Hashtable hashDATO in VARIABLES)
                {
                    DATOS_AUX = (Hashtable)(hashDATO.Clone());
                    if (DATOS_AUX["COD_CAMPO"].ToString().IndexOf("FEC_NACIMIENTO") > -1)
                    {
                        DATOS_AUX["VAL_CAMPO"] = DATOS_AUX["VAL_CAMPO"].ToString().Replace("/", "");
                    }
                    if (DATOS_AUX["COD_CAMPO"].ToString().IndexOf("MCA_FUMA") > -1)
                    {
                        DATOS_AUX["COD_CAMPO"] = "MCA_FUMAR";
                    }
                    if (DATOS_AUX["VAL_CAMPO"] != null)
                    {
                        if (DATOS_AUX["VAL_CAMPO"].ToString().Length > 10)
                        {
                            DATOS_AUX.Add("VAL_COR_CAMPO", DATOS_AUX["VAL_CAMPO"].ToString().Substring(0, 10));
                        }
                        else
                        {
                            DATOS_AUX.Add("VAL_COR_CAMPO", DATOS_AUX["VAL_CAMPO"]);
                        }
                    }
                    DATOS_AUX.Add("COD_RAMO", DATOS_POLIZA["COD_RAMO"]);
                    if (DATOS_AUX["FEC_NACIMIENTO"] != null)
                    {
                        DATOS_AUX["VAL_CAMPO"] = DATOS_AUX["VAL_CAMPO"];
                    }

                    objP2000020.setDatos(DATOS_AUX);
                    objXML.Append(objP2000020.getXML(ROW_NUM));
                    ROW_NUM++;

                }
                objXML.Append("</ROWSET></TABLE>");
            }

            // TABLA P2000060 por asegurado
            foreach (ArrayList BENEFICIARIOS in DATOS_BENEFICIARIOS)
            {
                // TABLA P2000060
                ROW_NUM = 1;
                objXML.Append("<TABLE NAME=\"P2000060\"><ROWSET>");
                foreach (Hashtable hashBENEFICIARIO in BENEFICIARIOS)
                {
                    DATOS_AUX = (Hashtable)(hashBENEFICIARIO.Clone());
                    objP2000060.setDatos(DATOS_AUX);
                    objXML.Append(objP2000060.getXML(ROW_NUM));
                    ROW_NUM++;
                }
                objXML.Append("</ROWSET></TABLE>");
            }


            // TABLA P2000040 por asegurado
            foreach (ArrayList COBERTURAS in DATOS_COBERTURAS)
            {
                // TABLA P2000040
                ROW_NUM = 1;
                objXML.Append("<TABLE NAME=\"P2000040\"><ROWSET>");
                foreach (Hashtable hashCOBERTURA in COBERTURAS)
                {
                    DATOS_AUX = (Hashtable)(hashCOBERTURA.Clone());
                    //DATOS_AUX.Add("COD_RAMO", DATOS_POLIZA["COD_RAMO"]);
                    //DATOS_AUX.Add("SUMA_ASEG_SPTO", DATOS_AUX["SUMA_ASEG"]);
                    objP2000040.setDatos(DATOS_AUX);
                    objXML.Append(objP2000040.getXML(ROW_NUM));
                    ROW_NUM++;
                }
                objXML.Append("</ROWSET></TABLE>");
            }


            // TABLA P2300060_MMX
            if (ASEGURADOS.Count > 0)
            {
                ROW_NUM = 1;
                objXML.Append("<TABLE NAME=\"P2300060_MMX\"><ROWSET>");
                foreach (Hashtable hashDATO in ASEGURADOS)
                {
                    DATOS_AUX = (Hashtable)(hashDATO.Clone());
                    objP2300060_MMX.setDatos(DATOS_AUX);
                    objXML.Append(objP2300060_MMX.getXML(ROW_NUM));
                    ROW_NUM++;
                }

                foreach (Hashtable hashDATO in FUNERARIOS)
                {
                    DATOS_AUX = (Hashtable)(hashDATO.Clone());
                    objP2300060_MMX.setDatos(DATOS_AUX);
                    objXML.Append(objP2300060_MMX.getXML(ROW_NUM));
                    ROW_NUM++;
                }
                objXML.Append("</ROWSET></TABLE>");
            }

            objXML.Append("</XML>");
            string XML;
            XML = objXML.ToString();

            CDEmision objCotiza = new CDEmision();
            return objCotiza.setCotizacionEmision(XML, conexion);
        }
        catch (Exception ex)
        {
            throw new Exception("ERROR Cotizacion.setCotizacionEmision(2) : " + ex.Message);
        }
    }



    /// <summary>M�todo para realizar la Cotizaci�n y obtener los calculos de primas.
    /// <para>Este llama a su vez al m�todo <b>setEmision</b>.</para>
    /// </summary>
    public DataSet getCotizacion(String[] arrDatosPoliza, String[] arrDatosVar, String[] arrDatosCob, String[] arrDatosCont, String[] arrDatosSol, String[] arrDatosBenef, String[] arrDatosBanco)
    {
        CDEmision objCotizaCalculo = new CDEmision();
        DataRow drCotizacion;
        DataSet objDS;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                drCotizacion = setEmision(arrDatosPoliza, arrDatosVar, arrDatosCob, arrDatosCont, arrDatosSol, arrDatosBenef, arrDatosBanco, conexion);
                if (drCotizacion[0] != System.DBNull.Value)
                {
                    objDS = objCotizaCalculo.getCalculos(drCotizacion[0].ToString(), conexion);
                    Session["PRIMAS"] = objDS.Tables[0].Rows[0]["PRIMAS"].ToString();
                    Session.Add("numCotizacion", drCotizacion[0].ToString());
                    DataTable objTabla = new DataTable();
                    objTabla.Columns.Add("COTIZACION");
                    DataRow objRow = objTabla.NewRow();
                    objRow["COTIZACION"] = drCotizacion[0].ToString();
                    objTabla.Rows.Add(objRow);
                    objDS.Tables.Add(objTabla);
                    try
                    {
                        int ramo = 0;
                        try
                        {
                            ramo = Convert.ToInt32(System.Web.HttpContext.Current.Session["RAMO"]);
                        }
                        catch
                        {
                            ramo = 0;
                        }
                        if (ramo == 105)
                        {
                            double primatot = 0;
                            int x1;
                            int nc = objDS.Tables[0].Rows.Count;

                            for (x1 = 0; x1 <= nc - 1; x1++)
                            {
                                if (Convert.ToInt32(objDS.Tables[0].Rows[x1]["COD_COB"]) == 1000 || Convert.ToInt32(objDS.Tables[0].Rows[x1]["COD_COB"]) == 1014)
                                {
                                    primatot = primatot + Convert.ToDouble(objDS.Tables[0].Rows[x1]["PRIMAS"]);
                                }
                            }

                            Session["primatot"] = primatot;
                        }

                    }
                    catch
                    {

                    }
                }
                else throw new Exception(drCotizacion[1].ToString());
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            string strMensaje = "";
            try
            {
                using (OracleConnection conexion = MConexion.getConexion("ConnectionSeGATEMP"))
                    strMensaje = ExceptionUtil.TWDescripcion(ex.Message, "TRONWEB", conexion);
            }
            catch
            {
                strMensaje = ex.Message;
            }
            throw new Exception(strMensaje);
        }

        /*~~~~~~~~~~~~~~~~~~~~~~EVENTO~~~~~~~~~~~~~~~~~~~~~~~~*/
        try
        {
            Usuario objUsuario = (Usuario)(Session["sUSUARIO"]);
            //int evento = Convert.ToInt32(WebUtils.getAppSetting("EventoCotizacion"));
            int agente = Convert.ToInt32(arrDatosPoliza[2].Split('=')[1]);
            String tip_plan = (String)Session["TipoPLan"];
            using (OracleConnection conexion = MConexion.getConexion("ConnectionSeGA"))
            {
                switch (tip_plan)
                {
                    case "1":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip1_Cot"].ToString()), drCotizacion[0].ToString(), "", agente, false, conexion);
                        break;
                    case "2":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip2_Cot"].ToString()), drCotizacion[0].ToString(), "", agente, false, conexion);
                        break;
                    case "3":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip3_Cot"].ToString()), drCotizacion[0].ToString(), "", agente, false, conexion);
                        break;
                    case "4":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip4_Cot"].ToString()), drCotizacion[0].ToString(), "", agente, false, conexion);
                        break;
                    case "5":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip5_Cot"].ToString()), drCotizacion[0].ToString(), "", agente, false, conexion);
                        break;
                    case "7":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip7_Cot"].ToString()), drCotizacion[0].ToString(), "", agente, false, conexion);
                        break;
                    case "8":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip8_Cot"].ToString()), drCotizacion[0].ToString(), "", agente, false, conexion);
                        break;
                    case "9":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip9_Cot"].ToString()), drCotizacion[0].ToString(), "", agente, false, conexion);
                        break;
                    case "10":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip10_Cot"].ToString()), drCotizacion[0].ToString(), "", agente, false, conexion);
                        break;
                    case "11":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip11_Cot"].ToString()), drCotizacion[0].ToString(), "", agente, false, conexion);
                        break;
                    case "12":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip12_Cot"].ToString()), drCotizacion[0].ToString(), "", agente, false, conexion);
                        break;
                    case "13":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip13_Cot"].ToString()), drCotizacion[0].ToString(), "", agente, false, conexion);
                        break;
                    case "14":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip14_Cot"].ToString()), drCotizacion[0].ToString(), "", agente, false, conexion);
                        break;
                    case "15":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip15_Cot"].ToString()), drCotizacion[0].ToString(), "", agente, false, conexion);
                        break;
                }
                //EventoUtil.registraEvento(objUsuario.USUARIO, 1, evento, drCotizacion[0].ToString(), "", agente, false, conexion);
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
        }
        /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
        return objDS;
    }

    public string getCotizacionFirma(String[] arrDatosPoliza, String[] arrDatosVar, String[] arrDatosCob, String[] arrDatosCont, String[] arrDatosSol, String[] arrDatosBenef, String[] arrDatosBanco)
    {
        CDEmision objCotizaCalculo = new CDEmision();
        string drCotizacion;
        DataSet objDS;
        try
        {
            drCotizacion = setEmisionFirma(arrDatosPoliza, arrDatosVar, arrDatosCob, arrDatosCont, arrDatosSol, arrDatosBenef, arrDatosBanco);

        }
        catch (Exception ex)
        {
            throw;
        }

        /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
        return drCotizacion;
    }

    /// <summary>M�todo para construirXMLEmision
    /// <para>Este llama a su vez al m�todo <b>setEmision</b>.</para>
    /// </summary>
    public string getXmlEmision(String[] arrDatosPoliza, String[] arrDatosVar, String[] arrDatosCob, String[] arrDatosCont, String[] arrDatosSol, String[] arrDatosBenef, String[] arrDatosBanco)
    {
        string drEmision;
        drEmision = setEmisionFirma(arrDatosPoliza, arrDatosVar, arrDatosCob, arrDatosCont, arrDatosSol, arrDatosBenef, arrDatosBanco);
        return drEmision;
    }

    /// <summary>M�todo para realizar la Emisi�n.
    /// <para>Este llama a su vez al m�todo <b>setEmision</b>.</para>
    /// </summary>
    public string getEmision(String[] arrDatosPoliza, String[] arrDatosVar, String[] arrDatosCob, String[] arrDatosCont, String[] arrDatosSol, String[] arrDatosBenef, String[] arrDatosBanco)
    {
        CDEmision objCotizaCalculo = new CDEmision();
        DataRow drEmision;
        string resultado;
        Usuario objUsuario = (Usuario)(Session["sUSUARIO"]);
        var isGenera = ConfigurationManager.AppSettings["GeneraTrazabilidad"];
        string ipHost = Dns.GetHostByName(Dns.GetHostName()).AddressList[1].ToString();
        Session.Remove("arrBenef");
        try
        {


            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                drEmision = setEmision(arrDatosPoliza, arrDatosVar, arrDatosCob, arrDatosCont, arrDatosSol, arrDatosBenef, arrDatosBanco, conexion);

                if (drEmision[0] != System.DBNull.Value)
                {
                    resultado = drEmision[0].ToString();
                    if(isGenera == "1")
                        Trazabilidad.OperacionesRelevantes.getInstance().RegistraOperacionRelevante(objUsuario.USUARIO, objUsuario.TIPO_USUARIO, "Emisión", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"), ipHost, "Emisión GeneralVida: " + drEmision[0].ToString());

                    if (Session["arrBenef"] != null)
                        setBenef(resultado, ((ArrayList)Session["arrBenef"]), conexion);
                }
                else
                {
                    resultado = "No se pudo realizar la Emisi�n de su P�liza " + drEmision[1].ToString();
                    throw new Exception(resultado);
                }
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            string strMensaje = "";
            try
            {
                using (OracleConnection conexion = MConexion.getConexion("ConnectionSeGATEMP"))
                    strMensaje = ExceptionUtil.TWDescripcion(ex.Message, "TRONWEB", conexion);
            }
            catch
            {
                strMensaje = ex.Message;
            }
            throw new Exception(strMensaje);
        }

        /*~~~~~~~~~~~~~~~~~~~~~~EVENTO~~~~~~~~~~~~~~~~~~~~~~~~*/
        try
        {

            string ramo = resultado.Substring(0, 3);
            //       int evento = Convert.ToInt32(WebUtils.getAppSetting("EventoEmision" + ramo));
            int agente = Convert.ToInt32(arrDatosPoliza[2].Split('=')[1]);
            String tip_plan = (String)Session["TipoPLan"];
            using (OracleConnection conexionTEMP = MConexion.getConexion("ConnectionSeGA"))
            {
                switch (tip_plan) {
                    case "1":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip1_Emi"].ToString()), resultado, "", agente, false, conexionTEMP);
                        break;
                    case "2":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip2_Emi"].ToString()), resultado, "", agente, false, conexionTEMP);
                        break;
                    case "3":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip3_Emi"].ToString()), resultado, "", agente, false, conexionTEMP);
                        break;
                    case "4":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip4_Emi"].ToString()), resultado, "", agente, false, conexionTEMP);
                        break;
                    case "5":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip5_Emi"].ToString()), resultado, "", agente, false, conexionTEMP);
                        break;
                    case "7":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip7_Emi"].ToString()), resultado, "", agente, false, conexionTEMP);
                        break;
                    case "8":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip8_Emi"].ToString()), resultado, "", agente, false, conexionTEMP);
                        break;
                    case "9":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip9_Emi"].ToString()), resultado, "", agente, false, conexionTEMP);
                        break;
                    case "10":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip10_Emi"].ToString()), resultado, "", agente, false, conexionTEMP);
                        break;
                    case "11":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip11_Emi"].ToString()), resultado, "", agente, false, conexionTEMP);
                        break;
                    case "12":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip12_Emi"].ToString()), resultado, "", agente, false, conexionTEMP);
                        break;
                    case "13":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip13_Emi"].ToString()), resultado, "", agente, false, conexionTEMP);
                        break;
                    case "14":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip14_Emi"].ToString()), resultado, "", agente, false, conexionTEMP);
                        break;
                    case "15":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoTip15_Emi"].ToString()), resultado, "", agente, false, conexionTEMP);
                        break;
                }
                //EventoUtil.registraEvento(objUsuario.USUARIO, 1, evento, resultado, "", objUsuario.COD_AGENTE, false, conexionTEMP);
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
        }
        /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
        return resultado;
    }

    /// <summary>M�todo para la creaci�n del XML emision
    /// <para>Este llama a su vez al m�todo <b>setEmisionFirma</b>.</para>
    /// </summary>
    public string setEmisionFirma(String[] DATOS_POLIZA, String[] DATOS_VARIABLES, String[] DATOS_COBERTURA, String[] DATOS_CONT, String[] DATOS_SOL, String[] DATOS_BENEF, String[] DATOS_BANCO)
    {
        ArrayList arrDATOS_VARIABLES = new ArrayList();
        ArrayList arrDATOS_COBERTURA = new ArrayList();
        ArrayList arrDATOS_BENEF = new ArrayList();
        Hashtable hashDATOS_POLIZA = new Hashtable();
        Hashtable hashDATOS_CONT = new Hashtable();
        Hashtable hashDATOS_SOL = new Hashtable();
        Hashtable hashDATOS_BANCO = new Hashtable();
        Hashtable hash_REGISTRO;
        String[] arrVAL_AUX;
        String[] arrAUX;

        try
        {
            // Datos Poliza
            foreach (string DATO in DATOS_POLIZA)
            {
                if (DATO != null)
                {
                    arrAUX = DATO.Split('=');
                    if (arrAUX[0].ToString() == "MCA_SF" && arrAUX[1].ToString() == "S") checkSF = true;
                    hashDATOS_POLIZA.Add(arrAUX[0], arrAUX[1]);
                }
            }


            // Datos Variables
            foreach (string VARIABLES in DATOS_VARIABLES)
            {
                if (VARIABLES != null)
                {
                    hash_REGISTRO = new Hashtable();
                    arrVAL_AUX = VARIABLES.Split('|');
                    foreach (string DATO in arrVAL_AUX)
                    {
                        arrAUX = DATO.Split('=');

                        hash_REGISTRO.Add(arrAUX[0], arrAUX[1]);
                    }
                    arrDATOS_VARIABLES.Add(hash_REGISTRO);
                }
            }


            // Datos Cobertura
            foreach (string COBERTURA in DATOS_COBERTURA)
            {
                if (COBERTURA != null)
                {
                    hash_REGISTRO = new Hashtable();
                    arrVAL_AUX = COBERTURA.Split('|');
                    foreach (string DATO in arrVAL_AUX)
                    {
                        arrAUX = DATO.Split('=');
                        hash_REGISTRO.Add(arrAUX[0], arrAUX[1]);
                    }
                    arrDATOS_COBERTURA.Add(hash_REGISTRO);
                }
            }


            // Datos Contratante
            int cont = 0;
            foreach (string DATO in DATOS_CONT)
            {
                if (DATO != null)
                {
                    //APL ini
                    try
                    {
                        if (Session["TipoPLan"].ToString() != "16")
                        {
                            arrAUX = DATO.Split('=');
                            hashDATOS_CONT.Add(arrAUX[0], arrAUX[1]);
                        }
                        else
                        {
                            cont++;
                            hashDATOS_CONT.Add(cont, DATO);
                        }
                    }
                    catch
                    {
                        cont++;
                        hashDATOS_CONT.Add(cont, DATO);
                    }
                    //APL fin
                }
            }


            // Datos Solicitante
            foreach (string DATO in DATOS_SOL)
            {
                if (DATO != null)
                {
                    arrAUX = DATO.Split('=');
                    hashDATOS_SOL.Add(arrAUX[0], arrAUX[1]);
                }
            }


            // Datos Beneficiario
            foreach (string BENEFICIARIO in DATOS_BENEF)
            {
                if (BENEFICIARIO != null)
                {
                    hash_REGISTRO = new Hashtable();
                    arrVAL_AUX = BENEFICIARIO.Split('|');
                    foreach (string DATO in arrVAL_AUX)
                    {
                        arrAUX = DATO.Split('=');
                        hash_REGISTRO.Add(arrAUX[0], arrAUX[1]);
                    }
                    arrDATOS_BENEF.Add(hash_REGISTRO);
                }
            }
            Session.Add("arrBenef", arrDATOS_BENEF);


            // Datos Bancarios
            foreach (string DATO in DATOS_BANCO)
            {
                if (DATO != null)
                {
                    arrAUX = DATO.Split('=');
                    hashDATOS_BANCO.Add(arrAUX[0], arrAUX[1].ToUpper());
                }
            }

            return setEmisionFirma(hashDATOS_POLIZA, arrDATOS_VARIABLES, arrDATOS_COBERTURA, hashDATOS_CONT, hashDATOS_SOL, arrDATOS_BENEF, hashDATOS_BANCO);

        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Cotizacion.setCotizacionEmision(1) : " + ex.Message);
        }
    }

    /// <summary>M�todo en donde se arma el XMl para la Firma.</summary>
    public string setEmisionFirma(Hashtable DATOS_POLIZA, ArrayList DATOS_VARIABLES, ArrayList DATOS_COBERTURAS, Hashtable DATOS_CONT, Hashtable DATOS_SOL, ArrayList DATOS_BENEF, Hashtable DATOS_BANCO)
    {
        string XML;
        int ROW_NUM;
        StringBuilder objXML = new StringBuilder();
        Hashtable DATOS_AUX = new Hashtable();
        P2000030 objP2000030 = new P2000030();
        P2000031 objP2000031 = new P2000031();
        P2000040 objP2000040 = new P2000040();
        P2000060 objP2000060 = new P2000060();
        P2300061_MMX objP2300061_MMX = new P2300061_MMX();
        MetodosAjax dtasgurados = new MetodosAjax();
        MapfreMMX.emision.tabla.P2000020 objP2000020 = new MapfreMMX.emision.tabla.P2000020();

        try
        {
            // Encabezado del XML

            objXML.Append("<XML ACCION=\"" + m_accion + "\" COD_RAMO=\"");
            objXML.Append(DATOS_POLIZA["COD_RAMO"]);
            objXML.Append("\" NUM_POLIZA=\"\" COD_ORIGEN=\"");
            objXML.Append(WebUtils.getAppSetting("codOrigen"));

            //MGM_MSI
            if (Session["BanderaMSI"] != null)
            {
                if (Session["BanderaMSI"].ToString() == "True")
                {
                    objXML.Append("\" MCA_BASICO_STD=\"S");
                }
            }
            //AEP BWMEILL.Mill�n Vida
            //if (DATOS_POLIZA["COD_RAMO"].ToString()=="111")
            //{
            //    if (Session["TipoPagoMV"].ToString() =="DB")
            //        objXML.Append("\" MCA_BASICO_STD=\"S");

            //}

            objXML.Append("\">");


            DATOS_POLIZA.Add("COD_USR", WebUtils.getAppSetting("codUsuario"));


            // Se Genera el Nodo de la Tabla P2000030
            ROW_NUM = 1;
            objXML.Append("<TABLE NAME=\"P2000030\"><ROWSET>");
            objP2000030.setDatos(DATOS_POLIZA);
            objXML.Append(objP2000030.getXML(ROW_NUM));
            objXML.Append("</ROWSET></TABLE>");


            // Se Genera el Nodo de la Tabla P2000031 riesgos
            int ramo = 0;
            try
            {
                ramo = Convert.ToInt32(HttpContext.Current.Session["RAMO"]);
            }
            catch
            {
                ramo = 0;
            }


            if (ramo == 105)
            {
                //string operacion2 = Convert.ToString(HttpContext.Current.Session["OPERACION"]);
                //if (operacion2 =="COTIZACION")
                //{
                //    ROW_NUM = 1;
                //    objXML.Append("<TABLE NAME=\"P2000031\"><ROWSET>");
                //    objP2000031.setDatos(DATOS_POLIZA);
                //    objXML.Append(objP2000031.getXML(ROW_NUM));
                //    objXML.Append("</ROWSET></TABLE>");
                //}
                //else
                //{
                ROW_NUM = 1;
                objXML.Append("<TABLE NAME=\"P2000031\"><ROWSET>");
                DataTable asegurados = dtasgurados.setAsegurados();
                string fecha = "";
                string fecEfectoMas1Anio = dtasgurados.sumarUnAnioAFecha(Convert.ToString(Session["FECHA"]));
                for (var i = 1; i <= asegurados.Rows.Count; i++)
                {

                    if (Convert.ToInt32(asegurados.Rows[i - 1]["cod_parent"]) == 37)
                    {

                    }
                    else
                    {
                        objXML.Append("<ROW num=\"" + i + "\">");
                        objXML.Append("<NOM_RIESGO>" + asegurados.Rows[i - 1]["nombre"].ToString() + " " + asegurados.Rows[i - 1]["paterno"].ToString() + " " + asegurados.Rows[i - 1]["materno"].ToString() + "</NOM_RIESGO>\n");
                        if (Session["FECHA"] == null)
                        {
                            fecha = DateTime.Now.ToShortDateString();
                            objXML.Append("<FEC_EFEC_RIESGO>" + fecha + "</FEC_EFEC_RIESGO>\n");
                            fecEfectoMas1Anio = dtasgurados.sumarUnAnioAFecha(fecha);
                            objXML.Append("<FEC_VCTO_RIESGO>" + fecEfectoMas1Anio + "</FEC_VCTO_RIESGO>\n");
                        }
                        else
                        {
                            objXML.Append("<FEC_EFEC_RIESGO>" + Session["FECHA"] + "</FEC_EFEC_RIESGO>\n");
                            objXML.Append("<FEC_VCTO_RIESGO>" + fecEfectoMas1Anio + "</FEC_VCTO_RIESGO>\n");
                        }

                        if (Session["MODALIDAD"] == null)
                        {
                            objXML.Append("<COD_MODALIDAD>" + 99999 + "</COD_MODALIDAD>\n");
                        }
                        else
                        {
                            objXML.Append("<COD_MODALIDAD>" + Session["MODALIDAD"] + "</COD_MODALIDAD>\n");
                        }

                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_RIESGO>" + i + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_SPTO>XX</TIP_SPTO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("</ROW>");
                    }
                }


                objXML.Append("</ROWSET></TABLE>");
                //}



            }
            else
            {
                ROW_NUM = 1;
                objXML.Append("<TABLE NAME=\"P2000031\"><ROWSET>");
                objP2000031.setDatos(DATOS_POLIZA);
                objXML.Append(objP2000031.getXML(ROW_NUM));
                objXML.Append("</ROWSET></TABLE>");
            }

            // Se Genera el Nodo de la Tabla P2000020
            ROW_NUM = 1;
            objXML.Append("<TABLE NAME=\"P2000020\"><ROWSET>");
            string operacion = Convert.ToString(HttpContext.Current.Session["OPERACION"]);
            if (ramo == 105)
            {
                //if (operacion == "COTIZACION")
                //{
                //    foreach (Hashtable hashDATO in DATOS_VARIABLES)
                //    {
                //        DATOS_AUX = (Hashtable)(hashDATO.Clone());
                //        objP2000020.setDatos(DATOS_AUX);
                //        objXML.Append(objP2000020.getXML(ROW_NUM));
                //        ROW_NUM++;
                //    }
                //}
                //else
                //{

                var comision = "";
                if (Session["COMISION"] != null)
                {
                    comision = Session["COMISION"].ToString();
                }
                else
                {
                    comision = "1";
                }

                objXML.Append("<ROW num=\"1\">");
                objXML.Append("<COD_CAMPO>COD_ZONA</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>9</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>9</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>1</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"2\">");
                objXML.Append("<COD_CAMPO>COD_RIESGO</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>0</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>0</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>2</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"3\">\n");
                objXML.Append("<COD_CAMPO>TIP_RIESGO</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>0</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>0</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>3</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"4\">\n");
                objXML.Append("<COD_CAMPO>TIP_DEDUCIBLE</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>2</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>2</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>4</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"5\">\n");
                objXML.Append("<COD_CAMPO>TIP_COMISION</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>" + comision + "</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>" + comision + "</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>5</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"6\">\n");
                objXML.Append("<COD_CAMPO>VAL_DURACION_SEGURO</COD_CAMPO>\n");
                int duracion = Convert.ToInt32(Session["DURACION"]);
                objXML.Append("<VAL_CAMPO>" + duracion + "</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>" + duracion + "</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>6</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"7\">\n");
                objXML.Append("<COD_CAMPO>COD_MODALIDAD</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>18001</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>18001</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>7</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"8\">\n");
                objXML.Append("<COD_CAMPO>VAL_FOLIO_SOLICITUD</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>1</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>1</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>8</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"9\">\n");
                objXML.Append("<COD_CAMPO>NUM_EMPLEADO</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>1</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>1</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>9</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"10\">\n");
                objXML.Append("<COD_CAMPO>MCA_BENEFMEN</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>N</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>N</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>10</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"11\">\n");
                objXML.Append("<COD_CAMPO>TIP_SEGURO_VIDA</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>P</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>P</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>11</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                DataTable asegurados = dtasgurados.setAsegurados();
                int nc = asegurados.Rows.Count;
                int x1;
                int row = 11;
                for (x1 = 0; x1 <= nc - 1; x1++)
                {
                    if (Convert.ToInt32(asegurados.Rows[x1]["cod_parent"]) == 37)
                    {
                        int secu = 1;
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = Convert.ToInt32(row) + 1) + "\">");
                        objXML.Append("<COD_CAMPO>COD_DOCUM_MANC</COD_CAMPO>\n");
                        //objXML.Append("<COD_CAMPO>DVCOD_PARENTESCO_MANC</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO>" + asegurados.Rows[x1]["cod_docum"] + "</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>" + asegurados.Rows[x1]["cod_docum"] + "</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>" + row + "</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        //
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = Convert.ToInt32(row) + 1) + "\">");
                        objXML.Append("<COD_CAMPO>COD_PARENTESCO_MANC</COD_CAMPO>\n");
                        //objXML.Append("<COD_CAMPO>DVCOD_PARENTESCO_MANC</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO>" + Convert.ToInt32(asegurados.Rows[x1]["cod_parent"]) + "</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>" + Convert.ToInt32(asegurados.Rows[x1]["cod_parent"]) + "</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>" + row + "</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = row + 1) + "\">");
                        objXML.Append("<COD_CAMPO>FEC_NACIMIENTO_MANC</COD_CAMPO>\n");
                        //objXML.Append("<COD_CAMPO>DVFEC_NACIMIENTO_MANC</COD_CAMPO>\n");
                        string fecha = asegurados.Rows[x1]["fec_nac"].ToString();
                        //fecha = fecha.Replace('/', '');
                        char[] MyChar = { '/' };
                        //string fecha2 = fecha.TrimStart(MyChar);
                        string fecha2 = fecha.Replace("/", "");
                        objXML.Append("<VAL_CAMPO>" + fecha2 + "</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>" + fecha2 + "</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>" + row + "</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");

                    }
                    else
                    {
                        int secu = 1;
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = Convert.ToInt32(row) + 1) + "\">");
                        objXML.Append("<COD_CAMPO>COD_DOCUM</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO>" + asegurados.Rows[x1]["cod_docum"] + "</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>" + asegurados.Rows[x1]["cod_docum"] + "</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        //
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = Convert.ToInt32(row) + 1) + "\">");
                        objXML.Append("<COD_CAMPO>COD_PARENTESCO</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO>" + Convert.ToInt32(asegurados.Rows[x1]["cod_parent"]) + "</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>" + Convert.ToInt32(asegurados.Rows[x1]["cod_parent"]) + "</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = row + 1) + "\">");
                        objXML.Append("<COD_CAMPO>FEC_NACIMIENTO</COD_CAMPO>\n");
                        //objXML.Append("<COD_CAMPO>DVFEC_NACIMIENTO</COD_CAMPO>\n");
                        string fecha = asegurados.Rows[x1]["fec_nac"].ToString();
                        //fecha = fecha.Replace('/', '');
                        char[] MyChar = { '/' };
                        //string fecha2 = fecha.TrimStart(MyChar);
                        string fecha2 = fecha.Replace("/", "");
                        objXML.Append("<VAL_CAMPO>" + fecha2 + "</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>" + fecha2 + "</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = row + 1) + "\">");
                        objXML.Append("<COD_CAMPO>MCA_SEXO</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO>" + Convert.ToInt32(asegurados.Rows[x1]["sexo"]) + "</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>" + Convert.ToInt32(asegurados.Rows[x1]["sexo"]) + "</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = row + 1) + "\">");
                        objXML.Append("<COD_CAMPO>MCA_FUMAR</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO>0</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>0</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = row + 1) + "\">");
                        objXML.Append("<COD_CAMPO>COD_OCUPACION</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO>0</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>0</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = row + 1) + "\">");
                        objXML.Append("<COD_CAMPO>NUM_ESTATURA</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO></VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO></VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = row + 1) + "\">");
                        objXML.Append("<COD_CAMPO>NUM_PESO</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO></VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO></VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = row + 1) + "\">");
                        objXML.Append("<COD_CAMPO>DTO_SEXO</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO></VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO></VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>3</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = row + 1) + "\">");
                        objXML.Append("<COD_CAMPO>DTO_FUMAR</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO></VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO></VAL_COR_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO></VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>3</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = row + 1) + "\">");
                        objXML.Append("<COD_CAMPO>DTO_AGENTE_DIR</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO>" + Convert.ToInt32(Session["AGENTE"]) + "</VAL_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>3</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");







                    }
                }


                //}
            }
            else
            {
                foreach (Hashtable hashDATO in DATOS_VARIABLES)
                {
                    DATOS_AUX = (Hashtable)(hashDATO.Clone());
                    objP2000020.setDatos(DATOS_AUX);
                    objXML.Append(objP2000020.getXML(ROW_NUM));
                    ROW_NUM++;
                }
            }
            objXML.Append("</ROWSET></TABLE>");


            // Se Genera el Nodo de la Tabla P2000060
            if (ramo == 105)
            {
                string operacion3 = Convert.ToString(HttpContext.Current.Session["OPERACION"]);
                if (operacion3 == "COTIZACION")
                {

                    DataTable dtAsegurados = new DataTable();
                    DataTable dtBeneficiarios = new DataTable();
                    dtAsegurados = ((DataTable)Session["Asegurados"]).Copy();
                    DataTable asegurados = dtasgurados.setAsegurados();
                    int nc = asegurados.Rows.Count;
                    int nb = 0;
                    try
                    {
                        dtBeneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();
                        nb = dtBeneficiarios.Rows.Count;
                    }
                    catch
                    {
                        nb = 0;

                    }



                    int x1;
                    int x2;
                    int row = 1;
                    objXML.Append("<TABLE NAME=\"P2000060\"><ROWSET>");
                    for (x1 = 0; x1 <= nc - 1; x1++)
                    {

                        if (Convert.ToInt32(asegurados.Rows[x1]["cod_parent"]) == 37)//si es mancomunado
                        {
                            objXML.Append("<ROW num=\"" + Convert.ToInt32(x1 + 1) + "\">\n");
                            objXML.Append("<TIP_BENEF>2</TIP_BENEF>\n");
                            objXML.Append("<NUM_SECU>" + Convert.ToInt32(x1 + 1) + "</NUM_SECU>\n");
                            objXML.Append("<TIP_DOCUM>CLM</TIP_DOCUM>\n");
                            objXML.Append("<COD_DOCUM>" + asegurados.Rows[x1]["cod_docum"].ToString() + "</COD_DOCUM>\n");
                            objXML.Append("<PCT_PARTICIPACION></PCT_PARTICIPACION>\n");
                            objXML.Append("<FEC_NACIMIENTO>" + asegurados.Rows[x1]["fec_nac"].ToString() + "</FEC_NACIMIENTO>\n");
                            objXML.Append("<COD_PARENTESCO>" + asegurados.Rows[x1]["cod_parent"].ToString() + "</COD_PARENTESCO>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<COD_CIA>1</COD_CIA>\n");
                            objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                            objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                            objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                            objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1) + "</NUM_RIESGO>\n");
                            objXML.Append("<MCA_PRINCIPAL>N</MCA_PRINCIPAL>\n");
                            objXML.Append("<MCA_CALCULO>N</MCA_CALCULO>\n");
                            objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                            objXML.Append("<MCA_BAJA>N</MCA_BAJA>\n");
                            objXML.Append("<MCA_SEXO>0</MCA_SEXO>\n");
                            objXML.Append("<MCA_FUMA>0</MCA_FUMA>\n");

                            objXML.Append("</ROW>\n");
                        }
                        else
                        {
                            objXML.Append("<ROW num=\"" + Convert.ToInt32(x1 + 1) + "\">\n");
                            objXML.Append("<TIP_BENEF>2</TIP_BENEF>\n");
                            objXML.Append("<NUM_SECU>" + Convert.ToInt32(x1 + 1) + "</NUM_SECU>\n");
                            objXML.Append("<TIP_DOCUM>CLM</TIP_DOCUM>\n");
                            objXML.Append("<COD_DOCUM>" + asegurados.Rows[x1]["cod_docum"].ToString() + "</COD_DOCUM>\n");
                            objXML.Append("<PCT_PARTICIPACION></PCT_PARTICIPACION>\n");
                            objXML.Append("<FEC_NACIMIENTO>" + asegurados.Rows[x1]["fec_nac"].ToString() + "</FEC_NACIMIENTO>\n");
                            objXML.Append("<COD_PARENTESCO>" + asegurados.Rows[x1]["cod_parent"].ToString() + "</COD_PARENTESCO>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<COD_CIA>1</COD_CIA>\n");
                            objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                            objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                            objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                            objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                            objXML.Append("<MCA_PRINCIPAL>N</MCA_PRINCIPAL>\n");
                            objXML.Append("<MCA_CALCULO>N</MCA_CALCULO>\n");
                            objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                            objXML.Append("<MCA_BAJA>N</MCA_BAJA>\n");
                            objXML.Append("<MCA_SEXO>0</MCA_SEXO>\n");
                            objXML.Append("<MCA_FUMA>0</MCA_FUMA>\n");
                            objXML.Append("</ROW>\n");
                            if (operacion3 == "COTIZACION")
                            {
                            }
                            else
                            {
                                for (x2 = 0; x2 <= nb - 1; x2++)
                                {
                                    if (asegurados.Rows[x1]["cod_docum"].ToString() == dtBeneficiarios.Rows[x2]["asegurado"].ToString())
                                    {
                                        objXML.Append("<ROW num=\"" + Convert.ToInt32(x1 + 1 + 1) + "\">\n");
                                        objXML.Append("<TIP_BENEF>" + dtBeneficiarios.Rows[x2]["tip_benef"].ToString() + "</TIP_BENEF>\n");
                                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(x1 + 1 + 1) + "</NUM_SECU>\n");
                                        objXML.Append("<TIP_DOCUM>BEN</TIP_DOCUM>\n");
                                        objXML.Append("<COD_DOCUM>" + dtBeneficiarios.Rows[x2]["cod_docum"].ToString() + "</COD_DOCUM>\n");
                                        objXML.Append("<PCT_PARTICIPACION>" + Convert.ToInt32(dtBeneficiarios.Rows[x2]["porcentaje"]) + "</PCT_PARTICIPACION>\n");
                                        string fecha = dtBeneficiarios.Rows[x2]["fecnac"].ToString();
                                        char[] MyChar = { '/' };
                                        //string fecha2 = fecha.TrimStart(MyChar);
                                        string fecha2 = fecha.Replace("/", "");
                                        objXML.Append("<FEC_NACIMIENTO>" + fecha + "</FEC_NACIMIENTO>\n");
                                        objXML.Append("<COD_PARENTESCO>" + asegurados.Rows[x1]["cod_parent"].ToString() + "</COD_PARENTESCO>\n");
                                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                                        objXML.Append("<MCA_PRINCIPAL>N</MCA_PRINCIPAL>\n");
                                        objXML.Append("<MCA_CALCULO>N</MCA_CALCULO>\n");
                                        objXML.Append("<MCA_BAJA>N</MCA_BAJA>\n");
                                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                                        objXML.Append("<MCA_SEXO>0</MCA_SEXO>\n");
                                        objXML.Append("<MCA_FUMA>0</MCA_FUMA>\n");
                                        objXML.Append("</ROW>\n");



                                    }

                                }
                            }
                        }

                    }

                    objXML.Append("</ROWSET></TABLE>");

                }
                else
                {

                    DataTable dtAsegurados = new DataTable();
                    DataTable dtBeneficiarios = new DataTable();
                    dtAsegurados = ((DataTable)Session["Asegurados"]).Copy();
                    DataTable asegurados = dtasgurados.setAsegurados();
                    int nc = asegurados.Rows.Count;
                    int nb = 0;
                    try
                    {
                        dtBeneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();
                        nb = dtBeneficiarios.Rows.Count;
                    }
                    catch
                    {
                        nb = 0;

                    }



                    int x1;
                    int x2;
                    int row = 1;
                    objXML.Append("<TABLE NAME=\"P2000060\"><ROWSET>");
                    for (x1 = 0; x1 <= nc - 1; x1++)
                    {

                        if (Convert.ToInt32(asegurados.Rows[x1]["cod_parent"]) == 37)//si es mancomunado
                        {
                            objXML.Append("<ROW num=\"" + Convert.ToInt32(x1 + 1) + "\">\n");
                            objXML.Append("<TIP_BENEF>2</TIP_BENEF>\n");
                            objXML.Append("<NUM_SECU>" + Convert.ToInt32(x1 + 1) + "</NUM_SECU>\n");
                            objXML.Append("<TIP_DOCUM>CLM</TIP_DOCUM>\n");
                            objXML.Append("<COD_DOCUM>" + asegurados.Rows[x1]["cod_docum"].ToString() + "</COD_DOCUM>\n");
                            objXML.Append("<PCT_PARTICIPACION></PCT_PARTICIPACION>\n");
                            objXML.Append("<FEC_NACIMIENTO>" + asegurados.Rows[x1]["fec_nac"].ToString() + "</FEC_NACIMIENTO>\n");
                            objXML.Append("<COD_PARENTESCO>" + asegurados.Rows[x1]["cod_parent"].ToString() + "</COD_PARENTESCO>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<COD_CIA>1</COD_CIA>\n");
                            objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                            objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                            objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                            objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1) + "</NUM_RIESGO>\n");
                            objXML.Append("<MCA_PRINCIPAL>N</MCA_PRINCIPAL>\n");
                            objXML.Append("<MCA_CALCULO>N</MCA_CALCULO>\n");
                            objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                            objXML.Append("<MCA_BAJA>N</MCA_BAJA>\n");
                            objXML.Append("<MCA_SEXO>0</MCA_SEXO>\n");
                            objXML.Append("<MCA_FUMA>0</MCA_FUMA>\n");

                            objXML.Append("</ROW>\n");
                        }
                        else
                        {
                            objXML.Append("<ROW num=\"" + Convert.ToInt32(x1 + 1) + "\">\n");
                            objXML.Append("<TIP_BENEF>2</TIP_BENEF>\n");
                            objXML.Append("<NUM_SECU>" + Convert.ToInt32(x1 + 1) + "</NUM_SECU>\n");
                            objXML.Append("<TIP_DOCUM>CLM</TIP_DOCUM>\n");
                            objXML.Append("<COD_DOCUM>" + asegurados.Rows[x1]["cod_docum"].ToString() + "</COD_DOCUM>\n");
                            objXML.Append("<PCT_PARTICIPACION></PCT_PARTICIPACION>\n");
                            objXML.Append("<FEC_NACIMIENTO>" + asegurados.Rows[x1]["fec_nac"].ToString() + "</FEC_NACIMIENTO>\n");
                            objXML.Append("<COD_PARENTESCO>" + asegurados.Rows[x1]["cod_parent"].ToString() + "</COD_PARENTESCO>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<COD_CIA>1</COD_CIA>\n");
                            objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                            objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                            objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                            objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                            objXML.Append("<MCA_PRINCIPAL>N</MCA_PRINCIPAL>\n");
                            objXML.Append("<MCA_CALCULO>N</MCA_CALCULO>\n");
                            objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                            objXML.Append("<MCA_BAJA>N</MCA_BAJA>\n");
                            objXML.Append("<MCA_SEXO>0</MCA_SEXO>\n");
                            objXML.Append("<MCA_FUMA>0</MCA_FUMA>\n");
                            objXML.Append("</ROW>\n");
                            for (x2 = 0; x2 <= nb - 1; x2++)
                            {
                                if (asegurados.Rows[x1]["cod_docum"].ToString() == dtBeneficiarios.Rows[x2]["asegurado"].ToString())
                                {
                                    objXML.Append("<ROW num=\"" + Convert.ToInt32(x1 + 1 + 1) + "\">\n");
                                    objXML.Append("<TIP_BENEF>" + dtBeneficiarios.Rows[x2]["tip_benef"].ToString() + "</TIP_BENEF>\n");
                                    objXML.Append("<NUM_SECU>" + Convert.ToInt32(x1 + 1 + 1) + "</NUM_SECU>\n");
                                    objXML.Append("<TIP_DOCUM>BEN</TIP_DOCUM>\n");
                                    objXML.Append("<COD_DOCUM>" + dtBeneficiarios.Rows[x2]["cod_docum"].ToString() + "</COD_DOCUM>\n");
                                    objXML.Append("<PCT_PARTICIPACION>" + Convert.ToInt32(dtBeneficiarios.Rows[x2]["porcentaje"]) + "</PCT_PARTICIPACION>\n");
                                    string fecha = dtBeneficiarios.Rows[x2]["fecnac"].ToString();
                                    char[] MyChar = { '/' };
                                    //string fecha2 = fecha.TrimStart(MyChar);
                                    string fecha2 = fecha.Replace("/", "");
                                    objXML.Append("<FEC_NACIMIENTO>" + fecha + "</FEC_NACIMIENTO>\n");
                                    objXML.Append("<COD_PARENTESCO>" + asegurados.Rows[x1]["cod_parent"].ToString() + "</COD_PARENTESCO>\n");
                                    objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                                    objXML.Append("<COD_CIA>1</COD_CIA>\n");
                                    objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                                    objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                                    objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                                    objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                                    objXML.Append("<MCA_PRINCIPAL>N</MCA_PRINCIPAL>\n");
                                    objXML.Append("<MCA_CALCULO>N</MCA_CALCULO>\n");
                                    objXML.Append("<MCA_BAJA>N</MCA_BAJA>\n");
                                    objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                                    objXML.Append("<MCA_SEXO>0</MCA_SEXO>\n");
                                    objXML.Append("<MCA_FUMA>0</MCA_FUMA>\n");
                                    objXML.Append("</ROW>\n");



                                }

                            }
                        }

                    }

                    objXML.Append("</ROWSET></TABLE>");

                }


            }
            else
            {



                ROW_NUM = 1;
                DATOS_AUX = new Hashtable();
                objXML.Append("<TABLE NAME=\"P2000060\"><ROWSET>");
                objP2000060.setDatos(DATOS_SOL);
                objXML.Append(objP2000060.getXML(ROW_NUM));

                if (checkSF)
                {
                    DATOS_AUX = (Hashtable)(DATOS_SOL.Clone());
                    DATOS_AUX["TIP_BENEF"] = "10";
                    objP2000060.setDatos(DATOS_AUX);
                    objXML.Append(objP2000060.getXML(ROW_NUM));
                }

                // Beneficiario
                if (DATOS_BENEF.Count > 0)
                {
                    ROW_NUM = 2;
                    foreach (Hashtable hashDATO in DATOS_BENEF)
                    {
                        DATOS_AUX = (Hashtable)(hashDATO.Clone());
                        objP2000060.setDatos(DATOS_AUX);
                        objXML.Append(objP2000060.getXML(ROW_NUM));
                        ROW_NUM++;
                    }
                }
                objXML.Append("</ROWSET></TABLE>");
            }


            // Se Genera el Nodo de la Tabla P2000040

            if (ramo == 105)
            {
                string operacion3 = Convert.ToString(HttpContext.Current.Session["OPERACION"]);
                if (operacion3 == "COTIZACION")
                {
                    //ROW_NUM = 1;
                    //objXML.Append("<TABLE NAME=\"P2000040\"><ROWSET>");
                    //foreach (Hashtable hashDATO in DATOS_COBERTURAS)
                    //{
                    //    DATOS_AUX = (Hashtable)(hashDATO.Clone());
                    //    objP2000040.setDatos(DATOS_AUX);
                    //    objXML.Append(objP2000040.getXML(ROW_NUM));
                    //    ROW_NUM++;
                    //}
                    //objXML.Append("</ROWSET></TABLE>");
                    DataTable dtcoberturas = ((DataTable)Session["coberturas"]).Copy();
                    int nc = dtcoberturas.Rows.Count;
                    int x1 = 0;
                    int row = 1;
                    objXML.Append("<TABLE NAME=\"P2000040\"><ROWSET>");
                    string cobertura;
                    int numcobertura = 0;
                    int amparada = 0;
                    int sumabasica = 0;
                    //coberturas.Columns.Add("cobertura");
                    //coberturas.Columns.Add("cantidad");
                    //coberturas.Columns.Add("asegurado");

                    //      BIT   = txtSuma1011
                    //      BIPA   = txtSuma1012
                    //      TEMPORAL  =  txtSuma1014
                    //      BEF = txtSuma1013

                    string riesgo = "0";
                    int numriesgo = 1;
                    for (x1 = 0; x1 <= nc - 1; x1++)
                    {
                        if (dtcoberturas.Rows[x1]["parentesco"].ToString() == "37")
                        {
                        }
                        else
                        {
                            objXML.Append("<ROW num=\"" + row + "\">\n");
                            cobertura = dtcoberturas.Rows[x1]["cobertura"].ToString();

                            if (cobertura == "BASICA")
                            {
                                numcobertura = 1000;
                            }

                            if (cobertura == "BIT")
                            {
                                numcobertura = 1011;
                            }

                            if (cobertura == "BIPA")
                            {
                                numcobertura = 1012;
                            }

                            if (cobertura == "TEMPORAL")
                            {
                                numcobertura = 1014;
                            }

                            if (cobertura == "BEF")
                            {
                                numcobertura = 1013;
                            }


                            objXML.Append("<COD_COB>" + numcobertura + "</COD_COB>\n");
                            string suma = dtcoberturas.Rows[x1]["cantidad"].ToString();
                            if (suma == "NaN")
                            {
                                //suma = dtcoberturas.Rows[x1 - 1]["cantidad"].ToString();
                                //if (suma == "Nan")
                                //{
                                //suma = "0";
                                suma = Session["amparada"].ToString();
                                //}

                                //if (suma == "AMPARADA")
                                //{
                                //    suma = Session["amparada"].ToString();
                                //}

                            }
                            else
                            {
                                suma = dtcoberturas.Rows[x1]["cantidad"].ToString();

                                if (numcobertura == 1014)
                                {
                                    Session["amparada"] = suma;
                                }


                                //if (numcobertura == 1000)
                                //{
                                //    Session["amparada"] = suma;

                                //}


                                if (numcobertura == 1000)
                                {
                                    Session["amparada"] = suma;
                                    sumabasica = sumabasica + Convert.ToInt32(suma);
                                    Session["sumabasica"] = sumabasica;
                                }

                            }

                            if (numcobertura == 1013)
                            {
                                objXML.Append("<SUMA_ASEG>" + Convert.ToInt32(Session["sumabasica"]) + "</SUMA_ASEG>\n");
                                objXML.Append("<SUMA_ASEG_SPTO>" + Convert.ToInt32(Session["sumabasica"]) + "</SUMA_ASEG_SPTO>\n");
                            }
                            else
                            {
                                if (numcobertura == 1011)
                                {
                                    double sumprimas = 0;
                                    double sumaprimas2 = 0;
                                    try
                                    {
                                        sumprimas = Convert.ToDouble(Session["primatot"]);
                                        sumaprimas2 = sumprimas * 10;
                                        if (sumaprimas2 == 0.0)
                                        {
                                            sumaprimas2 = Convert.ToDouble(Session["amparada"]);
                                        }
                                    }
                                    catch
                                    {
                                        sumaprimas2 = Convert.ToInt32(Session["amparada"]);
                                    }



                                    objXML.Append("<SUMA_ASEG>" + Convert.ToDouble(sumaprimas2) + "</SUMA_ASEG>\n");
                                    objXML.Append("<SUMA_ASEG_SPTO>" + Convert.ToDouble(sumaprimas2) + "</SUMA_ASEG_SPTO>\n");
                                }
                                else
                                {
                                    objXML.Append("<SUMA_ASEG>" + Convert.ToInt32(suma) + "</SUMA_ASEG>\n");
                                    objXML.Append("<SUMA_ASEG_SPTO>" + Convert.ToInt32(suma) + "</SUMA_ASEG_SPTO>\n");
                                }
                            }

                            //if (numcobertura == 1013 || numcobertura == 1011)
                            //{
                            //    objXML.Append("<SUMA_ASEG>" + Convert.ToInt32(Session["amparada"]) + "</SUMA_ASEG>\n");
                            //    objXML.Append("<SUMA_ASEG_SPTO>" + Convert.ToInt32(Session["amparada"]) + "</SUMA_ASEG_SPTO>\n");
                            //}
                            //else
                            //{
                            //    objXML.Append("<SUMA_ASEG>" + Convert.ToInt32(suma) + "</SUMA_ASEG>\n");
                            //    objXML.Append("<SUMA_ASEG_SPTO>" + Convert.ToInt32(suma) + "</SUMA_ASEG_SPTO>\n");
                            //}


                            objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                            if (numcobertura == 1011 || numcobertura == 1013)
                            {
                                objXML.Append("<COD_SECC_REAS>130</COD_SECC_REAS>\n");
                            }
                            else
                            {
                                objXML.Append("<COD_SECC_REAS>13</COD_SECC_REAS>\n");
                            }

                            if (riesgo == "0")
                            {
                                objXML.Append("<NUM_RIESGO>" + numriesgo + "</NUM_RIESGO>\n");
                                riesgo = dtcoberturas.Rows[x1]["asegurado"].ToString();
                            }
                            else
                            {
                                if (riesgo == dtcoberturas.Rows[x1]["asegurado"].ToString())
                                {
                                    objXML.Append("<NUM_RIESGO>" + numriesgo + "</NUM_RIESGO>\n");
                                    riesgo = dtcoberturas.Rows[x1]["asegurado"].ToString();
                                }
                                else
                                {
                                    numriesgo = numriesgo + 1;
                                    riesgo = dtcoberturas.Rows[x1]["asegurado"].ToString();
                                    objXML.Append("<NUM_RIESGO>" + numriesgo + "</NUM_RIESGO>\n");
                                }

                            }
                            objXML.Append("<COD_CIA>1</COD_CIA>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                            objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                            objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                            objXML.Append("<COD_FRANQUICIA></COD_FRANQUICIA>\n");
                            objXML.Append("<COD_MON_CAPITAL>1</COD_MON_CAPITAL>\n");
                            objXML.Append("<TASA_COB>0</TASA_COB>\n");
                            objXML.Append("<IMP_AGR_SPTO>0</IMP_AGR_SPTO>\n");
                            objXML.Append("<IMP_AGR_REL_SPTO>0</IMP_AGR_REL_SPTO>\n");
                            objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                            objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                            objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                            objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                            objXML.Append("<MCA_BAJA_COB>N</MCA_BAJA_COB>\n");
                            objXML.Append("</ROW>\n");
                            row = row + 1;
                        }


                    }

                    objXML.Append("</ROWSET></TABLE>");


                }
                else
                {
                    DataTable dtcoberturas = ((DataTable)Session["coberturas"]).Copy();
                    int nc = dtcoberturas.Rows.Count;
                    int x1 = 0;
                    int row = 1;
                    objXML.Append("<TABLE NAME=\"P2000040\"><ROWSET>");
                    string cobertura;
                    int numcobertura = 0;
                    int amparada = 0;
                    int sumabasica = 0;
                    //coberturas.Columns.Add("cobertura");
                    //coberturas.Columns.Add("cantidad");
                    //coberturas.Columns.Add("asegurado");

                    //      BIT   = txtSuma1011
                    //      BIPA   = txtSuma1012
                    //      TEMPORAL  =  txtSuma1014
                    //      BEF = txtSuma1013

                    string riesgo = "0";
                    int numriesgo = 1;
                    for (x1 = 0; x1 <= nc - 1; x1++)
                    {
                        if (dtcoberturas.Rows[x1]["parentesco"].ToString() == "37")
                        {
                        }
                        else
                        {
                            objXML.Append("<ROW num=\"" + row + "\">\n");
                            cobertura = dtcoberturas.Rows[x1]["cobertura"].ToString();

                            if (cobertura == "BASICA")
                            {
                                numcobertura = 1000;
                            }

                            if (cobertura == "BIT")
                            {
                                numcobertura = 1011;
                            }

                            if (cobertura == "BIPA")
                            {
                                numcobertura = 1012;
                            }

                            if (cobertura == "TEMPORAL")
                            {
                                numcobertura = 1014;
                            }

                            if (cobertura == "BEF")
                            {
                                numcobertura = 1013;
                            }


                            objXML.Append("<COD_COB>" + numcobertura + "</COD_COB>\n");
                            string suma = dtcoberturas.Rows[x1]["cantidad"].ToString();
                            if (suma == "NaN")
                            {
                                //suma = dtcoberturas.Rows[x1 - 1]["cantidad"].ToString();
                                //if (suma == "Nan")
                                //{
                                //suma = "0";
                                suma = Session["amparada"].ToString();
                                //}

                                //if (suma == "AMPARADA")
                                //{
                                //    suma = Session["amparada"].ToString();
                                //}

                            }
                            else
                            {
                                suma = dtcoberturas.Rows[x1]["cantidad"].ToString();

                                if (numcobertura == 1014)
                                {
                                    Session["amparada"] = suma;
                                }

                                if (numcobertura == 1000)
                                {
                                    sumabasica = sumabasica + Convert.ToInt32(suma);
                                    Session["sumabasica"] = sumabasica;
                                }
                            }

                            if (numcobertura == 1013)
                            {
                                objXML.Append("<SUMA_ASEG>" + Convert.ToInt32(Session["sumabasica"]) + "</SUMA_ASEG>\n");
                                objXML.Append("<SUMA_ASEG_SPTO>" + Convert.ToInt32(Session["sumabasica"]) + "</SUMA_ASEG_SPTO>\n");
                            }
                            else
                            {
                                if (numcobertura == 1011)
                                {
                                    double sumprimas = 0;
                                    double sumaprimas2 = 0;
                                    try
                                    {
                                        sumprimas = Convert.ToDouble(Session["primatot"]);
                                        sumaprimas2 = sumprimas * 10;
                                    }
                                    catch
                                    {
                                        sumaprimas2 = Convert.ToInt32(Session["amparada"]);
                                    }



                                    objXML.Append("<SUMA_ASEG>" + Convert.ToDouble(sumaprimas2) + "</SUMA_ASEG>\n");
                                    objXML.Append("<SUMA_ASEG_SPTO>" + Convert.ToDouble(sumaprimas2) + "</SUMA_ASEG_SPTO>\n");
                                }
                                else
                                {
                                    objXML.Append("<SUMA_ASEG>" + Convert.ToInt32(suma) + "</SUMA_ASEG>\n");
                                    objXML.Append("<SUMA_ASEG_SPTO>" + Convert.ToInt32(suma) + "</SUMA_ASEG_SPTO>\n");
                                }
                            }


                            objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                            if (numcobertura == 1011 || numcobertura == 1013)
                            {
                                objXML.Append("<COD_SECC_REAS>130</COD_SECC_REAS>\n");
                            }
                            else
                            {
                                objXML.Append("<COD_SECC_REAS>13</COD_SECC_REAS>\n");
                            }

                            if (riesgo == "0")
                            {
                                objXML.Append("<NUM_RIESGO>" + numriesgo + "</NUM_RIESGO>\n");
                                riesgo = dtcoberturas.Rows[x1]["asegurado"].ToString();
                            }
                            else
                            {
                                if (riesgo == dtcoberturas.Rows[x1]["asegurado"].ToString())
                                {
                                    objXML.Append("<NUM_RIESGO>" + numriesgo + "</NUM_RIESGO>\n");
                                    riesgo = dtcoberturas.Rows[x1]["asegurado"].ToString();
                                }
                                else
                                {
                                    numriesgo = numriesgo + 1;
                                    riesgo = dtcoberturas.Rows[x1]["asegurado"].ToString();
                                    objXML.Append("<NUM_RIESGO>" + numriesgo + "</NUM_RIESGO>\n");
                                }

                            }
                            objXML.Append("<COD_CIA>1</COD_CIA>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                            objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                            objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                            objXML.Append("<COD_FRANQUICIA></COD_FRANQUICIA>\n");
                            objXML.Append("<COD_MON_CAPITAL>1</COD_MON_CAPITAL>\n");
                            objXML.Append("<TASA_COB>0</TASA_COB>\n");
                            objXML.Append("<IMP_AGR_SPTO>0</IMP_AGR_SPTO>\n");
                            objXML.Append("<IMP_AGR_REL_SPTO>0</IMP_AGR_REL_SPTO>\n");
                            objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                            objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                            objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                            objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                            objXML.Append("<MCA_BAJA_COB>N</MCA_BAJA_COB>\n");
                            objXML.Append("</ROW>\n");
                            row = row + 1;
                        }


                    }

                    objXML.Append("</ROWSET></TABLE>");

                }
            }
            else
            {

                ROW_NUM = 1;
                objXML.Append("<TABLE NAME=\"P2000040\"><ROWSET>");
                foreach (Hashtable hashDATO in DATOS_COBERTURAS)
                {
                    DATOS_AUX = (Hashtable)(hashDATO.Clone());
                    objP2000040.setDatos(DATOS_AUX);
                    objXML.Append(objP2000040.getXML(ROW_NUM));
                    ROW_NUM++;
                }
                objXML.Append("</ROWSET></TABLE>");
            }

            //Insertar Datos Contratante para cotizar P2300061_mmx

            if (ramo == 105)
            {
                if (m_accion == "C")
                {
                    DataTable dtAsegurados = ((DataTable)Session["Asegurados"]).Copy();
                    //DataTable dtBeneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();


                    DataTable asegurados = dtasgurados.setAsegurados();



                    int nc = asegurados.Rows.Count;
                    //int nb = dtBeneficiarios.Rows.Count;
                    int x1;
                    int x2;
                    int row = 1;
                    objXML.Append("<TABLE NAME=\"P2300060_MMX\"><ROWSET>");
                    for (x1 = 0; x1 <= nc - 1; x1++)
                    {
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(x1 + 1) + "\">");
                        if (asegurados.Rows[x1]["cod_parent"].ToString() == "37")
                        {
                            objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1) + "</NUM_RIESGO>");
                            objXML.Append("<NUM_SECU>2</NUM_SECU>");
                        }
                        else
                        {
                            objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>");
                            objXML.Append("<NUM_SECU>1</NUM_SECU>");
                        }

                        objXML.Append("<COD_PARENTESCO>" + asegurados.Rows[x1]["cod_parent"].ToString() + "</COD_PARENTESCO>");
                        if (asegurados.Rows[x1]["cod_parent"].ToString() == "38")
                        {
                            objXML.Append("<NOM_PARENTESCO>MENOR</NOM_PARENTESCO>");
                        }
                        if (asegurados.Rows[x1]["cod_parent"].ToString() == "37")
                        {
                            objXML.Append("<NOM_PARENTESCO>MANCOMUNADO</NOM_PARENTESCO>");
                        }
                        if (asegurados.Rows[x1]["cod_parent"].ToString() == "4")
                        {
                            objXML.Append("<NOM_PARENTESCO>TITULAR</NOM_PARENTESCO>");
                        }

                        objXML.Append("<FEC_NACIMIENTO>" + asegurados.Rows[x1]["fec_nac"].ToString() + "</FEC_NACIMIENTO>");
                        objXML.Append("<MCA_SEXO>0</MCA_SEXO>");
                        objXML.Append("<MCA_FUMA>0</MCA_FUMA>");
                        objXML.Append("<TIP_BENEF>2</TIP_BENEF>");
                        objXML.Append("<COD_CIA>1</COD_CIA>");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>");
                        objXML.Append("</ROW>");
                    }
                    objXML.Append("</ROWSET></TABLE>");
                }
                objXML.Append("</XML>");
            }
            else
            {
                if (DATOS_CONT.Count > 0)
                {
                    objXML.Append(getXmlP2300060_MMX(DATOS_CONT));
                }


            }

            objXML.Append("</XML>");

            XML = objXML.ToString() + "|" + token;


            //CDEmision objCotiza = new CDEmision();
            //if (Convert.ToInt32(Session["RAMO"]) == 105)
            //{
            //    return objCotiza.setCotizacionEmision(XML, conexion);
            //}
            //else
            //{
            //	return objCotiza.setCotizacionEmision(XML, token, conexion);
            //}
            return XML;

        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Cotizacion.setEmisionFirma(2) : " + ex.Message);
        }
    }
    /// <summary>M�todo para procesar los arreglos utilizados en la Emisi�n.
    /// <para>Este llama a su vez al m�todo sobrecargado <b>setEmision</b>.</para>
    /// </summary>
    public DataRow setEmision(String[] DATOS_POLIZA, String[] DATOS_VARIABLES, String[] DATOS_COBERTURA, String[] DATOS_CONT, String[] DATOS_SOL, String[] DATOS_BENEF, String[] DATOS_BANCO, OracleConnection conexion)
    {
        ArrayList arrDATOS_VARIABLES = new ArrayList();
        ArrayList arrDATOS_COBERTURA = new ArrayList();
        ArrayList arrDATOS_BENEF = new ArrayList();
        Hashtable hashDATOS_POLIZA = new Hashtable();
        Hashtable hashDATOS_CONT = new Hashtable();
        Hashtable hashDATOS_SOL = new Hashtable();
        Hashtable hashDATOS_BANCO = new Hashtable();
        Hashtable hash_REGISTRO;
        String[] arrVAL_AUX;
        String[] arrAUX;

        try
        {
            // Datos Poliza
            foreach (string DATO in DATOS_POLIZA)
            {
                if (DATO != null)
                {
                    arrAUX = DATO.Split('=');
                    if (arrAUX[0].ToString() == "MCA_SF" && arrAUX[1].ToString() == "S") checkSF = true;
                    hashDATOS_POLIZA.Add(arrAUX[0], arrAUX[1]);
                }
            }


            // Datos Variables
            foreach (string VARIABLES in DATOS_VARIABLES)
            {
                if (VARIABLES != null)
                {
                    hash_REGISTRO = new Hashtable();
                    arrVAL_AUX = VARIABLES.Split('|');
                    foreach (string DATO in arrVAL_AUX)
                    {
                        arrAUX = DATO.Split('=');

                        hash_REGISTRO.Add(arrAUX[0], arrAUX[1]);
                    }
                    arrDATOS_VARIABLES.Add(hash_REGISTRO);
                }
            }


            // Datos Cobertura
            foreach (string COBERTURA in DATOS_COBERTURA)
            {
                if (COBERTURA != null)
                {
                    hash_REGISTRO = new Hashtable();
                    arrVAL_AUX = COBERTURA.Split('|');
                    foreach (string DATO in arrVAL_AUX)
                    {
                        arrAUX = DATO.Split('=');
                        hash_REGISTRO.Add(arrAUX[0], arrAUX[1]);
                    }
                    arrDATOS_COBERTURA.Add(hash_REGISTRO);
                }
            }


            // Datos Contratante
            int cont=0;
            foreach (string DATO in DATOS_CONT)
            {
                if (DATO != null)
                {
                    //APL ini
                    try
                    {
                        if (Session["TipoPLan"].ToString() != "16")
                        {
                            arrAUX = DATO.Split('=');
                            hashDATOS_CONT.Add(arrAUX[0], arrAUX[1]);
                        }
                        else
                        {
                            cont++;
                            hashDATOS_CONT.Add(cont, DATO);
                        }
                    }
                    catch
                    {
                        cont++;
                        hashDATOS_CONT.Add(cont, DATO);
                    }
                    //APL fin
                }
            }


            // Datos Solicitante
            foreach (string DATO in DATOS_SOL)
            {
                if (DATO != null)
                {
                    arrAUX = DATO.Split('=');
                    hashDATOS_SOL.Add(arrAUX[0], arrAUX[1]);
                }
            }


            // Datos Beneficiario
            foreach (string BENEFICIARIO in DATOS_BENEF)
            {
                if (BENEFICIARIO != null)
                {
                    hash_REGISTRO = new Hashtable();
                    arrVAL_AUX = BENEFICIARIO.Split('|');
                    foreach (string DATO in arrVAL_AUX)
                    {
                        arrAUX = DATO.Split('=');
                        hash_REGISTRO.Add(arrAUX[0], arrAUX[1]);
                    }
                    arrDATOS_BENEF.Add(hash_REGISTRO);
                }
            }
            Session.Add("arrBenef", arrDATOS_BENEF);


            // Datos Bancarios
            foreach (string DATO in DATOS_BANCO)
            {
                if (DATO != null)
                {
                    arrAUX = DATO.Split('=');
                    hashDATOS_BANCO.Add(arrAUX[0], arrAUX[1].ToUpper());
                }
            }

            return setEmision(hashDATOS_POLIZA, arrDATOS_VARIABLES, arrDATOS_COBERTURA, hashDATOS_CONT, hashDATOS_SOL, arrDATOS_BENEF, hashDATOS_BANCO, conexion);

        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Cotizacion.setCotizacionEmision(1) : " + ex.Message);
        }
    }

    /// <summary>M�todo en donde se arma el XMl para la Emisi�n.</summary>
    public DataRow setEmision(Hashtable DATOS_POLIZA, ArrayList DATOS_VARIABLES, ArrayList DATOS_COBERTURAS, Hashtable DATOS_CONT, Hashtable DATOS_SOL, ArrayList DATOS_BENEF, Hashtable DATOS_BANCO, OracleConnection conexion)
    {
        int ROW_NUM;
        StringBuilder objXML = new StringBuilder();
        Hashtable DATOS_AUX = new Hashtable();
        P2000030 objP2000030 = new P2000030();
        P2000031 objP2000031 = new P2000031();
        P2000040 objP2000040 = new P2000040();
        P2000060 objP2000060 = new P2000060();
        P2300061_MMX objP2300061_MMX = new P2300061_MMX();
        MetodosAjax dtasgurados = new MetodosAjax();
        MapfreMMX.emision.tabla.P2000020 objP2000020 = new MapfreMMX.emision.tabla.P2000020();

        try
        {
            // Encabezado del XML

            objXML.Append("<XML ACCION=\"" + m_accion + "\" COD_RAMO=\"");
            objXML.Append(DATOS_POLIZA["COD_RAMO"]);
            objXML.Append("\" NUM_POLIZA=\"\" COD_ORIGEN=\"");
            objXML.Append(WebUtils.getAppSetting("codOrigen"));

            //MGM_MSI
            if (Session["BanderaMSI"] != null)
            {
                if (Session["BanderaMSI"].ToString() == "True")
                {
                    objXML.Append("\" MCA_BASICO_STD=\"S");
                }
            }
            //AEP BWMEILL.Mill�n Vida
            //if (DATOS_POLIZA["COD_RAMO"].ToString()=="111")
            //{
            //    if (Session["TipoPagoMV"].ToString() =="DB")
            //        objXML.Append("\" MCA_BASICO_STD=\"S");

            //}

            objXML.Append("\">");


            DATOS_POLIZA.Add("COD_USR", WebUtils.getAppSetting("codUsuario"));


            // Se Genera el Nodo de la Tabla P2000030
            ROW_NUM = 1;
            objXML.Append("<TABLE NAME=\"P2000030\"><ROWSET>");
            objP2000030.setDatos(DATOS_POLIZA);
            objXML.Append(objP2000030.getXML(ROW_NUM));
            objXML.Append("</ROWSET></TABLE>");


            // Se Genera el Nodo de la Tabla P2000031 riesgos
            int ramo = 0;
            try
            {
                ramo = Convert.ToInt32(HttpContext.Current.Session["RAMO"]);
            }
            catch
            {
                ramo = 0;
            }


            if (ramo == 105)
            {
                //string operacion2 = Convert.ToString(HttpContext.Current.Session["OPERACION"]);
                //if (operacion2 =="COTIZACION")
                //{
                //    ROW_NUM = 1;
                //    objXML.Append("<TABLE NAME=\"P2000031\"><ROWSET>");
                //    objP2000031.setDatos(DATOS_POLIZA);
                //    objXML.Append(objP2000031.getXML(ROW_NUM));
                //    objXML.Append("</ROWSET></TABLE>");
                //}
                //else
                //{
                ROW_NUM = 1;
                objXML.Append("<TABLE NAME=\"P2000031\"><ROWSET>");
                DataTable asegurados = dtasgurados.setAsegurados();
                string fecha = "";
                string fecEfectoMas1Anio = dtasgurados.sumarUnAnioAFecha(Convert.ToString(Session["FECHA"]));
                for (var i = 1; i <= asegurados.Rows.Count  ; i++)
                {

                    if (Convert.ToInt32(asegurados.Rows[i-1]["cod_parent"]) == 37)
                    {

                    }
                    else
                    {
                        objXML.Append("<ROW num=\"" + i + "\">");
                        objXML.Append("<NOM_RIESGO>" + asegurados.Rows[i - 1]["nombre"].ToString() + " " + asegurados.Rows[i - 1]["paterno"].ToString() + " " + asegurados.Rows[i - 1]["materno"].ToString() + "</NOM_RIESGO>\n");
                        if (Session["FECHA"] == null)
                        {
                            fecha = DateTime.Now.ToShortDateString();
                            objXML.Append("<FEC_EFEC_RIESGO>" + fecha + "</FEC_EFEC_RIESGO>\n");
                            fecEfectoMas1Anio = dtasgurados.sumarUnAnioAFecha(fecha);
                            objXML.Append("<FEC_VCTO_RIESGO>" + fecEfectoMas1Anio + "</FEC_VCTO_RIESGO>\n");
                        }
                        else
                        {
                            objXML.Append("<FEC_EFEC_RIESGO>" + Session["FECHA"] + "</FEC_EFEC_RIESGO>\n");
                            objXML.Append("<FEC_VCTO_RIESGO>" + fecEfectoMas1Anio + "</FEC_VCTO_RIESGO>\n");
                        }

                        if (Session["MODALIDAD"] == null)
                        {
                            objXML.Append("<COD_MODALIDAD>" + 99999 + "</COD_MODALIDAD>\n");
                        }
                        else
                        {
                            objXML.Append("<COD_MODALIDAD>" + Session["MODALIDAD"] + "</COD_MODALIDAD>\n");
                        }

                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_RIESGO>" + i + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_SPTO>XX</TIP_SPTO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("</ROW>");
                    }
                }


                objXML.Append("</ROWSET></TABLE>");
                //}



            }
            else
            {
                ROW_NUM = 1;
                objXML.Append("<TABLE NAME=\"P2000031\"><ROWSET>");
                objP2000031.setDatos(DATOS_POLIZA);
                objXML.Append(objP2000031.getXML(ROW_NUM));
                objXML.Append("</ROWSET></TABLE>");
            }

            // Se Genera el Nodo de la Tabla P2000020
            ROW_NUM = 1;
            objXML.Append("<TABLE NAME=\"P2000020\"><ROWSET>");
            string operacion = Convert.ToString(HttpContext.Current.Session["OPERACION"]);
            if (ramo == 105)
            {
                //if (operacion == "COTIZACION")
                //{
                //    foreach (Hashtable hashDATO in DATOS_VARIABLES)
                //    {
                //        DATOS_AUX = (Hashtable)(hashDATO.Clone());
                //        objP2000020.setDatos(DATOS_AUX);
                //        objXML.Append(objP2000020.getXML(ROW_NUM));
                //        ROW_NUM++;
                //    }
                //}
                //else
                //{
                var comision = "";
                if (Session["COMISION"] != null)
                {
                    comision = Session["COMISION"].ToString();
                }
                else
                {
                    comision = "1";
                }

                objXML.Append("<ROW num=\"1\">");
                objXML.Append("<COD_CAMPO>COD_ZONA</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>9</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>9</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>1</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"2\">");
                objXML.Append("<COD_CAMPO>COD_RIESGO</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>0</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>0</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>2</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"3\">\n");
                objXML.Append("<COD_CAMPO>TIP_RIESGO</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>0</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>0</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>3</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"4\">\n");
                objXML.Append("<COD_CAMPO>TIP_DEDUCIBLE</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>2</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>2</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>4</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"5\">\n");
                objXML.Append("<COD_CAMPO>TIP_COMISION</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>" + comision + "</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>" + comision + "</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>5</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"6\">\n");
                objXML.Append("<COD_CAMPO>VAL_DURACION_SEGURO</COD_CAMPO>\n");
                int duracion = Convert.ToInt32(Session["DURACION"]);
                objXML.Append("<VAL_CAMPO>"+ duracion +"</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>"+ duracion +"</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>6</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"7\">\n");
                objXML.Append("<COD_CAMPO>COD_MODALIDAD</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>18001</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>18001</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>7</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"8\">\n");
                objXML.Append("<COD_CAMPO>VAL_FOLIO_SOLICITUD</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>1</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>1</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>8</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"9\">\n");
                objXML.Append("<COD_CAMPO>NUM_EMPLEADO</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>1</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>1</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>9</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"10\">\n");
                objXML.Append("<COD_CAMPO>MCA_BENEFMEN</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>N</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>N</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>10</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                objXML.Append("<ROW num=\"11\">\n");
                objXML.Append("<COD_CAMPO>TIP_SEGURO_VIDA</COD_CAMPO>\n");
                objXML.Append("<VAL_CAMPO>P</VAL_CAMPO>\n");
                objXML.Append("<VAL_COR_CAMPO>P</VAL_COR_CAMPO>\n");
                objXML.Append("<NUM_RIESGO>0</NUM_RIESGO>\n");
                objXML.Append("<TIP_NIVEL>1</TIP_NIVEL>\n");
                objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                objXML.Append("<NUM_SECU>11</NUM_SECU>\n");
                objXML.Append("<COD_CIA>1</COD_CIA>\n");
                objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                objXML.Append("</ROW>\n");
                DataTable asegurados = dtasgurados.setAsegurados();
                int nc = asegurados.Rows.Count;
                int x1;
                int row = 11;
                for (x1 = 0; x1 <= nc -1 ; x1++)
                {
                    if (Convert.ToInt32(asegurados.Rows[x1 ]["cod_parent"]) == 37)
                    {
                        int secu = 1;
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = Convert.ToInt32(row) + 1) + "\">");
                        objXML.Append("<COD_CAMPO>COD_DOCUM_MANC</COD_CAMPO>\n");
                        //objXML.Append("<COD_CAMPO>DVCOD_PARENTESCO_MANC</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO>" + asegurados.Rows[x1]["cod_docum"] + "</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>" + asegurados.Rows[x1]["cod_docum"] + "</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>" + row + "</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        //
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = Convert.ToInt32(row) + 1) + "\">");
                        objXML.Append("<COD_CAMPO>COD_PARENTESCO_MANC</COD_CAMPO>\n");
                        //objXML.Append("<COD_CAMPO>DVCOD_PARENTESCO_MANC</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO>" + Convert.ToInt32(asegurados.Rows[x1]["cod_parent"]) + "</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>" + Convert.ToInt32(asegurados.Rows[x1]["cod_parent"]) + "</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>" + row + "</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = row + 1) + "\">");
                        objXML.Append("<COD_CAMPO>FEC_NACIMIENTO_MANC</COD_CAMPO>\n");
                        //objXML.Append("<COD_CAMPO>DVFEC_NACIMIENTO_MANC</COD_CAMPO>\n");
                        string fecha = asegurados.Rows[x1]["fec_nac"].ToString();
                        //fecha = fecha.Replace('/', '');
                        char[] MyChar = { '/' };
                        //string fecha2 = fecha.TrimStart(MyChar);
                        string fecha2 = fecha.Replace("/", "");
                        objXML.Append("<VAL_CAMPO>" + fecha2 + "</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>" + fecha2 + "</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>" + row + "</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");

                    }
                    else
                    {
                        int secu= 1;
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row = Convert.ToInt32(row) + 1) + "\">");
                        objXML.Append("<COD_CAMPO>COD_DOCUM</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO>" + asegurados.Rows[x1]["cod_docum"] + "</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>" + asegurados.Rows[x1]["cod_docum"] + "</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        //
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row= Convert.ToInt32(row) + 1 )  + "\">");
                        objXML.Append("<COD_CAMPO>COD_PARENTESCO</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO>" + Convert.ToInt32(asegurados.Rows[x1]["cod_parent"]) + "</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>" + Convert.ToInt32(asegurados.Rows[x1]["cod_parent"]) + "</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>"+ Convert.ToInt32(x1 + 1) +"</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row= row + 1 ) + "\">");
                        objXML.Append("<COD_CAMPO>FEC_NACIMIENTO</COD_CAMPO>\n");
                        //objXML.Append("<COD_CAMPO>DVFEC_NACIMIENTO</COD_CAMPO>\n");
                        string fecha = asegurados.Rows[x1]["fec_nac"].ToString();
                        //fecha = fecha.Replace('/', '');
                        char[] MyChar = {'/'};
                        //string fecha2 = fecha.TrimStart(MyChar);
                        string fecha2 = fecha.Replace("/", "");
                        objXML.Append("<VAL_CAMPO>"+ fecha2 +"</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>" + fecha2 + "</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>"+ Convert.ToInt32(x1 + 1) +"</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row= row + 1 ) + "\">");
                        objXML.Append("<COD_CAMPO>MCA_SEXO</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO>" + Convert.ToInt32(asegurados.Rows[x1]["sexo"]) + "</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>" + Convert.ToInt32(asegurados.Rows[x1]["sexo"]) + "</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>"+ Convert.ToInt32(x1 + 1) +"</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" +Convert.ToInt32(row= row + 1 ) + "\">");
                        objXML.Append("<COD_CAMPO>MCA_FUMAR</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO>0</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>0</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>"+ Convert.ToInt32(x1 + 1) +"</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row= row + 1 ) + "\">");
                        objXML.Append("<COD_CAMPO>COD_OCUPACION</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO>0</VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO>0</VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>"+ Convert.ToInt32(x1 + 1) +"</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row= row + 1 ) + "\">");
                        objXML.Append("<COD_CAMPO>NUM_ESTATURA</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO></VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO></VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>"+ Convert.ToInt32(x1 + 1) +"</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row= row + 1 ) + "\">");
                        objXML.Append("<COD_CAMPO>NUM_PESO</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO></VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO></VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>"+ Convert.ToInt32(x1 + 1) +"</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>2</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row= row + 1 ) + "\">");
                        objXML.Append("<COD_CAMPO>DTO_SEXO</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO></VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO></VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>"+ Convert.ToInt32(x1 + 1) +"</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>3</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row= row + 1 ) + "\">");
                        objXML.Append("<COD_CAMPO>DTO_FUMAR</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO></VAL_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO></VAL_COR_CAMPO>\n");
                        objXML.Append("<VAL_COR_CAMPO></VAL_COR_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>"+ Convert.ToInt32(x1 + 1) +"</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>3</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(row= row + 1 ) + "\">");
                        objXML.Append("<COD_CAMPO>DTO_AGENTE_DIR</COD_CAMPO>\n");
                        objXML.Append("<VAL_CAMPO>"+ Convert.ToInt32(Session["AGENTE"]) +"</VAL_CAMPO>\n");
                        objXML.Append("<NUM_RIESGO>"+ Convert.ToInt32(x1 + 1) +"</NUM_RIESGO>\n");
                        objXML.Append("<TIP_NIVEL>3</TIP_NIVEL>\n");
                        objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                        //objXML.Append("<NUM_SECU>"+ row +"</NUM_SECU>\n");
                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(secu = secu + 1) + "</NUM_SECU>\n");
                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                        objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                        objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                        objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                        objXML.Append("</ROW>\n");







                    }
                }


                //}
            }
            else
            {
                foreach (Hashtable hashDATO in DATOS_VARIABLES)
                {
                    DATOS_AUX = (Hashtable)(hashDATO.Clone());
                    objP2000020.setDatos(DATOS_AUX);
                    objXML.Append(objP2000020.getXML(ROW_NUM));
                    ROW_NUM++;
                }
            }
            objXML.Append("</ROWSET></TABLE>");


            // Se Genera el Nodo de la Tabla P2000060
            if (ramo == 105)
            {
                string operacion3 = Convert.ToString(HttpContext.Current.Session["OPERACION"]);
                if (operacion3 == "COTIZACION")
                {

                    DataTable dtAsegurados = new DataTable();
                    DataTable dtBeneficiarios = new DataTable();
                    dtAsegurados = ((DataTable)Session["Asegurados"]).Copy();
                    DataTable asegurados = dtasgurados.setAsegurados();
                    int nc = asegurados.Rows.Count;
                    int nb = 0;
                    try
                    {
                        dtBeneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();
                        nb = dtBeneficiarios.Rows.Count;
                    }
                    catch
                    {
                        nb = 0;

                    }



                    int x1;
                    int x2;
                    int row = 1;
                    objXML.Append("<TABLE NAME=\"P2000060\"><ROWSET>");
                    for (x1 = 0; x1 <= nc - 1; x1++)
                    {

                        if (Convert.ToInt32(asegurados.Rows[x1]["cod_parent"]) == 37)//si es mancomunado
                        {
                            objXML.Append("<ROW num=\"" + Convert.ToInt32(x1 + 1) + "\">\n");
                            objXML.Append("<TIP_BENEF>2</TIP_BENEF>\n");
                            objXML.Append("<NUM_SECU>" + Convert.ToInt32(x1 + 1) + "</NUM_SECU>\n");
                            objXML.Append("<TIP_DOCUM>CLM</TIP_DOCUM>\n");
                            objXML.Append("<COD_DOCUM>" + asegurados.Rows[x1]["cod_docum"].ToString() + "</COD_DOCUM>\n");
                            objXML.Append("<PCT_PARTICIPACION></PCT_PARTICIPACION>\n");
                            objXML.Append("<FEC_NACIMIENTO>" + asegurados.Rows[x1]["fec_nac"].ToString() + "</FEC_NACIMIENTO>\n");
                            objXML.Append("<COD_PARENTESCO>" + asegurados.Rows[x1]["cod_parent"].ToString() + "</COD_PARENTESCO>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<COD_CIA>1</COD_CIA>\n");
                            objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                            objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                            objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                            objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1) + "</NUM_RIESGO>\n");
                            objXML.Append("<MCA_PRINCIPAL>N</MCA_PRINCIPAL>\n");
                            objXML.Append("<MCA_CALCULO>N</MCA_CALCULO>\n");
                            objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                            objXML.Append("<MCA_BAJA>N</MCA_BAJA>\n");
                            objXML.Append("<MCA_SEXO>0</MCA_SEXO>\n");
                            objXML.Append("<MCA_FUMA>0</MCA_FUMA>\n");

                            objXML.Append("</ROW>\n");
                        }
                        else
                        {
                            objXML.Append("<ROW num=\"" + Convert.ToInt32(x1 + 1) + "\">\n");
                            objXML.Append("<TIP_BENEF>2</TIP_BENEF>\n");
                            objXML.Append("<NUM_SECU>" + Convert.ToInt32(x1 + 1) + "</NUM_SECU>\n");
                            objXML.Append("<TIP_DOCUM>CLM</TIP_DOCUM>\n");
                            objXML.Append("<COD_DOCUM>" + asegurados.Rows[x1]["cod_docum"].ToString() + "</COD_DOCUM>\n");
                            objXML.Append("<PCT_PARTICIPACION></PCT_PARTICIPACION>\n");
                            objXML.Append("<FEC_NACIMIENTO>" + asegurados.Rows[x1]["fec_nac"].ToString() + "</FEC_NACIMIENTO>\n");
                            objXML.Append("<COD_PARENTESCO>" + asegurados.Rows[x1]["cod_parent"].ToString() + "</COD_PARENTESCO>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<COD_CIA>1</COD_CIA>\n");
                            objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                            objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                            objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                            objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                            objXML.Append("<MCA_PRINCIPAL>N</MCA_PRINCIPAL>\n");
                            objXML.Append("<MCA_CALCULO>N</MCA_CALCULO>\n");
                            objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                            objXML.Append("<MCA_BAJA>N</MCA_BAJA>\n");
                            objXML.Append("<MCA_SEXO>0</MCA_SEXO>\n");
                            objXML.Append("<MCA_FUMA>0</MCA_FUMA>\n");
                            objXML.Append("</ROW>\n");
                            if (operacion3 == "COTIZACION")
                            {
                            }
                            else
                            {
                                for (x2 = 0; x2 <= nb - 1; x2++)
                                {
                                    if (asegurados.Rows[x1]["cod_docum"].ToString() == dtBeneficiarios.Rows[x2]["asegurado"].ToString())
                                    {
                                        objXML.Append("<ROW num=\"" + Convert.ToInt32(x1 + 1 + 1) + "\">\n");
                                        objXML.Append("<TIP_BENEF>" + dtBeneficiarios.Rows[x2]["tip_benef"].ToString() + "</TIP_BENEF>\n");
                                        objXML.Append("<NUM_SECU>" + Convert.ToInt32(x1 + 1 + 1) + "</NUM_SECU>\n");
                                        objXML.Append("<TIP_DOCUM>BEN</TIP_DOCUM>\n");
                                        objXML.Append("<COD_DOCUM>" + dtBeneficiarios.Rows[x2]["cod_docum"].ToString() + "</COD_DOCUM>\n");
                                        objXML.Append("<PCT_PARTICIPACION>" + Convert.ToInt32(dtBeneficiarios.Rows[x2]["porcentaje"]) + "</PCT_PARTICIPACION>\n");
                                        string fecha = dtBeneficiarios.Rows[x2]["fecnac"].ToString();
                                        char[] MyChar = { '/' };
                                        //string fecha2 = fecha.TrimStart(MyChar);
                                        string fecha2 = fecha.Replace("/", "");
                                        objXML.Append("<FEC_NACIMIENTO>" + fecha + "</FEC_NACIMIENTO>\n");
                                        objXML.Append("<COD_PARENTESCO>" + asegurados.Rows[x1]["cod_parent"].ToString() + "</COD_PARENTESCO>\n");
                                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                                        objXML.Append("<COD_CIA>1</COD_CIA>\n");
                                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                                        objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                                        objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                                        objXML.Append("<MCA_PRINCIPAL>N</MCA_PRINCIPAL>\n");
                                        objXML.Append("<MCA_CALCULO>N</MCA_CALCULO>\n");
                                        objXML.Append("<MCA_BAJA>N</MCA_BAJA>\n");
                                        objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                                        objXML.Append("<MCA_SEXO>0</MCA_SEXO>\n");
                                        objXML.Append("<MCA_FUMA>0</MCA_FUMA>\n");
                                        objXML.Append("</ROW>\n");



                                    }

                                }
                            }
                        }

                    }

                    objXML.Append("</ROWSET></TABLE>");

                }
                else
                {

                    DataTable dtAsegurados = new DataTable();
                    DataTable dtBeneficiarios = new DataTable();
                    dtAsegurados = ((DataTable)Session["Asegurados"]).Copy();
                    DataTable asegurados = dtasgurados.setAsegurados();
                    int nc = asegurados.Rows.Count;
                    int nb =0;
                    try
                    {
                        dtBeneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();
                        nb = dtBeneficiarios.Rows.Count;
                    }
                    catch
                    {
                        nb = 0;

                    }



                    int x1;
                    int x2;
                    int row = 1;
                    objXML.Append("<TABLE NAME=\"P2000060\"><ROWSET>");
                    for (x1 = 0; x1 <= nc -1 ; x1++)
                    {

                        if (Convert.ToInt32(asegurados.Rows[x1]["cod_parent"]) == 37)//si es mancomunado
                        {
                            objXML.Append("<ROW num=\"" + Convert.ToInt32(x1 + 1) + "\">\n");
                            objXML.Append("<TIP_BENEF>2</TIP_BENEF>\n");
                            objXML.Append("<NUM_SECU>" + Convert.ToInt32(x1 + 1) + "</NUM_SECU>\n");
                            objXML.Append("<TIP_DOCUM>CLM</TIP_DOCUM>\n");
                            objXML.Append("<COD_DOCUM>" + asegurados.Rows[x1]["cod_docum"].ToString() + "</COD_DOCUM>\n");
                            objXML.Append("<PCT_PARTICIPACION></PCT_PARTICIPACION>\n");
                            objXML.Append("<FEC_NACIMIENTO>" + asegurados.Rows[x1]["fec_nac"].ToString() + "</FEC_NACIMIENTO>\n");
                            objXML.Append("<COD_PARENTESCO>" + asegurados.Rows[x1]["cod_parent"].ToString() + "</COD_PARENTESCO>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<COD_CIA>1</COD_CIA>\n");
                            objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                            objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                            objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                            objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1) + "</NUM_RIESGO>\n");
                            objXML.Append("<MCA_PRINCIPAL>N</MCA_PRINCIPAL>\n");
                            objXML.Append("<MCA_CALCULO>N</MCA_CALCULO>\n");
                            objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                            objXML.Append("<MCA_BAJA>N</MCA_BAJA>\n");
                            objXML.Append("<MCA_SEXO>0</MCA_SEXO>\n");
                            objXML.Append("<MCA_FUMA>0</MCA_FUMA>\n");

                            objXML.Append("</ROW>\n");
                        }
                        else
                        {
                            objXML.Append("<ROW num=\"" + Convert.ToInt32(x1 + 1) + "\">\n");
                            objXML.Append("<TIP_BENEF>2</TIP_BENEF>\n");
                            objXML.Append("<NUM_SECU>" + Convert.ToInt32(x1 + 1) + "</NUM_SECU>\n");
                            objXML.Append("<TIP_DOCUM>CLM</TIP_DOCUM>\n");
                            objXML.Append("<COD_DOCUM>" + asegurados.Rows[x1]["cod_docum"].ToString() + "</COD_DOCUM>\n");
                            objXML.Append("<PCT_PARTICIPACION></PCT_PARTICIPACION>\n");
                            objXML.Append("<FEC_NACIMIENTO>" + asegurados.Rows[x1]["fec_nac"].ToString() + "</FEC_NACIMIENTO>\n");
                            objXML.Append("<COD_PARENTESCO>" + asegurados.Rows[x1]["cod_parent"].ToString() + "</COD_PARENTESCO>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<COD_CIA>1</COD_CIA>\n");
                            objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                            objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                            objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                            objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                            objXML.Append("<MCA_PRINCIPAL>N</MCA_PRINCIPAL>\n");
                            objXML.Append("<MCA_CALCULO>N</MCA_CALCULO>\n");
                            objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                            objXML.Append("<MCA_BAJA>N</MCA_BAJA>\n");
                            objXML.Append("<MCA_SEXO>0</MCA_SEXO>\n");
                            objXML.Append("<MCA_FUMA>0</MCA_FUMA>\n");
                            objXML.Append("</ROW>\n");
                            for (x2 = 0; x2 <= nb -1 ; x2++)
                            {
                                if (asegurados.Rows[x1]["cod_docum"].ToString() == dtBeneficiarios.Rows[x2]["asegurado"].ToString())
                                {
                                    objXML.Append("<ROW num=\"" + Convert.ToInt32(x1 + 1 + 1) + "\">\n");
                                    objXML.Append("<TIP_BENEF>" + dtBeneficiarios.Rows[x2]["tip_benef"].ToString() + "</TIP_BENEF>\n");
                                    objXML.Append("<NUM_SECU>" + Convert.ToInt32(x1 + 1 + 1) + "</NUM_SECU>\n");
                                    objXML.Append("<TIP_DOCUM>BEN</TIP_DOCUM>\n");
                                    objXML.Append("<COD_DOCUM>" + dtBeneficiarios.Rows[x2]["cod_docum"].ToString() + "</COD_DOCUM>\n");
                                    objXML.Append("<PCT_PARTICIPACION>" + Convert.ToInt32(dtBeneficiarios.Rows[x2]["porcentaje"]) + "</PCT_PARTICIPACION>\n");
                                    string fecha = dtBeneficiarios.Rows[x2]["fecnac"].ToString();
                                    char[] MyChar = { '/' };
                                    //string fecha2 = fecha.TrimStart(MyChar);
                                    string fecha2 = fecha.Replace("/","");
                                    objXML.Append("<FEC_NACIMIENTO>" + fecha + "</FEC_NACIMIENTO>\n");
                                    objXML.Append("<COD_PARENTESCO>" + asegurados.Rows[x1]["cod_parent"].ToString() + "</COD_PARENTESCO>\n");
                                    objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                                    objXML.Append("<COD_CIA>1</COD_CIA>\n");
                                    objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                                    objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                                    objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                                    objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>\n");
                                    objXML.Append("<MCA_PRINCIPAL>N</MCA_PRINCIPAL>\n");
                                    objXML.Append("<MCA_CALCULO>N</MCA_CALCULO>\n");
                                    objXML.Append("<MCA_BAJA>N</MCA_BAJA>\n");
                                    objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                                    objXML.Append("<MCA_SEXO>0</MCA_SEXO>\n");
                                    objXML.Append("<MCA_FUMA>0</MCA_FUMA>\n");
                                    objXML.Append("</ROW>\n");



                                }

                            }
                        }

                    }

                    objXML.Append("</ROWSET></TABLE>");

                }


            }
            else
            {



                ROW_NUM = 1;
                DATOS_AUX = new Hashtable();
                objXML.Append("<TABLE NAME=\"P2000060\"><ROWSET>");
                objP2000060.setDatos(DATOS_SOL);
                objXML.Append(objP2000060.getXML(ROW_NUM));

                if (checkSF)
                {
                    DATOS_AUX = (Hashtable)(DATOS_SOL.Clone());
                    DATOS_AUX["TIP_BENEF"] = "10";
                    objP2000060.setDatos(DATOS_AUX);
                    objXML.Append(objP2000060.getXML(ROW_NUM));
                }

                // Beneficiario
                if (DATOS_BENEF.Count > 0)
                {
                    ROW_NUM = 2;
                    foreach (Hashtable hashDATO in DATOS_BENEF)
                    {
                        DATOS_AUX = (Hashtable)(hashDATO.Clone());
                        objP2000060.setDatos(DATOS_AUX);
                        objXML.Append(objP2000060.getXML(ROW_NUM));
                        ROW_NUM++;
                    }
                }
                objXML.Append("</ROWSET></TABLE>");
            }


            // Se Genera el Nodo de la Tabla P2000040

            if (ramo == 105)
            {
                string operacion3 = Convert.ToString(HttpContext.Current.Session["OPERACION"]);
                if (operacion3 == "COTIZACION")
                {
                    //ROW_NUM = 1;
                    //objXML.Append("<TABLE NAME=\"P2000040\"><ROWSET>");
                    //foreach (Hashtable hashDATO in DATOS_COBERTURAS)
                    //{
                    //    DATOS_AUX = (Hashtable)(hashDATO.Clone());
                    //    objP2000040.setDatos(DATOS_AUX);
                    //    objXML.Append(objP2000040.getXML(ROW_NUM));
                    //    ROW_NUM++;
                    //}
                    //objXML.Append("</ROWSET></TABLE>");
                    DataTable dtcoberturas = ((DataTable)Session["coberturas"]).Copy();
                    int nc = dtcoberturas.Rows.Count;
                    int x1 = 0;
                    int row = 1;
                    objXML.Append("<TABLE NAME=\"P2000040\"><ROWSET>");
                    string cobertura;
                    int numcobertura = 0;
                    int amparada = 0;
                    int sumabasica = 0;
                    //coberturas.Columns.Add("cobertura");
                    //coberturas.Columns.Add("cantidad");
                    //coberturas.Columns.Add("asegurado");

                    //      BIT   = txtSuma1011
                    //      BIPA   = txtSuma1012
                    //      TEMPORAL  =  txtSuma1014
                    //      BEF = txtSuma1013

                    string riesgo = "0";
                    int numriesgo = 1;
                    for (x1 = 0; x1 <= nc - 1; x1++)
                    {
                        if (dtcoberturas.Rows[x1]["parentesco"].ToString() == "37")
                        {
                        }
                        else
                        {
                            objXML.Append("<ROW num=\"" + row + "\">\n");
                            cobertura = dtcoberturas.Rows[x1]["cobertura"].ToString();

                            if (cobertura == "BASICA")
                            {
                                numcobertura = 1000;
                            }

                            if (cobertura == "BIT")
                            {
                                numcobertura = 1011;
                            }

                            if (cobertura == "BIPA")
                            {
                                numcobertura = 1012;
                            }

                            if (cobertura == "TEMPORAL")
                            {
                                numcobertura = 1014;
                            }

                            if (cobertura == "BEF")
                            {
                                numcobertura = 1013;
                            }


                            objXML.Append("<COD_COB>" + numcobertura + "</COD_COB>\n");
                            string suma = dtcoberturas.Rows[x1]["cantidad"].ToString();
                            if (suma == "NaN")
                            {
                                //suma = dtcoberturas.Rows[x1 - 1]["cantidad"].ToString();
                                //if (suma == "Nan")
                                //{
                                //suma = "0";
                                suma = Session["amparada"].ToString();
                                //}

                                //if (suma == "AMPARADA")
                                //{
                                //    suma = Session["amparada"].ToString();
                                //}

                            }
                            else
                            {
                                suma = dtcoberturas.Rows[x1]["cantidad"].ToString();

                                if (numcobertura == 1014)
                                {
                                    Session["amparada"] = suma;
                                }


                                //if (numcobertura == 1000)
                                //{
                                //    Session["amparada"] = suma;

                                //}


                                if (numcobertura == 1000)
                                {
                                    Session["amparada"] = suma;
                                    sumabasica = sumabasica + Convert.ToInt32(suma);
                                    Session["sumabasica"] = sumabasica;
                                }

                            }

                            if (numcobertura == 1013)
                            {
                                objXML.Append("<SUMA_ASEG>" + Convert.ToInt32(Session["sumabasica"]) + "</SUMA_ASEG>\n");
                                objXML.Append("<SUMA_ASEG_SPTO>" + Convert.ToInt32(Session["sumabasica"]) + "</SUMA_ASEG_SPTO>\n");
                            }
                            else
                            {
                                if (numcobertura == 1011)
                                {
                                    double sumprimas = 0;
                                    double sumaprimas2 = 0;
                                    try
                                    {
                                        sumprimas = Convert.ToDouble(Session["primatot"]);
                                        sumaprimas2 = sumprimas * 10;
                                        if (sumaprimas2 == 0.0)
                                        {
                                            sumaprimas2 = Convert.ToDouble(Session["amparada"]);
                                        }
                                    }
                                    catch
                                    {
                                        sumaprimas2 = Convert.ToInt32(Session["amparada"]);
                                    }



                                    objXML.Append("<SUMA_ASEG>" + Convert.ToDouble(sumaprimas2) + "</SUMA_ASEG>\n");
                                    objXML.Append("<SUMA_ASEG_SPTO>" + Convert.ToDouble(sumaprimas2) + "</SUMA_ASEG_SPTO>\n");
                                }
                                else
                                {
                                    objXML.Append("<SUMA_ASEG>" + Convert.ToInt32(suma) + "</SUMA_ASEG>\n");
                                    objXML.Append("<SUMA_ASEG_SPTO>" + Convert.ToInt32(suma) + "</SUMA_ASEG_SPTO>\n");
                                }
                            }

                            //if (numcobertura == 1013 || numcobertura == 1011)
                            //{
                            //    objXML.Append("<SUMA_ASEG>" + Convert.ToInt32(Session["amparada"]) + "</SUMA_ASEG>\n");
                            //    objXML.Append("<SUMA_ASEG_SPTO>" + Convert.ToInt32(Session["amparada"]) + "</SUMA_ASEG_SPTO>\n");
                            //}
                            //else
                            //{
                            //    objXML.Append("<SUMA_ASEG>" + Convert.ToInt32(suma) + "</SUMA_ASEG>\n");
                            //    objXML.Append("<SUMA_ASEG_SPTO>" + Convert.ToInt32(suma) + "</SUMA_ASEG_SPTO>\n");
                            //}


                            objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                            if (numcobertura == 1011 || numcobertura == 1013)
                            {
                                objXML.Append("<COD_SECC_REAS>130</COD_SECC_REAS>\n");
                            }
                            else
                            {
                                objXML.Append("<COD_SECC_REAS>13</COD_SECC_REAS>\n");
                            }

                            if (riesgo == "0")
                            {
                                objXML.Append("<NUM_RIESGO>" + numriesgo + "</NUM_RIESGO>\n");
                                riesgo = dtcoberturas.Rows[x1]["asegurado"].ToString();
                            }
                            else
                            {
                                if (riesgo == dtcoberturas.Rows[x1]["asegurado"].ToString())
                                {
                                    objXML.Append("<NUM_RIESGO>" + numriesgo + "</NUM_RIESGO>\n");
                                    riesgo = dtcoberturas.Rows[x1]["asegurado"].ToString();
                                }
                                else
                                {
                                    numriesgo = numriesgo + 1;
                                    riesgo = dtcoberturas.Rows[x1]["asegurado"].ToString();
                                    objXML.Append("<NUM_RIESGO>" + numriesgo + "</NUM_RIESGO>\n");
                                }

                            }
                            objXML.Append("<COD_CIA>1</COD_CIA>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                            objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                            objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                            objXML.Append("<COD_FRANQUICIA></COD_FRANQUICIA>\n");
                            objXML.Append("<COD_MON_CAPITAL>1</COD_MON_CAPITAL>\n");
                            objXML.Append("<TASA_COB>0</TASA_COB>\n");
                            objXML.Append("<IMP_AGR_SPTO>0</IMP_AGR_SPTO>\n");
                            objXML.Append("<IMP_AGR_REL_SPTO>0</IMP_AGR_REL_SPTO>\n");
                            objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                            objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                            objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                            objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                            objXML.Append("<MCA_BAJA_COB>N</MCA_BAJA_COB>\n");
                            objXML.Append("</ROW>\n");
                            row = row + 1;
                        }


                    }

                    objXML.Append("</ROWSET></TABLE>");


                }
                else
                {
                    DataTable dtcoberturas = ((DataTable)Session["coberturas"]).Copy();
                    int nc = dtcoberturas.Rows.Count;
                    int x1 = 0;
                    int row  = 1;
                    objXML.Append("<TABLE NAME=\"P2000040\"><ROWSET>");
                    string cobertura;
                    int numcobertura=0;
                    int amparada = 0;
                    int sumabasica = 0;
                    //coberturas.Columns.Add("cobertura");
                    //coberturas.Columns.Add("cantidad");
                    //coberturas.Columns.Add("asegurado");

                    //      BIT   = txtSuma1011
                    //      BIPA   = txtSuma1012
                    //      TEMPORAL  =  txtSuma1014
                    //      BEF = txtSuma1013

                    string riesgo = "0";
                    int numriesgo = 1;
                    for (x1 = 0; x1 <= nc - 1; x1++)
                    {
                        if (dtcoberturas.Rows[x1]["parentesco"].ToString() == "37")
                        {
                        }
                        else
                        {
                            objXML.Append("<ROW num=\"" + row + "\">\n");
                            cobertura = dtcoberturas.Rows[x1]["cobertura"].ToString();

                            if (cobertura == "BASICA")
                            {
                                numcobertura = 1000;
                            }

                            if (cobertura == "BIT")
                            {
                                numcobertura = 1011;
                            }

                            if (cobertura == "BIPA")
                            {
                                numcobertura = 1012;
                            }

                            if (cobertura == "TEMPORAL")
                            {
                                numcobertura = 1014;
                            }

                            if (cobertura == "BEF")
                            {
                                numcobertura = 1013;
                            }


                            objXML.Append("<COD_COB>" + numcobertura + "</COD_COB>\n");
                            string suma = dtcoberturas.Rows[x1]["cantidad"].ToString();
                            if (suma == "NaN")
                            {
                                //suma = dtcoberturas.Rows[x1 - 1]["cantidad"].ToString();
                                //if (suma == "Nan")
                                //{
                                //suma = "0";
                                suma = Session["amparada"].ToString();
                                //}

                                //if (suma == "AMPARADA")
                                //{
                                //    suma = Session["amparada"].ToString();
                                //}

                            }
                            else
                            {
                                suma  = dtcoberturas.Rows[x1]["cantidad"].ToString();

                                if (numcobertura == 1014)
                                {
                                    Session["amparada"] = suma;
                                }

                                if (numcobertura == 1000)
                                {
                                    sumabasica = sumabasica + Convert.ToInt32(suma);
                                    Session["sumabasica"] = sumabasica;
                                }
                            }

                            if (numcobertura == 1013)
                            {
                                objXML.Append("<SUMA_ASEG>" + Convert.ToInt32(Session["sumabasica"]) + "</SUMA_ASEG>\n");
                                objXML.Append("<SUMA_ASEG_SPTO>" + Convert.ToInt32(Session["sumabasica"]) + "</SUMA_ASEG_SPTO>\n");
                            }
                            else
                            {
                                if (numcobertura == 1011)
                                {
                                    double sumprimas = 0;
                                    double sumaprimas2 = 0;
                                    try
                                    {
                                        sumprimas = Convert.ToDouble(Session["primatot"]);
                                        sumaprimas2 = sumprimas * 10;
                                    }
                                    catch
                                    {
                                        sumaprimas2 = Convert.ToInt32(Session["amparada"]);
                                    }



                                    objXML.Append("<SUMA_ASEG>" + Convert.ToDouble(sumaprimas2) + "</SUMA_ASEG>\n");
                                    objXML.Append("<SUMA_ASEG_SPTO>" + Convert.ToDouble(sumaprimas2) + "</SUMA_ASEG_SPTO>\n");
                                }
                                else
                                {
                                    objXML.Append("<SUMA_ASEG>" + Convert.ToInt32(suma) + "</SUMA_ASEG>\n");
                                    objXML.Append("<SUMA_ASEG_SPTO>" + Convert.ToInt32(suma) + "</SUMA_ASEG_SPTO>\n");
                                }
                            }


                            objXML.Append("<COD_RAMO>105</COD_RAMO>\n");
                            if (numcobertura == 1011 || numcobertura == 1013)
                            {
                                objXML.Append("<COD_SECC_REAS>130</COD_SECC_REAS>\n");
                            }
                            else
                            {
                                objXML.Append("<COD_SECC_REAS>13</COD_SECC_REAS>\n");
                            }

                            if (riesgo == "0")
                            {
                                objXML.Append("<NUM_RIESGO>" + numriesgo + "</NUM_RIESGO>\n");
                                riesgo = dtcoberturas.Rows[x1]["asegurado"].ToString();
                            }
                            else
                            {
                                if (riesgo == dtcoberturas.Rows[x1]["asegurado"].ToString())
                                {
                                    objXML.Append("<NUM_RIESGO>" + numriesgo + "</NUM_RIESGO>\n");
                                    riesgo = dtcoberturas.Rows[x1]["asegurado"].ToString();
                                }
                                else
                                {
                                    numriesgo = numriesgo + 1;
                                    riesgo = dtcoberturas.Rows[x1]["asegurado"].ToString();
                                    objXML.Append("<NUM_RIESGO>" + numriesgo + "</NUM_RIESGO>\n");
                                }

                            }
                            objXML.Append("<COD_CIA>1</COD_CIA>\n");
                            objXML.Append("<NUM_POLIZA></NUM_POLIZA>\n");
                            objXML.Append("<NUM_SPTO>0</NUM_SPTO>\n");
                            objXML.Append("<NUM_APLI>0</NUM_APLI>\n");
                            objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>\n");
                            objXML.Append("<COD_FRANQUICIA></COD_FRANQUICIA>\n");
                            objXML.Append("<COD_MON_CAPITAL>1</COD_MON_CAPITAL>\n");
                            objXML.Append("<TASA_COB>0</TASA_COB>\n");
                            objXML.Append("<IMP_AGR_SPTO>0</IMP_AGR_SPTO>\n");
                            objXML.Append("<IMP_AGR_REL_SPTO>0</IMP_AGR_REL_SPTO>\n");
                            objXML.Append("<NUM_PERIODO>1</NUM_PERIODO>\n");
                            objXML.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>\n");
                            objXML.Append("<MCA_VIGENTE>S</MCA_VIGENTE>\n");
                            objXML.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>\n");
                            objXML.Append("<MCA_BAJA_COB>N</MCA_BAJA_COB>\n");
                            objXML.Append("</ROW>\n");
                            row = row + 1;
                        }


                    }

                    objXML.Append("</ROWSET></TABLE>");

                }
            }
            else
            {

                ROW_NUM = 1;
                objXML.Append("<TABLE NAME=\"P2000040\"><ROWSET>");
                foreach (Hashtable hashDATO in DATOS_COBERTURAS)
                {
                    DATOS_AUX = (Hashtable)(hashDATO.Clone());
                    objP2000040.setDatos(DATOS_AUX);
                    objXML.Append(objP2000040.getXML(ROW_NUM));
                    ROW_NUM++;
                }
                objXML.Append("</ROWSET></TABLE>");
            }

            //Insertar Datos Contratante para cotizar P2300061_mmx

            if (ramo == 105)
            {
                //if (DATOS_CONT.Count > 0)
                //{
                //    objXML.Append(getXmlP2300060_MMX(DATOS_CONT));
                //    objXML.Append("</XML>");
                //}
                //else
                //{

                if (m_accion == "C")
                {
                    DataTable dtAsegurados = ((DataTable)Session["Asegurados"]).Copy();
                    //DataTable dtBeneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();


                    DataTable asegurados = dtasgurados.setAsegurados();



                    int nc = asegurados.Rows.Count;
                    //int nb = dtBeneficiarios.Rows.Count;
                    int x1;
                    int x2;
                    int row = 1;
                    objXML.Append("<TABLE NAME=\"P2300060_MMX\"><ROWSET>");
                    for (x1 = 0; x1 <= nc - 1; x1++)
                    {
                        objXML.Append("<ROW num=\"" + Convert.ToInt32(x1 + 1) + "\">");
                        if (asegurados.Rows[x1]["cod_parent"].ToString() == "37")
                        {
                            objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1) + "</NUM_RIESGO>");
                            objXML.Append("<NUM_SECU>2</NUM_SECU>");
                        }
                        else
                        {
                            objXML.Append("<NUM_RIESGO>" + Convert.ToInt32(x1 + 1) + "</NUM_RIESGO>");
                            objXML.Append("<NUM_SECU>1</NUM_SECU>");
                        }

                        objXML.Append("<COD_PARENTESCO>" + asegurados.Rows[x1]["cod_parent"].ToString() + "</COD_PARENTESCO>");
                        if (asegurados.Rows[x1]["cod_parent"].ToString() == "38")
                        {
                            objXML.Append("<NOM_PARENTESCO>MENOR</NOM_PARENTESCO>");
                        }
                        if (asegurados.Rows[x1]["cod_parent"].ToString() == "37")
                        {
                            objXML.Append("<NOM_PARENTESCO>MANCOMUNADO</NOM_PARENTESCO>");
                        }
                        if (asegurados.Rows[x1]["cod_parent"].ToString() == "4")
                        {
                            objXML.Append("<NOM_PARENTESCO>TITULAR</NOM_PARENTESCO>");
                        }

                        objXML.Append("<FEC_NACIMIENTO>" + asegurados.Rows[x1]["fec_nac"].ToString() + "</FEC_NACIMIENTO>");
                        objXML.Append("<MCA_SEXO>0</MCA_SEXO>");
                        objXML.Append("<MCA_FUMA>0</MCA_FUMA>");
                        objXML.Append("<TIP_BENEF>2</TIP_BENEF>");
                        objXML.Append("<COD_CIA>1</COD_CIA>");
                        objXML.Append("<NUM_POLIZA></NUM_POLIZA>");
                        objXML.Append("<NUM_SPTO>0</NUM_SPTO>");
                        objXML.Append("<NUM_APLI>0</NUM_APLI>");
                        objXML.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>");
                        objXML.Append("</ROW>");
                    }
                    objXML.Append("</ROWSET></TABLE>");
                }
                objXML.Append("</XML>");
                //}
            }
            else
            {
                if (DATOS_CONT.Count > 0)
                {
                    objXML.Append(getXmlP2300060_MMX(DATOS_CONT));
                }

                objXML.Append("</XML>");
            }
            string XML;
            XML = objXML.ToString();


            CDEmision objCotiza = new CDEmision();
            //if (Convert.ToInt32(Session["RAMO"]) == 105)
            //{
            //    return objCotiza.setCotizacionEmision(XML, conexion);
            //}
            //else
            //{
            return objCotiza.setCotizacionEmision(XML, token, conexion);
            //}

        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Cotizacion.setCotizacionEmision(2) : " + ex.Message);
        }
    }

    public string setP2300061(string poliza, int riesgo, string codBenef, int numSecu, string tipBenef, string tipDocum, string codDocum, string txtAdicional, OracleConnection conexion)
    {
        MCommand cmd = new MCommand();
        DataRow objDR;
        try
        {
            cmd.Connection = conexion;
            cmd.CommandText = "ev_k_emisiones_web.p_inserta_p2300061";//USUSOLVI

            cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
            cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, poliza);
            cmd.agregarINParametro("p_num_spto", OracleDbType.Int32, 0);
            cmd.agregarINParametro("p_num_apli", OracleDbType.Int32, 0);
            cmd.agregarINParametro("p_num_spto_apli", OracleDbType.Int32, 0);
            cmd.agregarINParametro("p_num_riesgo", OracleDbType.Int32, riesgo);
            cmd.agregarINParametro("p_cod_benef", OracleDbType.Varchar2, codBenef);
            cmd.agregarINParametro("p_num_secu", OracleDbType.Int32, numSecu);
            cmd.agregarINParametro("p_tip_benef", OracleDbType.Varchar2, tipBenef);
            cmd.agregarINParametro("p_tip_docum", OracleDbType.Varchar2, tipDocum);
            cmd.agregarINParametro("p_cod_docum", OracleDbType.Varchar2, codDocum);
            cmd.agregarINParametro("p_txt_adicional", OracleDbType.Varchar2, txtAdicional);
            cmd.agregarOUTParametro("p_result", OracleDbType.Varchar2, 100);

            objDR = cmd.ejecutarRegistroSP();

            return objDR["p_result"].ToString();
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR USUSOLVI.EV_K_INSERTA_SOLICITUDES_MMX.P_INSERTA_P2300061: " + ex.Message);
        }
    }

    /// <summary>Arregla los beneficiarios para ser guardados en tablas</summary>
    /// <param name="poliza">N�mero de p�liza</param>
    /// <param name="DATOS_BENEF">Arreglo con beneficiarios</param>
    /// <param name="conexion">Conexi�n a la base de datos</param>
    public void setBenef(string poliza, ArrayList DATOS_BENEF, OracleConnection conexion)
    {
        try
        {
            if (DATOS_BENEF.Count > 0)
            {
                string codBenef = "";
                foreach (Hashtable hashDATO in DATOS_BENEF)
                {
                    if (hashDATO != null)
                    {
                        if (hashDATO["TIP_BENEF"].ToString() != "10")
                        {
                            if (hashDATO["TIP_BENEF"].ToString() == "6")
                                codBenef = hashDATO["COD_DOCUM"].ToString();
                            else
                            {
                                int riesgo = Convert.ToInt32(hashDATO["NUM_RIESGO"]);
                                int numSecu = Convert.ToInt32(hashDATO["NUM_SECU"]);
                                string tipBenef = hashDATO["TIP_BENEF"].ToString();
                                string tipDocum = hashDATO["TIP_DOCUM"].ToString();
                                string codDocum = hashDATO["COD_DOCUM"].ToString();

                                string result = setP2300061(poliza, riesgo, codBenef, numSecu, tipBenef, tipDocum, codDocum, null, conexion);
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    /// <summary>Obtiene la secuancia del CLI</summary>
    /// <returns>N�mero para el CLI</returns>
    public string getSecuCLI(OracleConnection conexion)
    {
        MCommand cmd = new MCommand();
        DataRow objDR;
        try
        {
            cmd.Connection = conexion;
            cmd.CommandText = "ev_k_emisiones_web.p_secuencia_cli";
            cmd.agregarOUTParametro("p_secuencia", OracleDbType.Double, 5);

            objDR = cmd.ejecutarRegistroSP();

            return objDR["p_secuencia"].ToString();
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR : " + ex.Message);
        }
    }


    //Agregado a la  clase Emisi�n GRA 05/08/2011.
    public string getXmlP2300060_MMX(Hashtable DATOS_CONT)
    {
        string strXml = "";
        string FEC_NACIMIENTO = "";
        string MCA_SEXO = "";
        string MCA_FUMA = "";
        //APL ini
        try
        {
            if (Session["TipoPLan"].ToString() != "16")
            {
                FEC_NACIMIENTO = DATOS_CONT["FEC_NACIMIENTO"].ToString();
                MCA_SEXO = DATOS_CONT["MCA_SEXO"].ToString();
                MCA_FUMA = DATOS_CONT["MCA_FUMA"].ToString();
                strXml = TablaP2300060_MMX(FEC_NACIMIENTO, MCA_SEXO, MCA_FUMA);
            }
            else
            {
                try
                {
                    strXml = TablaP2300060_MMX(DATOS_CONT);
                    Session["strXml"] = strXml;
                }
                catch
                {
                    try
                    {
                        //            FEC_NACIMIENTO = "01/01/2007";
                        //            MCA_SEXO = "0";
                        //            MCA_FUMA = "0";
                        //            //strXml = TablaP2300060_MMX(FEC_NACIMIENTO, MCA_SEXO, MCA_FUMA);
                        //            StringBuilder tblP2300060_MMX = new StringBuilder();
                        //             tblP2300060_MMX.Append(@"<TABLE NAME=""P2300060_MMX""><ROWSET>");
                        //            tblP2300060_MMX.Append(@"<ROW num=""1""><NUM_RIESGO>1</NUM_RIESGO><NUM_POLIZA></NUM_POLIZA><NUM_SPTO>0</NUM_SPTO><COD_CIA>1</COD_CIA><NUM_APLI>0</NUM_APLI><COD_PARENTESCO>38</COD_PARENTESCO><FEC_NACIMIENTO>01/01/2007</FEC_NACIMIENTO><NUM_SPTO_APLI>0</NUM_SPTO_APLI><MCA_FUMA>0</MCA_FUMA><MCA_SEXO>0</MCA_SEXO><NUM_SECU>1</NUM_SECU><TIP_BENEF>2</TIP_BENEF></ROW>");
                        //           tblP2300060_MMX.Append(@"</ROWSET></TABLE>");
                        ////return tblP2300060_MMX.ToString();
                        ////            strXml = "<TABLE NAME=""P2300060_MMX""><ROWSET><ROW num=""1""><NUM_RIESGO>1</NUM_RIESGO><NUM_POLIZA></NUM_POLIZA><NUM_SPTO>0</NUM_SPTO><COD_CIA>1</COD_CIA><NUM_APLI>0</NUM_APLI><COD_PARENTESCO>38</COD_PARENTESCO><FEC_NACIMIENTO>01/01/2007</FEC_NACIMIENTO><NUM_SPTO_APLI>0</NUM_SPTO_APLI><MCA_FUMA>0</MCA_FUMA><MCA_SEXO>0</MCA_SEXO><NUM_SECU>1</NUM_SECU><TIP_BENEF>2</TIP_BENEF></ROW></ROWSET></TABLE>";
                        strXml = Convert.ToString(Session["strXml"]);
                    }
                    catch (Exception e)
                    {

                    }
                }
            }
            //APL fin
        }
        catch
        {
            try
            {
                strXml = TablaP2300060_MMX(DATOS_CONT);
                Session["strXml"] = strXml;
            }
            catch
            {
                try
                {
                    //            FEC_NACIMIENTO = "01/01/2007";
                    //            MCA_SEXO = "0";
                    //            MCA_FUMA = "0";
                    //            //strXml = TablaP2300060_MMX(FEC_NACIMIENTO, MCA_SEXO, MCA_FUMA);
                    //            StringBuilder tblP2300060_MMX = new StringBuilder();
                    //             tblP2300060_MMX.Append(@"<TABLE NAME=""P2300060_MMX""><ROWSET>");
                    //            tblP2300060_MMX.Append(@"<ROW num=""1""><NUM_RIESGO>1</NUM_RIESGO><NUM_POLIZA></NUM_POLIZA><NUM_SPTO>0</NUM_SPTO><COD_CIA>1</COD_CIA><NUM_APLI>0</NUM_APLI><COD_PARENTESCO>38</COD_PARENTESCO><FEC_NACIMIENTO>01/01/2007</FEC_NACIMIENTO><NUM_SPTO_APLI>0</NUM_SPTO_APLI><MCA_FUMA>0</MCA_FUMA><MCA_SEXO>0</MCA_SEXO><NUM_SECU>1</NUM_SECU><TIP_BENEF>2</TIP_BENEF></ROW>");
                    //           tblP2300060_MMX.Append(@"</ROWSET></TABLE>");
                    ////return tblP2300060_MMX.ToString();
                    ////            strXml = "<TABLE NAME=""P2300060_MMX""><ROWSET><ROW num=""1""><NUM_RIESGO>1</NUM_RIESGO><NUM_POLIZA></NUM_POLIZA><NUM_SPTO>0</NUM_SPTO><COD_CIA>1</COD_CIA><NUM_APLI>0</NUM_APLI><COD_PARENTESCO>38</COD_PARENTESCO><FEC_NACIMIENTO>01/01/2007</FEC_NACIMIENTO><NUM_SPTO_APLI>0</NUM_SPTO_APLI><MCA_FUMA>0</MCA_FUMA><MCA_SEXO>0</MCA_SEXO><NUM_SECU>1</NUM_SECU><TIP_BENEF>2</TIP_BENEF></ROW></ROWSET></TABLE>";
                    strXml = Convert.ToString(Session["strXml"]);
                }
                catch (Exception e)
                {

                }
            }
        }
        return strXml;
    }

    public string TablaP2300060_MMX(string FEC_NACIMIENTO, string MCA_SEXO, string MCA_FUMA)
    {
        StringBuilder tblP2300060_MMX = new StringBuilder();

        tblP2300060_MMX.Append(@"<TABLE NAME=""P2300060_MMX""><ROWSET>");
        tblP2300060_MMX.Append(@"<ROW num=""1"">" + setRowP2300060_MMX(FEC_NACIMIENTO, MCA_SEXO, MCA_FUMA) + "</ROW>");
        tblP2300060_MMX.Append(@"</ROWSET></TABLE>");
        return tblP2300060_MMX.ToString();
    }

    public string setRowP2300060_MMX(string FEC_NACIMIENTO, string MCA_SEXO, string MCA_FUMA)
    {
        StringBuilder strRow = new StringBuilder();
        string Clave = "";
        string Valor = "";
        Hashtable tblRow = new Hashtable();

        tblRow.Add("FEC_NACIMIENTO", FEC_NACIMIENTO);
        tblRow.Add("MCA_SEXO", MCA_SEXO);
        tblRow.Add("MCA_FUMA", MCA_FUMA);

        tblRow.Add("NUM_POLIZA", "");
        tblRow.Add("NUM_SPTO", "0");
        tblRow.Add("NUM_APLI", "0");
        tblRow.Add("NUM_SPTO_APLI", "0");
        tblRow.Add("NUM_RIESGO", "1");

        tblRow.Add("TIP_BENEF", "1");
        tblRow.Add("NUM_SECU", "1");
        tblRow.Add("COD_CIA", "1");

        foreach (DictionaryEntry Dic in tblRow)
        {
            Clave = Dic.Key.ToString();
            Valor = Dic.Value.ToString();
            strRow.Append("<" + Clave.ToUpper() + ">");
            strRow.Append(Valor.ToUpper());
            strRow.Append("</" + Clave.ToUpper() + ">");
        }

        return strRow.ToString();
    }

    #region Unit Linked  
    //Unit Linked Cotizacion INI
    public DataSet getCotizacionUL(String[] arrDatosPoliza, String[] arrDatosVar, String[] arrDatosCob, String[] arrDatosCont, String[] arrDatosSol, String[] arrDatosBenef, String[] arrDatosBanco, String[] arrDatosComplementarios)
    {
        CDEmision objCotizaCalculo = new CDEmision();
        DataRow drCotizacion;
        DataSet objDS;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                drCotizacion = setEmisionUL(arrDatosPoliza, arrDatosVar, arrDatosCob, arrDatosCont, arrDatosSol, arrDatosBenef, arrDatosBanco, arrDatosComplementarios, conexion);
                if (drCotizacion[0] != System.DBNull.Value)
                {
                    objDS = objCotizaCalculo.getCalculos(drCotizacion[0].ToString(), conexion);
                    Session.Add("numCotizacion", drCotizacion[0].ToString());
                    DataTable objTabla = new DataTable();
                    objTabla.Columns.Add("COTIZACION");
                    DataRow objRow = objTabla.NewRow();
                    objRow["COTIZACION"] = drCotizacion[0].ToString();
                    objTabla.Rows.Add(objRow);
                    objDS.Tables.Add(objTabla);
                }
                else throw new Exception(drCotizacion[1].ToString());
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            string strMensaje = "";
            try
            {
                using (OracleConnection conexion = MConexion.getConexion("ConnectionSeGATEMP"))
                    strMensaje = ExceptionUtil.TWDescripcion(ex.Message, "TRONWEB", conexion);
            }
            catch
            {
                strMensaje = ex.Message;
            }
            throw new Exception(strMensaje);
        }

        /*~~~~~~~~~~~~~~~~~~~~~~EVENTO~~~~~~~~~~~~~~~~~~~~~~~~*/
        try
        {
            Usuario objUsuario = (Usuario)(Session["sUSUARIO"]);
            //     int evento = Convert.ToInt32(WebUtils.getAppSetting("EventoCotizacion"));
            int agente = Convert.ToInt32(arrDatosPoliza[2].Split('=')[1]);
            String cod_prod = (String)Session["CodProd"];
            using (OracleConnection conexion = MConexion.getConexion("ConnectionSeGA"))
            {
                switch (cod_prod) {
                    case "1":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoCodProd1_Cot"].ToString()), drCotizacion[0].ToString(), "", agente, false, conexion);
                        break;
                    case "2":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoCodProd2_Cot"].ToString()), drCotizacion[0].ToString(), "", agente, false, conexion);
                        break;
                    case "3":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoCodProd3_Cot"].ToString()), drCotizacion[0].ToString(), "", agente, false, conexion);
                        break;

                }
                //EventoUtil.registraEvento(objUsuario.USUARIO, 1, evento, drCotizacion[0].ToString(), "", agente, false, conexion);
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
        }
        /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
        return objDS;
    }

    public DataRow setEmisionUL(String[] DATOS_POLIZA, String[] DATOS_VARIABLES, String[] DATOS_COBERTURA, String[] DATOS_CONT, String[] DATOS_SOL, String[] DATOS_BENEF, String[] DATOS_BANCO, String[] DATOS_COMPLEMENTARIOS, OracleConnection conexion)
    {
        ArrayList arrDATOS_VARIABLES = new ArrayList();
        ArrayList arrDATOS_COBERTURA = new ArrayList();
        ArrayList arrDATOS_BENEF = new ArrayList();
        ArrayList arrDATOS_COMPLEMENTARIOS = new ArrayList();
        Hashtable hashDATOS_POLIZA = new Hashtable();
        Hashtable hashDATOS_CONT = new Hashtable();
        Hashtable hashDATOS_SOL = new Hashtable();
        Hashtable hashDATOS_BANCO = new Hashtable();
        Hashtable hashDATOS_COMPLEMENTARIOS = new Hashtable();
        Hashtable hash_REGISTRO;
        String[] arrVAL_AUX;
        String[] arrAUX;

        try
        {
            // Datos Poliza
            foreach (string DATO in DATOS_POLIZA)
            {
                if (DATO != null)
                {
                    arrAUX = DATO.Split('=');
                    if (arrAUX[0].ToString() == "MCA_SF" && arrAUX[1].ToString() == "S") checkSF = true;
                    hashDATOS_POLIZA.Add(arrAUX[0], arrAUX[1]);
                }
            }


            // Datos Variables
            foreach (string VARIABLES in DATOS_VARIABLES)
            {
                if (VARIABLES != null)
                {
                    hash_REGISTRO = new Hashtable();
                    arrVAL_AUX = VARIABLES.Split('|');
                    foreach (string DATO in arrVAL_AUX)
                    {
                        arrAUX = DATO.Split('=');
                        hash_REGISTRO.Add(arrAUX[0], arrAUX[1]);
                    }
                    arrDATOS_VARIABLES.Add(hash_REGISTRO);
                }
            }


            // Datos Cobertura
            foreach (string COBERTURA in DATOS_COBERTURA)
            {
                if (COBERTURA != null)
                {
                    hash_REGISTRO = new Hashtable();
                    arrVAL_AUX = COBERTURA.Split('|');
                    foreach (string DATO in arrVAL_AUX)
                    {
                        arrAUX = DATO.Split('=');
                        hash_REGISTRO.Add(arrAUX[0], arrAUX[1]);
                    }
                    arrDATOS_COBERTURA.Add(hash_REGISTRO);
                }
            }


            // Datos Contratante
            foreach (string DATO in DATOS_CONT)
            {
                if (DATO != null)
                {
                    arrAUX = DATO.Split('=');
                    hashDATOS_CONT.Add(arrAUX[0], arrAUX[1]);
                }
            }


            // Datos Solicitante
            foreach (string DATO in DATOS_SOL)
            {
                if (DATO != null)
                {
                    arrAUX = DATO.Split('=');
                    hashDATOS_SOL.Add(arrAUX[0], arrAUX[1]);
                }
            }


            // Datos Beneficiario
            foreach (string BENEFICIARIO in DATOS_BENEF)
            {
                if (BENEFICIARIO != null)
                {
                    hash_REGISTRO = new Hashtable();
                    arrVAL_AUX = BENEFICIARIO.Split('|');
                    foreach (string DATO in arrVAL_AUX)
                    {
                        arrAUX = DATO.Split('=');
                        hash_REGISTRO.Add(arrAUX[0], arrAUX[1]);
                    }
                    arrDATOS_BENEF.Add(hash_REGISTRO);
                }
            }
            Session.Add("arrBenef", arrDATOS_BENEF);

            //Datos Complementarios
            foreach (string COMPLEMENTARIOS in DATOS_COMPLEMENTARIOS)
            {
                if (COMPLEMENTARIOS != null)
                {
                    hash_REGISTRO = new Hashtable();
                    arrVAL_AUX = COMPLEMENTARIOS.Split('|');
                    foreach (string DATO in arrVAL_AUX)
                    {
                        arrAUX = DATO.Split('=');
                        hash_REGISTRO.Add(arrAUX[0], arrAUX[1]);
                    }
                    arrDATOS_COMPLEMENTARIOS.Add(hash_REGISTRO);
                }
            }

            // Datos Bancarios
            foreach (string DATO in DATOS_BANCO)
            {
                if (DATO != null)
                {
                    arrAUX = DATO.Split('=');
                    hashDATOS_BANCO.Add(arrAUX[0], arrAUX[1].ToUpper());
                }
            }

            return setEmisionUL(hashDATOS_POLIZA, arrDATOS_VARIABLES, arrDATOS_COBERTURA, hashDATOS_CONT, hashDATOS_SOL, arrDATOS_BENEF, hashDATOS_BANCO, arrDATOS_COMPLEMENTARIOS, conexion);

        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Cotizacion.setCotizacionEmision(1) : " + ex.Message);
        }
    }

    /// <summary>M�todo en donde se arma el XMl para la Emisi�n.</summary>
    public DataRow setEmisionUL(Hashtable DATOS_POLIZA, ArrayList DATOS_VARIABLES, ArrayList DATOS_COBERTURAS, Hashtable DATOS_CONT, Hashtable DATOS_SOL, ArrayList DATOS_BENEF, Hashtable DATOS_BANCO, ArrayList DATOS_COMPLEMENTARIOS, OracleConnection conexion)
    {
        int ROW_NUM;
        StringBuilder objXML = new StringBuilder();
        Hashtable DATOS_AUX = new Hashtable();
        P2000030 objP2000030 = new P2000030();
        P2000031 objP2000031 = new P2000031();
        P2000040 objP2000040 = new P2000040();
        P2000060 objP2000060 = new P2000060();
        P2000025 objP2000025 = new P2000025();
        P2300061_MMX objP2300061_MMX = new P2300061_MMX();
        MapfreMMX.emision.tabla.P2000020 objP2000020 = new MapfreMMX.emision.tabla.P2000020();

        try
        {
            // Encabezado del XML
            objXML.Append("<XML ACCION=\"" + m_accion + "\" COD_RAMO=\"");
            objXML.Append(DATOS_POLIZA["COD_RAMO"]);
            objXML.Append("\" NUM_POLIZA=\"\" COD_ORIGEN=\"");
            objXML.Append(WebUtils.getAppSetting("codOrigen"));

            //MGM_MSI
            if (Session["BanderaMSI"] != null)
            {
                if (Session["BanderaMSI"].ToString() == "True")
                {
                    objXML.Append("\" MCA_BASICO_STD=\"S");
                }
            }
            //AEP BWMEILL.Mill�n Vida
            //if (DATOS_POLIZA["COD_RAMO"].ToString()=="111")
            //{
            //    if (Session["TipoPagoMV"].ToString() =="DB")
            //        objXML.Append("\" MCA_BASICO_STD=\"S");

            //}

            objXML.Append("\">");


            DATOS_POLIZA.Add("COD_USR", WebUtils.getAppSetting("codUsuario"));


            // Se Genera el Nodo de la Tabla P2000030
            ROW_NUM = 1;
            objXML.Append("<TABLE NAME=\"P2000030\"><ROWSET>");
            objP2000030.setDatos(DATOS_POLIZA);
            objXML.Append(objP2000030.getXML(ROW_NUM));
            objXML.Append("</ROWSET></TABLE>");


            // Se Genera el Nodo de la Tabla P2000031
            ROW_NUM = 1;
            objXML.Append("<TABLE NAME=\"P2000031\"><ROWSET>");
            objP2000031.setDatos(DATOS_POLIZA);
            objXML.Append(objP2000031.getXML(ROW_NUM));
            objXML.Append("</ROWSET></TABLE>");

            // Se Genera el Nodo de la Tabla P2000025
            ROW_NUM = 1;
            objXML.Append("<TABLE NAME=\"P2000025\"><ROWSET>");
            foreach (Hashtable hashDATO in DATOS_COMPLEMENTARIOS)
            {
                DATOS_AUX = (Hashtable)(hashDATO.Clone());
                objP2000025.setDatos(DATOS_AUX);
                objXML.Append(objP2000025.getXML(ROW_NUM));
                ROW_NUM++;
            }
            objXML.Append("</ROWSET></TABLE>");

            // Se Genera el Nodo de la Tabla P2000020
            ROW_NUM = 1;
            objXML.Append("<TABLE NAME=\"P2000020\"><ROWSET>");
            foreach (Hashtable hashDATO in DATOS_VARIABLES)
            {
                DATOS_AUX = (Hashtable)(hashDATO.Clone());
                objP2000020.setDatos(DATOS_AUX);
                objXML.Append(objP2000020.getXML(ROW_NUM));
                ROW_NUM++;
            }
            objXML.Append("</ROWSET></TABLE>");


            // Se Genera el Nodo de la Tabla P2000060
            ROW_NUM = 1;
            DATOS_AUX = new Hashtable();
            objXML.Append("<TABLE NAME=\"P2000060\"><ROWSET>");
            objP2000060.setDatos(DATOS_SOL);
            objXML.Append(objP2000060.getXML(ROW_NUM));

            if (checkSF)
            {
                DATOS_AUX = (Hashtable)(DATOS_SOL.Clone());
                DATOS_AUX["TIP_BENEF"] = "10";
                objP2000060.setDatos(DATOS_AUX);
                objXML.Append(objP2000060.getXML(ROW_NUM));
            }

            // Beneficiario
            if (DATOS_BENEF.Count > 0)
            {
                ROW_NUM = 2;
                foreach (Hashtable hashDATO in DATOS_BENEF)
                {
                    DATOS_AUX = (Hashtable)(hashDATO.Clone());
                    objP2000060.setDatos(DATOS_AUX);
                    objXML.Append(objP2000060.getXML(ROW_NUM));
                    ROW_NUM++;
                }
            }
            objXML.Append("</ROWSET></TABLE>");


            // Se Genera el Nodo de la Tabla P2000040
            ROW_NUM = 1;
            objXML.Append("<TABLE NAME=\"P2000040\"><ROWSET>");
            foreach (Hashtable hashDATO in DATOS_COBERTURAS)
            {
                DATOS_AUX = (Hashtable)(hashDATO.Clone());
                objP2000040.setDatos(DATOS_AUX);
                objXML.Append(objP2000040.getXML(ROW_NUM));
                ROW_NUM++;
            }
            objXML.Append("</ROWSET></TABLE>");

            //Insertar Datos Contratante para cotizar P2300061_mmx
            if (DATOS_CONT.Count > 0)
            {
                objXML.Append(getXmlP2300060_MMX(DATOS_CONT));
            }

            objXML.Append("</XML>");

            string XML;
            XML = objXML.ToString();

            CDEmision objCotiza = new CDEmision();
            return objCotiza.setCotizacionEmision(XML, token, conexion);

        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Cotizacion.setCotizacionEmision(2) : " + ex.Message);
        }
    }

    //Unit Linked Cotizacion FIN

    public string getEmisionUL(String[] arrDatosPoliza, String[] arrDatosVar, String[] arrDatosCob, String[] arrDatosCont, String[] arrDatosSol, String[] arrDatosBenef, String[] arrDatosBanco, String[] arrDatosComplementarios)
    {
        CDEmision objCotizaCalculo = new CDEmision();
        DataRow drEmision;
        string resultado;
        Session.Remove("arrBenef");
        try
        {


            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                drEmision = setEmisionUL(arrDatosPoliza, arrDatosVar, arrDatosCob, arrDatosCont, arrDatosSol, arrDatosBenef, arrDatosBanco, arrDatosComplementarios, conexion);

                if (drEmision[0] != System.DBNull.Value)
                {
                    resultado = drEmision[0].ToString();
                    if (Session["arrBenef"] != null)
                        setBenef(resultado, ((ArrayList)Session["arrBenef"]), conexion);
                }
                else
                {
                    resultado = "No se pudo realizar la Emisi�n de su P�liza " + drEmision[1].ToString();
                    throw new Exception(resultado);
                }
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            string strMensaje = "";
            try
            {
                using (OracleConnection conexion = MConexion.getConexion("ConnectionSeGATEMP"))
                    strMensaje = ExceptionUtil.TWDescripcion(ex.Message, "TRONWEB", conexion);
            }
            catch
            {
                strMensaje = ex.Message;
            }
            throw new Exception(strMensaje);
        }

        /*~~~~~~~~~~~~~~~~~~~~~~EVENTO~~~~~~~~~~~~~~~~~~~~~~~~*/
        try
        {
            Usuario objUsuario = (Usuario)(Session["sUSUARIO"]);
            string ramo = resultado.Substring(0, 3);
            //   int evento = Convert.ToInt32(WebUtils.getAppSetting("EventoEmision" + ramo));
            int agente = Convert.ToInt32(arrDatosPoliza[2].Split('=')[1]);
            String cod_prod = (String)Session["CodProd"];
            using (OracleConnection conexionTEMP = MConexion.getConexion("ConnectionSeGA"))
            {
                switch (cod_prod)
                {
                    case "1":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoCodProd1_Emi"].ToString()), resultado, "", objUsuario.COD_AGENTE, false, conexionTEMP);
                        break;
                    case "2":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoCodProd2_Emi"].ToString()), resultado, "", objUsuario.COD_AGENTE, false, conexionTEMP);
                        break;
                    case "3":
                        EventoUtil.registraEvento(objUsuario.USUARIO, 1, Convert.ToInt32(ConfigurationManager.AppSettings["EventoCodProd3_Emi"].ToString()), resultado, "", objUsuario.COD_AGENTE, false, conexionTEMP);
                        break;
                }
                //EventoUtil.registraEvento(objUsuario.USUARIO, 1, evento, resultado, "", objUsuario.COD_AGENTE, false, conexionTEMP);
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
        }
        /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
        return resultado;
    }
    #endregion
    public string TablaP2300060_MMX(Hashtable Datos_Cont)
    {
        StringBuilder tblP2300060_MMX = new StringBuilder();
        String comillas = "\"";
        tblP2300060_MMX.Append(@"<TABLE NAME=""P2300060_MMX""><ROWSET>");
        for(int i = 0; i < Datos_Cont.Count; i++)
        {
            String datos = Datos_Cont[i+1].ToString();
            String[] dato = datos.Split('|');
            tblP2300060_MMX.Append(@"<ROW num="+comillas+(i+1)+comillas+">"+ setRowP2300060_MMX(dato[0].ToString(),dato[1].ToString(),dato[2].ToString(),dato[3].ToString(),dato[4].ToString(),i+1) + "</ROW>");
            //tblP2300060_MMX.Append(@"<ROW num=""1"">" + setRowP2300060_MMX(FEC_NACIMIENTO, MCA_SEXO, MCA_FUMA) + "</ROW>");
        }
        tblP2300060_MMX.Append(@"</ROWSET></TABLE>");
        return tblP2300060_MMX.ToString();

    }
    public string setRowP2300060_MMX(string FEC_NACIMIENTO, string MCA_SEXO, string MCA_FUMA,string TIP_BENEF,string COD_PARENTESCO,int NUM_RIESGO)
    {
        StringBuilder strRow = new StringBuilder();
        string Clave = "";
        string Valor = "";
        Hashtable tblRow = new Hashtable();
        String[] aux;

        aux = FEC_NACIMIENTO.Split('=');
        tblRow.Add("FEC_NACIMIENTO", aux[1].ToString());
        aux = MCA_SEXO.Split('=');
        tblRow.Add("MCA_SEXO", aux[1].ToString());
        aux = MCA_FUMA.Split('=');
        tblRow.Add("MCA_FUMA", aux[1].ToString());

        tblRow.Add("NUM_POLIZA", "");
        tblRow.Add("NUM_SPTO", "0");
        tblRow.Add("NUM_APLI", "0");
        tblRow.Add("NUM_SPTO_APLI", "0");
        aux = COD_PARENTESCO.Split('=');
        tblRow.Add("COD_PARENTESCO",aux[1].ToString());

        if (aux[1].ToString() == "37")
        {
            NUM_RIESGO = NUM_RIESGO - 1;
            tblRow.Add("NUM_SECU", "2");
        }
        else
            tblRow.Add("NUM_SECU", "1");

        tblRow.Add("NUM_RIESGO", NUM_RIESGO.ToString());


        aux = TIP_BENEF.Split('=');
        tblRow.Add("TIP_BENEF", aux[1].ToString());
        //tblRow.Add("NUM_SECU", "1");
        tblRow.Add("COD_CIA", "1");

        foreach (DictionaryEntry Dic in tblRow)
        {
            Clave = Dic.Key.ToString();
            Valor = Dic.Value.ToString();
            strRow.Append("<" + Clave.ToUpper() + ">");
            strRow.Append(Valor.ToUpper());
            strRow.Append("</" + Clave.ToUpper() + ">");
        }

        return strRow.ToString();
    }


}