using System;
using System.Text;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for P2990706_MMX
/// </summary>
public class P2990706_MMX
{
    private string XML_CTE;
    private string XML_VAR;

	public P2990706_MMX()
	{
        StringBuilder objSB = new StringBuilder();
        objSB.Append("<NUM_POLIZA></NUM_POLIZA>");
        objSB.Append("<NUM_SPTO>0</NUM_SPTO>");
        objSB.Append("<COD_CIA>1</COD_CIA>");
        objSB.Append("<FEC_ACTU>" + DateTime.Today.ToShortDateString() + "</FEC_ACTU>");
        objSB.Append("<FEC_EFEC_POLIZA>" + DateTime.Today.ToShortDateString() + "</FEC_EFEC_POLIZA>");
        objSB.Append("<FEC_EFEC_SPTO>" + DateTime.Today.ToShortDateString() + "</FEC_EFEC_SPTO>");
        objSB.Append("<FEC_VCTO_POLIZA>" + DateTime.Today.AddYears(1).ToShortDateString() + "</FEC_VCTO_POLIZA>");
        objSB.Append("<FEC_VCTO_SPTO>" + DateTime.Today.AddYears(1).ToShortDateString() + "</FEC_VCTO_SPTO>");
        objSB.Append("<COD_MON>1</COD_MON>");
        this.XML_CTE = objSB.ToString();
	}

    public void setDatos(Hashtable DATOS)
    {
        StringBuilder objSB = new StringBuilder();
        String[] arrCAMPOS = MapfreMMX.util.WebUtils.getAppSetting("DATOS_P2990706_MMX").Split(',');
        try
        {
            foreach (String CAMPO in arrCAMPOS)
            {
                objSB.Append("<");
                objSB.Append(CAMPO);
                objSB.Append(">");
                objSB.Append(DATOS[CAMPO]);
                objSB.Append("</");
                objSB.Append(CAMPO);
                objSB.Append(">");
            }
            this.XML_VAR = objSB.ToString();
        }
        catch (Exception ex)
        {
            throw new Exception("ERROR P2990706_MMX.setDatos() : " + ex.Message);
        }
    }

    public string getXML(int ROW_NUM)
    {
        StringBuilder objSB = new StringBuilder();
        try
        {
            objSB.Append("<ROW num=\"");
            objSB.Append(ROW_NUM);
            objSB.Append("\">");
            objSB.Append(this.XML_VAR);
            objSB.Append(this.XML_CTE);
            objSB.Append("</ROW>");
        }
        catch (Exception ex)
        {
            throw new Exception("ERROR P2990706_MMX.getXML() : " + ex.Message);
        }
        return objSB.ToString();
    }
}
