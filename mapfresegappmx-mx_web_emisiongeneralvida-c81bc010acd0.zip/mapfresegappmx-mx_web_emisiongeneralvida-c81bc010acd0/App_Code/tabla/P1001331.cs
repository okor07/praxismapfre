using System;
using System.Text;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for P1001331
/// </summary>
public class P1001331
{
    private string XML_CTE;
    private string XML_VAR;

	public P1001331()
	{
        StringBuilder objSB = new StringBuilder();
        objSB.Append("<COD_CIA>1</COD_CIA>");
        objSB.Append("<TIP_MVTO_BATCH>3</TIP_MVTO_BATCH>");
        objSB.Append("<COD_ACT_TERCERO>1</COD_ACT_TERCERO>");
        objSB.Append("<COD_IDIOMA>ES</COD_IDIOMA>");
        objSB.Append("<TXT_AUX1>NR</TXT_AUX1>");
        objSB.Append("<FEC_TRATAMIENTO>" + DateTime.Today.ToShortDateString() + "</FEC_TRATAMIENTO>");
        objSB.Append("<FEC_ACTU>" + DateTime.Today.ToShortDateString() + "</FEC_ACTU>");
        objSB.Append("<COD_CALIDAD>1</COD_CALIDAD>");
        objSB.Append("<TIP_ETIQUETA>1</TIP_ETIQUETA>");
        objSB.Append("<TLF_PAIS></TLF_PAIS>");
        objSB.Append("<TLF_ZONA></TLF_ZONA>");
        

        this.XML_CTE = objSB.ToString();
	}

    public void setDatos(Hashtable DATOS)
    {
        StringBuilder objSB = new StringBuilder();
        String[] arrCAMPOS = MapfreMMX.util.WebUtils.getAppSetting("DATOS_P1001331").Split(',');
        try
        {
            foreach (String CAMPO in arrCAMPOS)
            {
                objSB.Append("<");
                objSB.Append(CAMPO);
                objSB.Append(">");
                objSB.Append(DATOS[CAMPO]);
                objSB.Append("</");
                objSB.Append(CAMPO);
                objSB.Append(">");
            }
            this.XML_VAR = objSB.ToString();
        }
        catch (Exception ex)
        {
            throw new Exception("ERROR P1001331.setDatos() : " + ex.Message);
        }
    }

    public string getXML(int ROW_NUM)
    {
        StringBuilder objSB = new StringBuilder();
        try
        {
            objSB.Append("<ROW num=\"");
            objSB.Append(ROW_NUM);
            objSB.Append("\">");
            objSB.Append(this.XML_VAR);
            objSB.Append(this.XML_CTE);
            objSB.Append("</ROW>");
        }
        catch (Exception ex)
        {
            throw new Exception("ERROR P1001331.getXML() : " + ex.Message);
        }
        return objSB.ToString();
    }
}
