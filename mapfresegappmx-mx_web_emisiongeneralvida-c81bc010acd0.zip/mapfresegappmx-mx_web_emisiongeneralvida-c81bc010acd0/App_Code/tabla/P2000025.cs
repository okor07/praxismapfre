﻿using System;
using System.Text;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Descripción breve de P2000025
/// </summary>
public class P2000025
{
    private string XML_CTE;
    private string XML_VAR;

    public P2000025()
    {
        StringBuilder objSB = new StringBuilder();
        objSB.Append("<COD_CIA>1</COD_CIA>");
        objSB.Append("<NUM_POLIZA></NUM_POLIZA>");
        objSB.Append("<NUM_SPTO>0</NUM_SPTO>");
        objSB.Append("<NUM_APLI>0</NUM_APLI>");
        objSB.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>");
        objSB.Append("<MCA_BAJA_RIESGO>N</MCA_BAJA_RIESGO>");
        objSB.Append("<MCA_VIGENTE>S</MCA_VIGENTE>");
        objSB.Append("<MCA_VIGENTE_APLI>S</MCA_VIGENTE_APLI>");
        objSB.Append("<MCA_BAJA_OCURRENCIA>N</MCA_BAJA_OCURRENCIA>");
        objSB.Append("<IMP_OCURRENCIA>0</IMP_OCURRENCIA>");
        this.XML_CTE = objSB.ToString();
    }
    public void setDatos(Hashtable DATOS)
    {
        StringBuilder objSB = new StringBuilder();
        String[] arrCAMPOS = MapfreMMX.util.WebUtils.getAppSetting("DATOS_P2000025").Split(',');
        try
        {
            foreach (String CAMPO in arrCAMPOS)
            {
                objSB.Append("<");
                objSB.Append(CAMPO);
                objSB.Append(">");
                objSB.Append(DATOS[CAMPO]);
                objSB.Append("</");
                objSB.Append(CAMPO);
                objSB.Append(">");
            }
            this.XML_VAR = objSB.ToString();
        }
        catch (Exception ex)
        {
            throw new Exception("ERROR P2000025.setDatos() : " + ex.Message);
        }
    }

    public string getXML(int ROW_NUM)
    {
        StringBuilder objSB = new StringBuilder();
        try
        {
            objSB.Append("<ROW num=\"");
            objSB.Append(ROW_NUM);
            objSB.Append("\">");
            objSB.Append(this.XML_VAR);
            objSB.Append(this.XML_CTE);
            objSB.Append("</ROW>");
        }
        catch (Exception ex)
        {
            throw new Exception("ERROR P2000040.getXML() : " + ex.Message);
        }
        return objSB.ToString();
    }
}