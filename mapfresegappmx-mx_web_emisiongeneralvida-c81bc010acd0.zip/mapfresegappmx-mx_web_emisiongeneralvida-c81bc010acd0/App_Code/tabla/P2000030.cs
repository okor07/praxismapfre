using System;
using System.Text;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
//03052018

/// <summary>
/// Summary description for P2000030
/// </summary>
public class P2000030
{
    private string XML_CTE;
    private string XML_VAR;
    public P2000030()
    {
        int ramo = 0;
        StringBuilder objSB = new StringBuilder();
        int nc =0;
        int nr = 0;
        try
        {
            ramo = Convert.ToInt32(System.Web.HttpContext.Current.Session["RAMO"]);
        }
        catch
        {
            ramo = 0;
        }

        int ramo2 = 0;
        try
        {
            ramo2 = Convert.ToInt32(System.Web.HttpContext.Current.Session["RAMO"]);
        }
        catch
        { }

        try
        {
            if (ramo == 105 || ramo2 == 105)
            {
                MetodosAjax ma = new MetodosAjax();
                DataTable dt = ma.setAsegurados();
                nc = dt.Rows.Count;
                nr = nc;
                int x1;
                for (x1 = 0; x1 <= nc - 1; x1++)
                {
                    if (Convert.ToInt32(dt.Rows[x1]["cod_parent"]) == 37)
                    {
                        nr = nr - 1;
                    }
                }
            }
        }
        catch
        { }
        objSB.Append("<COD_CIA>1</COD_CIA>");
        objSB.Append("<COD_SECTOR>1</COD_SECTOR>");
        objSB.Append("<NUM_POLIZA></NUM_POLIZA>");
        objSB.Append("<NUM_SPTO>0</NUM_SPTO>");
        objSB.Append("<NUM_APLI>0</NUM_APLI>");
        objSB.Append("<NUM_SPTO_APLI>0</NUM_SPTO_APLI>");
        objSB.Append("<FEC_EMISION>" + DateTime.Today.ToShortDateString() + "</FEC_EMISION>");
        objSB.Append("<FEC_EMISION_SPTO>" + DateTime.Today.ToShortDateString() + "</FEC_EMISION_SPTO>");
        //Cambio para Ramo Millon Vida
        //objSB.Append("<TIP_DURACION>1</TIP_DURACION>");
        if (ramo == 105 || ramo2 == 105)
        {
            if (nr != 0)
            {
                objSB.Append("<NUM_RIESGOS>" + nr + "</NUM_RIESGOS>");
            }
            
        }
        else
        {
            objSB.Append("<NUM_RIESGOS>1</NUM_RIESGOS>");
        }
        objSB.Append("<CANT_RENOVACIONES>0</CANT_RENOVACIONES>");
        objSB.Append("<NUM_RENOVACIONES>0</NUM_RENOVACIONES>");
        objSB.Append("<TIP_COASEGURO>0</TIP_COASEGURO>");
        objSB.Append("<NUM_SECU_GRUPO></NUM_SECU_GRUPO>");
        objSB.Append("<TIP_SPTO>XX</TIP_SPTO>");
        objSB.Append("<MCA_REGULARIZA>S</MCA_REGULARIZA>");
        objSB.Append("<DURACION_PAGO_PRIMA>1</DURACION_PAGO_PRIMA>");
        objSB.Append("<MCA_TOMADORES_ALT>N</MCA_TOMADORES_ALT>");
        objSB.Append("<MCA_REASEGURO_MANUAL>N</MCA_REASEGURO_MANUAL>");
        objSB.Append("<MCA_PRORRATA>S</MCA_PRORRATA>");
        objSB.Append("<MCA_PRIMA_MANUAL>N</MCA_PRIMA_MANUAL>");
        objSB.Append("<MCA_PROVISIONAL>N</MCA_PROVISIONAL>");
        objSB.Append("<MCA_POLIZA_ANULADA>N</MCA_POLIZA_ANULADA>");
        objSB.Append("<MCA_SPTO_ANULADO>N</MCA_SPTO_ANULADO>");
        objSB.Append("<MCA_SPTO_TMP>N</MCA_SPTO_TMP>");
        objSB.Append("<MCA_DATOS_MINIMOS>N</MCA_DATOS_MINIMOS>");
        objSB.Append("<MCA_EXCLUSIVO>N</MCA_EXCLUSIVO>");
        if (ramo  == 105 || ramo2 == 105)
        {
            objSB.Append("<FEC_VALIDEZ>01/01/1990</FEC_VALIDEZ>");
        }
        else
        {
            objSB.Append("<FEC_VALIDEZ>" + DateTime.Today.ToShortDateString() + "</FEC_VALIDEZ>");
        }
        objSB.Append("<FEC_ACTU>" + DateTime.Today.ToShortDateString() + "</FEC_ACTU>");
        objSB.Append("<MCA_REASEGURO_MARCO>N</MCA_REASEGURO_MARCO>");
        objSB.Append("<TIP_POLIZA_TR>F</TIP_POLIZA_TR>");
        objSB.Append("<COD_NIVEL1></COD_NIVEL1>");
        objSB.Append("<COD_NIVEL2></COD_NIVEL2>");
        objSB.Append("<COD_NIVEL3></COD_NIVEL3>");
        objSB.Append("<COD_NIVEL3_CAPTURA>4920</COD_NIVEL3_CAPTURA>");
        objSB.Append("<COD_COMPENSACION>1</COD_COMPENSACION>");
        //objSB.Append("<TXT_MOTIVO_SPTO>P</TXT_MOTIVO_SPTO>");

        this.XML_CTE = objSB.ToString();
    }

    public void setDatos(Hashtable DATOS)
    {
        StringBuilder objSB = new StringBuilder();
        string ramo = "";
        try
        {
            ramo = System.Web.HttpContext.Current.Session["ramo"].ToString();
        }
        catch
        {
            ramo = "0";
        }
        String[] arrCAMPOS;
        if (ramo != "112")
        {
            arrCAMPOS = MapfreMMX.util.WebUtils.getAppSetting("DATOS_P2000030").Split(',');
        }
        else
        {
        arrCAMPOS = MapfreMMX.util.WebUtils.getAppSetting("DATOS_P2000030UL").Split(',');
        }

        try
        {
            int nc = 0;
            int nr = 0;
            if (ramo == "105")
            {
                MetodosAjax ma = new MetodosAjax();
                DataTable dt = ma.setAsegurados();
                nc = dt.Rows.Count;
                nr = nc;
            }
            foreach (String CAMPO in arrCAMPOS)
            {
                if (ramo == "105")
                {
                    
                    if (nr != 0 && CAMPO != "NUM_RIESGOS")
                    {
                        objSB.Append("<");
                        objSB.Append(CAMPO);
                        objSB.Append(">");
                        objSB.Append(DATOS[CAMPO]);
                        objSB.Append("</");
                        objSB.Append(CAMPO);
                        objSB.Append(">");
                    }else if (nr == 0)
                    {
                        objSB.Append("<");
                        objSB.Append(CAMPO);
                        objSB.Append(">");
                        objSB.Append(DATOS[CAMPO]);
                        objSB.Append("</");
                        objSB.Append(CAMPO);
                        objSB.Append(">");
                    }

                }
                else
                {
                    objSB.Append("<");
                    objSB.Append(CAMPO);
                    objSB.Append(">");
                    objSB.Append(DATOS[CAMPO]);
                    objSB.Append("</");
                    objSB.Append(CAMPO);
                    objSB.Append(">");
                }
            }
            this.XML_VAR = objSB.ToString();
        }
        catch (Exception ex)
        {
            throw new Exception("ERROR P2000030.setDatos() : " + ex.Message);
        }
    }

    public string getXML(int ROW_NUM)
    {
        StringBuilder objSB = new StringBuilder();
        try
        {
            objSB.Append("<ROW num=\"");
            objSB.Append(ROW_NUM);
            objSB.Append("\">");
            objSB.Append(this.XML_VAR);
            objSB.Append(this.XML_CTE);
            objSB.Append("</ROW>");
        }
        catch (Exception ex)
        {
            throw new Exception("ERROR P2000030.getXML() : " + ex.Message);
        }
        return objSB.ToString();
    }
}
