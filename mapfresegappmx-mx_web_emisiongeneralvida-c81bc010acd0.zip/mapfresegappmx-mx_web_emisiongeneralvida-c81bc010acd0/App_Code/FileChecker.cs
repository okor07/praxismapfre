﻿//****************************************************************************
//@Author                       : Juan Carlos Arroyave Arteaga
//@version                      : 1.0
//Development Environment       : Microsoft Visual Studio .Net 2010
//Name of the file              : FileChecker.vb
//Creation/Modification History : 
//Creado                        : 04-07-2012
//
//Validados del tipo de archivo a través de números magicos
//
//****************************************************************************

using System;
using System.Linq;
using System.IO;
using System.Configuration;

/// <summary>
/// Validados del tipo de archivo a través de números magicos
/// </summary>
public class FileChecker
{
    /// <summary>
    /// Propiedad que almacena la extensión descrita en el nombre del archivo
    /// <summary>
    private String sExtension { get; set; }
    /// <summary>
    /// Objeto stream para utilizado para abrir abrir el archivo y consultar sus números magicos.
    /// <summary>
    private Stream stFileStream { get; set; }

    /// <summary>
    /// <param name="sExtension">Estensión del archico que se carga.</param>
    /// <param name="stFileStream">Objeto stream con el archivo a evaluar</param>
    /// </summary>
    public FileChecker(String sExtension, Stream stFileStream)
    {
        this.sExtension = sExtension.Replace(".", "");
        this.stFileStream = stFileStream;
    }

    /// <summary>
    /// Funsión para obtener de la sesion de datos la lista de archivos permitidos.
    /// </summary>
    private string getexpectedSignature()
    {
        string ret = "";

        string cadFind = Convert.ToString(ConfigurationManager.AppSettings["extensionesPermitidas"]);

        foreach (string cad in cadFind.Split('|'))
        {
            if (cad.Split('=').GetValue(0).ToString().ToUpper() == sExtension.ToUpper())
            {
                ret = cad.Split('=').GetValue(1).ToString().ToUpper();
            }
        }

        return ret;
    }

    /// <summary>
    /// Obtiene el tamaño del numero magico del archivo.
    /// <param name="signature">Número magico que identifica el tipo de archivo.</param>
    /// </summary>
    private int getsignatureSize(string signature)
    {
        int size = 0;

        if (signature != "")
        {
            size = signature.Split('-').GetLength(0);
        }

        return size;
    }

    public String ValidaExtension()
    {
        try
        {
            string extensionesPer = ConfigurationManager.AppSettings["extensionesPermitidas"];
            if (extensionesPer.ToUpper().IndexOf(sExtension.ToUpper()) == -1)
                return "La extensión del archivo cargado no esta permitida.";
            else
            {
                if (!CheckSignature())
                    return "La extensión del archivo cargado no esta permitida.";
            }

        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            return ex.Message;
        }
        return "";
    }

    /// <summary>
    /// Verifica elnumero magico del archivo que se esta evaluando.
    /// </summary>
    private bool CheckSignature()
    {

        string expectedSignature = getexpectedSignature();
        int signatureSize = getsignatureSize(expectedSignature);

        if (String.IsNullOrEmpty(sExtension))
            throw new ArgumentException("Debes especificar la extensión");
        if (String.IsNullOrEmpty(expectedSignature))
            throw new ArgumentException("No se encontro el número magico a verificar");

        if (signatureSize > 0)
        {
            using (stFileStream)
            {
                if (stFileStream.Length < signatureSize)
                    return false;
                byte[] signature = new byte[signatureSize];
                int bytesRequired = signatureSize;
                int index = 0;

                while (bytesRequired > 0)
                {
                    int bytesRead = stFileStream.Read(signature, index, bytesRequired);
                    bytesRequired -= bytesRead;
                    index += bytesRead;
                }

                string actualSignature = BitConverter.ToString(signature);
                if (actualSignature == expectedSignature)
                    return true;
                else
                    return false;
            }
        }
        else
        {
            throw new ArgumentException("Codigo no valido");
        }
    }
}
