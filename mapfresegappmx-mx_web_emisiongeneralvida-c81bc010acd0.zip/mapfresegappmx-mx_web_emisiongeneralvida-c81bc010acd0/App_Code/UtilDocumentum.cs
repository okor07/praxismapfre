﻿using System;
using System.Collections.Generic; 
using System.Configuration;
using System.IO;
using System.Collections;
using System.Data;

using MapfreMMX.util;

using Cliente_REST_Documentum_OT.Utils;
using Cliente_REST_Documentum_OT.Wrapper;

/// <summary>
/// Descripción breve de UtilDocumentum
/// </summary>
public class UtilDocumentum
{
    public UtilDocumentum()
    {
        //
        // TODO: Agregar aquí la lógica del constructor
        //
    }

    public static string ImportarDocumento(clsDocumentum.CArchivo objetoArchivo, Hashtable Attribute)
    {
        // idDocumentum = objDocum.importDocument(objetoArchivo.NOMBRE, objetoArchivo.RUTA, WebUtils.getAppSetting("tipoArchivoDocumentum"), Attribute);
        string objectName = objetoArchivo.NOMBRE;
        string objectType = WebUtils.getAppSetting("tipoArchivoDocumentum");
        string sourcePath = objetoArchivo.RUTA;

        string destinationFolder = ConfigurationSettings.AppSettings["PathCabinet"] + "/" + DateTime.Today.ToString("yyyy");
        string filePath = sourcePath + @"\" + objectName;
        DmFormatType type = DmFormatType.Extension;

        FileInfo info = new FileInfo(filePath);
        string strFormat = info.Extension.Replace(".", "");
        string idDocumentum = ClienteREST.ImportDocumentGral(strFormat, type, objectName, filePath, destinationFolder, objectType, Attribute);
		info.Delete();
		
        return idDocumentum;
    }

    public static string ImportarDocumento(ArchivoWM objetoArchivo, Hashtable Attribute)
    {
        // string strIDDoc = objws_documentum.ImportGral(objArchivoWM.Nombre, objArchivoWM.Cabinet, objArchivoWM.TipoDocWM, strXmlAtributos);
        string objectName        = objetoArchivo.Nombre;
        string objectType        = objetoArchivo.TipoDocWM;
        string sourcePath        = objetoArchivo.RutaServer;
        string destinationFolder = objetoArchivo.Cabinet;
        string filePath          = sourcePath + @"\" + objectName;

        FileInfo info = new FileInfo(filePath);
        string strFormat         = info.Extension.Replace(".", "");

        DmFormatType type = DmFormatType.Extension;
        
        string idDocumentum = ClienteREST.ImportDocumentGral(strFormat, type, objectName, filePath, destinationFolder, objectType, Attribute);
        info.Delete();
		
        return idDocumentum;
    }

    public static string ImportarDocumento(clsRuta objetoArchivo, Hashtable Attribute)
    {
        // objDocumentum.ImportGral(objRuta.nombreArchivo,ConfigurationManager.AppSettings["CabinetSolicitudes"],ConfigurationManager.AppSettings["tipoArchivoDocumentumSolicitud"],XMLDocumentum);
        string objectName = objetoArchivo.nombreArchivo;
        string objectType = ConfigurationManager.AppSettings["tipoArchivoDocumentumSolicitud"];
        string sourcePath = objetoArchivo.ruta;
        string destinationFolder = ConfigurationManager.AppSettings["CabinetSolicitudes"];
        string filePath = sourcePath + @"\" + objectName;

        FileInfo info = new FileInfo(filePath);
        string strFormat = info.Extension.Replace(".", "");

        DmFormatType type = DmFormatType.Extension;

        string idDocumentum = ClienteREST.ImportDocumentGral(strFormat, type, objectName, filePath, destinationFolder, objectType, Attribute);
        info.Delete();
		
        return idDocumentum;
    }

    public static string getObjIDPolizaEndosoNew(string num_poliza, string num_spto, string tipo_doc)
    {
        try
        {
            List<Condicion> condiciones = new List<Condicion>(){
                new Condicion("num_poliza", "=", new Value("'" + num_poliza + "'"), "AND"),
                new Condicion("num_spto", "=", new Value("'" + num_spto + "'")),
                new Condicion("tipo_doc", "=", new Value("'" + tipo_doc + "'"))};
            ObjectQuery objectQuery = new ObjectQuery("r_object_id", "mmx_poliza", condiciones);
            DataTable table = ClienteREST.ExecuteQuery(objectQuery, "types_list");
            if (((table != null) && (table.Rows.Count > 0)) && (table.Rows[0][0] != DBNull.Value))
            {
                return Convert.ToString(table.Rows[0][0]);
            }
        }
        catch (Exception exception)
        {
            throw new Exception("JDocum.getObjIDPolizaEndoso() : " + exception.Message);
        }
        return null;
    }

    public static void viewDocument(string r_object_id, System.Web.HttpResponse resp)
    {
        try
        {
            string filepath = ClienteREST.GetContenido(r_object_id, "");
            FileInfo objFInfo = new FileInfo(filepath);
            resp.AddHeader("Content-Disposition", "filename=" + objFInfo.Name);
            resp.WriteFile(filepath);
            resp.Flush();
            objFInfo.Delete();
        }
        catch (Exception exception)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", exception);
            throw new Exception("JDocum.viewDocument() : " + exception.Message);
        }
    }
}