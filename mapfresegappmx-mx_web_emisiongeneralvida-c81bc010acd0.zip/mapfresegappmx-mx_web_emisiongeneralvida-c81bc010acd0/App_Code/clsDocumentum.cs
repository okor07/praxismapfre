//'******************************************************************************************************************** 
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2010
//'Name of the file              : clsDocumentum.cs
//'Creation/Modification History :
//'Modification                  : 
//                               
//'********************************************************************************************************************

using System;
using MapfreMMX.oracle;
using MapfreMMX.util;
using Oracle.DataAccess.Client;
using System.Collections;
using System.Configuration;
using System.IO;

using Cliente_REST_Documentum_OT.Utils;

public class clsDocumentum
    {
        public void eliminaArchivoLocal(CArchivo objetoArchivo)
        {
            string filePath = objetoArchivo.RUTA + objetoArchivo.NOMBRE;
            string file = WebUtils.getAppSetting("pathlocal").ToString() + System.IO.Path.GetFileName(filePath).ToString();
            try
            {
                System.IO.File.Delete(file);
            }
            catch { }
        }
        public void guardaDoc(CArchivo objetoArchivo)
        {
            try
            {
                enviaFTP(objetoArchivo.RUTA + objetoArchivo.NOMBRE);
                //Env�a a sevridor FTP 
                Oracle.DataAccess.Client.OracleConnection conexion;
                conexion = MConexion.getConexion("ConnectionSEGA");
                setDBArchivo(objetoArchivo, conexion);
                //Se guarda el registro en la base de datos 
                //Se borra el archivo del servidor FTP 
                DelFileIn(objetoArchivo.NOMBRE);
            }
            catch (Exception ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
                throw new Exception(ex.Message.ToString());
            }
        }

        public void subeDocumentum(string folioRAM, CArchivo objetoArchivo)
        {
            Oracle.DataAccess.Client.OracleConnection conexion = null; 
            try
            {
                Hashtable Attribute = new Hashtable();
                string idDocumentum = "";
                conexion = MConexion.getConexion("ConnectionSEGA");
                Attribute.Add("num_folio", folioRAM);
            
            	idDocumentum = UtilDocumentum.ImportarDocumento(objetoArchivo, Attribute);


            	setDBDocumento(objetoArchivo.IDSISTEMA, objetoArchivo.IDUSUARIO, objetoArchivo.NOMBRE, objetoArchivo.IDESTACION, idDocumentum, conexion);
            }
            catch (Exception ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
                throw new Exception(ex.Message.ToString());
            }
            finally
            {
                conexion.Close();
                conexion.Dispose();
            }
        }

        // APL -- Nueva forma de conexion FTPS
        public void enviaFTP(string filePath)
        {

            try
            {
                Mapfre.Ftp.FTPClient ftp = new Mapfre.Ftp.FTPClient(WebUtils.getAppSetting("ftphost"),
                    WebUtils.getAppSetting("ftpusr"), WebUtils.getAppSetting("ftppas"));
                ftp.Upload(filePath);
                ftp.Close();
            }
            catch (Exception ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
                throw new Exception(ex.Message.ToString());

            }
        }

        // APL -- Nueva forma de conexion FTPS
        private void DelFileIn(string filePath)
        {
            try
            {
                Mapfre.Ftp.FTPClient ftp = new Mapfre.Ftp.FTPClient(ConfigurationSettings.AppSettings["ftphost"], ConfigurationSettings.AppSettings["ftpusr"], ConfigurationSettings.AppSettings["ftppas"]);
               
                //obtenemos el archive guardado en el server de aplicacion 
                string file = ConfigurationSettings.AppSettings["pathftp"] + "/" + System.IO.Path.GetFileName(filePath);
                ftp.DeleteFile(file);
                ftp.Close();
            }
            catch (Exception ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
                throw new Exception("El archivo no se pudo borrar del servidor de FTP por la siguiente causa: " + ex.Message);
            }
        }

        public void setDBArchivo(CArchivo objArchivo, OracleConnection conexion)
        {
            //Dim cmd As OracleCommand = Nothing 
            MCommand cmd = new MCommand();
            try
            {

                cmd.CommandText = WebUtils.getAppSetting("SPArchivo");
                cmd.Connection = conexion;
                cmd.agregarINParametro("p_WF_OT_M_OT", OracleDbType.Int32,objArchivo.IDSISTEMA);
                cmd.agregarINParametro("p_NTSEG_C_ACCESO", OracleDbType.Int32, objArchivo.IDUSUARIO);
                cmd.agregarINParametro("p_WF_SIS_C_ESTA", OracleDbType.Int32, objArchivo.IDESTACION);
                cmd.agregarINParametro("p_NOMBRE_ARC_STR", OracleDbType.Varchar2, objArchivo.NOMBRE);
                cmd.agregarINParametro("p_RUTA_ARC_STR", OracleDbType.Varchar2, objArchivo.RUTAWEB);
                cmd.agregarINParametro("p_TIPO_ARC_INT", OracleDbType.Int32, objArchivo.TIPO);

                cmd.ejecutarSP();
                
            }
            catch (Exception ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
                throw new Exception("ERROR CDArchivo.setDBArchivo()", ex);
            }
            finally
            {
                cmd.Connection.Close();
                cmd.Connection.Dispose();
            }
        }

        public void setDBDocumento(int IDSISTEMA, int user, string FileName, int estacion, string r_object_id, OracleConnection conexion)
        {
            MCommand cmd = new MCommand();

            try
            {

                cmd.Connection = conexion;
                cmd.CommandText = WebUtils.getAppSetting("SPDocumento");
                cmd.agregarINParametro("p_wf_ot_m_ot", OracleDbType.Int32, IDSISTEMA);
                cmd.agregarINParametro("p_r_object_id", OracleDbType.Varchar2, r_object_id);
                cmd.agregarINParametro("p_ntseg_c_acceso", OracleDbType.Int32, user);
                cmd.agregarINParametro("p_wf_sis_c_esta", OracleDbType.Int32, estacion);
                cmd.agregarINParametro("p_nombre_arc_str", OracleDbType.Varchar2, FileName);
                cmd.agregarINParametro("p_tipo_arc_int", OracleDbType.Int32, Convert.ToInt16(WebUtils.getAppSetting("tipoArchivo")));

                cmd.ejecutarSP();
            }
            catch (Exception ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
                throw new Exception("Error : clsDocumentum.setDBDocumento()" + ex.Message);
            }
            finally
            {
                cmd = null;
            }
        }
        

    public string ImportarDocumento(CArchivo objetoArchivo, Hashtable attributes)
    {
        string idDocumentum = "";
        try
        {
            string destinationFolder = ConfigurationSettings.AppSettings["PathCabinet"] + "/" + DateTime.Today.ToString("yyyy");
            string FilePath = objetoArchivo.RUTA + @"\" + objetoArchivo.NOMBRE;
            FileInfo info = new FileInfo(FilePath);
            idDocumentum = ClienteREST.ImportDocumentGral(info.Extension.Replace(".", ""), Cliente_REST_Documentum_OT.Utils.DmFormatType.Extension, objetoArchivo.NOMBRE, FilePath, destinationFolder, WebUtils.getAppSetting("tipoArchivoDocumentum"), attributes);
            info.Delete();
            return idDocumentum;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message.ToString());
        }
    }

    public class CArchivo
    {
        private int iIDSISTEMA;
        private int iIDARCHIVO;
        private int iIDUSUARIO;
        private int iIDESTACION;
        private string strNOMBRE;
        private string strRUTA;
        private string strRUTAWEB;
        private int iTIPO;

        public int IDSISTEMA
        {
            get { return iIDSISTEMA; }
            set { iIDSISTEMA = value; }
        }
        public int IDARCHIVO
        {
            get { return iIDARCHIVO; }
            set { iIDARCHIVO = value; }
        }
        public int IDUSUARIO
        {
            get { return iIDUSUARIO; }
            set { iIDUSUARIO = value; }
        }
        public int IDESTACION
        {
            get { return iIDESTACION; }
            set { iIDESTACION = value; }
        }
        public string NOMBRE
        {
            get { return strNOMBRE; }
            set { strNOMBRE = value; }
        }
        public string RUTA
        {
            get { return strRUTA; }
            set { strRUTA = value; }
        }
        public string RUTAWEB
        {
            get { return strRUTAWEB; }
            set { strRUTAWEB = value; }
        }
        public int TIPO
        {
            get { return iTIPO; }
            set { iTIPO = value; }
        }
    }
}