﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using MapfreMMX.util;
using System.Threading;
using System.Threading.Tasks;
//using System.Threading.Tasks;

namespace Trazabilidad
{
    public class UsuarioAED
    {
        private static UsuarioAED INSTANCE;
        /*===================================================================================*/
        [MethodImpl(MethodImplOptions.Synchronized)]
        public static UsuarioAED getInstance()
        {
            if (INSTANCE == null)
            {
                INSTANCE = new UsuarioAED();
            }
            return INSTANCE;
        }

        public bool GuardaActualizaEliminaUsuario(string tipoCambio, string usuario, string fechaHora, string ipAcceso)
        {
            DateTime f = Convert.ToDateTime(fechaHora);
            DateTimeOffset dtOffset = new DateTimeOffset(f, TimeZoneInfo.Local.GetUtcOffset(f));
            string dateString = dtOffset.ToString("o");

            var traza = new Trazabilidad
            {
                aplicacion = ConfigurationManager.AppSettings["APLICACION_TRAZABILIDAD"],
                datos = new datos
                {
                    cliente_prod_accion = "n/a",
                    consulta_realizada = "n/a",
                    datos_especiales = false,
                    estado_consulta = "n/a",
                    fecha = dateString,
                    intentos_descarga = "n/a",
                    ip = ipAcceso,
                    privilegios_acceso = new privilegios_acceso
                    {
                        nivel_aut = "n/a",
                        perfil = "n/a",
                        rol = "n/a"
                    },
                    registros_descargados = "n/a",
                    tipo_accion = "n/a",
                    tipo_cambio = tipoCambio,
                    tipo_descarga = "n/a",
                    tipo_usuario = 0,
                    usuario = usuario
                },
                evento = "cambio_perfil"
            };

            string json = JsonConvert.SerializeObject(traza);
            var tsk = Task.Factory.StartNew(() => AsyncRequest(json));
            Task.WaitAll(tsk);
            string response = tsk.Result;

            if (response == null)
                return false;
            else
                return true;
        }
        private string AsyncRequest(string json)
        {
            RequestTrazabilidad request = new RequestTrazabilidad();
            Thread.Sleep(2000);
            return request.post(json);
        }
    }
}
