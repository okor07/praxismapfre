﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using MapfreMMX.util;
using System.Threading;
using System.Threading.Tasks;

namespace Trazabilidad
{
    public class AcessoDatos
    {
        private static AcessoDatos INSTANCE;
        /*===================================================================================*/
        [MethodImpl(MethodImplOptions.Synchronized)]
        public static AcessoDatos getInstance()
        {
            if (INSTANCE == null)
            {
                INSTANCE = new AcessoDatos();
            }
            return INSTANCE;
        }

        public bool RegistraBusquedaCliente(string usuario, int tipoUsuario, string fechaHora, string ipAcceso, string statusConsulta, bool datosSensibles, string consultaRealizada)
        {
            DateTime f = Convert.ToDateTime(fechaHora);
            DateTimeOffset dtOffset = new DateTimeOffset(f, TimeZoneInfo.Local.GetUtcOffset(f));
            string dateString = dtOffset.ToString("o");

            var traza = new Trazabilidad
            {
                aplicacion = ConfigurationManager.AppSettings["APLICACION_TRAZABILIDAD"],
                datos = new datos
                {
                    cliente_prod_accion = "n/a",
                    consulta_realizada = consultaRealizada,
                    datos_especiales = datosSensibles,
                    estado_consulta = statusConsulta,
                    fecha = dateString,
                    intentos_descarga = "n/a",
                    ip = ipAcceso,
                    privilegios_acceso = new privilegios_acceso
                    {
                        nivel_aut = "n/a",
                        perfil = "n/a",
                        rol = "n/a"
                    },
                    registros_descargados = "n/a",
                    tipo_accion = "n/a",
                    tipo_cambio = "n/a",
                    tipo_descarga = "n/a",
                    tipo_usuario = tipoUsuario,
                    usuario = usuario
                },
                evento = "accesos_datos_clientes"
            };

            string json = JsonConvert.SerializeObject(traza);
            var tsk = Task.Factory.StartNew(() => AsyncRequest(json));
            Task.WaitAll(tsk);
            string response = tsk.Result;

            if (response == null)
                return false;
            else
                return true;
        }

        private string AsyncRequest(string json)
        {
            RequestTrazabilidad request = new RequestTrazabilidad();
            Thread.Sleep(2000); 
            return request.post(json);
        }
    }
}
