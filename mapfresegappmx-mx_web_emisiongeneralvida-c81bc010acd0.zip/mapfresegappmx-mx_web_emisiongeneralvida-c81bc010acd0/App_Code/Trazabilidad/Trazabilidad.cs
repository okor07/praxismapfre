﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;
//v1.14
namespace Trazabilidad
{
    public class Trazabilidad
    {

        public string aplicacion { get; set; }
        public datos datos { get;  set; }
        public string evento { get; set; }
    }

    public class datos
    {
        public string cliente_prod_accion { get; set; }
        public string consulta_realizada { get; set; }
        public bool datos_especiales { get; set; }
        public string estado_consulta { get; set; }
        public string fecha { get; set; }
        public string intentos_descarga { get; set; }
        public string ip { get; set; }
        public privilegios_acceso privilegios_acceso { get; internal set; }
        public string registros_descargados { get; set; }
        public string tipo_accion { get; set; }
        public string tipo_cambio { get; set; }
        public string tipo_descarga { get; set; }
        public int tipo_usuario { get; set; }
        public string usuario { get; set; }
       
    }

    public class privilegios_acceso
    {
        public string nivel_aut { get; set; }
        public string perfil { get; set; }
        public string rol { get; set; }
    }
}
