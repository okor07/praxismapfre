﻿using MapfreMMX.util;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Web;

public class RequestTrazabilidad
{
    public string post(string json)
    {
        string responseString = string.Empty;
        var url = ConfigurationManager.AppSettings["PATH_TRAZABILIADAD"];
        try
        {
            var request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "POST";
            request.ContentType = "application/json";
            request.Accept = "application/json";
            request.Timeout = 2000;
            var streamWriter = new StreamWriter(request.GetRequestStream());

            streamWriter.Write(json);
            streamWriter.Flush();
            streamWriter.Close();
            var response = (HttpWebResponse)request.GetResponse();

            responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
        }
        catch (WebException ex)
        {
            responseString = "";
        }
        return responseString;
    }
}