﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using MapfreMMX.util;
using System.Threading;
using System.Threading.Tasks;

namespace Trazabilidad
{
    public class OperacionesRelevantes
    {
        private static OperacionesRelevantes INSTANCE;
        /*===================================================================================*/
        [MethodImpl(MethodImplOptions.Synchronized)]
        public static OperacionesRelevantes getInstance()
        {
            if (INSTANCE == null)
            {
                INSTANCE = new OperacionesRelevantes();
            }
            return INSTANCE;
        }
        public bool RegistraOperacionRelevante(string usuario, int tipoUsuario, string tipoAccion, string fechaHora, string ipAcceso, string clienteProducto)
        {
            DateTime f = Convert.ToDateTime(fechaHora);
            DateTimeOffset dtOffset = new DateTimeOffset(f, TimeZoneInfo.Local.GetUtcOffset(f));
            string dateString = dtOffset.ToString("o");

            var traza = new Trazabilidad
            {
                aplicacion = ConfigurationManager.AppSettings["APLICACION_TRAZABILIDAD"],
                datos = new datos
                {
                    cliente_prod_accion = clienteProducto,
                    consulta_realizada = "n/a",
                    datos_especiales = false,
                    estado_consulta = "n/a",
                    fecha = dateString,
                    intentos_descarga = "n/a",
                    ip = ipAcceso,
                    privilegios_acceso = new privilegios_acceso
                    {
                        nivel_aut = "n/a",
                        perfil = "n/a",
                        rol = "n/a"
                    },
                    registros_descargados = "n/a",
                    tipo_accion = tipoAccion,
                    tipo_cambio = "n/a",
                    tipo_descarga = "n/a",
                    tipo_usuario = tipoUsuario,
                    usuario = usuario
                },
                evento = "operaciones_relevantes"
            };

            string json = JsonConvert.SerializeObject(traza);
            var tsk = Task.Factory.StartNew(() => AsyncRequest(json));
            Task.WaitAll(tsk);
            string response = tsk.Result;

            if (response == null)
                return false;
            else
                return true;
        }
        private string AsyncRequest(string json)
        {
            RequestTrazabilidad request = new RequestTrazabilidad();
            Thread.Sleep(2000);
            return request.post(json);
        }
    }
}
