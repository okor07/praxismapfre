﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using MapfreMMX.util;
using System.Threading;
using System.Threading.Tasks;

namespace Trazabilidad
{
    public class DescargaInformacionConsulta
    {
        private static DescargaInformacionConsulta INSTANCE;
        /*===================================================================================*/
        [MethodImpl(MethodImplOptions.Synchronized)]
        public static DescargaInformacionConsulta getInstance()
        {
            if (INSTANCE == null)
            {
                INSTANCE = new DescargaInformacionConsulta();
            }
            return INSTANCE;
        }
        public bool RegistraDescargaInformacion(string usuario, int tipoUsuario, string tipoDescarga, string fechaHora, string ipAcceso, int intentos, int registros, string error)
        {
            DateTime f = Convert.ToDateTime(fechaHora);
            DateTimeOffset dtOffset = new DateTimeOffset(f, TimeZoneInfo.Local.GetUtcOffset(f));
            string dateString = dtOffset.ToString("o");

            var traza = new Trazabilidad
            {
                aplicacion = ConfigurationManager.AppSettings["APLICACION_TRAZABILIDAD"],
                datos = new datos
                {
                    cliente_prod_accion = "n/a",
                    consulta_realizada = "n/a",
                    datos_especiales = false,
                    estado_consulta = "n/a",
                    fecha = dateString,
                    intentos_descarga = Convert.ToString(intentos),
                    ip = ipAcceso,
                    privilegios_acceso = new privilegios_acceso
                    {
                        nivel_aut = "n/a",
                        perfil = "n/a",
                        rol = "n/a"
                    },
                    registros_descargados = Convert.ToString(registros),
                    tipo_accion = "n/a",
                    tipo_cambio = "n/a",
                    tipo_descarga = tipoDescarga,
                    tipo_usuario = tipoUsuario,
                    usuario = usuario
                },
                evento = "descarga_informacion"
            };

            string json = JsonConvert.SerializeObject(traza);
            var tsk = Task.Factory.StartNew(() => AsyncRequest(json));
            Task.WaitAll(tsk);
            string response = tsk.Result;

            if (response == null)
                return false;
            else
                return true;
        }

        private string AsyncRequest(string json)
        {
            RequestTrazabilidad request = new RequestTrazabilidad();
            Thread.Sleep(2000);
            return request.post(json);
        }
    }
}
