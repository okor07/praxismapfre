﻿//'********************************************************************************* 
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2010
//'Name of the file              : MetodosAjax.cs
//'Creation/Modification History :
//'Modification                  : jdgomezc  Indra SWLabs
//                               : jchuertas Indra SWLabs
//                               : emontoya  Indra SWLabs
//'C1                            : jchuertas - 30-12-2012
//                               : Se hace la validación del tipo de coberturas y se cambia el control por radio button
//                               : cuando es necesario.
//'C2                            : emontoya - 30-12-2012
//                               : Se agrega el parámetro tip_benef con el objetivo de mostrar los beneficiarios
//                                 por tipo de beneficiario.
//'C3                            : emontoya - 30-12-2012
//                               : Se crea el método para obtener los beneficiarios por los tipos: Fallecimiento o
//                               : Remanente.
//'C4                            : emontoya - 30-12-2012 
//                               : Se Filtran y ordenan las coberturas saliendo  primero en los ordenes especificos: 
//                               : BASICA, BIT, BIPA, EG, ACCIDENTES Y SERVICIOS FUNERARIOS.
//'C5                            : emontoya - jchuertas - 19-11-2012
//                               : Se agrega validación para cada tipo de benefiario para retornar el grid al cual
//                               : pertenece el beneficiario y se ordenan las coberturas segun el orden especificado.
//'C6                            : jchuertas - 30-12-2012
//                                 Se agregaron los eventos javascript y el espacio para los tooltips de coberturas.
//'C7                            : jchuertas - 30-12-2012
//                                 Se agrega el método validaAntecedentesOII
//'C8                            : jchuertas -30-12-2012
//                                 Obtiene el mensaje que será enviado por correo electrónico.
//'C9                            : jchuertas - 30-12-2012
//                                 Se capturan los datos necesarios para hacer el llamado al metodo 
//                                 que agrega el folio a suscripcion/emision en el flujo ram de solicitud
//'C10                           : emontoya - 30-12-2012
//                               : Se crea el método getParentescoSeguro.
//'C11                           : jchuertas - 30/12/2012
//                                 se agregó el método getObtieneTipoSeguros()
//'C12                           : jchuertas - 30/12/2012
//                                 se agregó el método getDocumentosAdjuntar
//'C13                           : emontoya - 30-12-2012
//                               : Se agregan los parámetros:Ramo, Modalidad y contrato. 
//'C14                           : emontoya - 30-12-2012
//                               : Se crea el método validaImpresion.
//'C15                           : emontoya - 30-12-2012
//                               : Se crea el método validaImprimePolizaSolicitud.
//'C16                           : emontoya - 30-12-2012
//'                              : Se crea el método getOcupacion()
//'C17                           : emontoya - 30-12-2012
//'                              : Se crea el método validaImpresionPreLlenada() 
//'C18                           : jchuertas - 01-10-2013
//'                              : Se crea el metodo que obtiene la lista de exámenes.
//'C19                           : jglopezh - 20-11-2013
//                               : Se crea el parámetro strTipoPlan en el método 
//                               : getDuracion
//'C20                           : apl - 09-12-2014
//                               : getCoberturasEdad() Se agrega ordenamiento de coberturas.
//'C21                           : Se agrega funcionalidad de requerimiento A27840 Segunda Fase Expediente Cliente
//26042018
//'C22                           : HEAQUINO
//                               : 17/07/2019
//                               : MU-2019-039250 - MX_NC_VID CONTRATO DE HSBC Y CREDIT SUIISE (CONTIGO)
//                               : Se agrega el contrato CREDIT SUISSE
// C23:		 					 : 26-08-2019
//   		 					 : MU-2019-050447 - MX_NC_VID Incremento de sumas aseguradas
// C24:                          : HEAQUINO
//                               : 16/04/2020
//                               : MU-2020-027447 - MX_NC_VID Limitar la edad máxima de aceptación de los ramos 100, 101, 103, 104 y 108 en zonaliados
//                               : Se cambia edad minima y edad maxima para los productos 1,3,4,7,8,9,10
// C25:                          : HEAQUINO
//                               : 18/08/2020
//                               : MU-2020-057795 - MX_NC_VID REQUERIMIENTO PARA LA AMPLIACIÓN DE EDAD DE ACEPTACIÓN DE LOS PRODUCTOS TEMPORAL PLAZOS FIJOS Y EDAD ALCANZADA A 90 AÑOS
//                               : Se cambia edad maxima para el ramo 100 modalidades 10005 y 10006 para los plazos 5,10,15 y 20
//C26                            : HEAQUINO
//                               : 26/07/2021
//                               : MU-2021-046282 - MX_NC_VID Re tarificación Plan Devolución Vida
//                               : Se amplia edad de aceptación para ramo 108 y se modifica impresion para que salga por HP
//								 : MU-2022-038409 Cuestionario de Enfermedades Respiratorias.
//C7							 : MU-2023-010678 Nuevas validaciones del cuestionario millon
//'******************************************************************************
using Ajax;
using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Text;
using System.Collections;
using Oracle.DataAccess.Client;
using MapfreMMX.oracle;
using MapfreMMX.util;
using System.IO;
using MapfreMMX.emision;
using System.Xml;
using System.Net;
using Cliente_REST_Documentum_OT.Utils;
using Cliente_REST_Documentum_OT.Wrapper;
using System.Collections.Generic;
using System.Globalization;

/// <summary>
/// Summary description for MetodosAjax
/// </summary>
public class MetodosAjax : Page
{
    public MetodosAjax()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string ObtenerDatosAGE(int COD_AGE)
    {
        System.Text.StringBuilder strDatos = new System.Text.StringBuilder();
        DataRow objDR;
        DatosVidaClass ObjVida = new DatosVidaClass();
        String cuadro_com = "";
        Catalogos objCatalogos = new Catalogos();
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                objDR = ObjVida.getConsultaAge(conexion, COD_AGE);

                strDatos.Append(objDR["p_nom_agte"].ToString() + "|");
                strDatos.Append(objDR["p_nom_div"].ToString() + "|");
                strDatos.Append(objDR["p_tel_agte"].ToString() + "|");
                strDatos.Append(objDR["p_mail_agte"].ToString() + "|");
                cuadro_com = objCatalogos.getcuadrocomMV(COD_AGE, Convert.ToInt32(Session["ramo"]));
                //strDatos.Append(objDR["p_cuadro_com"].ToString() + "|");                
                strDatos.Append(cuadro_com.ToString() + "|");
                strDatos.Append(objDR["p_valida"].ToString() + "|");
            }
        }
        catch (System.Exception Error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", Error);
            strDatos.Append(Error.Message);
        }

        return strDatos.ToString();
    }

    [Ajax.AjaxMethod()]
    public string getCorreoAgente(int COD_AGE)
    {
        string strEMail = "";
        DataRow objDR;
        DatosVidaClass ObjVida = new DatosVidaClass();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                objDR = ObjVida.getConsultaAge(conexion, COD_AGE);
                strEMail = objDR["p_mail_agte"].ToString();
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
        }

        return strEMail;
    }

    [AjaxMethod()]
    public string getCuadroComision(string agente)
    {
        DataRow objDR;
        Catalogos objCatalogos = new Catalogos();
        try
        {
            objDR = objCatalogos.getDatosAgente(agente);
            return objDR["p_cuadro_com"].ToString();
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public DataTable getMoneda(int CodigoRamo, string contrato, int tipoPlan)
    {
        Catalogos objCatalogos = new Catalogos();
        try
        {
            return objCatalogos.getMoneda(CodigoRamo, contrato, tipoPlan);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public DataTable getCrecimiento(int CodigoRamo, string contrato, int Moneda, int tipoPlan)
    {
        if (CodigoRamo == 105)
        {
            CDListaValor objListaValor = new CDListaValor();
            DataTable objDT;
            OracleConnection conexion = MConexion.getConexion("ConnectionTW");
            try
            {
                objDT = objListaValor.getCRECIMIENTO(1, CodigoRamo, Moneda, conexion);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                ((IDisposable)conexion).Dispose();
            }

            return objDT;
        }
        else
        {
            Catalogos objCatalogos = new Catalogos();
            try
            {
                return objCatalogos.getCrecimiento(CodigoRamo, contrato, Moneda, tipoPlan);
            }
            catch (Exception ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
                throw new Exception(ex.Message);
            }
        }

    }

    [Ajax.AjaxMethod()]
    public DataTable getDeducible(int CodigoRamo, string contrato, int Moneda, string strTipRegularizaSuma)
    {
        Catalogos objCatalogos = new Catalogos();
        try
        {
            return objCatalogos.getDeducible(CodigoRamo, contrato, Moneda, strTipRegularizaSuma);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public string getDeducibleNoJubilacion(int CodigoRamo, string contrato, int Moneda, string strTipRegularizaSuma)
    {
        Catalogos objCatalogos = new Catalogos();
        try
        {
            string strCodDedu = "-1";
            DataTable dt = objCatalogos.getDeducible(CodigoRamo, contrato, Moneda, strTipRegularizaSuma);
            if (dt.Rows.Count > 0)
            {
                strCodDedu = dt.Rows[0][0].ToString();
            }

            return strCodDedu;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    // <---- C19 ---->
    [Ajax.AjaxMethod()]
    public DataTable getDuracion(int CodigoRamo, string contrato, int Moneda,
                                 string strTipRegularizaSuma, string strTipDeducible, string strTipoPlan)
    {
        if (CodigoRamo == 105)
        {
            CDListaValor objListaValor = new CDListaValor();
            DataTable objDT;
            OracleConnection conexion = MConexion.getConexion("ConnectionTW");
            try
            {
                objDT = objListaValor.getDURACION(1, CodigoRamo, Moneda, Convert.ToInt32(strTipRegularizaSuma), conexion);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                ((IDisposable)conexion).Dispose();
            }
            return objDT;

        }
        else
        {
            Catalogos objCatalogos = new Catalogos();
            try
            {
                DataTable dtDuracion = new DataTable();
                // <---- C19 ---->
                dtDuracion = objCatalogos.getDuracion(CodigoRamo, contrato, Moneda, strTipRegularizaSuma, strTipDeducible, strTipoPlan);

                return dtDuracion;
            }
            catch (Exception ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
                throw new Exception(ex.Message);
            }
        }
    }

    [Ajax.AjaxMethod()]
    public DataTable getComision(int CodigoRamo, string contrato, int Moneda, string strTipRegularizaSuma, string strTipDeducible,
        string strDuracion, int tipoPlan)
    {
        Catalogos objCatalogos = new Catalogos();
        try
        {
            if (CodigoRamo == 105 && Moneda == 2 && strDuracion == "18")
            {
                strDuracion = "15";
                DataTable dtComision = new DataTable();
                dtComision = objCatalogos.getComision(CodigoRamo, contrato, Moneda,
                                                      strTipRegularizaSuma, strTipDeducible, strDuracion, tipoPlan);

                return dtComision;
            }
            else
            {

                DataTable dtComision = new DataTable();
                dtComision = objCatalogos.getComision(CodigoRamo, contrato, Moneda,
                                                      strTipRegularizaSuma, strTipDeducible, strDuracion, tipoPlan);

                return dtComision;
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public string getModalidad(int CodigoRamo, string contrato, int Moneda,
                               string strTipRegularizaSuma, string strTipDeducible,
                               string strTipComision, string strDuracion, string strMarca, int tipoPlan)
    {
        Catalogos objCatalogos = new Catalogos();
        try
        {
            DataTable dtModalidad = new DataTable();

            dtModalidad = objCatalogos.getModalidad(CodigoRamo, contrato, Moneda, strTipRegularizaSuma,
                                                    strTipDeducible, strTipComision, strDuracion, strMarca, tipoPlan);

            string strModalidad = "-1";
            string strEdadTopeMin = "0";
            string strEdadTopeMax = "100";
            //<---- C24 ---->
            string[] plazos = ConfigurationManager.AppSettings["leyenda_covid"].ToString().Split(',');
            bool bandera = false;
            foreach (String plan in plazos)
            {
                if (plan == tipoPlan.ToString())
                    bandera = true;
            }
            if (dtModalidad.Rows.Count > 0)
            {
                strModalidad = dtModalidad.Rows[0][0].ToString();
                if (bandera && strModalidad != "10003" && (tipoPlan.ToString() != "1" || strModalidad == "10002"))
                {
                    strEdadTopeMin = ConfigurationManager.AppSettings["edad_minima"].ToString();
                    //<--- C26--> ini
                    if (tipoPlan != 10)
                    {
                        strEdadTopeMax = ConfigurationManager.AppSettings["edad_maxima"].ToString();
                        if (CodigoRamo.ToString() == "103")
                        {
                            strEdadTopeMax = "70";
                        }
                    }
                    else
                    {
                        strEdadTopeMax = dtModalidad.Rows[0]["TOPE_MAX"].ToString();
                    }
                    //<--- C26--> fin
                }  //<--- C25--> ini     
                else if (bandera && tipoPlan.ToString() == "1" && strModalidad != "10002")
                {
                    strEdadTopeMin = ConfigurationManager.AppSettings["edad_minima"].ToString();
                    switch (strDuracion)
                    {
                        case "5": strEdadTopeMax = ConfigurationManager.AppSettings["edad_maxima_temp_plazo_5"].ToString();
                            break;
                        case "10": strEdadTopeMax = ConfigurationManager.AppSettings["edad_maxima_temp_plazo_5"].ToString();
                            break;
                        case "15": strEdadTopeMax = ConfigurationManager.AppSettings["edad_maxima_temp_plazo_5"].ToString();
                            break;
                        case "20": strEdadTopeMax = ConfigurationManager.AppSettings["edad_maxima_temp_plazo_20"].ToString();
                            break;
                        case "90": strEdadTopeMax = ConfigurationManager.AppSettings["edad_maxima_temp_plazo_5"].ToString();
                            break;
                        default: strEdadTopeMax = ConfigurationManager.AppSettings["edad_maxima"].ToString();
                            break;
                    }
                }//<---C25---> fin
                else
                {
                    strEdadTopeMin = dtModalidad.Rows[0]["TOPE_MIN"].ToString();
                    strEdadTopeMax = dtModalidad.Rows[0]["TOPE_MAX"].ToString();
                }
            }
            //<---- C24 ---->
            return strModalidad + "|" + strEdadTopeMin + "|" + strEdadTopeMax;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public DataTable getPolizaGrupo(int CodigoRamo, int CodAgente)
    {
        Catalogos objCatalogos = new Catalogos();

        try
        {
            //return objCatalogos.getPolizasGrupo(CodigoRamo, CodAgente);

            //if (CodigoRamo.ToString() == "108")
            if (ConfigurationManager.AppSettings["ramosConf"].Contains(CodigoRamo.ToString()))
            {

                return objCatalogos.getPolizasGrupo108(CodigoRamo, CodAgente);
            }
            else
            {
                return objCatalogos.getPolizasGrupo(CodigoRamo, CodAgente);
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public DataTable getContratos(int CodigoRamo, string numPolizaGpo, int CodAgente)
    {
        Catalogos objCatalogos = new Catalogos();

        try
        {
            //if (CodigoRamo.ToString() == "108")
            if (ConfigurationManager.AppSettings["ramosConf"].Contains(CodigoRamo.ToString()))
            {

                return objCatalogos.getContratos108(CodigoRamo, numPolizaGpo, CodAgente);
            }
            else
            {
                return objCatalogos.getContratos(CodigoRamo, numPolizaGpo, CodAgente);
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public DataTable getRamos(string contrato)
    {
        Catalogos objCatalogos = new Catalogos();

        try
        {
            return objCatalogos.getRamos(contrato);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable getFormasPago(int ramo, string Modalidad, int contrato)
    {
        Catalogos objCatalogos = new Catalogos();

        try
        {
            DataTable dtFormasPago = objCatalogos.getFormasPago(ramo, Modalidad, contrato);
            string strNoFormas = dtFormasPago.Rows.Count.ToString();
            string strFormas = "";

            foreach (DataRow dr in dtFormasPago.Rows)
            {
                strFormas += dr[0].ToString() + ";";
            }

            if (Session["FormasDePago"] == null)
                Session.Add("FormasDePago", strNoFormas + "|" + strFormas);
            else
                Session["FormasDePago"] = strNoFormas + "|" + strFormas;

            return dtFormasPago;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    // <--- C13 --->
    /// <summary>
    /// Método que se encarga de consultar el tipo de pago para un contrato.
    /// </summary>
    /// <param name="CodigoRamo">ramo</param>
    /// <param name="Modalidad">modalidad</param>
    /// <param name="Contrato">número de contrato</param>
    /// <param name="formaPago">forma de pago disponible para el contrato</param>
    /// <returns>DataTable con los tipos de pago correspondientes al contrato</returns>
    [Ajax.AjaxMethod()]
    public DataTable getTipoPago(int CodigoRamo, string Modalidad, string Contrato, string formaPago)
    {
        Catalogos objCatalogos = new Catalogos();

        try
        {
            return objCatalogos.getTipoPago(CodigoRamo, Modalidad, Contrato, formaPago);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR MetodosAjax.getTipoPago(): " + ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public DataRow SumaAseguradaBasica(int CodigoRamo, int CodCob, string Modalidad, int Moneda, string suma_aseg)
    {
        Catalogos objCatalogos = new Catalogos();

        try
        {
            return objCatalogos.SumaAseguradaBasica(CodigoRamo, CodCob, Modalidad, Moneda, suma_aseg);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public DataRow validaCoberturas(int CodCob, int CodigoRamo, string Modalidad, int Moneda,
                                    string suma_aseg_basica, string suma_aseg)
    {
        Catalogos objCatalogos = new Catalogos();

        try
        {
            return objCatalogos.validaCoberturas(CodCob, CodigoRamo, Modalidad, Moneda, suma_aseg_basica, suma_aseg);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public DataRow validaSumaBasica(int ramo, int modalidad, int contrato, int Moneda, string suma_aseg_basica)
    {
        Catalogos objCatalogos = new Catalogos();

        try
        {
            return objCatalogos.validaSumaBasica(ramo, modalidad, contrato, Moneda, suma_aseg_basica);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public DataRow validaCLMServFun(string strCLM)
    {
        Catalogos objCatalogos = new Catalogos();
        try
        {
            return objCatalogos.validaCLMServFun(strCLM);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public DataRow validaIMC(string Peso, string Estatura)
    {
        Catalogos objCatalogos = new Catalogos();

        try
        {
            return objCatalogos.validaIMC(Peso, Estatura);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public DataRow validaOcupacion(string strCodOcupacion)
    {
        Catalogos objCatalogos = new Catalogos();

        try
        {
            return objCatalogos.validaOcupacion(strCodOcupacion);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public DataRow validaCumulos(string ramo, string modalidad, string contrato, string moneda, string Edad,
                                 string nombre, string apeM, string apeP, string fechaNac, string sumAseg)
    {
        Catalogos objCatalogos = new Catalogos();

        try
        {
            return objCatalogos.validaCumulos(ramo, modalidad, contrato, moneda, Edad, nombre, apeM, apeP, fechaNac, sumAseg);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    //--------------->C18<---------
    /// <summary>
    ///     Este método se encarga de la comunicación entre el javascript y 
    ///     la clase que obtiene la lista de exámenes.
    /// </summary>
    /// <param name="ramo">codigo del ramo</param>
    /// <param name="modalidad">Codigo de la modalidad</param>
    /// <param name="contrato">numero de contrato</param>
    /// <param name="moneda">Tipo de moneda</param>
    /// <param name="Edad">Edad</param>
    /// <returns></returns>
    /// 
    [Ajax.AjaxMethod()]
    public DataRow validaExamenes(string ramo, string modalidad, string contrato, string moneda, string Edad, string sumAseg,
                                  string nombre, string apeM, string apeP, string fechaNac)
    {
        Catalogos objCatalogos = new Catalogos();

        try
        {
            return objCatalogos.validaExamenes(ramo, modalidad, contrato, moneda, Edad, sumAseg, nombre, apeM, apeP, fechaNac);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    //--------------->C19<---------
    /// <summary>
    ///     Este método se encarga de la comunicación entre el javascript y 
    ///     la clase que obtiene el cuestionario.
    /// </summary>
    /// <param name="ramo">codigo del ramo</param>
    /// <param name="modalidad">Codigo de la modalidad</param>
    /// <param name="contrato">numero de contrato</param>
    /// <param name="moneda">Tipo de moneda</param>
    /// <param name="Edad">Edad</param>
    /// <returns></returns>
    /// 
    [Ajax.AjaxMethod()]
    public string devuelveCuestionario(int codigoRamo, int modalidad, int contrato)
    {
        Catalogos objCatalogos = new Catalogos();
        StringBuilder strHTMLTabla = new StringBuilder();
        DataTable objDataTable = new DataTable();
        string version = null;
        objDataTable = objCatalogos.devuelveCuestionario(codigoRamo, modalidad, contrato);

        try
        {
            if (objDataTable.Rows.Count > 0)
            {

                strHTMLTabla.Append("<table class='table table-bordered tab-border-red' id='gvCuestionario' style='width:95%;border-collapse: collapse; cellspacing=0;' rules='all' cellSpacing='0' border='1' data-version='@version' >");
                strHTMLTabla.Append("<tr class='table-danger' style='color:#FFF;'>");
                strHTMLTabla.Append("<td></td><td>¿PADECIO Y/O PADECE ALGUNA DE LAS SIGUIENTES ENFERMEDADES?</td><td>Si</td><td>No</td>");
                strHTMLTabla.Append("</tr>");
                int ContAux = 1;

                foreach (DataRow dr in objDataTable.Rows)
                {
                    strHTMLTabla.Append("<tr>");
                    strHTMLTabla.Append("<td align=\"left\" >" + ContAux + "</td>");
                    strHTMLTabla.Append("<td align=\"center\" >" + dr["nom_pregunta"] + "</td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkSi' id='chkSi" + ContAux + "' onclick='selCheckBox(" + ContAux + ", \"Si\")' runat='server' /></td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkNo' id='chkNo" + ContAux + "' onclick='selCheckBox(" + ContAux + ", \"No\")' runat='server' value='on' checked /></td>");

                    ContAux++;
                }
                //Agregar if
                if (ConfigurationManager.AppSettings["ModalidadesFirma"].ToString().Contains(modalidad.ToString()))
                {
                    version = "1";
                    string[] preguntasTemporal = ConfigurationManager.AppSettings["PreguntasTemporal"].ToString().Split('|');
                    foreach (string dr in preguntasTemporal)
                    {
                        strHTMLTabla.Append("<tr>");
                        strHTMLTabla.Append("<td align=\"left\" >" + ContAux + "</td>");
                        strHTMLTabla.Append("<td align=\"center\" >" + dr + "</td>");
                        strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkSi' id='chkSi" + ContAux + "' onclick='selCheckBox(" + ContAux + ", \"Si\")' runat='server' /></td>");
                        strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkNo' id='chkNo" + ContAux + "' onclick='selCheckBox(" + ContAux + ", \"No\")' runat='server' value='on' checked /></td>");

                        ContAux++;
                    }
                }
                //esto debe de ir
                if (ConfigurationManager.AppSettings["Modalidades_CEFR"].ToString().Contains(modalidad.ToString()))
                {
                    version = "2";


                    //14
                    strHTMLTabla.Append("<tr>");
                    strHTMLTabla.Append("<td align=\"left\">14</td>");
                    strHTMLTabla.Append("<td align=\"center\">");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("¿HA SIDO DIAGNOSTICADO EN LOS ÚLTIMOS 3 MESES DE ALGUNA ENFERMEDAD RESPIRATORIA?");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-5 mt-3'>");
                    strHTMLTabla.Append("EN CASO AFIRMATIVO, INDICAR CUAL:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='col-7'>");
                    strHTMLTabla.Append("<input id='txt14' type='text' class='padding-left-0'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkSi' id='chkSi14' onclick='selCheckBox(14, \"Si\")' runat='server' /></td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkNo' id='chkNo14' onclick='selCheckBox(14, \"No\")' runat='server' value='on' /></td>");
                    strHTMLTabla.Append("</tr>");

                    //15
                    strHTMLTabla.Append("<tr>");
                    strHTMLTabla.Append("<td align=\"left\">15</td>");
                    strHTMLTabla.Append("<td align=\"center\">");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("¿ALGUNO DE SUS AMIGOS O FAMILIARES QUE HAYA VISITADO RECIENTEMENTE ESTÁ SIENDO ATENDIDO POR ALGUNA ENFERMEDAD RESPIRATORIA?");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-5 mt-3'>");
                    strHTMLTabla.Append("EN CASO AFIRMATIVO, INDICAR CUAL:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='col-7'>");
                    strHTMLTabla.Append("<input id='txt15' type='text' class='padding-left-0'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkSi' id='chkSi15' onclick='selCheckBox(15, \"Si\")' runat='server' /></td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkNo' id='chkNo15' onclick='selCheckBox(15, \"No\")' runat='server' value='on' /></td>");
                    strHTMLTabla.Append("</tr>");


                    //16
                    strHTMLTabla.Append("<tr>");
                    strHTMLTabla.Append("<td align=\"left\">16</td>");
                    strHTMLTabla.Append("<td align=\"center\">");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("¿HA EXPERIMENTADO ALGUNO DE LOS SIGUIENTES SÍNTOMAS EN LOS ÚLTIMOS 14 DÍAS?");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12 ml-5' align='left'>");
                    strHTMLTabla.Append("<div class='form-check'>");
                    strHTMLTabla.Append("<input class='form-check-input' type='checkbox' value='' id='chk16a'>");
                    strHTMLTabla.Append("<label class='form-check-label mt-2 pl-1' for='chk16a'>FIEBRE</label>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='form-check'>");
                    strHTMLTabla.Append("<input class='form-check-input' type='checkbox' value='' id='chk16b'>");
                    strHTMLTabla.Append("<label class='form-check-label mt-2 pl-1' for='chk16b'>TOS</label>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='form-check'>");
                    strHTMLTabla.Append("<input class='form-check-input' type='checkbox' value='' id='chk16c'>");
                    strHTMLTabla.Append("<label class='form-check-label mt-2 pl-1' for='chk16c'>FALTA DE ALIENTO O AIRE</label>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='form-check'>");
                    strHTMLTabla.Append("<input class='form-check-input' type='checkbox' value='' id='chk16d'>");
                    strHTMLTabla.Append("<label class='form-check-label mt-2 pl-1' for='chk16d'>MALESTAR (CANSANCIO SIMILAR A LA GRIPE/CUERPO CORTADO)</label>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='form-check'>");
                    strHTMLTabla.Append("<input class='form-check-input' type='checkbox' value='' id='chk16e'>");
                    strHTMLTabla.Append("<label class='form-check-label mt-2 pl-1' for='chk16e'>RINORREA (SECRECIÓN DE MOCO DE LA NARIZ)</label>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='form-check'>");
                    strHTMLTabla.Append("<input class='form-check-input' type='checkbox' value='' id='chk16f'>");
                    strHTMLTabla.Append("<label class='form-check-label mt-2 pl-1' for='chk16f'>DOLOR DE GARGANTA</label>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='form-check'>");
                    strHTMLTabla.Append("<input class='form-check-input' type='checkbox' value='' id='chk16g'>");
                    strHTMLTabla.Append("<label class='form-check-label mt-2 pl-1' for='chk16g'>SÍNTOMAS GASTROINTESTINALES COMO NAUSEAS, VOMITO Y/O DIARREA</label>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='form-check'>");
                    strHTMLTabla.Append("<input class='form-check-input' type='checkbox' value='' id='chk16h'>");
                    strHTMLTabla.Append("<label class='form-check-label mt-2 pl-1' for='chk16h'>CEFALEA</label>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkSi' id='chkSi16' onclick='selCheckBox(16, \"Si\")' runat='server' /></td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkNo' id='chkNo16' onclick='selCheckBox(16, \"No\")' runat='server' value='on' /></td>");
                    strHTMLTabla.Append("</tr>");

                    //17
                    strHTMLTabla.Append("<tr>");
                    strHTMLTabla.Append("<td align=\"left\">17</td>");
                    strHTMLTabla.Append("<td align=\"center\"><dl>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("¿LE HAN REALIZADO TEST O PRUEBAS DE LABORATORIO PARA DIAGNOSTICAR SARS COV2 / COVID 19, CON RESULTADO POSITIVO?");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");

                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-7'>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-5 mt-3'>QUE TIPO DE PRUEBA:</div>");
                    strHTMLTabla.Append("<div class='col-7'>");
                    strHTMLTabla.Append("<select id='txt17a' class='form-control padding-left-0'>");
                    strHTMLTabla.Append("<option>Seleccione</option>");
                    strHTMLTabla.Append("<option>PRUEBA PCR (REACCIÓN EN CADENA DE LA POLIMERASA)</option>");
                    strHTMLTabla.Append("<option>PRUEBA NAAT (AMPLIACIÓN DE ÁCIDOS NUCLEICOS)</option>");
                    strHTMLTabla.Append("<option>PRUEBAS DE ANTICUERPOS O SEROLÓGICAS</option>");
                    strHTMLTabla.Append("<option>PRUEBAS DE ANTÍGENOS</option>");
                    strHTMLTabla.Append("</select>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='col-5'>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-4 mt-3'>FECHA:</div>");
                    strHTMLTabla.Append("<div class='col-8'>");
                    strHTMLTabla.Append("<input id='txt17b' type='date' class='form-control padding-left-0'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkSi' id='chkSi17' onclick='selCheckBox(17, \"Si\")' runat='server' /></td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkNo' id='chkNo17' onclick='selCheckBox(17, \"No\")' runat='server' value='on' /></td>");
                    strHTMLTabla.Append("</tr>");


                    //18
                    strHTMLTabla.Append("<tr>");
                    strHTMLTabla.Append("<td align=\"left\">18</td>");
                    strHTMLTabla.Append("<td align=\"center\"><dl>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("¿SE LE HA DIAGNOSTICADO CON CORONAVIRUS SARS COV2 / COVID-19?");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("EN CASO AFIRMATIVO REFERIR:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");



                    strHTMLTabla.Append("<div class='row'>");


                    strHTMLTabla.Append("<div class='col-4'>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-4 mt-3'>FECHA:</div>");
                    strHTMLTabla.Append("<div class='col-8'>");
                    strHTMLTabla.Append("<input id='txt18a' type='date' class='form-control padding-left-0 mt-2'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");


                    strHTMLTabla.Append("<div class='col-8'>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-6 mt-3'>ATENCIÓN EN CASA U HOSPITAL:</div>");
                    strHTMLTabla.Append("<div class='col-6'>");
                    strHTMLTabla.Append("<select id='txt18b' class='form-control padding-left-0'>");
                    strHTMLTabla.Append("<option>SELECCIONE</option>");
                    strHTMLTabla.Append("<option>CASA</option>");
                    strHTMLTabla.Append("<option>HOSPITAL</option>");
                    strHTMLTabla.Append("</select>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");



                    strHTMLTabla.Append("<div class='row' align='left'>");
                    strHTMLTabla.Append("<div class='col-2 mt-3'>");
                    strHTMLTabla.Append("TRATAMIENTO:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='col-10'>");
                    strHTMLTabla.Append("<input id='txt18c' type='text' class='padding-left-0'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkSi' id='chkSi18' onclick='selCheckBox(18, \"Si\")' runat='server' /></td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkNo' id='chkNo18' onclick='selCheckBox(18, \"No\")' runat='server' value='on' /></td>");
                    strHTMLTabla.Append("</tr>");


                    strHTMLTabla.Append("<tr>");
                    strHTMLTabla.Append("<td align=\"left\">19</td>");
                    strHTMLTabla.Append("<td align=\"center\">");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("¿SE REALIZÓ UN TEST O PRUEBA DE LABORATORIO SARS COV2/COVID 19 CON RESULTADO NEGATIVO AL TÉRMINO DEL PADECIMIENTO?");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("EN CASO AFIRMATIVO, ANEXAR COPIA DEL INFORME MÉDICO FINAL Y REFERIR:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-7'>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-5 mt-3'>QUE TIPO DE PRUEBA:</div>");
                    strHTMLTabla.Append("<div class='col-7'>");
                    strHTMLTabla.Append("<select id='txt19a' class='form-control padding-left-0'>");
                    strHTMLTabla.Append("<option>Seleccione</option>");
                    strHTMLTabla.Append("<option>PRUEBA PCR (REACCIÓN EN CADENA DE LA POLIMERASA)</option>");
                    strHTMLTabla.Append("<option>PRUEBA NAAT (AMPLIACIÓN DE ÁCIDOS NUCLEICOS)</option>");
                    strHTMLTabla.Append("<option>PRUEBAS DE ANTICUERPOS O SEROLÓGICAS</option>");
                    strHTMLTabla.Append("<option>PRUEBAS DE ANTÍGENOS</option>");
                    strHTMLTabla.Append("</select>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='col-5'>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-4 mt-3'>FECHA:</div>");
                    strHTMLTabla.Append("<div class='col-8'>");
                    strHTMLTabla.Append("<input id='txt19b' type='date' class='form-control padding-left-0'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkSi' id='chkSi19' onclick='selCheckBox(19, \"Si\")' runat='server' /></td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkNo' id='chkNo19' onclick='selCheckBox(19, \"No\")' runat='server' value='on' /></td>");
                    strHTMLTabla.Append("</tr>");

                    strHTMLTabla.Append("<tr>");
                    strHTMLTabla.Append("<td align=\"left\">20</td>");
                    strHTMLTabla.Append("<td align=\"center\"><dl>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("¿PRESENTO ALGUNA SECUELA DEL SARS COV2/COVID 19?");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("EN CASO AFIRMATIVO REFERIR:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-3 mt-3' align='left'>");
                    strHTMLTabla.Append("TIPO DE SECUELA:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='col-9'>");
                    strHTMLTabla.Append("<input id='txt20a' type='text' class='padding-left-0'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-3 mt-3' align='left'>");
                    strHTMLTabla.Append("TRATAMIENTO MÉDICO:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='col-9'>");
                    strHTMLTabla.Append("<input id='txt20b' type='text' class='padding-left-0'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-5 mt-3' align='left'>");
                    strHTMLTabla.Append("ESTADO ACTUAL (ANEXAR INFORME MÉDICO):");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='col-7'>");
                    strHTMLTabla.Append("<input id='txt20c' type='text' class='padding-left-0'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");

                    strHTMLTabla.Append("</td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkSi' id='chkSi20' onclick='selCheckBox(20,\"Si\")' runat='server' /></td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkNo' id='chkNo20' onclick='selCheckBox(20,\"No\")' runat='server' value='on' /></td>");
                    strHTMLTabla.Append("</tr>");

                    strHTMLTabla.Append("<tr>");
                    strHTMLTabla.Append("<td align=\"left\">21</td>");
                    strHTMLTabla.Append("<td align=\"center\">");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("¿USTED ESTÁ O HA ESTADO EN CONTACTO CERCANO CON ALGUIEN QUE HA SIDO PUESTO EN CUARENTENA O DIAGNOSTICADO POR CORONAVIRUS SARS COV2 / COVID 19?");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-6'>");
                    strHTMLTabla.Append("EN CASO AFIRMATIVO ESPECIFICAR LA FECHA:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='col-6'>");
                    strHTMLTabla.Append("<input id='txt21' type='date' class='form-control'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkSi' id='chkSi21' onclick='selCheckBox(21, \"Si\")' runat='server' /></td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkNo' id='chkNo21' onclick='selCheckBox(21, \"No\")' runat='server' value='on' /></td>");
                    strHTMLTabla.Append("</tr>");

                    strHTMLTabla.Append("<tr>");
                    strHTMLTabla.Append("<td align=\"left\">22</td>");
                    strHTMLTabla.Append("<td align=\"center\"><dl>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("¿EN LOS ÚLTIMOS 14 DÍAS HA REALIZADO VIAJES FUERA DE SU ESTADO (ENTIDAD FEDERATIVA)?");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("EN CASO AFIRMATIVO ESPECIFICAR:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-4'>");
                    strHTMLTabla.Append("FECHA:<input id='txt22a' type='date' class='form-control'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='col-4'>");
                    strHTMLTabla.Append("MEDIO DE TRANSPORTE:");
                    strHTMLTabla.Append("<select id='txt22b' class='form-control'>");
                    strHTMLTabla.Append("<option>SELECCIONE</option>");
                    strHTMLTabla.Append("<option>AUTO PARTICULAR</option>");
                    strHTMLTabla.Append("<option>TAXI</option>");
                    strHTMLTabla.Append("<option>AUTOBÚS</option>");
                    strHTMLTabla.Append("<option>AVIÓN PRIVADO</option>");
                    strHTMLTabla.Append("<option>AVIÓN COMERCIAL</option>");
                    strHTMLTabla.Append("<option>OTRO</option>");
                    strHTMLTabla.Append("</select>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='col-4'>");
                    strHTMLTabla.Append("DESTINO:");
                    strHTMLTabla.Append("<select id='txt22c' class='form-control'>");
                    strHTMLTabla.Append("<option>SELECCIONE</option>");
                    strHTMLTabla.Append("<option>AGUASCALIENTES</option>");
                    strHTMLTabla.Append("<option>BAJA CALIFORNIA</option>");
                    strHTMLTabla.Append("<option>BAJA CALIFORNIA SUR</option>");
                    strHTMLTabla.Append("<option>CAMPECHE</option>");
                    strHTMLTabla.Append("<option>CHIAPAS</option>");
                    strHTMLTabla.Append("<option>CHIHUAHUA</option>");
                    strHTMLTabla.Append("<option>CIUDAD DE MÉXICO</option>");
                    strHTMLTabla.Append("<option>COAHUILA DE ZARAGOZA</option>");
                    strHTMLTabla.Append("<option>COLIMA</option>");
                    strHTMLTabla.Append("<option>DURANGO</option>");
                    strHTMLTabla.Append("<option>GUANAJUATO</option>");
                    strHTMLTabla.Append("<option>GUERRERO</option>");
                    strHTMLTabla.Append("<option>HIDALGO</option>");
                    strHTMLTabla.Append("<option>JALISCO</option>");
                    strHTMLTabla.Append("<option>ESTADO DE MÉXICO</option>");
                    strHTMLTabla.Append("<option>MICHOACÁN DE OCAMPO</option>");
                    strHTMLTabla.Append("<option>MORELOS</option>");
                    strHTMLTabla.Append("<option>NAYARIT</option>");
                    strHTMLTabla.Append("<option>NUEVO LEÓN</option>");
                    strHTMLTabla.Append("<option>OAXACA</option>");
                    strHTMLTabla.Append("<option>PUEBLA</option>");
                    strHTMLTabla.Append("<option>QUERÉTARO</option>");
                    strHTMLTabla.Append("<option>QUINTANA ROO</option>");
                    strHTMLTabla.Append("<option>SAN LUIS POTOSÍ</option>");
                    strHTMLTabla.Append("<option>SINALOA</option>");
                    strHTMLTabla.Append("<option>SONORA</option>");
                    strHTMLTabla.Append("<option>TABASCO</option>");
                    strHTMLTabla.Append("<option>TAMAULIPAS</option>");
                    strHTMLTabla.Append("<option>TLAXCALA</option>");
                    strHTMLTabla.Append("<option>VERACRUZ</option>");
                    strHTMLTabla.Append("<option>YUCATÁN</option>");
                    strHTMLTabla.Append("<option>ZACATECAS</option>");
                    strHTMLTabla.Append("</select>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkSi' id='chkSi22' onclick='selCheckBox(22, \"Si\")' runat='server' /></td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkNo' id='chkNo22' onclick='selCheckBox(22, \"No\")' runat='server' value='on' /></td>");
                    strHTMLTabla.Append("</tr>");

                    strHTMLTabla.Append("<tr>");
                    strHTMLTabla.Append("<td align=\"left\">23</td>");
                    strHTMLTabla.Append("<td align=\"center\"><dl>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("¿TIENE PLANEADO REALIZAR ALGÚN VIAJE FUERA DE SU ENTIDAD EN LOS PRÓXIMOS DÍAS?");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("EN CASO AFIRMATIVO REFERIR:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");

                    strHTMLTabla.Append("<div class='row'>");


                    strHTMLTabla.Append("<div class='col-5'>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-4 mt-3'>FECHA INICIO:</div>");
                    strHTMLTabla.Append("<div class='col-8'>");
                    strHTMLTabla.Append("<input id='txt23a' type='date' class='form-control padding-left-0 mt-2'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");


                    strHTMLTabla.Append("<div class='col-7'>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-4 mt-3'>FECHA TERMINO:</div>");
                    strHTMLTabla.Append("<div class='col-8'>");
                    strHTMLTabla.Append("<input id='txt23b' type='date' class='form-control padding-left-0 mt-2'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");

                    strHTMLTabla.Append("</div>");

                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-5'>");

                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-5 mt-3'>DESTINO:</div>");
                    strHTMLTabla.Append("<div class='col-7'>");
                    strHTMLTabla.Append("<select id='txt23c' class='form-control padding-left-0'>");
                    strHTMLTabla.Append("<option>SELECCIONE</option>");
                    strHTMLTabla.Append("<option>AGUASCALIENTES</option>");
                    strHTMLTabla.Append("<option>BAJA CALIFORNIA</option>");
                    strHTMLTabla.Append("<option>BAJA CALIFORNIA SUR</option>");
                    strHTMLTabla.Append("<option>CAMPECHE</option>");
                    strHTMLTabla.Append("<option>CHIAPAS</option>");
                    strHTMLTabla.Append("<option>CHIHUAHUA</option>");
                    strHTMLTabla.Append("<option>CIUDAD DE MÉXICO</option>");
                    strHTMLTabla.Append("<option>COAHUILA DE ZARAGOZA</option>");
                    strHTMLTabla.Append("<option>COLIMA</option>");
                    strHTMLTabla.Append("<option>DURANGO</option>");
                    strHTMLTabla.Append("<option>GUANAJUATO</option>");
                    strHTMLTabla.Append("<option>GUERRERO</option>");
                    strHTMLTabla.Append("<option>HIDALGO</option>");
                    strHTMLTabla.Append("<option>JALISCO</option>");
                    strHTMLTabla.Append("<option>ESTADO DE MÉXICO</option>");
                    strHTMLTabla.Append("<option>MICHOACÁN DE OCAMPO</option>");
                    strHTMLTabla.Append("<option>MORELOS</option>");
                    strHTMLTabla.Append("<option>NAYARIT</option>");
                    strHTMLTabla.Append("<option>NUEVO LEÓN</option>");
                    strHTMLTabla.Append("<option>OAXACA</option>");
                    strHTMLTabla.Append("<option>PUEBLA</option>");
                    strHTMLTabla.Append("<option>QUERÉTARO</option>");
                    strHTMLTabla.Append("<option>QUINTANA ROO</option>");
                    strHTMLTabla.Append("<option>SAN LUIS POTOSÍ</option>");
                    strHTMLTabla.Append("<option>SINALOA</option>");
                    strHTMLTabla.Append("<option>SONORA</option>");
                    strHTMLTabla.Append("<option>TABASCO</option>");
                    strHTMLTabla.Append("<option>TAMAULIPAS</option>");
                    strHTMLTabla.Append("<option>TLAXCALA</option>");
                    strHTMLTabla.Append("<option>VERACRUZ</option>");
                    strHTMLTabla.Append("<option>YUCATÁN</option>");
                    strHTMLTabla.Append("<option>ZACATECAS</option>");
                    strHTMLTabla.Append("</select>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");

                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='col-7'>");

                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-5 mt-3'>MEDIO DE TRANSPORTE:</div>");
                    strHTMLTabla.Append("<div class='col-7'>");
                    strHTMLTabla.Append("<select id='txt23d' class='form-control padding-left-0'>");
                    strHTMLTabla.Append("<option>SELECCIONE</option>");
                    strHTMLTabla.Append("<option>AUTO PARTICULAR</option>");
                    strHTMLTabla.Append("<option>TAXI</option>");
                    strHTMLTabla.Append("<option>AUTOBÚS</option>");
                    strHTMLTabla.Append("<option>AVIÓN PRIVADO</option>");
                    strHTMLTabla.Append("<option>AVIÓN COMERCIAL</option>");
                    strHTMLTabla.Append("<option>OTRO</option>");
                    strHTMLTabla.Append("</select>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");



                    strHTMLTabla.Append(" </td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkSi' id='chkSi23' onclick='selCheckBox(23, \"Si\")' runat='server' /></td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkNo' id='chkNo23' onclick='selCheckBox(23, \"No\")' runat='server' value='on' /></td>");
                    strHTMLTabla.Append("</tr>");


                    strHTMLTabla.Append("<tr>");
                    strHTMLTabla.Append("<td align=\"left\">24</td>");
                    strHTMLTabla.Append("<td align=\"center\"><dl>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("¿HA PARTICIPADO O ASISTIDO EN EVENTOS MASIVOS EN LOS ÚLTIMOS 15 DÍAS?");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("EN CASO AFIRMATIVO REFERIR:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");

                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-1 mt-3' align='left'>");
                    strHTMLTabla.Append("FECHAS:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='col-11'>");
                    strHTMLTabla.Append("<input id='txt24a' type='text' class='padding-left-0'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");


                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-1 mt-3' align='left'>");
                    strHTMLTabla.Append("LUGARES:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='col-11'>");
                    strHTMLTabla.Append("<input id='txt24b' type='text' class='padding-left-0'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");

                    strHTMLTabla.Append("</td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkSi' id='chkSi24' onclick='selCheckBox(24, \"Si\")' runat='server' /></td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkNo' id='chkNo24' onclick='selCheckBox(24, \"No\")' runat='server' value='on' /></td>");
                    strHTMLTabla.Append("</tr>");

                    strHTMLTabla.Append("<tr>");
                    strHTMLTabla.Append("<td align=\"left\">25</td>");
                    strHTMLTabla.Append("<td align=\"center\"><dl>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("¿CUENTA CON LA APLICACIÓN DE ALGUNA VACUNA CONTRA EL SARS COV2 / COVID-19?");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-12'>");
                    strHTMLTabla.Append("EN CASO AFIRMATIVO REFERIR:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");


                    strHTMLTabla.Append("<div class='row mt-2'>");
                    strHTMLTabla.Append("<div class='col-5 mt-3' align='left'>");
                    strHTMLTabla.Append("FECHA DE LA APLICACIÓN PRIMERA DOSIS:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='col-4'>");
                    strHTMLTabla.Append("<input id='txt25a' type='date' class=' form-control form-control-sm padding-left-0 mt-2'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");

                    strHTMLTabla.Append("<div class='row mt-2'>");
                    strHTMLTabla.Append("<div class='col-5 mt-3' align='left'>");
                    strHTMLTabla.Append("FECHA DE LA APLICACIÓN SEGUNDA DOSIS:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='col-4'>");
                    strHTMLTabla.Append("<input id='txt25b' type='date' class='form-control form-control-sm padding-left-0 mt-2'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");

                    strHTMLTabla.Append("<div class='row'>");
                    strHTMLTabla.Append("<div class='col-3 mt-3' align='left'>");
                    strHTMLTabla.Append("VACUNA APLICADA:");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("<div class='col-9'>");
                    strHTMLTabla.Append("<input id='txt25c' type='text' class='form-control padding-left-0 MT-1'/>");
                    strHTMLTabla.Append("</div>");
                    strHTMLTabla.Append("</div>");



                    strHTMLTabla.Append("</td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkSi' id='chkSi25' onclick='selCheckBox(25, \"Si\")' runat='server' value='on' /></td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkNo' id='chkNo25' onclick='selCheckBox(25, \"No\")' runat='server' /></td>");
                    strHTMLTabla.Append("</tr>");


                    strHTMLTabla.Append("<tr>");
                    strHTMLTabla.Append("<td align=\"left\">26</td>");
                    strHTMLTabla.Append("<td align=\"center\"><dl>");
                    strHTMLTabla.Append("¿UTILIZA MÁS DE DOS VECES A LA SEMANA EL TRANSPORTE PÚBLICO?");
                    strHTMLTabla.Append("</td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkSi' id='chkSi26' onclick='selCheckBox(26, \"Si\")' runat='server' /></td>");
                    strHTMLTabla.Append("<td align=\"center\" ><input type='checkbox' name='chkNo' id='chkNo26' onclick='selCheckBox(26, \"No\")' runat='server' value='on' /></td>");
                    strHTMLTabla.Append("</tr>");

                }
                strHTMLTabla.Append("</table>");

                strHTMLTabla.Replace("@version", version);
                //esto debe ir
            }

            return strHTMLTabla.ToString();
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public string devuelveCuestionarioMillon()
    {
        // StringBuilder strHTMLTabla = new StringBuilder();
        StringBuilder strHTMLTabla = new StringBuilder();
        try
        {
            #region HTML
            //strHTMLTabla.Append("<div class=\"col-12\">");
            strHTMLTabla.Append("<h3>");
            strHTMLTabla.Append("<span id=\"lblCuestionarioMillon\">Cuestionario para suma asegurada mayor a 1.5 millones de pesos o su equivalente en dólares o udis</span></h3>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-12\">");
            strHTMLTabla.Append("<p><b>Información laboral del solicitante</b></p>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6\">");
            strHTMLTabla.Append("<p>Giro de la empresa</p>");
            strHTMLTabla.Append("<input name=\"txtGiro\" onchange=\"valNumero()\" type =\"text\" id=\"txtGiro\" class=\"form-control\" />");
            //strHTMLTabla.Append("<asp:TextBox ID=\"txtGiro\" runat=\"server\" CssClass=\"form-control inp-sel-48\"></asp:TextBox>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>Teléfono</p>");
            strHTMLTabla.Append("<input name=\"txtTelefono\" type=\"text\"  maxlength=10 onkeypress=\"return KeyNumber(this, event);\" id=\"txtTelefono\" class=\"form-control\" />");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>Clave país</p>");
            strHTMLTabla.Append("<input name=\"txtCvePais\" onkeypress=\"return KeyNumber(this, event);\" type=\"text\" id=\"txtCvePais\" class=\"form-control\" />");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>Código de ciudad</p>");
            strHTMLTabla.Append("<input name=\"txtCodCiudad\" onkeypress=\"return KeyNumber(this, event);\" type=\"text\" id=\"txtCodCiudad\" class=\"form-control\"  />");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>¿Qué tipo de máquinas, herramientas, sustancias o vehículos utiliza?</p>");
            strHTMLTabla.Append("<select id='txtTipoMaquinas' name='txtTipoMaquinas' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option>HERRAMIENTAS DE CORTE</option>");
            strHTMLTabla.Append("<option>CUCHILLOS</option>");
            strHTMLTabla.Append("<option>SECADORAS</option>");
            strHTMLTabla.Append("<option>TIJERAS</option>");
            strHTMLTabla.Append("<option>TAXIS</option>");
            strHTMLTabla.Append("<option>MOTO</option>");
            strHTMLTabla.Append("<option>AUTOBUSES DE TRANSPORTE PUBLICO</option>");
            strHTMLTabla.Append("<option>AUTOBUSES DE TRANSPORTE PRIVADO</option>");
            strHTMLTabla.Append("<option>GRUAS</option>");
            strHTMLTabla.Append("<option>AMBULANCIAS</option>");
            strHTMLTabla.Append("<option>CAMIONES DE ARTICULOS PESADOS</option>");
            strHTMLTabla.Append("<option>CAMIONES DE ARTICULOS LIGEROS</option>");
            strHTMLTabla.Append("<option>TRACTORES</option>");
            strHTMLTabla.Append("<option>COSECHADORAS</option>");
            strHTMLTabla.Append("<option>SIERRAS DE CADENA</option>");
            strHTMLTabla.Append("<option>NINGUNA DE LAS ANTERIORES</option>");
            strHTMLTabla.Append("</select>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>¿Tiene alguna otra ocupación? </p>");
            strHTMLTabla.Append("SI&nbsp;<input id=\"chkSiOtraOcupacion\" type=\"checkbox\" onclick=\"PreguntasSiNo(this, 'chkSiOtraOcupacion', 'chkNoOtraOcupacion');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("NO&nbsp;<input id=\"chkNoOtraOcupacion\" type=\"checkbox\" checked=\"true\" onclick=\"PreguntasSiNo(this, 'chkSiOtraOcupacion', 'chkNoOtraOcupacion');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("<div id=\"divConsiste\" hidden>");
            strHTMLTabla.Append("<p>¿En que consiste?</p>");
            strHTMLTabla.Append("<select id='txtOtraOcupacion' name='txtOtraOcupacion' class='form-control padding-left-0'>");
            strHTMLTabla.Append("</select>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>¿Requiere viajar?</p><br>");
            strHTMLTabla.Append("SI&nbsp;<input id=\"chkSiViajar\" type=\"checkbox\" onclick=\"PreguntasSiNo(this, 'chkSiViajar', 'chkNoViajar');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("NO&nbsp;<input id=\"chkNoViajar\" type=\"checkbox\" checked=\"true\" onclick=\"PreguntasSiNo(this, 'chkSiViajar', 'chkNoViajar');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("<div id=\"divTipoTransporte\" hidden>");
            strHTMLTabla.Append("<p>Indique tipo de transporte</p>");
            strHTMLTabla.Append("<select id='txtTipoTransporte' onchange='selectTranspote();' name='txtTipoTransporte' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option>AEREO</option>");
            strHTMLTabla.Append("<option>MARITIMO</option>");
            strHTMLTabla.Append("<option>TERRESTRE</option>");
            strHTMLTabla.Append("</select>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div hidden id='divAeronaves' class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>¿Viaja en aeronaves particulares?</p>");
            strHTMLTabla.Append("SI&nbsp;<input id=\"chkSiAParticular\" type=\"checkbox\" onclick=\"PreguntasSiNo(this, 'chkSiAParticular', 'chkNoAParticular');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("NO&nbsp;<input id=\"chkNoAParticular\" type=\"checkbox\" checked=\"true\" onclick=\"PreguntasSiNo(this, 'chkSiAParticular', 'chkNoAParticular');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("<div id=\"divEspecifiqueAeronave\" hidden>");
            strHTMLTabla.Append("<p>Especifique tipo de aeronave y horas de vuelo:</p>");
            strHTMLTabla.Append("<input name=\"txtTipoAeronave\" type=\"text\" id=\"txtTipoAeronave\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\">");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>¿Utiliza motocicleta?</p>");
            strHTMLTabla.Append("SI&nbsp;<input id=\"chkSiMotocicleta\" type=\"checkbox\" onclick=\"PreguntasSiNo(this, 'chkSiMotocicleta', 'chkNoMotocicleta');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("NO&nbsp;<input id=\"chkNoMotocicleta\" type=\"checkbox\" checked=\"true\" onclick=\"PreguntasSiNo(this, 'chkSiMotocicleta', 'chkNoMotocicleta');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("<div id=\"divMotoFrecuencia\" hidden>");
            strHTMLTabla.Append("<p>Especifique con qué frecuencia y para qué</p>");
            strHTMLTabla.Append("<input name=\"txtFMotocicleta\" type=\"text\" id=\"txtFMotocicleta\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\">");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>¿Trabaja en las alturas?</p><br>");
            strHTMLTabla.Append("SI&nbsp;<input id=\"chkSiAlturas\" type=\"checkbox\" onclick=\"PreguntasSiNo(this, 'chkSiAlturas', 'chkNoAlturas');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("NO&nbsp;<input id=\"chkNoAlturas\" type=\"checkbox\" checked=\"true\" onclick=\"PreguntasSiNo(this, 'chkSiAlturas', 'chkNoAlturas');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("<div id=\"divIndicarAltura\" hidden>");
            strHTMLTabla.Append("<p>Indicar altura promedio en metros</p>");
            strHTMLTabla.Append("<input name=\"txtAlturas\" type=\"text\" id=\"txtAlturas\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\">");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>Indique el lugar de trabajo</p>");
            strHTMLTabla.Append("<select id='txtLugarTrabajo' name='txtLugarTrabajo' onchange='selectLugarTrabajo();' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option>OFICINA</option>");
            strHTMLTabla.Append("<option>FABRICA</option>");
            strHTMLTabla.Append("<option>TALLER</option>");
            strHTMLTabla.Append("<option>OTRO</option>");
            strHTMLTabla.Append("</select>");
            //strHTMLTabla.Append("Oficina&nbsp;<input id=\"chkOficina\" type=\"checkbox\" checked=\"true\" onclick=\"PreguntaTrabajo(this, 'chkOficina', 'chkFabrica', 'chkTaller', 'chkCalle');\" style=\"height: auto;\" />");
            //strHTMLTabla.Append("Fábrica&nbsp;<input id=\"chkFabrica\" type=\"checkbox\" onclick=\"PreguntaTrabajo(this, 'chkOficina', 'chkFabrica', 'chkTaller', 'chkCalle');\" style=\"height: auto;\" />");
            //strHTMLTabla.Append("Taller&nbsp;<input id=\"chkTaller\" type=\"checkbox\" onclick=\"PreguntaTrabajo(this, 'chkOficina', 'chkFabrica', 'chkTaller', 'chkCalle');\" style=\"height: auto;\" />");
            //strHTMLTabla.Append("Calle&nbsp;<input id=\"chkCalle\" type=\"checkbox\" onclick=\"PreguntaTrabajo(this, 'chkOficina', 'chkFabrica', 'chkTaller', 'chkCalle');\" style=\"height: auto;\" />");
            //strHTMLTabla.Append("&nbsp;&nbsp;Otro:<input name=\"txtOtroLugarTrabajo\" type=\"text\" id=\"txtOtroLugarTrabajo\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\">");
            strHTMLTabla.Append("<div id=\"divOtro\" hidden>");
            strHTMLTabla.Append("<p>Otro:</p>");
            strHTMLTabla.Append("<input name=\"txtOtroLugarTrabajo\" type=\"text\" id=\"txtOtroLugarTrabajo\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\">");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p><b><br><br><br><br></b></p>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-12\">");
            strHTMLTabla.Append("<p><b>Deportes y/o afición</b></p>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>¿En qué forma practica el deporte y/o afición?</p>");
            strHTMLTabla.Append("<select id='txtDeporte' name='txtDeporte' onchange='selectDeporte();' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option id=\"chkDProfesional\">PROFESIONAL</option>");
            strHTMLTabla.Append("<option id=\"chkDAficionado\">AFICIONADO</option>");
            strHTMLTabla.Append("<option id=\"chkDAmateur\">AMATEUR</option>");
            strHTMLTabla.Append("<option>NINGUNO</option>");
            strHTMLTabla.Append("</select>");
            //strHTMLTabla.Append("Profesional&nbsp;<input id=\"chkDProfesional\" type=\"checkbox\" onclick=\"PreguntaFormaDeporte(this, 'chkDProfesional', 'chkDAficionado', 'chkDAmateur');\" style=\"height: auto;\" />");
            //strHTMLTabla.Append("Aficionado&nbsp;<input id=\"chkDAficionado\" type=\"checkbox\" onclick=\"PreguntaFormaDeporte(this, 'chkDProfesional', 'chkDAficionado', 'chkDAmateur');\" style=\"height: auto;\" />");
            //strHTMLTabla.Append("Amateur&nbsp;<input id=\"chkDAmateur\" type=\"checkbox\" checked=\"true\" onclick=\"PreguntaFormaDeporte(this, 'chkDProfesional', 'chkDAficionado', 'chkDAmateur');\" style=\"height: auto;\" />                        ");

            strHTMLTabla.Append("<div id='divCubrirRiesgo' hidden>");
            strHTMLTabla.Append("<p>¿Desea cubrir el riesgo?</p>");
            strHTMLTabla.Append("SI&nbsp;<input id=\"chkSiRiesgo\" type=\"checkbox\" onclick=\"PreguntasSiNo(this, 'chkSiRiesgo', 'chkNoRiesgo');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("NO&nbsp;<input id=\"chkNoRiesgo\" type=\"checkbox\" checked=\"true\" onclick=\"PreguntasSiNo(this, 'chkSiRiesgo', 'chkNoRiesgo');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("<p>Si usted desea cubrir el riesgo, por favor solicite y requisite el cuestionario correspondiente.</p>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-12\">");
            strHTMLTabla.Append("<p><b>Hábitos</b></p>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>En caso de ingerir bebidas alcohólicas Indique cantidad de copas: </p>");
            strHTMLTabla.Append("<select id='txtCantBebida' name='txtCantBebida' onchange='selectCopas();' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            for (int i = 0; i < 251; i++)
            {
                strHTMLTabla.Append("<option>" + i + "</option>");
            }
            strHTMLTabla.Append("</select>");
            //strHTMLTabla.Append(" Indique cantidad en copas <input name=\"txtCantBebida\" type=\"text\" id=\"txtCantCopas\" class=\"form-control\" onkeypress=\"return KeyNumber(this, event);\" />");
            strHTMLTabla.Append("<div id='divFrecuencia' hidden>");
            strHTMLTabla.Append("<p>Frecuencia:</p>");
            strHTMLTabla.Append("<select id='txtFrecuenciaBebida' name='txtFrecuenciaBebida' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option>DIARIA</option>");
            strHTMLTabla.Append("<option>SEMANAL</option>");
            strHTMLTabla.Append("<option>MENSUAL</option>");
            strHTMLTabla.Append("</select>");
            // strHTMLTabla.Append("<input name=\"txtFrecuenciaBebida\" type=\"text\" id=\"txtFrecuenciaBebida\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\">");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div id='divFumar' class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>En caso de fumar:</p>");
            strHTMLTabla.Append("<select id='txtFuma' name='txtFuma' onchange='selectFuma();' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option id=\"chkCigarros\">CIGARROS</option>");
            strHTMLTabla.Append("<option id=\"chkPuro\">PURO</option>");
            strHTMLTabla.Append("<option id=\"chkPipa\">PIPA</option>");
            strHTMLTabla.Append("<option>NINGUNO</option>");
            strHTMLTabla.Append("</select>");
            // strHTMLTabla.Append("Cigarros&nbsp;<input id=\"chkCigarros\" type=\"checkbox\" onclick=\"PreguntaTipoFumar(this, 'chkCigarros', 'chkPuro', 'chkPipa');\" style=\"height: auto;\" />");
            //strHTMLTabla.Append("Puro&nbsp;<input id=\"chkPuro\" type=\"checkbox\" onclick=\"PreguntaTipoFumar(this, 'chkCigarros', 'chkPuro', 'chkPipa');\" style=\"height: auto;\" />");
            //strHTMLTabla.Append("Pipa&nbsp;<input id=\"chkPipa\" type=\"checkbox\" onclick=\"PreguntaTipoFumar(this, 'chkCigarros', 'chkPuro', 'chkPipa');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("<div id=\"divCantidadFumar\" hidden>");
            strHTMLTabla.Append("<p>Cantidad:</p>");
            strHTMLTabla.Append("<select id='txtCantidadFumar' name='txtCantidadFumar' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            for (int i = 0; i < 51; i++)
            {
                strHTMLTabla.Append("<option>" + i + "</option>");
            }
            strHTMLTabla.Append("</select>");
            strHTMLTabla.Append("</div>");

            strHTMLTabla.Append("<div id=\"divFrecuenciaFumar\" hidden>");
            strHTMLTabla.Append("<p>Frecuencia:</p>");
            strHTMLTabla.Append("<select id='txtFrecuenciaFumar' name='txtFrecuenciaFumar' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option>DIARIA</option>");
            strHTMLTabla.Append("<option>SEMANAL</option>");
            strHTMLTabla.Append("<option>MENSUAL</option>");
            strHTMLTabla.Append("</select>");
            strHTMLTabla.Append("</div>");

            //strHTMLTabla.Append("Cantidad:<input name=\"txtCantFumar\" type=\"text\" id=\"txtCantFumar\" class=\"form-control\" onkeypress=\"return KeyNumber(this, event);\" />");
            //strHTMLTabla.Append("y&nbsp;Frecuencia:<input name=\"txtFrecuenciaFumar\" type=\"text\" id=\"txtFrecuenciaFumar\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\" />");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            //strHTMLTabla.Append("<p>En caso de hacer uso de drogas o estimulantes indique:</p>");
            strHTMLTabla.Append("<p>Uso de drogas o estimulantes:</p>");
            strHTMLTabla.Append("SI&nbsp;<input id=\"chkSiDroga\" type=\"checkbox\" onclick=\"PreguntasSiNo(this, 'chkSiDroga', 'chkNoDroga');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("NO&nbsp;<input id=\"chkNoDroga\" type=\"checkbox\" checked=\"true\" onclick=\"PreguntasSiNo(this, 'chkSiDroga', 'chkNoDroga');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("<div id=\"divTipoFrecuencia\" hidden>");
            strHTMLTabla.Append("<p>Tipo y Frecuencia:</p>");
            strHTMLTabla.Append("<input name=\"txtTipoFrecuenciaDroga\" type=\"text\" id=\"txtTipoFrecuenciaDroga\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\">");
            strHTMLTabla.Append("</div>");
            //strHTMLTabla.Append("Tipo:<input name=\"txtTipoDroga\" type=\"text\" id=\"txtTipoDroga\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\" />");
            //strHTMLTabla.Append("y&nbsp;Frecuencia:<input name=\"txtFrecuenciaDroga\" type=\"text\" id=\"txtFrecuenciaDroga\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\" />");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p><b>&nbsp;</b></p>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-12\">");
            strHTMLTabla.Append("<p><b>Si en el pasado hizo uso de uno o varios de esos productos indique:</b></p>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-12\">");
            strHTMLTabla.Append("<table class=\"table table-bordered tab-border-red\" id=\"tblAdicciones\" >");
            strHTMLTabla.Append("<tbody>");
            strHTMLTabla.Append("<tr class=\"table-danger\" style=\"color:#FFF;\">");
            strHTMLTabla.Append("<td></td>");
            strHTMLTabla.Append("<td>Fecha Inicio</td>");
            strHTMLTabla.Append("<td>Fecha Fin</td>");
            strHTMLTabla.Append("<td>Motivo de término</td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td>Bebidas alcohólicas</td>");
            strHTMLTabla.Append("<td><input name=\"txtFIBebida\" type=\"date\" placeholder=\"dd/mm/yyyy\" maxlength=\"12\" id=\"txtFIBebida\"></td>");
            strHTMLTabla.Append("<td><input name=\"txtFFBebida\" type=\"date\" placeholder=\"dd/mm/yyyy\" maxlength=\"12\" id=\"txtFFBebida\"></td>");
            strHTMLTabla.Append("<td><input name=\"txtMotivoBebida\" type=\"text\" id=\"txtMotivoBebida\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\" /></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td>Fumar</td>");
            strHTMLTabla.Append("<td><input name=\"txtFIFumar\" type=\"date\" placeholder=\"dd/mm/yyyy\" maxlength=\"12\" id=\"txtFIFumar\"></td>");
            strHTMLTabla.Append("<td><input name=\"txtFFFumar\" type=\"date\" placeholder=\"dd/mm/yyyy\" maxlength=\"12\" id=\"txtFFFumar\"></td>");
            strHTMLTabla.Append("<td><input name=\"txtMotivoFumar\" type=\"text\" id=\"txtMotivoFumar\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\" /></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td>Drogas o estimulantes</td>");
            strHTMLTabla.Append("<td><input name=\"txtFIDroga\" type=\"date\" placeholder=\"dd/mm/yyyy\" maxlength=\"12\" id=\"txtFIDroga\"></td>");
            strHTMLTabla.Append("<td><input name=\"txtFFDroga\" type=\"date\" placeholder=\"dd/mm/yyyy\" maxlength=\"12\" id=\"txtFFDroga\"></td>");
            strHTMLTabla.Append("<td><input name=\"txtMotivoDroga\" type=\"text\" id=\"txtMotivoDroga\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\" /></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("</tbody>");
            strHTMLTabla.Append("</table>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-12\">");
            strHTMLTabla.Append("<p><b>Antecedentes familiares:</b></p>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-12\">");
            strHTMLTabla.Append("<table class=\"table table-bordered tab-border-red\" id=\"tblAntecFamiliar\" >");
            strHTMLTabla.Append("<tbody>");
            strHTMLTabla.Append("<tr class=\"table-danger\" style=\"color:#FFF;\">");
            strHTMLTabla.Append("<td></td>");
            strHTMLTabla.Append("<td>Edad</td>");
            strHTMLTabla.Append("<td>Estado de salud</td>");
            strHTMLTabla.Append("<td>Vive si/No</td>");
            strHTMLTabla.Append("<td>Edad de muerte</td>");
            strHTMLTabla.Append("<td>Motivos</td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td>Madre</td>");
            strHTMLTabla.Append("<td><input name=\"txtEdadMadre\" type=\"text\" maxlength=\"2\" id=\"txtEdadMadre\" class=\"form-control\" onkeypress=\"return KeyNumber(this, event);\" /></td>");
            strHTMLTabla.Append("<td>");
            strHTMLTabla.Append("<select id='txtEdoSaludMadre' name='txtEdoSaludMadre' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option>BUENO</option>");
            strHTMLTabla.Append("<option>MALO</option>");
            strHTMLTabla.Append("</select>");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td>");
            strHTMLTabla.Append("<select id='txtViveMadre' name='txtViveMadre' onchange='selectViveMadre();' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option>SI</option>");
            strHTMLTabla.Append("<option>NO</option>");
            strHTMLTabla.Append("</select>");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td><input name=\"txtEdadMuerteMadre\" type=\"text\" maxlength=\"3\" id=\"txtEdadMuerteMadre\" class=\"form-control\" onkeypress=\"return KeyNumber(this, event);\" disabled/></td>");
            strHTMLTabla.Append("<td><input name=\"txtMotivosMadre\" type=\"text\" id=\"txtMotivosMadre\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\" disabled/></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td>Padre</td>");
            strHTMLTabla.Append("<td><input name=\"txtEdadPadre\" type=\"text\" maxlength=\"2\" id=\"txtEdadPadre\" class=\"form-control\" onkeypress=\"return KeyNumber(this, event);\" /></td>");
            strHTMLTabla.Append("<td>");
            strHTMLTabla.Append("<select id='txtEdoSaludPadre' name='txtEdoSaludPadre' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option>BUENO</option>");
            strHTMLTabla.Append("<option>MALO</option>");
            strHTMLTabla.Append("</select>");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td>");
            strHTMLTabla.Append("<select id='txtVivePadre' onchange='selectVivePadre();' name='txtVivePadre' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option>SI</option>");
            strHTMLTabla.Append("<option>NO</option>");
            strHTMLTabla.Append("</select>");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td><input name=\"txtEdadMuertePadre\" type=\"text\" maxlength=\"3\" id=\"txtEdadMuertePadre\" class=\"form-control\" onkeypress=\"return KeyNumber(this, event);\" disabled/></td>");
            strHTMLTabla.Append("<td><input name=\"txtMotivosPadre\" type=\"text\" id=\"txtMotivosPadre\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\" disabled/></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td>Hermanos</td>");
            strHTMLTabla.Append("<td><input name=\"txtEdadHermanos\" type=\"text\" maxlength=\"2\" id=\"txtEdadHermanos\" class=\"form-control\" onkeypress=\"return KeyNumber(this, event);\" /></td>");
            strHTMLTabla.Append("<td>");
            strHTMLTabla.Append("<select id='txtEdoSaludHermanos' name='txtEdoSaludHermanos' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option>BUENO</option>");
            strHTMLTabla.Append("<option>MALO</option>");
            strHTMLTabla.Append("</select>");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td>");
            strHTMLTabla.Append("<select id='txtViveHermanos' onchange='selectViveHermanos();' name='txtViveHermanos' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option>SI</option>");
            strHTMLTabla.Append("<option>NO</option>");
            strHTMLTabla.Append("</select>");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td><input name=\"txtEdadMuerteHermanos\" type=\"text\" maxlength=\"3\" id=\"txtEdadMuerteHermanos\" class=\"form-control\" onkeypress=\"return KeyNumber(this, event);\" disabled/></td>");
            strHTMLTabla.Append("<td><input name=\"txtMotivosHermanos\" type=\"text\" id=\"txtMotivosHermanos\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\"disabled /></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td>Hijos</td>");
            strHTMLTabla.Append("<td><input name=\"txtEdadHijos\" type=\"text\" maxlength=\"2\" id=\"txtEdadHijos\" class=\"form-control\" onkeypress=\"return KeyNumber(this, event);\" /></td>");
            strHTMLTabla.Append("<td>");
            strHTMLTabla.Append("<select id='txtEdoSaludHijos' name='txtEdoSaludHijos' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option>BUENO</option>");
            strHTMLTabla.Append("<option>MALO</option>");
            strHTMLTabla.Append("</select>");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td>");
            strHTMLTabla.Append("<select id='txtViveHijos' onchange='selectViveHijos();' name='txtViveHijos' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option>SI</option>");
            strHTMLTabla.Append("<option>NO</option>");
            strHTMLTabla.Append("</select>");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td><input name=\"txtEdadMuerteHijos\" type=\"text\" maxlength=\"3\" id=\"txtEdadMuerteHijos\" class=\"form-control\" onkeypress=\"return KeyNumber(this, event);\" disabled/></td>");
            strHTMLTabla.Append("<td><input name=\"txtMotivosHijos\" type=\"text\" id=\"txtMotivosHijos\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\" disabled/></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("</tbody>");
            strHTMLTabla.Append("</table>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-12\">");
            strHTMLTabla.Append("<p><b>Sus padres tienen o han tenido alguna de las siguientes enfermedades:</b></p>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-12\">");
            strHTMLTabla.Append("<table class=\"table table-bordered tab-border-red\" id=\"tblEnfermedadesFam\" >");
            strHTMLTabla.Append("<tbody>");
            strHTMLTabla.Append("<tr class=\"table-danger\" style=\"color:#FFF;\">");
            strHTMLTabla.Append("<td></td>");
            strHTMLTabla.Append("<td>¿Quién?</td>");
            strHTMLTabla.Append("<td>Evolución</td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td>Enfermedad cardiaca</td>");
            strHTMLTabla.Append("<td>");
            strHTMLTabla.Append("<select id='txtQuienCardiaca' onchange='selectQuienCardiaca();' name='txtQuienCardiaca' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option>MADRE</option>");
            strHTMLTabla.Append("<option>PADRE</option>");
            strHTMLTabla.Append("<option>NINGUNO</option>");
            strHTMLTabla.Append("</select>");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td><input name=\"txtEvolucionCardiaca\" type=\"text\" maxlength=\"12\" id=\"txtEvolucionCardiaca\" disabled></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td>Cancer</td>");
            strHTMLTabla.Append("<td>");
            strHTMLTabla.Append("<select id='txtQuienCancer' onchange='selectQuienCancer();' name='txtQuienCancer' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option>MADRE</option>");
            strHTMLTabla.Append("<option>PADRE</option>");
            strHTMLTabla.Append("<option>NINGUNO</option>");
            strHTMLTabla.Append("</select>");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td><input name=\"txtEvolucionCancer\" type=\"text\" maxlength=\"12\" id=\"txtEvolucionCancer\" disabled></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td>Presión arterial alta</td>");
            strHTMLTabla.Append("<td>");
            strHTMLTabla.Append("<select id='txtQuienPresion' onchange='selectQuienPresion();' name='txtQuienPresion' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option>MADRE</option>");
            strHTMLTabla.Append("<option>PADRE</option>");
            strHTMLTabla.Append("<option>NINGUNO</option>");
            strHTMLTabla.Append("</select>");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td><input name=\"txtEvolucionPresion\" type=\"text\" maxlength=\"12\" id=\"txtEvolucionPresion\" disabled></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td>Diabetes</td>");
            strHTMLTabla.Append("<td>");
            strHTMLTabla.Append("<select id='txtQuienDiabetes' onchange='selectQuienDiabetes();' name='txtQuienDiabetes' class='form-control padding-left-0'>");
            strHTMLTabla.Append("<option>SELECCIONE</option>");
            strHTMLTabla.Append("<option>MADRE</option>");
            strHTMLTabla.Append("<option>PADRE</option>");
            strHTMLTabla.Append("<option>NINGUNO</option>");
            strHTMLTabla.Append("</select>");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td><input name=\"txtEvolucionDiabetes\" type=\"text\" maxlength=\"12\" id=\"txtEvolucionDiabetes\" disabled></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("</tbody>");
            strHTMLTabla.Append("</table>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-12\">");
            strHTMLTabla.Append("<p><b>CUESTIONARIO ¿Padeció y/o padece alguna de las siguientes enfermedades?</b></p>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-12\">");
            strHTMLTabla.Append("<table class=\"table table-bordered tab-border-red\" id=\"tblCuestionarioEnferm\" border=\"1\">");
            strHTMLTabla.Append("<tbody>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td>1</td>");
            strHTMLTabla.Append("<td style=\"width: 50%\">¿Le han practicado alguna intervención quirúrgica en los últimos 5 años o ha estado internado en algún hospital, clínica o sanatorio durante los últimos 5 años por alguna otra razón?</td>");
            strHTMLTabla.Append("<td align=\"center\">");
            strHTMLTabla.Append("SI&nbsp;<input id=\"chk1Si\" type=\"checkbox\" onclick=\"PreguntasSiNo(this, 'chk1Si', 'chk1No');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("NO&nbsp;<input id=\"chk1No\" type=\"checkbox\" checked=\"true\" onclick=\"PreguntasSiNo(this, 'chk1Si', 'chk1No');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td align=\"center\">Causa<input name=\"txt1Causa\" type=\"text\" id=\"txt1Causa\" disabled /></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td>2</td>");
            strHTMLTabla.Append("<td style=\"width: 50%\">¿Ha sido examinado o tratado durante los dos últimos años por algún médico, toma algún medicamento?</td>");
            strHTMLTabla.Append("<td align=\"center\">");
            strHTMLTabla.Append("SI&nbsp;<input id=\"chk2Si\" type=\"checkbox\" onclick=\"PreguntasSiNo(this, 'chk2Si', 'chk2No');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("NO&nbsp;<input id=\"chk2No\" type=\"checkbox\" checked=\"true\" onclick=\"PreguntasSiNo(this, 'chk2Si', 'chk2No');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td align=\"center\">Causa<input name=\"txt2Causa\" type=\"text\" id=\"txt2Causa\"  disabled/>");
            strHTMLTabla.Append("¿Desde cuándo?<input name=\"txt2Cuando\" type=\"text\" id=\"txt2Cuando\" disabled/></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td>3</td>");
            strHTMLTabla.Append("<td style=\"width: 50%\">¿Tiene alguna limitación física como consecuencia de enfermedad o accidente (sordera, cojera, mudez, pérdida de miembros, etc.) ó tiene alguna incapacidad o invalidez temporal o permanente?</td>");
            strHTMLTabla.Append("<td align=\"center\">");
            strHTMLTabla.Append("SI&nbsp;<input id=\"chk3Si\" type=\"checkbox\" onclick=\"PreguntasSiNo(this, 'chk3Si', 'chk3No');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("NO&nbsp;<input id=\"chk3No\" type=\"checkbox\" checked=\"true\" onclick=\"PreguntasSiNo(this, 'chk3Si', 'chk3No');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td align=\"center\">Causa<input name=\"txt3Causa\" type=\"text\" id=\"txt3Causa\" disabled/>");
            strHTMLTabla.Append("¿Desde cuándo?<input name=\"txt3Cuando\" type=\"text\" id=\"txt3Cuando\" disabled /></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td>4</td>");
            strHTMLTabla.Append("<td style=\"width: 50%\">¿Le ha sido practicado alguna prueba especial como: electrocardiograma, radiografía de algún órgano en concreto, curva de glucosa, prueba de la función hepática o renal, examen de SIDA?</td>");
            strHTMLTabla.Append("<td align=\"center\">");
            strHTMLTabla.Append("SI&nbsp;<input id=\"chk4Si\" type=\"checkbox\" onclick=\"PreguntasSiNo(this, 'chk4Si', 'chk4No');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("NO&nbsp;<input id=\"chk4No\" type=\"checkbox\" checked=\"true\" onclick=\"PreguntasSiNo(this, 'chk4Si', 'chk4No');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td align=\"center\">Causa<input name=\"txt4Causa\" type=\"text\" id=\"txt4Causa\" disabled/>");
            strHTMLTabla.Append("¿Desde cuándo?<input name=\"txt4Cuando\" type=\"text\" id=\"txt4Cuando\" disabled/></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td>5</td>");
            strHTMLTabla.Append("<td style=\"width: 50%\">¿Ha disminuido o aumentado su peso 10 kg o más en el último año?</td>");
            strHTMLTabla.Append("<td align=\"center\">");
            strHTMLTabla.Append("SI&nbsp;<input id=\"chk5Si\" type=\"checkbox\" onclick=\"PreguntasSiNo(this, 'chk5Si', 'chk5No');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("NO&nbsp;<input id=\"chk5No\" type=\"checkbox\" checked=\"true\" onclick=\"PreguntasSiNo(this, 'chk5Si', 'chk5No');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td align=\"center\">Kg aumentados<input name=\"txtKgAumentados\" type=\"text\" id=\"txtKgAumentados\" onkeypress=\"return KeyNumber(this, event);\" disabled/>");
            strHTMLTabla.Append("Kg disminuidos<input name=\"txtKgDisminuidos\" type=\"text\" id=\"txtKgDisminuidos\" onkeypress=\"return KeyNumber(this, event);\" disabled/></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr id='trMujer' class=\"table-danger\" style=\"color:#FFF;\">");
            strHTMLTabla.Append("<td>6</td>");
            strHTMLTabla.Append("<td>Preguntas adicionales para mujeres</td>");
            strHTMLTabla.Append("<td></td>");
            strHTMLTabla.Append("<td></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr id='trEnfermedadMujer'>");
            strHTMLTabla.Append("<td>a</td>");
            strHTMLTabla.Append("<td style=\"width: 50%\">¿Ha tenido una enfermedad propia de la mujer?</td>");
            strHTMLTabla.Append("<td align=\"center\">");
            strHTMLTabla.Append("SI&nbsp;<input id=\"chk7Si\" type=\"checkbox\" onclick=\"PreguntasSiNo(this, 'chk7Si', 'chk7No');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("NO&nbsp;<input id=\"chk7No\" type=\"checkbox\" checked=\"true\" onclick=\"PreguntasSiNo(this, 'chk7Si', 'chk7No');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td align=\"center\">Causa<input name=\"txt7Causa\" type=\"text\" id=\"txt7Causa\" hidden/></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr id='trEmbarazada'>");
            strHTMLTabla.Append("<td>b</td>");
            strHTMLTabla.Append("<td style=\"width: 50%\">¿Esta actualmente embarazada?</td>");
            strHTMLTabla.Append("<td align=\"center\">");
            strHTMLTabla.Append("SI&nbsp;<input id=\"chk8Si\" type=\"checkbox\" onclick=\"EstaEmbarazada(this, 'chk8Si', 'chk8No');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("NO&nbsp;<input id=\"chk8No\" type=\"checkbox\" checked=\"true\" onclick=\"EstaEmbarazada(this, 'chk8Si', 'chk8No');\" style=\"height: auto;\" />");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td align=\"center\">¿Cuántos meses?<input name=\"txt8Meses\" type=\"text\" id=\"txt8Meses\" disabled=\"true\" onblur=\"ValidaMeses();\" onkeypress=\"return KeyNumber(this, event);\" /></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr id='trRealizacion'>");
            strHTMLTabla.Append("<td>c</td>");
            strHTMLTabla.Append("<td style=\"width: 50%\">¿Fecha de realización del último<br />Papanicolau<br />Mamografía</td>");
            strHTMLTabla.Append("<td align=\"center\">");
            strHTMLTabla.Append("<br />");
            strHTMLTabla.Append("<input name=\"txtFPapanicolau\" type=\"text\" value=\"dd/mm/yyyy\" maxlength=\"12\" id=\"txtFPapanicolau\" /><br />");
            strHTMLTabla.Append("<input name=\"txtFMamografia\" type=\"text\" value=\"dd/mm/yyyy\" maxlength=\"12\" id=\"txtFMamografia\" />");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("<td align=\"center\">");
            strHTMLTabla.Append("<br />Resultado<input name=\"txtResPapanicolau\" type=\"text\" id=\"txtResPapanicolau\" />");
            strHTMLTabla.Append("Resultado<input name=\"txtResMamografia\" type=\"text\" id=\"txtResMamografia\" />");
            strHTMLTabla.Append("</td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("</tbody>");
            strHTMLTabla.Append("</table>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-12\">");
            strHTMLTabla.Append("<p><b>EN CASO AFIRMATIVO DE ALGUNA DE LAS PREGUNTAS ANTERIORES AMPLIAR LA INFORMACIÓN</b></p>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-12\">");
            strHTMLTabla.Append("<table class=\"table table-bordered tab-border-red\" id=\"tblAmpliacion\" border=\"1\">");
            strHTMLTabla.Append("<tbody>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td># pregunta</td>");
            strHTMLTabla.Append("<td>Padecimiento</td>");
            strHTMLTabla.Append("<td>Fecha de inicio</td>");
            strHTMLTabla.Append("<td>Duración</td>");
            strHTMLTabla.Append("<td>Estado actual y/o tratamiento y/o resultado</td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td><input name=\"txt1Pregunta\" type=\"text\" onkeypress=\"return KeyNumber(this, event);\" id=\"txt1Pregunta\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt1Padecimiento\" type=\"text\" id=\"txt1Padecimiento\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt1FInicio\" type=\"text\" value=\"dd/mm/yyyy\" maxlength=\"12\" id=\"txt1FInicio\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt1Duracion\" type=\"text\" id=\"txt1Duracion\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt1Estado\" type=\"text\" id=\"txt1Estado\" /></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td><input name=\"txt2Pregunta\" type=\"text\" onkeypress=\"return KeyNumber(this, event);\" id=\"txt2Pregunta\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt2Padecimiento\" type=\"text\" id=\"txt2Padecimiento\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt2FInicio\" type=\"text\" value=\"dd/mm/yyyy\" maxlength=\"12\" id=\"txt2FInicio\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt2Duracion\" type=\"text\" id=\"txt2Duracion\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt2Estado\" type=\"text\" id=\"txt2Estado\" /></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td><input name=\"txt3Pregunta\" type=\"text\" onkeypress=\"return KeyNumber(this, event);\" id=\"txt3Pregunta\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt3Padecimiento\" type=\"text\" id=\"txt3Padecimiento\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt3FInicio\" type=\"text\" value=\"dd/mm/yyyy\" maxlength=\"12\" id=\"txt3FInicio\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt3Duracion\" type=\"text\" id=\"txt3Duracion\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt3Estado\" type=\"text\" id=\"txt3Estado\" /></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td><input name=\"txt4Pregunta\" type=\"text\" onkeypress=\"return KeyNumber(this, event);\" id=\"txt4Pregunta\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt4Padecimiento\" type=\"text\" id=\"txt4Padecimiento\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt4FInicio\" type=\"text\" value=\"dd/mm/yyyy\" maxlength=\"12\" id=\"txt4FInicio\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt4Duracion\" type=\"text\" id=\"txt4Duracion\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt4Estado\" type=\"text\" id=\"txt4Estado\" /></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("</tbody>");
            strHTMLTabla.Append("</table>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \" id='divtxtNomDomMedico'>");
            strHTMLTabla.Append("<p>Nombre y domicilio del médico que acostumbra consultar:</p>");
            strHTMLTabla.Append("   <input name=\"txtNomDomMedico\" type=\"text\" id=\"txtNomDomMedico\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\">");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \" id='divtxtNHospital'>");
            strHTMLTabla.Append("<p>Nombre del hospital:</p>");
            strHTMLTabla.Append("<input name=\"txtNHospital\" type=\"text\" id=\"txtNHospital\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\">");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("");
            strHTMLTabla.Append("<div class=\"col-12\" id='idRefPersonales'>");
            strHTMLTabla.Append("<p><b>REFERENCIAS PERSONALES</b></p>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-12\" id='divtblRefPersonales'>");
            strHTMLTabla.Append("<table class=\"table table-bordered tab-border-red\" id=\"tblRefPersonales\" border=\"1\">");
            strHTMLTabla.Append("<tbody>");
            strHTMLTabla.Append("<tr class=\"table-danger\" style=\"color:#FFF;\">");
            strHTMLTabla.Append("<td>Nombre completo</td>");
            strHTMLTabla.Append("<td>Domicilio</td>");
            strHTMLTabla.Append("<td>Teléfono</td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td><input name=\"txt1Nombre\" type=\"text\" id=\"txt1Nombre\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt1Domicilio\" type=\"text\" id=\"txt1Domicilio\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt1Telefono\" type=\"text\" id=\"txt1Telefono\" onkeypress=\"return KeyNumber(this, event);\" /></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td><input name=\"txt2Nombre\" type=\"text\" id=\"txt2Nombre\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt2Domicilio\" type=\"text\" id=\"txt2Domicilio\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt2Telefono\" type=\"text\" id=\"txt2Telefono\" onkeypress=\"return KeyNumber(this, event);\" /></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("</tbody>");
            strHTMLTabla.Append("</table>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-12\">");
            strHTMLTabla.Append("<p><b>INFORMACIÓN EXCLUSIVA PARA LLENADO DEL AGENTE</b></p>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>1.- ¿Cuánto tiempo hace que conoce al (los) solicitante (s)?</p>");
            strHTMLTabla.Append("   <input name=\"txtTiempoConocer\" type=\"text\" id=\"txtTiempoConocer\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\">");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>2.- Indique el capital estimado del contratante y prima equivalente</p>");
            strHTMLTabla.Append("<input name=\"txtCapitalEstimado\" type=\"text\" id=\"txtCapitalEstimado\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\">");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>3.- ¿Existe algún riesgo peligroso dentro de su ocupación habitual?</p>");
            strHTMLTabla.Append("<input name=\"txtRiesgoPeligroso\" type=\"text\" id=\"txtRiesgoPeligroso\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\">");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>4.- ¿Conoce usted algo de su salud, hábitos, pasatiempos, ambiente o modo de vida que pudiera afectar el riesgo?</p>");
            strHTMLTabla.Append("<input name=\"txtSaludRiesgo\" type=\"text\" id=\"txtSaludRiesgo\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\">");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>5.- ¿En cuánto estima sus ingresos mensuales?</p>");
            strHTMLTabla.Append("<input name=\"txtIngresos\" type=\"text\" id=\"txtIngresos\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\">");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>6.- ¿Aparenta buena salud el solicitante?</p>");
            strHTMLTabla.Append("SI&nbsp;<input id=\"chkSaludSi\" type=\"checkbox\" onclick=\"PreguntasSiNo(this, 'chkSaludSi', 'chkSaludNo');\" style=\"height: auto;\">");
            strHTMLTabla.Append("NO&nbsp;<input id=\"chkSaludNo\" type=\"checkbox\" checked=\"true\" onclick=\"PreguntasSiNo(this, 'chkSaludSi', 'chkSaludNo');\" style=\"height: auto;\">");
            strHTMLTabla.Append("<input name=\"txtBuenaSalud\" type=\"text\" id=\"txtBuenaSalud\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\">");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>7.- ¿Le consta que el cliente firmó esta solicitud?</p><br>");
            strHTMLTabla.Append("SI&nbsp;<input id=\"chkFirmoSi\" type=\"checkbox\" onclick=\"PreguntasSiNo(this, 'chkFirmoSi', 'chkFirmoNo');\" style=\"height: auto;\">");
            strHTMLTabla.Append("NO&nbsp;<input id=\"chkFirmoNo\" type=\"checkbox\" checked=\"true\" onclick=\"PreguntasSiNo(this, 'chkFirmoSi', 'chkFirmoNo');\" style=\"height: auto;\">");
            strHTMLTabla.Append("<input name=\"txtFirmo\" type=\"text\" id=\"txtFirmo\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\">");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("&nbsp;");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-12\">");
            strHTMLTabla.Append("<table class=\"table table-bordered tab-border-red\" id=\"tblAgentes\" border=\"1\">");
            strHTMLTabla.Append("<tbody>");
            strHTMLTabla.Append("<tr class=\"table-danger\" style=\"color:#FFF;\">");
            strHTMLTabla.Append("<td>Nombre del (los) Agente(s)</td>");
            strHTMLTabla.Append("<td>Clave</td>");
            strHTMLTabla.Append("<td>Porcentaje</td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td><input name=\"txt1Agente\" type=\"text\" id=\"txt1Agente\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt1CveAg\" type=\"text\" id=\"txt1CveAg\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt1Porcentaje\" type=\"text\" id=\"txt1Porcentaje\" onkeypress=\"return KeyNumber(this, event);\" /></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td><input name=\"txt2Agente\" type=\"text\" id=\"txt2Agente\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt2CveAg\" type=\"text\" id=\"txt2CveAg\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt2Porcentaje\" type=\"text\" id=\"txt2Porcentaje\" onkeypress=\"return KeyNumber(this, event);\" /></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("<tr>");
            strHTMLTabla.Append("<td><input name=\"txt3Agente\" type=\"text\" id=\"txt3Agente\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt3CveAg\" type=\"text\" id=\"txt3CveAg\" /></td>");
            strHTMLTabla.Append("<td><input name=\"txt3Porcentaje\" type=\"text\" id=\"txt3Porcentaje\" onkeypress=\"return KeyNumber(this, event);\" /></td>");
            strHTMLTabla.Append("</tr>");
            strHTMLTabla.Append("</tbody>");
            strHTMLTabla.Append("</table>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>Teléfonos:</p>");
            strHTMLTabla.Append("<input name=\"txtTelefonoAgt\" type=\"text\" id=\"txtTelefonoAgt\" class=\"form-control\" onkeypress=\"return KeyNumber(this, event);\"/>");
            strHTMLTabla.Append("</div>");
            strHTMLTabla.Append("<div class=\"col-s12 col-md-6 col-lg-6 \">");
            strHTMLTabla.Append("<p>Correo electrónico</p>");
            strHTMLTabla.Append("<input name=\"txtMailAgt\" type=\"text\" id=\"txtMailAgt\" class=\"form-control\" onkeypress=\"ValidaCaptura(NUMERICO_PUNTO);\"/>");
            strHTMLTabla.Append("</div>");
            #endregion

            return strHTMLTabla.ToString().Replace("\t", "").Replace("\n", "");
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }


    // <--- C14 --->
    /// <summary>
    /// Método que consulta si se imprime una póliza o una solicitud.
    /// </summary>
    /// <param name="contrato">número de contrato</param>
    /// <param name="ramo">ramo</param>
    /// <param name="modalidad">modalidad</param>
    /// <returns>DataRow que contiene S o N para habilitar la opción de la solicitud prellenada.</returns>
    [Ajax.AjaxMethod()]
    public DataRow validaImpresion(int contrato, int ramo, int modalidad)
    {
        Catalogos objCatalogos = new Catalogos();

        try
        {
            return objCatalogos.validaImpresion(contrato, ramo, modalidad);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR MetodosAjax.validaImpresion(): " + ex.Message);
        }
    }


    // <--- C10 --->
    /// <summary>
    /// Método que consulta los beneficiarios según el tipo de seguro.
    /// </summary>
    /// <param name="ramo">ramo</param>
    /// <param name="Modalidad">modalidad</param>
    /// <param name="contrato">número de contrato seleccionado</param>
    /// <param name="tipoSeguro">tipo de seguro seleccionado</param>
    /// <param name="tipoBeneficiario">tipo de beneficiario seleccionado</param>
    /// <returns>DataTable que contiene los beneficiarios que cumplen con los parámetros ingresados</returns>
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable getParentescoSeguro(int ramo, string Modalidad, int contrato, string tipoSeguro,
                                         int tipoBeneficiario)
    {
        Catalogos objCatalogos = new Catalogos();
        try
        {
            DataTable dtParentesco = objCatalogos.getParentescoSeguro(ramo, Modalidad, contrato, tipoSeguro,
                                                                      tipoBeneficiario);

            return dtParentesco;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR MetodosAjax.getParentescoSeguro(): " + ex.Message);
        }
    }

    // <--- C16 --->
    /// <summary>
    /// Método para consultar las ocupaciones por ramo, modalidad y contrato
    /// </summary>
    /// <param name="ramo">Parámetro de tipo entero para almacenar el Código del Ramo.</param>
    /// <param name="Modalidad">>Parámetro de tipo cadena para almacenar la Modalidad</param>
    /// <param name="contrato">Parámetro de tipo entero para almacenar el número de contrato</param>
    /// <returns>DataTable con las ocupaciones correspondientes a los parámetros de entrada</returns>
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable getOcupacion(int ramo, string Modalidad, int contrato)
    {
        Catalogos objCatalogos = new Catalogos();
        try
        {
            DataTable dtParentesco = objCatalogos.getOcupacion(ramo, Modalidad, contrato);

            return dtParentesco;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR MetodosAjax.getOcupacion(): " + ex.Message);
        }
    }

    // <--- C15 --->
    /// <summary>
    /// Método que valida si se realiza una póliza o una solicitud.
    /// </summary>
    /// <param name="ramo">ramo</param>
    /// <param name="Modalidad">modalidad</param>
    /// <param name="contrato">número de contrato</param>
    /// <returns>DataRow que contiene S o N para imprimir póliza o solicitud.</returns>
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataRow validaImprimePolizaSolicitud(int ramo, int Modalidad, int contrato)
    {
        Catalogos objCatalogos = new Catalogos();

        try
        {
            DataRow dtPolizaSolicitud = objCatalogos.validaImprimePolizaSolicitud(ramo, Modalidad, contrato);

            return dtPolizaSolicitud;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR MetodosAjax.validaImprimePolizaSolicitud(): " + ex.Message);
        }
    }


    [Ajax.AjaxMethod()]
    public DataRow validaPrimaMinima(string strPrima, int Moneda, string strFormaPago,
                                    string codPortal, string codCia, string codRamo,
                                    string codModalidad, string numContrato)
    {
        Catalogos objCatalogos = new Catalogos();
        try
        {
            return objCatalogos.validaPrimaMinima(strPrima, Moneda, strFormaPago, codPortal, codCia,
                                                    codRamo, codModalidad, numContrato);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    /// <summary>
    /// Obtiene el mensaje a mostrar al usuario de los montos de la politica
    /// de lavado de dindero
    /// </summary>
    /// <param name="strPrima">Prima Neta</param>
    /// <param name="Moneda">Moneda</param>
    /// <returns>Mensaje</returns>
    [Ajax.AjaxMethod()]
    public DataRow validaPoliticaLavadoDeDinero(string codPortal, string codCia, string codRamo,
                                                string codModalidad, string numContrato, int Moneda,
                                                string strPrima)
    {
        Catalogos objCatalogos = new Catalogos();
        try
        {
            return objCatalogos.validaPoliticaLavadoDeDinero(codPortal, codCia, codRamo, codModalidad,
                                                             numContrato, Moneda, strPrima);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string getCoberturas(int CodRamo, string contrato, int Moneda)
    {
        Catalogos objCatalogos = new Catalogos();
        try
        {
            StringBuilder strHTMLTabla = new StringBuilder();
            DataTable objDataTable = objCatalogos.getCoberturas(CodRamo, contrato, Moneda);

            strHTMLTabla.Append("<table id='Coberturas' class='table table-bordered tab-border-red' style='width: 100%;display:table-row;'>");
            strHTMLTabla.Append("<tr class='table-danger'>");
            strHTMLTabla.Append("<td></td><td>Cobertura</td><td>Suma Asegurada</td><td>Prima</td>");
            strHTMLTabla.Append("</tr>");
            int ContAux = 1;
            foreach (DataRow dr in objDataTable.Rows)
            {
                strHTMLTabla.Append("<tr>");
                strHTMLTabla.Append("<td align=\"center\" ><INPUT id='chk" + ContAux.ToString() + "' ");
                if (dr["MCA_OBLIGATORIA"].ToString() == "S")
                    strHTMLTabla.Append("disabled='disabled' checked='checked' ");
                strHTMLTabla.Append("type='checkbox' value='" + dr[0].ToString() +
                                    "' runat='server' onclick=\"actMarcaCobertura(" + dr[0].ToString() +
                                    ",'chk" + ContAux.ToString() + "','txtSuma" + dr[0].ToString() + "');\" ></td>");
                strHTMLTabla.Append("<td  class=\"EtiquetaGeneralIzquierda\" ><input type='text' disabled='disabled' value='" + dr[1].ToString() + "' runat='server' id='Cobertura" + dr[0] + "' /></td>");
                strHTMLTabla.Append("<td><INPUT id='txtSuma" + dr[0].ToString() + "'");
                if (dr["MCA_OBLIGATORIA"].ToString() != "S")
                    strHTMLTabla.Append(" disabled= 'disabled' ");
                strHTMLTabla.Append(" type='text' " + " runat='server' class=\"EtiquetaGeneralDescripcion\" onkeypress='return KeyNumber(this, event);'" +
                    //" style='width: 90px;text-align:right' onblur=\"actSumaAseg(" + dr[0].ToString() + ",'txtSuma" + dr[0].ToString() + "');\" ></td>");
                                    " style='width: 90px;text-align:right' onblur=\"actSumaAseg(" + dr[0].ToString() + ",'txtSuma" + dr[0].ToString() + "');\" ></td>");
                strHTMLTabla.Append("<td><INPUT id='txtPrima" + dr[0].ToString() + "' type='text' " +
                                    " runat='server' class=\"EtiquetaGeneralDescripcion\" readonly='readonly' style='width: 90px;text-align:right' >");
                strHTMLTabla.Append("<input id='hdnSumaAsegDesde" + dr[0].ToString() +
                                    "' runat='server' type='hidden' value='" +
                                    dr["SUMA_ASEG_DESDE"].ToString() + "' />");
                strHTMLTabla.Append("<input id='hdnSumaAsegHasta" + dr[0].ToString() +
                                    "' runat='server' type='hidden' value='" +
                                    dr["SUMA_ASEG_HASTA"].ToString() + "' />");
                strHTMLTabla.Append("</td>");
                strHTMLTabla.Append("</tr>");

                ContAux++;
            }
            strHTMLTabla.Append("</table>");

            return strHTMLTabla.ToString();

        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    //-------->C11<-------
    /// <summary>
    ///     Se encarga de generar el codigo html con los radio buttons 
    ///     obtenidos de la consulta a la base de datos. (Tipo de seguros)
    /// </summary>
    /// <param name="CodigoRamo"></param>
    /// <param name="contrato"></param>
    /// <param name="Modalidad"></param>
    /// <returns></returns>

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string getObtieneTipoSeguros(int CodigoRamo, int contrato, int Modalidad, string coberturas)
    {
        StringBuilder htmlSeguros = new StringBuilder();
        Catalogos objCatalogos = new Catalogos();
        int ContAux = 0;
        try
        {
            DataTable seguros = objCatalogos.getObtieneTipoSeguros(CodigoRamo, contrato, Modalidad, coberturas);

            foreach (DataRow dr in seguros.Rows)
            {
                if (dr[0].ToString() == "P")
                {
                    htmlSeguros.Append("<input name='rblTipoSeguro' checked='true' id='rblTipoSeguro_" + ContAux.ToString() + "'  type='radio' value='"
                                        + dr[0].ToString() + "' runat='server' onclick='OcultarMostrarBeneficiario()' /> " + dr[1].ToString() +
                                        "<span style='margin-right:20px;'></span>");
                }
                else
                {
                    htmlSeguros.Append("<input name='rblTipoSeguro' id='rblTipoSeguro_" + ContAux.ToString() + "'  type='radio' value='"
                                        + dr[0].ToString() + "' runat='server' onclick='OcultarMostrarBeneficiario()' /> " + dr[1].ToString()
                                        + "<span style='margin-right:20px;'></span>");
                }
                ContAux++;
            }

            return htmlSeguros.ToString();
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR MetodosAjax.getObtieneTipoSeguros(): " + ex.Message);
        }
    }

    //-------->C12<-------
    /// <summary>
    ///     Se encarga de generar el codigo html que se insertará en los tooltips 
    ///     con los documentos que se deben adjuntar
    /// </summary>
    /// <param name="CodigoRamo"></param>
    /// <param name="contrato"></param>
    /// <param name="Modalidad"></param>
    /// <returns></returns>

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string getDocumentosAdjuntar(int CodigoRamo, int contrato, int Modalidad)
    {
        Catalogos objCatalogos = new Catalogos();

        try
        {
            string documentos = objCatalogos.getValidaDocumento(CodigoRamo, contrato, Modalidad);
            return documentos;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR MetodosAjax.getDocumentosAdjuntar(): " + ex.Message);
        }
    }

    /// <summary>
    /// Método que consulta las coberturas por edad
    /// </summary>
    /// <param name="CodigoRamo">ramo</param>
    /// <param name="contrato">número de contrato</param>
    /// <param name="Modalidad">modalidad</param>
    /// <param name="Edad">edad</param>
    /// <param name="Moneda">código de moneda</param>
    /// <returns>DataTable con las coberturas, tope máximo y mínimo de edad.</returns>
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string getCoberturasEdad(int CodigoRamo, string contrato, string Modalidad, int Edad, int Moneda, int Tip_plan)
    {
        Catalogos objCatalogos = new Catalogos();

        try
        {
            StringBuilder strHTMLTabla = new StringBuilder();
            DataTable objDataTable = objCatalogos.getCoberturasEdad(CodigoRamo, contrato, Modalidad, Edad, Moneda);
            DataView objDataTable2 = new DataView(objDataTable);
            if (Tip_plan == 3 && contrato == WebUtils.getAppSetting("contratoSeGATW").ToString())
            {
                DataTable objTemporal = objCatalogos.getCoberturasEdad(CodigoRamo, WebUtils.getAppSetting("contratotvm").ToString(),
                                        Modalidad, Edad, Moneda);
                foreach (DataRow dr in objDataTable.Rows)
                {
                    if (dr["COD_COB"].ToString() == "1000")
                    {
                        dr["SUMA_ASEG_DESDE"] = objTemporal.Rows[0].ItemArray[5];
                        dr["SUMA_ASEG_HASTA"] = objTemporal.Rows[0].ItemArray[6];
                    }
                }
            }
            // --> C5 <--
            DataView vistaTabla = new DataView(objDataTable);
            DataTable cobertura;
            DataRow row = null;
            DataTable coberturasOrganizadas;
            coberturasOrganizadas = objDataTable.Clone();

            // --> C20 <--



            string[] consultas = new string[] {
                "NOM_COB = 'BASICA'",
                "NOM_COB = 'BIT' OR NOM_COB = 'BIT-A'",
                "NOM_COB = 'BIPA'",
                "NOM_COB = 'EG' OR NOM_COB = 'ENFERMEDADES GRAVES'",
                "NOM_COB = 'MA' OR NOM_COB = 'MUERTE ACCIDENTAL'",
                "NOM_COB = 'PO' OR NOM_COB = 'PERDIDAS ORGANICAS'",
                "NOM_COB = 'MAC' OR NOM_COB = 'MUERTE ACCIDENTAL COLECTIVA'",
                "NOM_COB = 'POC'",
                "NOM_COB = 'MAPO'",
                "NOM_COB = 'MAPOC'",
                "NOM_COB = 'PASI'",
                "NOM_COB = 'SERVICIOS FUNERARIOS'",
            };

            //Filtro de las coberturas con los ordenes especificos
            if (CodigoRamo == 105)
            { }
            else
            {
                foreach (var item in consultas)
                {
                    vistaTabla.RowFilter = item;

                    cobertura = vistaTabla.ToTable();

                    if (!(cobertura.Rows.Count == 0))
                    {
                        row = cobertura.Rows[0];
                        coberturasOrganizadas.ImportRow(row);
                        vistaTabla.Delete(0);
                    }
                }
            }

            vistaTabla.RowFilter = "";
            coberturasOrganizadas.Merge(vistaTabla.ToTable());

            if (CodigoRamo == 105)
            {
                //if (coberturasOrganizadas.Rows.Count > 1)
                //{
                //    objDataTable = objDataTable2.ToTable().Copy();

                //}
                //else
                //{
                objDataTable = coberturasOrganizadas;
                //}

            }
            else
            {
                objDataTable = coberturasOrganizadas;
            }
            //-------------------
            if (objDataTable.Rows.Count > 0)
            {

                strHTMLTabla.Append("<table id='Coberturas' class='table table-bordered tab-border-red' style='width: 100%;display:table-row;'>");

                strHTMLTabla.Append("<tr class='table-danger'>");
                strHTMLTabla.Append("<td></td><td>Cobertura</td><td>Suma Asegurada</td><td>Prima</td>");
                strHTMLTabla.Append("</tr>");
                int ContAux = 1;

                foreach (DataRow dr in objDataTable.Rows)
                {
                    strHTMLTabla.Append("<tr id=" + dr[0] + ">");
                    strHTMLTabla.Append("<td align=\"center\" ><input ");
                    #region comment
                    //if (CodigoRamo == 105)
                    //{
                    //    if (Edad > 17)
                    //    {
                    //        if (dr["MCA_OBLIGATORIO"].ToString() == "S")
                    //            strHTMLTabla.Append("disabled='disabled' checked='checked' ");

                    //        else
                    //        {
                    //            if (dr["MCA_OBLIGATORIA"].ToString() == "S")
                    //                strHTMLTabla.Append("disabled='disabled' checked='checked' ");
                    //        }

                    //    }
                    //}
                    //else
                    //{
                    #endregion
                    if (dr["MCA_OBLIGATORIA"].ToString() == "S")
                    { strHTMLTabla.Append("disabled='disabled' checked='checked' "); }
                    #region comment2
                    //}

                    //-------> C5 <-------------
                    //if (CodigoRamo == 105)
                    //{
                    //    if (Edad > 17)
                    //    {
                    //    if (dr[1].ToString() != "1500")
                    //        strHTMLTabla.Append("name='chkCobertura' id='chk" + ContAux.ToString() + "'  type='checkbox' value='" + dr[1].ToString() +
                    //                            "' onclick=\"actMarcaCobertura(" + dr[1].ToString() + ",'chk" + ContAux.ToString() + "','txtSuma" +
                    //                            dr[1].ToString() + "');\" /></td>");
                    //    else

                    //        strHTMLTabla.Append("name='chkCobertura' id='chk" + ContAux.ToString() + "'  type='checkbox' value='" + dr[1].ToString() +
                    //                            "' onclick=\"actMarcaCobertura(" + dr[1].ToString() + ",'chk" + ContAux.ToString() + "','txtSuma" +
                    //                            dr[1].ToString() + "'); validaSAtemporal(); muestracuest();\" /></td>");
                    //    }
                    //    else
                    //    {
                    //       if (dr["MCA_ACCIDENTES"].ToString() == "S")
                    //        strHTMLTabla.Append("name='rbCobertura' id='chk" + ContAux.ToString() + "'  type='radio' value='" + dr[0].ToString() +
                    //                            "' onclick=\"actMarcaCobertura(" + dr[0].ToString() + ",'chk" + ContAux.ToString() + "','txtSuma" +
                    //                            dr[0].ToString() + "');\" /></td>");
                    //    //MU-080082 Se agrega la funcionalidad para la cobertura temporal INI
                    //    else if (dr[0].ToString() != "1500")
                    //        strHTMLTabla.Append("name='chkCobertura' id='chk" + ContAux.ToString() + "'  type='checkbox' value='" + dr[0].ToString() +
                    //                            "' onclick=\"actMarcaCobertura(" + dr[0].ToString() + ",'chk" + ContAux.ToString() + "','txtSuma" +
                    //                            dr[0].ToString() + "');\" /></td>");
                    //    else

                    //        strHTMLTabla.Append("name='chkCobertura' id='chk" + ContAux.ToString() + "'  type='checkbox' value='" + dr[0].ToString() +
                    //                            "' onclick=\"actMarcaCobertura(" + dr[0].ToString() + ",'chk" + ContAux.ToString() + "','txtSuma" +
                    //                            dr[0].ToString() + "'); validaSAtemporal(); muestracuest();\" /></td>");
                    //    }
                    //}
                    //else
                    //{
                    #endregion
                    if (dr["MCA_ACCIDENTES"].ToString() == "S")
                    {
                        strHTMLTabla.Append("name='rbCobertura' id='chk" + ContAux.ToString() + "'  type='radio' value='" + dr[0].ToString() +
                                               "' onclick=\"actMarcaCobertura(" + dr[0].ToString() + ",'chk" + ContAux.ToString() + "','txtSuma" +
                                               dr[0].ToString() + "');\" /></td>");
                    }
                    //MU-080082 Se agrega la funcionalidad para la cobertura temporal INI
                    else if (dr[0].ToString() != "1500")
                    {
                        strHTMLTabla.Append("name='chkCobertura' id='chk" + ContAux.ToString() + "'  type='checkbox' value='" + dr[0].ToString() +
                                               "' onclick=\"actMarcaCobertura(" + dr[0].ToString() + ",'chk" + ContAux.ToString() + "','txtSuma" +
                                               dr[0].ToString() + "');\" /></td>");
                    }
                    else
                    {
                        strHTMLTabla.Append("name='chkCobertura' id='chk" + ContAux.ToString() + "'  type='checkbox' value='" + dr[0].ToString() +
                                            "' onclick=\"actMarcaCobertura(" + dr[0].ToString() + ",'chk" + ContAux.ToString() + "','txtSuma" +
                                            dr[0].ToString() + "'); validaSAtemporal(); muestracuest();\" /></td>");
                    }
                    #region comment
                    //}
                    //MU-080082 Se agrega la funcionalidad para la cobertura temporal FIN
                    //---> C6 <---
                    //if (CodigoRamo == 105)
                    //{
                    //    if (Edad >17)
                    //    {
                    //    strHTMLTabla.Append("<td class=\"EtiquetaGeneralIzquierda\" ><div onmouseover=\"mostrar2(event, '" + dr["NOM_COB"].ToString() +
                    //                       "', 'tooltipCoberturas', 35)\" onmouseout=\"ocultar('tooltipCoberturas')\">" + dr[0].ToString() + "</div></td>");
                    //    strHTMLTabla.Append("<td><input id='txtSuma" + dr[1].ToString() + "'");
                    //    }
                    //    else
                    //    {
                    //    strHTMLTabla.Append("<td class=\"EtiquetaGeneralIzquierda\" ><div onmouseover=\"mostrar2(event, '" + dr["DESCRIPCION"].ToString() +
                    //                        "', 'tooltipCoberturas', 35)\" onmouseout=\"ocultar('tooltipCoberturas')\">" + dr[1].ToString() + "</div></td>");
                    //    strHTMLTabla.Append("<td><input id='txtSuma" + dr[0].ToString() + "'");
                    //    }
                    //}
                    //else
                    //{
                    #endregion
                    strHTMLTabla.Append("<td class=\"EtiquetaGeneralIzquierda\" ><div id=\"Coberturas" + dr[0].ToString() + "\" onmouseover=\"mostrar2(event, '" + dr["DESCRIPCION"].ToString() +
                                        "', 'tooltipCoberturas', 35)\" onmouseout=\"ocultar('tooltipCoberturas')\">" + dr[1].ToString() + "</div></td>");
                    strHTMLTabla.Append("<td><input id='txtSuma" + dr[0].ToString() + "'");
                    #region Comment
                    //}

                    //    if (CodigoRamo == 105)
                    //{
                    //    if (Edad > 17)
                    //    {
                    //        if (dr["MCA_OBLIGATORIO"].ToString() != "S")
                    //        strHTMLTabla.Append(" disabled='disabled' ");
                    //    }
                    //    else
                    //    {
                    //          if (dr["MCA_OBLIGATORIA"].ToString() != "S")
                    //        strHTMLTabla.Append(" disabled='disabled' ");
                    //    }
                    //}
                    //else
                    //{
                    #endregion
                    if (dr["MCA_OBLIGATORIA"].ToString() != "S")
                    { strHTMLTabla.Append(" disabled='disabled' "); }
                    //}
                    //AEP BWMEILL. Millón Vida Fase 2. Agregar la modalidad 11103 para PPR.
                    if (Modalidad == "11101" || Modalidad == "11102" || Modalidad == "11103")
                    {
                        strHTMLTabla.Append(" type='text' " + " class=\"EtiquetaGeneralDescripcion\" disabled='disabled' readonly='readonly' style='width: 90px;" +
                                            "text-align:right; border-top-style: none; border-right-style: none; border-left-style: none; border-bottom-style: none'" +
                                            "onblur=\"actSumaAseg(" + dr[0].ToString() + ",'txtSuma" + dr[0].ToString() + "');\" /></td>");
                        //MU-080082 Se inhabilita el campo de Prima para la cobertura temporal INI

                        if (dr[0].ToString() == "1000")
                        {
                            strHTMLTabla.Append("<td><input id='txtPrima" + dr[0].ToString() + "' type='text' " + " class=\"EtiquetaGeneralDescripcion\" onkeypress='return KeyNumber(this, event);'" +
                                                "style='width: 90px;text-align:right;border-top-style: none; border-right-style: none;" +
                                                " border-left-style: none; border-bottom-style: none' />");
                        }
                        else
                        {
                            strHTMLTabla.Append("<td><input id='txtPrima" + dr[0].ToString() + "' type='text' disabled='disabled' " + " class=\"EtiquetaGeneralDescripcion\" onkeypress='return KeyNumber(this, event);'" +
                                                "style='width: 90px;text-align:right;border-top-style: none; border-right-style: none;" +
                                                " border-left-style: none; border-bottom-style: none' />");
                        }
                        //MU-080082 Se inhabilita el campo de Prima para la cobertura temporal FIN
                    }
                    else
                    {
                        strHTMLTabla.Append(" type='text' " + " class=\"EtiquetaGeneralDescripcion\" onkeypress='return KeyNumber(this, event);' style='width: 90px;" +
                                            "text-align:right; border-top-style: none; border-right-style: none; border-left-style: none; border-bottom-style: none'" +
                                            "onblur=\"actSumaAseg(" + dr[0].ToString() + ",'txtSuma" + dr[0].ToString() + "');\" /></td>");
                        strHTMLTabla.Append("<td><input id='txtPrima" + dr[0].ToString() + "' type='text' " + " class=\"EtiquetaGeneralDescripcion\" disabled='disabled'" +
                                            "readonly='readonly' style='width: 90px;text-align:right;border-top-style: none; border-right-style: none;" +
                                            " border-left-style: none; border-bottom-style: none' />");
                    }
                    #region Comment
                    //if (CodigoRamo == 105)
                    //{
                    //    if (Edad > 17)
                    //    {}
                    //    else
                    //    {
                    //        strHTMLTabla.Append("<input id='hdnSumaAsegDesde" + dr[0].ToString() + "' type='hidden' value='" + dr["SUMA_ASEG_DESDE"].ToString() + "' />");
                    //    strHTMLTabla.Append("<input id='hdnSumaAsegHasta" + dr[0].ToString() + "' type='hidden' value='" + dr["SUMA_ASEG_HASTA"].ToString() + "' />");
                    //    strHTMLTabla.Append("<input id='hdnMarcaAcc" + dr[0].ToString() + "' type='hidden' value='" + dr["MCA_ACCIDENTES"].ToString() + "' />");

                    //    }
                    //}
                    //else
                    //{
                    #endregion
                    strHTMLTabla.Append("<input id='hdnSumaAsegDesde" + dr[0].ToString() + "' type='hidden' value='" + dr["SUMA_ASEG_DESDE"].ToString() + "' />");
                    strHTMLTabla.Append("<input id='hdnSumaAsegHasta" + dr[0].ToString() + "' type='hidden' value='" + dr["SUMA_ASEG_HASTA"].ToString() + "' />");
                    strHTMLTabla.Append("<input id='hdnMarcaAcc" + dr[0].ToString() + "' type='hidden' value='" + dr["MCA_ACCIDENTES"].ToString() + "' />");
                    //}
                    strHTMLTabla.Append("</td>");
                    strHTMLTabla.Append("</tr>");

                    ContAux++;
                }
                strHTMLTabla.Append("</table>");
                //--->C6<---
                strHTMLTabla.Append("<div id=\"tooltipCoberturas\" style=\"position:absolute;border:2px solid red;" +
                                      "min-width:250px;display:none;text-align:left;    background: rgb(228, 35, 19);color: rgb(255, 255, 255);\">prueba</div>");

            }
            else
            {
                if (Moneda != 0 && Modalidad != "-1")
                {
                    strHTMLTabla.Append(" ");
                }
            }
            return strHTMLTabla.ToString();
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR MetodosAjax.getCoberturasEdad(): " + ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public DataTable getDctoSexoFuma(int CodigoRamo, string Modalidad, int CodCob)
    {
        Catalogos objCatalogos = new Catalogos();

        try
        {
            return objCatalogos.getDctoSexoFuma(CodigoRamo, Modalidad, CodCob);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataSet getCotiza(String[] arrDatosPoliza, String[] arrDatosVariables, String[] arrDatosBeneficiarios, String[] arrDatosCoberturas, String[] arrDatosAsegurados, String[] arrDatosFunerarios, String[] arrDatosMancomunado, String[] arrDatosImpresion)
    {
        DataRow cotizacion = null;
        Emision objCotiza = new Emision("C");
        CDEmision objCotizaCalculo = new CDEmision();
        DataSet objDS = null;
        try
        {
            OracleConnection conexion = MConexion.getConexion("ConnectionTW");
            //OracleConnection conexion = MConexion.getConexion("ConnectionSeGATEMP");

            try
            {
                cotizacion = objCotiza.setCotizacion(arrDatosPoliza, arrDatosVariables, arrDatosBeneficiarios, arrDatosCoberturas, arrDatosAsegurados, arrDatosFunerarios, arrDatosMancomunado, conexion);
                if (cotizacion[0] != System.DBNull.Value)
                {
                    Session["variableAnexos"] = @"C:\xprfiles\Cotizacion\CotizacionVida_TW\CotizacionVida" + cotizacion[0].ToString() + ".pdf"; //Variable fija para envio de correo

                    objDS = objCotizaCalculo.getCalculos(cotizacion[0].ToString(), conexion);
                    Session.Add("numCotizacion", cotizacion[0].ToString());
                    DataTable objTabla = new DataTable();
                    objTabla.Columns.Add("COTIZACION");
                    DataRow objRow = objTabla.NewRow();
                    objRow["cotizacion"] = cotizacion[0].ToString();
                    objTabla.Rows.Add(objRow);
                    objDS.Tables.Add(objTabla);

                    objDS.Tables.Remove("Table");
                    /*                    objTabla = new DataTable();
                                        objTabla = getPrimas(cotizacion[0].ToString(), conexion);
                                        objDS.Tables.Add(objTabla.Copy());
                    */
                }
                else throw new Exception(cotizacion[1].ToString());

                Session.Add("DatosPoliza", arrDatosPoliza);
                Session.Add("DatosVariables", arrDatosVariables);
                Session.Add("DatosBeneficiarios", arrDatosBeneficiarios);
                Session.Add("DatosCoberturas", arrDatosCoberturas);
                Session.Add("DatosAsegurados", arrDatosAsegurados);
                Session.Add("DatosMancomunado", arrDatosMancomunado);
                Session.Add("Calculos", objDS);
                Session.Add("DatosImpresion", arrDatosImpresion);
            }
            finally
            {
                ((IDisposable)conexion).Dispose();
            }
        }
        catch (Exception ex)
        {
            string strMensaje = "";

            try
            {
                OracleConnection conexion = MConexion.getConexion("ConnectionSeGATEMP");
                try
                {
                    strMensaje = ExceptionUtil.TWDescripcion(ex.Message, "TRONWEB", conexion);
                }
                finally
                {
                    ((IDisposable)conexion).Dispose();
                }
            }
            catch (Exception ignorar)
            {
                strMensaje = ex.Message;
            }
            throw new Exception(strMensaje);
        }
        if (Session["sUSUARIO"] != null)
        {

            using (OracleConnection conexion2 = MConexion.getConexion("ConnectionSeGATEMP"))
            {
                Usuario objUsuario = (Usuario)(Session["sUSUARIO"]);
                int evento = Convert.ToInt32(WebUtils.getAppSetting("EventoCotizacion"));
                EventoUtil.registraEvento(objUsuario.USUARIO, 1, evento, cotizacion[0].ToString(), "", objUsuario.COD_AGENTE, false, conexion2);
            }
        }

        return objDS;
    }

    // Funcion que devuelve los datos variables
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable getDatosVariables(int ramo)
    {
        OracleConnection conexion = MConexion.getConexion("ConnectionTW");
        Catalogos objVariables = new Catalogos();

        try
        {
            return objVariables.getDatosVariables(ramo, conexion);
        }
        catch (Exception ex)
        {
            throw new Exception("ERROR Cotizacion.getDatosVariables() : " + ex.Message);
        }
        finally
        {
            ((IDisposable)conexion).Dispose();
        }
    }



    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataSet getCotizacion(string accion, String[] arrDatosPoliza, String[] arrDatosVar, String[] arrDatosCob, String[] arrDatosCont, String[] arrDatosSol, String[] arrDatosBenef, String[] arrDatosBanco, string p_token)
    {
        Emision objCotizacion = new Emision(accion);
        try
        {
            objCotizacion.token = p_token;

            DataSet objDataSet = objCotizacion.getCotizacion(arrDatosPoliza, arrDatosVar, arrDatosCob, arrDatosCont, arrDatosSol, arrDatosBenef, arrDatosBanco);
            objDataSet = AgregarTablaPrimas(objDataSet);
            return objDataSet;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataSet getSolicitud(string accion, String[] arrDatosPoliza, String[] arrDatosVar, String[] arrDatosCob, String[] arrDatosCont, String[] arrDatosSol, String[] arrDatosBenef, String[] arrDatosBanco, string p_token)
    {
        string p_wf_ot_m_ot;
        Emision objCotizacion = new Emision(accion);
        Catalogos objCatalogos = new Catalogos();

        try
        {
            objCotizacion.token = p_token;
            int cod_usr;
            String[] DatosBenef = new String[0];

            DataSet objDataSet = objCotizacion.getCotizacion(arrDatosPoliza, arrDatosVar, arrDatosCob, arrDatosCont, arrDatosSol, DatosBenef, arrDatosBanco);

            string strCotizacion = objDataSet.Tables[4].Rows[0]["COTIZACION"].ToString();
            GuardarBeneficiarios(strCotizacion, arrDatosBenef);

            DataTable dtFolioRAM = new DataTable();
            dtFolioRAM.Columns.Add("FOLIO_RAM");
            string strFolioRAM = ObtenerFolioRAMSolicitud(objDataSet.Tables[4].Rows[0][0].ToString());
            DataRow dr = dtFolioRAM.NewRow();
            dr["FOLIO_RAM"] = strFolioRAM;
            dtFolioRAM.Rows.Add(dr);
            objDataSet.Tables.Add(dtFolioRAM);

            //---C9---

            p_wf_ot_m_ot = Session["p_wf_ot_m_ot"].ToString();
            cod_usr = Int32.Parse(arrDatosPoliza[1].Split('=')[1]);

            objCatalogos.solicitudSuscripcion(p_wf_ot_m_ot, cod_usr, "");

            return objDataSet;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR MetodosAjax.getSolicitud(): " + ex.Message);
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string getSolicitudFirma(string accion, String[] arrDatosPoliza, String[] arrDatosVar, String[] arrDatosCob, String[] arrDatosCont, String[] arrDatosSol, String[] arrDatosBenef, String[] arrDatosBanco, string p_token)
    {
        Emision objCotizacion = new Emision(accion);

        try
        {
            objCotizacion.token = p_token;
            String[] DatosBenef = new String[0];

            string XmlEmision = objCotizacion.getCotizacionFirma(arrDatosPoliza, arrDatosVar, arrDatosCob, arrDatosCont, arrDatosSol, DatosBenef, arrDatosBanco);
            Session["XmlEmisionFirma"] = XmlEmision;
            return XmlEmision;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR MetodosAjax.getSolicitud(): " + ex.Message);
        }
    }
    protected void GuardarBeneficiarios(string strCotizacion, String[] DATOS_BENEF)
    {
        ArrayList arrDATOS_BENEF = new ArrayList();
        Hashtable hash_REGISTRO;
        String[] arrVAL_AUX;
        String[] arrAUX;

        try
        {
            // Datos Beneficiario
            foreach (string BENEFICIARIO in DATOS_BENEF)
            {
                if (BENEFICIARIO != null)
                {
                    hash_REGISTRO = new Hashtable();
                    arrVAL_AUX = BENEFICIARIO.Split('|');
                    foreach (string DATO in arrVAL_AUX)
                    {
                        arrAUX = DATO.Split('=');
                        hash_REGISTRO.Add(arrAUX[0], arrAUX[1]);
                    }
                    arrDATOS_BENEF.Add(hash_REGISTRO);
                }
            }

            Emision objBenef = new Emision("C");
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                objBenef.setBenef(strCotizacion, arrDATOS_BENEF, conexion);
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    protected DataSet AgregarTablaPrimas(DataSet ds)
    {
        DataTable dtPrimas = new DataTable();
        dtPrimas.Columns.Add("TABLA_PRIMAS");

        DataRow dr = dtPrimas.NewRow();
        GestionPrimas TablaPrimas = new GestionPrimas(ds.Tables[4].Rows[0]["COTIZACION"].ToString(), ObtenerFormasPago());
        dr["TABLA_PRIMAS"] = TablaPrimas.HTMLTabla;
        dtPrimas.Rows.Add(dr);

        ds.Tables.Add(dtPrimas);

        return ds;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataRow getPrimas(string numPoliza)
    {
        DataRow outrow;
        MCommand cmd = new MCommand();

        using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
        {

            try
            {
                cmd.Connection = conexion;
                cmd.CommandText = "ev_k_reportes_edu.p_primas_cotizador";

                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, numPoliza);
                cmd.agregarINParametro("p_num_spto", OracleDbType.Int32, 0);
                cmd.agregarINParametro("p_num_apli", OracleDbType.Int32, 0);
                cmd.agregarINParametro("p_num_spto_apli", OracleDbType.Int32, 0);
                cmd.agregarOUTParametro("p_cadena", OracleDbType.Varchar2, 2000);

                outrow = cmd.ejecutarRegistroSP();

                return outrow;

            }
            catch (Exception ex)
            {
                throw new Exception("ERROR ev_k_reportes_edu_mmx.getPagos : " + ex.Message);
            }
        }
    }

    protected string ObtenerFormasPago()
    {
        string strFormasPago = "";
        if (Session["FormasDePago"] != null)
            strFormasPago = Session["FormasDePago"].ToString();
        else
            throw new Exception("No hay datos o ha expirado la sesión");

        return strFormasPago;
    }

    protected string ObtenerFolioRAMSolicitud(string strNoSoli)
    {
        FolioRAM objFolioRAM = new FolioRAM();
        string strFolioRAM = "";
        try
        {
            string strNoSolicitud = strNoSoli;
            string COD_DOCUMT = Session["COD_DOCUMT"].ToString();
            string NOM_TERCEROT = Session["NOM_TERCEROT"].ToString();
            string COD_ESTADOT = Session["COD_ESTADOT"].ToString();
            strFolioRAM = objFolioRAM.crearFolioRAMCotizacion(strNoSolicitud, COD_DOCUMT, NOM_TERCEROT, COD_ESTADOT);

            return strFolioRAM;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            strFolioRAM = "No Pudo Generarse El Folio RAM.";
            return strFolioRAM;
        }

    }

    protected string ObtenerFolioRAMPoliza(string strNoPoliza)
    {
        FolioRAM objFolioRAM = new FolioRAM();
        string strFolioRAM = "";
        try
        {
            string COD_DOCUMT = Session["COD_DOCUMT"].ToString();
            string NOM_TERCEROT = Session["NOM_TERCEROT"].ToString();
            string COD_ESTADOT = Session["COD_ESTADOT"].ToString();
            string codRamo = strNoPoliza.Substring(0, 3);
            strFolioRAM = objFolioRAM.crearFolioRAMPoliza(strNoPoliza, COD_DOCUMT, NOM_TERCEROT, COD_ESTADOT, codRamo);

            return strFolioRAM;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            strFolioRAM = "No Pudo Generarse El Folio RAM.";
            return strFolioRAM;
        }

    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)] //JDVI
    public string getEmision(string accion, String[] arrDatosPoliza, String[] arrDatosVar, String[] arrDatosCob, String[] arrDatosCont, String[] arrDatosSol, String[] arrDatosBenef, String[] arrDatosBanco, string p_token, string MSI)//MGM_MSI
    {
        Emision objEmision = new Emision(accion);
        if (MSI == "S")
        {
            HttpContext.Current.Session["BanderaMSI"] = true;//MGM_MSI 
        }

        try
        {
            objEmision.token = p_token;
            string strPoliza = objEmision.getEmision(arrDatosPoliza, arrDatosVar, arrDatosCob, arrDatosCont, arrDatosSol, arrDatosBenef, arrDatosBanco);


            DataTable dtControlesTecnicosPLD = null;
            StringBuilder strMensaje = new StringBuilder();
            string strControles = "";
            bool blBanderaControlPLD = false;

            dtControlesTecnicosPLD = obtenListaControlesTecnicos(1, strPoliza, 0, 0, 0);

            if (ConfigurationManager.AppSettings["BanCTPLD"] == "S" && dtControlesTecnicosPLD != null)
            {
                if (dtControlesTecnicosPLD.Rows.Count != 0)
                {
                    foreach (DataRow drControles in dtControlesTecnicosPLD.Rows)
                    {
                        if (drControles["COD_ERROR"].ToString() == "9002")
                        {
                            strMensaje.Append("9002,");
                        }
                        if (drControles["COD_ERROR"].ToString() == "9003")
                        {
                            strMensaje.Append("9003,");
                        }
                        if (drControles["COD_ERROR"].ToString() == "9004")
                        {
                            strMensaje.Append("9004,");
                        }
                        if (drControles["COD_ERROR"].ToString() == "9005")
                        {
                            strMensaje.Append("9005");
                        }
                    }

                    strControles = "|" + strMensaje.ToString().Substring(0, strMensaje.ToString().Length - 1);
                }
                else
                {
                    strControles = "|";
                }
            }
            else
            {
                strControles = "|";
            }


            try
            {
                Factura(arrDatosPoliza, strPoliza);
            }
            catch (Exception ex)
            {

            }

            strPoliza += "|" + ObtenerFolioRAMPoliza(strPoliza) + strControles + "|" + ConfigurationManager.AppSettings["rutaPantallaExpediente"];

            return strPoliza;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }


    // Función para obtener los controles técnicos de una póliza recien emitida
    private DataTable obtenListaControlesTecnicos(Int32 intCodCia, string strNumPoliza, Int32 intNumSpto, Int32 intNumApli, int intNumSptoApli)
    {
        DataSet dsControlesTecnicos;
        DataTable dtControlesTecnicos = null;
        DataRow drControlesTecnicos = null;
        MapfreMMX.oracle.MCommand cmd = new MapfreMMX.oracle.MCommand();

        try
        {
            using (OracleConnection conexion = MConnection.getConexion(WebUtils.getAppSetting("ConnectionTW")))
            {
                cmd.Connection = conexion;
                cmd.agregarRETURNParametro("result", OracleDbType.RefCursor, 5000);
                cmd.CommandText = "tron2000.em_k_control_tecnico_trn.f_errores_ct_poliza";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, intCodCia);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, strNumPoliza);
                cmd.agregarINParametro("p_num_spto", OracleDbType.Int32, intNumSpto);
                cmd.agregarINParametro("p_num_apli", OracleDbType.Int32, intNumApli);
                cmd.agregarINParametro("p_num_spto_apli", OracleDbType.Int32, intNumSptoApli);

                dsControlesTecnicos = cmd.ejecutarRefCursorSP();
                dtControlesTecnicos = dsControlesTecnicos.Tables[0];
            }
        }
        catch (Exception ex)
        {
            throw new Exception("Imposible recuperar lista de controles técnicos " + ex.Message.ToString());
        }

        return dtControlesTecnicos;
    }


    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string getXmlEmision(string accion, String[] arrDatosPoliza, String[] arrDatosVar, String[] arrDatosCob, String[] arrDatosCont, String[] arrDatosSol, String[] arrDatosBenef, String[] arrDatosBanco, string p_token, string MSI)
    {
        Emision objEmision = new Emision(accion);
        if (MSI == "S")
        {
            HttpContext.Current.Session["BanderaMSI"] = true;//MGM_MSI 
        }

        try
        {
            objEmision.token = p_token;
            string xmlEmision = objEmision.getXmlEmision(arrDatosPoliza, arrDatosVar, arrDatosCob, arrDatosCont, arrDatosSol, arrDatosBenef, arrDatosBanco);
            Session["xmlEmisionFirma"] = xmlEmision;
            return xmlEmision;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    //MGM_MSI
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void BorraMSI()
    {
        HttpContext.Current.Session.Remove("BanderaMSI");

    }
    //AEP BWMEILL. Millón Vida Fase 2. Método para almacenar la forma de pago seleccionada
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void OcultaPasarela(int formaPago)
    {
        if (formaPago == 1)
        {
            HttpContext.Current.Session.Remove("TipoPagoMV");
            Session.Add("TipoPagoMV", "TD");
        }
        if (formaPago == 2)
        {
            HttpContext.Current.Session.Remove("TipoPagoMV");
            Session.Add("TipoPagoMV", "DB");
        }
    }

    //MGM_MSI
    //Procedimiento para mostrar los bancos que tienen la promocion de MSI
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string ObtieneBancosMSI(Int32 ramo, Int16 TipoPago)
    {
        try
        {
            DataSet outDs = new DataSet();
            string ResMSI = "";

            using (OracleConnection conexion = MConnection.getConexion(WebUtils.getAppSetting("ConnectionTW")))
            {
                MCommand cmd = new MCommand();
                cmd.Connection = conexion;
                cmd.CommandText = "ea_k_admon_msi.p_obt_info_vig_msi";
                cmd.agregarINParametro("p_cod_sector", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, ramo);
                cmd.agregarINParametro("p_num_poliza_grupo", OracleDbType.Varchar2, WebUtils.getAppSetting("polizaGrupoSeGATW"));
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Int32, Convert.ToInt32(WebUtils.getAppSetting("contratoSeGATW")));
                cmd.agregarINParametro("p_mca_floti", OracleDbType.Varchar2, "N");
                cmd.agregarINParametro("p_mca_multianual", OracleDbType.Varchar2, "N");
                cmd.agregarINParametro("p_cod_fracc_pago", OracleDbType.Int16, TipoPago);
                cmd.agregarINParametro("p_tip_gestor", OracleDbType.Varchar2, "TA");
                cmd.agregarINParametro("p_cod_spto", OracleDbType.Int16, 0);
                cmd.agregarINParametro("p_sub_cod_spto", OracleDbType.Int16, 0);
                cmd.agregarINParametro("p_num_afiliacion", OracleDbType.Varchar2, "");
                cmd.agregarINParametro("p_fec_efec_spto", OracleDbType.Varchar2, DateTime.Now.ToString("ddMMyyyy"));
                cmd.agregarOUTParametro("p_regresa_info", OracleDbType.RefCursor, 0);
                cmd.agregarOUTParametro("p_txt_error", OracleDbType.Varchar2, 255);
                outDs = cmd.ejecutarRefCursorSP();

                if (outDs.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < outDs.Tables[0].Rows.Count; i++)
                    {
                        ResMSI += outDs.Tables[0].Rows[i]["NOM_ENTIDAD"].ToString() + ", ";
                    }

                }

                return ResMSI;
            }
        }
        catch (Exception ex)
        {
            MLogFile.getInstance().writeText("Aplicación:" + HttpContext.Current.Request.ApplicationPath + "," + "Error:", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public string sumarUnAnioAFecha(string strFecha)
    {
        DateTime dtFechaASumar;
        if (DateTime.TryParse(strFecha, out dtFechaASumar))
            strFecha = dtFechaASumar.AddYears(1).ToString("dd/MM/yyyy");

        return strFecha;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void setSession(string nombre, string valor)
    {
        if (Session[nombre] == null)
            Session.Add(nombre, valor);
        else Session[nombre] = valor;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void EnviarCorreo(int ramo, int modalidad, int contrato, string strAsunto, string strEmailTo)
    {
        string cuerpo = "";
        try
        {
            bool bdrEnvioCorreo = false;
            bool.TryParse(ConfigurationManager.AppSettings["EnviarCorreo"].ToString(), out bdrEnvioCorreo);
            if (bdrEnvioCorreo)
            {
                Catalogos objCatalogos = new Catalogos();
                try
                {
                    //--->C8<---
                    cuerpo = objCatalogos.obtieneMensajecorreo(ramo, modalidad, contrato);

                    StringBuilder strbody = new StringBuilder();
                    string strFecha = DateTime.Now.ToShortDateString();

                    strbody.Append("<html>");
                    strbody.Append("<body>");
                    strbody.Append("<div>" + cuerpo + "</div>");
                    strbody.Append("</body>");
                    strbody.Append("</html>");

                    EmailManagerClass Correo = new EmailManagerClass();
                    Correo.SendEmailWithAttachment(ConfigurationManager.AppSettings["SMTPEmailAccountToUseForSending"].ToString(), strEmailTo, strAsunto, strbody.ToString(), "");

                }
                catch (Exception ex)
                {
                    MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
                    throw new Exception("ERROR MetodosAjax.EnviarCorreo(): " + ex.Message);
                }
            }
        }
        catch { }
    }

    #region Beneficiarios

    /// <summary>
    /// Método que inserta los beneficiarios principales y adicionales por tipo de benefiario al datatable Beneficiarios
    /// </summary>
    /// <param name="cod_benef">Código del benefiario Principal al que pertenece el beneficiario secundario</param>
    /// <param name="nombre">nombre beneficiario del nuevo benefiario</param>
    /// <param name="paterno">apellido paterno del nuevo benefiario</param>
    /// <param name="materno">apellido materno del nuevo benefiario</param>
    /// <param name="porcentaje">porcentaje</param>
    /// <param name="cod_parent"></param>
    /// <param name="nom_parent"></param>
    /// <param name="tip_benef">tipo de beneficiario del nuevo beneficiario</param>
    /// <param name="existe"></param>
    /// <returns>Script que corresponde al grid del tipo de benefiario que se esta insertando</returns>
    //'21 Se agregan parámetros string fecnac, string domicilio
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string insertaBenef(double cod_benef, string nombre, string paterno, string materno, string porcentaje, string cod_parent, string nom_parent, int tip_benef, bool existe, string fecnac, string domicilio, string telefono, string mail) //'21 Se agregan parámetros string fecnac, string domicilio //MU-2017-052841
    {
        Beneficiario objBeneficiario = new Beneficiario();

        string keySession = "";
        string strTotal = "";
        int total = 10;
        try
        {
            objBeneficiario.Tip_Benef = tip_benef;
            objBeneficiario.Cod_Benef = cod_benef;

            if (tip_benef == 6)
            {
                strTotal = " principales";
                keySession = "Beneficiarios";
            }
            else
            {
                strTotal = " adicionales";
                keySession = "BenefAd" + objBeneficiario.Nivel1.ToString();
            }

            if (Session[keySession] == null)
                Session.Add(keySession, objBeneficiario.Beneficiarios);
            objBeneficiario.Beneficiarios = ((DataTable)Session[keySession]).Copy();
            //'C21 Se agregan parámetros string fecnac, string domicilio
            objBeneficiario.Insertar(nombre, paterno, materno, porcentaje, cod_parent, nom_parent, existe, fecnac, domicilio, telefono, mail);

            // valida numero de beneficiarios
            if (objBeneficiario.Beneficiarios.Rows.Count > total)
                throw new Exception("Solo puedes agregar " + total + " beneficiarios" + strTotal);

            // Se verifica que primero se capturen los beneficiarios principales

            objBeneficiario.calculaPcto();
            if (tip_benef != 6)
            {
                //                primeroPrincipal();
                //  if (objBeneficiario.Nivel1 == 0)
                if (Session["m_Nivel1"].ToString() == "0")
                    throw new Exception("Debes seleccionar un beneficiario principal");
            }
            Session[keySession] = objBeneficiario.Beneficiarios;

            objBeneficiario.Beneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();
            objBeneficiario.addTipBenef("S");
            Session["Beneficiarios"] = objBeneficiario.Beneficiarios;
            // <--- C5 --->
            switch (tip_benef)
            {
                case 13:
                    return objBeneficiario.Return_Script_Fallecimiento;

                case 15:
                    return objBeneficiario.Return_Script_Remanente;

                default:
                    return objBeneficiario.Return_Script;

            }
            // ------------
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }


    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string insertaBenef105(double cod_benef, string nombre, string paterno, string materno, string porcentaje, string cod_parent, string nom_parent, int tip_benef, bool existe, string fecnac, string domicilio, string asegurado) //'21 Se agregan parámetros string fecnac, string domicilio
    {
        Beneficiario objBeneficiario = new Beneficiario();

        string keySession = "";
        string strTotal = "";
        int total = 10;
        try
        {
            objBeneficiario.Tip_Benef = tip_benef;
            objBeneficiario.Cod_Benef = cod_benef;

            if (tip_benef == 6)
            {
                strTotal = " principales";
                keySession = "Beneficiarios";
            }
            else
            {
                strTotal = " adicionales";
                keySession = "BenefAd" + objBeneficiario.Nivel1.ToString();
            }

            if (Session[keySession] == null)
                Session.Add(keySession, objBeneficiario.Beneficiarios);
            objBeneficiario.Beneficiarios = ((DataTable)Session[keySession]).Copy();
            //'C21 Se agregan parámetros string fecnac, string domicilio
            objBeneficiario.Insertar105(nombre, paterno, materno, porcentaje, cod_parent, nom_parent, existe, fecnac, domicilio, asegurado);

            // valida numero de beneficiarios
            if (objBeneficiario.Beneficiarios.Rows.Count > total)
                throw new Exception("Solo puedes agregar " + total + " beneficiarios" + strTotal);

            // Se verifica que primero se capturen los beneficiarios principales

            objBeneficiario.calculaPcto();
            if (tip_benef != 6)
            {
                //                primeroPrincipal();
                //  if (objBeneficiario.Nivel1 == 0)
                if (Session["m_Nivel1"].ToString() == "0")
                    throw new Exception("Debes seleccionar un beneficiario principal");
            }
            Session[keySession] = objBeneficiario.Beneficiarios;

            //objBeneficiario.Beneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();
            //objBeneficiario.addTipBenef("S");
            //Session["Beneficiarios"] = objBeneficiario.Beneficiarios;
            // <--- C5 --->
            switch (tip_benef)
            {
                case 13:
                    return objBeneficiario.Return_Script;

                case 15:
                    return objBeneficiario.Return_Script_Remanente;

                case 12:
                    return objBeneficiario.Return_Script;

                default:
                    return objBeneficiario.Return_Script;

            }
            // ------------
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string eliminaBenef(double cod_benef, int tip_benef)
    {
        Beneficiario objBeneficiario = new Beneficiario();
        string keySession = "";
        try
        {
            objBeneficiario.Tip_Benef = tip_benef;
            objBeneficiario.Cod_Benef = cod_benef;
            int nivel1 = objBeneficiario.Nivel1;

            if (tip_benef == 6)
                keySession = "Beneficiarios";
            else keySession = "BenefAd" + objBeneficiario.Nivel1.ToString();

            if (Session[keySession] == null)
                throw new Exception("No hay datos de beneficiarios o ha expirado la sesión");
            objBeneficiario.Beneficiarios = ((DataTable)Session[keySession]).Copy();
            bool eliminado = objBeneficiario.Eliminar();

            if (objBeneficiario.Beneficiarios.Rows.Count == 0)
                Session.Remove(keySession);
            else Session[keySession] = objBeneficiario.Beneficiarios;

            if (tip_benef == 6)
            {
                if (eliminado)
                {
                    for (int i = nivel1; i <= 10; i++)
                    {
                        if (Session["BenefAd" + i] != null)
                        {
                            int j = i + 1;
                            if (Session["BenefAd" + j] != null)
                                Session["BenefAd" + i] = Session["BenefAd" + j];
                            else Session.Remove("BenefAd" + i);
                        }
                    }
                }
            }
            else
            {
                if (objBeneficiario.numeroAdd() == 0)
                {
                    objBeneficiario.Beneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();
                    objBeneficiario.addTipBenef("");
                    Session["Beneficiarios"] = objBeneficiario.Beneficiarios;
                }
            }

            if (Session["Beneficiarios"] != null)
                objBeneficiario.Beneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();

            return objBeneficiario.Return_Script;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataRow obtieneBenef(double cod_benef, int tip_benef)
    {
        Beneficiario objBeneficiario = new Beneficiario();
        string keySession = "";
        try
        {
            objBeneficiario.Cod_Benef = cod_benef;

            if (tip_benef == 6)
                keySession = "Beneficiarios";
            else keySession = "BenefAd" + objBeneficiario.Nivel1.ToString();

            if (Session[keySession] != null)
                objBeneficiario.Beneficiarios = ((DataTable)Session[keySession]).Copy();
            DataRow objDR = objBeneficiario.Modificar();

            if (objDR == null)
                throw new Exception("No hay datos de este beneficiario o ha expirado la sesión");

            return objDR;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    // <--- C2 --->
    /// <summary>
    /// Muestra los benefiarios por tipo.
    /// </summary>
    /// <param name="cod_benef">Código del benefiario Principal al que pertenece el beneficiario secundario</param>
    /// <param name="tip_benef">Tipo de beneficiario </param>
    /// <returns></returns>
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string muestraBenef(double cod_benef, int tip_benef)
    {
        int nivel = Convert.ToInt32(cod_benef);
        DataTable objDTP = new DataTable();
        DataTable objDTA = new DataTable();
        DataTable objDTATotal = new DataTable();
        // <--- C2 --->
        DataTable beneficiariosAdicionales = new DataTable();
        // ------------
        Beneficiario objBeneficiario = new Beneficiario();

        try
        {
            if (Session["Beneficiarios"] == null)
                Session.Add("Beneficiarios", objBeneficiario.Beneficiarios);
            if (Session["BenefAd" + nivel.ToString()] == null)
                Session.Add("BenefAd" + nivel.ToString(), objBeneficiario.Beneficiarios);

            objDTP = ((DataTable)Session["Beneficiarios"]).Copy();
            objDTA = ((DataTable)Session["BenefAd" + nivel.ToString()]).Copy();

            // <--- C2 --->
            if (Session["BenefAd" + nivel.ToString()] != null)
            {
                beneficiariosAdicionales = obtieneBeneficiariosAdicionales(tip_benef);
                objBeneficiario.Beneficiarios = beneficiariosAdicionales;
            }
            else
                objBeneficiario.Beneficiarios = objDTP;
            // ------------

            // <--- C5 --->
            if (tip_benef != 6)
            {
                primeroPrincipal();
            }

            switch (tip_benef)
            {
                case 13:
                    return objBeneficiario.Return_Script_Fallecimiento;

                case 15:
                    return objBeneficiario.Return_Script_Remanente;

                default:
                    return objBeneficiario.Return_Script;

            }
        }

        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR MetodosAjax.muestraBenef(): " + ex.Message);
        }
    }

    // <--- C3 --->
    /// <summary>
    /// Metodo para obtener los beneficiarios por los tipos: Fallecimiento o
    /// Remanente.
    /// </summary>
    /// <param name="tip_benef">Tipo de beneficiario</param>
    /// <returns></returns>
    public DataTable obtieneBeneficiariosAdicionales(int tip_benef)
    {
        DataTable tblBenefP = new DataTable();
        DataTable tblBenefA = new DataTable();
        DataTable tblBenefTotal = ((DataTable)Session["Beneficiarios"]).Clone();
        try
        {
            if (Session["Beneficiarios"] != null)
                tblBenefP = ((DataTable)Session["Beneficiarios"]).Copy();
            else throw new Exception("No hay datos o ha expirado la sesión");

            for (int i = 0; i < tblBenefP.Rows.Count; i++)
            {
                if (Session["BenefAd" + i] != null)
                {
                    tblBenefA = ((DataTable)Session["BenefAd" + i.ToString()]).Copy();
                    foreach (DataRow dr in tblBenefA.Rows)
                    {
                        if (dr["tip_benef"].ToString() == tip_benef.ToString())
                        {
                            tblBenefTotal.ImportRow(dr);
                        }
                    }
                }
            }


            return tblBenefTotal;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR MetodosAjax.obtieneBeneficiariosAdicionales(): " + ex.Message);
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public int totalBenef()
    {
        Beneficiario objBeneficiario = new Beneficiario();
        if (Session["Beneficiarios"] == null)
            Session.Add("Beneficiarios", objBeneficiario.Beneficiarios);
        objBeneficiario.Beneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();
        return objBeneficiario.Beneficiarios.Rows.Count;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable obtieneTablaBenef()
    {
        DataTable tblBenefP = new DataTable();
        DataTable tblBenefA = new DataTable();
        try
        {
            if (Session["Beneficiarios"] != null)
            {
                tblBenefP = ((DataTable)Session["Beneficiarios"]).Copy();
            }
            else
            {
                try
                {
                    tblBenefP = ((DataTable)Session["Beneficiarios2"]).Copy();
                }
                catch
                {
                    throw new Exception("No hay datos o ha expirado la sesión");
                }
            }

            for (int i = 0; i <= tblBenefP.Rows.Count; i++)
            {
                if (Session["BenefAd" + i] != null)
                {
                    tblBenefA = ((DataTable)Session["BenefAd" + i]).Copy();
                    tblBenefP.Merge(tblBenefA);
                }
            }

            tblBenefP.DefaultView.Sort = "nivel1, tip_benef, nivel2";
            return tblBenefP.DefaultView.ToTable();
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }
    // ---------

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable generaCodDocumBENEF()
    {
        int ramo;
        try
        {
            ramo = Convert.ToInt32(Session["RAMO"]);
        }
        catch
        {
            ramo = 0;
        }
        Beneficiario objBenefP = new Beneficiario();
        Beneficiario objBenefA = new Beneficiario();

        if (ramo == 105)
        {
            try
            {
                if (Session["Beneficiarios"] == null)
                    throw new Exception("No hay datos o ha expirado la sesión");


                objBenefP.Beneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();


                if (Session["BenefAd12"] != null)
                {
                    //objBenefP.Beneficiarios = ((DataTable)Session["BenefAd12"]).Copy();

                    DataTable BenefAd12 = ((DataTable)Session["BenefAd12"]).Copy();
                    DataTable Beneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();

                    foreach (DataRow dr in Beneficiarios.Rows)
                    {
                        BenefAd12.ImportRow(dr);
                    }
                    objBenefP.Beneficiarios = BenefAd12.Copy();
                    Session["Beneficiarios"] = objBenefP.Beneficiarios;
                }

                if (Session["BenefAd13"] != null)
                {
                    DataTable BenefAd13 = ((DataTable)Session["BenefAd13"]).Copy();
                    DataTable Beneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();

                    foreach (DataRow dr in Beneficiarios.Rows)
                    {
                        BenefAd13.ImportRow(dr);
                    }

                    objBenefP.Beneficiarios = BenefAd13.Copy();
                    Session["Beneficiarios"] = objBenefP.Beneficiarios;
                }


                if (Session["BenefAd15"] != null)
                {

                    DataTable BenefAd15 = ((DataTable)Session["BenefAd15"]).Copy();
                    DataTable Beneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();

                    foreach (DataRow dr in Beneficiarios.Rows)
                    {
                        BenefAd15.ImportRow(dr);
                    }

                    objBenefP.Beneficiarios = BenefAd15.Copy();
                    Session["Beneficiarios"] = objBenefP.Beneficiarios;


                }




                objBenefP.generaCodDocum();
                Session["Beneficiarios"] = objBenefP.Beneficiarios;

                return obtieneTablaBenef();
            }
            catch (Exception ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
                throw new Exception(ex.Message);
            }
        }
        else
        {
            try
            {
                if (Session["Beneficiarios"] == null)
                    throw new Exception("No hay datos o ha expirado la sesión");

                objBenefP.Beneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();
                objBenefP.generaCodDocum();
                Session["Beneficiarios"] = objBenefP.Beneficiarios;

                for (int i = 0; i <= objBenefP.Beneficiarios.Rows.Count; i++)
                {
                    if (Session["BenefAd" + i] != null)
                    {
                        objBenefA.Beneficiarios = ((DataTable)Session["BenefAd" + i]).Copy();
                        objBenefA.generaCodDocum();
                        Session["BenefAd" + i] = objBenefA.Beneficiarios;
                    }
                }

                return obtieneTablaBenef();
            }
            catch (Exception ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
                throw new Exception(ex.Message);
            }
        }
    }

    public bool existeTabla(string nivel)
    {
        try
        {
            string keySession = "BenefAd" + nivel;
            if (Session[keySession] != null)
            {
                DataTable objDT = ((DataTable)Session[keySession]).Copy();
                if (objDT.Rows.Count > 0)
                    return true;
                else return false;
            }
            else return false;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    public void primeroPrincipal()
    {
        int participacion = 0;
        Beneficiario objBeneficiario = new Beneficiario();

        if (Session["Beneficiarios"] == null)
            Session.Add("Beneficiarios", objBeneficiario.Beneficiarios);
        objBeneficiario.Beneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();

        foreach (DataRow row in objBeneficiario.Beneficiarios.Rows)
        {
            if (Convert.ToInt32(row["tip_benef"]) == 6)
                participacion += Convert.ToInt32(row["porcentaje"]);
        }

        if (participacion < 100)
            throw new Exception("Es necesario capturar primero todos los beneficiarios principales");
    }

    #endregion

    /// <summary>
    ///     Este método retorna el resultado obtenido en el procedimiento de 
    ///     validacion oii de la clase catalogos
    /// </summary>
    /// <param name="nombre">nombre</param>
    /// <param name="sexo">Genero</param>
    /// <param name="fecNac">Fecha de nacimiento</param>
    /// <returns>Datarow con los datos del usuario</returns>
    [Ajax.AjaxMethod()]
    public DataRow validaAntecedentesOII(string nombre, string sexo, string fecNac)
    {
        Catalogos objCatalogos = new Catalogos();
        try
        {
            return objCatalogos.validaAntecedentesOII(nombre, sexo, fecNac);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR MetodosAjax.validaAntecedentesOII(): " + ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public string getTelefono(int cod_usuario)
    {
        Util objUtil = new Util();
        try
        {
            return objUtil.getTelefono(cod_usuario);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR MetodosAjax.getTelefono(): " + ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public void AgregarFolioDocumentum(string archivos, string folio, string poliza, string strSistRAM)
    {
        string strPath = ConfigurationManager.AppSettings["pathlocal"].ToString();
        string[] archivo;
        string strMensaje = "";
        MapfreMMX.util.MLogFile.getInstance().writeText("Entra AgregarFolioDocumentum()");
        MapfreMMX.util.MLogFile.getInstance().writeText("Archivos: " + archivos);
        MapfreMMX.util.MLogFile.getInstance().writeText("folio: " + folio);
        MapfreMMX.util.MLogFile.getInstance().writeText("poliza: " + poliza);
        MapfreMMX.util.MLogFile.getInstance().writeText("strSistRAM: " + strSistRAM);
        archivo = archivos.Split(',');

        for (int i = 0; i < archivo.Length - 1; i++)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("SubirArchivoDos()");
            DatosVidaClass EnviarArcAFolioRAM = new DatosVidaClass();
            strMensaje = EnviarArcAFolioRAM.SubirArchivoDos(poliza, folio, strPath, archivo[i], strSistRAM);
        }
    }
    #region Beneficiarios Ascx

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string validarBeneficiarios()
    {
        try
        {
            string strMensaje = "";

            //Validación de haber Capturado Primero al Principal con 100%
            if (!validarCapturadoPrincipal())
            {
                strMensaje = "* Debe capturar a los beneficiarios principales al 100%.\n";
                return strMensaje;
            }

            //Se obtienen los diferentes tipos de Beneficiarios que no sean el Principal.
            Hashtable htTipoBene = new Hashtable();
            if (Session["sBeneficiarios"] != null)
            {
                DataTable objTemp = (DataTable)Session["sBeneficiarios"];
                foreach (DataRow dr in objTemp.Rows)
                {
                    if (dr["tip_benef"].ToString() != "6")
                        if (!htTipoBene.ContainsKey(dr["tip_benef"].ToString()))
                            htTipoBene.Add(dr["tip_benef"].ToString(), dr["tip_benef"].ToString());
                }
            }

            //Validación para que cada tipo de Beneficiario sume el 100%.
            foreach (string strTipoBene in htTipoBene.Keys)
            {
                float Porcentaje = getPorcPorTipoBene(strTipoBene);
                if (Porcentaje < 100)
                {
                    strMensaje += "* El porcentaje debe sumar 100% por Tipo de Beneficiario agregado.\n";
                    return strMensaje;
                }
            }
            return strMensaje;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    protected float getPorcPorTipoBene(string strTipoBene)
    {
        float PorcentajeTotal = 0F;
        if (Session["sBeneficiarios"] != null)
        {
            DataTable objTemp = (DataTable)Session["sBeneficiarios"];
            foreach (DataRow dr in objTemp.Rows)
            {
                if (dr["tip_benef"].ToString() == strTipoBene)
                    PorcentajeTotal = PorcentajeTotal + Convert.ToSingle(dr["Porcentaje"].ToString());
            }
        }
        return PorcentajeTotal;
    }

    protected bool validarCapturadoPrincipal()
    {
        bool ExistePrincipalAlCien = false;
        if (Session["sBeneficiarios"] != null)
        {
            DataTable objTemp = (DataTable)Session["sBeneficiarios"];
            float Porcentaje = 0F;
            foreach (DataRow dr in objTemp.Rows)
            {
                if (dr["tip_benef"].ToString() == "6")
                {
                    Porcentaje = Porcentaje + Convert.ToSingle(dr["Porcentaje"].ToString());
                }
            }
            if (Porcentaje == 100)
                ExistePrincipalAlCien = true;

        }
        return ExistePrincipalAlCien;
    }

    #endregion

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void setEstadoRAMCapturado()
    {
        string p_wf_ot_m_ot;
        Catalogos objCatalogos = new Catalogos();

        try
        {
            p_wf_ot_m_ot = Session["p_wf_ot_m_ot"].ToString();
            objCatalogos.setEstadoRAMCapturado(p_wf_ot_m_ot);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR MetodosAjax.setEstadoRAMCapturado(): " + ex.Message);
        }
    }


    [Ajax.AjaxMethod()]
    public void AgregarPolizaDocumentumARam(string noPoliza, string num_spto, string simpol, string folio, string poliza, string strSistRAM)//(string archivos, string folio, string poliza, string strSistRAM)
    {
        string sector = "1";
        string strMensaje = string.Empty;
        try
        {
            // Busca en documentum                    

            string idDocumento1 = null;
            string idDocumento2 = null;

            string endoso = num_spto;
            if (num_spto == null || num_spto == string.Empty)
                endoso = "0";

            // Con recibos
            if (WebUtils.getAppSetting("MCA_DOCUMENTUM") == "S")
            {
                // Con recibos
                idDocumento1 = UtilDocumentum.getObjIDPolizaEndosoNew(noPoliza, endoso, "true");
                // Sin recibos
                idDocumento2 = UtilDocumentum.getObjIDPolizaEndosoNew(noPoliza, endoso, "false");
            }

            string ramo = noPoliza.Substring(0, 3);
            // Si el idDocumento es nulo realiza procedimiento normal, en caso contrario, abre desde Documentum
            if (idDocumento1 != null)
            {
                UtilDocumentum.viewDocument(idDocumento1, Response);
                Session.Add("idDocumento1", idDocumento1);
                Session.Add("idDocumento2", idDocumento2);
            }
            else
            {
                //// IBM Marzo 2008                  
                clsRuta objRuta = new clsRuta();
                objRuta.tipoDocum = "P";
                objRuta.cotizacion = noPoliza;
                objRuta.permiteRecibo = "False";
                objRuta.poliza = noPoliza;
                objRuta.sector = sector;
                objRuta.solicitaRecibo = true;
                objRuta.getRuta(); // Ejecuta armado de ruta de archivo para subir a documentum 

                /* apl 19112014. Se sustituye método de generación de PDF de DisImpClass.dll por el consumo de WebService */

                //UtilFile objFile = new UtilFile();
                //objFile.creaPDF(noPoliza, endoso, sector, simpol, "", string.Empty, objRuta.ruta);
                //string strMensaje = "";
                //DatosVidaClass EnviarArcAFolioRAM = new DatosVidaClass();
                //strMensaje = EnviarArcAFolioRAM.SubirArchivoDos(poliza, folio, objRuta.directorio, objRuta.nombreArchivo, strSistRAM);

                wsImpresion.Service1 wsImpService = new wsImpresion.Service1();
                String sDocumentumId = "";
                //<--- C26--> ini
                if (ramo != "108")
                    sDocumentumId = wsImpService.getXmlDatosWeb(poliza, "0", "1");
                else
                {
                    try
                    {
                        CreaPDFHPExstream(poliza);
                        List<Condicion> condiciones = new List<Condicion>() {
                        new Condicion("cod_cia", "=", new Value("'1'"), "AND"),
                        new Condicion("num_poliza", "=", new Value("'" + poliza + "'"), "AND"),
                        new Condicion("num_spto", "=", new Value("'0'")) };
                        DataTable objObject_id;
                        objObject_id = ClienteREST.ExecuteQuery(new ObjectQuery("r_object_id", "mmx_poliza", condiciones), "query_output");
                        sDocumentumId = objObject_id.Rows[0].ItemArray[0].ToString();
                    }
                    catch (Exception ex)
                    {
                        MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
                        throw new Exception(ex.Message.ToString());
                    }
                }
                //<--- C26--> fin


                // Eliminar dependencia de MapfreMMX.docum
                //DmContent content = new DmContent();

                clsDocumentum objClsTramite = new clsDocumentum();
                //string dOCBASE = ConfigurationSettings.AppSettings["DocBase"];
                //DmPersistentSession session = DmPersistentSession.getInstance();

                if (ConfigurationManager.AppSettings["MCA_DOCUMENTUM"] == "S")
                {
                    Oracle.DataAccess.Client.OracleConnection conexion = null;
                    try
                    {
                        Hashtable Attribute = new Hashtable();
                        conexion = MConexion.getConexion("ConnectionSEGA");
                        Attribute.Add("num_folio", folio);
                        ClienteREST.SetAttributes(sDocumentumId, Attribute);

                        objClsTramite.setDBDocumento(int.Parse(strSistRAM), int.Parse(MapfreMMX.util.WebUtils.getAppSetting("usuarioSeGARAM")), objRuta.nombreArchivo, 1, sDocumentumId, conexion);
                        strMensaje = "Archivo adjuntado satisfactoriamente.";
                    }
                    catch (Exception ex)
                    {
                        MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
                        throw new Exception(ex.Message.ToString());
                    }
                    finally
                    {
                        conexion.Close();
                        conexion.Dispose();
                    }
                }
            }
        }
        catch (Exception ex)
        {
            strMensaje = ex.ToString();
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message.ToString());
        }
    }

    [Ajax.AjaxMethod()]
    public void AnexarDocRamC(string cuestionarioRespuestas, string HiddenNoSolPol, string strIDSistemaRAM)
    {
        try
        {
            string strPath = ConfigurationManager.AppSettings["pathlocal"].ToString();
            FileStream fs = new FileStream(strPath + "AnexoCuestionario.csv", FileMode.Create,
                                              FileAccess.ReadWrite);
            StreamWriter w;
            w = new StreamWriter(fs);
            w.Write(cuestionarioRespuestas);
            w.Close();

            //Enviar adjunto a RAM
            string strPoliza = HiddenNoSolPol;
            string strIdCotizacion = string.Empty;
            string strNombreArchivo = "AnexoCuestionario.csv";
            string strSistRAM = strIDSistemaRAM;

            //if (Session["numCotizacion"] != null)
            //{
            //    strIdCotizacion = Session["numCotizacion"].ToString();
            //}

            DatosVidaClass EnviarArcAFolioRAM = new DatosVidaClass();
            string strMensaje = EnviarArcAFolioRAM.SubirArchivo(strPoliza, strIdCotizacion, strPath, strNombreArchivo, strSistRAM);

        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
        }
    }

    [Ajax.AjaxMethod()]
    public void AgregarDictamenMedicoDocumentumARam(string folio, string noPoliza, string strSistRAM)
    {
        MapfreMMX.util.MLogFile.getInstance().writeText("Entra AgregarDictamenMedicoDocumentumARam()");
        controlesSolicitudes.CrearCotizacionAdobe objSega = new controlesSolicitudes.CrearCotizacionAdobe();
        //controlSolicitud obj = new controlSolicitud();
        int ramo = 0;

        //try
        //{
        //    ramo = Convert.ToInt32(Session["RAMO"]);
        //}
        //catch
        //{
        //    ramo = 0;
        //}

        //if (ramo == 105)
        //{
        //    try
        //    {
        //        UtilFile objFile = new UtilFile();
        //        COMLib.O2ComTP objAdobe = new COMLib.O2ComTP();
        //        string strXML = obj.xmlSolicitudesVida(noPoliza, "DictamenMedico", "", "", "", "", "", "", "");

        //        string nombreArchivo = "DictamenMedico_" + noPoliza + ".pdf";
        //        string strPath = ConfigurationManager.AppSettings["pathlocal"].ToString();
        //        string a = "text/xml";
        //        object ass3 = a;
        //        objAdobe.set_ContentType(ref ass3);
        //        object ass = strXML;
        //        objAdobe.set_Data(ref ass);
        //        object ass2 = "xprSolicitudesTw/DictamenMedico";
        //        objAdobe.set_XprName(ref ass2);
        //        objAdobe.Run();
        //        object objByte = true;
        //        objAdobe.set_ByteMode(ref objByte);
        //        File.WriteAllBytes(strPath + nombreArchivo, (byte[])objAdobe.get_Data());

        //        DatosVidaClass EnviarArcAFolioRAM = new DatosVidaClass();
        //        string strMensaje = EnviarArcAFolioRAM.SubirArchivo(noPoliza, folio, strPath, nombreArchivo, strSistRAM);

        //    }
        //    catch (Exception ex)
        //    {
        //        MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
        //    }
        //}
        //else
        //{
        try
        {
            UtilFile objFile = new UtilFile();
            COMLib.O2ComTP objAdobe = new COMLib.O2ComTP();
            string strXML = objSega.xmlSolicitudesVida(noPoliza, "DictamenMedico", "", "", "", "", "", "", "");

            string nombreArchivo = "DictamenMedico_" + noPoliza + ".pdf";
            string strPath = ConfigurationManager.AppSettings["pathlocal"].ToString();
            string a = "text/xml";
            object ass3 = a;
            objAdobe.set_ContentType(ref ass3);
            object ass = strXML;
            objAdobe.set_Data(ref ass);
            object ass2 = "xprSolicitudesTw/DictamenMedico";
            objAdobe.set_XprName(ref ass2);
            objAdobe.Run();
            object objByte = true;
            objAdobe.set_ByteMode(ref objByte);
            File.WriteAllBytes(strPath + nombreArchivo, (byte[])objAdobe.get_Data());

            MapfreMMX.util.MLogFile.getInstance().writeText("nombreArchivo" + nombreArchivo);
            MapfreMMX.util.MLogFile.getInstance().writeText("strPath" + strPath);
            MapfreMMX.util.MLogFile.getInstance().writeText("a" + a);
            MapfreMMX.util.MLogFile.getInstance().writeText("objAdobe: " + objAdobe.get_Data().ToString());

            DatosVidaClass EnviarArcAFolioRAM = new DatosVidaClass();
            string strMensaje = EnviarArcAFolioRAM.SubirArchivo(noPoliza, folio, strPath, nombreArchivo, strSistRAM);
            MapfreMMX.util.MLogFile.getInstance().writeText("Termina Dictament: ");
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
        }
        //}
    }
    [Ajax.AjaxMethod()]
    public void AgregarSolicitud(string noPoliza, string relacion, string folio, string strSistRAM)
    {
        DisImpClass.Impresion DSXML = new DisImpClass.Impresion();

        string sector = noPoliza.Substring(0, 1);
        string ramo = noPoliza.Substring(0, 3);
        string strXML = "", xprFile = "";
        string idDocumento = null;
        Oracle.DataAccess.Client.OracleConnection conexion = null;
        Oracle.DataAccess.Client.OracleConnection conexion1 = null;
        try
        {
            xprFile = WebUtils.getAppSetting("xprSol" + ramo);
            conexion = MConexion.getConexion("ConnectionTW");
            strXML = DSXML.SolicitudVidaIndividual(noPoliza, "0", relacion, conexion);
            clsRuta objRuta = new clsRuta();
            objRuta.tipoDocum = "S";
            objRuta.cotizacion = noPoliza;
            objRuta.permiteRecibo = "False";
            objRuta.poliza = noPoliza;
            objRuta.sector = sector;
            objRuta.solicitaRecibo = true;
            objRuta.getRuta();
            WebUtils.PDF_RUN(strXML, xprFile + "_Correo", "");

            // Subir a documentum el archivo
            // crea con Recibos
            Hashtable Attribute = new Hashtable();
            Attribute.Add("num_poliza", noPoliza);
            Attribute.Add("num_spto", "0");
            Attribute.Add("tipo_doc", "S");
            //Subimos al ftp
            /*
            subirArchivoFTP(objRuta.ruta,
                            ConfigurationManager.AppSettings["DocumentumServer"],
                            ConfigurationManager.AppSettings["DocumentumFTPUser"],
                            ConfigurationManager.AppSettings["DocumentumFTPPassword"],
                            ConfigurationManager.AppSettings["DocumentumRemotePath"]);
            */

            idDocumento = UtilDocumentum.ImportarDocumento(objRuta, Attribute);

            clsDocumentum objClsTramite = new clsDocumentum();

            conexion1 = MConexion.getConexion("ConnectionSEGA");
            objClsTramite.setDBDocumento(int.Parse(strSistRAM), int.Parse(MapfreMMX.util.WebUtils.getAppSetting("usuarioSeGARAM")), objRuta.nombreArchivo, 1, idDocumento, conexion1);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("MetodosAjax.AgregaSolicitud: ", ex);
        }
        finally
        {
            conexion.Close();
            conexion.Dispose();
            conexion1.Close();
            conexion1.Dispose();
        }
    }

    // APL -- Nueva forma de conexion FTPS
    /*
    public static void subirArchivoFTP(string file_path,
                                   string servidor,
                                   string usuario,
                                   string password,
                                   string remote_path)
    {
        Mapfre.Ftp.FTPClient objFTP = new Mapfre.Ftp.FTPClient(servidor, usuario, password);
        objFTP.RemotePath = remote_path;
        objFTP.Upload(file_path);
        objFTP.Close();
    }
    */

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public String cobranza(string strPoliza, string strBanco, string strTitular, string strAPTitular, string strAMTitular, string strAnioTarjeta, string strMesTarjeta, string strNumTarjeta, string strCodTarjeta, string strTipoTarjeta, string factor)
    {
        string pago = "0|No se genero la poliza.";
        string tipoOperacion = "";
        string ipHost = Dns.GetHostByName(Dns.GetHostName()).AddressList[1].ToString();
        try
        {
            Usuario objUsuario = (Usuario)Session["sUSUARIO"];

            if (!string.IsNullOrEmpty(strPoliza))
            {
                if (Convert.ToInt32(ConfigurationManager.AppSettings["ValidaTarjetaUAT"]) == 1)
                {
                    NPagoEnLinea pagoLinea = new NPagoEnLinea();
                    pagoLinea.NumPoliza = strPoliza;
                    pagoLinea.CodBanco = strBanco;
                    pagoLinea.NombreTitular = strTitular;
                    pagoLinea.APaternoTitular = strAPTitular;
                    pagoLinea.AMaternoTitular = strAMTitular;
                    pagoLinea.MesExpTarjeta = strMesTarjeta;
                    pagoLinea.AnioExpTarjeta = strAnioTarjeta;
                    pagoLinea.NumTarjeta = strNumTarjeta;
                    pagoLinea.CodTarjeta = strCodTarjeta;
                    pagoLinea.TipTarjeta = strTipoTarjeta;
                    //AEP Cambio MV
                    if (factor == "UL")
                    {
                        pagoLinea.factor = "0";
                    }
                    else
                    {
                        pagoLinea.factor = factor;
                    }
                    pagoLinea.pagoEnLinea();
                    var isGenera = ConfigurationManager.AppSettings["GeneraTrazabilidad"];
                    if (!pagoLinea.MsgRechazo.Equals(string.Empty))
                    {
                        pago = "0|" + pagoLinea.MsgRechazo;
                        tipoOperacion = "Pago en línea rechazado";
                        if (isGenera == "1")
                            Trazabilidad.OperacionesRelevantes.getInstance().RegistraOperacionRelevante(objUsuario.USUARIO, objUsuario.TIPO_USUARIO, tipoOperacion, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"), ipHost, strPoliza);
                    }
                    else
                    {
                        pago = "1|" + pagoLinea.NumAutorizacion;
                        tipoOperacion = "Pago en línea aprobado";
                        if (isGenera == "1")
                            Trazabilidad.OperacionesRelevantes.getInstance().RegistraOperacionRelevante(objUsuario.USUARIO, objUsuario.TIPO_USUARIO, tipoOperacion, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"), ipHost, strPoliza);
                        //Response.Write("<script language=javascript>alert('**********************\nPoliza Cobrada: " + pagoLinea.NumPoliza + " Autorizacion: " + pagoLinea.NumAutorizacion + "\n**********************\n');</script>");
                    }
                }
                else
                {
                    pago = "1|" + "0000000000";
                }
            }

            return pago;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("MetodosAjax.cobranza: ", ex);
            throw new Exception("ERROR MetodosAjax.cobranza: " + ex.Message);
        }
    }

    [Ajax.AjaxMethod()]
    public String ValidaTarjeta(string num_tarjeta, string cod_banco)
    {
        CDConsulta objConsulta = new CDConsulta();
        string mensaje = "";

        using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
        {
            try
            {
                objConsulta.validaTD(num_tarjeta, cod_banco, conexion);
            }
            catch (Exception ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("MetodosAjax.ValidaTarjeta: ", ex);
                mensaje = "El número de Tarjeta es inválido";
            }
        }
        return mensaje;
    }

    [Ajax.AjaxMethod()]
    public String fnCotizaSumasMV(string cod_cia, string cod_ramo, string duracion_hasta, String cod_modalidad, String cod_mon, String CadCob, String fecha_emision, String fecha_fin, String prima_a_calcular, String edad, String sexo)
    {

        MCommand cmd = new MCommand();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {

                cmd.Connection = conexion;
                cmd.CommandText = "tron2000.ev_k_productos_vida_mmx.p_obtiene_sum_aseg_za";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, Convert.ToInt16(cod_cia));
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, Convert.ToInt16(cod_ramo));
                cmd.agregarINParametro("p_duracion_poliza", OracleDbType.Varchar2, duracion_hasta);
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Varchar2, cod_modalidad);
                cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Convert.ToInt32(cod_mon));
                cmd.agregarINParametro("p_cod_cob", OracleDbType.Int32, Convert.ToInt32(CadCob));
                cmd.agregarINParametro("p_fec_efec_poliza", OracleDbType.Varchar2, fecha_emision);
                cmd.agregarINParametro("p_fec_vcto_poliza", OracleDbType.Varchar2, fecha_fin);
                cmd.agregarINParametro("p_prima", OracleDbType.Varchar2, prima_a_calcular);
                cmd.agregarINParametro("p_edad", OracleDbType.Int32, Convert.ToInt32(edad));
                cmd.agregarINParametro("p_sexo", OracleDbType.Varchar2, sexo);
                cmd.agregarOUTParametro("p_suma_aseg", OracleDbType.Varchar2, 2000);

                DataRow drCadenaSumas = cmd.ejecutarRegistroSP();

                return (String)(drCadenaSumas.Table.Rows[0].ItemArray[0]);
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR  tron2000.ev_k_productos_vida_mmx.p_obtiene_sum_aseg_za: " + ex.Message);
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string LeePoliza(string poliza)
    {
        try
        {
            MCommand cmd = new MCommand();
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "TRON2000.em_k_a2000030_trn.p_lee_Pol_Cobranza";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int16, 1);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, poliza);
                cmd.agregarINParametro("p_num_spto", OracleDbType.Int16, 0);
                cmd.agregarINParametro("p_num_apli", OracleDbType.Decimal, 0);
                cmd.agregarINParametro("p_num_spto_apli", OracleDbType.Int16, 0);
                cmd.ejecutarSP();
                return "";
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
    }

    #region Metodos Unit Linked

    //Unit Linked Poliza Grupo y Contrato INI
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable getPolizaGrupoUL(string ramo, Int32 agt)
    {
        DataSet dstpol = new DataSet();
        DataSet dstpolclon = new DataSet();
        DataTable dtpol = new DataTable();
        try
        {
            MCommand cmd = new MCommand();
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "ev_k_define_contratos.p_devuelve_poliza_gpo";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int16, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Varchar2, ramo);
                cmd.agregarINParametro("p_agente", OracleDbType.Int32, agt);
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);

                cmd.agregarOUTParametro("p_nom_poliza_gpo", OracleDbType.RefCursor, 0);

                dstpol = cmd.ejecutarRefCursorSP();

                //MU-2017-064392
                string contrato = System.Web.HttpContext.Current.Session["contrato"].ToString();
                dstpolclon = dstpol.Clone();

                if (contrato == "99999")
                {
                    foreach (DataRow row in dstpol.Tables[0].Rows)
                    {
                        if (row["NUM_POLIZA_GRUPO"].ToString() != WebUtils.getAppSetting("polgpo_ulbanco").ToString())
                        {
                            dstpolclon.Tables[0].ImportRow(row);
                        }
                    }
                }
                else
                {
                    foreach (DataRow row in dstpol.Tables[0].Rows)
                    {
                        if (row["NUM_POLIZA_GRUPO"].ToString() != WebUtils.getAppSetting("polgpo_ulcontigo").ToString())
                        {
                            dstpolclon.Tables[0].ImportRow(row);
                        }
                    }
                }
                if (ConfigurationManager.AppSettings["Campana_activa"].ToString() == "S")
                {
                    DataRow row2 = dstpolclon.Tables[0].NewRow();
                    row2["NUM_POLIZA_GRUPO"] = "1ULCONTIGO";
                    dstpolclon.Tables[0].Rows.Add(row2);
                }
                //MU-2017-064392
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return dtpol = dstpolclon.Tables[0];
    }

    //Unit Linked Poliza Grupo y Contrato INI
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable getPolizaGrupoUL2(string ramo, Int32 agt)
    {
        DataSet dstpol = new DataSet();
        DataSet dstpolclon = new DataSet();
        DataTable dtpol = new DataTable();
        try
        {
            MCommand cmd = new MCommand();
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "ev_k_define_contratos.p_devuelve_poliza_gpo";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int16, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Varchar2, ramo);
                cmd.agregarINParametro("p_agente", OracleDbType.Int32, agt);
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);

                cmd.agregarOUTParametro("p_nom_poliza_gpo", OracleDbType.RefCursor, 0);

                dstpol = cmd.ejecutarRefCursorSP();

                //MU-2017-064392
                string contrato = System.Web.HttpContext.Current.Session["contrato"].ToString();
                dstpolclon = dstpol.Clone();

                if (contrato == "99999")
                {
                    foreach (DataRow row in dstpol.Tables[0].Rows)
                    {
                        if (row["NUM_POLIZA_GRUPO"].ToString() != "1ULMIFEL")
                        {
                            if (row["NUM_POLIZA_GRUPO"].ToString() != WebUtils.getAppSetting("polgpo_ulbanco").ToString())
                            {
                                dstpolclon.Tables[0].ImportRow(row);
                            }
                        }
                    }
                }
                else
                {
                    foreach (DataRow row in dstpol.Tables[0].Rows)
                    {
                        if (row["NUM_POLIZA_GRUPO"].ToString() != "1ULMIFEL")
                        {
                            if (row["NUM_POLIZA_GRUPO"].ToString() != WebUtils.getAppSetting("polgpo_ulcontigo").ToString())
                            {
                                dstpolclon.Tables[0].ImportRow(row);
                            }
                        }
                    }
                }
                if (ConfigurationManager.AppSettings["Campana_activa"].ToString() == "S")
                {
                    DataRow row2 = dstpolclon.Tables[0].NewRow();
                    row2["NUM_POLIZA_GRUPO"] = "1ULCONTIGO";
                    dstpolclon.Tables[0].Rows.Add(row2);
                }
                //MU-2017-064392
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return dtpol = dstpolclon.Tables[0];
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable getContratosUL(Int32 ramo, string polgpo, Int32 agente)
    {
        DataSet dstcontra = new DataSet();
        DataTable dtcontra = new DataTable();
        DataSet contra = new DataSet();
        string[] arraycontrato = new string[2];
        try
        {
            MCommand cmd = new MCommand();
            //MU-2017-064392
            string contrato = System.Web.HttpContext.Current.Session["contrato"].ToString();

            if (contrato != "99999")
            {
                String cod_modalidad = System.Web.HttpContext.Current.Session["cod_modalidad"].ToString();

                using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
                {
                    cmd.Connection = conexion;
                    cmd.CommandText = "ev_k_define_contratos.p_devuelve_contratoUL";
                    cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, ramo);
                    cmd.agregarINParametro("p_num_poliza_grupo", OracleDbType.Varchar2, polgpo);
                    cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Varchar2, cod_modalidad);
                    cmd.agregarINParametro("p_agente", OracleDbType.Int32, agente);
                    cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);

                    cmd.agregarOUTParametro("p_nom_contrato", OracleDbType.RefCursor, 0);

                    dstcontra = cmd.ejecutarRefCursorSP();
                    //C22{
                    if (polgpo == "1ULCONTIGO")
                    {
                        DataRow row = dstcontra.Tables[0].NewRow();
                        row["NUM_CONTRATO"] = 11217;
                        row["NOM_CONTRATO"] = "CONTIGO2019";
                        dstcontra.Tables[0].Rows.Add(row);

                    }
                    //}C22

                    //C22{
                    if (polgpo == "1ULMIFEL")
                    {

                        DataRow row2 = dstcontra.Tables[0].NewRow();
                        row2["NUM_CONTRATO"] = 11228;
                        row2["NOM_CONTRATO"] = "CONTIGO11228";
                        dstcontra.Tables[0].Rows.Add(row2);
                        DataRow row3 = dstcontra.Tables[0].NewRow();
                        row3["NUM_CONTRATO"] = 11229;
                        row3["NOM_CONTRATO"] = "CONTIGO11229";
                        dstcontra.Tables[0].Rows.Add(row3);
                    }
                    //}C22
                    contra = dstcontra;
                }

            }
            else
            {
                using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
                {
                    cmd.Connection = conexion;
                    cmd.CommandText = "ev_k_define_contratos.p_devuelve_contrato";
                    cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                    cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, ramo);
                    cmd.agregarINParametro("p_num_poliza_grupo", OracleDbType.Varchar2, polgpo);
                    cmd.agregarINParametro("p_agente", OracleDbType.Int32, agente);
                    cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);

                    cmd.agregarOUTParametro("p_nom_contrato", OracleDbType.RefCursor, 0);

                    dstcontra = cmd.ejecutarRefCursorSP();
                }

                contra = dstcontra;
            }
            //MU-2017-064392
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return contra.Tables[0];
    }

    //Unit Linked Poliza Grupo y Contrato FIN

    //Unit Linked Monedas INI
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable getMonedasUL(Int32 cia, Int32 ramo, string contrato)
    {
        DataSet monedas = new DataSet();

        try
        {
            MCommand cmd = new MCommand();
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "ev_k_define_contratos.p_devuelve_moneda";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, ramo);
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Varchar2, contrato);

                cmd.agregarOUTParametro("p_moneda", OracleDbType.RefCursor, 0);

                monedas = cmd.ejecutarRefCursorSP();
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return monedas.Tables[0];
    }
    //Unit Linked Monedas FIN

    //Unit Linked Perfiles INI
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable getPerfilesUL(Int32 cia, Int32 ramo, string parametros)
    {
        DataSet objds = new DataSet();
        DataTable objdt = new DataTable();

        MCommand cmd = new MCommand();
        string tabla = "TA899039";
        Int32 version = 2;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "EM_K_GEN_WS.GETLOV";

                cmd.agregarRETURNParametro("results", OracleDbType.RefCursor, 0);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, cia);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, ramo);
                cmd.agregarINParametro("p_cod_campo", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_nom_tabla", OracleDbType.Varchar2, tabla);
                cmd.agregarINParametro("p_cod_version", OracleDbType.Int32, version);
                cmd.agregarINParametro("p_pramaetros", OracleDbType.Varchar2, parametros);

                objds = cmd.ejecutarRefCursorSP();

                objdt = objds.Tables[0];
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return objdt;
    }
    //Unit Linked Perfiles FIN

    //Unit Linked Periodicidad INI
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable getPeriodicidadP(Int32 cia, Int32 ramo, string parametros)
    {
        DataSet objds = new DataSet();
        DataTable objdt = new DataTable();

        MCommand cmd = new MCommand();
        string tabla = "A1001402";
        Int32 version = 10;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "EM_K_GEN_WS.GETLOV";

                cmd.agregarRETURNParametro("results", OracleDbType.RefCursor, 0);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, cia);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, ramo);
                cmd.agregarINParametro("p_cod_campo", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_nom_tabla", OracleDbType.Varchar2, tabla);
                cmd.agregarINParametro("p_cod_version", OracleDbType.Int32, version);
                cmd.agregarINParametro("p_pramaetros", OracleDbType.Varchar2, parametros);

                objds = cmd.ejecutarRefCursorSP();

                objdt = objds.Tables[0];
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return objdt;
    }
    //Unit Linked Periodicidad FIN

    //Unit Linked Duracion INI
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable getduracioUL(string modalidad, string ramo)
    {

        DataTable dura = new DataTable("Duraciones");
        string contrato = Session["contrato"].ToString();
        string duracion = "";
        string[] arrduracion = new string[2];
        try
        {
            DataSet objds = new DataSet();
            MCommand cmd = new MCommand();
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = ConfigurationManager.AppSettings["EsquemaVida"].ToString() + ".p_recupera_config_web";
                cmd.agregarINParametro("p_cod_aplicacion", OracleDbType.Varchar2, "ZAEMISIONGENERAL");
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, Convert.ToInt32(ramo));
                cmd.agregarINParametro("p_num_poliza_grupo", OracleDbType.Varchar2, "ZTODAS");
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Int32, Convert.ToInt32(contrato));
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Int32, Convert.ToInt32(modalidad));
                cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, 99);
                cmd.agregarINParametro("p_cod_campo", OracleDbType.Varchar2, "VAL_DURACION");
                cmd.agregarOUTParametro("p_val_campo", OracleDbType.Varchar2, 80);

                objds = cmd.ejecutarRefCursorSP();
                duracion = objds.Tables[0].Rows[0]["p_val_campo"].ToString();
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error MetodosAjax.getduracionUL(): " + ex);
        }
        if (contrato == "11228")
        {
            duracion = "23,75";

        }

        if (contrato == "11229")
        {
            duracion = "23,85";

        }

        arrduracion = duracion.Split(',');

        DataColumn columna1 = dura.Columns.Add("NOM_EA", typeof(string));
        DataColumn columna2 = dura.Columns.Add("VALOR_EA", typeof(string));

        if (arrduracion.Length > 1)
        {
            for (int i = Convert.ToInt32(arrduracion[0]); i <= Convert.ToInt32(arrduracion[1]); i++)
            {
                dura.Rows.Add("EA " + i, i);
            }
        }
        else
        {
            dura.Rows.Add("EA " + arrduracion[0], arrduracion[0]);
        }

        return dura;
    }
    //Unit Linked Duracion FIN

    //Unit Linked Dias Pago INI
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable diaspago()
    {
        CDListaValor objListaValor = new CDListaValor();
        DataTable tabladias = new DataTable("diaspago");
        try
        {
            string dias = "";
            string[] arrdias = new string[2];

            dias = WebUtils.getAppSetting("diaspago");

            arrdias = dias.Split(',');

            DataColumn columna1 = tabladias.Columns.Add("DIA", typeof(string));
            DataColumn columna2 = tabladias.Columns.Add("VALOR_DIA", typeof(string));

            if (arrdias.Length > 1)
            {
                for (int i = Convert.ToInt32(arrdias[0]); i <= Convert.ToInt32(arrdias[1]); i++)
                {
                    tabladias.Rows.Add("DIA", i);
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return tabladias;
    }
    //Unit Linked Dias Pago FIN

    //Unit Linked Coberturas INI
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string getDatosCobUL(Int32 cia, Int32 ramo, string modalidad, Int32 moneda, Int32 edad, string parametros)
    {
        DataSet objds = new DataSet();
        DataTable objdt = new DataTable();
        DataTable objdtpct = new DataTable();
        MetodosAjax metodos = new MetodosAjax();

        MCommand cmd = new MCommand();
        string tabla = "A1002150";
        Int32 version = 15;
        string contrato = (Session["contrato"].ToString());

        try
        {
            StringBuilder strHTMLTabla = new StringBuilder();
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "EM_K_GEN_WS.GETLOV";

                cmd.agregarRETURNParametro("results", OracleDbType.RefCursor, 0);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, cia);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, ramo);
                cmd.agregarINParametro("p_cod_campo", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_nom_tabla", OracleDbType.Varchar2, tabla);
                cmd.agregarINParametro("p_cod_version", OracleDbType.Int32, version);
                cmd.agregarINParametro("p_pramaetros", OracleDbType.Varchar2, parametros);

                objds = cmd.ejecutarRefCursorSP();

                objdt = objds.Tables[0];
            }

            objdtpct = metodos.getpctcobsUL(cia, ramo, modalidad);
            string pctBasica = objdtpct.Rows[0].ItemArray[0].ToString();
            string pctMA = objdtpct.Rows[0].ItemArray[1].ToString();

            DataView vistaTabla = new DataView(objdt);
            DataTable cobertura;
            DataRow row = null;
            DataTable coberturasOrganizadas;
            coberturasOrganizadas = objdt.Clone();

            string[] consultas = new string[] {
                "NOM_COB = 'BASICA'",
                "NOM_COB = 'BIT' OR NOM_COB = 'BIT-A'",
                "NOM_COB = 'BIPA'",
                "NOM_COB = 'EG' OR NOM_COB = 'ENFERMEDADES GRAVES'",
                "NOM_COB = 'MA' OR NOM_COB = 'MUERTE ACCIDENTAL'",
                "NOM_COB = 'PO' OR NOM_COB = 'PERDIDAS ORGANICAS'",
                "NOM_COB = 'MAC' OR NOM_COB = 'MUERTE ACCIDENTAL COLECTIVA'",
                "NOM_COB = 'POC'",
                "NOM_COB = 'MAPO'",
                "NOM_COB = 'MAPOC'",
                "NOM_COB = 'PASI'",
                "NOM_COB = 'SERVICIOS FUNERARIOS'",
            };

            foreach (var item in consultas)
            {
                vistaTabla.RowFilter = item;

                cobertura = vistaTabla.ToTable();

                if (!(cobertura.Rows.Count == 0))
                {
                    row = cobertura.Rows[0];
                    coberturasOrganizadas.ImportRow(row);
                    vistaTabla.Delete(0);
                }
            }

            vistaTabla.RowFilter = "";
            coberturasOrganizadas.Merge(vistaTabla.ToTable());
            objdt = coberturasOrganizadas;
            string cobbasica = "";


            if (objdt.Rows.Count > 0)
            {
                strHTMLTabla.Append("<table id='Coberturas' class='table table-bordered tab-border-red justify-content-center' style='width: 100%; display:table-row;'>");
                strHTMLTabla.Append("<tr class='table-danger'>");
                //C22{
                if (modalidad != "11204")
                    strHTMLTabla.Append("<td></td><td>Cobertura</td><td>Porcentaje</td>");
                else
                    strHTMLTabla.Append("<td></td><td>Cobertura</td><td>Suma Asegurada</td><td>Prima</td>");
                //}C22
                strHTMLTabla.Append("</tr>");
                int ContAux = 1;

                foreach (DataRow dr in objdt.Rows)
                {
                    if (dr["COD_AGRUP_COB_2"].ToString() != "")
                    {
                        if (modalidad == "11201" && (contrato == "11203" || contrato == "11207" || contrato == "11212" || contrato == "11213"))
                        {
                            if (dr[1].ToString() == WebUtils.getAppSetting("coberturaD"))
                            {
                                if (dr[2].ToString() != "" || dr[2] != null)
                                {
                                    strHTMLTabla.Append("<tr>");
                                    strHTMLTabla.Append("<td align=\"center\" ><input ");
                                    strHTMLTabla.Append("disabled checked='checked' ");
                                    //Celda con radiobutton
                                    strHTMLTabla.Append("name=chkCobertura id=chk" + ContAux.ToString() + " type=checkbox value=" + dr[1].ToString() + "></td>");
                                    //Celda con los nombres de las coberturas
                                    cobbasica = dr[0].ToString();
                                    cobbasica = cobbasica.ToString().Replace(cobbasica, "MUERTE ACCIDENTAL");
                                    strHTMLTabla.Append("<td> <input disabled class=\"EtiquetaGeneralIzquierda\" size=25 value=\"" + cobbasica.ToString() + "\"></td>");
                                    //Celda del campo de Porcentaje
                                    if (dr[1].ToString() == "1000")
                                    {
                                        strHTMLTabla.Append("<td align=\"center\"><input disabled class=\"EtiquetaGeneralIzquierda\" size=5 id=txtPct" + dr[1].ToString() + " value=" + pctBasica.ToString() + "></td>");
                                    }
                                    else
                                    {
                                        strHTMLTabla.Append("<td align=\"center\"><input disabled class=\"EtiquetaGeneralIzquierda\" size=5 id=txtPct" + dr[1].ToString() + " value=" + pctMA.ToString() + "></td>");
                                    }
                                }
                            }
                        }
                        //C22{
                        if (modalidad == "11204")
                        {
                            if (dr[2].ToString() != "" || dr[2] != null)
                            {
                                strHTMLTabla.Append("<tr>");
                                strHTMLTabla.Append("<td align=\"center\" ><input ");
                                if (dr["MCA_OBLIGATORIO"].ToString() == "S")
                                    strHTMLTabla.Append("disabled checked='checked' ");
                                strHTMLTabla.Append("name=chkCobertura id=chk" + ContAux.ToString() + " type=checkbox value=" + dr[1].ToString() + "></td>");
                                //Nombre
                                strHTMLTabla.Append("<td> <input class=\"EtiquetaGeneralIzquierda\" size=33 value=\"" + dr[0].ToString() + "\"></td>");

                                strHTMLTabla.Append("<td align=\"center\"><input  class=\"EtiquetaGeneralIzquierda\" onkeypress='return KeyNumber(this, event);' size=5 id=txtSumAseg" + dr[1].ToString() + " value='' ></td>");
                                strHTMLTabla.Append("<td align=\"center\"><input disabled  class=\"EtiquetaGeneralIzquierda\" size=5 id=txtPrim" + dr[1].ToString() + " value='' ></td>");
                            }
                        }
                        //}C22
                        else
                        {
                            if (dr[2].ToString() != "" || dr[2] != null)
                            {
                                strHTMLTabla.Append("<tr>");
                                strHTMLTabla.Append("<td align=\"center\" ><input disabled checked='checked' ");
                                //Celda con radiobutton
                                strHTMLTabla.Append("name=chkCobertura id=chk" + ContAux.ToString() + " type=checkbox value=" + dr[1].ToString() + "></td>");
                                //Celda con los nombres de las coberturas
                                strHTMLTabla.Append("<td> <input disabled class=\"EtiquetaGeneralIzquierda\" size=33 value=\"" + dr[0].ToString() + "\"></td>");
                                //Celda del campo de Porcentaje
                                if (dr[1].ToString() == "1000")
                                {
                                    strHTMLTabla.Append("<td align=\"center\"><input disabled class=\"EtiquetaGeneralIzquierda\" size=5 id=txtPct" + dr[1].ToString() + " value=" + pctBasica.ToString() + "></td>");
                                }
                                else
                                {
                                    strHTMLTabla.Append("<td align=\"center\"><input disabled class=\"EtiquetaGeneralIzquierda\" size=5 id=txtPct" + dr[1].ToString() + " value=" + pctMA.ToString() + "></td>");
                                }
                            }
                        }
                    }
                    ContAux++;
                }
                strHTMLTabla.Append("</table>");
            }
            else
            {
                if (moneda != 0 && modalidad != "-1")
                {
                    strHTMLTabla.Append(" ");
                }
            }
            return strHTMLTabla.ToString();
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
    }
    //Unit Linked Coberturas FIN

    //Unit Linked Porcentaje de Coberturas INI
    public DataTable getpctcobsUL(Int32 cia, Int32 ramo, string modalidad)
    {
        DataSet objds = new DataSet();
        DataTable objdt = new DataTable();

        MCommand cmd = new MCommand();
        string tabla = "TA899040";
        Int32 version = 1;

        //string contra = System.Web.HttpContext.Current.Session["contrato"].ToString();
        string contra = (Session["contrato"].ToString());
        string fecha = DateTime.Now.ToString("dd/MM/yyyy").Substring(0, 10); //01012001
        fecha = fecha.Replace("/", "");
        string mes = fecha.Substring(2, 2);
        string anio = fecha.Substring(6, 2);

        var parametros = "[cod_cia = " + cia + "][cod_ramo = " + ramo + "][dvcod_modalidad = " + modalidad + "][num_contrato = " + contra + "][ano_poliza = " + anio + "][mes_poliza = " + mes + "][fec_efec_poliza = '" + fecha + "'" + "]";

        try
        {
            StringBuilder strHTMLTabla = new StringBuilder();
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "EM_K_GEN_WS.GETLOV";

                cmd.agregarRETURNParametro("results", OracleDbType.RefCursor, 0);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, cia);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, ramo);
                cmd.agregarINParametro("p_cod_campo", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_nom_tabla", OracleDbType.Varchar2, tabla);
                cmd.agregarINParametro("p_cod_version", OracleDbType.Int32, version);
                cmd.agregarINParametro("p_pramaetros", OracleDbType.Varchar2, parametros);

                objds = cmd.ejecutarRefCursorSP();

                objdt = objds.Tables[0];
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return objdt;
    }
    //Unit Linked Porcentaje de Coberturas FIN

    //Unit Linked Tabla Fondos INI
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string getfondosUL(Int32 cia, Int32 ramo, string parametros, string moneda)
    {
        DataSet objds = new DataSet();
        DataTable objdt = new DataTable();
        DataTable objdtfinal = new DataTable();

        MCommand cmd = new MCommand();
        string tabla = "TA899039";
        Int32 version = 3;
        string contrato = Session["contrato"].ToString();

        string expression;
        DataRow[] foundrows;
        int aux = 0;
        int contadorNegativo = 0;
        string perfilordenado;

        try
        {
            StringBuilder strHTMLTabla = new StringBuilder();
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "EM_K_GEN_WS.GETLOV";

                cmd.agregarRETURNParametro("results", OracleDbType.RefCursor, 0);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, cia);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, ramo);
                cmd.agregarINParametro("p_cod_campo", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_nom_tabla", OracleDbType.Varchar2, tabla);
                cmd.agregarINParametro("p_cod_version", OracleDbType.Int32, version);
                cmd.agregarINParametro("p_pramaetros", OracleDbType.Varchar2, parametros);

                objds = cmd.ejecutarRefCursorSP();

                objdt = objds.Tables[0];
            }

            Int32 conta = 1;
            string numfondos = objdt.Rows.Count.ToString();

            if (objdt.Rows.Count > 0)
            {
                strHTMLTabla.Append("<table id = 'Fondos' class='table table-bordered tab-border-red' style='width: 100%;' >");
                strHTMLTabla.Append("<tr class='table-danger'>");
                if (contrato == "99999" || contrato == "19999")     //Unit Linked Contigo
                {
                    strHTMLTabla.Append("<td align=center> Perfil del Cliente </td><td align=center> Tipo Inversión </td><td align=center> Porcentaje de distribución </td><td align=center> Distribución Inicial </td></tr>");
                }
                else            //Unit Linked Bancos
                {
                    strHTMLTabla.Append("<td align=center> Tipo Inversión </td><td align=center> Porcentaje de distribución </td><td align=center> Distribución Inicial </td></tr>");
                }
            }

            int totalfondos = objdt.Rows.Count;

            objdtfinal = objdt.Clone();
            objdtfinal.Columns.Add("PERFIL_INV");

            if (contrato == "99999" || contrato == "19999")     //Unit Linked Contigo
            {
                if (moneda == "1")
                {
                    contadorNegativo = 0;
                    string[] ordenfondo_pesos;
                    ordenfondo_pesos = WebUtils.getAppSetting("ordenFondos_pesos").Split('|');
                    string[] ordenPerfilfondo_pesos;
                    ordenPerfilfondo_pesos = WebUtils.getAppSetting("ordenPerfilFondo_pesos").Split('|');

                    //foreach (DataRow drfondo in objdt.Rows)                                 //Se agregan los fondos segun la llave del config
                    for (int i = 0; i < ordenfondo_pesos.Length; i++)                                 //Se agregan los fondos segun la llave del config
                    {
                        //if (drfondo != null)
                        //{
                        expression = ordenfondo_pesos[aux];
                        foundrows = objdt.Select("NOM_FUNDO LIKE '%" + expression + "%' ");
                        perfilordenado = ordenPerfilfondo_pesos[aux];
                        if (foundrows != null && foundrows.Count() != 0)
                        {
                            objdtfinal.ImportRow(foundrows[0]);
                            objdtfinal.Rows[aux - contadorNegativo]["PERFIL_INV"] = perfilordenado;        //Agrega el perfil segun la llave del config
                            aux = aux + 1;
                        }
                        else
                        {
                            aux = aux + 1;
                            contadorNegativo = contadorNegativo + 1;
                        }
                        //}
                    }
                    foreach (DataRow dt in objdtfinal.Rows)
                    {
                        if (dt != null)
                        {
                            strHTMLTabla.Append("<tr>");
                            strHTMLTabla.Append("<td align=center><input ");
                            //Celda con Nombre del Perfil
                            strHTMLTabla.Append("disabled size=15 class=\"EtiquetaGeneralDescripcion\" value=" + dt[2].ToString() + " id=perfil_" + dt[2].ToString() + "></td>");
                            //Celda con Nombre del fondo
                            strHTMLTabla.Append("<td align=center><input disabled size=15 class=\"EtiquetaGeneralDescripcion\" value=" + dt[0].ToString() + " id=fondo_" + dt[1].ToString() + "></td>");
                            //Celda Porcentaje
                            strHTMLTabla.Append("<td align=center><input value=0 class=\"EtiquetaGeneralDescripcion\" size=2 maxlength=3 id=txtpctfondo_" + conta.ToString() + " onkeypress='return KeyNumber(this, event);'onchange='validapctfondos();'> % </td>");
                            //Celda Distribucion
                            strHTMLTabla.Append("<td align=center><input disabled class=\"EtiquetaGeneralDescripcion\" size=12 id=txtdistini_" + dt[1].ToString() + "></td>");
                            strHTMLTabla.Append("<td style=display:none><input id= idfondo_" + conta.ToString() + " value=" + dt[1].ToString() + "></td>");
                            strHTMLTabla.Append("</tr>");
                            conta = conta + 1;
                        }
                        else
                        {
                            strHTMLTabla.Append(" ");
                        }
                    }
                    strHTMLTabla.Append("<tr style=display:none><td><input id= numfondos value =" + numfondos + "></td>");
                    strHTMLTabla.Append("</tr>");
                    strHTMLTabla.Append("</table>");
                    return strHTMLTabla.ToString();
                }
                else    //Moneda dolares
                {
                    string[] ordenfondo_dolares;
                    ordenfondo_dolares = WebUtils.getAppSetting("ordenFondos_dolares").Split('|');
                    string[] ordenPerfilfondo_dolares;
                    ordenPerfilfondo_dolares = WebUtils.getAppSetting("ordenPerfilFondo_dolares").Split('|');
                    contadorNegativo = 0;

                    //foreach (DataRow drfondo in objdt.Rows)     //Se agregan los fondos segun la llave del config
                    for (int i = 0; i < ordenfondo_dolares.Length; i++)
                    {
                        //if (drfondo != null)
                        //{
                        expression = ordenfondo_dolares[aux];
                        foundrows = objdt.Select("NOM_FUNDO LIKE '%" + expression + "%' ");
                        perfilordenado = ordenPerfilfondo_dolares[aux];
                        if (foundrows != null)
                        {
                            objdtfinal.ImportRow(foundrows[0]);
                            objdtfinal.Rows[aux - contadorNegativo]["PERFIL_INV"] = perfilordenado;        //Agrega el perfil segun la llave del config
                            aux = aux + 1;
                        }
                        else
                        {
                            aux = aux + 1;
                            contadorNegativo = contadorNegativo + 1;
                        }
                        //}
                    }
                    foreach (DataRow dt in objdtfinal.Rows)
                    {
                        if (dt != null)
                        {
                            strHTMLTabla.Append("<tr>");
                            strHTMLTabla.Append("<td align=center><input ");
                            //Celda con Nombre del fondo
                            strHTMLTabla.Append("disabled size=15 class=\"EtiquetaGeneralDescripcion\" value=" + dt[2].ToString() + " id=perfil_" + dt[2].ToString() + "></td>");
                            //Celda con Nombre del fondo
                            strHTMLTabla.Append("<td align=center><input disabled size=15 class=\"EtiquetaGeneralDescripcion\" value=" + dt[0].ToString() + " id=fondo_" + dt[1].ToString() + "></td>");
                            //Celda Porcentaje
                            strHTMLTabla.Append("<td align=center><input value=0 class=\"EtiquetaGeneralDescripcion\" size=2 maxlength=3 id=txtpctfondo_" + conta.ToString() + " onkeypress='return KeyNumber(this, event);'onchange='validapctfondos();'> % </td>");
                            //Celda Distribucion
                            strHTMLTabla.Append("<td align=center><input disabled class=\"EtiquetaGeneralDescripcion\" size=12 id=txtdistini_" + dt[1].ToString() + "></td>");
                            strHTMLTabla.Append("<td style=display:none><input id= idfondo_" + conta.ToString() + " value=" + dt[1].ToString() + "></td>");
                            strHTMLTabla.Append("</tr>");
                            conta = conta + 1;
                        }
                        else
                        {
                            strHTMLTabla.Append(" ");
                        }
                    }
                    strHTMLTabla.Append("<tr style=display:none><td><input id= numfondos value =" + numfondos + "></td>");
                    strHTMLTabla.Append("</tr>");
                    strHTMLTabla.Append("</table>");
                    return strHTMLTabla.ToString();
                }
            }
            else            //Unit Linked Bancos
            {
                foreach (DataRow dt in objdt.Rows)
                {
                    if (dt != null)
                    {
                        strHTMLTabla.Append("<tr>");
                        strHTMLTabla.Append("<td align=center><input ");
                        //Celda con Nombre del fondo
                        strHTMLTabla.Append("disabled size=15 class=\"EtiquetaGeneralDescripcion\" value=" + dt[0].ToString() + " id=fondo_" + dt[1].ToString() + "></td>");
                        //Celda Porcentaje
                        strHTMLTabla.Append("<td align=center><input value=0 class=\"EtiquetaGeneralDescripcion\" size=2 maxlength=3 id=txtpctfondo_" + conta.ToString() + " onkeypress='return KeyNumber(this, event);'> % </td>");
                        //Celda Distribucion
                        strHTMLTabla.Append("<td align=center><input disabled class=\"EtiquetaGeneralDescripcion\" size=12 id=txtdistini_" + dt[1].ToString() + "></td>");
                        strHTMLTabla.Append("<td style=display:none><input id= idfondo_" + conta.ToString() + " value=" + dt[1].ToString() + "></td>");
                        strHTMLTabla.Append("</tr>");
                        conta = conta + 1;
                    }
                    else
                    {
                        strHTMLTabla.Append(" ");
                    }
                }
                strHTMLTabla.Append("<tr style=display:none><td><input id= numfondos value =" + numfondos + "></td>");
                strHTMLTabla.Append("</tr>");
                strHTMLTabla.Append("</table>");
                return strHTMLTabla.ToString();
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
    }
    //Unit Linked Tabla Fondos FIN

    //Unit Linked Fechas Aportacion INI
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string getfecaportacion(string periodo, string dia)
    {
        DateTime dt = DateTime.Now;
        string fecaporte = "";
        Int32 periodomes = 0;
        string[] arrfecha;

        if (periodo == "2")         //Semestral
        {
            periodomes = 6;
        }
        else if (periodo == "3")    //Trimestral
        {
            periodomes = 3;
        }
        else if (periodo == "4")    //Mensual
        {
            periodomes = 1;
        }
        else if (periodo == "10")    //Anual
        {
            periodomes = 12;
        }
        dt = dt.AddMonths(periodomes);

        fecaporte = dt.ToString("dd/MM/yyyy");

        //Se valida que el dia sugerido no sea mayor al ultimo dia del mes
        arrfecha = fecaporte.Split('/');

        Int32 maxDia = DateTime.DaysInMonth(dt.Year, dt.Month);

        if (Convert.ToInt32(dia) > maxDia)
        {
            dia = maxDia.ToString();
        }
        if (Convert.ToInt32(dia) < 10)
        {
            dia = "0" + dia;
        }
        fecaporte = arrfecha[0].ToString().Replace(arrfecha[0].ToString(), dia) + arrfecha[1].ToString() + arrfecha[2].ToString();

        return fecaporte;
    }
    //Unit Linked Fechas Aportacion FIN

    //Unit Linked Metodos cotizacion INI
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataSet getCotizacionUL(string accion, String[] arrDatosPoliza, String[] arrDatosVar, String[] arrDatosCob, String[] arrDatosCont, String[] arrDatosSol, String[] arrDatosBenef, String[] arrDatosBanco, String[] arrDatosComplementarios, string p_token)
    {
        Emision objCotizacion = new Emision(accion);
        try
        {
            objCotizacion.token = p_token;

            DataSet objDataSet = objCotizacion.getCotizacionUL(arrDatosPoliza, arrDatosVar, arrDatosCob, arrDatosCont, arrDatosSol, arrDatosBenef, arrDatosBanco, arrDatosComplementarios);
            //objDataSet = AgregarTablaPrimas(objDataSet);
            return objDataSet;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataSet getSolicitudUL(string accion, String[] arrDatosPoliza, String[] arrDatosVar, String[] arrDatosCob, String[] arrDatosCont, String[] arrDatosSol, String[] arrDatosBenef, String[] arrDatosBanco, String[] arrDatosComplementarios, string p_token)
    {
        string p_wf_ot_m_ot;
        Emision objCotizacion = new Emision(accion);
        Catalogos objCatalogos = new Catalogos();

        try
        {
            objCotizacion.token = p_token;
            int cod_usr;
            String[] DatosBenef = new String[0];

            DataSet objDataSet = objCotizacion.getCotizacionUL(arrDatosPoliza, arrDatosVar, arrDatosCob, arrDatosCont, arrDatosSol, DatosBenef, arrDatosBanco, arrDatosComplementarios);

            string strCotizacion = objDataSet.Tables[4].Rows[0]["COTIZACION"].ToString();
            GuardarBeneficiarios(strCotizacion, arrDatosBenef);

            DataTable dtFolioRAM = new DataTable();
            dtFolioRAM.Columns.Add("FOLIO_RAM");
            string strFolioRAM = ObtenerFolioRAMSolicitud(objDataSet.Tables[4].Rows[0][0].ToString());
            DataRow dr = dtFolioRAM.NewRow();
            dr["FOLIO_RAM"] = strFolioRAM;
            dtFolioRAM.Rows.Add(dr);
            objDataSet.Tables.Add(dtFolioRAM);

            //---C9---

            p_wf_ot_m_ot = Session["p_wf_ot_m_ot"].ToString();
            cod_usr = Int32.Parse(arrDatosPoliza[1].Split('=')[1]);

            objCatalogos.solicitudSuscripcion(p_wf_ot_m_ot, cod_usr, "");

            return objDataSet;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR MetodosAjax.getSolicitud(): " + ex.Message);
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable getDistFondos(string cotizacion)
    {
        DataSet objds = new DataSet();

        MCommand cmd = new MCommand();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "ev_k_112_unit.get_distribucion_fondos";
                cmd.agregarRETURNParametro("results", OracleDbType.RefCursor, 0);
                cmd.agregarINParametro("p_num_cotizacion", OracleDbType.Varchar2, cotizacion);

                objds = cmd.ejecutarRefCursorSP();
            }

        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return objds.Tables[0];
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string deduccionesUL(string cotizacion, string primaini)
    {
        DataSet objds = new DataSet();
        DataTable objdt = new DataTable();
        StringBuilder htmltabla = new StringBuilder();


        MCommand cmd = new MCommand();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "ev_k_112_unit.get_deducciones";
                cmd.agregarRETURNParametro("results", OracleDbType.RefCursor, 0);
                cmd.agregarINParametro("p_num_cotizacion", OracleDbType.Varchar2, cotizacion);

                objds = cmd.ejecutarRefCursorSP();

                objdt = objds.Tables[0];
            }

            string deduccion = objdt.Rows[0].ItemArray[0].ToString();

            decimal resultado = (Convert.ToDecimal(primaini)) - (Convert.ToDecimal(deduccion));

            if (objdt.Rows[0].ToString() != "")
            {
                htmltabla.Append("<Table id='Deducciones' class='table table-bordered tab-border-red' style='width: 100%;' >");
                htmltabla.Append("<tr class='table-danger'>");
                htmltabla.Append("<td>Concepto</td><td>Total</td></tr>");
                htmltabla.Append("<tr>");
                //Nombre Concepto
                htmltabla.Append("<td align=left><input disabled ");
                htmltabla.Append("class=\"EtiquetaGeneralDescripcion\" size = 10 id=Concepto1 value=Prima Inicial></td>");
                //Total Concepto
                htmltabla.Append("<td align=left><input disabled ");
                htmltabla.Append("class=\"EtiquetaGeneralDescripcion\" size = 12 id=Total1 value=" + primaini + "></td></tr>");
                htmltabla.Append("<tr>");
                //Nombre Concepto
                htmltabla.Append("<td align=left><input disabled ");
                htmltabla.Append("class=\"EtiquetaGeneralDescripcion\" size = 10 id=Concepto2 value=Deducciones></td>");
                //Total Concepto
                htmltabla.Append("<td align=left><input disabled ");
                htmltabla.Append("class=\"EtiquetaGeneralDescripcion\" size = 12 id=Total2 value=" + deduccion + "></td></tr>");
                htmltabla.Append("<tr>");
                //Nombre Concepto
                htmltabla.Append("<td align=left><input disabled ");
                htmltabla.Append("class=\"EtiquetaGeneralDescripcion\" size = 10 id=Concepto3 value=Total a Invertir></td>");
                //Total Concepto
                htmltabla.Append("<td align=left><input disabled ");
                htmltabla.Append("class=\"EtiquetaGeneralDescripcion\"  size = 12 id=Total3 value=" + resultado + "></td></tr>");
                htmltabla.Append("</table>");
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return htmltabla.ToString();
    }

    private void Factura(String[] arrDatosPoliza, string numPoliza)
    {
        Hashtable hashDatos = new Hashtable();
        csFacturacion factura = new csFacturacion();
        foreach (string cadena in arrDatosPoliza)
        {
            string[] dato = cadena.Split('=');
            hashDatos.Add(dato[0], dato[1]);
        }
        if (hashDatos["RegFiscal"] == null) { return; }
        string RegFiscal = hashDatos["RegFiscal"].ToString();
        string CodPostalFiscal = hashDatos["CodPostalFiscal"].ToString();
        string RegSocietario = hashDatos["RegSocietario"].ToString();
        string RfcStr = hashDatos["RfcStr"].ToString();
        factura.guardaFacturacion(1, "RFC", int.Parse(RegFiscal), CodPostalFiscal, RegSocietario, numPoliza, RfcStr);
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string getEmisionUL(string accion, String[] arrDatosPoliza, String[] arrDatosVar, String[] arrDatosCob, String[] arrDatosCont, String[] arrDatosSol, String[] arrDatosBenef, String[] arrDatosBanco, String[] arrDatosComplementarios, string p_token, string MSI)//MGM_MSI
    {
        Emision objEmision = new Emision(accion);
        if (MSI == "S")
        {
            HttpContext.Current.Session["BanderaMSI"] = true;//MGM_MSI 
        }

        try
        {
            objEmision.token = p_token;
            string strPoliza = objEmision.getEmisionUL(arrDatosPoliza, arrDatosVar, arrDatosCob, arrDatosCont, arrDatosSol, arrDatosBenef, arrDatosBanco, arrDatosComplementarios);

            DataTable dtControlesTecnicosPLD = null;
            StringBuilder strMensaje = new StringBuilder();
            string strControles = "";
            bool blBanderaControlPLD = false;

            dtControlesTecnicosPLD = obtenListaControlesTecnicos(1, strPoliza, 0, 0, 0);

            if (ConfigurationManager.AppSettings["BanCTPLD"] == "S" && dtControlesTecnicosPLD != null)
            {
                if (dtControlesTecnicosPLD.Rows.Count != 0)
                {
                    foreach (DataRow drControles in dtControlesTecnicosPLD.Rows)
                    {
                        if (drControles["COD_ERROR"].ToString() == "9002")
                        {
                            strMensaje.Append("9002,");
                        }
                        if (drControles["COD_ERROR"].ToString() == "9003")
                        {
                            strMensaje.Append("9003,");
                        }
                        if (drControles["COD_ERROR"].ToString() == "9004")
                        {
                            strMensaje.Append("9004,");
                        }
                        if (drControles["COD_ERROR"].ToString() == "9005")
                        {
                            strMensaje.Append("9005");
                        }
                    }

                    strControles = "|" + strMensaje.ToString().Substring(0, strMensaje.ToString().Length - 1);
                }
                else
                {
                    strControles = "|";
                }
            }
            else
            {
                strControles = "|";
            }

            Factura(arrDatosPoliza, strPoliza);
            try
            {
                Factura(arrDatosPoliza, strPoliza);
            }
            catch (Exception ex)
            {

            }
            strPoliza += "|" + ObtenerFolioRAMPoliza(strPoliza) + strControles + "|" + ConfigurationManager.AppSettings["rutaPantallaExpediente"];
            return strPoliza;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string validaEdadDuracion(string contrato, string duracion, string edad)
    {
        string mensaje = "";

        try
        {
            int intEdad = 0;
            int intDuracion = 0;

            if (!Int32.TryParse(edad, out intEdad))
                return "Verifique la edad";

            if (!Int32.TryParse(duracion, out intDuracion))
                return "Seleccione la duración";

            string varK = "";
            if (contrato == WebUtils.getAppSetting("Cont_Inv_Port09").ToString().Split(',')[0])
                varK += "Cont_Inv_Port09";
            else if (contrato == WebUtils.getAppSetting("Cont_Inv_Port10").ToString().Split(',')[0])
                varK += "Cont_Inv_Port10";
            else if (contrato == WebUtils.getAppSetting("Cont_Inv_Port11").ToString().Split(',')[0])
                varK += "Cont_Inv_Port11";
            else
                return "";

            if (!string.IsNullOrEmpty(varK)
                && WebUtils.getAppSetting(varK).ToString().Split('|')[1].ToString().Split(',').Count() > 2
                && (intDuracion - intEdad) < Convert.ToDecimal(WebUtils.getAppSetting(varK).ToString().Split('|')[1].ToString().Split(',')[2]))
            {
                mensaje = string.Format("La diferencia entre la duracion y la edad debe de ser mayor a: {0} años", WebUtils.getAppSetting(varK).ToString().Split('|')[1].ToString().Split(',')[2]);
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }

        return mensaje;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string val_prima_programada(string ramo, string modalidad, string prima, string moneda)
    {
        CDListaValor objlista = new CDListaValor();
        Hashtable param = new Hashtable();
        DataTable dt = new DataTable();
        string mensaje = "";
        string contrato = (Session["contrato"].ToString());
        String prima_min_ad = "";
        if (prima != "")
        {
            try
            {
                DataSet objds = new DataSet();
                MCommand cmd = new MCommand();
                using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
                {
                    cmd.Connection = conexion;
                    cmd.CommandText = ConfigurationManager.AppSettings["EsquemaVida"].ToString() + ".p_recupera_config_web";
                    cmd.agregarINParametro("p_cod_aplicacion", OracleDbType.Varchar2, "ZAEMISIONGENERAL");
                    cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, Convert.ToInt32(ramo));
                    cmd.agregarINParametro("p_num_poliza_grupo", OracleDbType.Varchar2, "ZTODAS");
                    cmd.agregarINParametro("p_num_contrato", OracleDbType.Int32, Convert.ToInt32(contrato));
                    cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Int32, Convert.ToInt32(modalidad));
                    cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Convert.ToInt32(moneda));
                    cmd.agregarINParametro("p_cod_campo", OracleDbType.Varchar2, "VAL_PRIM_MIN_AD");
                    cmd.agregarOUTParametro("p_val_campo", OracleDbType.Varchar2, 80);

                    objds = cmd.ejecutarRefCursorSP();
                    prima_min_ad = objds.Tables[0].Rows[0]["p_val_campo"].ToString();
                }
            }
            catch (Exception ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("Error MetodosAjax.val_prima_min: " + ex);
            }
            if (Convert.ToDecimal(prima) < Convert.ToDecimal(prima_min_ad))
            {
                mensaje = "La prima programada mínima no puede ser menor que: " + prima_min_ad.ToString();
            }
        }
        else
        {
            mensaje = "El monto de prima adicional no puede ser nulo";
        }

        return mensaje;
    }


    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string val_prima_min(string prima, string modalidad, string moneda, string ramo)
    {
        string mensaje = "";
        string contrato = Session["contrato"].ToString();
        string prima_min = "";
        if (prima != "")
        {
            try
            {
                DataSet objds = new DataSet();
                MCommand cmd = new MCommand();
                using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
                {
                    cmd.Connection = conexion;
                    cmd.CommandText = ConfigurationManager.AppSettings["EsquemaVida"].ToString() + ".p_recupera_config_web";
                    cmd.agregarINParametro("p_cod_aplicacion", OracleDbType.Varchar2, "ZAEMISIONGENERAL");
                    cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, Convert.ToInt32(ramo));
                    cmd.agregarINParametro("p_num_poliza_grupo", OracleDbType.Varchar2, "ZTODAS");
                    cmd.agregarINParametro("p_num_contrato", OracleDbType.Int32, Convert.ToInt32(contrato));
                    cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Int32, Convert.ToInt32(modalidad));
                    cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Convert.ToInt32(moneda));
                    cmd.agregarINParametro("p_cod_campo", OracleDbType.Varchar2, "VAL_PRIM_MIN");
                    cmd.agregarOUTParametro("p_val_campo", OracleDbType.Varchar2, 80);

                    objds = cmd.ejecutarRefCursorSP();
                    prima_min = objds.Tables[0].Rows[0]["p_val_campo"].ToString();
                }
            }
            catch (Exception ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("Error MetodosAjax.val_prima_min: " + ex);
            }
            if (Convert.ToDecimal(prima) < Convert.ToDecimal(prima_min))
            {
                mensaje = "La prima mínima no puede ser menor que: " + prima_min.ToString();
            }
        }
        else
        {
            mensaje = "El monto de prima inicial no puede ser nulo";
        }
        return mensaje;
    }


    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable getPerfilesULind(Int32 cia, Int32 ramo, string parametros)
    {
        DataSet objds = new DataSet();
        DataTable objdt = new DataTable();

        MCommand cmd = new MCommand();
        string tabla = "TA899039";
        Int32 version = 5;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "EM_K_GEN_WS.GETLOV";

                cmd.agregarRETURNParametro("results", OracleDbType.RefCursor, 0);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, cia);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, ramo);
                cmd.agregarINParametro("p_cod_campo", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_nom_tabla", OracleDbType.Varchar2, tabla);
                cmd.agregarINParametro("p_cod_version", OracleDbType.Int32, version);
                cmd.agregarINParametro("p_pramaetros", OracleDbType.Varchar2, parametros);

                objds = cmd.ejecutarRefCursorSP();

                objdt = objds.Tables[0];
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return objdt;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable PlanInd(string ramo)
    {
        CDListaValor objlistavalor = new CDListaValor();
        MCommand cmd = new MCommand();
        DataTable objtabla = new DataTable();
        Hashtable objDatos = new Hashtable();
        string strNOM_TABLA = "G1010031";
        Int32 version = 59;
        string codigo = Session["codprod"].ToString(); //1 = Inversion, 2 = Jubilacion, PPR 
        DataTable tablapaso = new DataTable();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                objDatos.Add("cod_campo", "'" + "TIP_PLAN_UL" + "'");
                objDatos.Add("cod_idioma", "'" + "ES" + "'");
                objDatos.Add("cod_ramo", ramo);

                objtabla = objlistavalor.getListaValores(null, strNOM_TABLA, version, objDatos, conexion);

                if (objtabla.Rows.Count > 0)
                {
                    foreach (DataRow dr in objtabla.Rows)
                    {
                        //Sustituye valores
                        string valori = dr["COD_VALOR"].ToString();
                        if (dr["COD_VALOR"].ToString().Length > 1) //Se valida que sea mayor a 1 ya que siempre deberian venir como 04, 05, 06 etc.
                        {
                            dr["COD_VALOR"] = valori.Replace(valori, ramo + valori);
                        }
                    }
                    tablapaso = objtabla.Clone();
                    foreach (DataRow DRC in objtabla.Rows)
                    {
                        //Se valida que info se insertara a la tabla
                        if (DRC["COD_VALOR"].ToString() == "11204" && codigo == "1")
                        {
                            DataRow row = tablapaso.NewRow();
                            row.ItemArray = DRC.ItemArray;
                            tablapaso.Rows.Add(row);
                        }
                        else if (codigo == "2" && DRC["COD_VALOR"].ToString() != "11204")
                        {
                            DataRow row = tablapaso.NewRow();
                            row.ItemArray = DRC.ItemArray;
                            tablapaso.Rows.Add(row);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return tablapaso;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable getduracioULInd(string ramo, string modalidad, string edad)
    {
        DataTable dura = new DataTable("Duraciones");

        try
        {
            string duracion = "";
            string rango = "";
            string[] arrduracion = new string[2];
            string maxedad = WebUtils.getAppSetting("edad_max");

            //INVERSION = 11204
            //JUBILACION = 11205
            //PPR = 11206

            if (modalidad == "11204")
            {
                duracion = WebUtils.getAppSetting("dur_invIndividual");
                rango = WebUtils.getAppSetting("rango_invIndividual");
            }
            else if (modalidad == "11205")
            {
                duracion = WebUtils.getAppSetting("dur_jubIndividual");
                rango = WebUtils.getAppSetting("rango_jubIndividual");
            }
            else if (modalidad == "11206")
            {
                duracion = WebUtils.getAppSetting("dur_pprIndividual");
                rango = WebUtils.getAppSetting("rango_pprIndividual");
            }

            arrduracion = duracion.Split(',');

            DataColumn columna1 = dura.Columns.Add("NOM_EA", typeof(string));
            DataColumn columna2 = dura.Columns.Add("VALOR_EA", typeof(string));

            if (arrduracion.Length > 1)
            {
                if (modalidad == "11204")
                {
                    int plazosmuestro = Convert.ToInt32(maxedad) - Convert.ToInt32(edad);
                    for (int i = Convert.ToInt32(arrduracion[0]); i <= Convert.ToInt32(plazosmuestro); i++)
                    {
                        dura.Rows.Add(i, i);
                    }
                }
                else
                {
                    for (int i = Convert.ToInt32(arrduracion[0]); i <= Convert.ToInt32(arrduracion[1]); i++)
                    {
                        dura.Rows.Add("EA " + i, i);
                    }
                }
            }
            else
            {
                dura.Rows.Add("EA " + arrduracion[0], arrduracion[0]);
            }

        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return dura;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string prima_min_ind(string prima, string modalidad, string moneda)
    {
        //Se agregan parametros
        string mensaje = "";
        //11204 Inv
        //11205 Jub
        //11206 PPR
        if (prima != "")
        {
            switch (moneda)
            {
                case "1":
                    switch (modalidad)
                    {
                        case "11204":
                            if (Convert.ToDecimal(prima) < Convert.ToDecimal(WebUtils.getAppSetting("Prim_min_UL_ind").ToString()))
                            {
                                mensaje = "El monto mínimo es de: " + WebUtils.getAppSetting("Prim_min_UL_ind").ToString();
                            }
                            else if (Convert.ToDecimal(prima) > Convert.ToDecimal(WebUtils.getAppSetting("maximo_primas_ind").ToString()))
                            {
                                mensaje = "El monto máximo es de: " + WebUtils.getAppSetting("maximo_primas_ind").ToString();
                            }
                            break;
                        case "11205":
                            if (Convert.ToDecimal(prima) < Convert.ToDecimal(WebUtils.getAppSetting("Prim_min_UL_ind").ToString()))
                            {
                                mensaje = "El monto mínimo es de: " + WebUtils.getAppSetting("Prim_min_UL_ind").ToString();
                            }
                            else if (Convert.ToDecimal(prima) > Convert.ToDecimal(WebUtils.getAppSetting("maximo_primas_ind").ToString()))
                            {
                                mensaje = "El monto máximo es de: " + WebUtils.getAppSetting("maximo_primas_ind").ToString();
                            }
                            break;
                        case "11206":
                            if (Convert.ToDecimal(prima) < Convert.ToDecimal(WebUtils.getAppSetting("Prim_min_UL_ind").ToString()))
                            {
                                mensaje = "El monto mínimo es de: " + WebUtils.getAppSetting("Prim_min_UL_ind").ToString();
                            }
                            else if (Convert.ToDecimal(prima) > Convert.ToDecimal(WebUtils.getAppSetting("maximo_primas_ind").ToString()))
                            {
                                mensaje = "El monto máximo es de: " + WebUtils.getAppSetting("maximo_primas_ind").ToString();
                            }
                            break;
                    }
                    break;
                case "2":
                    switch (modalidad)
                    {
                        case "11204":
                            if (Convert.ToDecimal(prima) < Convert.ToDecimal(WebUtils.getAppSetting("Prim_min_UL_inddol").ToString()))
                            {
                                mensaje = "El monto mínimo es de: " + WebUtils.getAppSetting("Prim_min_UL_inddol").ToString();
                            }
                            break;
                        case "11205":
                            if (Convert.ToDecimal(prima) < Convert.ToDecimal(WebUtils.getAppSetting("Prim_min_UL_inddol").ToString()))
                            {
                                mensaje = "El monto mínimo es de: " + WebUtils.getAppSetting("Prim_min_UL_inddol").ToString();
                            }
                            break;
                        case "11206":
                            if (Convert.ToDecimal(prima) < Convert.ToDecimal(WebUtils.getAppSetting("Prim_min_UL_inddol").ToString()))
                            {
                                mensaje = "El monto mínimo es de: " + WebUtils.getAppSetting("Prim_min_UL_inddol").ToString();
                            }
                            break;
                    }
                    break;
            }
        }
        else
        {
            mensaje = "El monto de prima inicial no puede ser nulo";
        }
        return mensaje;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string programada_min_ind(string ramo, string modalidad, string prima, string moneda, string per)
    {
        // Se agregan parametros
        string mensaje = "";
        try
        {
            if (prima != "")
            {
                switch (moneda)
                {
                    case "1":
                        switch (modalidad)
                        {
                            case "11204":
                                if (per == "4")
                                {
                                    if (Convert.ToDecimal(prima) < Convert.ToDecimal(WebUtils.getAppSetting("valorInicialPesos").ToString()))
                                    {
                                        string result = WebUtils.getAppSetting("valorInicialPesos").ToString();
                                        mensaje = "El monto mínimo es de: " + "$" + result + " MXN";
                                    }
                                    else if (Convert.ToDecimal(prima) > Convert.ToDecimal(WebUtils.getAppSetting("maximo_primas_ind").ToString()))
                                    {
                                        mensaje = "El monto máximo es de: " + "$" + WebUtils.getAppSetting("maximo_primas_ind").ToString() + " MXN";
                                    }
                                }
                                else if (per == "3")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 3))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 3;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " MXN";
                                    }
                                    else if (Convert.ToDecimal(prima) > Convert.ToDecimal(WebUtils.getAppSetting("maximo_primas_ind").ToString()))
                                    {
                                        mensaje = "El monto máximo es de: " + "$" + WebUtils.getAppSetting("maximo_primas_ind").ToString() + " MXN";
                                    }
                                }
                                else if (per == "3")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 3))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 3;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " MXN";
                                    }
                                    else if (Convert.ToDecimal(prima) > Convert.ToDecimal(WebUtils.getAppSetting("maximo_primas_ind").ToString()))
                                    {
                                        mensaje = "El monto máximo es de: " + "$" + WebUtils.getAppSetting("maximo_primas_ind").ToString() + " MXN";
                                    }
                                }
                                else if (per == "2")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 6))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 6;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " MXN";
                                    }
                                    else if (Convert.ToDecimal(prima) > Convert.ToDecimal(WebUtils.getAppSetting("maximo_primas_ind").ToString()))
                                    {
                                        mensaje = "El monto máximo es de: " + "$" + WebUtils.getAppSetting("maximo_primas_ind").ToString() + " MXN";
                                    }
                                }
                                else if (per == "10")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 12))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 12;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " MXN";
                                    }
                                    else if (Convert.ToDecimal(prima) > Convert.ToDecimal(WebUtils.getAppSetting("maximo_primas_ind").ToString()))
                                    {
                                        mensaje = "El monto máximo es de: " + "$" + WebUtils.getAppSetting("maximo_primas_ind").ToString() + " MXN";
                                    }
                                }
                                break;
                            case "11205":
                                if (per == "4")
                                {
                                    if (Convert.ToDecimal(prima) < Convert.ToDecimal(WebUtils.getAppSetting("valorInicialPesos").ToString()))
                                    {
                                        string result = WebUtils.getAppSetting("valorInicialPesos").ToString();
                                        mensaje = "El monto mínimo es de: " + "$" + result + " MXN";
                                    }
                                    else if (Convert.ToDecimal(prima) > Convert.ToDecimal(WebUtils.getAppSetting("maximo_primas_ind").ToString()))
                                    {
                                        mensaje = "El monto máximo es de: " + "$" + WebUtils.getAppSetting("maximo_primas_ind").ToString() + " MXN";
                                    }
                                }
                                else if (per == "3")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 3))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 3;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " MXN";
                                    }
                                    else if (Convert.ToDecimal(prima) > Convert.ToDecimal(WebUtils.getAppSetting("maximo_primas_ind").ToString()))
                                    {
                                        mensaje = "El monto máximo es de: " + "$" + WebUtils.getAppSetting("maximo_primas_ind").ToString() + " MXN";
                                    }
                                }
                                else if (per == "3")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 3))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 3;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " MXN";
                                    }
                                    else if (Convert.ToDecimal(prima) > Convert.ToDecimal(WebUtils.getAppSetting("maximo_primas_ind").ToString()))
                                    {
                                        mensaje = "El monto máximo es de: " + "$" + WebUtils.getAppSetting("maximo_primas_ind").ToString() + " MXN";
                                    }
                                }
                                else if (per == "2")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 6))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 6;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " MXN";
                                    }
                                    else if (Convert.ToDecimal(prima) > Convert.ToDecimal(WebUtils.getAppSetting("maximo_primas_ind").ToString()))
                                    {
                                        mensaje = "El monto máximo es de: " + "$" + WebUtils.getAppSetting("maximo_primas_ind").ToString() + " MXN";
                                    }
                                }
                                else if (per == "10")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 12))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 12;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " MXN";
                                    }
                                    else if (Convert.ToDecimal(prima) > Convert.ToDecimal(WebUtils.getAppSetting("maximo_primas_ind").ToString()))
                                    {
                                        mensaje = "El monto máximo es de: " + "$" + WebUtils.getAppSetting("maximo_primas_ind").ToString() + " MXN";
                                    }
                                }
                                break;
                            case "11206":
                                if (per == "4")
                                {
                                    if (Convert.ToDecimal(prima) < Convert.ToDecimal(WebUtils.getAppSetting("valorInicialPesos").ToString()))
                                    {
                                        string result = WebUtils.getAppSetting("valorInicialPesos").ToString();
                                        mensaje = "El monto mínimo es de: " + "$" + result + " MXN";
                                    }
                                    else if (Convert.ToDecimal(prima) > Convert.ToDecimal(WebUtils.getAppSetting("maximo_primas_ind").ToString()))
                                    {
                                        mensaje = "El monto máximo es de: " + "$" + WebUtils.getAppSetting("maximo_primas_ind").ToString() + " MXN";
                                    }
                                }
                                else if (per == "3")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 3))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 3;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " MXN";
                                    }
                                    else if (Convert.ToDecimal(prima) > Convert.ToDecimal(WebUtils.getAppSetting("maximo_primas_ind").ToString()))
                                    {
                                        mensaje = "El monto máximo es de: " + "$" + WebUtils.getAppSetting("maximo_primas_ind").ToString() + " MXN";
                                    }
                                }
                                else if (per == "2")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 6))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 6;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " MXN";
                                    }
                                    else if (Convert.ToDecimal(prima) > Convert.ToDecimal(WebUtils.getAppSetting("maximo_primas_ind").ToString()))
                                    {
                                        mensaje = "El monto máximo es de: " + "$" + WebUtils.getAppSetting("maximo_primas_ind").ToString() + " MXN";
                                    }
                                }
                                else if (per == "10")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 12))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialPesos").ToString()) * 12;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " MXN";
                                    }
                                    else if (Convert.ToDecimal(prima) > Convert.ToDecimal(WebUtils.getAppSetting("maximo_primas_ind").ToString()))
                                    {
                                        mensaje = "El monto máximo es de: " + "$" + WebUtils.getAppSetting("maximo_primas_ind").ToString() + " MXN";
                                    }
                                }
                                break;
                        }
                        break;
                    case "2":
                        switch (modalidad)
                        {
                            case "11204":
                                if (per == "4")
                                {
                                    if (Convert.ToDecimal(prima) < Convert.ToDecimal(WebUtils.getAppSetting("valorInicialDolares").ToString()))
                                    {
                                        string result = WebUtils.getAppSetting("valorInicialDolares").ToString();
                                        mensaje = "El monto mínimo es de: " + "$" + result + " USD";
                                    }

                                }
                                else if (per == "3")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 3))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 3;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " USD";
                                    }
                                }
                                else if (per == "2")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 6))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 6;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " USD";
                                    }
                                }
                                else if (per == "10")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 12))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 12;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " USD";
                                    }
                                }

                                break;
                            case "11205":
                                if (per == "4")
                                {
                                    if (Convert.ToDecimal(prima) < Convert.ToDecimal(WebUtils.getAppSetting("valorInicialDolares").ToString()))
                                    {
                                        string result = WebUtils.getAppSetting("valorInicialDolares").ToString();
                                        mensaje = "El monto mínimo es de: " + "$" + result + " USD";
                                    }
                                }
                                if (per == "3")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 3))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 3;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " USD";
                                    }
                                }
                                if (per == "2")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 6))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 6;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " USD";
                                    }
                                }
                                if (per == "10")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 12))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 12;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " USD";
                                    }
                                }
                                break;
                            case "11206":
                                if (per == "4")
                                {
                                    if (Convert.ToDecimal(prima) < Convert.ToDecimal(WebUtils.getAppSetting("valorInicialDolares").ToString()))
                                    {
                                        string result = WebUtils.getAppSetting("valorInicialDolares").ToString();
                                        mensaje = "El monto mínimo es de: " + "$" + result + " USD";
                                    }
                                }
                                if (per == "3")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 3))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 3;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " USD";
                                    }
                                }
                                if (per == "2")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 6))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 6;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " USD";
                                    }
                                }
                                if (per == "10")
                                {
                                    if (Convert.ToDecimal(prima) < (Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 12))
                                    {
                                        int result = Convert.ToInt16(WebUtils.getAppSetting("valorInicialDolares").ToString()) * 12;
                                        mensaje = "El monto mínimo es de: " + "$" + Convert.ToString(result) + " USD";
                                    }
                                }
                                break;
                        }
                        break;
                }
            }
            else
            {
                mensaje = "El monto de prima adicional no puede ser nulo";
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return mensaje;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string getDatosCobULind(Int32 cia, Int32 ramo, string modalidad, Int32 moneda, Int32 edad, string parametros)
    {
        DataSet objds = new DataSet();
        DataTable objdt = new DataTable();
        DataTable objdtpct = new DataTable();
        MetodosAjax metodos = new MetodosAjax();

        MCommand cmd = new MCommand();
        string tabla = "A1002150";
        Int32 version = 30;

        try
        {
            StringBuilder strHTMLTabla = new StringBuilder();
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "EM_K_GEN_WS.GETLOV";

                cmd.agregarRETURNParametro("results", OracleDbType.RefCursor, 0);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, cia);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, ramo);
                cmd.agregarINParametro("p_cod_campo", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_nom_tabla", OracleDbType.Varchar2, tabla);
                cmd.agregarINParametro("p_cod_version", OracleDbType.Int32, version);
                cmd.agregarINParametro("p_pramaetros", OracleDbType.Varchar2, parametros);

                objds = cmd.ejecutarRefCursorSP();

                objdt = objds.Tables[0];
            }

            DataView vistaTabla = new DataView(objdt);
            DataTable cobertura;
            DataRow row = null;
            DataTable coberturasOrganizadas;
            coberturasOrganizadas = objdt.Clone();

            int duracion = Convert.ToInt32(recuperasession("duration"));
            string[] consultas;

            if (duracion < 5)
            {
                consultas = new string[] {
                "COD_COB = '1000'",                 //chk1
                "COD_COB = '1004'",                 //chk2
                "COD_COB = '1003'",};               //chk5              
            }
            else
            {
                consultas = new string[] {
                "COD_COB = '1000'",                                 //chk1
                "COD_COB = '1004'",                                 //chk2
                "COD_COB = '1095'",                                 //chk3
                "COD_COB = '1096'",                                 //chk4
                "COD_COB = '1003'",};                               //chk5
            }

            foreach (var item in consultas)
            {
                vistaTabla.RowFilter = item;
                cobertura = vistaTabla.ToTable();
                if (!(cobertura.Rows.Count == 0))
                {
                    row = cobertura.Rows[0];
                    coberturasOrganizadas.ImportRow(row);
                    vistaTabla.Delete(0);
                }
            }
            vistaTabla.RowFilter = "";
            //coberturasOrganizadas.Merge(vistaTabla.ToTable());
            objdt = coberturasOrganizadas;
            string nomcob = "";


            if (objdt.Rows.Count > 0)
            {
                strHTMLTabla.Append("<table id='Coberturas' class='table table-bordered tab-border-red' style='width: 100%;display:table-row;'>");
                strHTMLTabla.Append("<tr class='table-danger'>");
                strHTMLTabla.Append("<td></td><td align=\"center\">Cobertura</td><td align=\"center\">Suma Asegurada</td><td align=\"center\">Prima</td>");
                strHTMLTabla.Append("</tr>");
                int ContAux = 1;

                foreach (DataRow dr in objdt.Rows)
                {
                    if (dr["COD_AGRUP_COB_2"].ToString() != "")
                    {
                        if (dr[2].ToString() != "" || dr[2] != null)
                        {
                            strHTMLTabla.Append("<tr>");
                            strHTMLTabla.Append("<td align=\"center\" ><input ");
                            //Celda con checkbox
                            if (dr[1].ToString() == "1000")//Basica
                            {
                                strHTMLTabla.Append("disabled checked='checked' ");
                                strHTMLTabla.Append("name=chkCobertura id=chk" + ContAux + " type=checkbox value=" + dr[1].ToString() + "></td>");
                            }
                            else
                            {
                                strHTMLTabla.Append("name=chkCobertura id=chk" + ContAux + " type=checkbox value=" + dr[1].ToString() + " onclick=\"validacheck(this.value)\"></td>");
                            }
                            //Celda con los nombres de las coberturas
                            nomcob = dr[0].ToString();

                            switch (nomcob)
                            {
                                case "BASICA":
                                    nomcob = nomcob.ToString().Replace(nomcob, "FALLECIMIENTO");
                                    strHTMLTabla.Append("<td><input disabled class=\"EtiquetaGeneralIzquierda\" size=45 value=\"" + nomcob.ToString() + "\"></td>");
                                    break;
                                case "FALLECIMIENTO ACCIDENTAL":
                                    nomcob = nomcob.ToString().Replace(nomcob, "MUERTE ACCIDENTAL");
                                    strHTMLTabla.Append("<td><input disabled class=\"EtiquetaGeneralIzquierda\" size=45 value=\"" + nomcob.ToString() + "\"></td>");
                                    break;
                                case "BIT":
                                    nomcob = nomcob.ToString().Replace(nomcob, "EXENCIÓN DEL COSTO DE COBERTURA (BIT)");
                                    strHTMLTabla.Append("<td><input disabled class=\"EtiquetaGeneralIzquierda\" size=45 value=\"" + nomcob.ToString() + "\"></td>");
                                    break;
                                case "BIPA":
                                    nomcob = nomcob.ToString().Replace(nomcob, "INVALIDEZ TOTAL Y PERMANENTE (BIPA)");
                                    strHTMLTabla.Append("<td><input disabled class=\"EtiquetaGeneralIzquierda\" size=45 value=\"" + nomcob.ToString() + "\"></td>");
                                    break;
                                case "EG":
                                    nomcob = nomcob.ToString().Replace(nomcob, "ENFERMEDADES GRAVES");
                                    strHTMLTabla.Append("<td><input disabled class=\"EtiquetaGeneralIzquierda\" size=45 value=\"" + nomcob.ToString() + "\"></td>");
                                    break;
                            }

                            //Celda del campo de SA
                            switch (dr[1].ToString())
                            {
                                case "1000":    //Basica
                                    strHTMLTabla.Append("<td align=\"center\"><input size=10 MaxLength= 9 onblur=\"validaSAB()\" class=\"EtiquetaGeneralIzquierda\" id=txtSuma" + dr[1].ToString() + "></td>");
                                    break;
                                case "1004":    //Fallecimiento
                                    strHTMLTabla.Append("<td align=\"center\"><input size=10 disabled MaxLength= 9 onblur=\"validaSAO(" + dr[1].ToString() + ")\" class=\"EtiquetaGeneralIzquierda\" id=txtSuma" + dr[1].ToString() + "></td>");
                                    break;
                                case "1096":    //BIPA
                                    strHTMLTabla.Append("<td align=\"center\"><input size=10 disabled MaxLength= 9 onblur=\"validaSAO(" + dr[1].ToString() + ")\" class=\"EtiquetaGeneralIzquierda\" id=txtSuma" + dr[1].ToString() + "></td>");
                                    break;
                                case "1095":    //BIT
                                    strHTMLTabla.Append("<td align=\"center\"><input size=10 disabled MaxLength= 9 \" class=\"EtiquetaGeneralIzquierda\" id=txtSuma" + dr[1].ToString() + "></td>");
                                    break;
                                case "1003":    //EG
                                    strHTMLTabla.Append("<td align=\"center\"><input  size=10  disabled MaxLength= 9 \" class=\"EtiquetaGeneralIzquierda\" id=txtSuma" + dr[1].ToString() + "></td>");
                                    break;
                            }
                            //Celda de Prima
                            strHTMLTabla.Append("<td align=\"center\"><input disabled class=\"EtiquetaGeneralIzquierda\" size=10 id=txtPrima" + dr[1].ToString() + "></td>");
                        }
                    }
                    ContAux++;
                }
                strHTMLTabla.Append("</table>");
            }
            else
            {
                if (moneda != 0 && modalidad != "-1")
                {
                    strHTMLTabla.Append(" ");
                }
            }
            return strHTMLTabla.ToString();
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string getDatosCobULind2(Int32 cia, Int32 ramo, string modalidad, Int32 moneda, Int32 edad, string parametros)
    {
        DataSet objds = new DataSet();
        DataTable objdt = new DataTable();
        DataTable objdtpct = new DataTable();
        MetodosAjax metodos = new MetodosAjax();

        MCommand cmd = new MCommand();
        string tabla = "A1002150";
        Int32 version = 30;


        try
        {
            StringBuilder strHTMLTabla = new StringBuilder();
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "EM_K_GEN_WS.GETLOV";

                cmd.agregarRETURNParametro("results", OracleDbType.RefCursor, 0);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, cia);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, ramo);
                cmd.agregarINParametro("p_cod_campo", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_nom_tabla", OracleDbType.Varchar2, tabla);
                cmd.agregarINParametro("p_cod_version", OracleDbType.Int32, version);
                cmd.agregarINParametro("p_pramaetros", OracleDbType.Varchar2, parametros);

                objds = cmd.ejecutarRefCursorSP();

                objdt = objds.Tables[0];
            }

            DataView vistaTabla = new DataView(objdt);
            DataTable cobertura;
            DataRow row = null;
            DataTable coberturasOrganizadas;
            coberturasOrganizadas = objdt.Clone();

            int duracion = Convert.ToInt32(recuperasession("duration"));
            string[] consultas;

            if (duracion < 5)
            {
                consultas = new string[] {
                "COD_COB = '1000'"};               //chk5              
            }
            else
            {
                consultas = new string[] {
                "COD_COB = '1000'"};                               //chk5
            }

            foreach (var item in consultas)
            {
                vistaTabla.RowFilter = item;
                cobertura = vistaTabla.ToTable();
                if (!(cobertura.Rows.Count == 0))
                {
                    row = cobertura.Rows[0];
                    coberturasOrganizadas.ImportRow(row);
                    vistaTabla.Delete(0);
                }
            }
            vistaTabla.RowFilter = "";
            //coberturasOrganizadas.Merge(vistaTabla.ToTable());
            objdt = coberturasOrganizadas;
            string nomcob = "";


            if (objdt.Rows.Count > 0)
            {
                strHTMLTabla.Append("<table id='Coberturas' class='table table-bordered tab-border-red' style='width: 100%;display:table-row;'>");
                strHTMLTabla.Append("<tr class='table-danger'>");
                strHTMLTabla.Append("<td></td><td align=\"center\">Cobertura</td><td align=\"center\">Suma Asegurada</td><td align=\"center\">Prima</td>");
                strHTMLTabla.Append("</tr>");
                int ContAux = 1;

                foreach (DataRow dr in objdt.Rows)
                {
                    if (dr["COD_AGRUP_COB_2"].ToString() != "")
                    {
                        if (dr[2].ToString() != "" || dr[2] != null)
                        {
                            strHTMLTabla.Append("<tr>");
                            strHTMLTabla.Append("<td align=\"center\" ><input ");
                            //Celda con checkbox
                            if (dr[1].ToString() == "1000")//Basica
                            {
                                strHTMLTabla.Append("disabled checked='checked' ");
                                strHTMLTabla.Append("name=chkCobertura id=chk" + ContAux + " type=checkbox value=" + dr[1].ToString() + "></td>");
                            }
                            else
                            {
                                strHTMLTabla.Append("name=chkCobertura id=chk" + ContAux + " type=checkbox value=" + dr[1].ToString() + " onclick=\"validacheck(this.value)\"></td>");
                            }
                            //Celda con los nombres de las coberturas
                            nomcob = dr[0].ToString();

                            switch (nomcob)
                            {
                                case "BASICA":
                                    nomcob = nomcob.ToString().Replace(nomcob, "FALLECIMIENTO");
                                    strHTMLTabla.Append("<td><input disabled class=\"EtiquetaGeneralIzquierda\" size=45 value=\"" + nomcob.ToString() + "\"></td>");
                                    break;
                                case "FALLECIMIENTO ACCIDENTAL":
                                    nomcob = nomcob.ToString().Replace(nomcob, "MUERTE ACCIDENTAL");
                                    strHTMLTabla.Append("<td><input disabled class=\"EtiquetaGeneralIzquierda\" size=45 value=\"" + nomcob.ToString() + "\"></td>");
                                    break;
                                case "BIT":
                                    nomcob = nomcob.ToString().Replace(nomcob, "EXENCIÓN DEL COSTO DE COBERTURA (BIT)");
                                    strHTMLTabla.Append("<td><input disabled class=\"EtiquetaGeneralIzquierda\" size=45 value=\"" + nomcob.ToString() + "\"></td>");
                                    break;
                                case "BIPA":
                                    nomcob = nomcob.ToString().Replace(nomcob, "INVALIDEZ TOTAL Y PERMANENTE (BIPA)");
                                    strHTMLTabla.Append("<td><input disabled class=\"EtiquetaGeneralIzquierda\" size=45 value=\"" + nomcob.ToString() + "\"></td>");
                                    break;
                                case "EG":
                                    nomcob = nomcob.ToString().Replace(nomcob, "ENFERMEDADES GRAVES");
                                    strHTMLTabla.Append("<td><input disabled class=\"EtiquetaGeneralIzquierda\" size=45 value=\"" + nomcob.ToString() + "\"></td>");
                                    break;
                            }

                            //Celda del campo de SA
                            switch (dr[1].ToString())
                            {
                                case "1000":    //Basica
                                    strHTMLTabla.Append("<td align=\"center\"><input size=10 MaxLength= 9 onblur=\"validaSAB()\" class=\"EtiquetaGeneralIzquierda\" id=txtSuma" + dr[1].ToString() + "></td>");
                                    break;
                                case "1004":    //Fallecimiento
                                    strHTMLTabla.Append("<td align=\"center\"><input size=10 disabled MaxLength= 9 onblur=\"validaSAO(" + dr[1].ToString() + ")\" class=\"EtiquetaGeneralIzquierda\" id=txtSuma" + dr[1].ToString() + "></td>");
                                    break;
                                case "1096":    //BIPA
                                    strHTMLTabla.Append("<td align=\"center\"><input size=10 disabled MaxLength= 9 onblur=\"validaSAO(" + dr[1].ToString() + ")\" class=\"EtiquetaGeneralIzquierda\" id=txtSuma" + dr[1].ToString() + "></td>");
                                    break;
                                case "1095":    //BIT
                                    strHTMLTabla.Append("<td align=\"center\"><input size=10 disabled MaxLength= 9 \" class=\"EtiquetaGeneralIzquierda\" id=txtSuma" + dr[1].ToString() + "></td>");
                                    break;
                                case "1003":    //EG
                                    strHTMLTabla.Append("<td align=\"center\"><input  size=10  disabled MaxLength= 9 \" class=\"EtiquetaGeneralIzquierda\" id=txtSuma" + dr[1].ToString() + "></td>");
                                    break;
                            }
                            //Celda de Prima
                            strHTMLTabla.Append("<td align=\"center\"><input disabled class=\"EtiquetaGeneralIzquierda\" size=10 id=txtPrima" + dr[1].ToString() + "></td>");
                        }
                    }
                    ContAux++;
                }
                strHTMLTabla.Append("</table>");
            }
            else
            {
                if (moneda != 0 && modalidad != "-1")
                {
                    strHTMLTabla.Append(" ");
                }
            }
            return strHTMLTabla.ToString();
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
    }


    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string validaSAind(string saB, string cobertura, string edad, string saO, string moneda)
    {
        //Se agrego la moneda

        string mensaje = "";
        string maxsaedad65 = WebUtils.getAppSetting("rango_sa_edad65").ToString();
        string maxsaedad70 = WebUtils.getAppSetting("rango_sa_edad70").ToString();
        string maxsaedad80 = WebUtils.getAppSetting("rango_sa_edad80").ToString();
        string maxsaedad65dol = WebUtils.getAppSetting("rango_sa_edad65dol").ToString();
        string maxsaedad70dol = WebUtils.getAppSetting("rango_sa_edad70dol").ToString();
        string maxsaedad80dol = WebUtils.getAppSetting("rango_sa_edad80dol").ToString();
        string minsa = WebUtils.getAppSetting("min_sa_ulind").ToString();
        string minsadol = WebUtils.getAppSetting("min_sa_ulinddol").ToString();

        try
        {
            if (cobertura == "1000")
            {
                if (saB != "")
                {
                    switch (moneda)
                    {
                        case "1":
                            if (Convert.ToInt32(edad) <= 65)
                            {
                                if (Convert.ToInt32(saB) > Convert.ToInt32(maxsaedad65))
                                {
                                    mensaje = "La suma asegurada máxima es de: " + Convert.ToString(maxsaedad65);
                                }
                            }
                            else if (Convert.ToInt32(edad) <= 70)
                            {
                                if (Convert.ToInt32(saB) > Convert.ToInt32(maxsaedad70))
                                {
                                    mensaje = "La suma asegurada máxima es de: " + Convert.ToString(maxsaedad70);
                                }
                            }
                            else if (Convert.ToInt32(edad) <= 80)
                            {
                                if (Convert.ToInt32(saB) > Convert.ToInt32(maxsaedad80))
                                {
                                    mensaje = "La suma asegurada máxima es de: " + Convert.ToString(maxsaedad80);
                                }
                            }
                            break;
                        case "2":                           //Dolares
                            if (Convert.ToInt32(edad) <= 65)
                            {
                                if (Convert.ToInt32(saB) > Convert.ToInt32(maxsaedad65dol))
                                {
                                    mensaje = "La suma asegurada máxima es de: " + Convert.ToString(maxsaedad65dol);
                                }
                            }
                            else if (Convert.ToInt32(edad) <= 70)
                            {
                                if (Convert.ToInt32(saB) > Convert.ToInt32(maxsaedad70dol))
                                {
                                    mensaje = "La suma asegurada máxima es de: " + Convert.ToString(maxsaedad70dol);
                                }
                            }
                            else if (Convert.ToInt32(edad) <= 80)
                            {
                                if (Convert.ToInt32(saB) > Convert.ToInt32(maxsaedad80dol))
                                {
                                    mensaje = "La suma asegurada máxima es de: " + Convert.ToString(maxsaedad80dol);
                                }
                            }
                            break;
                    }
                }
                else
                {
                    mensaje = "El monto de la suma asegurada básica no puede ser nulo.";
                }
            }
            else if (cobertura != "1004" && cobertura != "1096" && cobertura != "1000")
            {
                double total = Convert.ToDouble(saB) * 0.25;

                if (Convert.ToDouble(saO) > (Convert.ToDouble(saB) * 0.25))
                {
                    mensaje = "La suma asegurada máxima es de: " + Convert.ToString(total);
                }
                else if (Convert.ToDouble(saO) < Convert.ToDouble(minsa))
                {
                    mensaje = "La suma asegurada mínima es de: " + minsa;
                }

            }
            else//valida SA de la cobertura opcional
            {
                if (saO != "")
                {
                    switch (moneda)
                    {
                        case "1":
                            if (Convert.ToInt32(saO) < Convert.ToInt32(minsa))
                            {
                                mensaje = "La suma asegurada mínima es de: " + minsa;
                            }
                            else if (Convert.ToInt32(saB) < Convert.ToInt32(saO))
                            {
                                mensaje = "La suma asegurada máxima es de: " + saB;
                            }
                            break;
                        case "2":
                            if (Convert.ToInt32(saO) < Convert.ToInt32(minsadol))
                            {
                                mensaje = "La suma asegurada mínima es de: " + minsadol;
                            }
                            else if (Convert.ToInt32(saB) < Convert.ToInt32(saO))
                            {
                                mensaje = "La suma asegurada máxima es de: " + saB;
                            }
                            break;
                    }
                }
                else
                {
                    if (cobertura == "1000")
                    {
                        mensaje = "El monto de la suma asegurada básica no puede ser nulo.";
                    }
                    else
                    {
                        mensaje = "El monto de la suma asegurada no puede ser nulo.";
                    }
                }
            }

            switch (moneda)
            {
                case "1":
                    if (Convert.ToInt32(saB) < Convert.ToInt32(minsa))
                    {
                        mensaje = "La suma asegurada mínima es de: " + minsa;
                    }
                    break;
                case "2":
                    if (Convert.ToInt32(saB) < Convert.ToInt32(minsadol))
                    {
                        mensaje = "La suma asegurada mínima es de: " + minsadol;
                    }
                    break;
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return mensaje;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable getprimasul(string cobs, string ramo, string moda, string duracion, string edad, string moneda, string contrato)
    {
        MCommand cmd = new MCommand();
        DataSet objds = new DataSet();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "tron2000.ev_k_productos_vida_mmx.p_ul_ind_prima_riesgo";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, Convert.ToInt32(ramo));
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Int32, Convert.ToInt32(moda));
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Int32, Convert.ToInt32(contrato));
                cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Convert.ToInt32(moneda));
                cmd.agregarINParametro("p_sumas_aseg", OracleDbType.Varchar2, cobs);
                cmd.agregarINParametro("p_duracion", OracleDbType.Int32, Convert.ToInt32(duracion));
                cmd.agregarINParametro("p_edad", OracleDbType.Int32, Convert.ToInt32(edad));
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);
                cmd.agregarOUTParametro("p_primas", OracleDbType.RefCursor, 0);

                objds = cmd.ejecutarRefCursorSP();
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return objds.Tables[0];
    }

    [Ajax.AjaxMethod()]
    public String ValidaTarjetaTC(string num_tarjeta, string cod_banco, string gestor)
    {
        CDConsulta objConsulta = new CDConsulta();
        string mensaje = "";

        using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
        {
            try
            {
                objConsulta.validaTC(num_tarjeta, cod_banco, gestor, conexion);
            }
            catch (Exception ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("MetodosAjax.ValidaTarjeta: ", ex);
                mensaje = "El número de Tarjeta es inválido";
            }
        }
        return mensaje;
    }

    [Ajax.AjaxMethod()]
    public string recuperasession(string nomsession)
    {
        string sesion = "";

        sesion = Session[nomsession].ToString();
        if (sesion != "")
        {
            return sesion;
        }
        else
        {
            sesion = "";
            return sesion;
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string deduccionesULIND(string cotizacion, string primaini, string primafracc)
    {
        DataSet objds = new DataSet();
        DataTable objdt = new DataTable();
        StringBuilder htmltabla = new StringBuilder();


        MCommand cmd = new MCommand();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "ev_k_112_unit.get_deducciones";
                cmd.agregarRETURNParametro("results", OracleDbType.RefCursor, 0);
                cmd.agregarINParametro("p_num_cotizacion", OracleDbType.Varchar2, cotizacion);

                objds = cmd.ejecutarRefCursorSP();

                objdt = objds.Tables[0];
            }

            string deduccion = objdt.Rows[0].ItemArray[0].ToString();

            decimal suma = Convert.ToDecimal(primaini) + Convert.ToDecimal(primafracc);

            decimal resultado = suma - (Convert.ToDecimal(deduccion));

            if (objdt.Rows[0].ToString() != "")
            {
                htmltabla.Append("<Table id='Deducciones' class='table table-bordered tab-border-red' style='width: 100%;'>");
                htmltabla.Append("<tr class='table-danger'>");
                htmltabla.Append("<td>Concepto</td><td>Total</td></tr>");
                htmltabla.Append("<tr>");
                //Nombre Concepto
                htmltabla.Append("<td align=left><input disabled ");
                htmltabla.Append("class=\"EtiquetaGeneralDescripcion\" size = 10 id=Concepto1 value=Prima Inicial></td>");
                //Total Concepto
                htmltabla.Append("<td align=left><input disabled ");
                htmltabla.Append("class=\"EtiquetaGeneralDescripcion\" size = 12 id=Total1 value=" + Convert.ToString(suma) + "></td></tr>");
                htmltabla.Append("<tr>");
                //Nombre Concepto
                htmltabla.Append("<td align=left><input disabled ");
                htmltabla.Append("class=\"EtiquetaGeneralDescripcion\" size = 10 id=Concepto2 value=Deducciones></td>");
                //Total Concepto
                htmltabla.Append("<td align=left><input disabled ");
                htmltabla.Append("class=\"EtiquetaGeneralDescripcion\" size = 12 id=Total2 value=" + deduccion + "></td></tr>");
                htmltabla.Append("<tr>");
                //Nombre Concepto
                htmltabla.Append("<td align=left><input disabled ");
                htmltabla.Append("class=\"EtiquetaGeneralDescripcion\" size = 10 id=Concepto3 value=Total a Invertir></td>");
                //Total Concepto
                htmltabla.Append("<td align=left><input disabled ");
                htmltabla.Append("class=\"EtiquetaGeneralDescripcion\"  size = 12 id=Total3 value=" + Convert.ToString(resultado) + "></td></tr>");
                htmltabla.Append("</table>");
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return htmltabla.ToString();
    }

    #endregion
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void GuardaSession(String Tipo_benef)
    {
        DataTable dt = new DataTable();
        dt = (DataTable)Session["Beneficiarios"];
        switch (Tipo_benef.ToLower())
        {
            case "titular":
                Session["Beneficiarios_Titular"] = dt;
                break;
            case "menor":
                Session["Beneficiarios_Menor"] = dt;
                break;
            case "mancomunado":
                Session["Beneficiarios_Mancomuna"] = dt;
                break;

        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void Eliminasession()
    {
        Session["Beneficiarios2"] = ((DataTable)Session["Beneficiarios"]).Copy();
        Session["Beneficiarios"] = null;

    }

    //[Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    //public void GuardaSessionCoti()
    //{


    //  Session["COTI"] = 1;



    //}

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public int setprimas()
    {
        int primas;
        int pruebas = Convert.ToInt32(Session["PRIMAS"]);
        if (Session["PRIMAS"] == null)
        {
            primas = 0;
        }
        else
        {
            primas = Convert.ToInt32(Session["PRIMAS"]);
        }

        return primas;


    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void insertaAseg(string cod_docum, string rfc, string nombre, string paterno, string materno, int cod_parent, string nom_parent, string fec_nac, int edad, int sexo, string edo_civil, string nom_civil) //'21 Se agregan parámetros string fecnac, string domicilio
    {


        AseguradoSF objAsegurado = new AseguradoSF();

        string keySession = "";
        string strTotal = "";
        int total = 5;
        try
        {


            strTotal = " principales";
            keySession = "Asegurados";



            if (Session[keySession] == null)
                Session.Add(keySession, objAsegurado.Asegurados);
            objAsegurado.Asegurados = ((DataTable)Session[keySession]).Copy();
            //'C21 Se agregan parámetros string fecnac, string domicilio
            objAsegurado.Insertar(cod_docum, rfc, nombre, paterno, materno, cod_parent, nom_parent, fec_nac, edad, sexo, edo_civil, nom_civil);


            // valida numero de asegurados
            if (objAsegurado.Asegurados.Rows.Count > total)
                throw new Exception("Solo puedes agregar " + total + " Asegurados" + strTotal);

            // Se verifica que primero se capturen los beneficiarios principales



            Session[keySession] = objAsegurado.Asegurados;

            objAsegurado.Asegurados = ((DataTable)Session["Asegurados"]).Copy();
            Session["Asegurados"] = objAsegurado.Asegurados;
            // <--- C5 --->

            // ------------

        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable setAsegurados()
    {
        DataTable asegurados = new DataTable();
        try
        {
            asegurados = ((DataTable)Session["Asegurados"]).Copy();

            return asegurados;
        }
        catch
        {
            return asegurados;
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable getCoberturasFirma()
    {
        DataTable coberturasAseg = new DataTable();
        try
        {
            coberturasAseg = ((DataTable)Session["coberturas"]).Copy();
            return coberturasAseg;
        }
        catch
        {
            return coberturasAseg;
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable CuestionarioTitularMancomunado(string TipoPersona, string chkCorazonSi, string chkHipertesionArterialSi,
        string chkCrebroVasculadresSI, string chkPsiquiatricasNerviosasSi, string chkEndocrinasSI, string chkInsuficienciaRenalSi,
        string chkSangreSi, string chkCirrosisHeptitisSi, string chkPulmonaresRespiratoriasSi, string chkConsumoDrogasSI, string chkSidaSI, string chkArtritisSI,
        string chkAparatoDigestivoSi, string chkSiPregunta1, string chkSiPregunta2, string chkSiPregunta3, string chkSiPregunta4, string chkSiPregunta5,
        string chkSiPregunta5_1, string chkSiPregunta6, string chkSiPregunta7, string chkSiPregunta8, string chkSiPregunta9, string chkSiPregunta10,
        string chkSiPregunta11, string chkSiPregunta12, string Nombre)
    {
        DataTable CuestionarioTitularMancomunado;

        try
        {
            if (Session["CuestionarioTitularMancomunado"] == null)
            {
                CuestionarioTitularMancomunado = new DataTable();

                CuestionarioTitularMancomunado.Columns.Add("TipoPersona");
                CuestionarioTitularMancomunado.Columns.Add("chkCorazonSi");
                CuestionarioTitularMancomunado.Columns.Add("chkHipertesionArterialSi");
                CuestionarioTitularMancomunado.Columns.Add("chkCrebroVasculadresSI");
                CuestionarioTitularMancomunado.Columns.Add("chkPsiquiatricasNerviosasSi");
                CuestionarioTitularMancomunado.Columns.Add("chkEndocrinasSI");
                CuestionarioTitularMancomunado.Columns.Add("chkInsuficienciaRenalSi");
                CuestionarioTitularMancomunado.Columns.Add("chkSangreSi");
                CuestionarioTitularMancomunado.Columns.Add("chkCirrosisHeptitisSi");
                CuestionarioTitularMancomunado.Columns.Add("chkPulmonaresRespiratoriasSi");
                CuestionarioTitularMancomunado.Columns.Add("chkConsumoDrogasSI");
                CuestionarioTitularMancomunado.Columns.Add("chkSidaSI");
                CuestionarioTitularMancomunado.Columns.Add("chkArtritisSI");
                CuestionarioTitularMancomunado.Columns.Add("chkAparatoDigestivoSi");
                CuestionarioTitularMancomunado.Columns.Add("chkSiPregunta1");
                CuestionarioTitularMancomunado.Columns.Add("chkSiPregunta2");
                CuestionarioTitularMancomunado.Columns.Add("chkSiPregunta3");
                CuestionarioTitularMancomunado.Columns.Add("chkSiPregunta4");
                CuestionarioTitularMancomunado.Columns.Add("chkSiPregunta5");
                CuestionarioTitularMancomunado.Columns.Add("chkSiPregunta5_1");
                CuestionarioTitularMancomunado.Columns.Add("chkSiPregunta6");
                CuestionarioTitularMancomunado.Columns.Add("chkSiPregunta7");
                CuestionarioTitularMancomunado.Columns.Add("chkSiPregunta8");
                CuestionarioTitularMancomunado.Columns.Add("chkSiPregunta9");
                CuestionarioTitularMancomunado.Columns.Add("chkSiPregunta10");
                CuestionarioTitularMancomunado.Columns.Add("chkSiPregunta11");
                CuestionarioTitularMancomunado.Columns.Add("chkSiPregunta12");
                CuestionarioTitularMancomunado.Columns.Add("Nombre");
                //CuestionarioTitularMancomunado.Columns.Add("ingreso_mensual");
                //CuestionarioTitularMancomunado.Columns.Add("cargo_publico");

                Session["CuestionarioTitularMancomunado"] = CuestionarioTitularMancomunado;
            }
            else
            {
                CuestionarioTitularMancomunado = ((DataTable)Session["CuestionarioTitularMancomunado"]).Copy();
            }

            DataRow objDR = CuestionarioTitularMancomunado.NewRow();
            objDR["TipoPersona"] = TipoPersona;
            objDR["chkCorazonSi"] = chkCorazonSi;
            objDR["chkHipertesionArterialSi"] = chkHipertesionArterialSi;
            objDR["chkCrebroVasculadresSI"] = chkCrebroVasculadresSI;
            objDR["chkPsiquiatricasNerviosasSi"] = chkPsiquiatricasNerviosasSi;
            objDR["chkEndocrinasSI"] = chkEndocrinasSI;
            objDR["chkInsuficienciaRenalSi"] = chkInsuficienciaRenalSi;
            objDR["chkSangreSi"] = chkSangreSi;
            objDR["chkCirrosisHeptitisSi"] = chkCirrosisHeptitisSi;
            objDR["chkPulmonaresRespiratoriasSi"] = chkPulmonaresRespiratoriasSi;
            objDR["chkConsumoDrogasSI"] = chkConsumoDrogasSI;
            objDR["chkSidaSI"] = chkSidaSI;
            objDR["chkArtritisSI"] = chkArtritisSI;
            objDR["chkAparatoDigestivoSi"] = chkAparatoDigestivoSi;
            objDR["chkSiPregunta1"] = chkSiPregunta1;
            objDR["chkSiPregunta2"] = chkSiPregunta2;
            objDR["chkSiPregunta3"] = chkSiPregunta3;
            objDR["chkSiPregunta4"] = chkSiPregunta4;
            objDR["chkSiPregunta5"] = chkSiPregunta5;
            objDR["chkSiPregunta5_1"] = chkSiPregunta5_1;
            objDR["chkSiPregunta6"] = chkSiPregunta6;
            objDR["chkSiPregunta7"] = chkSiPregunta7;
            objDR["chkSiPregunta8"] = chkSiPregunta8;
            objDR["chkSiPregunta9"] = chkSiPregunta9;
            objDR["chkSiPregunta10"] = chkSiPregunta10;
            objDR["chkSiPregunta11"] = chkSiPregunta11;
            objDR["chkSiPregunta12"] = chkSiPregunta12;
            objDR["Nombre"] = Nombre;
            CuestionarioTitularMancomunado.Rows.Add(objDR);
            Session["CuestionarioTitularMancomunado"] = CuestionarioTitularMancomunado;
            return CuestionarioTitularMancomunado;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
            //return asegurados;
        }
    }


    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable AgregaAsegurado(string parentesco, string nombre, string apellidoPaterno, string apellidoMaterno, string numRiesgo,
        string edad, string Ocupacion, string Peso, string Estatura, string cod_parent, string cod_docum, string fec_nac, string sexo,
        string fuma, string Ingreso_Mensual, string CargoPublico)
    {
        DataTable asegurados;

        try
        {
            if (Session["Asegurados"] == null)
            {
                asegurados = new DataTable();

                asegurados.Columns.Add("parentesco");
                asegurados.Columns.Add("nombre");
                asegurados.Columns.Add("paterno");
                asegurados.Columns.Add("materno");
                asegurados.Columns.Add("num_riesgo");
                asegurados.Columns.Add("edad");
                asegurados.Columns.Add("ocupacion");
                asegurados.Columns.Add("peso");
                asegurados.Columns.Add("estatura");
                asegurados.Columns.Add("cod_parent");
                asegurados.Columns.Add("cod_docum");
                asegurados.Columns.Add("fec_nac");
                asegurados.Columns.Add("sexo");
                asegurados.Columns.Add("fuma");
                asegurados.Columns.Add("ingreso_mensual");
                asegurados.Columns.Add("cargo_publico");

                Session["Asegurados"] = asegurados;
            }
            else
            {
                asegurados = ((DataTable)Session["Asegurados"]).Copy();
            }

            DataRow objDR = asegurados.NewRow();
            objDR["parentesco"] = parentesco;
            objDR["nombre"] = nombre;
            objDR["paterno"] = apellidoPaterno;
            objDR["materno"] = apellidoMaterno;
            objDR["num_riesgo"] = numRiesgo;
            objDR["edad"] = edad;
            objDR["ocupacion"] = Ocupacion;
            objDR["peso"] = Peso;
            objDR["estatura"] = Estatura;
            objDR["cod_parent"] = cod_parent;
            objDR["cod_docum"] = cod_docum;
            objDR["fec_nac"] = fec_nac;
            objDR["sexo"] = sexo;
            objDR["fuma"] = fuma;
            objDR["ingreso_mensual"] = Ingreso_Mensual;
            objDR["cargo_publico"] = CargoPublico;
            asegurados.Rows.Add(objDR);
            Session["Asegurados"] = asegurados;
            return asegurados;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
            //return asegurados;
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable setCoberturas(string cobertura, string cantidad, string asegurado, string parentesco)
    {
        DataTable coberturas;
        if (Session["coberturas"] == null)
        {
            coberturas = new DataTable();
            coberturas.Columns.Add("cobertura");
            coberturas.Columns.Add("cantidad");
            coberturas.Columns.Add("asegurado");
            coberturas.Columns.Add("parentesco");
        }
        else
        {
            coberturas = ((DataTable)Session["coberturas"]).Copy();

        }

        DataRow objDR = coberturas.NewRow();
        objDR["cobertura"] = cobertura;
        objDR["cantidad"] = cantidad;
        objDR["asegurado"] = asegurado;
        objDR["parentesco"] = parentesco;

        coberturas.Rows.Add(objDR);


        Session["coberturas"] = coberturas;
        return coberturas;


    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void setEdad(int edad)
    {

        Session["EDAD"] = edad;



    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void setOperacion(String operacion)
    {

        Session["OPERACION"] = operacion;



    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void setDuracion(int duracion)
    {

        Session["DURACION"] = duracion;


    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void setFecha(String fecha)
    {

        Session["FECHA"] = fecha;



    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public int setPorcentaje6()
    {
        int porcentaje = 0;
        try
        {
            porcentaje = Convert.ToInt32(HttpContext.Current.Session["6"]);
        }
        catch
        {
            porcentaje = 0;
        }


        return porcentaje;

    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public int setm_Tip_Benef()
    {
        int porcentaje = 0;
        try
        {
            porcentaje = Convert.ToInt32(HttpContext.Current.Session["m_Tip_Benef"]);
        }
        catch
        {
            porcentaje = 0;
        }


        return porcentaje;

    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void setModalidad(String modalidad)
    {

        Session["MODALIDAD"] = modalidad;



    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void setAgente(String agente)
    {

        Session["AGENTE"] = agente;



    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void setPRIMA(string prima)
    {

        Session["PRIMATOTAL"] = Convert.ToDouble(prima);



    }


    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public bool ComparaEdad(int edad)
    {
        if (Convert.ToInt32(Session["EDAD"]) > edad)
        {
            return false;
        }
        else
        {
            return true;
        }

    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string getfactorconv(string primatotal)
    {
        decimal valor;
        string valorfinal;
        try
        {
            string factorConversion = recuperasession("factorConv");
            valor = Convert.ToDecimal(primatotal) * Convert.ToDecimal(factorConversion);

            string[] arreglovalor;
            arreglovalor = valor.ToString().Split('.');
            valorfinal = arreglovalor[0] + "." + arreglovalor[1].Substring(0, 2);

            setSession("TotalConv", valorfinal.ToString());
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }

        return Convert.ToString(valorfinal);

    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataTable ObtenBeneficiariosULIND(string contrato, string modalidad)
    {
        Catalogos objCatalogos = new Catalogos();
        DataTable dt = new DataTable();
        DataTable dtfinal = new DataTable();
        DataRow[] foundrowselimina;
        DataRow dtadd;

        string beneficiariosadd = WebUtils.getAppSetting("tiposbenefULAgrego").ToString();
        string beneficiariosdelete = WebUtils.getAppSetting("tiposbenefULElimino").ToString();

        try
        {
            dt = objCatalogos.getTipoBeneficiario();
            string[] beneficiarioagrego = beneficiariosadd.Split('|');

            if (dt.Rows.Count > 0)
            {
                dtfinal = dt.Clone();
                foundrowselimina = dt.Select("NOM_VALOR LIKE '%" + beneficiariosdelete.Split('|')[0] + "%' ");
                if (foundrowselimina != null)
                {
                    dt.Rows.Remove(foundrowselimina[0]);
                }

                foreach (DataRow dr in dt.Rows)
                {
                    dtfinal.ImportRow(dr);
                }
                dtadd = dtfinal.NewRow();
                dtadd["COD_VALOR"] = beneficiarioagrego[0];
                dtadd["NOM_VALOR"] = beneficiarioagrego[1];
                dtfinal.Rows.Add(dtadd);
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return dtfinal;
    }
    //C22{
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public String getModalidadContigo(string cod_prod)
    {
        String[] contratos;
        String[] parametro;
        string modalidad = "";
        switch (cod_prod)
        {
            case "1":
                contratos = (ConfigurationManager.AppSettings["Cont_Inv_Port17_pesos"].ToString()).Split('|');
                parametro = contratos[0].Split(',');
                modalidad = parametro[1];
                break;
            case "2":
                contratos = (ConfigurationManager.AppSettings["Cont_jub_Port17_pesos"].ToString()).Split('|');
                parametro = contratos[0].Split(',');
                modalidad = parametro[1];

                break;
            case "3":
                contratos = (ConfigurationManager.AppSettings["Cont_ppr_Port17_pesos"].ToString()).Split('|');
                parametro = contratos[0].Split(',');
                modalidad = parametro[1];

                break;
        }
        return modalidad;
    }
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string validaSumAsegBaContigo(string SumAseg, string cod_cob, string moneda)
    {
        string mensaje = "";
        string SABasicaP = ConfigurationManager.AppSettings["SaMaxpesos_11217_cob_1000"].ToString();
        string SABasicaD = ConfigurationManager.AppSettings["SaMaxdolar_11217_cob_1000"].ToString();
        string minsa = WebUtils.getAppSetting("min_sa_ulind").ToString();
        string minsadol = WebUtils.getAppSetting("min_sa_ulinddol").ToString();
        switch (moneda)
        {
            case "1":
                if (Convert.ToInt32(SumAseg) > Convert.ToInt32(SABasicaP))
                    mensaje = "La suma asegurada máxima es de: " + SABasicaP;
                if (Convert.ToInt32(SumAseg) < Convert.ToInt32(minsa))
                    mensaje = "La suma asegurada mínima es de: " + minsa;
                break;
            case "2":
                if (Convert.ToInt32(SumAseg) > Convert.ToInt32(SABasicaD))
                    mensaje = "La suma asegurada máxima es de: " + SABasicaD;
                if (Convert.ToInt32(SumAseg) < Convert.ToInt32(minsadol))
                    mensaje = "La suma asegurada mínima es de: " + minsadol;
                break;
        }
        return mensaje;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string validaSumAsegBaContigo2(string SumAseg, string cod_cob, string moneda)
    {

        string mensaje = "";
        string SABasicaP = ConfigurationManager.AppSettings["SaMaxpesos_11217_cob_1000"].ToString();
        string SABasicaD = ConfigurationManager.AppSettings["SaMaxdolar_11217_cob_1000"].ToString();
        string minsa = "30000";
        string minsadol = WebUtils.getAppSetting("min_sa_ulinddol").ToString();
        switch (moneda)
        {
            case "1":
                if (Convert.ToInt32(SumAseg) > Convert.ToInt32(SABasicaP))
                    mensaje = "La suma asegurada máxima es de: " + SABasicaP;
                if (Convert.ToInt32(SumAseg) < Convert.ToInt32(minsa))
                    mensaje = "La suma asegurada mínima es de: " + minsa;
                break;
            case "2":
                if (Convert.ToInt32(SumAseg) > Convert.ToInt32(SABasicaD))
                    mensaje = "La suma asegurada máxima es de: " + SABasicaD;
                if (Convert.ToInt32(SumAseg) < Convert.ToInt32(minsadol))
                    mensaje = "La suma asegurada mínima es de: " + minsadol;
                break;
        }
        return mensaje;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string validaSumAsegCOContigo(string SumAsegBa, string cod_cob, string SumasegCob, string Moneda)
    {
        string mensaje = "";
        string minsa = WebUtils.getAppSetting("min_sa_ulind").ToString();
        string minsadol = WebUtils.getAppSetting("min_sa_ulinddol").ToString();
        if (SumasegCob.Trim() == "")
            mensaje = "El monto de la suma asegurada no puede ser nulo.";
        else
        {
            if (Convert.ToInt32(SumAsegBa) < Convert.ToInt32(SumasegCob))
                mensaje = "La suma asegurada máxima es de: " + SumAsegBa;
            switch (Moneda)
            {
                case "1":
                    if (Convert.ToInt32(SumasegCob) < Convert.ToInt32(minsa))
                        mensaje = "La suma asegurada mínima es de: " + minsa;
                    break;
                case "2":
                    if (Convert.ToInt32(SumasegCob) < Convert.ToInt32(minsadol))
                        mensaje = "La suma asegurada mínima es de: " + minsadol;
                    break;
            }
        }

        return mensaje;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public int ValidaCantMax(string ramo, string modalidad, int moneda, int edad)
    {
        int sumaHasta = 0;
        foreach (string codRamo in ConfigurationManager.AppSettings["Ramos"].ToString().Split(','))
        {
            if (ramo == codRamo)
            {
                foreach (string codModalidad in ConfigurationManager.AppSettings["Modalidad" + ramo].ToString().Split(','))
                {
                    if (modalidad == ConfigurationManager.AppSettings["Modalidad1003"].ToString())
                    {
                        if (edad > 12 && edad < 61)
                        {
                            switch (moneda)
                            {
                                case 1:
                                    sumaHasta = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMax10003"].ToString().Split(',')[0]);
                                    break;
                            }
                        }
                        else if (edad > 61)
                        {
                            switch (moneda)
                            {
                                case 1:
                                    sumaHasta = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMax10003"].ToString().Split(',')[1]);
                                    break;
                            }
                        }
                        break;
                    }
                    else if (modalidad == codModalidad)
                    {

                        //if (edad > 12 && edad < 61)
                        if (edad >= 18 && edad <= 50)
                        {
                            switch (moneda)
                            {
                                case 1:
                                    sumaHasta = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMax" + ramo].ToString().Split('|')[0].Split(',')[0]);
                                    break;
                                case 2:
                                    sumaHasta = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMax" + ramo].ToString().Split('|')[0].Split(',')[1]);
                                    break;
                                case 6:
                                    sumaHasta = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMax" + ramo].ToString().Split('|')[0].Split(',')[2]);
                                    break;
                            }
                        }
                        else
                        {
                            //if (edad > 61)
                            if (edad >= 51 && edad <= 65)
                            {
                                switch (moneda)
                                {
                                    case 1:
                                        sumaHasta = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMax" + ramo].ToString().Split('|')[1].Split(',')[0]);
                                        break;
                                    case 2:
                                        sumaHasta = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMax" + ramo].ToString().Split('|')[1].Split(',')[1]);
                                        break;
                                    case 6:
                                        sumaHasta = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMax" + ramo].ToString().Split('|')[1].Split(',')[2]);
                                        break;
                                }
                            }


                            if (edad >= 66 && edad <= 70)
                            {
                                switch (moneda)
                                {
                                    case 1:
                                        sumaHasta = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMax" + ramo].ToString().Split('|')[2].Split(',')[0]);
                                        break;
                                    case 2:
                                        sumaHasta = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMax" + ramo].ToString().Split('|')[2].Split(',')[1]);
                                        break;
                                    case 6:
                                        sumaHasta = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMax" + ramo].ToString().Split('|')[2].Split(',')[2]);
                                        break;
                                }
                            }

                        }
                        break;
                    }

                }
                break;
            }
        }
        return sumaHasta;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public int ValidaCantMaxULInd(string ramo, int moneda, int edad)
    {
        int sumaHasta = 0;
        foreach (string codRamo in ConfigurationManager.AppSettings["Ramos"].ToString().Split(','))
        {
            if (ramo == codRamo)
            {
                if (edad > 12 && edad < 61)
                {
                    switch (moneda)
                    {
                        case 1:
                            sumaHasta = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMax" + ramo].ToString().Split('|')[0].Split(',')[0]);
                            break;
                        case 2:
                            sumaHasta = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMax" + ramo].ToString().Split('|')[0].Split(',')[1]);
                            break;
                        case 6:
                            sumaHasta = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMax" + ramo].ToString().Split('|')[0].Split(',')[2]);
                            break;
                    }
                }
                else
                {
                    if (edad > 61)
                    {
                        switch (moneda)
                        {
                            case 1:
                                sumaHasta = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMax" + ramo].ToString().Split('|')[1].Split(',')[0]);
                                break;
                            case 2:
                                sumaHasta = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMax" + ramo].ToString().Split('|')[1].Split(',')[1]);
                                break;
                            case 6:
                                sumaHasta = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMax" + ramo].ToString().Split('|')[1].Split(',')[2]);
                                break;
                        }
                    }
                }
                break;


            }
        }
        return sumaHasta;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public int ValidaBtNAdjunta2(int moneda)
    {
        int activaDivAdjunta2 = 0;
        switch (moneda)
        {
            case 1:
                activaDivAdjunta2 = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMaxBTN"].ToString().Split(',')[0]);
                break;
            case 2:
                activaDivAdjunta2 = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMaxBTN"].ToString().Split(',')[1]);
                break;
            case 6:
                activaDivAdjunta2 = Convert.ToInt32(ConfigurationManager.AppSettings["MontoMaxBTN"].ToString().Split(',')[2]);
                break;
        }
        return activaDivAdjunta2;
    }
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string getPlazoUL(string ramo, string modalidad, string contrato, string duracion, string edad)
    {
        string mensaje = "";
        try
        {
            DataSet objds = new DataSet();
            MCommand cmd = new MCommand();
            string plazo;
            Int32 dura;
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = ConfigurationManager.AppSettings["EsquemaVida"].ToString() + ".p_recupera_config_web";
                cmd.agregarINParametro("p_cod_aplicacion", OracleDbType.Varchar2, "ZAEMISIONGENERAL");
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, Convert.ToInt32(ramo));
                cmd.agregarINParametro("p_num_poliza_grupo", OracleDbType.Varchar2, "ZTODAS");
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Int32, Convert.ToInt32(contrato));
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Int32, Convert.ToInt32(modalidad));
                cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, 99);
                cmd.agregarINParametro("p_cod_campo", OracleDbType.Varchar2, "VAL_PLAZO");
                cmd.agregarOUTParametro("p_val_campo", OracleDbType.Varchar2, 80);

                objds = cmd.ejecutarRefCursorSP();
                plazo = objds.Tables[0].Rows[0]["p_val_campo"].ToString();
            }
            if (contrato == "11228")
            {
                plazo = "5";
            }
            if (contrato == "11229")
            {
                plazo = "5";
            }
            dura = Convert.ToInt32(duracion) - Convert.ToInt32(edad);
            if (dura < Convert.ToInt32(plazo))
            {
                mensaje = "El plazo para este producto no puede ser menor de " + plazo;
                return mensaje;
            }
            setSession("duration", dura.ToString());
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error MetodosAjax.getPlazoUL(): " + ex);
        }

        return mensaje;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public bool ValidaSAAnexo(string sumaAsegurada, string drpMoneda)
    {
        bool res = false;
        switch (drpMoneda)
        {
            case "1":
                if (Convert.ToDouble(sumaAsegurada) > 1500000)
                { res = true; }
                break;
            case "2":
                if ((Convert.ToDouble(sumaAsegurada) * Convert.ToDouble(Session["tipoCambioUSD"])) > 1500000)
                { res = true; }
                break;
            case "6":
                if ((Convert.ToDouble(sumaAsegurada) * Convert.ToDouble(Session["tipoCambioUDIS"])) > 1500000)
                { res = true; }
                break;
        }
        return res;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string EnviaFirma(string numCotizacion, string nomContratante, string nomAsegurado, string agente, string ramo, string mailContratante, string mailAsegurado, string mailAgente, string fecNacAseg)
    {
        string resultado = "";
        bool resDb = false;
        DateTime dateValue = DateTime.ParseExact(fecNacAseg, "dd/MM/yyyy", CultureInfo.InvariantCulture);
        string formattedfecNacAseg = dateValue.ToString("ddMMyyyy");
        try
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Evento boton envia Firma");
            FirmaDigital firma = new FirmaDigital();
            string strService = firma.EnviaFirma(numCotizacion, nomContratante, nomAsegurado, agente, ramo, mailContratante, mailAsegurado, mailAgente, formattedfecNacAseg);
            if (strService.Length > 2)
            {

                resDb = InsertaDatos("1", ramo, strService.Split('|')[0], strService.Split('|')[1], numCotizacion, nomContratante.Replace("|", " "), nomAsegurado.Replace("|", " "), DateTime.Today.ToString("ddMMyyyy"), agente, Session["XMLEmisionFirma"].ToString(), "PENDIENTE DE FIRMA", DateTime.Today.ToString("ddMMyyyy"), DateTime.Today.AddYears(1).ToString("ddMMyyyy"));
            }
            if (resDb)
            {
                resultado = numCotizacion + "|" + strService.Split('|')[1];
                DeleteFile(numCotizacion);
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error evento boton Firma: " + ex.Message);
        }
        return resultado;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string EnviaFirma105(string numCotizacion, string nomContratante, string nomAsegurado, string nomAseguradoMancomunado, string agente, string ramo, string mailContratante, string mailAsegurado, string mailAseguradoMancomunado, string mailAgente)
    {
        string resultado = "";
        bool resDb = false;
        try
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Evento boton envia Firma");
            FirmaDigital firma = new FirmaDigital();
            string strService = firma.EnviaFirma105(numCotizacion, nomContratante, nomAsegurado, nomAseguradoMancomunado, agente, ramo, mailContratante, mailAsegurado, mailAseguradoMancomunado, mailAgente);
            if (strService.Length > 2)
            {
                resDb = InsertaDatos("1", ramo, strService.Split('|')[0], strService.Split('|')[1], numCotizacion, nomContratante, nomAsegurado, DateTime.Today.ToString("ddMMyyyy"), agente, Session["XMLEmisionFirma"].ToString(), "PENDIENTE DE FIRMA", DateTime.Today.ToString("ddMMyyyy"), DateTime.Today.AddYears(1).ToString("ddMMyyyy"));
                if (nomAseguradoMancomunado != "" && mailAseguradoMancomunado != "")
                {
                    resDb = InsertaDatos("1", ramo, strService.Split('|')[0], strService.Split('|')[1], numCotizacion, nomContratante, nomAseguradoMancomunado, DateTime.Today.ToString("ddMMyyyy"), agente, Session["XMLEmisionFirma"].ToString(), "PENDIENTE DE FIRMA", DateTime.Today.ToString("ddMMyyyy"), DateTime.Today.AddYears(1).ToString("ddMMyyyy"));
                }
            }
            if (resDb)
            {
                resultado = numCotizacion + "|" + strService.Split('|')[1];
                DeleteFile(numCotizacion);
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error evento boton Firma: " + ex.Message);
        }
        return resultado;
    }

    public bool InsertaDatos(string cod_cia, string cod_ramo, string id_transaccion, string num_folio, string num_poliza,
        string nom_contratante, string nom_aseg, string fec_ini_tramite, string cod_agt, string txt_solicitud, string txt_estatus,
        string fec_efec, string fec_vcto)
    {
        MCommand cmd = new MCommand();
        bool resp = false;
        DataRow dr;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "tron2000.em_k_gen_firma_digital_mmx.p_inserta";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, Convert.ToInt32(cod_cia));
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, Convert.ToInt32(cod_ramo));
                cmd.agregarINParametro("p_id_transaccion", OracleDbType.Varchar2, id_transaccion);
                cmd.agregarINParametro("p_num_folio", OracleDbType.Varchar2, num_folio);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, num_poliza);
                cmd.agregarINParametro("p_nom_contratante", OracleDbType.Varchar2, nom_contratante);
                cmd.agregarINParametro("p_nom_aseg", OracleDbType.Varchar2, nom_aseg);
                cmd.agregarINParametro("p_fec_ini_tramite", OracleDbType.Varchar2, fec_ini_tramite);
                cmd.agregarINParametro("p_cod_agt", OracleDbType.Int32, cod_agt);
                cmd.agregarINParametro("p_txt_solicitud", OracleDbType.Clob, txt_solicitud);
                cmd.agregarINParametro("p_txt_estatus", OracleDbType.Varchar2, txt_estatus);
                cmd.agregarINParametro("p_fec_efec_poliza", OracleDbType.Varchar2, fec_efec);
                cmd.agregarINParametro("p_fec_vcto_poliza", OracleDbType.Varchar2, fec_vcto);

                dr = cmd.ejecutarRegistroSP();
                resp = true;

            }
        }
        catch (Exception ex)
        {
            resp = false;
            MapfreMMX.util.MLogFile.getInstance().writeText("Error EnviarFirmaElectronica.InsertaDatos():  " + ex.Message);
            throw new Exception("Error EnviarFirmaElectronica.InsertaDatos():  " + ex.Message);
        }
        return resp;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string getValSession(string nomsession)
    {
        string sesion = "";

        sesion = Session[nomsession].ToString();
        if (sesion != "")
        {
            return sesion;
        }
        else
        {
            sesion = "";
            return sesion;
        }
    }

    public void DeleteFile(string FileName)
    {
        if (File.Exists("C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Firma\\sv_" + FileName + ".pdf"))
            File.Delete("C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Firma\\sv_" + FileName + ".pdf");

        if (File.Exists("C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Firma\\cer_" + FileName + ".pdf"))
            File.Delete("C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Firma\\cer_" + FileName + ".pdf");

        if (File.Exists("C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Firma\\cSA_" + FileName + ".pdf"))
            File.Delete("C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Firma\\cSA_" + FileName + ".pdf");

        if (File.Exists("C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Firma\\" + FileName + ".pdf"))
            File.Delete("C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Firma\\" + FileName + ".pdf");

        //DateTime hoy = DateTime.Today;
        //string[] ficherosCarpeta = Directory.GetFiles(@"C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Firma\\");
        //foreach (string archivo in ficherosCarpeta)
        //{
        //    DateTime dtFile = File.GetLastWriteTime(archivo);
        //    double totalDays = (hoy - dtFile).TotalDays;
        //    if (totalDays > 1)
        //    {
        //        File.Delete(archivo);
        //    }
        //}
    }
    //C26{
    public string obtenXmlHpExstream(string num_poliza)
    {
        MCommand cmd = new MCommand();
        DataRow dr = null;
        try
        {
            using (OracleConnection cnn = MConexion.getConexion("ConnectionTW"))
            {

                cmd.Connection = cnn;

                cmd.CommandText = "TRON2000.EM_K_IMP_GRAL_MMX.p_imprime_poliza";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Decimal, 1);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, num_poliza);
                cmd.agregarINParametro("p_num_spto", OracleDbType.Decimal, 0);
                cmd.agregarINParametro("p_tip_emision", OracleDbType.Varchar2, "P");
                cmd.agregarOUTParametro("p_xml", OracleDbType.Clob, 32000);
                cmd.agregarOUTParametro("p_error", OracleDbType.Varchar2, 500);

                dr = cmd.ejecutarRegistroSP();

                if (!string.IsNullOrEmpty(Convert.ToString(dr["p_error"])))
                    return "Error:  " + Convert.ToString(dr["p_error"]);
                else
                    return Convert.ToString(dr["p_xml"]);
            }
        }
        catch (Exception ex)
        {
            throw new Exception("MetodosAjax.obtenXmlHpExstream(" + num_poliza + ") : " + ex.Message);
        }
    }
    public void CreaPDFHPExstream(string num_poliza)
    {
        String xmlHPExstream = obtenXmlHpExstream(num_poliza);
        if (!xmlHPExstream.Contains("Error:"))
        {
            byte[] byt = System.Text.Encoding.UTF8.GetBytes(xmlHPExstream);
            xmlHPExstream = Convert.ToBase64String(byt);

            string userHPExstream = ConfigurationManager.AppSettings["UserHp"];
            string paswHPExstream = ConfigurationManager.AppSettings["PassHp"];
            string sPubFile = ConfigurationManager.AppSettings["PubFilePolVida"];
            string emisionSector = ConfigurationManager.AppSettings["ProductosHP"];

            HttpWebRequest request = CreateWebRequest();
            XmlDocument soapEnvelopeXml = new XmlDocument();

            soapEnvelopeXml.LoadXml(@"<soapenv:Envelope xmlns:eng=""urn:hpexstream-services/Engine"" xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"">
                                                               <soapenv:Header>
                                                                  <wsse:Security soapenv:mustUnderstand=""0"" xmlns:wsse=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"" xmlns:wsu=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"">
                                                                     <wsse:UsernameToken wsu:Id=""UsernameToken-1"">
                                                                        <wsse:Username>" + userHPExstream + @"</wsse:Username>
                                                                        <wsse:Password Type=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText"">" + paswHPExstream + @"</wsse:Password>
                                                                        <wsse:Nonce EncodingType=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary"">9XbhOoet06M5XXD83sgM7Q==</wsse:Nonce>
                                                                        <wsu:Created>2015-07-21T08:23:30.207Z</wsu:Created>
                                                                     </wsse:UsernameToken>
                                                                  </wsse:Security>
                                                               </soapenv:Header>
                                                               <soapenv:Body>
                                                                  <eng:Compose>
                                                                     <EWSComposeRequest>
                                                                        <driver>
                                                                           <!--Fichero de datos en Base64-->
                                                                           <driver>" + xmlHPExstream + @"</driver>
                                                                           <fileName>INPUT</fileName>
                                                                        </driver>
                                                                        <engineOptions>
                                                                           <name>IMPORTDIRECTORY</name>
                                                                           <value>/var/opt/exstream/pubs</value>
                                                                        </engineOptions>
                                                                        <engineOptions>
                                                                           <!--Ruta donde se encuentra fichero de referencias-->
                                                                           <!--A su vez, el fichero contiene ruta a recursos-->
                                                                           <name>FILEMAP</name>
                                                                           <value>REFERENCIAS,/var/opt/exstream/pubs/" + emisionSector + @"/REFERENCIAS.ini</value>
                                                                        </engineOptions>
                                                                        <!--Optional:-->
                                                                        <pubFile>" + sPubFile + @"</pubFile>
                                                                     </EWSComposeRequest>
                                                                  </eng:Compose>
                                                               </soapenv:Body>
                                                            </soapenv:Envelope>");

            using (Stream stream = request.GetRequestStream())
            {
                soapEnvelopeXml.Save(stream);
            }

            using (WebResponse response = request.GetResponse())
            {

                using (StreamReader rd = new StreamReader(response.GetResponseStream()))
                {

                    string soapResult = rd.ReadToEnd();
                    string sFileOutput;
                    int iCadenaIni = soapResult.IndexOf("<fileOutput>") + 12;
                    int iCadenaFin = soapResult.IndexOf("</fileOutput>");

                    sFileOutput = soapResult.Substring(iCadenaIni, (iCadenaFin - iCadenaIni));

                    string RutaImp = ConfigurationManager.AppSettings["RutaImpresionArchivo"];

                    //genera el pdf en base a la cadena de 64 bits
                    // WriteByteArrayToPdf(sFileOutput, RutaImp, num_poliza + ".pdf");
                }
            }
        }
    }
    public HttpWebRequest CreateWebRequest()
    {
        string RutaURL = ConfigurationManager.AppSettings["URLWSHpExtream"];
        HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(RutaURL);
        webRequest.Headers.Add(@"SOAP:Action");
        webRequest.ContentType = "text/xml;charset=\"utf-8\"";
        webRequest.Accept = "text/xml";
        webRequest.Method = "POST";
        return webRequest;
    }
    public void WriteByteArrayToPdf(string inPDFByteArrayStream, string pdflocation, string fileName)
    {

        byte[] data = Convert.FromBase64String(inPDFByteArrayStream);

        if (Directory.Exists(pdflocation))
        {
            pdflocation = pdflocation + fileName;

            using (FileStream Writer = new System.IO.FileStream(pdflocation, FileMode.Create, FileAccess.Write))
            {
                Writer.Write(data, 0, data.Length);
            }
        }
        else
        {
            throw new System.Exception("PDF Shared Location not found");
        }
    }
    //}C26
    /// <summary>
    /// 20230822: Mejoras Firma Digital Vida
    /// Método para insertar los correos a la tabla de gestión de correos de firma digital.
    /// </summary>
    /// <param name="numCotizacion">Número de cotización</param>
    /// <param name="transaccion">Transacción</param>
    /// <param name="folio">Folio</param>
    /// <param name="ramo">Ramo</param>
    /// <param name="mailContratante">Correo del contratante</param>
    /// <param name="mailAsegurado">Correo del asegurado</param>
    /// <param name="mailAgente">Correo del agente</param>
    /// <param name="telefono">Telefono del agente</param>
    /// <param name="PDFBase64">Archivo PDF en base 64</param>
    /// <param name="editado">Indica si el registro es editable o no, para la recuperacion de correos.</param>
    /// <returns></returns>
    public bool insertarCorreos(string numCotizacion, string transaccion, string folio, string ramo, string mailContratante, string mailAsegurado, string mailAgente, string telefono, string PDFBase64, string editado)
    {
        MCommand cmd = new MCommand();
        bool resp = false;
        DataRow dr;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "tron2000.em_k_gen_firma_digital_mmx.p_inserta_correos";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, Convert.ToInt32(1));
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, Convert.ToInt32(ramo));
                cmd.agregarINParametro("p_id_transaccion", OracleDbType.Varchar2, transaccion);
                cmd.agregarINParametro("p_num_folio", OracleDbType.Varchar2, folio);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, numCotizacion);
                cmd.agregarINParametro("p_mail_contratante", OracleDbType.Varchar2, mailContratante);
                cmd.agregarINParametro("p_mail_asegurado", OracleDbType.Varchar2, mailAsegurado);
                cmd.agregarINParametro("p_mail_agente", OracleDbType.Varchar2, mailAgente);
                cmd.agregarINParametro("p_editado", OracleDbType.Varchar2, editado);
                cmd.agregarINParametro("p_telefono", OracleDbType.Varchar2, telefono);
                cmd.agregarINParametro("p_PDFBase64", OracleDbType.Clob, PDFBase64);


                dr = cmd.ejecutarRegistroSP();
                resp = true;

            }
        }
        catch (Exception ex)
        {
            resp = false;
            {
                throw new Exception("Error MetodosAjax.insertarCorreos():  " + ex.Message);
                MapfreMMX.util.MLogFile.getInstance().writeText("Error MetodosAjax.insertarCorreos():  " + ex.Message);
            }
        }
        return resp;
    }
    /// <summary>
    /// 20230822: Mejoras Firma Digital Vida
    /// Método para editar los correos a la tabla de gestión de correos de firma digital.
    /// </summary>
    /// <param name="numCotizacion">Número de cotización</param>
    /// <param name="transaccion">Transacción</param>
    /// <param name="folio">Folio</param>
    /// <param name="ramo">Ramo</param>
    /// <param name="mailContratante">Correo del contratante</param>
    /// <param name="mailAsegurado">Correo del asegurado</param>
    /// <param name="mailAgente">Correo del agente</param>
    /// <returns></returns>
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public bool editarCorreos(string numCotizacion, string transaccion, string folio, string mailContratante, string mailAsegurado, string mailAgente)
    {
        MCommand cmd = new MCommand();
        bool resp = false;
        DataRow dr;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "tron2000.em_k_gen_firma_digital_mmx.p_edita_correos";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, Convert.ToInt32(1));
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, Convert.ToInt32(100));
                cmd.agregarINParametro("p_id_transaccion", OracleDbType.Varchar2, transaccion);
                cmd.agregarINParametro("p_num_folio", OracleDbType.Varchar2, folio);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, numCotizacion);
                cmd.agregarINParametro("p_mail_contratante", OracleDbType.Varchar2, mailContratante);
                cmd.agregarINParametro("p_mail_asegurado", OracleDbType.Varchar2, mailAsegurado);
                cmd.agregarINParametro("p_mail_agente", OracleDbType.Varchar2, mailAgente);
                cmd.agregarINParametro("p_editado", OracleDbType.Varchar2, "S");


                dr = cmd.ejecutarRegistroSP();
                resp = true;

            }
        }
        catch (Exception ex)
        {
            resp = false;
            {
                throw new Exception("Error MetodosAjax.editarCorreos():  " + ex.Message);
                MapfreMMX.util.MLogFile.getInstance().writeText("Error MetodosAjax.editarCorreos():  " + ex.Message);
            }
        }
        return resp;
    }
    /// <summary>
    /// 20230822: Mejoras Firma Digital Vida
    /// Método para consultar los correos a la tabla de gestión de correos de firma digital.
    /// </summary>
    /// <param name="numCotizacion">Número de cotización</param>
    /// <param name="transaccion">Transacción</param>
    /// <param name="folio">Folio</param>
    /// <returns></returns>
    public DataRow consultaCorreos(string numCotizacion, string transaccion, string folio)
    {
        MCommand cmd = new MCommand();
        DataSet dt = new DataSet();
        DataRow dr;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "tron2000.em_k_gen_firma_digital_mmx.p_consulta_correos";
                cmd.agregarINParametro("p_id_transaccion", OracleDbType.Varchar2, transaccion);
                cmd.agregarINParametro("p_num_folio", OracleDbType.Varchar2, folio);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, numCotizacion);
                cmd.agregarOUTParametro("p_cursor_res", OracleDbType.RefCursor, 0);

                dt = cmd.ejecutarRefCursorSP();
                dr = dt.Tables[0].Rows[0];
            }
        }
        catch (Exception ex)
        {
            throw new Exception("Error MetodosAjax.consultaCorreos():  " + ex.Message);
            MapfreMMX.util.MLogFile.getInstance().writeText("Error MetodosAjax.consultaCorreos():  " + ex.Message);
        }

        return dr;
    }
    public DataRow ConsultaInfoCLM(string _clm)
    {
        using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
        {
            try
            {
                MCommand cmd = new MCommand();
                cmd.Connection = conexion;
                cmd.CommandText = "tron2000.em_k_gen_firma_digital_mmx.p_consulta_info_clm";
                cmd.agregarINParametro("p_clm", OracleDbType.Varchar2, _clm);                
                cmd.agregarOUTParametro("p_cursor_res", OracleDbType.RefCursor, 0);

                DataSet dt = cmd.ejecutarRefCursorSP();

                if (dt.Tables.Count > 0 && dt.Tables[0].Rows.Count > 0)
                {
                    return dt.Tables[0].Rows[0];
                }
                else
                {
                    return null;
                }
            }
            catch (OracleException ex)
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("ERROR MetodosAjax.ConsultaDatosCLM(): " + ex.Message);
                throw new Exception("ERROR MetodosAjax.ConsultaDatosCLM(): " + ex.Message);
            }
        }
    }


    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string EnviaFirmaMod(string numCotizacion, string transaccionAnt, string folioAnt, string mailContratante, string mailAsegurado, string mailAgente, string telefono)
    {
        string resultado = "";
        bool resDb = false;
        try
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Entra a EnviaFirmaMod despues de la edición de correos.");
            FirmaDigital firma = new FirmaDigital();
            //Se envía a proceso de firma con lo nuevos correos.
            string strService = firma.EnviaFirmaMod(numCotizacion, transaccionAnt, folioAnt, mailContratante, mailAsegurado, mailAgente, telefono);
            if (strService.Length > 2)
            {
                string transaccionMod = strService.Split('|')[0];
                string folioMod = strService.Split('|')[1];
                MapfreMMX.util.MLogFile.getInstance().writeText("Enviar a Firma correos nuevos CORRECTO.");
                //Se modifica la solicitud original con la información de la nueva solicitud para darle el seguimiento.
                resDb = actualizarFolio(numCotizacion, transaccionAnt, folioAnt, transaccionMod, folioMod);
                MapfreMMX.util.MLogFile.getInstance().writeText("Actualizar la poliza: " + numCotizacion + " CORRECTO.");
            }

            if (resDb)
            {
                resultado = numCotizacion + "|" + strService.Split('|')[0] + "|" + strService.Split('|')[1] + "|true" + "|" + ConfigurationManager.AppSettings["URLGestion2008EstatusFirma"].ToString();
                MapfreMMX.util.MLogFile.getInstance().writeText("Actualizar gestion2008 con los siguientes parametros: ");
                MapfreMMX.util.MLogFile.getInstance().writeText("Solicitud: " + numCotizacion);
                MapfreMMX.util.MLogFile.getInstance().writeText("transaccion: " + strService.Split('|')[0]);
                MapfreMMX.util.MLogFile.getInstance().writeText("folio: " + strService.Split('|')[1]);
                MapfreMMX.util.MLogFile.getInstance().writeText("Correcto: true");
                MapfreMMX.util.MLogFile.getInstance().writeText("URLGestion2008EstatusFirma: " + ConfigurationManager.AppSettings["URLGestion2008EstatusFirma"].ToString());
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error evento boton Firma: " + ex.Message);
        }

        return resultado;
    }
    public bool actualizarFolio(string numCotizacion, string transaccionAnt, string folioAnt, string transaccionMod, string folioMod)
    {
        MCommand cmd = new MCommand();
        bool resp = false;
        DataRow dr;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "tron2000.em_k_gen_firma_digital_mmx.p_actualiza_solicitud";
                cmd.agregarINParametro("p_id_transaccion", OracleDbType.Varchar2, transaccionAnt);
                cmd.agregarINParametro("p_num_folio", OracleDbType.Varchar2, folioAnt);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, numCotizacion);
                cmd.agregarINParametro("p_id_transaccionMod", OracleDbType.Varchar2, transaccionMod);
                cmd.agregarINParametro("p_num_folioAntMod", OracleDbType.Varchar2, folioMod);

                dr = cmd.ejecutarRegistroSP();
                resp = true;
            }
        }
        catch (Exception ex)
        {
            resp = false;
            {
                throw new Exception("Error MetodosAjax.actualizarFolio():  " + ex.Message);
                MapfreMMX.util.MLogFile.getInstance().writeText("Error MetodosAjax.actualizarFolio():  " + ex.Message);
            }
        }
        return resp;
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void BorraSessionAsegurados(string name)
    {
        Session[name] = null;
    }
}