﻿using System;
using System.Data; 
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MapfreMMX.util;
using DocumentumMMX;
using System.Collections;
using System.Collections.Generic;
using System.Xml;

/// <summary>
/// Summary description for EnviarArchivoWM
/// </summary>
public class EnviarArchivoWM
{
	public EnviarArchivoWM()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public string SubirArchivo(string strUsuario, string strFolioWM, string strPathServer, string strNombreArchivo)
    {
        string strMensaje = "";
        try
        {
            ArchivoWM objArchivoWM = new ArchivoWM();
            objArchivoWM.Usuario = strUsuario;
            objArchivoWM.RutaServer = strPathServer;
            objArchivoWM.Nombre = strNombreArchivo;
            objArchivoWM.Cabinet = ConfigurationManager.AppSettings["CabinetWM"].ToString();
            objArchivoWM.FolioWM = strFolioWM;
            objArchivoWM.TipoDocWM = ConfigurationManager.AppSettings["TipoDocWM"].ToString();

            //Se guarda el archivo en el Servidor FTP.
            //GuardaArchivo(objArchivoWM);

            //Se Sube el archivo a Documentum.
            SubeADocumentum(objArchivoWM);

            strMensaje = "Archivo adjuntado satisfactoriamente.";
        }
        catch(Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            strMensaje = "ERROR: No pudo ser adjuntado el archivo, por la siguiente causa: " + ex.Message;
        }
        return strMensaje;
    }

    protected void GuardaArchivo(ArchivoWM objArchivoWM)
    {
        try
        {
            enviaFTP(objArchivoWM.RutaServer + objArchivoWM.Nombre);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    protected void SubeADocumentum(ArchivoWM objArchivoWM)
    {
        try
        {
            Hashtable Attribute = new Hashtable();
            Attribute.Add("num_folio", objArchivoWM.FolioWM);
            Attribute.Add("cod_usuario", objArchivoWM.Usuario);
            
            ValCertificacion();
            
            string strIDDoc = UtilDocumentum.ImportarDocumento(objArchivoWM, Attribute);
            //Se borra el archivo en el Servidor de la aplicación.
            BorrarArchivos(objArchivoWM);

            if (strIDDoc.ToUpper().StartsWith("ERROR"))
                throw new Exception(strIDDoc);
            
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    protected void BorrarArchivos(ArchivoWM objArchivoWM)
    {
        try
        {
            //Se borra el archivo en el Servidor de la Aplicación.
            eliminaArchivoAplicacion(objArchivoWM);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    // APL -- Nueva forma de conexion FTPS
    protected void enviaFTP(string filePath)
    {
        try
        {
            Mapfre.Ftp.FTPClient ftp = new Mapfre.Ftp.FTPClient(WebUtils.getAppSetting("FTPServerWM"), WebUtils.getAppSetting("UsuarioFTP_WM"), WebUtils.getAppSetting("PassFTP_WM"));
            ftp.RemotePath = ConfigurationManager.AppSettings["PathFTP_WM"];
            ftp.Upload(filePath);
            ftp.Close();
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message.ToString());

        }
    }

    protected void eliminaArchivoAplicacion(ArchivoWM objArchivoWM)
    {
        string file = objArchivoWM.RutaServer + objArchivoWM.Nombre;
        try
        {
            System.IO.File.Delete(file);
        }
        catch (Exception ex) 
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
        }
    }

    protected string getXmlAtributos(List<Atributo> objListAtt)
    {
        XmlDocument objXmlDocument = new XmlDocument();

        //Se declara el XmlNode y XmlDeclaration para la Declaración y creación del Nodo raiz "xml"
        XmlNode objXmlNode;
        XmlDeclaration objXmlDeclaration;

        //Se crea la Declaración "<?xml version="1.0" encoding="UTF-8"?>" del documento Xml
        objXmlNode = objXmlDocument.CreateNode(XmlNodeType.XmlDeclaration, string.Empty, string.Empty);
        objXmlDocument.AppendChild(objXmlNode);
        objXmlDeclaration = (XmlDeclaration)objXmlDocument.FirstChild;
        objXmlDeclaration.Encoding = "UTF-8";

        //Se crea el Nodo raiz "xml".
        objXmlNode = objXmlDocument.CreateNode(XmlNodeType.Element, "xml", "");
        objXmlDocument.AppendChild(objXmlNode);

        //Se crean los XmlNode's para la creación de los nodos para la información de los controles.
        XmlNode nodo;
        XmlNode subNodo;

        //Se crea el Nodo "Datos" para agregar los atributos en el nodo "xml".
        nodo = objXmlDocument.CreateNode(XmlNodeType.Element, "Datos", "");
        objXmlDocument.SelectSingleNode("//xml").AppendChild(nodo);

        foreach (Atributo objAtributo in objListAtt)
        {
            subNodo = objXmlDocument.CreateNode(XmlNodeType.Element, objAtributo.NombreAtributo, "");
            subNodo.InnerText = objAtributo.ValorAtributo;
            nodo.AppendChild(subNodo);
        }

        return objXmlDocument.OuterXml;
    }

    protected void ValCertificacion()
    {
        System.Net.ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(ValidateServerCertificate);
    }

    protected static bool ValidateServerCertificate(Object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
    {
        return true;
    }
}

public class ArchivoWM
{
    private string _Usuario;
    private string _Nombre;
    private string _RutaServer;
    private string _Cabinet;
    private string _FolioWM;
    private string _TipoDocWM;

    public string Usuario
    {
        get { return _Usuario; }
        set { _Usuario = value; }
    }
    public string Nombre
    {
        get { return _Nombre; }
        set { _Nombre = value; }
    }
    public string RutaServer
    {
        get { return _RutaServer; }
        set { _RutaServer = value; }
    }
    public string Cabinet
    {
        get { return _Cabinet; }
        set { _Cabinet = value; }
    }
    public string FolioWM
    {
        get { return _FolioWM; }
        set { _FolioWM = value; }
    }
    public string TipoDocWM
    {
        get { return _TipoDocWM; }
        set { _TipoDocWM = value; }
    }
}

public class Atributo
{
    private string _NombreAtributo;
    private string _ValorAtributo;
    public string NombreAtributo
    {
        get { return _NombreAtributo; }
        set { _NombreAtributo = value; }
    }
    public string ValorAtributo
    {
        get { return _ValorAtributo; }
        set { _ValorAtributo = value; }
    }
}