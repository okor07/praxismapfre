﻿//'********************************************************************************************************************
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2010
//'Name of the file              : EmisionGeneralVida.aspx.cs
//'Creation/Modification History :
//'Modification                  : jdgomezc  Indra SWLabs
//                               
//'C2                            : jdgomezc - 30-12-2012
//                                 Corregido nombre de metodo incorrecto que traia  
//                                 los modos de pago y no los tipos de beneficiarios                              
//'C3                            : jdgomezc - 30-12-2012
//                                 Se crea validaPoliticaLavadoDeDinero para segun
//                                 los montos indicados en la tabla XXXX se muestre
//                                 un mensaje al usuario que documentos se deben
//                                 adjuntar segun el monto de prima neta que obtenga 
//'C4                            : jchuertas - 30-12-2012
//                                 Se agrega el método validaAntecedentesOII  
//'C5                            : jchuertas - 30-12-2012
//                               : Se agregó el método obtieneMensajecorreo
//'C6                            : jchuertas -30-12-2012
//                                 se agregó el método solicitudSuscripcion
//'C7                            : jchuertas -30-12-2012
//                                 se agregaron los métodos getObtieneTipoSeguros y getValidaDocumento
//'C8                            : emontoya - 30-12-2012
//                               : Se modificaron los métodos: getCoberturasEdad, getFormasPago y getTipoPago.
//                               : emontoya - 30-12-2012
//'C9                            : Se agrega el método validaImpresion.
//                               : emontoya - 30-12-2012
//'C10                           : Se agrega el método validaImprimePolizaSolicitud.
//                               : emontoya - 30-11-2012
//'C11                           : Se agrega el método getParentescoSeguro.
//'                         
//'C12                           : jdgomezc - 30-12-2012
//'                              : Cambio de getCoberturasEdad() al nuevo procedimiento  
//'C13                           : jchuertas - 30-12-2012
//'                              : Cambio de validaSumaBasica() al nuevo procedimiento   
//'C15                           : jchuertas - 30-12-2012
//'                              : Cambio de validaCumulos() al nuevo procedimiento    
//'C16                           : jchuertas - 30-12-2012
//'                              : Se agregó el método validaPrimaMinima()
//'C17                           : emontoya - 30-12-2012
//'                              : Se realiza sobrecarga del método getOcupacion()                    
//'C18                           : jdgomezc - 30-12-2012
//'                              : Se cambia el procedimiento del que se obtiene 
//                                 el cuestionario al nuevo modelo 
//'C19                           : emontoya - 30-12-2012
//'                              : Se crea el método validaImpresionPreLlenada() 
//'C20                           : emontoya - 30-12-2012
//'                              : Se crea el método getTipoBeneficiario() 
//'C21                           : emontoya - 04-03-2013
//'                              : Se agrega el parametro de entrada p_tip_benef. 
//'C22                           : jchuertas - 01-10-2013
//'                              : Se crea el metodo que obtiene la lista de exámenes.
//'C22                           : Marco A. Navarrete - 11-11-2013
//'                              : Se agregó nuevo parámetro para enviar la fecha de validez de cada pregunta del cuestionario.
//'C23                           : jglopezh - 20-11-2013
//'                              : Se agregó nuevo parámetro 'tipoPlan' al método getDuracion() y 'p_tip_plan' al procedimiento 
//                               : p_obtiene_duracion.
//'C24                           : APL 26-07-2017
//'                              : Se agrega catalgo de parentesco para ramo 105
//26042018
//'********************************************************************************************************************

using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Oracle.DataAccess.Client;
using MapfreMMX.oracle;
using MapfreMMX.Seguridad;
using MapfreMMX.util;
using System.IO;
using Generales.Clases;
using MapfreMMX.emision;
using System.Collections;

/// <summary>
/// Summary description for Catalogos
/// </summary>
public class Catalogos
{
    string strPaqueteVida = ConfigurationManager.AppSettings["EsquemaVida"].ToString();
    string strPaqueteVidaContratos = "ev_k_define_contratos";
    string strEsquemaValidaciones = ConfigurationManager.AppSettings["EsquemaValidaciones"].ToString();
    string strPaqueteParaWM = ConfigurationManager.AppSettings["PaqueteParaWM"].ToString();

    public Catalogos()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    /// <summary>
    /// Método para obtener Agentes.
    /// </summary>
    /// <param name="cod_oficina">Parámetro de tipo cadena para almacenar el código de Oficina.</param>
    /// <returns>Regresa un objeto de tipo DataTable con la Información de Agentes.</returns>
    public DataTable getAgentes(int cod_oficina)
    {
        CDListaValor objListaValor = new CDListaValor();
        Hashtable PARAMETROS = new Hashtable();
        DataTable objTable = new DataTable();
        try
        {
            PARAMETROS.Add("COD_NIVEL3", cod_oficina);

            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                objTable = objListaValor.getListaValores(null, "A1001332", 3, PARAMETROS, conexion);
            }

            objTable.Columns.Add("NOM_COMPLETO");
            objTable.DefaultView.Sort = "NOM_TERCERO ASC";
            foreach (DataRow outRow in objTable.Rows)
            {
                outRow["NOM_COMPLETO"] = outRow["NOM_TERCERO"].ToString() + " " + outRow["APE1_TERCERO"].ToString() + " " +
                outRow["APE2_TERCERO"].ToString() + " (" + outRow["COD_AGT"].ToString() + ")";
            }

            return objTable.DefaultView.ToTable();
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getAgentes() : " + ex.Message);
        }
    }
    public DataTable getDATOS_AGENTE(int COD_AGT)
    {
        CDListaValor objLista = new CDListaValor();
        Hashtable objDatos = new Hashtable();
        string strNOM_TABLA = "A1001332";
        int iVERSION = 8;
        MCommand cmd = new MCommand();	
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                objDatos.Add("COD_AGT", COD_AGT);
                objDatos.Add("COD_NIVEL3", "NULL");
                objDatos.Add("COD_NIVEL2", "NULL");
                objDatos.Add("COD_NIVEL1", "NULL");
                objDatos.Add("COD_NIVEL1B", "NULL");

                return objLista.getListaValores(null, strNOM_TABLA,
                                                iVERSION, objDatos,
                                                conexion);
            }

        }
        catch (Exception ex)
        {
            throw new Exception("ERROR Catalogos.getDATOS_AGENTE() : " + ex.Message);
        }
    }

    public DataRow getDatosAgente(string cod_agt)
    {
        MCommand cmd = new MCommand();
        DataRow objDR;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "ev_k_emisiones_web.p_verifica_agente";

                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int16, 1);
                cmd.agregarINParametro("p_cod_agente", OracleDbType.Int32, cod_agt);
                cmd.agregarOUTParametro("p_nom_agte", OracleDbType.Varchar2, 80);
                cmd.agregarOUTParametro("p_nom_div", OracleDbType.Varchar2, 80);
                cmd.agregarOUTParametro("p_tel_agte", OracleDbType.Varchar2, 80);
                cmd.agregarOUTParametro("p_mail_agte", OracleDbType.Varchar2, 80);
                cmd.agregarOUTParametro("p_cuadro_com", OracleDbType.Int16, 80);
                cmd.agregarOUTParametro("p_valida", OracleDbType.Varchar2, 80);

                objDR = cmd.ejecutarRegistroSP();
            }
            return objDR;
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getDatosAgente() : " + ex.Message);
        }
    }

    /// <summary>Obtiene Catálogo de Parentesco</summary>
    /// <returns>DataTable</returns>
    public DataTable getParentesco()
    {
        CDListaValor objListaValor = new CDListaValor();
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                //C1
                return objListaValor.getPARENTESCOBENEF("'PARENTESCO_PORTAL_VIDA'", "'ES'", conexion);
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getParentesco() : " + ex.Message);
        }
    }

    //<--- C17 --->
    /// <summary>
    /// Método para consultar las ocupaciones por ramo, modalidad y contrato
    /// </summary>
    /// <param name="ramo">Parámetro de tipo entero para almacenar el Código del Ramo.</param>
    /// <param name="Modalidad">>Parámetro de tipo cadena para almacenar la Modalidad</param>
    /// <param name="contrato">Parámetro de tipo entero para almacenar el número de contrato</param>
    /// <returns>DataTable con las ocupaciones correspondientes a los parámetros de entrada</returns>
    public DataTable getOcupacion(int ramo, string Modalidad, int contrato)
    {
        MCommand cmd = new MCommand();
        CDListaValor objListaValor = new CDListaValor(ramo);
        DataSet objDS = new DataSet();
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strEsquemaValidaciones + strPaqueteParaWM + ".p_obtiene_ocupaciones";

                cmd.agregarINParametro("p_cod_portal", OracleDbType.Double, 2);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Double, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Double, ramo);
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Double, Modalidad);
                cmd.agregarINParametro("p_num_contrato ", OracleDbType.Double, contrato);
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);
                cmd.agregarOUTParametro("p_ocupaciones ", OracleDbType.RefCursor, 0);

                objDS = cmd.ejecutarRefCursorSP();
            }

            if (objDS.Tables[0].Rows.Count < 1)
                throw new Exception("No hay datos");
            else
                return objDS.Tables[0];
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getOcupacion() : " + ex.Message);

        }
    }

    public DataTable getOcupacion()
    {
        CDListaValor objListaValor = new CDListaValor();
        DataTable objDT = new DataTable();

        string cod_idioma = "'ES'";

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                //objDT = objListaValor.getOCUPACION();
                objDT = objListaValor.getPROFESION(cod_idioma, conexion);
            }

            return objDT;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getOcupacion() : " + ex.Message);
        }
    }

    /// <summary>
    ///     Método para obtener las Polizas Grupo.
    /// </summary>
    /// <param name="CodRamo">Parámetro de tipo entero para almacenar el Código del Ramo.</param>
    /// <param name="codAgente">Parámetro de tipo entero para almacenar el Código del Agente.</param>
    /// <returns>Regresa un objeto de tipo DataTable con la Información de las Polizas Grupo.</returns>
    public DataTable getPolizasGrupo(int CodRamo, int codAgente)
    {
        DataTable objDT = new DataTable();
        MCommand cmd = new MCommand();
        DataSet numPolizasGpo;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;//  strPaqueteVidaContratos
                cmd.CommandText = strPaqueteVida + ".p_devuelve_poliza_gpo";

                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodRamo);
                cmd.agregarINParametro("p_agente", OracleDbType.Int32, codAgente);
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);

                cmd.agregarOUTParametro("p_nom_poliza_gpo", OracleDbType.RefCursor, 0);

                numPolizasGpo = cmd.ejecutarRefCursorSP();
            }

            return numPolizasGpo.Tables[0];
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getPolizasGrupo() : " + ex.Message);
        }
    }

    public DataTable getPolizasGrupo108(int CodRamo, int codAgente)
    {
        DataTable objDT = new DataTable();
        MCommand cmd = new MCommand();
        DataSet numPolizasGpo;
        int cod_portal = 2;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "TRON2000.ev_k_define_contratos_mmx.p_devuelve_poliza_gpo";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodRamo);
                cmd.agregarINParametro("p_agente", OracleDbType.Int32, codAgente);
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);
                cmd.agregarINParametro("p_cod_portal", OracleDbType.Int32, cod_portal);
                cmd.agregarOUTParametro("p_nom_poliza_gpo", OracleDbType.RefCursor, 0);
                numPolizasGpo = cmd.ejecutarRefCursorSP();
            }

            return numPolizasGpo.Tables[0];
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getPolizasGrupo() : " + ex.Message);
        }
    }
    /// <summary>
    ///     Método para obtener Contratos.
    /// </summary>
    /// <param name="CodRamo">Parámetro de tipo entero para almacenar el Código del Ramo.</param>
    /// <param name="numPolizaGpo">Parámetro de tipo cadena para almacenar el Número de la Poliza Grupo.</param>
    /// <param name="codAgente">Parámetro de tipo entero para almacenar el Código del Agente.</param>
    /// <returns>Regresa un objeto de tipo DataTable con la Información de los Contratos.</returns>
    public DataTable getContratos(int CodRamo, string numPolizaGpo, int codAgente)
    {
        DataTable objDT = new DataTable();
        MCommand cmd = new MCommand();
        DataSet numContratos;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                //cmd.CommandText = strPaqueteVidaContratos + ".p_devuelve_contrato";
                cmd.CommandText = strPaqueteVida + ".p_devuelve_contrato";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodRamo);
                cmd.agregarINParametro("p_num_poliza_grupo", OracleDbType.Varchar2, numPolizaGpo);
                cmd.agregarINParametro("p_agente", OracleDbType.Int32, codAgente);
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);

                cmd.agregarOUTParametro("p_nom_contrato", OracleDbType.RefCursor, 0);

                numContratos = cmd.ejecutarRefCursorSP();
            }

            /*if (numContratos.Tables[0].Rows.Count == 0)
            { throw new Exception("Error"); }*/

            return numContratos.Tables[0];
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getContratos() : " + ex.Message);
        }
    }

    public DataTable getContratos108(int CodRamo, string numPolizaGpo, int codAgente)
    {
        DataTable objDT = new DataTable();
        MCommand cmd = new MCommand();
        DataSet numContratos;
        int cod_portal = 2;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "TRON2000.ev_k_define_contratos_mmx.p_devuelve_contrato";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodRamo);
                cmd.agregarINParametro("p_agente", OracleDbType.Int32, codAgente);
                cmd.agregarINParametro("p_num_poliza_grupo", OracleDbType.Varchar2, numPolizaGpo);
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);
                cmd.agregarINParametro("p_cod_portal", OracleDbType.Int32, cod_portal);
                cmd.agregarOUTParametro("p_nom_contrato", OracleDbType.RefCursor, 0);
                numContratos = cmd.ejecutarRefCursorSP();
            }

            /*if (numContratos.Tables[0].Rows.Count == 0)
            { throw new Exception("Error"); }*/

            return numContratos.Tables[0];
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getContratos108() : " + ex.Message);
        }
    }
    /// <summary>
    ///     Método para obtener los Ramos.
    /// </summary>
    /// <returns>Regresa un objeto de tipo DataTable con la Información de los Ramos.</returns>
    public DataTable getRamos()
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataSet objDataSet = new DataSet();

        string contrato = ConfigurationManager.AppSettings["ContratoGenerico"].ToString();
        //string strCodCampo = ConfigurationManager.AppSettings["CodCampoRamosAEliminar"].ToString();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strPaqueteVida + ".p_obtiene_ramo";

                cmd.agregarINParametro("cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Double, contrato);
                cmd.agregarOUTParametro("p_ramos", OracleDbType.RefCursor, 2000);

                objDataSet = cmd.ejecutarRefCursorSP();

                //General.eliminaItems(objDataSet.Tables[0], "RamosAEliminar", strCodCampo);

                return objDataSet.Tables[0];
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getRamos() : " + ex.Message);
        }
    }

    /// <summary>
    /// Método para obtener los Ramos.
    /// </summary>
    /// <param name="contrato">Parámetro de tipo cadena para almacenar el Contrato.</param>
    /// <returns>Regresa un objeto de tipo DataTable con la Información de los Ramos.</returns>
    public DataTable getRamos(string contrato)
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataSet objDataSet = new DataSet();

        //string strCodCampo = ConfigurationManager.AppSettings["CodCampoRamosAEliminar"].ToString();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strPaqueteVida + ".p_obtiene_ramo";

                cmd.agregarINParametro("cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Double, contrato);
                cmd.agregarOUTParametro("p_ramos", OracleDbType.RefCursor, 2000);

                objDataSet = cmd.ejecutarRefCursorSP();

                //General.eliminaItems(objDataSet.Tables[0], "RamosAEliminar", strCodCampo);

                return objDataSet.Tables[0];
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getRamos() : " + ex.Message);
        }
    }

    /// <summary>
    /// Método para obtener los tipos de Moneda.
    /// </summary>
    /// <param name="CodigoRamo">Parámetro de tipo entero para almacenar el código del Ramo.</param>
    /// <param name="contrato">Parámetro de tipo cadena para almacenar el contrato.</param>
    /// <returns>Regresa un objeto de tipo DataTable con la Información de los Tipos de Moneda.</returns>
    public DataTable getMoneda(int CodigoRamo, string contrato, int tipoPlan)
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataSet objDataSet = new DataSet();

        try
        {
            if (CodigoRamo == 105)
            {
                CDListaValor objListaValor = new CDListaValor();
                DataTable objDT;
                OracleConnection conexion = MConexion.getConexion("ConnectionTW");
                try
                {
                    objDT = objListaValor.getMONEDA(1, CodigoRamo, conexion);
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    ((IDisposable)conexion).Dispose();
                }
                return objDT;
            }
            else
            {
                using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
                {


                    cmd.Connection = conexion;
                    cmd.CommandText = strPaqueteVida + ".p_obtiene_moneda";

                    cmd.agregarINParametro("cod_cia", OracleDbType.Int32, 1);
                    cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodigoRamo);
                    cmd.agregarINParametro("p_num_contrato", OracleDbType.Double, contrato);
                    cmd.agregarINParametro("p_tip_plan", OracleDbType.Int32, tipoPlan);
                    cmd.agregarOUTParametro("p_cod_mon", OracleDbType.RefCursor, 2000);

                    objDataSet = cmd.ejecutarRefCursorSP();

                    return objDataSet.Tables[0];
                }
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getMoneda() : " + ex.Message);
        }
    }

    /// <summary>
    /// Método para obtener el Crecimiento.
    /// </summary>
    /// <param name="CodigoRamo">Parámetro de tipo entero para almacenar el Código del Ramo.</param>
    /// <param name="contrato">Parámetro de tipo cadena para almacenar el contrato.</param>
    /// <param name="Moneda">Parámetro de tipo cadena para almacenar el Tipo de Moneda.</param>
    /// <returns>Regresa un objeto de tipo DataTable con la Información del Crecimiento.</returns>
    public DataTable getCrecimiento(int CodigoRamo, string contrato, int Moneda, int tipoPlan)
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataSet objDataSet = new DataSet();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                if (CodigoRamo == 105)
                {
                    cmd.Connection = conexion;
                    cmd.CommandText = "tron2000.ev_k_productos_vida_mmx" + ".p_obtiene_crecimiento";

                    cmd.agregarINParametro("cod_cia", OracleDbType.Int32, 1);
                    cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodigoRamo);
                    cmd.agregarINParametro("p_num_contrato", OracleDbType.Double, contrato);
                    cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Moneda);
                    cmd.agregarINParametro("p_tip_plan", OracleDbType.Int32, tipoPlan);
                    cmd.agregarOUTParametro("p_crecimiento", OracleDbType.RefCursor, 2000);

                    objDataSet = cmd.ejecutarRefCursorSP();

                    return objDataSet.Tables[0];
                }
                else
                {
                    cmd.Connection = conexion;
                    cmd.CommandText = strPaqueteVida + ".p_obtiene_crecimiento";

                    cmd.agregarINParametro("cod_cia", OracleDbType.Int32, 1);
                    cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodigoRamo);
                    cmd.agregarINParametro("p_num_contrato", OracleDbType.Double, contrato);
                    cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Moneda);
                    cmd.agregarINParametro("p_tip_plan", OracleDbType.Int32, tipoPlan);
                    cmd.agregarOUTParametro("p_crecimiento", OracleDbType.RefCursor, 2000);

                    objDataSet = cmd.ejecutarRefCursorSP();

                    return objDataSet.Tables[0];
                }
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getCrecimiento() : " + ex.Message);
        }
    }

    /// <summary>
    /// Método para obtener deducible.
    /// </summary>
    /// <param name="CodigoRamo">Parámetro de tipo entero para almacenar el Código del Ramo.</param>
    /// <param name="contrato">Parámetro de tipo cadena para almacenar el contrato.</param>
    /// <param name="Moneda">Parámetro de tipo entero para almacenar el tipo de Moneda.</param>
    /// <param name="strTipRegularizaSuma">Parámetro de tipo cadena para almacenar el "TIP_REGULARIZA_SUMA"</param>
    /// <returns>Regresa un objeto de tipo DataTable con la Información del Crecimiento.</returns>
    public DataTable getDeducible(int CodigoRamo, string contrato, int Moneda, string strTipRegularizaSuma)
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataSet objDataSet = new DataSet();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strPaqueteVida + ".p_obtiene_deducible";

                cmd.agregarINParametro("cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodigoRamo);
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Double, contrato);
                cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Moneda);
                cmd.agregarINParametro("p_tip_regulariza_suma", OracleDbType.Int32, strTipRegularizaSuma);
                cmd.agregarOUTParametro("p_tip_deducible", OracleDbType.RefCursor, 2000);

                objDataSet = cmd.ejecutarRefCursorSP();

                return objDataSet.Tables[0];
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getDeducible() : " + ex.Message);
        }
    }

    // <---- C23 ---->
    /// <summary>
    /// Método para obtener Duración.
    /// </summary>
    /// <param name="CodigoRamo">Parámetro de tipo entero para almacenar el Código del Ramo.</param>
    /// <param name="contrato">Parámetro de tipo cadena para almacenar el Contrato.</param>
    /// <param name="Moneda">Parámetro de tipo entero para almacenar el tipo de Moneda.</param>
    /// <param name="strTipRegularizaSuma">Parámetro de tipo cadena para almacenar el "TIP_REGULARIZA_SUMA"</param>
    /// <param name="tipoDeducible">Parámetro de tipo cadena para almacenar el tipoDeducible.</param>
    /// <param name="tipoPlan">Parámetro de tipo cadena para almacenar el tipoPlan.</param>
    /// <returns>Regresa un objeto de tipo DataTable con la Información de la Duración.</returns>
    public DataTable getDuracion(int CodigoRamo, string contrato, int Moneda, string strTipRegularizaSuma, string tipoDeducible, string tipoPlan)
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataSet objDataSet = new DataSet();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {

                if (CodigoRamo == 105)
                {
                    cmd.Connection = conexion;
                    cmd.CommandText = strPaqueteVida + ".p_obtiene_duracion";

                    cmd.agregarINParametro("cod_cia", OracleDbType.Int32, 1);
                    cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodigoRamo);
                    cmd.agregarINParametro("p_num_contrato", OracleDbType.Double, contrato);
                    cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Moneda);
                    cmd.agregarINParametro("p_tip_regulariza_suma", OracleDbType.Int32, strTipRegularizaSuma);
                    cmd.agregarINParametro("p_tip_deducible", OracleDbType.Int32, tipoDeducible);
                    // <---- C23 ---->
                    cmd.agregarINParametro("p_tip_plan", OracleDbType.Int32, Convert.ToInt32(tipoPlan));
                    // <------------->
                    cmd.agregarOUTParametro("p_cad_duracion", OracleDbType.RefCursor, 2000);

                    objDataSet = cmd.ejecutarRefCursorSP();
                    //if (CodigoRamo == 105 & Moneda == 2)
                    //{
                    //    DataRow row = objDataSet.Tables[0].NewRow(); ;
                    //    row["DURACION_HASTA"] = 18;

                    //    objDataSet.Tables[0].Rows.Add(row);
                    //}
                    //else
                    //{ }


                    return objDataSet.Tables[0];
                }
                else
                {
                    cmd.Connection = conexion;
                    cmd.CommandText = strPaqueteVida + ".p_obtiene_duracion";

                    cmd.agregarINParametro("cod_cia", OracleDbType.Int32, 1);
                    cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodigoRamo);
                    cmd.agregarINParametro("p_num_contrato", OracleDbType.Double, contrato);
                    cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Moneda);
                    cmd.agregarINParametro("p_tip_regulariza_suma", OracleDbType.Int32, strTipRegularizaSuma);
                    cmd.agregarINParametro("p_tip_deducible", OracleDbType.Int32, tipoDeducible);
                    // <---- C23 ---->
                    cmd.agregarINParametro("p_tip_plan", OracleDbType.Int32, Convert.ToInt32(tipoPlan));
                    // <------------->
                    cmd.agregarOUTParametro("p_cad_duracion", OracleDbType.RefCursor, 2000);

                    objDataSet = cmd.ejecutarRefCursorSP();
                    //if (CodigoRamo == 105 & Moneda == 2)
                    //{
                    //    DataRow row = objDataSet.Tables[0].NewRow(); ;
                    //    row["DURACION_HASTA"] = 18;

                    //    objDataSet.Tables[0].Rows.Add(row);
                    //}
                    //else
                    //{ }


                    return objDataSet.Tables[0];
                }


            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getDuracion() : " + ex.Message);
        }
    }

    /// <summary>
    /// Método para obtener Comisión.
    /// </summary>
    /// <param name="CodigoRamo">Parámetro de tipo entero para almacenar el Código del Ramo.</param>
    /// <param name="contrato">Parámetro de tipo cadena para almacenar el Contrato.</param>
    /// <param name="Moneda">Parámetro de tipo entero para almacenar el tipo de Moneda.</param>
    /// <param name="strTipRegularizaSuma">Parámetro de tipo cadena para almacenar el "TIP_REGULARIZA_SUMA"</param>
    /// <param name="tipoDeducible">Parámetro de tipo cadena para almacenar el tipoDeducible.</param>
    /// <param name="duracion">Parámetro de tipo cadena para almacenar la Duración.</param>
    /// <returns></returns>
    public DataTable getComision(int CodigoRamo, string contrato, int Moneda, string strTipRegularizaSuma,
                                 string tipoDeducible, string duracion, int tipoPlan)
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataSet objDataSet = new DataSet();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strPaqueteVida + ".p_obtiene_tip_comision";

                cmd.agregarINParametro("cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodigoRamo);
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Double, contrato);
                cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Moneda);
                cmd.agregarINParametro("p_tip_regulariza_suma", OracleDbType.Int32, strTipRegularizaSuma);
                cmd.agregarINParametro("p_tip_deducible", OracleDbType.Int32, tipoDeducible);
                cmd.agregarINParametro("p_duracion", OracleDbType.Int32, duracion);
                cmd.agregarINParametro("p_tip_plan", OracleDbType.Int32, tipoPlan);
                cmd.agregarOUTParametro("p_tip_comision", OracleDbType.RefCursor, 2000);

                objDataSet = cmd.ejecutarRefCursorSP();

                return objDataSet.Tables[0];
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getComision() : " + ex.Message);
        }
    }

    /// <summary>
    /// Método para obtener la Modalidad.
    /// </summary>
    /// <param name="CodigoRamo">Parámetro de tipo entero para almacenar el Código del Ramo.</param>
    /// <param name="contrato">Parámetro de tipo cadena para almacenar el Contrato.</param>
    /// <param name="Moneda">Parámetro de tipo entero para almacenar el tipo de Moneda.</param>
    /// <param name="strTipRegularizaSuma">Parámetro de tipo cadena para almacenar el "TIP_REGULARIZA_SUMA"</param>
    /// <param name="tipoDeducible">Parámetro de tipo cadena para almacenar el tipo de Comisión.</param>
    /// <param name="tipComision">Parámetro de tipo cadena para almacenar el tipo de Comisión.</param>
    /// <param name="duracion">Parámetro de tipo cadena para almacenar la Duración.</param>
    /// <returns>Regresa un objeto de tipo DataTable con la Información de la Modalidad.</returns>
    public DataTable getModalidad(int CodigoRamo, string contrato, int Moneda, string strTipRegularizaSuma,
                                  string tipoDeducible, string tipComision, string duracion, string strMarca, int tipoPlan)
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataSet objDataSet = new DataSet();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                //cmd.CommandText = "ev_k_productos_vida_mmx.p_obtiene_modalidad";
                cmd.CommandText = strPaqueteVida + ".p_obtiene_modalidad";

                cmd.agregarINParametro("cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodigoRamo);
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Double, contrato);
                cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Moneda);
                cmd.agregarINParametro("p_tip_regulariza_suma", OracleDbType.Varchar2, strTipRegularizaSuma);
                cmd.agregarINParametro("p_tip_deducible", OracleDbType.Int32, tipoDeducible);
                cmd.agregarINParametro("p_tip_comision", OracleDbType.Int32, tipComision);
                cmd.agregarINParametro("p_duracion_hasta", OracleDbType.Int32, duracion);
                cmd.agregarINParametro("p_mca_especial", OracleDbType.Varchar2, strMarca);
                cmd.agregarINParametro("p_tip_plan", OracleDbType.Int32, tipoPlan);
                cmd.agregarOUTParametro("p_cod_modalidad", OracleDbType.RefCursor, 2000);

                objDataSet = cmd.ejecutarRefCursorSP();

                return objDataSet.Tables[0];
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getModalidad() : " + ex.Message);
        }
    }

    /// <summary>
    /// Obtiene Catalogo con las coberturas.
    /// </summary>
    /// <param name="CodigoRamo">Parámetro de tipo entero para almacenar el Código del Ramo.</param>
    /// <param name="contrato">Parámetro de tipo cadena para almacenar el contrato.</param>
    /// <param name="Moneda">Parámetro de tipo entero para almacenar el tipo de Moneda.</param>
    /// <returns></returns>
    public DataTable getCoberturas(int CodigoRamo, string contrato, int Moneda)
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataSet objDataSet = new DataSet();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "ev_k_define_contratos.p_devuelve_coberturas";

                cmd.agregarINParametro("cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodigoRamo);
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Double, contrato);
                cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Moneda);
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Now.Date);
                cmd.agregarOUTParametro("p_coberturas", OracleDbType.RefCursor, 2000);

                objDataSet = cmd.ejecutarRefCursorSP();

                return objDataSet.Tables[0];
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getCoberturas() : " + ex.Message);
        }
    }

    // <--- C8 --->
    /// <summary>
    /// Método que consulta las coberturas por edad
    /// </summary>
    /// <param name="CodigoRamo">Parámetro de tipo entero para almacenar el Código del Ramo.</param>
    /// <param name="contrato">número de contrato</param>
    /// <param name="Modalidad">modalidad</param>
    /// <param name="Edad">edad</param>
    /// <param name="Moneda">código de moneda</param>
    /// <returns>DataTable con las coberturas, tope máximo y mínimo de edad.</returns>
    public DataTable getCoberturasEdad(int CodigoRamo, string contrato, string Modalidad, int Edad, int Moneda)
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataSet objDataSet = new DataSet();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                if (CodigoRamo == 105)
                {
                    if (Edad > 17)
                    {
                        CDListaValor objListaValor = new CDListaValor();
                        Hashtable objDatos = new Hashtable();
                        DataTable objTabla = new DataTable();
                        DataTable dt = new DataTable();
                        string strNOM_TABLA = "A1002150";
                        int iVERSION = 23;
                        try
                        {
                            objDatos.Add("cod_cia", 1);
                            objDatos.Add("cod_ramo", CodigoRamo);
                            objDatos.Add("cod_modalidad", Modalidad);
                            objDatos.Add("num_edad", Edad);

                            //return objListaValor.getListaValores(null, strNOM_TABLA, iVERSION, objDatos, conexion);

                            objTabla = objListaValor.getListaValores(null, strNOM_TABLA, iVERSION, objDatos, conexion);

                            dt.Columns.Add("COD_COB", typeof(int));
                            dt.Columns.Add("NOM_COB", typeof(String));
                            dt.Columns.Add("MCA_OBLIGATORIA", typeof(String));
                            dt.Columns.Add("MCA_ACCIDENTES", typeof(String));
                            dt.Columns.Add("COD_COB_DEP", typeof(String));
                            dt.Columns.Add("SUMA_ASEG_DESDE", typeof(int));
                            dt.Columns.Add("SUMA_ASEG_HASTA", typeof(int));
                            dt.Columns.Add("DESCRIPCION", typeof(String));
                            DataRow row = dt.NewRow();

                            for (int i = 0; i <= objTabla.Rows.Count - 1; i++)
                            {
                                row = dt.NewRow();
                                row["COD_COB"] = objTabla.Rows[i]["COD_COB"].ToString();
                                row["NOM_COB"] = objTabla.Rows[i]["NOM_COB"].ToString();
                                row["MCA_OBLIGATORIA"] = objTabla.Rows[i]["MCA_OBLIGATORIO"].ToString();
                                row["MCA_ACCIDENTES"] = objTabla.Rows[i]["MCA_OBLIGATORIO"].ToString();
                                row["COD_COB_DEP"] = "N";
                                if (Moneda == 2)
                                {
                                    row["SUMA_ASEG_DESDE"] = 1;
                                    row["SUMA_ASEG_HASTA"] = 75000;
                                }
                                if (Moneda == 6)
                                {
                                    row["SUMA_ASEG_DESDE"] = 1;
                                    row["SUMA_ASEG_HASTA"] = 200000;
                                }

                                if (objTabla.Rows[i]["NOM_COB"].ToString() == "TEMPORAL")
                                {
                                    row["DESCRIPCION"] = "TEMPORAL";
                                }

                                if (objTabla.Rows[i]["NOM_COB"].ToString() == "BIT")
                                {
                                    row["DESCRIPCION"] = "EXENCIÓN DE PAGO DE PRIMAS POR INVALIDEZ TOTAL Y PERMANENTE POR ACCIDENTE Y/O ENFERMEDAD";
                                }

                                if (objTabla.Rows[i]["NOM_COB"].ToString() == "BIPA")
                                {
                                    row["DESCRIPCION"] = "PAGO ADICIONAL POR INVALIDEZ TOTAL Y PERMANENTE POR ACCIDENTE Y/O ENFERMEDAD";
                                }

                                if (objTabla.Rows[i]["NOM_COB"].ToString() == "BEF")
                                {
                                    row["DESCRIPCION"] = "BENEFICIO DE EXENCIÓN DE PAGO DE PRIMAS POR FALLECIMIENTO";
                                }


                                dt.Rows.Add(row);

                            }


                            return dt;

                        }
                        catch (Exception ex)
                        {
                            throw new Exception("ERROR CDListaValor.getMONEDA() : " + ex.Message);
                        }
                    }
                    else
                    {
                        cmd.Connection = conexion;
                        cmd.CommandText = "tron2000.ev_k_productos_vida_mmx.p_cobertura_edad";
                        cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                        cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodigoRamo);
                        cmd.agregarINParametro("p_num_contrato", OracleDbType.Double, contrato);
                        cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Double, Modalidad);
                        cmd.agregarINParametro("p_edad", OracleDbType.Int32, Edad);
                        cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Moneda);
                        cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Now.Date);
                        cmd.agregarOUTParametro("p_cober_edad", OracleDbType.RefCursor, 2000);
                        //C12

                        objDataSet = cmd.ejecutarRefCursorSP();

                        objDataSet.Tables[0].Columns.Add("DESCRIPCION", typeof(String));




                        DataRow row = objDataSet.Tables[0].NewRow(); ;
                        row["DESCRIPCION"] = "BÁSICA";

                        objDataSet.Tables[0].Rows[0]["DESCRIPCION"] = "BÁSICA";


                        return objDataSet.Tables[0];
                    }
                }
                else
                {
                    //C12
                    cmd.Connection = conexion;
                    cmd.CommandText = strEsquemaValidaciones + strPaqueteParaWM + ".p_cobertura_edad";
                    cmd.agregarINParametro("p_cod_portal", OracleDbType.Int32, 2);
                    cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                    cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodigoRamo);
                    cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Double, Modalidad);
                    cmd.agregarINParametro("p_num_contrato", OracleDbType.Double, contrato);
                    cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Moneda);
                    cmd.agregarINParametro("p_edad", OracleDbType.Int32, Edad);
                    cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Now.Date);
                    cmd.agregarOUTParametro("p_cobertura_edad", OracleDbType.RefCursor, 2000);
                    //C12

                    objDataSet = cmd.ejecutarRefCursorSP();

                    return objDataSet.Tables[0];
                }
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getCoberturasEdad() : " + ex.Message);
        }
    }

    public DataTable getDctoSexoFuma(int CodigoRamo, string Modalidad, int CodCob)
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataSet objDataSet = new DataSet();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strPaqueteVida + ".p_devuelve_dctos";

                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodigoRamo);
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Double, Modalidad);
                cmd.agregarINParametro("p_cod_cob", OracleDbType.Int32, CodCob);
                cmd.agregarOUTParametro("p_descuentos", OracleDbType.RefCursor, 2000);

                objDataSet = cmd.ejecutarRefCursorSP();

                return objDataSet.Tables[0];
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getDctoSexoFuma() : " + ex.Message);
        }
    }

    /// <summary>
    /// Obtiene Catálogo de formas de pago
    /// </summary>
    /// <param name="num_contrato">Número de Contrato.</param>
    /// <returns>DataTable con lista de formas de pago</returns>
    // <--- C8 --->
    public DataTable getFormasPago(int ramo, string Modalidad, int num_contrato)
    {
        MCommand cmd = new MCommand();
        CDListaValor objListaValor = new CDListaValor(ramo);
        DataSet objDS = new DataSet();
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strEsquemaValidaciones + strPaqueteParaWM + ".p_devuelve_forma_pago";

                cmd.agregarINParametro("p_cod_portal", OracleDbType.Double, 2);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Double, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Double, ramo);
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Double, Modalidad);
                cmd.agregarINParametro("p_num_contrato ", OracleDbType.Double, num_contrato);
                cmd.agregarINParametro("p_fecha_validez", OracleDbType.Date, DateTime.Today);
                cmd.agregarOUTParametro("p_forma_pago", OracleDbType.RefCursor, 0);

                objDS = cmd.ejecutarRefCursorSP();
            }

            if (objDS.Tables[0].Rows.Count < 1)
                throw new Exception("No hay datos");
            else
                return objDS.Tables[0];
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getFormasPago() : " + ex.Message);
        }
    }

    /// <summary>
    /// Obtiene Catálogo de tipo de pago
    /// </summary>
    /// <returns>DataTable con lista de tipo de pago</returns>
    public DataTable getGestor()
    {
        CDListaValor objListaValor = new CDListaValor();
        DataTable objDT = new DataTable();
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                objDT = objListaValor.getGESTOR(conexion);
            }

            General.eliminaItems(objDT, "gestorND", "TIP_GESTOR");
            return objDT;
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getGestor() : " + ex.Message);
        }
    }

    // <--- C8 --->
    /// <summary>
    /// Método que se encarga de consultar el tipo de pago para un contrato.
    /// </summary>
    /// <param name="CodigoRamo">ramo</param>
    /// <param name="Modalidad">modalidad</param>
    /// <param name="Contrato">número de contrato</param>
    /// <param name="formaPago">forma de pago disponible para el contrato</param>
    /// <returns>DataTable con los tipos de pago correspondientes al contrato</returns>
    public DataTable getTipoPago(int CodigoRamo, string Modalidad, string Contrato, string formaPago)
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataSet objDataSet = new DataSet();
        DataTable objDataTable = new DataTable();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strEsquemaValidaciones + strPaqueteParaWM + ".p_obtiene_tipo_pago";

                cmd.agregarINParametro("p_cod_portal", OracleDbType.Int32, 2);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodigoRamo);
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Double, Modalidad);
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Double, Contrato);
                cmd.agregarINParametro("p_forma_pago", OracleDbType.Double, formaPago);
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);
                cmd.agregarOUTParametro("p_tipo_pago", OracleDbType.RefCursor, 2000);

                objDataSet = cmd.ejecutarRefCursorSP();

                return objDataSet.Tables[0];
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getTipoPago() : " + ex.Message);
        }
    }

    /// <summary>Obtiene Montos de las Formas de Pago</summary>
    /// <param name="cotizacion">El número de Cotización.</param>
    /// <param name="numPagos">El número de Pagos.</param>
    /// <param name="pagos">Cadena de las Formas de Pago.</param>
    /// <param name="conexion">Conexión a la base de datos.</param>
    /// <returns>DataRow.</returns>
    public DataRow getFormaPago(string cotizacion, float numPagos, string pagos, OracleConnection conexion)
    {
        DataRow objRow = null;
        MCommand cmd = new MCommand();
        try
        {
            cmd.Connection = conexion;
            //cmd.CommandText = "ev_k_impresion_cotiza.p_imprime_formapagos";
            cmd.CommandText = strPaqueteVida + ".p_imprime_formapagos";

            cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
            cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, cotizacion);
            cmd.agregarINParametro("p_num_spto", OracleDbType.Int32, 0);
            cmd.agregarINParametro("p_num_apli", OracleDbType.Int32, 0);
            cmd.agregarINParametro("p_num_spto_apli", OracleDbType.Int32, 0);
            cmd.agregarINParametro("p_tip_mvto_batch", OracleDbType.Varchar2, 3);
            cmd.agregarINParametro("p_tip_emision", OracleDbType.Varchar2, 'C');
            cmd.agregarINParametro("p_num_forpagos", OracleDbType.Double, numPagos);
            cmd.agregarINParametro("p_cad_forpagos", OracleDbType.Varchar2, pagos);
            cmd.agregarOUTParametro("p_cadena_cotizacion", OracleDbType.Varchar2, 2000);

            objRow = cmd.ejecutarRegistroSP();

            return objRow;

        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR EV_K_IMPRESION_COTIZA.P_IMPRIME_FORMAPAGOS : " + ex.Message);
        }
    }

    public DataRow SumaAseguradaBasica(int CodigoRamo, int CodCob, string Modalidad, int Moneda, string suma_aseg)
    {
        MCommand cmd = new MCommand();
        DataRow objRow = null;

        try
        {

            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strPaqueteVida + ".p_coberturas";

                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodigoRamo);
                cmd.agregarINParametro("p_cod_cob", OracleDbType.Int32, CodCob);
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Double, Modalidad);
                cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Moneda);
                cmd.agregarINParametro("p_suma_aseg_basica", OracleDbType.Double, suma_aseg);
                cmd.agregarOUTParametro("p_suma_aseg", OracleDbType.Varchar2, 100);
                cmd.agregarOUTParametro("p_mca_modifica", OracleDbType.Varchar2, 100);



                objRow = cmd.ejecutarRegistroSP();

                return objRow;
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.SumaAseguradaBasica() : " + ex.Message);
        }
    }

    public DataRow validaCoberturas(int CodCob, int CodigoRamo, string Modalidad, int Moneda, string suma_aseg_basica,
        string suma_aseg)
    {
        MCommand cmd = new MCommand();
        DataRow objRow = null;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strPaqueteVida + ".p_valida_coberturas";

                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_cob", OracleDbType.Int32, CodCob);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodigoRamo);
                cmd.agregarINParametro("p_modalidad", OracleDbType.Double, Modalidad);
                cmd.agregarINParametro("p_cod_limite", OracleDbType.Int32, Moneda);
                cmd.agregarINParametro("p_suma_aseg_basica", OracleDbType.Double, suma_aseg_basica);
                cmd.agregarINOUTParametro("p_suma_aseg", OracleDbType.Varchar2, 1000, suma_aseg);
                cmd.agregarOUTParametro("p_mca_valido", OracleDbType.Varchar2, 100);
                cmd.agregarOUTParametro("p_error", OracleDbType.Varchar2, 100);

                objRow = cmd.ejecutarRegistroSP();

                return objRow;
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.validaCoberturas() : " + ex.Message);
        }
    }

    /// <summary>
    ///     Este método se encarga de la consulta al procedimiento almacenado que valida el tope maximo de suma asegurada
    /// </summary>
    /// <param name="ramo">Id del ramo</param>
    /// <param name="modalidad">Modalidad de la emision</param>
    /// <param name="contrato">Numero de contrato</param>
    /// <param name="Moneda">Tipo de moneda</param>
    /// <param name="suma_aseg_basica">Valor de suma asegurada</param>
    /// <returns></returns>
    public DataRow validaSumaBasica(int ramo, int modalidad, int contrato, int Moneda, string suma_aseg_basica)
    {
        MCommand cmd = new MCommand();
        DataRow objRow = null;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                //----------------------->C13<--------------------------------
                cmd.Connection = conexion;
                cmd.CommandText = strEsquemaValidaciones + strPaqueteParaWM + ".p_valida_sum_Aseg_basica";

                cmd.agregarINParametro("p_cod_portal", OracleDbType.Int32, 2);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, ramo);
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Int32, modalidad);
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Int32, contrato);
                cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Moneda);
                cmd.agregarINParametro("p_suma_asegurada", OracleDbType.Double, suma_aseg_basica);
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);
                cmd.agregarOUTParametro("p_mca_valido", OracleDbType.Varchar2, 100);
                cmd.agregarOUTParametro("p_error", OracleDbType.Varchar2, 100);
                cmd.agregarOUTParametro("p_continua_sol", OracleDbType.Varchar2, 100);

                objRow = cmd.ejecutarRegistroSP();

                return objRow;
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.validaSumaBasica() : " + ex.Message);
        }
    }

    public DataRow validaCLMServFun(string strCLM)
    {
        MCommand cmd = new MCommand();
        DataRow objRow = null;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strEsquemaValidaciones + strPaqueteVida + ".p_valida_clm";

                cmd.agregarINParametro("p_rfc", OracleDbType.Varchar2, strCLM);
                cmd.agregarOUTParametro("p_mca_valido", OracleDbType.Varchar2, 100);
                cmd.agregarOUTParametro("p_valida", OracleDbType.Varchar2, 100);

                objRow = cmd.ejecutarRegistroSP();

                return objRow;
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.validaCLMServFun() : " + ex.Message);
        }
    }

    public DataRow validaIMC(string Peso, string Estatura)
    {
        MCommand cmd = new MCommand();
        DataRow objRow = null;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strPaqueteVida + ".p_calcula_imc";

                cmd.agregarINParametro("p_peso", OracleDbType.Varchar2, Peso);
                cmd.agregarINParametro("p_estatura", OracleDbType.Varchar2, Estatura);
                cmd.agregarOUTParametro("p_mca_valido", OracleDbType.Varchar2, 100);

                objRow = cmd.ejecutarRegistroSP();

                return objRow;
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.validaIMC() : " + ex.Message);
        }
    }

    public DataRow validaOcupacion(string CodOcupacion)
    {
        MCommand cmd = new MCommand();
        DataRow objRow = null;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strPaqueteVida + ".p_valida_ocupacion";

                cmd.agregarINParametro("p_cod_profesion", OracleDbType.Varchar2, CodOcupacion);
                cmd.agregarOUTParametro("p_nom_profesion", OracleDbType.Varchar2, 100);
                cmd.agregarOUTParametro("p_mca_valido", OracleDbType.Varchar2, 100);

                objRow = cmd.ejecutarRegistroSP();

                return objRow;
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.validaOcupacion() : " + ex.Message);
        }
    }

    public DataRow validaCumulos(string ramo, string modalidad, string contrato, string moneda, string Edad,
                                 string nombre, string apeM, string apeP, string fechaNac, string sumAseg)
    {
        MCommand cmd = new MCommand();
        DataRow objRow = null;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                //-------------------------->C15<--------------------------------
                cmd.Connection = conexion;
                cmd.CommandText = strEsquemaValidaciones + strPaqueteParaWM + ".p_obtiene_cumulos_sa";

                cmd.agregarINParametro("p_cod_portal", OracleDbType.Int32, 2);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, Int32.Parse(ramo));
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Int32, Int32.Parse(modalidad));
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Int32, Int32.Parse(contrato));
                cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Int32.Parse(moneda));
                cmd.agregarINParametro("p_edad", OracleDbType.Int32, Int32.Parse(Edad));
                cmd.agregarINParametro("p_nom_tercero", OracleDbType.Varchar2, nombre);
                cmd.agregarINParametro("p_ape_paterno", OracleDbType.Varchar2, apeP);
                cmd.agregarINParametro("p_ape_materno", OracleDbType.Varchar2, apeM);
                cmd.agregarINParametro("p_fec_nacimiento", OracleDbType.Date, Convert.ToDateTime(fechaNac));
                cmd.agregarINParametro("p_suma_asegurada", OracleDbType.Double, double.Parse(sumAseg));
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);
                cmd.agregarOUTParametro("p_cumulo_sa", OracleDbType.Varchar2, 100);
                cmd.agregarOUTParametro("p_mca_valido", OracleDbType.Varchar2, 100);
                cmd.agregarOUTParametro("p_error", OracleDbType.Varchar2, 100);

                objRow = cmd.ejecutarRegistroSP();

                return objRow;
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.validaCumulos() : " + ex.Message);
        }
    }

    //---------->C22<---------
    /// <summary>
    ///     Se obtienen los exámenes que se deben realizar.
    /// </summary>
    /// <param name="ramo">codigo del ramo</param>
    /// <param name="modalidad">codigo de modalidad</param>
    /// <param name="contrato">numero de contrato</param>
    /// <param name="moneda">tipo de moneda</param>
    /// <param name="Edad">edad</param>
    /// <returns></returns>
    /// 
    public DataRow validaExamenes(string ramo, string modalidad, string contrato, string moneda, string Edad, string sumAseg,
                                  string nombre, string apeM, string apeP, string fechaNac)
    {
        MCommand cmd = new MCommand();
        DataRow objRow = null;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strEsquemaValidaciones + strPaqueteParaWM + ".p_valida_examenes";

                cmd.agregarINParametro("p_cod_portal", OracleDbType.Int32, 2);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, Int32.Parse(ramo));
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Int32, Int32.Parse(modalidad));
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Int32, Int32.Parse(contrato));
                cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Int32.Parse(moneda));
                cmd.agregarINParametro("p_edad", OracleDbType.Int32, Int32.Parse(Edad));
                cmd.agregarINParametro("p_suma_asegurada", OracleDbType.Double, double.Parse(sumAseg));
                cmd.agregarINParametro("p_nom_tercero", OracleDbType.Varchar2, nombre);
                cmd.agregarINParametro("p_ape_paterno", OracleDbType.Varchar2, apeP);
                cmd.agregarINParametro("p_ape_materno", OracleDbType.Varchar2, apeM);
                cmd.agregarINParametro("p_fec_nacimiento", OracleDbType.Date, Convert.ToDateTime(fechaNac));
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);
                cmd.agregarOUTParametro("p_mensaje", OracleDbType.Varchar2, 500);

                objRow = cmd.ejecutarRegistroSP();

                return objRow;
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.validaExamenes() : " + ex.Message);
        }
    }

    // <--- C9 --->
    /// <summary>
    /// Método encargado de validar si una póliza o solicitud se imprime.
    /// </summary>
    /// <param name="contrato">número de contrato</param>
    /// <param name="ramo">ramo</param>
    /// <param name="modalidad">modalidad</param>
    /// <returns>Devuelve un Datarow resultado de la consulta</returns>
    public DataRow validaImpresion(int contrato, int ramo, int modalidad)
    {
        MCommand cmd = new MCommand();
        DataRow objRow = null;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strEsquemaValidaciones + strPaqueteParaWM + ".p_valida_impr_soli";
                cmd.agregarINParametro("p_cod_portal", OracleDbType.Int32, 2);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, ramo);
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Int32, modalidad);
                cmd.agregarINParametro("p_num_contrato ", OracleDbType.Double, contrato);
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);
                cmd.agregarOUTParametro("p_imprime_sol", OracleDbType.Varchar2, 80);

                objRow = cmd.ejecutarRegistroSP();

                return objRow;
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.validaImpresion() : " + ex.Message);
        }
    }



    public DataTable devuelveCuestionario(int codigoRamo, int modalidad, int contrato)
    {
        MCommand cmd = new MCommand();
        DataSet objDataSet = new DataSet();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                //<-----------C18-C22-------------->
                cmd.CommandText = strEsquemaValidaciones + strPaqueteParaWM + ".p_recupera_cuestionario";
                cmd.agregarINParametro("p_cod_portal", OracleDbType.Int32, 2);
                cmd.agregarINParametro("cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, codigoRamo);
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Int32, modalidad);
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Double, contrato);
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Now.Date);
                cmd.agregarOUTParametro("p_cuestionario", OracleDbType.RefCursor, 2000);

                objDataSet = cmd.ejecutarRefCursorSP();

                DataTable dtCuestionario = objDataSet.Tables[0];
                //<-----------C18--------------->

                return dtCuestionario;
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.devuelveCuestionario() : " + ex.Message);
        }
    }

    //------------------------------>C16<----------------------------
    /// <summary>
    ///     Valida la prima mínima
    /// </summary>
    /// <param name="strPrima">Valor de la prima</param>
    /// <param name="Moneda">Tipo de moneda</param>
    /// <param name="strFormaPago">Forma de pago seleccionada</param>
    /// <param name="codPortal">Id del portal</param>
    /// <param name="codCia">Id de la compañia</param>
    /// <param name="codRamo">Id del ramo</param>
    /// <param name="codModalidad">Modalidad de la emisión</param>
    /// <param name="numContrato">Numero de contrato</param>
    /// <returns></returns>
    public DataRow validaPrimaMinima(string strPrima, int Moneda, string strFormaPago,
                                    string codPortal, string codCia, string codRamo,
                                    string codModalidad, string numContrato)
    {


        MCommand cmd = new MCommand();
        DataRow objRow = null;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strEsquemaValidaciones + strPaqueteParaWM + ".p_valida_prima_minima";

                cmd.agregarINParametro("p_cod_portal", OracleDbType.Int32, Int32.Parse(codPortal));
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, Int32.Parse(codCia));
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, Int32.Parse(codRamo));
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Int32, Int32.Parse(codModalidad));
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Int32, Int32.Parse(numContrato));
                cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Moneda);
                cmd.agregarINParametro("p_cod_forma_pago", OracleDbType.Int32, Int32.Parse(strFormaPago));
                cmd.agregarINParametro("p_prima", OracleDbType.Double, Double.Parse(strPrima));
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);
                cmd.agregarOUTParametro("p_mca_valido", OracleDbType.Varchar2, 100);
                cmd.agregarOUTParametro("p_error", OracleDbType.Varchar2, 100);

                objRow = cmd.ejecutarRegistroSP();

                return objRow;
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.validaPrimaMinima() : " + ex.Message);
        }
    }


    public DataRow InsertarBenefEnSol(string strSolicitud, string TipDocum, string codDocum, string tipBenef,
                                      string participacion, int Secuencia)
    {
        MCommand cmd = new MCommand();
        DataRow objRow = null;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strPaqueteVida + ".p_inserta_p2000060";

                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, strSolicitud);
                cmd.agregarINParametro("p_tip_docum", OracleDbType.Varchar2, TipDocum);
                cmd.agregarINParametro("p_cod_docum", OracleDbType.Varchar2, codDocum);
                cmd.agregarINParametro("p_tip_benef", OracleDbType.Varchar2, tipBenef);
                cmd.agregarINParametro("p_pct_participacion", OracleDbType.Varchar2, participacion);
                cmd.agregarINParametro("p_num_riesgo", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_num_secu", OracleDbType.Int32, Secuencia);
                cmd.agregarOUTParametro("p_mca_valida", OracleDbType.Varchar2, 100);

                objRow = cmd.ejecutarRegistroSP();

                return objRow;
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.InsertarBenefEnSol() : " + ex.Message);
        }
    }

    //C3
    /// <summary>
    /// Valida la politica de lavado de dinero para mostrar al usuario un mensaje indicandole
    /// los documentos que debe adjuntar segun sean las sumas de prima neta que obtenga
    /// </summary>
    /// <param name="strPrima">Valor de prima neta</param>
    /// <param name="Moneda">Moneda</param>
    /// <param name="strFormaPago"></param>
    /// <returns>Mensaje indicando al usuario los documentos que debe adjuntar</returns>
    public DataRow validaPoliticaLavadoDeDinero(string codPortal, string codCia, string codRamo,
                                                string codModalidad, string numContrato, int Moneda, string strPrima)
    {
        MCommand cmd = new MCommand();
        DataRow objRow = null;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strEsquemaValidaciones + strPaqueteParaWM + ".p_valida_lavado_dinero";

                cmd.agregarINParametro("p_cod_portal", OracleDbType.Int32, Int32.Parse(codPortal));
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, Int32.Parse(codCia));
                cmd.agregarINParametro("p_cod_ramo ", OracleDbType.Int32, Int32.Parse(codRamo));
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Int32, Int32.Parse(codModalidad));
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Int32, Int32.Parse(numContrato));
                cmd.agregarINParametro("p_cod_mon", OracleDbType.Int32, Moneda);
                cmd.agregarINParametro("p_prima", OracleDbType.Double, Double.Parse(strPrima));
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);
                cmd.agregarOUTParametro("p_mensaje", OracleDbType.Varchar2, 100);

                objRow = cmd.ejecutarRegistroSP();

                return objRow;
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.p_valida_lavado_dinero() : " + ex.Message);
        }
    }

    //---------------->C5<---------------
    /// <summary>
    ///     Este método llama el procedimiento almacendado que retorna el cuerpo del mensaje
    ///     que se le enviará al agente a la hora de hacer la emision.
    /// </summary>
    /// <param name="portal">Id del portal</param>
    /// <param name="compania">Id de la compañia</param>
    /// <returns>Retorna el mensaje para ser enviado por correo electrónico</returns>
    public string obtieneMensajecorreo(int ramo, int modalidad, int contrato)
    {
        MCommand cmd = new MCommand();
        DataRow objRow = null;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strEsquemaValidaciones + strPaqueteParaWM + ".p_correo_agente";

                cmd.agregarINParametro("p_cod_portal", OracleDbType.Int32, 2);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, ramo);
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Int32, modalidad);
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Int32, contrato);
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);
                cmd.agregarOUTParametro("p_mensaje", OracleDbType.Varchar2, 1000);

                objRow = cmd.ejecutarRegistroSP();

                return objRow["p_mensaje"].ToString();
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.obtieneMensajecorreo() : " + ex.Message);
        }
    }

    //-------------------------->C4<---------------------------
    /// <summary>
    ///     Este método se encarga de consultar el procedimiento que verifica si el
    ///     beneficiario tiene o no antecedentes OII
    /// </summary>
    /// <param name="nombre">Nombre</param>
    /// <param name="sexo">Genero</param>
    /// <param name="fecNac">Fecha de nacimiento</param>
    /// <returns>Retorna el Datarow resultado de la consulta</returns>
    public DataRow validaAntecedentesOII(string nombre, string sexo, string fecNac)
    {
        MCommand cmd = new MCommand();
        DataRow objRow = null;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strEsquemaValidaciones + ".EV_K_AP2300440_MMX.p_consulta_oii";

                cmd.agregarINParametro("p_nombre", OracleDbType.Varchar2, nombre);
                cmd.agregarINParametro("p_sexo", OracleDbType.Varchar2, sexo);
                cmd.agregarINParametro("p_fecha_nacimiento", OracleDbType.Varchar2, fecNac);
                cmd.agregarOUTParametro("p_mca_valido", OracleDbType.Varchar2, 100);
                cmd.agregarOUTParametro("p_error", OracleDbType.Varchar2, 100);

                objRow = cmd.ejecutarRegistroSP();

                return objRow;
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.validaAntecedentesOII() : " + ex.Message);
        }
    }

    //----------------------->C6<--------------------------
    /// <summary>
    ///     Se agrega en la bitacora la suscripcion debido a que en el flujo ram se realizó 
    ///     una solicitud
    /// </summary>
    /// <param name="p_wf_ot_m_ot"></param>
    /// <param name="p_cod_usr">Usuario</param>
    /// <param name="descripcion">Descripcion</param>
    public void solicitudSuscripcion(string p_wf_ot_m_ot, int p_cod_usr, string descripcion)
    {
        MCommand cmd = new MCommand();
        int wf_ot_m_ot;

        try
        {
            if (p_wf_ot_m_ot != "")
                wf_ot_m_ot = Int32.Parse(p_wf_ot_m_ot);
            else
                wf_ot_m_ot = 0;

            using (OracleConnection conexion = MConexion.getConexion("ConnectionSeGA"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "USRWORKF.WF_INSERTA_BITACORA_OT";

                cmd.agregarINParametro("p_wf_ot_m_ot", OracleDbType.Int32, wf_ot_m_ot);
                cmd.agregarINParametro("p_ntseg_c_acceso", OracleDbType.Int32, p_cod_usr);
                cmd.agregarINParametro("p_wf_sis_c_esta", OracleDbType.Int32, 214);
                cmd.agregarINParametro("p_wf_sis_c_estt", OracleDbType.Int32, 118);
                cmd.agregarINParametro("p_OBSERVA_OBSE", OracleDbType.Varchar2, descripcion);
                cmd.agregarINParametro("p_usrasig_asig_int", OracleDbType.Int32, p_cod_usr);
                cmd.agregarINParametro("p_tipo_motivo", OracleDbType.Int32, 0);
                cmd.agregarINParametro("p_id_motivo", OracleDbType.Int32, 0);
                cmd.agregarINParametro("p_OBSERVA_AGEN", OracleDbType.Varchar2, null);

                cmd.ejecutarSP();
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.solicitudSuscripcion() : " + ex.Message);
        }
    }

    // <--- C11 --->
    /// <summary>
    /// Método que consulta los beneficiarios según el tipo de seguro.
    /// </summary>
    /// <param name="ramo">ramo</param>
    /// <param name="Modalidad">modalidad</param>
    /// <param name="contrato">número de contrato seleccionado</param>
    /// <param name="tipoSeguro">tipo de seguro seleccionado</param>
    /// <param name="tipoBeneficiario">tipo de beneficiario seleccionado</param>
    /// <returns>DataTable que contiene los beneficiarios que cumplen con los parámetros ingresados</returns>
    public DataTable getParentescoSeguro(int ramo, string Modalidad, int contrato, string tipoSeguro,
        int tipoBeneficiario)
    {
        MCommand cmd = new MCommand();
        CDListaValor objListaValor = new CDListaValor(ramo);
        DataSet objDS = new DataSet();
        try
        {
            if (tipoBeneficiario == 0)
            {
                throw new Exception("Debe seleccionar un Beneficiario");
            }

            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strEsquemaValidaciones + strPaqueteParaWM + ".p_obtiene_parentesco";

                cmd.agregarINParametro("p_cod_portal", OracleDbType.Double, 2);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Double, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Double, ramo);
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Double, Modalidad);
                cmd.agregarINParametro("p_num_contrato ", OracleDbType.Double, contrato);
                //<--- C21 --->
                cmd.agregarINParametro("p_tip_benef", OracleDbType.Varchar2, tipoBeneficiario);
                //<----------->
                cmd.agregarINParametro("p_tipo_seguro", OracleDbType.Varchar2, tipoSeguro);
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);
                cmd.agregarOUTParametro("p_parentesco_bene", OracleDbType.RefCursor, 0);

                objDS = cmd.ejecutarRefCursorSP();
            }

            if (objDS.Tables[0].Rows.Count < 1)
                throw new Exception("No hay datos");
            else
                return objDS.Tables[0];
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getParentescoSeguro() : " + ex.Message);
        }
    }

    //<--- C20 --->
    /// <summary>
    /// Método que consulta los tipos de beneficiario.
    /// </summary>
    /// <returns>DataTable que contiene los tipos de beneficiario</returns>
    public DataTable getTipoBeneficiario()
    {
        MCommand cmd = new MCommand();
        DataSet objDS = new DataSet();
        DataTable dt = new DataTable();
        DataRow[] dr3;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strEsquemaValidaciones + strPaqueteParaWM + ".p_tip_benef";

                cmd.agregarOUTParametro("pcursor_tip_benef", OracleDbType.RefCursor, 0);

                objDS = cmd.ejecutarRefCursorSP();
            }

            if (objDS.Tables[0].Rows.Count < 1)
                throw new Exception("No hay datos");
            else
            {
                dt.Columns.Add("COD_VALOR").DataType = System.Type.GetType("System.Int32");
                dt.Columns.Add("NOM_VALOR").DataType = System.Type.GetType("System.String");

                foreach (DataRow dr in objDS.Tables[0].Rows)
                {
                    DataRow dr2 = dt.NewRow();

                    dr2["COD_VALOR"] = dr["COD_VALOR"];
                    dr2["NOM_VALOR"] = dr["NOM_VALOR"];

                    dt.Rows.Add(dr2);
                }


                dr3 = dt.Select("", "COD_VALOR ASC");
                dt = dr3.CopyToDataTable();

                return dt;
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getTipoBeneficiario() : " + ex.Message);
        }
    }

    // -------------------------------->C10--------------------------------->
    /// <summary>
    /// Método que valida si se realiza una póliza o una solicitud.
    /// </summary>
    /// <param name="ramo">ramo</param>
    /// <param name="Modalidad">modalidad</param>
    /// <param name="contrato">número de contrato</param>
    /// <returns>DataRow que contiene S o N para imprimir póliza o solicitud.</returns>
    public DataRow validaImprimePolizaSolicitud(int ramo, int modalidad, int contrato)
    {
        MCommand cmd = new MCommand();
        DataRow objRow = null;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                //----------------- llamado del paquete ---------------------
                cmd.CommandText = strEsquemaValidaciones + strPaqueteParaWM + ".p_valida_poli_soli";

                cmd.agregarINParametro("p_cod_portal", OracleDbType.Int32, 2);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, ramo);
                cmd.agregarINParametro("p_cod_modalidad", OracleDbType.Int32, modalidad);
                cmd.agregarINParametro("p_num_contrato ", OracleDbType.Double, contrato);
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);
                cmd.agregarOUTParametro("p_poli_soli", OracleDbType.Varchar2, 80);

                objRow = cmd.ejecutarRegistroSP();

                return objRow;
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.validaImprimePolizaSolicitud() : " + ex.Message);
        }
    }

    //---------------------------->C7<------------------------------
    /// <summary>
    ///     Consulta los tipos de seguro que debe mostrar en la zona beneficiarios
    /// </summary>
    /// <param name="CodigoRamo">Numero del ramo</param>
    /// <param name="contrato">Numero de contrato</param>
    /// <param name="modalidad">Numero de la modalidad</param>
    /// <returns>Dataset con los seguros obtenidos para mostrar en los radio buttons</returns>
    public DataTable getObtieneTipoSeguros(int CodigoRamo, int contrato, int modalidad, string coberturas)
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataSet objDataSet = new DataSet();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strEsquemaValidaciones + strPaqueteParaWM + ".p_obtiene_tipo_seguros";

                cmd.agregarINParametro("p_portal", OracleDbType.Int32, 2);
                cmd.agregarINParametro("cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodigoRamo);
                cmd.agregarINParametro("p_modalidad", OracleDbType.Int32, modalidad);
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Double, contrato);
                cmd.agregarINParametro("p_coberturas", OracleDbType.Varchar2, coberturas);
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);
                cmd.agregarOUTParametro("p_seguros", OracleDbType.RefCursor, 2000);

                objDataSet = cmd.ejecutarRefCursorSP();

                return objDataSet.Tables[0];
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getObtieneTipoSeguros() : " + ex.Message);
        }
    }

    //---------------------------->C7<------------------------------
    /// <summary>
    ///     Consulta el mensaje para el tooltip de adjuntar archivo
    /// </summary>
    /// <param name="CodigoRamo">Numero del ramo</param>
    /// <param name="contrato">Numero de contrato</param>
    /// <param name="modalidad">Numero de la modalidad</param>
    /// <returns>Cadena que contiene los archivos que se deben adjuntar</returns>
    public string getValidaDocumento(int CodigoRamo, int contrato, int modalidad)
    {
        OracleCommand Comando = new OracleCommand();
        MCommand cmd = new MCommand();
        DataRow objDataRow;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = strEsquemaValidaciones + strPaqueteParaWM + ".p_valida_documento";

                cmd.agregarINParametro("p_portal", OracleDbType.Int32, 2);
                cmd.agregarINParametro("cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, CodigoRamo);
                cmd.agregarINParametro("p_modalidad", OracleDbType.Int32, modalidad);
                cmd.agregarINParametro("p_num_contrato", OracleDbType.Double, contrato);
                cmd.agregarINParametro("p_fec_validez", OracleDbType.Date, DateTime.Today);
                cmd.agregarOUTParametro("p_documentos", OracleDbType.Varchar2, 2000);

                objDataRow = cmd.ejecutarRegistroSP();

                return objDataRow["p_documentos"].ToString();
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getValidaDocumento() : " + ex.Message);
        }
    }

    /// <summary>
    /// Establece el estado de capturado al folio ram
    /// </summary>
    /// <param name="p_wf_ot_m_ot">Id de orden de trabajo</param>
    /// <returns>Resultado de la operación de establecer estado</returns>
    public bool setEstadoRAMCapturado(string p_wf_ot_m_ot)
    {
        bool result = false;
        MCommand cmd = new MCommand();
        int wf_ot_m_ot;

        try
        {
            if (p_wf_ot_m_ot != "")
                wf_ot_m_ot = Int32.Parse(p_wf_ot_m_ot);
            else
                wf_ot_m_ot = 0;

            using (OracleConnection conexion = MConexion.getConexion("ConnectionSeGA"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "USRWORKF.WF_INSERTA_BITACORA_OT";

                cmd.agregarINParametro("p_wf_ot_m_ot", OracleDbType.Double, wf_ot_m_ot);
                cmd.agregarINParametro("p_ntseg_c_acceso", OracleDbType.Double, ConfigurationManager.AppSettings["usuarioSeGARAM"].ToString());
                cmd.agregarINParametro("p_wf_sis_c_esta", OracleDbType.Double, 110);
                cmd.agregarINParametro("p_wf_sis_c_estt", OracleDbType.Double, 101);
                cmd.agregarINParametro("p_OBSERVA_OBSE", OracleDbType.Varchar2, "");
                cmd.agregarINParametro("p_usrasig_asig_int", OracleDbType.Double, null);
                cmd.agregarINParametro("p_tipo_motivo", OracleDbType.Double, null);
                cmd.agregarINParametro("p_id_motivo", OracleDbType.Double, null);
                cmd.agregarINParametro("p_OBSERVA_AGEN", OracleDbType.Varchar2, null);

                cmd.ejecutarSP();

                result = true;
            }

            //using (OracleConnection conexion = MConexion.getConexion("ConnectionSeGA"))
            //{
            //    cmd.Connection = conexion;
            //    cmd.CommandText = "USRWORKF.WF_INSERTA_BITACORA_OT";

            //    cmd.agregarINParametro("p_wf_ot_m_ot", OracleDbType.Int32, wf_ot_m_ot);
            //    cmd.agregarINParametro("p_ntseg_c_acceso", OracleDbType.Int32, p_cod_usr);
            //    cmd.agregarINParametro("p_wf_sis_c_esta", OracleDbType.Int32, 214);
            //    cmd.agregarINParametro("p_wf_sis_c_estt", OracleDbType.Int32, 118);
            //    cmd.agregarINParametro("p_OBSERVA_OBSE", OracleDbType.Varchar2, descripcion);
            //    cmd.agregarINParametro("p_usrasig_asig_int", OracleDbType.Int32, p_cod_usr);
            //    cmd.agregarINParametro("p_tipo_motivo", OracleDbType.Int32, 0);
            //    cmd.agregarINParametro("p_id_motivo", OracleDbType.Int32, 0);
            //    cmd.agregarINParametro("p_OBSERVA_AGEN", OracleDbType.Varchar2, null);

            //    cmd.ejecutarSP();
            //}
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.setEstadoRAMCapturado() : " + ex.Message);
        }

        return result;
    }


    /// <summary>
    /// Obtiene la lista de los parametros para el Cobro de Millon Vida
    /// </summary>
    public DataTable getDatosCobro(int cod_cia, int cod_ramo, string Tabla, int Version)
    {
        DataSet objDS;
        DataTable dtblBanco = new DataTable();
        MCommand cmd = new MCommand();
        string strNOM_TABLA = Tabla;
        int iVERSION = Version;
        string COD_CAMPO = null;
        string PARAMETROS = null;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "EM_K_GEN_WS.GETLOV";

                cmd.agregarRETURNParametro("results", OracleDbType.RefCursor, 0);
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, cod_cia);
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, cod_ramo);
                cmd.agregarINParametro("p_cod_campo", OracleDbType.Varchar2, COD_CAMPO);
                cmd.agregarINParametro("p_nom_tabla", OracleDbType.Varchar2, strNOM_TABLA);
                cmd.agregarINParametro("p_cod_version", OracleDbType.Int32, iVERSION);
                cmd.agregarINParametro("p_pramaetros", OracleDbType.Varchar2, PARAMETROS);

                objDS = cmd.ejecutarRefCursorSP();

                dtblBanco = objDS.Tables[0];
            }
        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR EM_K_GEN_WS.GETLOV : " + ex.Message);
        }

        return dtblBanco;
    }

    //MV Cuadros de Comisión INI
    public string getcuadrocomMV(int agt, int ramo)
    {
        DataTable dtcuadrocom = new DataTable();
        CDListaValor objListaValor = new CDListaValor();
        string cuadrocom = "";
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                //dtcuadrocom = objListaValor.getCUADROS_COMISIONESVIDA(agt, conexion);
                Hashtable parametos = new Hashtable();
                parametos.Add("cod_ramo", ramo);
                parametos.Add("cod_agt", agt);
                dtcuadrocom = objListaValor.getListaValores(null, "G1000301_MMX", 1, parametos, conexion);
            }
            if (dtcuadrocom.Rows.Count > 0)
                cuadrocom = dtcuadrocom.Rows[0]["COD_CUADRO_COM"].ToString();
            else
                return cuadrocom;

        }
        catch (System.Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception("ERROR Catalogos.getcuadrocomMV() : " + ex.Message);
        }
        return cuadrocom;
    }
    //MV Cuadros de Comisión FIN
    //---------------------------->C24<------------------------------
    /// <summary>
    ///     Carga el catalogo de parentesco para el ramo 105
    /// </summary>
    /// 
    public DataTable getParentescoAseg()
    {
        CDListaValor objListavalor = new CDListaValor();
        DataTable dt = new DataTable();
        Hashtable parametros = new Hashtable();

        try
        {
            parametros.Add("cod_campo", "'COD_PARENTESCO'");
            parametros.Add("cod_idioma", "'ES'");
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                dt = objListavalor.getListaValores(null, ConfigurationManager.AppSettings["Tab_Parentesco_105"].ToString(), Convert.ToInt32(ConfigurationManager.AppSettings["Ver_Parentesco_105"].ToString()), parametros, conexion);
                return dt;
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("ERROR Catalogos.getParentesco(): " + ex.ToString());
            throw new Exception("ERROR Catalogos.getParentesco(): " + ex.ToString());
        }
    }

    public DataTable getDatosVariables(int COD_RAMO, OracleConnection conexion)
    {
        DataSet objDS;
        DataTable objTable = null;
        MCommand cmd = new MCommand();

        try
        {

            cmd.Connection = conexion;
            cmd.CommandText = "ED_K_COTIZADOR_GMI.F_OBTIENE_DV";

            cmd.agregarRETURNParametro("results", OracleDbType.RefCursor, 0);
            cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, COD_RAMO);

            objDS = cmd.ejecutarRefCursorSP();

            if (objDS != null)
            {
                return objDS.Tables[0];
            }

        }
        catch (Exception ex)
        {
            throw new Exception("ERROR ED_K_COTIZADOR_GMI.F_OBTIENE_DV : " + ex.Message);
        }
        return objTable;
    }

}