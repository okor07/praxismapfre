using MapfreMMX.oracle;
using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for csFacturacion
/// </summary>
public class csFacturacion
{
    public string guardaFacturacion(int codCia, string tipDocum, int regFiscal, string codPostal, string regSocietario, string numPoliza, string rfc)
    {
        MCommand cmd = new MCommand();
        DataRow dataRow = null;
        DataRow myRow = null;
        string result = string.Empty;
        try
        {
            using (OracleConnection conn = MConnection.getConexion(ConfigurationManager.AppSettings["ConnectionTW"]))
            {
                cmd.Connection = conn;

                cmd.CommandText = "tron2000.gc_k_a1001356_mmx_mmx.p_devuelve_dts_fsc";
                cmd.agregarINParametro("p_poliza", OracleDbType.Varchar2, numPoliza);
                cmd.agregarINParametro("p_rfc", OracleDbType.Varchar2, rfc);
                cmd.agregarOUTParametro("p_nom_tercero", OracleDbType.Varchar2, 500);
                cmd.agregarOUTParametro("p_ape1_tercero", OracleDbType.Varchar2, 500);
                cmd.agregarOUTParametro("p_ape2_tercero", OracleDbType.Varchar2, 500);
                cmd.agregarOUTParametro("p_mca_fisico", OracleDbType.Varchar2, 500);
                cmd.agregarOUTParametro("p_cod_reg_fiscal", OracleDbType.Int32, 5);
                cmd.agregarOUTParametro("p_nom_domicilio1", OracleDbType.Varchar2, 500);
                cmd.agregarOUTParametro("p_nom_domicilio2", OracleDbType.Varchar2, 500);
                cmd.agregarOUTParametro("p_num_ext", OracleDbType.Varchar2, 500);
                cmd.agregarOUTParametro("p_num_int", OracleDbType.Varchar2, 500);
                cmd.agregarOUTParametro("p_cod_pais", OracleDbType.Varchar2, 500);
                cmd.agregarOUTParametro("p_nom_pais", OracleDbType.Varchar2, 500);
                cmd.agregarOUTParametro("p_cod_prov", OracleDbType.Int32, 5);
                cmd.agregarOUTParametro("p_nom_prov", OracleDbType.Varchar2, 500);
                cmd.agregarOUTParametro("p_cod_postal", OracleDbType.Varchar2, 500);
                cmd.agregarOUTParametro("p_cod_estado", OracleDbType.Int32, 10);
                cmd.agregarOUTParametro("p_nom_estado", OracleDbType.Varchar2, 500);
                cmd.agregarOUTParametro("p_tlf_numero1", OracleDbType.Varchar2, 500);
                cmd.agregarOUTParametro("p_tlf_numero2", OracleDbType.Varchar2, 500);
                cmd.agregarOUTParametro("p_email1", OracleDbType.Varchar2, 500);
                cmd.agregarOUTParametro("p_email2", OracleDbType.Varchar2, 500);
                dataRow = cmd.ejecutarRegistroSP();

                if (dataRow != null)
                {
                    var fisico = dataRow["p_mca_fisico"];
                    if (!dataRow.IsNull("p_mca_fisico"))
                    {
                        cmd = new MCommand();
                        if (Convert.ToString(dataRow["p_mca_fisico"]) == "S")
                            regSocietario = Convert.ToString(dataRow["p_ape1_tercero"]);
                        cmd.Connection = conn;
                        cmd.CommandText = "tron2000.GC_K_CARGA_MAS_DTS_FSC_2_MMX.p_carga_datos";
                        cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, codCia);
                        cmd.agregarINParametro("p_tip_docum", OracleDbType.Varchar2, tipDocum);
                        cmd.agregarINParametro("p_cod_docum", OracleDbType.Varchar2, rfc);
                        cmd.agregarINParametro("p_mca_fisico", OracleDbType.Varchar2, Convert.ToString(dataRow["p_mca_fisico"]));
                        cmd.agregarINParametro("p_reg_fiscal", OracleDbType.Int32, regFiscal);
                        cmd.agregarINParametro("p_nombre_razon", OracleDbType.Varchar2, Convert.ToString(dataRow["p_nom_tercero"]));
                        cmd.agregarINParametro("p_ape_paterno", OracleDbType.Varchar2, regSocietario);
                        cmd.agregarINParametro("p_ape_materno", OracleDbType.Varchar2, Convert.ToString(dataRow["p_ape2_tercero"]));
                        cmd.agregarINParametro("p_nom_domicilio1", OracleDbType.Varchar2, Convert.ToString(dataRow["p_nom_domicilio1"]));
                        cmd.agregarINParametro("p_nom_domicilio2", OracleDbType.Varchar2, Convert.ToString(dataRow["p_nom_domicilio2"]));
                        cmd.agregarINParametro("p_num_ext", OracleDbType.Varchar2, Convert.ToString(dataRow["p_num_ext"]));
                        cmd.agregarINParametro("p_num_int", OracleDbType.Varchar2, Convert.ToString(dataRow["p_num_int"]));
                        cmd.agregarINParametro("p_cod_postal", OracleDbType.Varchar2, codPostal);
                        cmd.agregarINParametro("p_cod_prov", OracleDbType.Int32, int.Parse(dataRow["p_cod_prov"].ToString()));
                        cmd.agregarINParametro("p_cod_estado", OracleDbType.Int32, Convert.ToString(dataRow["p_cod_estado"]));
                        cmd.agregarINParametro("p_cod_pais", OracleDbType.Varchar2, Convert.ToString(dataRow["p_cod_pais"]));
                        cmd.agregarINParametro("p_cod_usr", OracleDbType.Varchar2, "");
                        cmd.agregarINParametro("p_fec_actu", OracleDbType.Date, DateTime.Now);
                        cmd.agregarOUTParametro("p_proceso_val", OracleDbType.Double, 5);
                        cmd.agregarOUTParametro("p_mensaje_val", OracleDbType.Varchar2, 500);

                        myRow = cmd.ejecutarRegistroSP();

                        result = myRow["p_mensaje_val"].ToString();
                        cmd.removeAll();
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception("ERROR DArchivos.getDatosGeneralesPorRFCFical()", ex);
        }
        return result;
    }
}