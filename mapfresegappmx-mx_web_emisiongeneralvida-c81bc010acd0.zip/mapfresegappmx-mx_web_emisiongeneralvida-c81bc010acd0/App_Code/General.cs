﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MapfreMMX.util;

namespace Generales.Clases
{
    /// <summary>
    /// Summary description for General
    /// </summary>
    public class General
    {
        public static void llenaGridView(GridView objGridView, DataTable objTable, string sort)
        {
            objTable.DefaultView.Sort = sort;
            objGridView.DataSource = objTable.DefaultView.ToTable();
            objGridView.DataBind();
        }

        public static void llenaDropDown(DropDownList objDropDown, DataTable objTable, string value, string text, string indice)
        {
            objDropDown.DataSource = objTable;
            objDropDown.DataTextField = text;
            objDropDown.DataValueField = value;
            objDropDown.DataBind();
            if (indice != null)
                objDropDown.Items.Insert(0, new ListItem(indice, "0"));
        }

        public static void eliminaItems(DataTable objDataTable, string key_webConfig, string nom_campo)
        {
            string[] items = WebUtils.getAppSetting(key_webConfig).Split(',');
            ArrayList objDataRowCollection = new ArrayList();

            foreach (string item in items)
                objDataRowCollection.Add(objDataTable.Select(nom_campo + "='" + item + "'"));

            foreach (DataRow[] registros in objDataRowCollection)
            {
                foreach (DataRow registro in registros)
                    objDataTable.Rows.Remove(registro);
            }
        }

        /// <summary>
        /// Método que regresa una cadena en formato de tipo Moneda.
        /// </summary>
        /// <param name="strValor">Parámetro de tipo cadena que contiene el valor al que se le desea dar formato de Moneda.</param>
        /// <returns>Regresa una cadena con un valor en Formato de moneda, en caso de que el valor no pueda ser parseado, regresará el valor de la cadena Original.</returns>
        public string FormatoMoneda(string strValor)
        {
            string strValorConFormato = strValor;

            decimal dValor;
            if (Decimal.TryParse(strValorConFormato, out dValor))
            {
                strValorConFormato = string.Format("{0:C2}", dValor);
            }

            return strValorConFormato;
        }
    }
}