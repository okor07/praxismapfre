﻿//'****************************************************************************
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2008
//'Name of the file              : CLM.cs
//'Creation/Modification History :
//'Description                   :          
//'Modification                  : Marco A. Navarrete C. Indra SWLabs
//'C1                            : 12-05-2014
//                               : Se agregaron los datos FATCA.  
//´C2                            : Se agrega funcionalidad de requerimiento A27840 Segunda Fase Expediente Cliente
//'*****************************************************************************

/**********************************************************************************************************************
 * Héctor Díaz Tello HEDIAZTE (Indra)
 * A26580-Expediente Cliente
 * 15/04/2015
 * -->C-001: Se divide el domicilio del beneficiario en cadenas de 40 caracteres y se insertan en los campos
 *           domicilio1, domicilio2 y colonia
 **********************************************************************************************************************/

 
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using MapfreMMX.emision;
using MapfreMMX.oracle;
using MapfreMMX.util;
using MapfreMMX.clm;
using Oracle.DataAccess.Client;

/// <summary>
/// Summary description for CLM
/// </summary>
public class CLM : System.Web.UI.Page
{
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void setToken(string p_token, string[] arrParams)
    {
        ActualizaCLM objActualiza = new ActualizaCLM();
        Hashtable parametros = new Hashtable();
        try
        {
            parametros.Add("COD_SECTOR", 1);
            parametros.Add("COD_ORIGEN", WebUtils.getAppSetting("codOrigen"));
            parametros.Add("COD_USR", WebUtils.getAppSetting("codUsuario"));
            if (Session["numCotizacion"] != null)
            {
                parametros.Add("NUM_COTIZACION", Session["numCotizacion"].ToString());
            }
            foreach (string param in arrParams)
            {
                string[] dato = param.Split('=');
                if (dato[1] != "")
                    parametros.Add(dato[0], dato[1]);
            }

            using (OracleConnection conexion = MConnection.getConexion(ConfigurationManager.AppSettings["ConnectionTW"]))
            {
                objActualiza.FijaContexto(p_token, parametros, conexion);
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string[] getDatosCLM(string cod_docum, string tip_benef, string tip_docum)
    {
        CLMGeneral objGeneral = new CLMGeneral();
        ConsultaCLM objConsulta = new ConsultaCLM();
        DataTable tablaCLM = new DataTable();
        ArrayList arrDatosCLM = new ArrayList();

        using (OracleConnection conexion = MConnection.getConexion(ConfigurationManager.AppSettings["ConnectionTW"]))
        {
            if (tip_docum == "RFC")
                objGeneral = objConsulta.getDatosGeneralesPorRFC(1, cod_docum, null, null, null, conexion);
            else if (tip_docum == "CLM")
                objGeneral = objConsulta.getDatosGenerales(1, tip_docum, cod_docum, null, null, null, null, conexion);
        }

        if (objGeneral != null)
        {
            arrDatosCLM.Add(objGeneral.PERSONA.TIP_DOCUM);                  //[0]tip_docum
            arrDatosCLM.Add(objGeneral.PERSONA.COD_DOCUM);                  //[1]cod_docum

            if (objGeneral.MCA_FISICA == TipoPersona.Fisica)
            {
                CLMFisica objFisica = (CLMFisica)objGeneral.PERSONA;
                arrDatosCLM.Add("S");                                       //[2]mca_fisico
                arrDatosCLM.Add(objFisica.NOM_TERCERO);                     //[3]nom_tercero
                arrDatosCLM.Add(objFisica.APE1_TERCERO);                    //[4]ape1_tercero
                arrDatosCLM.Add(objFisica.APE2_TERCERO);                    //[5]ape2_tercero
                arrDatosCLM.Add(objFisica.getFEC_NACIMIENTOstring() +       //[6]fec_nacimiento
                    "|" + calculaEdad(objFisica.FEC_NACIMIENTO));           //   edad
                arrDatosCLM.Add(objFisica.COD_SEXO.ToString());             //[7]cod_sexo
                arrDatosCLM.Add(objFisica.COD_EST_CIVIL +                   //[8]cod_est_civil
                    "|" + objFisica.NOM_EST_CIVIL);                         //   nom_est_civil
                arrDatosCLM.Add(objFisica.COD_PROFESION +                   //[9]cod_profesion
                    "|" + objFisica.NOM_PROFESION);                         //   nom_profesion
                arrDatosCLM.Add(objFisica.COD_PARENTESCO +                  //[10]cod_parentesco
                    "|" + objFisica.NOM_PARENTESCO);                        //    nom_parentesco
                arrDatosCLM.Add(objFisica.TLF_MOVIL);                       //[11]tlf_movil
                arrDatosCLM.Add(objFisica.CVE_RFC);                         //[12]rfc
                arrDatosCLM.Add(objFisica.CURP);                            //[13]curp
                arrDatosCLM.Add(objFisica.COD_NACIONALIDAD +                //[14]cod_nacionalidad
                    "|" + objFisica.NOM_NACIONALIDAD);                      //    nom_nacionalidad
            }
            else
            {
                CLMMoral objMoral = (CLMMoral)objGeneral.PERSONA;
                arrDatosCLM.Add("N");                                       //[2]mca_fisico
                arrDatosCLM.Add(objMoral.RAZON_SOCIAL);                     //[3]razon_social
                arrDatosCLM.Add("");                                        //[4]
                arrDatosCLM.Add("");                                        //[5]
                arrDatosCLM.Add(objMoral.getFEC_CONSTITUCIONstring() +      //[6]fec_constitucion
                    "|" + calculaEdad(objMoral.FEC_CONSTITUCION));          //   edad
                arrDatosCLM.Add("");                                        //[7]
                arrDatosCLM.Add(objMoral.TIP_ACTIVIDAD +                    //[8]tip_actividad
                    "|" + objMoral.NOM_ACTIVIDAD);                          //   nom_actividad
                arrDatosCLM.Add(objMoral.NOM_CONTACTO);                     //[9]nom_contacto
                arrDatosCLM.Add(objMoral.TIP_CARGO +                        //[10]tip_cargo
                    "|" + objMoral.NOM_CARGO);                              //    nom_cargo
                arrDatosCLM.Add("");                                        //[11]
                arrDatosCLM.Add(objMoral.CVE_RFC);                          //[12]rfc
                arrDatosCLM.Add("");                                        //[13]
                arrDatosCLM.Add("");                                        //[14]
            }

            CLMContacto objContacto = objGeneral.CONTACTO;
            arrDatosCLM.Add(objContacto.DOMICILIO.NOM_DOMICILIO);           //[15]nom_domicilio
            arrDatosCLM.Add(objContacto.DOMICILIO.COLONIA);                 //[16]nom_colonia
            arrDatosCLM.Add(objContacto.DOMICILIO.COD_ESTADO +              //[17]cod_estado
                "|" + objContacto.DOMICILIO.NOM_ESTADO);                    //    nom_estado
            arrDatosCLM.Add(objContacto.DOMICILIO.COD_POBLACION +           //[18]cod_prov
                "|" + objContacto.DOMICILIO.NOM_POBLACION);                 //    nom_prov
            arrDatosCLM.Add(objContacto.DOMICILIO.CODIGO_POSTAL);           //[19]cod_postal
            arrDatosCLM.Add(objContacto.TLF_NUMERO);                        //[20]tlf_numero
            arrDatosCLM.Add(objContacto.EMAIL);                             //[21]email

            CLMFiscal objFiscal = objGeneral.FISCAL;
            arrDatosCLM.Add(objFiscal.DOMICILIO.NOM_DOMICILIO               //[22]Domicilio Fiscal
                + "|" + objFiscal.DOMICILIO.COLONIA
                + "|" + objFiscal.DOMICILIO.NOM_ESTADO
                + "|" + objFiscal.DOMICILIO.NOM_POBLACION
                + "|" + objFiscal.DOMICILIO.CODIGO_POSTAL
                + "|" + objFiscal.TLF_NUMERO
                + "|" + objFiscal.EMAIL);

            //C1
            arrDatosCLM.Add(objGeneral.DatosFATCA.MCA_PRODUCTO_FATCA);              //[22]marca si el ramo es producto fatca

            if (objGeneral.DatosFATCA.MCA_PRODUCTO_FATCA == "S")
            {
                arrDatosCLM.Add(objGeneral.DatosFATCA.COD_PAIS_REF_FISCAL              //[23]pais referencia fiscal
                + "|" + objGeneral.DatosFATCA.NOM_PAIS_REF_FISCAL);              //[23]pais referencia fiscal
                arrDatosCLM.Add(objGeneral.DatosFATCA.NOM_PAIS_NACIMIENTO              //[24]pais referencia fiscal
                + "|" + objGeneral.DatosFATCA.NOM_PAIS_NACIMIENTO);              //[24]pais referencia fiscal
                arrDatosCLM.Add(objGeneral.DatosFATCA.COD_PAIS_REP_LEGAL              //[25]pais referencia fiscal
                + "|" + objGeneral.DatosFATCA.NOM_PAIS_REP_LEGAL);              //[25]pais referencia fiscal
                arrDatosCLM.Add(objGeneral.DatosFATCA.COD_PAIS_FIS_DISTINTO1        //[26]pais referencia fiscal
                + "|" + objGeneral.DatosFATCA.NOM_PAIS_FIS_DISTINTO1);              //[26]pais referencia fiscal
                arrDatosCLM.Add(objGeneral.DatosFATCA.COD_PAIS_FIS_DISTINTO2        //[27]pais referencia fiscal
                + "|" + objGeneral.DatosFATCA.NOM_PAIS_FIS_DISTINTO2);              //[27]pais referencia fiscal
                arrDatosCLM.Add(objGeneral.DatosFATCA.COD_PAIS_FIS_DISTINTO3        //[28]pais referencia fiscal
                + "|" + objGeneral.DatosFATCA.NOM_PAIS_FIS_DISTINTO3);              //[28]pais referencia fiscal
                arrDatosCLM.Add(objGeneral.DatosFATCA.COD_PAIS_TRANSFERENCIA         //[29]pais referencia fiscal
                + "|" + objGeneral.DatosFATCA.NOM_PAIS_TRANFERENCIA);               //[29]pais referencia fiscal
                arrDatosCLM.Add(objGeneral.DatosFATCA.NUM_TIN);        //[30]pais referencia fiscal
            }

        }
        return (string[])arrDatosCLM.ToArray(typeof(string));
    }

    private int calculaEdad(DateTime fechaNacimiento, DateTime fechaVigencia)
    {
        int edad = fechaVigencia.Year - fechaNacimiento.Year;
        if (fechaNacimiento.DayOfYear > fechaVigencia.DayOfYear)
            edad--;
        return edad;
    }

    private int calculaEdad(DateTime fechaNacimiento)
    {
        return calculaEdad(fechaNacimiento, DateTime.Today);
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public string getDatosContexto(string p_token)
    {
        ActualizaCLM objActualiza = new ActualizaCLM();
        ConsultaCLM objConsulta = new ConsultaCLM();
        StringBuilder cadena = new StringBuilder();
        XMLRead objXML;
        try
        {
            using (OracleConnection conexion = MConnection.getConexion(ConfigurationManager.AppSettings["ConnectionTW"]))
            {
                objActualiza.CopiaContexto(p_token, conexion);

                string xml = objConsulta.getDatosContexto(p_token, conexion);
                objXML = new XMLRead(xml);
            }
            if (objXML.getNode("//cod_docum") != null)
                cadena.Append(objXML.getNode("//cod_docum").InnerText);
            if (objXML.getNode("//cod_gestor") != null)
                cadena.Append("|" + objXML.getNode("//cod_gestor").InnerText);
            return cadena.ToString();
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataRow altaTercero(string[] arrDatosTercero, string cod_ramo, string tip_benef)
    {
        ActualizaCLM objActualiza = new ActualizaCLM();
        StringBuilder XML = new StringBuilder();
        try
        {
            string cod_usr = WebUtils.getAppSetting("codUsuario");

            XML.Append("<XML><TERCERO>");
            foreach (string datos in arrDatosTercero)
            {
                string[] dato = datos.Split('=');
                XML.Append("<" + dato[0] + ">");
                XML.Append(dato[1]);
                XML.Append("</" + dato[0] + ">");
            }
            XML.Append("</TERCERO></XML>");

            using (OracleConnection conexion = MConnection.getConexion(ConfigurationManager.AppSettings["ConnectionTW"]))
            {
                return objActualiza.AltaTercero(XML.ToString(), cod_usr, cod_ramo, tip_benef, conexion);
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    /// <summary>
    /// 'C2 Se agregan parámetros string fecnac, string domicilio
    /// </summary>
    /// <param name="mca_fisico"></param>
    /// <param name="nom_tercero"></param>
    /// <param name="ape1_tercero"></param>
    /// <param name="ape2_tercero"></param>
    /// <param name="cod_parentesco"></param>
    /// <param name="fecnac"></param>
    /// <param name="domicilio"></param>
    /// <returns></returns>
    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public DataRow altaBeneficiario(string mca_fisico, string nom_tercero, string ape1_tercero, string ape2_tercero, string cod_parentesco, string fecnac, string domicilio, string tel, string mail)
    {
        ActualizaCLM objActualiza = new ActualizaCLM();
        CLMPersona objPersona = new CLMPersona();

        StringBuilder XML = new StringBuilder();
        try
        {
            //Datos Persona Fisica
            if (mca_fisico.Equals("S"))
            {
                CLMFisica objPFisica = new CLMFisica();
                objPFisica.NOM_TERCERO = nom_tercero;
                objPFisica.APE1_TERCERO = ape1_tercero;
                objPFisica.APE2_TERCERO = ape2_tercero;
                objPFisica.COD_PARENTESCO = cod_parentesco;
                //'C2
                objPFisica.FEC_NACIMIENTO = Convert.ToDateTime(fecnac);
                //'C2F

                objPersona = objPFisica;
                objPersona.TIP_PERSONA = TipoPersona.Fisica;
            }
            else
            {
                //Datos Persona Moral
                CLMMoral objPMoral = new CLMMoral();
                objPMoral.RAZON_SOCIAL = nom_tercero;
                //'C2
                objPMoral.FEC_CONSTITUCION = Convert.ToDateTime(fecnac);
                //'C2F

                objPersona = objPMoral;
                objPersona.TIP_PERSONA = TipoPersona.Moral;
            }
            //'C2
            objPersona.Direccion = new Direccion();
            if (domicilio.Length > 80) // C-001
            {
                objPersona.Direccion.DOMICILIO1 = domicilio.Substring(0, 40);
                objPersona.Direccion.DOMICILIO2 = domicilio.Substring(40, 40);
                objPersona.Direccion.COLONIA = domicilio.Substring(80);
            }
            else if (domicilio.Length > 40)
            {
                objPersona.Direccion.DOMICILIO1 = domicilio.Substring(0, 40);
                objPersona.Direccion.DOMICILIO2 = domicilio.Substring(40);
            }
            else
            {
                objPersona.Direccion.DOMICILIO1 = domicilio;
            }
            //'C2F

            //MU-2017-052841 INI
            objPersona.TELEFONO = tel;
            objPersona.MAIL = mail;
            //MU-2017-052841 FIN

            using (OracleConnection conexion = MConnection.getConexion(ConfigurationManager.AppSettings["ConnectionTW"]))
            {
                return objActualiza.AltaBeneficiario(objPersona, conexion);
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }

    public string getFolioCLM(string num_poliza, string num_spto)
    {
        ConsultaCLM objConsulta = new ConsultaCLM();
        using (OracleConnection conexion = MConnection.getConexion(ConfigurationManager.AppSettings["ConnectionTW"]))
        {
            return objConsulta.getFolioCLM(1, num_poliza, num_spto, conexion);
        }
    }

    [Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)]
    public void validaCopia(int ramo, string agente, string tip_benef, string cod_docum, string cotizacion,
                            string poliza_grupo, string contrato, string modalidad, string edad, string sexo,
                            string estado, string poblacion)
    {
        CDConsulta objConsulta = new CDConsulta();
        try
        {
            using (OracleConnection conexion = MConnection.getConexion(ConfigurationManager.AppSettings["ConnectionTW"]))
            {
                objConsulta.validaCopiaPersona(1, 1, ramo, agente, tip_benef,
                                            (cotizacion == string.Empty ? null : cotizacion),
                                            (poliza_grupo == string.Empty ? null : poliza_grupo),
                                            (contrato == string.Empty ? null : contrato),
                                            (modalidad == string.Empty ? null : modalidad),
                                            null, cod_docum, edad, sexo, estado, poblacion, conexion);
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
            throw new Exception(ex.Message);
        }
    }
    public DataSet GetCLMData(string CLM, int Indice)
    {
        DataSet objetoDS;
        MCommand cmd = new MCommand();

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "dc_k_clm_gestion.p_lee";

                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_tip_docum", OracleDbType.Varchar2, "CLM");
                cmd.agregarINParametro("p_cod_docum", OracleDbType.Varchar2, CLM);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_num_riesgo", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_num_spto", OracleDbType.Varchar2, null);
                cmd.agregarINParametro("p_otra_dir_pivotal", OracleDbType.Int32, 0);
                cmd.ejecutarSP();

                cmd.removeAll();

                objetoDS = GetDatosCLM(cmd, conexion);

            }
        }
        catch (Exception _error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("GetCLMData...", _error);
            throw new Exception("ERROR CLM.GetCLMData : " + _error.Message);
        }
        
        return objetoDS;
    }

    public DataSet GetDatosCLM(MCommand cmd, OracleConnection con)
    {

        DataRow result = null;
        DataSet objetoDS = new DataSet();

        try
        {
               cmd.CommandText = "dc_k_clm_gestion.p_devuelve";

                cmd.agregarINOUTParametro("p_mca_fisico", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_tip_docum", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_cod_docum", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_tip_docum_padre", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_cod_docum_padre", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_ape1_tercero", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_ape2_tercero", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_nom_tercero", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_cod_nacionalidad", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_nom_domicilio1", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_nom_domicilio2", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_nom_domicilio3", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_cod_pais", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_cod_estado", OracleDbType.Int32, 2, DBNull.Value);
                cmd.agregarINOUTParametro("p_cod_prov", OracleDbType.Int32, 5, DBNull.Value);
                cmd.agregarINOUTParametro("p_cod_postal", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_tlf_pais", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_tlf_zona", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_tlf_numero", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_email", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_nom_domicilio1_com", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_nom_domicilio2_com", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_nom_domicilio3_com", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_cod_pais_com", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_cod_estado_com", OracleDbType.Int32, 2, DBNull.Value);
                cmd.agregarINOUTParametro("p_cod_prov_com", OracleDbType.Int32, 5, DBNull.Value);
                cmd.agregarINOUTParametro("p_cod_postal_com", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_tlf_pais_com", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_tlf_zona_com", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_tlf_numero_com", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_email_com", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_tlf_movil", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_nom_contacto", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_tip_cargo", OracleDbType.Int32, 2, DBNull.Value);
                cmd.agregarINOUTParametro("p_tip_act_economica", OracleDbType.Int32, 2, DBNull.Value);
                cmd.agregarINOUTParametro("p_fec_nacimiento", OracleDbType.Date, 10, DBNull.Value);
                cmd.agregarINOUTParametro("p_cod_parentesco", OracleDbType.Int32, 9, DBNull.Value);
                cmd.agregarINOUTParametro("p_cod_est_civil", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_cod_profesion", OracleDbType.Int32, 9, DBNull.Value);
                cmd.agregarINOUTParametro("p_mca_sexo", OracleDbType.Varchar2, 2, DBNull.Value);
                cmd.agregarINOUTParametro("p_obs_asegurado", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_txt_aux2", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_txt_aux3", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_tip_modificacion", OracleDbType.Varchar2, 255, DBNull.Value);
                cmd.agregarINOUTParametro("p_num_riesgo", OracleDbType.Int32, 6, DBNull.Value);
                cmd.agregarINOUTParametro("p_rep_legal", OracleDbType.Varchar2, 500, DBNull.Value);
                cmd.agregarINOUTParametro("p_tip_identificacion", OracleDbType.Varchar2, 500, DBNull.Value);
                cmd.agregarINOUTParametro("p_num_identificacion", OracleDbType.Varchar2, 500, DBNull.Value);
                cmd.agregarINOUTParametro("p_pais_nacimiento", OracleDbType.Varchar2, 500, DBNull.Value);
                cmd.agregarINOUTParametro("p_cod_fea", OracleDbType.Varchar2, 100, DBNull.Value);
                cmd.agregarINOUTParametro("p_num_exterior", OracleDbType.Varchar2, 10, DBNull.Value);
                cmd.agregarINOUTParametro("p_num_interior", OracleDbType.Varchar2, 10, DBNull.Value);
                cmd.agregarINOUTParametro("p_num_exterior_com", OracleDbType.Varchar2, 10, DBNull.Value);
                cmd.agregarINOUTParametro("p_num_interior_com", OracleDbType.Varchar2, 10, DBNull.Value);
                cmd.agregarINOUTParametro("p_num_folio_mercantil", OracleDbType.Varchar2, 25, DBNull.Value);

                result = cmd.ejecutarRegistroSP();
        }
        catch (System.Exception _error)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("GetDatosCLM...", _error);
            throw new Exception("ERROR CLM.GetDatosCLM : " + _error.Message);
        }
        objetoDS.Tables.Add(result.Table);
        return objetoDS;
    }
}
