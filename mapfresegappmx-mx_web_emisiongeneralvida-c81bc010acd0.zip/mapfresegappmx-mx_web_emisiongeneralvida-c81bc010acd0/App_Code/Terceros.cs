﻿//'********************************************************************************************************************
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2010
//'Name of the file              : Terceros.cs
//'Creation/Modification History :
//'Modification                  : jdgomezc  Indra SWLabs
//'C1                            : jdgomezc - 30-12-2012 
//                               : Se pregunta si el parentezco corresponde a los
//                               : cógigos 18,19,16 en caso de ser así indica
//                               : que es una persona moral a 
//                               : objCLM.altaBeneficiario
//'C2                            : emontoya - 30-12-2012                               
//                               : Se inicializa el grid Fallecimiento y el grid
//                               : Remanente.
//'C3                            : Configuración de las columnas que conforman al
//                               : grid Fallecimiento y grid Remanente
//'C4                            : emontoya - 30-12-2012
//                               : Se elimina el enlace Adicionales para los beneficiarios
//                               : adicionales. Esta columna se usa para mostrar la 
//                               : información Relación con. Se configura además las 
//                               : columnas que se deben mostrar según el formato.
//'C5                            : emontoya - 30-12-2012
//'Description                   : Se agrega la configuración para el grid beneficiarios y
//                               : para el grid Remanentes.        
//'C6                            : Se agrega funcionalidad de requerimiento A27840 Segunda Fase Expediente Cliente    
//03052018                  
//'********************************************************************************************************************

using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for Terceros
/// </summary>
public class Agente
{
    private DataTable m_Agentes;
    private GridView m_gridAgt;

    public Agente()
	{
        m_Agentes = new DataTable();
        m_Agentes.Columns.Add("indice", Type.GetType("System.Int32"));
        m_Agentes.Columns.Add("cod_agt");
        m_Agentes.Columns.Add("nombre");
        m_Agentes.Columns.Add("porcentaje");
        m_Agentes.Columns.Add("cuadro_com");
        m_Agentes.Columns.Add("divisional");

        inicializaGrid();
    }

    #region Atributos

    public DataTable Agentes
    {
        set { m_Agentes = value; }
        get
        {
            m_Agentes.DefaultView.Sort = "indice";
            m_Agentes = m_Agentes.DefaultView.ToTable();
            return m_Agentes;
        }
    }

    public GridView Grid_Agentes
    {
        get
        {
            m_Agentes.DefaultView.Sort = "indice";
            m_gridAgt.DataSource = m_Agentes.DefaultView.ToTable();
            m_gridAgt.DataBind();
            return m_gridAgt;
        }
    }

    public string Return_Script
    {
        get
        {
            GridView grid = this.Grid_Agentes;
            StringWriter SW = new StringWriter();
            HtmlTextWriter HW = new HtmlTextWriter(SW);
            grid.RenderControl(HW);
            return SW.ToString();
        }
    }

    #endregion

    public void Insertar(string cod_agt, string nombre, string divisional, string porcentaje, string cuadro_com)
    {
        bool existe = false;
        for (int i = 0; i < m_Agentes.Rows.Count; i++)
        {
            if (m_Agentes.Rows[i]["cod_agt"].ToString() == cod_agt)
            {
                m_Agentes.Rows[i]["cod_agt"] = cod_agt;
                m_Agentes.Rows[i]["nombre"] = nombre;
                m_Agentes.Rows[i]["divisional"] = divisional;
                m_Agentes.Rows[i]["porcentaje"] = porcentaje;
                m_Agentes.Rows[i]["cuadro_com"] = cuadro_com;
                existe = true;
                break;
            }
        }

        if (!existe)
        {
            DataRow objDR = m_Agentes.NewRow();
            objDR["indice"] = m_Agentes.Rows.Count;
            objDR["cod_agt"] = cod_agt;
            objDR["nombre"] = nombre;
            objDR["divisional"] = divisional;
            objDR["porcentaje"] = porcentaje;
            objDR["cuadro_com"] = cuadro_com;
            m_Agentes.Rows.Add(objDR);
        }
    }

    public void Eliminar(string cod_agt)
    {
        bool eliminado = false;
        foreach (DataRow rowAgt in m_Agentes.Rows)
        {
            if (rowAgt["cod_agt"].ToString() == cod_agt)
            {
                if (Convert.ToInt32(rowAgt["indice"]) > 0)
                {
                    m_Agentes.Rows.Remove(rowAgt);
                    eliminado = true;
                    break;
                }
            }
        }

        if (eliminado)
        {
            for (int i = 0; i < m_Agentes.Rows.Count; i++)
                m_Agentes.Rows[i]["indice"] = i;
        }
    }

    public DataRow Modificar(string cod_agt)
    {
        foreach(DataRow rowAgt in m_Agentes.Rows)
        {
            if(rowAgt["cod_agt"].ToString() == cod_agt)
                return rowAgt;
        }
        return null;
    }

    private void inicializaGrid()
    {
        m_gridAgt = new GridView();
        m_gridAgt.ID = "grdAgentes";
        m_gridAgt.CssClass = "letraNormal";
        m_gridAgt.Width = Unit.Percentage(85);
        m_gridAgt.AutoGenerateColumns = false;
        m_gridAgt.HeaderStyle.Font.Bold = true;
        m_gridAgt.HeaderStyle.ForeColor = System.Drawing.Color.White;
        m_gridAgt.HeaderStyle.BackColor = System.Drawing.Color.WhiteSmoke;
        m_gridAgt.HeaderStyle.Wrap = false;

        BoundField objBField = new BoundField();
        objBField.DataField = "cod_agt";
        objBField.HeaderText = "Clave";
        objBField.ItemStyle.Width = Unit.Percentage(15);
        m_gridAgt.Columns.Add(objBField);

        objBField = new BoundField();
        objBField.DataField = "porcentaje";
        objBField.HeaderText = "Porcentaje";
        objBField.ItemStyle.Width = Unit.Percentage(15);
        m_gridAgt.Columns.Add(objBField);
        
        objBField = new BoundField();
        objBField.DataField = "nombre";
        objBField.HeaderText = "Nombre de los agentes";
        objBField.ItemStyle.Width = Unit.Percentage(30);
        m_gridAgt.Columns.Add(objBField);

        objBField = new BoundField();
        objBField.DataField = "divisional";
        objBField.HeaderText = "División";
        objBField.ItemStyle.Width = Unit.Percentage(40);
        m_gridAgt.Columns.Add(objBField);

        m_gridAgt.RowDataBound  += new GridViewRowEventHandler(Agente_RowDataBound);
    }

    private void Agente_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        string rowID = "";
        
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            rowID = "row" + e.Row.RowIndex;
            e.Row.Attributes.Add("id", rowID);
            e.Row.Attributes.Add("onmouseover", "this.style.cursor='hand';");
            e.Row.Attributes.Add("onclick", "seleccionaAgente('" + e.Row.Cells[0].Text + "', '" + rowID + "');this.style.backgroundColor='Gainsboro'");
            e.Row.Attributes.Add("ondblclick", "modificarAgente('" + e.Row.Cells[0].Text + "');this.style.backgroundColor='Gainsboro'");
        }
    }
}

public class Beneficiario
{
    private DataTable m_Beneficiarios;
  
    // <--- C2 --->
    private GridView m_gridBenef;
    private GridView m_gridFallecimiento;
    private GridView m_gridRemanente;
    //AEP BWMEILL. Millón Vida Fase 2. Nuevo tipo de beneficiario
    private GridView m_gridSobreviviente;
    // ------------
    private double m_Cod_Benef;
    
    private string m_Nom_Tipo;
    private int m_Tip_Benef;
    private int m_Nivel1;
    private int m_Nivel2;

    public Beneficiario()
    {
        m_Beneficiarios = new DataTable();
        m_Beneficiarios.Columns.Add("indice", Type.GetType("System.Double"));
        m_Beneficiarios.Columns.Add("cod_benef");
        m_Beneficiarios.Columns.Add("nombre");
        m_Beneficiarios.Columns.Add("paterno");
        m_Beneficiarios.Columns.Add("materno");
        m_Beneficiarios.Columns.Add("porcentaje");
        m_Beneficiarios.Columns.Add("cod_parent");
        m_Beneficiarios.Columns.Add("nom_parent");
        m_Beneficiarios.Columns.Add("tip_benef", Type.GetType("System.Int32"));
        m_Beneficiarios.Columns.Add("nivel1", Type.GetType("System.Int32"));
        m_Beneficiarios.Columns.Add("nivel2", Type.GetType("System.Int32"));
        m_Beneficiarios.Columns.Add("BF");
        m_Beneficiarios.Columns.Add("BM");
        m_Beneficiarios.Columns.Add("BR");
        m_Beneficiarios.Columns.Add("tip_docum");
        m_Beneficiarios.Columns.Add("cod_docum");
        //'C6
        m_Beneficiarios.Columns.Add("fecnac");
        m_Beneficiarios.Columns.Add("domicilio");
        int ramo = 0;
        try
        {
            ramo = Convert.ToInt32(HttpContext.Current.Session["RAMO"]);
        }
        catch
        {
            ramo = 0;
        }
        if (ramo == 105)
        {
         m_Beneficiarios.Columns.Add("asegurado");
        }

        //MU-2017-052841 INI
        m_Beneficiarios.Columns.Add("telefono");
        m_Beneficiarios.Columns.Add("mail");
        //MU-2017-052841 FIN

        inicializaGrid();

        m_Cod_Benef = 0;
        m_Tip_Benef = 6;
        m_Nom_Tipo = "";
        m_Nivel1 = 0;
        m_Nivel2 = 0;
    }
    

    #region Atributos

    public DataTable Beneficiarios
    {
        set { m_Beneficiarios = value; }
        get
        {
            m_Beneficiarios.DefaultView.Sort = "indice";
            m_Beneficiarios = m_Beneficiarios.DefaultView.ToTable();
            return m_Beneficiarios;
        }
    }

    
    public GridView Grid_Beneficiarios
    {
        get
        {
            m_Beneficiarios.DefaultView.Sort = "nivel1, tip_benef, nivel2";
            m_gridBenef.DataSource = m_Beneficiarios.DefaultView.ToTable();
            m_gridBenef.DataBind();
            return m_gridBenef;
        }
    }

    // <--- C5 --->
    public GridView Grid_Fallecimiento
    {
        get
        {
            m_Beneficiarios.DefaultView.Sort = "nivel1, tip_benef, nivel2";
            m_gridFallecimiento.DataSource = m_Beneficiarios.DefaultView.ToTable();
            m_gridFallecimiento.DataBind();
            return m_gridFallecimiento;
        }
    }
    //AEP BWMEILL. Millón Vida Fase 2. Nuevo tipo de beneficiario
    public GridView Grid_Sobreviviente
    {
        get
        {
            m_Beneficiarios.DefaultView.Sort = "nivel1, tip_benef, nivel2";
            m_gridSobreviviente.DataSource = m_Beneficiarios.DefaultView.ToTable();
            m_gridSobreviviente.DataBind();
            return m_gridSobreviviente;
        }
    }

    public GridView Grid_Remanente
    {
        get
        {
            m_Beneficiarios.DefaultView.Sort = "nivel1, tip_benef, nivel2";
            m_gridRemanente.DataSource = m_Beneficiarios.DefaultView.ToTable();
            m_gridRemanente.DataBind();
            return m_gridRemanente;
        }
    }
    // -----------

    public string Return_Script
    {
        get
        {
            GridView grid = this.Grid_Beneficiarios;
            StringWriter SW = new StringWriter();
            HtmlTextWriter HW = new HtmlTextWriter(SW);
            grid.RenderControl(HW);
            return SW.ToString();
        }
    }

    // <--- C5 --->
    public string Return_Script_Fallecimiento
    {
        get
        {
            GridView grid = this.Grid_Fallecimiento;
            StringWriter SW = new StringWriter();
            HtmlTextWriter HW = new HtmlTextWriter(SW);
            grid.RenderControl(HW);
            return SW.ToString();
        }
    }

    public string Return_Script_Remanente
    {
        get
        {
            GridView grid = this.Grid_Remanente;
            StringWriter SW = new StringWriter();
            HtmlTextWriter HW = new HtmlTextWriter(SW);
            grid.RenderControl(HW);
            return SW.ToString();
        }
    }
    // -------

    public double Cod_Benef
    {
        set
        {
            m_Cod_Benef = value;
            m_Nivel1 = Convert.ToInt32(m_Cod_Benef);
            m_Nivel2 = Convert.ToInt32((m_Cod_Benef - m_Nivel1) / 0.01);
            if (m_Tip_Benef == 6) m_Nivel2 = 0;
        }
        get
        {
            return m_Nivel1 + (m_Nivel2 * 0.01);
        }
    }

    public int Tip_Benef
    {
        set
        {
            m_Tip_Benef = value;
            switch (m_Tip_Benef)
            {
                case 13:
                    m_Nom_Tipo = "BF";
                    break;
                case 14:
                    m_Nom_Tipo = "BM";
                    break;
                case 15:
                    m_Nom_Tipo = "BR";
                    break;
                default:
                    m_Nom_Tipo = "BP";
                    break;
            }
        }
        get { return m_Tip_Benef; }
    }

    public int Nivel1
    {
        set { m_Nivel1 = value; }
        get { return m_Nivel1; }
    }

    #endregion

    //'C6 Se agregan parámetros string fecnac, string domicilio
    public void Insertar(string nombre, string paterno, string materno, string porcentaje, string cod_parent,
        string nom_parent, bool existe, string fecnac, string domicilio, string telefono, string mail)
    {
        if (existe)
        {
            for (int i = 0; i < m_Beneficiarios.Rows.Count; i++)
            {
                if (m_Beneficiarios.Rows[i]["cod_benef"].ToString() == m_Cod_Benef.ToString())
                {
                    m_Beneficiarios.Rows[i]["cod_benef"] = m_Cod_Benef;
                    m_Beneficiarios.Rows[i]["nombre"] = nombre;
                    m_Beneficiarios.Rows[i]["paterno"] = paterno;
                    m_Beneficiarios.Rows[i]["materno"] = materno;
                    m_Beneficiarios.Rows[i]["porcentaje"] = porcentaje;
                    m_Beneficiarios.Rows[i]["cod_parent"] = cod_parent;
                    m_Beneficiarios.Rows[i]["nom_parent"] = nom_parent;
                    m_Beneficiarios.Rows[i]["tip_benef"] = m_Tip_Benef;
                    m_Beneficiarios.Rows[i]["nivel1"] = m_Nivel1;
                    m_Beneficiarios.Rows[i]["nivel2"] = m_Nivel2;
                    //'C6
                    m_Beneficiarios.Rows[i]["fecnac"] = fecnac;
                    m_Beneficiarios.Rows[i]["domicilio"] = domicilio;
                    //'C6F
                    //MU-2017-052841 INI
                    m_Beneficiarios.Rows[i]["telefono"] = telefono;
                    m_Beneficiarios.Rows[i]["mail"] = mail;
                    //MU-2017-052841 FIN

                    if (m_Nom_Tipo != "" && m_Nom_Tipo != "BP")
                        m_Beneficiarios.Rows[i][m_Nom_Tipo] = "S";

                    break;
                }
            }
        }
        else
        {
            if (m_Tip_Benef == 6)
            {
                m_Nivel1 = m_Beneficiarios.Rows.Count + 1;
                HttpContext.Current.Session["m_Nivel1"]=m_Nivel1.ToString();
            }
            else m_Nivel2 = m_Beneficiarios.Rows.Count + 1;

            DataRow objDR = m_Beneficiarios.NewRow();
            objDR["indice"] = m_Beneficiarios.Rows.Count;
            objDR["cod_benef"] = Cod_Benef;
            objDR["nombre"] = nombre;
            objDR["paterno"] = paterno;
            objDR["materno"] = materno;
            objDR["porcentaje"] = porcentaje;
            objDR["cod_parent"] = cod_parent;
            objDR["nom_parent"] = nom_parent;
            objDR["tip_benef"] = m_Tip_Benef;
            objDR["nivel1"] = m_Nivel1;
            objDR["nivel2"] = m_Nivel2;
            //'C6
            objDR["fecnac"] = fecnac;
            objDR["domicilio"] = domicilio;
            //'C6F
            //MU-2017-052841 INI
            objDR["telefono"] = telefono;
            objDR["mail"] = mail;
            //MU-2017-052841 FIN
            if (m_Nom_Tipo != "" && m_Nom_Tipo != "BP")
                objDR[m_Nom_Tipo] = "S";
            m_Beneficiarios.Rows.Add(objDR);
        }
    }


    public void Insertar105(string nombre, string paterno, string materno, string porcentaje, string cod_parent,
        string nom_parent, bool existe, string fecnac, string domicilio,string asegurado)
    {
        if (existe)
        {
            for (int i = 0; i < m_Beneficiarios.Rows.Count; i++)
            {
                if (m_Beneficiarios.Rows[i]["cod_benef"].ToString() == m_Cod_Benef.ToString())
                {
                    m_Beneficiarios.Rows[i]["cod_benef"] = m_Cod_Benef;
                    m_Beneficiarios.Rows[i]["nombre"] = nombre;
                    m_Beneficiarios.Rows[i]["paterno"] = paterno;
                    m_Beneficiarios.Rows[i]["materno"] = materno;
                    m_Beneficiarios.Rows[i]["porcentaje"] = porcentaje;
                    m_Beneficiarios.Rows[i]["cod_parent"] = cod_parent;
                    m_Beneficiarios.Rows[i]["nom_parent"] = nom_parent;
                    m_Beneficiarios.Rows[i]["tip_benef"] = m_Tip_Benef;
                    m_Beneficiarios.Rows[i]["nivel1"] = m_Nivel1;
                    m_Beneficiarios.Rows[i]["nivel2"] = m_Nivel2;
                    //'C6
                    m_Beneficiarios.Rows[i]["fecnac"] = fecnac;
                    m_Beneficiarios.Rows[i]["domicilio"] = domicilio;
                    m_Beneficiarios.Rows[i]["asegurado"] = asegurado;
                    //'C6F
                    if (m_Nom_Tipo != "" && m_Nom_Tipo != "BP")
                        m_Beneficiarios.Rows[i][m_Nom_Tipo] = "S";

                    break;
                }
            }
        }
        else
        {
            if (m_Tip_Benef == 6)
            {
                m_Nivel1 = m_Beneficiarios.Rows.Count + 1;
                HttpContext.Current.Session["m_Nivel1"] = m_Nivel1.ToString();
            }
            else m_Nivel2 = m_Beneficiarios.Rows.Count + 1;

            DataRow objDR = m_Beneficiarios.NewRow();
            objDR["indice"] = m_Beneficiarios.Rows.Count;
            objDR["cod_benef"] = Cod_Benef;
            objDR["nombre"] = nombre;
            objDR["paterno"] = paterno;
            objDR["materno"] = materno;
            objDR["porcentaje"] = porcentaje;
            objDR["cod_parent"] = cod_parent;
            objDR["nom_parent"] = nom_parent;
            objDR["tip_benef"] = m_Tip_Benef;
            objDR["nivel1"] = m_Nivel1;
            objDR["nivel2"] = m_Nivel2;
            //'C6
            objDR["fecnac"] = fecnac;
            objDR["domicilio"] = domicilio;
            objDR["asegurado"] = asegurado;
            //'C6F
            if (m_Nom_Tipo != "" && m_Nom_Tipo != "BP")
                objDR[m_Nom_Tipo] = "S";
            m_Beneficiarios.Rows.Add(objDR);
        }
    }


    

    public void addTipBenef(string agregar)
    {
        for (int i = 0; i < m_Beneficiarios.Rows.Count; i++)
        {
            int tip_benef = Convert.ToInt32(m_Beneficiarios.Rows[i]["tip_benef"]);
            int num_nivel = Convert.ToInt32(m_Beneficiarios.Rows[i]["nivel1"]);
            if (tip_benef == 6 && num_nivel == m_Nivel1)
            {
                try
                {
                    m_Beneficiarios.Rows[i][m_Nom_Tipo] = agregar;
                    break;
                }
                catch { }
            }
        }
    }

    public bool Eliminar()
    {
        bool eliminado = false;
        foreach (DataRow rowBenef in m_Beneficiarios.Rows)
        {
            if (rowBenef["cod_benef"].ToString() == m_Cod_Benef.ToString())
            {
                m_Beneficiarios.Rows.Remove(rowBenef);
                eliminado = true;
                break;
            }
        }

        if (eliminado)
        {
            if (m_Cod_Benef == 0)
                m_Nivel1 = 1;
            else m_Nivel2 = 1;

            for (int i = 0; i < m_Beneficiarios.Rows.Count; i++)
            {
                m_Beneficiarios.Rows[i]["indice"] = i;
                m_Beneficiarios.Rows[i]["cod_benef"] = Cod_Benef;
                m_Beneficiarios.Rows[i]["nivel1"] = m_Nivel1;
                m_Beneficiarios.Rows[i]["nivel2"] = m_Nivel2;

                if (m_Cod_Benef == 0)
                    m_Nivel1++;
                else m_Nivel2++;
            }
        }
        return eliminado;
    }

    public DataRow Modificar()
    {
        foreach (DataRow rowBenef in m_Beneficiarios.Rows)
        {
            if (rowBenef["cod_benef"].ToString() == m_Cod_Benef.ToString())
                return rowBenef;
        }
        return null;
    }

    public void generaCodDocum()
    {
        foreach (DataRow rowBenef in m_Beneficiarios.Rows)
        {
            if (rowBenef["cod_docum"].ToString().Equals(""))
            {
                string nombre = rowBenef["nombre"].ToString();
                string paterno = rowBenef["paterno"].ToString();
                string materno = rowBenef["materno"].ToString();
                string parentesco = rowBenef["cod_parent"].ToString();
                //'C6
                string fecnac = rowBenef["fecnac"].ToString();
                string domicilio = rowBenef["domicilio"].ToString();
                //'C6F
                //MU-2017-052841 INI
                string tel = rowBenef["telefono"].ToString();
                string mail = rowBenef["mail"].ToString();
                //MU-2017-052841 FIN


                CLM objCLM = new CLM();
                //C1
                //PERSONA MORAL (clave TW 18)
                //INSTITUCION BANCARIA (clave TW 19)
                //SOCIOS (clave TW 16)
                string tipoPersona;
                if (rowBenef["cod_parent"].ToString() == "18"
                    || rowBenef["cod_parent"].ToString() == "19")
                {
                    tipoPersona = "N"; //No es persona Fisica
                }
                else
                {
                    tipoPersona = "S"; // 
                }
                //'C6 Se agregaron parámetros fecnac, domicilio
                //MU-2017-052841 INI
                DataRow objDR = objCLM.altaBeneficiario(tipoPersona, nombre, paterno, materno, parentesco, fecnac, domicilio, tel, mail);
                //MU-2017-052841 FIN
                //'C6F
                rowBenef["tip_docum"] = objDR["p_tip_docum"].ToString();
                rowBenef["cod_docum"] = objDR["p_cod_docum"].ToString();
            }
        }
    }
   
    public void calculaPcto()
    {
        int contador;
        int participacion = 0;
        DataRow row2;
        int cod_benf;
        int ramo = 0;
        try
        {
            ramo = Convert.ToInt32(HttpContext.Current.Session["RAMO"]);
        }
        catch
        {
            ramo = 0;
        }

        if (ramo == 105)
        {
            foreach (DataRow row in m_Beneficiarios.Rows)
            {
                if (m_Tip_Benef == 6)
                {
                    cod_benf = Convert.ToInt32(row["cod_benef"]);

                    if (Convert.ToInt32(row["tip_benef"]) == m_Tip_Benef)
                    {
                        if (ramo == 105)
                        {
                            string asegurado = Convert.ToString(row["asegurado"]);
                            string asegurado2 = Convert.ToString(HttpContext.Current.Session["asegurado"]);
                            if (asegurado != asegurado2)
                            {
                                if (m_Beneficiarios.Rows.Count == 1)
                                {
                                    participacion = 0;
                                    participacion += Convert.ToInt32(row["porcentaje"]);

                                    if (participacion > 100)
                                        throw new Exception("La suma del porcentaje de los beneficiarios principales excede del 100%");

                                    HttpContext.Current.Session["asegurado"] = asegurado;
                                    HttpContext.Current.Session["6"] = participacion;
                                }
                                else
                                {
                                    participacion = 0;
                                    participacion += Convert.ToInt32(row["porcentaje"]);

                                    if (participacion > 100)
                                        throw new Exception("La suma del porcentaje de los beneficiarios principales excede del 100%");

                                    HttpContext.Current.Session["asegurado"] = asegurado;
                                    HttpContext.Current.Session["6"] = participacion;
                                }




                            }
                            else
                            {
                                participacion += Convert.ToInt32(row["porcentaje"]);

                                if (participacion > 100)
                                    throw new Exception("La suma del porcentaje de los beneficiarios principales excede del 100%");

                                HttpContext.Current.Session["asegurado"] = asegurado;
                                HttpContext.Current.Session["6"] = participacion;
                            }
                            HttpContext.Current.Session["asegurado"] = asegurado;
                        }
                        else
                        {
                            participacion += Convert.ToInt32(row["porcentaje"]);

                            if (participacion > 100)
                                throw new Exception("La suma del porcentaje de los beneficiarios principales excede del 100%");
                        }

                    }


                }
                else
                {
                    int porcentaje = 0;
                    int procentaje2 = 0;
                    int tipo_benef = 0;

                    try
                    {
                        tipo_benef = Convert.ToInt32(HttpContext.Current.Session["Tip_Benef"]);
                    }
                    catch
                    {
                        tipo_benef = 0;
                    }
                    try
                    {
                        porcentaje = Convert.ToInt32(HttpContext.Current.Session["6"]);
                    }
                    catch
                    {
                        porcentaje = 0;
                    }

                    try
                    {
                        procentaje2 = Convert.ToInt32(HttpContext.Current.Session["m_Tip_Benef"]);
                    }
                    catch
                    {
                        procentaje2 = 0;
                    }

                    if (porcentaje < 100)
                    {
                        throw new Exception("La suma del porcentaje de los beneficiarios principales no es del 100%");
                    }
                    if (tipo_benef != 0)
                    {
                        if (tipo_benef == m_Tip_Benef)
                        {

                        }
                        else
                        {
                            if (procentaje2 < 100)
                            {
                                if (tipo_benef == 12)
                                {
                                    throw new Exception("La suma del porcentaje de los beneficiarios por sobrevivencia no es del 100%");
                                }

                                if (tipo_benef == 13)
                                {
                                    throw new Exception("La suma del porcentaje de los beneficiarios por fallecimiento no es del 100%");
                                }

                            }
                        }
                    }

                    if (Convert.ToInt32(row["tip_benef"]) == m_Tip_Benef && Convert.ToInt32(row["nivel1"]) == m_Nivel1)
                    {
                        if (ramo == 105)
                        {
                            string asegurado = Convert.ToString(row["asegurado"]);
                            string asegurado2 = Convert.ToString(HttpContext.Current.Session["asegurado"]);
                            if (asegurado != asegurado2)
                            {
                                if (m_Beneficiarios.Rows.Count == 1)
                                {
                                    participacion += Convert.ToInt32(row["porcentaje"]);
                                    if (ramo == 105)
                                    {
                                        string tipbenef = "";
                                        if (m_Tip_Benef == 12)
                                        {
                                            tipbenef = "sobrevivencia";
                                        }
                                        if (m_Tip_Benef == 13)
                                        {
                                            tipbenef = "fallecimiento";
                                        }
                                        if (participacion > 100)
                                            throw new Exception("La suma del porcentaje de los beneficiarios por " + tipbenef + "  excede del 100%");
                                        HttpContext.Current.Session["m_Tip_Benef"] = participacion;
                                        HttpContext.Current.Session["Tip_Benef"] = m_Tip_Benef;
                                    }
                                    else
                                    {
                                        if (participacion > 100)
                                            throw new Exception("La suma del porcentaje de los beneficiarios adicionales de tipo '" +
                                        m_Nom_Tipo + "' excede del 100%");
                                    }

                                    HttpContext.Current.Session["asegurado"] = asegurado;
                                }
                                else
                                {
                                    participacion = 0;
                                    participacion += Convert.ToInt32(row["porcentaje"]);

                                    string tipbenef = "";
                                    if (m_Tip_Benef == 12)
                                    {
                                        tipbenef = "sobrevivencia";
                                    }
                                    if (m_Tip_Benef == 13)
                                    {
                                        tipbenef = "fallecimiento";
                                    }
                                    if (participacion > 100)
                                        throw new Exception("La suma del porcentaje de los beneficiarios por " + tipbenef + "  excede del 100%");

                                    HttpContext.Current.Session["m_Tip_Benef"] = participacion;
                                    HttpContext.Current.Session["Tip_Benef"] = m_Tip_Benef;
                                }

                            }
                            else
                            {
                                participacion += Convert.ToInt32(row["porcentaje"]);
                                if (ramo == 105)
                                {

                                    string tipbenef = "";
                                    if (m_Tip_Benef == 12)
                                    {
                                        tipbenef = "sobrevivencia";
                                    }
                                    if (m_Tip_Benef == 13)
                                    {
                                        tipbenef = "fallecimiento";
                                    }
                                    if (participacion > 100)
                                        throw new Exception("La suma del porcentaje de los beneficiarios por " + tipbenef + "  excede del 100%");
                                    HttpContext.Current.Session["m_Tip_Benef"] = participacion;
                                    HttpContext.Current.Session["Tip_Benef"] = m_Tip_Benef;
                                }
                                else
                                {
                                    if (participacion > 100)
                                        throw new Exception("La suma del porcentaje de los beneficiarios adicionales de tipo '" +
                                        m_Nom_Tipo + "' excede del 100%");
                                }

                                HttpContext.Current.Session["asegurado"] = asegurado;
                            }
                            HttpContext.Current.Session["asegurado"] = asegurado;
                        }
                        else
                        {
                            participacion += Convert.ToInt32(row["porcentaje"]);
                            if (ramo == 105)
                            {
                                string tipbenef = "";
                                if (m_Tip_Benef == 12)
                                {
                                    tipbenef = "sobrevivencia";
                                }
                                if (m_Tip_Benef == 13)
                                {
                                    tipbenef = "fallecimiento";
                                }
                                if (participacion > 100)
                                    throw new Exception("La suma del porcentaje de los beneficiarios por " + tipbenef + "  excede del 100%");
                                HttpContext.Current.Session["m_Tip_Benef"] = participacion;
                            }
                            else
                            {
                                if (participacion > 100)
                                    throw new Exception("La suma del porcentaje de los beneficiarios adicionales de tipo '" +
                                        m_Nom_Tipo + "' excede del 100%");
                            }
                        }
                    }
                }
            }
            HttpContext.Current.Session["cod_benef"] = null;
        }
        //entra todo lo que no es 105 y con el porcentaje anterior
        else
        {
            participacion = 0;
            foreach (DataRow row in m_Beneficiarios.Rows)
            {
                if (m_Tip_Benef == 6)
                {
                    if (Convert.ToInt32(row["tip_benef"]) == m_Tip_Benef)
                    {
                        participacion += Convert.ToInt32(row["porcentaje"]);
                        if (participacion > 100)
                            throw new Exception("La suma del porcentaje de los beneficiarios principales excede del 100%");
                    }
                }
                else
                {
                    if (Convert.ToInt32(row["tip_benef"]) == m_Tip_Benef && Convert.ToInt32(row["nivel1"]) == m_Nivel1)
                    {
                        participacion += Convert.ToInt32(row["porcentaje"]);
                        if (participacion > 100)
                            throw new Exception("La suma del porcentaje de los beneficiarios adicionales de tipo '" +
                                m_Nom_Tipo + "' excede del 100%");
                    }
                }
            }
        }

    }

    public int CuentaNoBeneficiarios()
    {
        int ContBenef = 0;
        foreach (DataRow row in m_Beneficiarios.Rows)
        {
            if (m_Tip_Benef == 6)
            {
                if (Convert.ToInt32(row["tip_benef"]) == m_Tip_Benef)
                {
                    ContBenef++;
                }
            }
        }
        return ContBenef;
    }

    public int numeroAdd()
    {
        int contador = 0;
        foreach (DataRow rowBenef in m_Beneficiarios.Rows)
        {
            int tip_benef = Convert.ToInt32(rowBenef["nivel1"]);
            int nivel1 = Convert.ToInt32(rowBenef["tip_benef"]);
            if (tip_benef == m_Tip_Benef && nivel1 == m_Nivel1)
                contador++;
        }
        return contador;
    }

    private void inicializaGrid()
    {
        m_gridBenef = new GridView();
        m_gridBenef.ID = "grdBeneficiarios";
        m_gridBenef.CssClass = "EtiquetaGeneralDescripcion";
        m_gridBenef.Width = Unit.Percentage(90);
        m_gridBenef.AutoGenerateColumns = false;
        m_gridBenef.HeaderStyle.Font.Bold = true;
        m_gridBenef.HeaderStyle.ForeColor = System.Drawing.Color.White;
        m_gridBenef.HeaderStyle.BackColor = System.Drawing.Color.Red;
        m_gridBenef.HeaderStyle.Wrap = false;

        //  <--- C3 --->
        m_gridFallecimiento = new GridView();
        m_gridFallecimiento.ID = "grdFallecimiento";
        m_gridFallecimiento.CssClass = "EtiquetaGeneralDescripcion";
        m_gridFallecimiento.Width = Unit.Percentage(90);
        m_gridFallecimiento.AutoGenerateColumns = false;
        m_gridFallecimiento.HeaderStyle.Font.Bold = true;
        m_gridFallecimiento.HeaderStyle.ForeColor = System.Drawing.Color.White;
        m_gridFallecimiento.HeaderStyle.BackColor = System.Drawing.Color.Red;
        m_gridFallecimiento.HeaderStyle.Wrap = false;

        m_gridRemanente = new GridView();
        m_gridRemanente.ID = "grdRemanente";
        m_gridRemanente.CssClass = "EtiquetaGeneralDescripcion";
        m_gridRemanente.Width = Unit.Percentage(90);
        m_gridRemanente.AutoGenerateColumns = false;
        m_gridRemanente.HeaderStyle.Font.Bold = true;
        m_gridRemanente.HeaderStyle.ForeColor = System.Drawing.Color.White;
        m_gridRemanente.HeaderStyle.BackColor = System.Drawing.Color.Red;
        m_gridRemanente.HeaderStyle.Wrap = false;

        //AEP BWMEILL- Millón Vida Fase 2. Nuevo tipo de beneficiario
        m_gridSobreviviente = new GridView();
        m_gridSobreviviente.ID = "grdSobreviviente";
        m_gridSobreviviente.CssClass = "EtiquetaGeneralDescripcion";
        m_gridSobreviviente.Width = Unit.Percentage(90);
        m_gridSobreviviente.AutoGenerateColumns = false;
        m_gridSobreviviente.HeaderStyle.Font.Bold = true;
        m_gridSobreviviente.HeaderStyle.ForeColor = System.Drawing.Color.White;
        m_gridSobreviviente.HeaderStyle.BackColor = System.Drawing.Color.Red;
        m_gridSobreviviente.HeaderStyle.Wrap = false;
        // ---------

        BoundField objBField = new BoundField();
        
        objBField = new BoundField();
        objBField.DataField = "nombre";                         // 0
        objBField.HeaderText = "Nombre(s)";
        objBField.ItemStyle.Width = Unit.Percentage(35);
        objBField.ItemStyle.HorizontalAlign = HorizontalAlign.Left;
        m_gridBenef.Columns.Add(objBField);
        m_gridFallecimiento.Columns.Add(objBField);
        m_gridRemanente.Columns.Add(objBField);
        //AEP BWMEILL. Millón Vida Fase 2. Nuevo tipo de beneficiario
        m_gridSobreviviente.Columns.Add(objBField);

        objBField = new BoundField();
        objBField.DataField = "paterno";                        // 1
        objBField.HeaderText = "Apellido Paterno";
        m_gridBenef.Columns.Add(objBField);
        //  <--- C3 --->
        m_gridFallecimiento.Columns.Add(objBField);
        m_gridRemanente.Columns.Add(objBField);
        //AEP BWMEILL. Millón Vida Fase 2. Nuevo tipo de beneficiario
        m_gridSobreviviente.Columns.Add(objBField);
        //  ------------
        
        objBField = new BoundField();
        objBField.DataField = "materno";                        // 2
        objBField.HeaderText = "Apellido Materno";
        m_gridBenef.Columns.Add(objBField);
        //  <--- C3 --->
        m_gridFallecimiento.Columns.Add(objBField);
        m_gridRemanente.Columns.Add(objBField);
        //AEP BWMEILL. Millón Vida Fase 2. Nuevo tipo de beneficiario
        m_gridSobreviviente.Columns.Add(objBField);
        //  ------------
        
        objBField = new BoundField();
        objBField.DataField = "nom_parent";                     // 4
        objBField.HeaderText = "Parentesco";
        objBField.ItemStyle.Width = Unit.Percentage(20);
        objBField.ItemStyle.HorizontalAlign = HorizontalAlign.Center;
        m_gridBenef.Columns.Add(objBField);
        //  <--- C3 --->
        m_gridFallecimiento.Columns.Add(objBField);
        m_gridRemanente.Columns.Add(objBField);
        //AEP BWMEILL. Millón Vida Fase 2. Nuevo tipo de beneficiario
        m_gridSobreviviente.Columns.Add(objBField);
        //  ------------

        objBField = new BoundField();
        objBField.DataField = "porcentaje";                     // 3
        objBField.HeaderText = "%";
        objBField.ItemStyle.Width = Unit.Percentage(10);
        objBField.ItemStyle.HorizontalAlign = HorizontalAlign.Center;
        m_gridBenef.Columns.Add(objBField);
        //  <--- C3 --->
        m_gridFallecimiento.Columns.Add(objBField);
        m_gridRemanente.Columns.Add(objBField);
        //AEP BWMEILL. Millón Vida Fase 2. Nuevo tipo de beneficiario
        m_gridSobreviviente.Columns.Add(objBField);
        //  ------------
        int ramo = 0;

        try
        {
            ramo = Convert.ToInt32(HttpContext.Current.Session["RAMO"]);
        }
        catch
        {
            ramo = 0;
        }
        if (ramo == 105)
        {
            objBField = new BoundField();
            objBField.DataField = "asegurado";                     // 3
            objBField.HeaderText = "Asegurado";
            objBField.ItemStyle.Width = Unit.Percentage(10);
            objBField.ItemStyle.HorizontalAlign = HorizontalAlign.Center;
            m_gridBenef.Columns.Add(objBField);
            m_gridFallecimiento.Columns.Add(objBField);
            m_gridRemanente.Columns.Add(objBField);
            m_gridSobreviviente.Columns.Add(objBField);
        }

        
        objBField = new BoundField();
        objBField.DataField = "BF";                             // 5
        objBField.HeaderText = "BF";
        objBField.ItemStyle.Width = Unit.Percentage(5);
        objBField.ItemStyle.HorizontalAlign = HorizontalAlign.Center;
        m_gridBenef.Columns.Add(objBField);
        //  <--- C3 ---> 
        m_gridFallecimiento.Columns.Add(objBField);
        m_gridRemanente.Columns.Add(objBField);
        //AEP BWMEILL. Millón Vida Fase 2. Nuevo tipo de beneficiario
        m_gridSobreviviente.Columns.Add(objBField);
        //  ------------

        objBField = new BoundField();
        objBField.DataField = "BM";                             // 6
        objBField.HeaderText = "BM";
        objBField.ItemStyle.Width = Unit.Percentage(5);
        objBField.ItemStyle.HorizontalAlign = HorizontalAlign.Center;
        m_gridBenef.Columns.Add(objBField);
        //  <--- C3 --->
        m_gridFallecimiento.Columns.Add(objBField);
        m_gridRemanente.Columns.Add(objBField);
        //AEP BWMEILL. Millón Vida Fase 2. Nuevo tipo de beneficiario
        m_gridSobreviviente.Columns.Add(objBField);
        //  ------------

        objBField = new BoundField();
        objBField.DataField = "BR";                             // 7
        objBField.HeaderText = "BR";
        objBField.ItemStyle.Width = Unit.Percentage(5);
        objBField.ItemStyle.HorizontalAlign = HorizontalAlign.Center;
        m_gridBenef.Columns.Add(objBField);
        //  <--- C3 --->
        m_gridFallecimiento.Columns.Add(objBField);
        m_gridRemanente.Columns.Add(objBField);
        //AEP BWMEILL. Millón Vida Fase 2. Nuevo tipo de beneficiario
        m_gridSobreviviente.Columns.Add(objBField);
        //  ------------

        objBField = new BoundField();
        objBField.DataField = "cod_benef";                      // 8
        objBField.ItemStyle.Width = Unit.Percentage(10);
        m_gridBenef.Columns.Add(objBField);
        //  <--- C3 --->
        m_gridFallecimiento.Columns.Add(objBField);
        m_gridRemanente.Columns.Add(objBField);
        //AEP BWMEILL. Millón Vida Fase 2. Nuevo tipo de beneficiario
        m_gridSobreviviente.Columns.Add(objBField);
        //  ------------

        objBField = new BoundField();
        objBField.DataField = "tip_benef";                      // 9
        m_gridBenef.Columns.Add(objBField);
        //  <--- C3 --->
        m_gridFallecimiento.Columns.Add(objBField);
        m_gridRemanente.Columns.Add(objBField);
        //AEP BWMEILL. Millón Vida Fase 2. Nuevo tipo de beneficiario
        m_gridSobreviviente.Columns.Add(objBField);
        //  ------------

        objBField = new BoundField();
        objBField.DataField = "nivel1";                         // 10
        m_gridBenef.Columns.Add(objBField);
        //  <--- C3 --->
        m_gridFallecimiento.Columns.Add(objBField);
        m_gridRemanente.Columns.Add(objBField);
        //AEP BWMEILL. Millón Vida Fase 2. Nuevo tipo de beneficiario
        m_gridSobreviviente.Columns.Add(objBField);
        //  ------------
        if (ramo == 105)
        {
           
            objBField = new BoundField();
            objBField.DataField = "asegurado";                     // 3
            objBField.HeaderText = "Asegurado";
            objBField.ItemStyle.Width = Unit.Percentage(20);
            m_gridBenef.Columns.Add(objBField);
            //  <--- C3 --->
            m_gridFallecimiento.Columns.Add(objBField);
            m_gridRemanente.Columns.Add(objBField);
            //AEP BWMEILL. Millón Vida Fase 2. Nuevo tipo de beneficiario
            m_gridSobreviviente.Columns.Add(objBField);
        }
        else
        {
            objBField = new BoundField();
            objBField.DataField = "cod_benef";                      // 11
            objBField.HeaderText = "Relación con";
            objBField.ItemStyle.Width = Unit.Percentage(10);
            m_gridBenef.Columns.Add(objBField);
            //  <--- C3 --->
            m_gridFallecimiento.Columns.Add(objBField);
            m_gridRemanente.Columns.Add(objBField);
            //AEP BWMEILL. Millón Vida Fase 2. Nuevo tipo de beneficiario
            m_gridSobreviviente.Columns.Add(objBField);
            //  ------------
        }
        m_gridBenef.RowDataBound += new GridViewRowEventHandler(Benef_RowDataBound);
        // <--- C5 --->
        m_gridFallecimiento.RowDataBound += new GridViewRowEventHandler(m_gridFallecimiento_RowDataBound);
        m_gridRemanente.RowDataBound += new GridViewRowEventHandler(m_gridRemanente_RowDataBound);
        //AEP BWMEILL. Millón Vida Fase 2. Nuevo tipo de beneficiario
        m_gridSobreviviente.RowDataBound += new GridViewRowEventHandler(m_gridSobreviviente_RowDataBound);
        // ------------

    }

    // <--- C5 --->
    private void m_gridRemanente_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        string rowID = "";
        string codigoBeneficiario = "";

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            rowID = "row" + e.Row.RowIndex;
            e.Row.Attributes.Add("id", rowID);

            e.Row.Attributes.Add("onmouseover", "this.style.cursor='hand';");
            e.Row.Attributes.Add("onclick", "seleccionaBenef('" + e.Row.Cells[8].Text + "', '" + e.Row.Cells[9].Text + "', '" + rowID + "');this.style.backgroundColor='Gainsboro'");
            e.Row.Attributes.Add("ondblclick", "modificarBenef('" + e.Row.Cells[8].Text + "','" + e.Row.Cells[9].Text + "');this.style.backgroundColor='Gainsboro'");

            e.Row.Cells[5].Text = e.Row.Cells[5].Text.Replace("S", "X");
            e.Row.Cells[6].Text = e.Row.Cells[6].Text.Replace("S", "X");
            e.Row.Cells[7].Text = e.Row.Cells[7].Text.Replace("S", "X");

            e.Row.Cells[0].Text = e.Row.Cells[0].Text;

            codigoBeneficiario = (e.Row.Cells[8].Text).ToString();
            string[] relacion = codigoBeneficiario.Split('.');
            e.Row.Cells[11].Text = relacion[0];

        }
        else if (e.Row.RowType == DataControlRowType.Footer)
        {
            for (int c = 0; c < m_gridRemanente.Columns.Count; c++)
            {
                string[] noDeseada = new string[] { "5", "6", "7", "8", "9", "10" };
                foreach (string elimina in noDeseada)
                {
                    if (c.ToString() == elimina)
                        m_gridRemanente.Columns[c].Visible = false;
                }
            }
        }
    }
    //AEP BWMEILL. Millón Vida Fase 2. Nuevo Beneficiario
    private void m_gridSobreviviente_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        string rowID = "";
        string codigoBeneficiario = "";

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            rowID = "row" + e.Row.RowIndex;
            e.Row.Attributes.Add("id", rowID);

            e.Row.Attributes.Add("onmouseover", "this.style.cursor='hand';");
            e.Row.Attributes.Add("onclick", "seleccionaBenef('" + e.Row.Cells[8].Text + "', '" + e.Row.Cells[9].Text + "', '" + rowID + "');this.style.backgroundColor='Gainsboro'");
            e.Row.Attributes.Add("ondblclick", "modificarBenef('" + e.Row.Cells[8].Text + "','" + e.Row.Cells[9].Text + "');this.style.backgroundColor='Gainsboro'");

            e.Row.Cells[5].Text = e.Row.Cells[5].Text.Replace("S", "X");
            e.Row.Cells[6].Text = e.Row.Cells[6].Text.Replace("S", "X");
            e.Row.Cells[7].Text = e.Row.Cells[7].Text.Replace("S", "X");

            e.Row.Cells[0].Text = e.Row.Cells[0].Text;

            codigoBeneficiario = (e.Row.Cells[8].Text).ToString();
            string[] relacion = codigoBeneficiario.Split('.');
            e.Row.Cells[11].Text = relacion[0];

        }
        else if (e.Row.RowType == DataControlRowType.Footer)
        {
            for (int c = 0; c < m_gridSobreviviente.Columns.Count; c++)
            {
                string[] noDeseada = new string[] { "5", "6", "7", "8", "9", "10" };
                foreach (string elimina in noDeseada)
                {
                    if (c.ToString() == elimina)
                        m_gridSobreviviente.Columns[c].Visible = false;
                }
            }
        }
    }
    private void m_gridFallecimiento_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        string rowID = "";
        string codigoBeneficiario = "";

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            rowID = "row" + e.Row.RowIndex;
            e.Row.Attributes.Add("id", rowID);

            e.Row.Attributes.Add("onmouseover", "this.style.cursor='hand';");
            e.Row.Attributes.Add("onclick", "seleccionaBenef('" + e.Row.Cells[8].Text + "', '" + e.Row.Cells[9].Text + "', '" + rowID + "');this.style.backgroundColor='Gainsboro'");
            e.Row.Attributes.Add("ondblclick", "modificarBenef('" + e.Row.Cells[8].Text + "','" + e.Row.Cells[9].Text + "');this.style.backgroundColor='Gainsboro'");

            e.Row.Cells[5].Text = e.Row.Cells[5].Text.Replace("S", "X");
            e.Row.Cells[6].Text = e.Row.Cells[6].Text.Replace("S", "X");
            e.Row.Cells[7].Text = e.Row.Cells[7].Text.Replace("S", "X");

            e.Row.Cells[0].Text = e.Row.Cells[0].Text;

            codigoBeneficiario = (e.Row.Cells[8].Text).ToString();
            string[] relacion = codigoBeneficiario.Split('.');
            e.Row.Cells[11].Text = relacion[0];

        }
        else if (e.Row.RowType == DataControlRowType.Footer)
        {
            for (int c = 0; c < m_gridFallecimiento.Columns.Count; c++)
            {
                string[] noDeseada = new string[] { "5", "6", "7", "8", "9", "10" };

                foreach (string elimina in noDeseada)
                {
                    if (c.ToString() == elimina)
                        m_gridFallecimiento.Columns[c].Visible = false;
                }
            }
        }
    }
    
    private void Benef_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        string rowID = "";
        string codigoBeneficiario = "";
                       
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            rowID = "row" + e.Row.RowIndex;
            e.Row.Attributes.Add("id", rowID);

            e.Row.Attributes.Add("onmouseover", "this.style.cursor='hand';");
            e.Row.Attributes.Add("onclick", "seleccionaBenef('" + e.Row.Cells[8].Text + "', '" + 
                                  e.Row.Cells[9].Text + "', '" + rowID + "');this.style.backgroundColor='Gainsboro'");
            e.Row.Attributes.Add("ondblclick", "modificarBenef('" + e.Row.Cells[8].Text + "','" + 
                                  e.Row.Cells[9].Text + "');this.style.backgroundColor='Gainsboro'");

            e.Row.Cells[5].Text = e.Row.Cells[5].Text.Replace("S", "X");
            e.Row.Cells[6].Text = e.Row.Cells[6].Text.Replace("S", "X");
            e.Row.Cells[7].Text = e.Row.Cells[7].Text.Replace("S", "X");

            e.Row.Cells[0].Text = e.Row.Cells[0].Text;

            codigoBeneficiario = (e.Row.Cells[8].Text).ToString();
            string[] relacion = codigoBeneficiario.Split('.');
            e.Row.Cells[11].Text = relacion[0];            
        }
        else if (e.Row.RowType == DataControlRowType.Footer)
        {
            for (int c = 0; c < m_gridBenef.Columns.Count; c++)
            {
                    //  <--- C4 --->
                    string[] noDeseada = new string[] { "5", "6", "7", "8", "9", "10" , "11" };
                    //  ------------
                    foreach (string elimina in noDeseada)
                    {
                        if (c.ToString() == elimina)
                            m_gridBenef.Columns[c].Visible = false;
                    }
            }
        }
    }

}

public class AseguradoSF
{
    private DataTable m_Asegurados;
    private GridView m_gridAseg;
    public string Ramo;
    public string IdContexto;

    public AseguradoSF()
	{
        m_Asegurados = new DataTable();
        m_Asegurados.Columns.Add("indice", Type.GetType("System.Int32"));
        m_Asegurados.Columns.Add("cod_docum");
        m_Asegurados.Columns.Add("rfc");
        m_Asegurados.Columns.Add("nombre");
        m_Asegurados.Columns.Add("paterno");
        m_Asegurados.Columns.Add("materno");
        m_Asegurados.Columns.Add("cod_parent", Type.GetType("System.Int32"));
        m_Asegurados.Columns.Add("nom_parent");
        m_Asegurados.Columns.Add("fec_nac");
        m_Asegurados.Columns.Add("edad", Type.GetType("System.Int32"));
        m_Asegurados.Columns.Add("sexo", Type.GetType("System.Int32"));
        m_Asegurados.Columns.Add("edo_civil");
        m_Asegurados.Columns.Add("nom_civil");

        inicializaGrid();
    }

    #region Atributos

    public DataTable Asegurados
    {
        set { m_Asegurados = value; }
        get
        {
            m_Asegurados.DefaultView.Sort = "indice";
            m_Asegurados = m_Asegurados.DefaultView.ToTable();
            return m_Asegurados;
        }
    }

    public GridView Grid_Asegurados
    {
        get
        {
            m_Asegurados.DefaultView.Sort = "indice";
            m_gridAseg.DataSource = m_Asegurados.DefaultView.ToTable();
            m_gridAseg.DataBind();
            return m_gridAseg;
        }
    }

    public string Return_Script
    {
        get
        {
            GridView grid = this.Grid_Asegurados;
            StringWriter SW = new StringWriter();
            HtmlTextWriter HW = new HtmlTextWriter(SW);
            grid.RenderControl(HW);
            return SW.ToString();
        }
    }

    #endregion

    public void Insertar(string cod_docum, string rfc, string nombre, string paterno, string materno, 
                         int cod_parent, string nom_parent, string fec_nac, int edad, int sexo, string edo_civil, 
                         string nom_civil)
    {
        bool existe = false;
        for (int i = 0; i < m_Asegurados.Rows.Count; i++)
        {
            if (m_Asegurados.Rows[i]["cod_docum"].ToString() == cod_docum || m_Asegurados.Rows[i]["rfc"].ToString() == rfc)
            {
                if (i > 0)
                {
                    m_Asegurados.Rows[i]["cod_docum"] = cod_docum;
                    m_Asegurados.Rows[i]["rfc"] = rfc;
                    m_Asegurados.Rows[i]["nombre"] = nombre;
                    m_Asegurados.Rows[i]["paterno"] = paterno;
                    m_Asegurados.Rows[i]["materno"] = materno;
                    m_Asegurados.Rows[i]["cod_parent"] = cod_parent;
                    m_Asegurados.Rows[i]["nom_parent"] = nom_parent;
                    m_Asegurados.Rows[i]["fec_nac"] = fec_nac;
                    m_Asegurados.Rows[i]["edad"] = edad;
                    m_Asegurados.Rows[i]["sexo"] = sexo;
                    m_Asegurados.Rows[i]["edo_civil"] = edo_civil;
                    m_Asegurados.Rows[i]["nom_civil"] = nom_civil;
                }
                existe = true;
                break;
            }
        }

        if (!existe)
        {
            DataRow objDR = m_Asegurados.NewRow();
            objDR["indice"] = m_Asegurados.Rows.Count;
            objDR["cod_docum"] = cod_docum;
            objDR["rfc"] = rfc;
            objDR["nombre"] = nombre;
            objDR["paterno"] = paterno;
            objDR["materno"] = materno;
            objDR["cod_parent"] = cod_parent;
            objDR["nom_parent"] = nom_parent;
            objDR["fec_nac"] = fec_nac;
            objDR["edad"] = edad;
            objDR["sexo"] = sexo;
            objDR["edo_civil"] = edo_civil;
            objDR["nom_civil"] = nom_civil;
            m_Asegurados.Rows.Add(objDR);
        }
    }

    public void Eliminar(string cod_docum)
    {
        bool eliminado = false;
        foreach (DataRow rowAgt in m_Asegurados.Rows)
        {
            if (rowAgt["cod_docum"].ToString() == cod_docum)
            {
                if (Convert.ToInt32(rowAgt["indice"]) > 0)
                {
                    m_Asegurados.Rows.Remove(rowAgt);
                    eliminado = true;
                    break;
                }
            }
        }

        if (eliminado)
        {
            for (int i = 0; i < m_Asegurados.Rows.Count; i++)
                m_Asegurados.Rows[i]["indice"] = i;
        }
    }

    public DataRow Modificar(string cod_docum)
    {
        foreach (DataRow rowAgt in m_Asegurados.Rows)
        {
            if (rowAgt["cod_docum"].ToString() == cod_docum)
                return rowAgt;
        }
        return null;
    }

    public void generaCodDocum()
    {
        foreach (DataRow rowAseg in m_Asegurados.Rows)
        {
            if (rowAseg["cod_docum"].ToString().Equals(""))
            {
                ArrayList array = new ArrayList();
                array.Add("MCA_FISICO=S");
                array.Add("NOM_TERCERO=" + rowAseg["nombre"].ToString());
                array.Add("APE1_TERCERO=" + rowAseg["paterno"].ToString());
                array.Add("APE2_TERCERO=" + rowAseg["materno"].ToString());
                array.Add("COD_PARENTESCO=" + rowAseg["cod_parent"].ToString());
                array.Add("COD_EST_CIVIL=" + rowAseg["edo_civil"].ToString());
                array.Add("MCA_SEXO=" + rowAseg["sexo"].ToString());
                array.Add("FEC_NACIMIENTO=" + rowAseg["fec_nac"].ToString());
                array.Add("COD_IDENTIFICADOR=" + IdContexto);

                CLM objCLM = new CLM();
                DataRow objDR = objCLM.altaTercero((string[])array.ToArray(typeof(string)), Ramo, "10");
                //rowAseg["tip_docum"] = objDR["p_tip_docum"].ToString();
                rowAseg["cod_docum"] = objDR["p_cod_docum"].ToString();
            }
        }
    }

    public void InsertarCLM(int id, string cod_docum)
    {
        m_Asegurados.Rows[id]["cod_docum"] = cod_docum;
    }

    private void inicializaGrid()
    {
        m_gridAseg = new GridView();
        m_gridAseg.ID = "grdAsegSF";
        m_gridAseg.CssClass = "letraNormal";
        m_gridAseg.Width = Unit.Percentage(95);
        m_gridAseg.AutoGenerateColumns = false;
        m_gridAseg.HeaderStyle.Font.Bold = true;
        m_gridAseg.HeaderStyle.ForeColor = System.Drawing.Color.White;
        m_gridAseg.HeaderStyle.BackColor = System.Drawing.Color.WhiteSmoke;
        m_gridAseg.HeaderStyle.Wrap = false;

        BoundField objBField = new BoundField();
        objBField.DataField = "cod_docum";                      // 0
        objBField.HeaderText = "Clave única";
        m_gridAseg.Columns.Add(objBField);

        objBField = new BoundField();
        objBField.DataField = "rfc";                            // 1
        objBField.HeaderText = "RFC";
        m_gridAseg.Columns.Add(objBField);

        objBField = new BoundField();
        objBField.DataField = "nombre";                         // 2
        objBField.HeaderText = "Nombre";
        objBField.ItemStyle.Width = Unit.Percentage(22);
        m_gridAseg.Columns.Add(objBField);

        objBField = new BoundField();
        objBField.DataField = "paterno";                        // 3
        objBField.HeaderText = "Apellido Paterno";
        objBField.ItemStyle.Width = Unit.Percentage(19);
        m_gridAseg.Columns.Add(objBField);

        objBField = new BoundField();
        objBField.DataField = "materno";                        // 4
        objBField.HeaderText = "Apellido Materno";
        objBField.ItemStyle.Width = Unit.Percentage(19);
        m_gridAseg.Columns.Add(objBField);

        objBField = new BoundField();
        objBField.DataField = "nom_parent";                     // 5
        objBField.HeaderText = "Parentesco";
        objBField.ItemStyle.Width = Unit.Percentage(15);
        m_gridAseg.Columns.Add(objBField);

        objBField = new BoundField();
        objBField.DataField = "nom_civil";                      // 6
        objBField.HeaderText = "Estado Civil";
        objBField.ItemStyle.Width = Unit.Percentage(15);
        m_gridAseg.Columns.Add(objBField);

        objBField = new BoundField();
        objBField.DataField = "edad";                           // 7
        objBField.HeaderText = "Edad";
        m_gridAseg.Columns.Add(objBField);

        m_gridAseg.RowDataBound += new GridViewRowEventHandler(AseguradoSF_RowDataBound);
    }

    private void AseguradoSF_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        string rowID = "";
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            MetodosAjax objMA = new MetodosAjax();
            rowID = "row" + e.Row.RowIndex;
            e.Row.Attributes.Add("id", rowID);

            e.Row.Attributes.Add("onmouseover", "this.style.cursor='hand';");
            e.Row.Attributes.Add("onclick", "seleccionaAsegSF('" + e.Row.Cells[0].Text + "', '" + 
                                  rowID + "');this.style.backgroundColor='Gainsboro'");
            e.Row.Attributes.Add("ondblclick", "modificarAsegSF('" + e.Row.Cells[0].Text + 
                                 "');this.style.backgroundColor='Gainsboro'");

            foreach (TableCell cell in e.Row.Cells)
                cell.Attributes.Add("class", "letraNormal");
        }
    }
}