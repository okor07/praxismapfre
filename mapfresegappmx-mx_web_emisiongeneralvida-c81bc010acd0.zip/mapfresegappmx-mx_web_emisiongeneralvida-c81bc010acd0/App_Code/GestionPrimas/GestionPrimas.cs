﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Oracle.DataAccess.Client;
using MapfreMMX.oracle;
using Generales.Clases;
using System.Text;

/// <summary>
/// Summary description for GestionPrimas
/// </summary>
public class GestionPrimas
{

    private string _HTMLTabla;
    public string HTMLTabla
    {
        get { return _HTMLTabla; }
        set { _HTMLTabla = value; }
    }
    
    public GestionPrimas()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public GestionPrimas(string strNoCotizacion, string strPagos)
    {

        Catalogos objCatalogos = new Catalogos();
        DataRow tablaPagos;

        float NoPagos = 0F;
        string strFormasPago = "";
        NoPagos = Convert.ToSingle(strPagos.Split('|')[0].ToString());
        strFormasPago = strPagos.Split('|')[1].ToString();

        using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
        {
            tablaPagos = objCatalogos.getFormaPago(strNoCotizacion, NoPagos, strFormasPago, conexion);
        }
        _HTMLTabla = ArmarHTMLPrimas(ArmarDTDesgPrimas(tablaPagos));
    }

    /// <summary>
    /// Método para armar un DataTable con el desglose de la Prima Total.
    /// </summary>
    /// <param name="objDR">Parámetro de tipo DataRow que contiene la Información del desglose de la Prima Total.</param>
    /// <returns>Regresa un objeto de Tipo DataTable con el desglose de la Prima Total.</returns>
    protected DataTable ArmarDTDesgPrimas(DataRow objDR)
    {
        General objGeneral = new General();
        
        DataTable objDT = new DataTable();

        string strInfoPrimas = objDR[0].ToString();

        //Se valida que la cadena de donde se leera la información del desglose no esté vacía.
        if (!string.IsNullOrEmpty(strInfoPrimas))
        {
            //Se almacena en un arreglo cada elemento del desglose cada uno de estos elementos
            //estará representado en cada Fila del DataTable a llenar.
            string[] arrElementos = strInfoPrimas.Split('|');

            //Parte para el agregado de cada columna del DataTable en base a la Info del desglose.
            //Se valida que por lo menos exista un elemento en el arreglo ya que se trabajará
            //con el elemento con Indice 0 del arreglo.
            if (arrElementos.Count() > 0)
            {
                //Se remueve el último caracter del Elemento con Índice 0 ya que se sabe que
                //ese índice contiene la Información de los Encabezados.
                string strAux = arrElementos[0].Remove(arrElementos[0].LastIndexOf(";"));

                string[] arrColumnas = strAux.Split(';');
                foreach (string strColumna in arrColumnas)
                {
                    string strCol = strColumna.Replace("*", "");
                    objDT.Columns.Add(strCol);
                }
            }

            //Se inicializa un Contador de Elementos.
            int ContadorElem = 0;
            //Se recorren todos los elementos del arreglo que contiene la Información del Desglose.
            foreach (string ItemPrima in arrElementos)
            {
                //Solo se consideran los Primeros nueve elementos del Arreglo.
                if (ContadorElem < 9)
                {
                    //Se remueve el último caracter del Elemento con Índice 0 ya que se sabe que
                    //ese índice contiene la Información de los Encabezados.
                    string[] arrValores = ItemPrima.Remove(ItemPrima.LastIndexOf(";")).Split(';');
                    //Se valida que el número de Columnas agregadas coincida con el Número de Valores de cada Elemento recorrido.
                    if (objDT.Columns.Count == arrValores.Count())
                    {
                        //Se agrega un DataRow por cada Elemento recorrido.
                        DataRow Fila = objDT.NewRow();
                        //Se recorrerá un ciclo de acuerdo al Número de columnas agregadas del DataTable.
                        for (int i = 0; i < objDT.Columns.Count; i++)
                        {
                            //Se almacena en el DataRow Nuevo, cada elemento en su Índice de columna correspondiente.
                            //Se valida que a la Fila con Número de Índice 6 no se le Aplique formato de Moneda.
                            if (ContadorElem != 6)
                                //Fila[i] = objGeneral.FormatoMoneda(arrValores[i].ToString().Replace("*", "")).ToString().Replace("$","");
                                Fila[i] = arrValores[i].ToString();
                            else
                                Fila[i] = arrValores[i].ToString();
                        }
                        objDT.Rows.Add(Fila);
                    }
                }
                ContadorElem++;
            }
        }

        return objDT;
    }

    protected string ArmarHTMLPrimas(DataTable dt)
    {

        string strEstiloEncabezado = "";
        string strEstiloCuerpo = "";
        string strAnchoColumna = "";
        if (dt.Columns.Count < 6)
        {
            strEstiloEncabezado = "table-danger";
            strEstiloCuerpo = "cuerpo_tabla_small_gray";
            strAnchoColumna = "80px";
        }
        else
        {
            if (dt.Columns.Count > 8)
            {
                strEstiloEncabezado = "cabeza_tabla_micro_gray";
                strEstiloCuerpo = "cuerpo_tabla_micro_gray";
                strAnchoColumna = "40px";
            }
            else
            {
                strEstiloEncabezado = "cabeza_tabla_mini_gray";
                strEstiloCuerpo = "cuerpo_tabla_mini_gray";
                strAnchoColumna = "50px";
            }
        }
        
        StringBuilder strHTMLTabla = new StringBuilder();
        strHTMLTabla.Append("<table id='Coberturas' class='table table-bordered tab-border-red' style='width: 100%;' >");
        strHTMLTabla.Append("<tr class='table-danger'>");
        //Llenar Encabezado
        foreach (DataColumn dc in dt.Columns)
        {
            if (dc.ColumnName == "FORMA DE PAGO")
                strHTMLTabla.Append("<td></td>"); 
            else
                strHTMLTabla.Append("<td>" + dc.ColumnName + "</td>"); 
        }
        strHTMLTabla.Append("</tr>");
        //Llenar Filas
        int Cont = 0;
        foreach (DataRow dr in dt.Rows)
        {
            //Filas
            if (Cont > 0 && Cont < 6)
            {
                strHTMLTabla.Append("<tr class='" + strEstiloCuerpo + "' >");
                //Se Arman las Columnas.
                foreach (DataColumn dc in dt.Columns)
                {
                    if(dc.ColumnName == "FORMA DE PAGO")
                        strHTMLTabla.Append("<td align='left'>" + dr[dc.ColumnName].ToString() + "</td>");
                    else
                        strHTMLTabla.Append("<td align='right' style='width: " + strAnchoColumna + "' >" + dr[dc.ColumnName].ToString() + "</td>");
                }
                strHTMLTabla.Append("</tr>");
            }
            Cont++;
        }

        strHTMLTabla.Append("</table>");

        return strHTMLTabla.ToString();
    }
}
