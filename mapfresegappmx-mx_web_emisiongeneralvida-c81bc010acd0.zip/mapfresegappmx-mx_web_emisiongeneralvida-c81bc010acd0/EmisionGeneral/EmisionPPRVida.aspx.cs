﻿//'*********************************************************************************************************************
//'@Author                       : APL BWMEILL
//'@version                      : 1.0
//'Name of the file              : EmisionPPRVida.aspx.cs
//'Creation/Modification History :  
//'********************************************************************************************************************
using Ajax;
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Oracle.DataAccess.Client;
using MapfreMMX.oracle;
using MapfreMMX.util;
using System.Text;
using Generales.Clases;
using System.IO;

public partial class EmisionPPRVida : System.Web.UI.Page
{
    Catalogos objCatalogos;
    private int indiceRow = 0;
    public static AjaxControlToolkit.AsyncFileUpload archivoCargado;
    public static DataTable dtAdjuntos;
    public int adjuntado = 0;
    public int adjunto = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        Ajax.Utility.RegisterTypeForAjax(typeof(MetodosAjax));
        Ajax.Utility.RegisterTypeForAjax(typeof(ImpresionReportes));

        //Millon Vida
        hidFechaSistema.Value = DateTime.Now.ToString("dd/MM/yyyy").Substring(0, 10); //Fecha del sistema
        hidFecValidez.Value = "01011980";
        //
        
        HiddenContratoGenerico.Value = ConfigurationManager.AppSettings["ContratoGenerico"];
        HiddenIFrameAAjustar.Value = ConfigurationManager.AppSettings["IFrameAAjustar"];
hdnUrlPagoDo.Value = WebUtils.getAppSetting("urlPagoDomiciliado");
        string ramo = Request.QueryString["codRamo"].Trim();
        HiddenRamoRequest.Value = ramo;
        string ramom = getNombreRamo(ramo);
        HiddenRamoDescripcion.Value = ramom.Replace(ramom, "SEGURO DE VIDA PLAN PERSONAL RETIRO");
        lblNombreRamo.Text = HiddenRamoDescripcion.Value;

        if (Convert.ToBoolean(ConfigurationManager.AppSettings["MostrarEtiquetaPlan"]))
            divPlan.Visible = true;
        else
            divPlan.Visible = false;

        lblRamoPlan.Text = ramo;

        //Indica que el acceso se realizó por portal Gente MAPFRE
        Session.Add("UsuarioRAM", WebUtils.getAppSetting("usuarioSeGARAM"));

        //MU-080082 Valor del hidden de tope SA cobertura temporal INI
        hdntopeSA.Value = WebUtils.getAppSetting("topeSA");
        //MU-080082 Valor del hidden de tope SA cobertura temporal INI

        if (!IsPostBack)
        {
 //AEP BWMEILL. Millón Vida fase2. Para capturar la conversión de moneda al día de hoy y variable para identificar el tipo de pago.
            Session.Add("TipoPagoMV","TD");
            TipodeCambio tipoCambio = getTipoCambio();
            hdnUSD.Value = tipoCambio.USD;
            hdnUDIS.Value = tipoCambio.UDIS;
            DataTable dt = new DataTable();
            grdAdjuntarArchivo.DataSource = dt;
            dtAdjuntos = dt;
            dt.Columns.Add("Archivo(s) adjunto(s)");
            grdAdjuntarArchivo.DataBind();
            hdnFecha.Value = DateTime.Today.ToString("dd/MM/yyyy");
            txtFechaEfecto.Text = DateTime.Today.ToString("dd/MM/yyyy");
            hdnFecVcto.Value = DateTime.Today.AddYears(1).ToString("dd/MM/yyyy");

            //ValidarAcceso
            bool ValidarAcceso = true;
            bool.TryParse(ConfigurationManager.AppSettings["ValidarAcceso"].ToString(), out ValidarAcceso);           
            Usuario objUsuario = new Usuario();

            if (ValidarAcceso)
            {
                if (Session["sUSUARIO"] != null)
                {

                    HiddenRamoRequest.Value = Request.QueryString["codRamo"].ToString();
                    string ramomm = getNombreRamo(Request.QueryString["codRamo"].ToString());
                    HiddenRamoDescripcion.Value = ramomm.Replace(ramomm, "SEGURO DE VIDA PLAN PERSONAL RETIRO");
                    HiddenTipoPlanRequest.Value = Request.QueryString["codTipoPlan"].ToString();
                    Session["TipoPLan"] = Request.QueryString["codTipoPlan"].ToString();
                    lblNombreRamo.Text = HiddenRamoDescripcion.Value;
                    lblRamoPlan.Text = Request.QueryString["codRamo"].ToString();
                    objUsuario = ((Usuario)Session["sUSUARIO"]);
                    HiddenUsuario.Value = objUsuario.USUARIO;
                    HiddenUsuarioTel.Value = new MetodosAjax().getTelefono(objUsuario.COD_AGENTE);
                    HiddenAgente.Value = objUsuario.COD_AGENTE.ToString();
                    HiddenEmailAgente.Value = new MetodosAjax().getCorreoAgente(objUsuario.COD_AGENTE);
                    objCatalogos = new Catalogos();
                    if (objUsuario.TIPO_USUARIO == 0)
                    {
                        General.llenaDropDown(drpAgente, objCatalogos.getAgentes(objUsuario.COD_OFICINA), "COD_AGT",
                            "NOM_COMPLETO", "Selecciona un agente para esta gerencia");
                    }
                    else
                        drpAgente.Items.Add(new ListItem(objUsuario.NOMBRE_COMPLETO + " (" + 
                            objUsuario.COD_AGENTE.ToString() + ")", objUsuario.COD_AGENTE.ToString()));
                    //Se configuran los Controles CLM.
                    ConfigurarControlesCLM();
                }
                else
                {
                    ClientScript.RegisterStartupScript(GetType(), "sesion",
                        "<script>alert('Ha expirado la sesión');</script>");
                    return;
                }
            }
            else
            {
                string strCodAgente = ConfigurationManager.AppSettings["CodAgentePruebas"].ToString();
                drpAgente.Items.Add(new ListItem("Agente para Pruebas (" + strCodAgente + ")", strCodAgente));
            }

            //Se invoca al Método para Llenar los controles DropDownList que se cargarán
            //al cargarse la página.
            LlenarDropDownLists();
            //Se invoca al Método para Agregar atributos a los Controles.
            AgregarAtributos();
            //Cargar Grid de Agentes.
            CargarSeccionAgentes();
            btnAdjuntar.Enabled = false;                
        }

        if (adjuntado == 1)
        {
            btnAdjuntar.Enabled = true;
            adjuntado = 0;            
        }
        else
        {
            if (adjuntado == 3)
            {
                btnAdjuntar.Enabled = true;                
            }
        }

        //Cambio para millon vida
        //Hidden de crecimiento y deducible
        HiddenCrecimiento.Value = ConfigurationManager.AppSettings["CrecimientoMV"];
        HdnDeducible.Value = ConfigurationManager.AppSettings["DeducibleMV"];
        HdnSumaPMinMV.Value = ConfigurationManager.AppSettings["SumaPMinMV"];
        HdnSumaDMinMV.Value = ConfigurationManager.AppSettings["SumaDMinMV"];
        hdnSumaMaxMV.Value = ConfigurationManager.AppSettings["SumaMaxMV"];        
        hdnPPR.Value = "S";
        DeshabilitarBtn();
        LlenarCombosCobro();

 }
//AEP BWMEILL. Millón Vida. Metodo para obtener el tipo d ecambio al día de hoy
    private static TipodeCambio getTipoCambio()
    {
        WebLogin objDAcceso = null;
        objDAcceso = new WebLogin();
        DataTable dtTipoCambio;
        TipodeCambio tipoCambio = new TipodeCambio();
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                dtTipoCambio = objDAcceso.getTipoCambio(conexion);
            }
            if (dtTipoCambio.Rows.Count > 0)
            {
                // Guarda valores en los campos ocultos para tomarlos desde tipodcambio.html
                foreach (DataRow drMoneda in dtTipoCambio.Rows)
                {
                    switch (drMoneda[0].ToString())
                    {
                        case "USD":
                            tipoCambio.USD = drMoneda[1].ToString();
                            break;
                        case "UDI":
                            tipoCambio.UDIS = drMoneda[1].ToString();
                            break;
                    }
                }
            }
            return tipoCambio;
        }
        catch (Exception ex)
        {
            MLogFile.getInstance().writeText(new pPage().getUsuario() + "Error:", ex);
            throw ex;
        }
    }
    public struct TipodeCambio
    {
        public string USD;
        public string UDIS;
    }

    void DeshabilitarBtn()
    {
        btnObtenerPrimas.Disabled = true;
        txtNTitular.Enabled = false;
        txtAPTitular.Enabled = false;
        txtAMTitular.Enabled = false;
    }

    /// <summary>
    /// Método para llenar los combos de cobro (Pasarela de cobro).
    /// </summary>
    void LlenarCombosCobro()
    {
        objCatalogos = new Catalogos();
        //Llena el mes y año de la pasarela de cobro
        if (HiddenRamoRequest.Value == "111")
        {
            int inicio = System.DateTime.Now.Year;
            int fin = inicio + 20;
            ddlMesTarjeta.Items.Insert(0, "Selecciona");
            ddlAnioTarjeta.Items.Insert(0, "Selecciona");
            for (int i = 1; i <= 12; i++)
            {
                if (i < 10)
                {
                    ddlMesTarjeta.Items.Insert(i, "0" + i.ToString());
                }
                else
                {
                    ddlMesTarjeta.Items.Insert(i, i.ToString());
                }
            }
            for (int j = 1; inicio <= fin; j++)
            {
                ddlAnioTarjeta.Items.Insert(j, inicio.ToString());
                inicio = inicio + 1;
            }

            //Llena el combo de Banco
            ddlBanco.DataSource = objCatalogos.getDatosCobro(1, 111, "A5020900", 7);
            ddlBanco.DataTextField = "NOM_ENTIDAD";
            ddlBanco.DataValueField = "COD_ENTIDAD";
            ddlBanco.DataBind();

            if (ddlBanco.Items.Count > 1)
            {
                ddlBanco.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Selecciona el banco", "-1"));
            }

            //Llenar el combo de Tipo de Tarjeta.
            ddlTipoTarjeta.DataSource = objCatalogos.getDatosCobro(1, 111, "A5020021", 1);
            ddlTipoTarjeta.DataTextField = "NOM_TIP_TARJETA";
            ddlTipoTarjeta.DataValueField = "TIP_TARJETA";
            ddlTipoTarjeta.DataBind();

            if (ddlTipoTarjeta.Items.Count > 1)
            {
                ddlTipoTarjeta.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Selecciona el tipo de tarjeta", "-1"));
            }

        }
    }
    
   
    /// <summary>
    /// Método para llenar controles DropDownList al momento de cargarse la Página.
    /// </summary>
    void LlenarDropDownLists()
    {
        objCatalogos = new Catalogos();      
        DataTable dtblmoneda = new DataTable();
        dtblmoneda = objCatalogos.getMoneda(Convert.ToInt32(HiddenRamoRequest.Value),
            HiddenContratoGenerico.Value, Convert.ToInt32(HiddenTipoPlanRequest.Value));

  if (HiddenRamoRequest.Value == "111"){
            for (int i = dtblmoneda.Rows.Count - 1; i >= 0; i--) {
                DataRow dtrmoneda = dtblmoneda.Rows[i];
                //AEP BWMEILL. Fase 2 Emisión Vida. Eliminar moneda Pesos
                if (dtrmoneda.ItemArray.GetValue(0).ToString() == "1")
                { dtrmoneda.Delete(); }
            }
        }
        General.llenaDropDown(drpMoneda, dtblmoneda, "COD_MON", "NOM_MON", "Selecciona");
        General.llenaDropDown(drpParentesco, objCatalogos.getParentesco(), "COD_VALOR", "NOM_VALOR", "Selecciona");
        General.llenaDropDown(drpTipBenef, objCatalogos.getTipoBeneficiario(), "COD_VALOR", "NOM_VALOR", "Selecciona");        
    }

    /// <summary>
    /// Método para agregar atributos a Controles de la página.
    /// </summary>
    void AgregarAtributos()
    {
        txtEdad.Attributes.Add("onKeyPress", "return KeyNumber(this, event);");
        txtEdad.Attributes.Add("onblur", "calcula_fechaNac(this.value);obtenerCoberturas();ValidarEdad();LimpiarPrimas();limpiaCombo('drpPlazo');limpiaCombo('drpComision');");
        drpSexo.Attributes.Add("onchange", "LimpiarPrimas();");
        drpFuma.Attributes.Add("onchange", "LimpiarPrimas();");
        rbtnListPolizaContrato.Attributes.Add("onclick", "OcultarMostrarDivsConContrato();");
        //AEP Bwmeill. Millón Vida FAse 2. Usar solomoneda dolares.
        rbtMetodoPago.Attributes.Add("onclick", "OcultarMostrarPasarelaPago();");
        drpPolizaGrupo.Attributes.Add("onchange", "LlenarDropContrato('drpContrato');LimpiarPrimas();");
        drpContrato.Attributes.Add("onchange", "LlenarPlanyMoneda('drpMoneda');LimpiarPrimas();");
        drpAgente.Attributes.Add("onchange", "limpiaCtrlsConAgente();cambiaAgente(this);getEmailAgente();LimpiarPrimas();");
        drpMoneda.Attributes.Add("onchange", "LlenarDropDuracion('drpPlazo');LimpiarPrimas();");
        drpComision.Attributes.Add("onchange", "ObtenerModalidad();LlenarDropFormaPago('drpFormaPago');LimpiarPrimas();obtenerCoberturas();");
        drpTipBenef.Attributes.Add("onchange", "SeleccionaParentesco(rblTipoSeguro);");

        //Se deja el condicional en caso de que sea necesaria una condicion especial para el ramo 100
        if (HiddenRamoRequest.Value == "100" || HiddenRamoRequest.Value == "111")
        {
            drpPlazo.Attributes.Add("onchange", "LlenarDropComision('drpComision');LimpiarPrimas();ObtenerModalidad();");
        }
        else
        {
            drpPlazo.Attributes.Add("onchange", "LlenarDropComision('drpComision');LimpiarPrimas();");  
        }

        drpFormaPago.Attributes.Add("onchange", "LlenarDropTipoPago('drpTipoPago');LimpiarPrimas();");
        drpTipoPago.Attributes.Add("onchange", "LimpiarPrimas(); LlenarOcupacion('drpOcupacion')");
		
        //Validación para mostrar el DropDownList de Deducible solo para el plan de Jubilación.
        if (HiddenRamoRequest.Value != "101")
        {
            lblDeducible.Visible = false;
            drpDeducible.Visible = false;
        }

        txtFecNac.Attributes.Add("onblur", "txtFecNac");
        txtNombreBenef.Attributes.Add("onKeyPress", "Convert(aMAYUSCULAS);ValidaCaptura(NOMBRE);");
        txtPaternoBenef.Attributes.Add("onKeyPress", "Convert(aMAYUSCULAS);ValidaCaptura(NOMBRE);");
        txtMaternoBenef.Attributes.Add("onKeyPress", "Convert(aMAYUSCULAS);ValidaCaptura(NOMBRE);");
        txtPctBenef.Attributes.Add("onKeyPress", "return KeyNumber(this, event);");
        txtNumTarjeta.Attributes.Add("onKeyPress", "ValidaCaptura(NUMERICO);");
        txtCodTarjeta.Attributes.Add("onKeyPress", "ValidaCaptura(NUMERICO);");
        btnModDatos.Attributes.Add("onclick", "focusCtrl('drpAgente');");        
        btnObtenerPrimas.Attributes.Add("onclick", "Cotiza();");
        btnObtenSumAseg.Attributes.Add("onclick", "ObtieneSumaMV();");
        drpParentesco.Attributes.Add("onchange","muestraRazonSocial(this)");
        btnImprimeSolicitud.Attributes.Add("onclick", "MM_ImprimirSolicitud();");
        btnImprimePoliza.Attributes.Add("onclick", "EsperaImpPoliza();");
        HiddenTiempoRetardo.Value = ConfigurationManager.AppSettings["TiempoRetardo"].ToString();
        btnNuevaSolicitud.Attributes.Add("onclick", "NuevaEmision();");
        txtNumTarjeta.Attributes.Add("onblur", "ValidaTarjeta();");

        //MV Cuadros de Comisión INI
        Session["ramo"] = HiddenRamoRequest.Value.ToString();
        int agt = Convert.ToInt32(HiddenAgente.Value.ToString());
        Catalogos cata = new Catalogos();
        string mensage = null;
        HidCuadroCom.Value = cata.getcuadrocomMV(agt,Convert.ToInt32(HiddenRamoRequest.Value.ToString()));
        Usuario objUsuario = ((Usuario)Session["sUSUARIO"]);
        if (objUsuario.TIPO_USUARIO != 0)
        {
            if (HidCuadroCom.Value == "")
            {
                mensage = "alert('El Agente no cuenta con Cuadro de Comisión para este producto.');";
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Alert", mensage, true);
                txtEdad.Enabled = false;
            }
        }
        //MV Cuadros de Comisión FIN
    }

    void ConfigurarControlesCLM()
    {
        //Control Contratante
        UscContCLM.TipoUC = TipoBeneficiario.Contratante;
        UscContCLM.UCchkContSol.Visible = false;
        UscContCLM.veProfesion = false;
        UscContCLM.veEdoCivil = false;
        UscContCLM.veSexo = false;
        UscContCLM.veNacimiento = false;
        UscContCLM.veEdad = false;
        UscContCLM.veCargo = false;
        UscContCLM.veNacionalidad = false;
        UscContCLM.TipoUCDestinos = new TipoBeneficiario[] { TipoBeneficiario.Asegurado };
        UscContCLM.generaToken(Session["sUSUARIO"]);
        //Control Solicitante
        UscAsegCLM.TipoUC = TipoBeneficiario.Asegurado;
        UscAsegCLM.TipoUCOrigen = TipoBeneficiario.Contratante;
        UscAsegCLM.veProfesion = false;
        UscAsegCLM.veCargo = false;
        UscAsegCLM.validaCopiaScript = "validaCopia();";
        UscAsegCLM.generaToken(Session["sUSUARIO"]);
        UscAsegCLM.AfterScript_DatosCLM = "LlenarDatosDelSeguro();validarBoton b b();valOcupacion();";
        UscAsegCLM.veFacturar = false;
    }

    protected string getNombreRamo(string strCodRamo)
    {
        string strNombreRamo = "";
        objCatalogos = new Catalogos();
        DataTable dtRamos = objCatalogos.getRamos();
        DataRow[] drRamo = dtRamos.Select("COD_RAMO = " + strCodRamo);
        if (drRamo.Count() > 0)
        {
            DataRow drR = drRamo[0];
            strNombreRamo = drR[1].ToString();
        }
        return strNombreRamo;
    }

    protected void gvCuestionario_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        string rowID = String.Empty;
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Font.Bold = true;
            indiceRow = 0;
        }
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            indiceRow++;
            rowID = "row" + e.Row.RowIndex;
            e.Row.Attributes.Add("id", "row" + e.Row.RowIndex);
            e.Row.Cells[0].Width = 20;
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Right;
            e.Row.Cells[2].Width = 10;
            e.Row.Cells[3].Width = 10;
            e.Row.Cells[0].Text = indiceRow.ToString() + ".-";
            e.Row.Cells[2].Text = "<input id='chkSi" + indiceRow +
                "' type='checkbox' runat='server' name='chkSi' onclick='selCheckBox(" + indiceRow + ", \"Si\")' />";
            e.Row.Cells[3].Text = "<input id='chkNo" + indiceRow + 
                "' type='checkbox' runat='server' name='chkNo' checked onclick='selCheckBox(" + indiceRow + ", \"No\")' />";
        }
    }

    private void ClearContents(Control control)
    {
        for (var i = 0; i < Session.Keys.Count; i++)
        {
            if (Session.Keys[i].Contains(control.ClientID))
            {
                Session.Remove(Session.Keys[i]);
                break;
            }
        }
    }

    public void btnEnviar_Click(object sender, EventArgs e)
    {
        string strMensaje = "";
        string strPoliza = HiddenNoSolPol.Value;
        string strIdCotizacion = "";
        int cotizacion = 0;
        string strSistRAM = "";
        string strPath = ConfigurationManager.AppSettings["pathlocal"].ToString();
        DatosVidaClass vida = new DatosVidaClass();
        try
        {
            if (Session["numCotizacion"] != null)
            {
                strIdCotizacion = Session["numCotizacion"].ToString();
                cotizacion = 1;
            }
            else
            {
                cotizacion = 0;
            }

            HiddenIDSistemaRAM.Value = vida.ObtenerIDSistema();
            strSistRAM = HiddenIDSistemaRAM.Value;
            string strNombreArchivo = "";
            DataTable dt = dtAdjuntos;

            if (archivoCargado == null || cotizacion == 0)
            {
                if (archivoCargado == null)
                {
                    strMensaje = "NO SE SELECCIONÓ ARCHIVO PARA ENVIAR";
                }
                else
                {
                    strMensaje = "DEBE REALIZAR PRIMERO LA COTIZACIÓN DE COBERTURAS";
                }
                adjuntado = 3;
            }
            else
            {
                if (archivoCargado.FailedValidation == true)
                {
                    strMensaje = "SOLO IMAGEN O PDF";
                }
                else
                {
                    strNombreArchivo = System.IO.Path.GetFileName(archivoCargado.PostedFile.FileName);
                    if (Convert.ToBoolean(ConfigurationManager.AppSettings["SubirArchivo"]))
                    {
                        DatosVidaClass EnviarArcAFolioRAM = new DatosVidaClass();
                        strMensaje = EnviarArcAFolioRAM.SubirArchivo(strPoliza, strIdCotizacion, strPath, strNombreArchivo, strSistRAM);
                        if (strMensaje != "No pudo ser adjuntado el archivo en Documentum.")
                        {
                            DataRow dr = dt.NewRow();
                            dr["Archivo(s) adjunto(s)"] = strNombreArchivo;
                            dt.Rows.Add(dr);
                            dt.AcceptChanges();
                            grdAdjuntarArchivo.DataSource = dt;
                            grdAdjuntarArchivo.DataBind();
                            adjuntado = 1;
                        }
                    }
                    else
                        strMensaje = "EL MODO PARA SUBIR ARCHIVOS ESTÁ DESHABILITADO, CONSULTA A TU ADMINISTRADOR.";
                }
            }

            //Millon Vida: Se retira temporalmente para evitar problemas en Firefox y poder depurar errores, regresa para version final
            ClearContents(AsyncFileUpload1);
            archivoCargado = null;
            Page_Load(sender, e);
            ScriptManager.RegisterStartupScript(btnAdjuntar, btnAdjuntar.GetType(), "cargando2", "Cargando2(false)", true);
            ScriptManager.RegisterStartupScript(btnAdjuntar, btnAdjuntar.GetType(), "mensaje", "alert('" + strMensaje.ToUpper() + "')", true);
            ScriptManager.RegisterStartupScript(btnAdjuntar, btnAdjuntar.GetType(), "mensaje", "habilitarCtrl('btnEmite',true)", true);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
        }
    }

    void SetSesionesBeneficiarios()
    {
        if (Session["Beneficiarios"] != null)
        {
            Beneficiario objBeneficiario = new Beneficiario();
            objBeneficiario.Beneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();

            int ContNoBenef = objBeneficiario.CuentaNoBeneficiarios();
            for (int i = 1; i <= ContNoBenef; i++)
            {
                if (Session["BenefAd" + i] != null)
                    Session.Remove("BenefAd" + i);
            }
        }
    }


    #region Seccion de Tabla de Agentes.
    void CargarSeccionAgentes()
    {
        drpIntMasDeUnAgente.Attributes.Add("onchange", "javascript:AsignaCveA();");

        //******************** Funciones para Insertar,Editar o borrar en el GRID ********************
        //********************									  *********************
        lnkInsertar.Attributes.Add("onclick", "javascript:InsertaAgentecedentes();return false;");
        lnkModificar.Attributes.Add("onclick", "javascript:ModificaAgentecedentes();return false;");
        lnkBorrar.Attributes.Add("onclick", "javascript:BorrarAgentecedentes();return false;");

        //****************************************************************

        //Valida la entrada de caracteres que sean solo números.
        //txtAgente.Attributes.Add("onkeypress", "javascript:ValidaCaptura(PATRON_NUMERICO_PUNTO);");
        txtClaveAgen.Attributes.Add("onkeypress", "javascript:ValidaCaptura(PATRON_NUMERICO);");
        txtClaveAgen.Attributes.Add("onBlur", "javascript:wsObtieneAgente();");
        txtClaveA.Attributes.Add("onkeypress", "javascript:ValidaCaptura(PATRON_NUMERICO);");
        txtClaveA.Attributes.Add("onBlur", "javascript:wsObtieneAgente2();");

        //Nuevas para TRON WEB
        txtPorcentaje.Attributes.Add("onkeypress", "javascript:ValidaCaptura(PATRON_NUMERICO);");
        CleanDtg();
    }

    //Esta Función nos permite limpiar el datagrid
    //e inicializarlo en Blanco al Inicio cuando se carga el User Control
    //si no se ejecuta NO aparece el datagrid al iniciar
    private void CleanDtg()
    {
        DataSet dts = Gendts();
        dtgReferencias.DataSource = dts.Tables[0].DefaultView;
        dtgReferencias.VirtualItemCount = 4;
        dtgReferencias.DataBind();
    }

    private DataSet Gendts()
    {
        DataRow dtrRenglon;
        DataSet dts = new DataSet();
        dts.Tables.Add("NewRow");
        dts.Tables["NewRow"].Columns.Add("NomAgente");
        dts.Tables["NewRow"].Columns.Add("Clave");
        dts.Tables["NewRow"].Columns.Add("Porcentaje");     
        //fijo a 5 renglones
        //for (int intIndex = 0; intIndex < 5; intIndex++)
        //fijo a 4 renglones
        for (int intIndex = 0; intIndex < 4; intIndex++)
        {
            dtrRenglon = dts.Tables["NewRow"].NewRow();
            dtrRenglon["NomAgente"] = "";
            dtrRenglon["Clave"] = "";
            dtrRenglon["Porcentaje"] = "";
            dts.Tables["NewRow"].Rows.Add(dtrRenglon);
        }
        return dts;
    }
    #endregion


    public void FileUploadComplete(object sender, EventArgs e)
    {
        //Millon Vida: Se retira temporalmente para evitar problemas en Firefox y poder depurar errores, regresa para version final
        archivoCargado = AsyncFileUpload1;
        string strNombreArchivo = "";
        FileChecker clsValida;
        string strExt;
        string strValida;
        string file;
        string file2;
        try
        {
            string strPath = ConfigurationManager.AppSettings["pathlocal"].ToString();
            strNombreArchivo = System.IO.Path.GetFileName(archivoCargado.PostedFile.FileName);
            archivoCargado.PostedFile.SaveAs(strPath + strNombreArchivo);
            //Se crea ademas una copia del archivo con el mismo nombre pero adicionando
            //un número dos. Esto debido a que Documentum elimina de forma automatica el
            //archivo y este se necesitará de nuevo al momento que se obtiene el número 
            //de folio ram
            strNombreArchivo = "2" + strNombreArchivo;
            archivoCargado.PostedFile.SaveAs(strPath + strNombreArchivo);
            btnAdjuntar.Enabled = true;

            //Validacion del tipo de dato del archivo
            strNombreArchivo = System.IO.Path.GetFileName(archivoCargado.PostedFile.FileName);

            //validacion del archivo 
            strExt = strNombreArchivo.Substring(strNombreArchivo.LastIndexOf(".") + 1);
            Stream infAdjuntar = File.OpenRead(strPath + strNombreArchivo);
            clsValida = new FileChecker(strExt, infAdjuntar);
            strValida = clsValida.ValidaExtension();
            infAdjuntar.Close();

            if (!string.IsNullOrEmpty(strValida))
            {
                //El archivo no es valido para subirlo al servidor
                //por lo que se debe borrar el original y la copia
                file = WebUtils.getAppSetting("pathlocal").ToString() + System.IO.Path.GetFileName(strPath + strNombreArchivo).ToString();
                file2 = WebUtils.getAppSetting("pathlocal").ToString() + System.IO.Path.GetFileName(strPath + "2" + strNombreArchivo).ToString();
                try
                {
                    System.IO.File.Delete(file);
                    System.IO.File.Delete(file2);
                }
                catch (Exception exe)
                {
                    MapfreMMX.util.MLogFile.getInstance().writeText("Error...", exe);
                }
                archivoCargado.FailedValidation = true;
            }
            Page_Load(sender, e);
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error...", ex);
        }
    }

    public void AnexarDocRAM_(object sender, EventArgs e)
    {
        int codigoRamo = int.Parse(Request.Form["HiddenRamoRequest"]);
        int modalidad = int.Parse(Request.Form["HiddenModalidad"]);
        int contrato = int.Parse(Request.Form["HiddenContratoGenerico"]);
        string cuestionarioRespuestas = Request.Form["HiddenRespuestasCuestionario"];
        string strPath = ConfigurationManager.AppSettings["pathlocal"].ToString() + "AnexoCuestionario.csv";
        FileStream fs = new FileStream(strPath, FileMode.Create,
                                          FileAccess.ReadWrite);
        StreamWriter w;
        w = new StreamWriter(fs);
        w.Write(cuestionarioRespuestas);
        w.Close();

        //Enviar adjunto a RAM
        string strPoliza = HiddenNoSolPol.Value;
        string strIdCotizacion = string.Empty;
        string strNombreArchivo = "AnexoCuestionario.csv";
        string strSistRAM = HiddenIDSistemaRAM.Value;
        if (Session["numCotizacion"] != null)
        {
            strIdCotizacion = Session["numCotizacion"].ToString();
        }

        DatosVidaClass EnviarArcAFolioRAM = new DatosVidaClass();
        string strMensaje = EnviarArcAFolioRAM.SubirArchivo(strPoliza, strIdCotizacion, strPath, strNombreArchivo, strSistRAM);
        DataTable dt = dtAdjuntos;
        if (strMensaje != "No pudo ser adjuntado el archivo en Documentum.")
        {
            DataRow dr = dt.NewRow();
            dr["Archivo(s) adjunto(s)"] = strNombreArchivo;
            dt.Rows.Add(dr);
            dt.AcceptChanges();
            grdAdjuntarArchivo.DataSource = dt;
            grdAdjuntarArchivo.DataBind();
            adjuntado = 1;
        }
    }

    public void CambiarEstadoRAM(object sender, EventArgs e)
    {
        string modoEmision = Request.Form["HiddenModoEmision"];
        string estatus = string.Empty;
        if (modoEmision == "P")
            estatus = "Impresión/Integración";
        else
            estatus = "Suscripción";
        //ToDo: Actualizar estatus en RAM via WS
    }
}


