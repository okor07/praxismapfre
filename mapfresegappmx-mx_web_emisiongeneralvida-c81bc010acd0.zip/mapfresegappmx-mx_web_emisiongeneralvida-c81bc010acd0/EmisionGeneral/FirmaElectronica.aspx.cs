﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Oracle.DataAccess.Client;
using MapfreMMX.oracle;

using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.xml;

using System.IO;
using System.Text;
using System.Globalization;
using MapfreMMX.util;

public partial class EmisionGeneral_FirmaElectronica : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Ajax.Utility.RegisterTypeForAjax(typeof(MetodosAjax));
        try
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Entra FirmaElectronica");
            if (string.IsNullOrEmpty(Request.Form["numCotizacion"]) && string.IsNullOrEmpty(Request.Form["txtSolicitante"])
                && string.IsNullOrEmpty(Request.Form["txtContratante"]) && string.IsNullOrEmpty(Request.Form["age"]) && string.IsNullOrEmpty(Request.Form["ramo"]))
            {
                Response.Write("<div id='divError' class='col-12' align='center'>");
                Response.Write("<br />");
                Response.Write("<p>ERROR:</p>");
                Response.Write("Lo sentimos, no se cargaron correctamente los datos. Favor de intentar nuevamente");
                Response.Write("<br />");
                Response.Write("<br />");
                Response.Write("<input id='btnCerrarError' type='button' runat='server' onclick='Cerrar()' value='Cerrar' class='btn btnred_g' style='width: 210px;' />");
                Response.Write("</div>");
            }
            else
            {
                string numCotizacion = Request.Form["numCotizacion"];
                string asegurado = Request.Form["txtSolicitante"];
                string contratante = Request.Form["txtContratante"];
                string agente = Request.Form["age"];
                string ramo = Request.Form["ramo"];
                bool cuestionarioMillon = Convert.ToBoolean(Request.Form["cuestionarioMillon"]);
                string fecNacAseg = string.IsNullOrEmpty(Request.Form["txtFecNacAseg"]) ? "" : Request.Form["txtFecNacAseg"];

                //Variables para recuperar los correos del contratante, asegurado y agente, así com el teléfono del agente en caso de que la SA sea mayor a 1.5MDP
                string mailContratante = "";
                string mailAsegurado = "";
                string mailAgente = "";
                string telAgente = "";

                MapfreMMX.util.MLogFile.getInstance().writeText("NumCotizacion: " + numCotizacion);
                MapfreMMX.util.MLogFile.getInstance().writeText("Asegurado: " + asegurado);
                MapfreMMX.util.MLogFile.getInstance().writeText("Contratante: " + contratante);
                MapfreMMX.util.MLogFile.getInstance().writeText("Agente: " + agente);
                MapfreMMX.util.MLogFile.getInstance().writeText("CuestionarioMillon: " + cuestionarioMillon.ToString());

                FillFormSolicitud(numCotizacion);

                if (Request.Form["version"] == "1")
                    FillFormCuestionariMedico(numCotizacion);
                else
                    FillFormCuestionariMedicoNuevo(numCotizacion);


                string[] pdfs;
                if (cuestionarioMillon)
                {
                    //En caso de que la SA sea mayor a 1.5MDP recuperar el correo del agente asi como el teléfono del cuestionario.
                    //Correo del agente.
                    //Si se capturó se muestra.
                    if (Request.Form["txtSAEmailAgt"].ToString() != "" && Request.Form["txtSAEmailAgt"].ToString() != string.Empty)
                    {
                        mailAgente = Request.Form["txtSAEmailAgt"];
                    }

                    if (Request.Form["txtSATelAgt"].ToString() != "" && Request.Form["txtSATelAgt"].ToString() != string.Empty)
                    {
                        //Teléfono del Agente:
                        telAgente = Request.Form["txtSATelAgt"];
                    }


                    FillFormCuestionarioSumaAsegurada(numCotizacion);
                    pdfs = new string[] { "C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Firma\\sv_" + numCotizacion + ".pdf", "C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Firma\\cSA_" + numCotizacion + ".pdf", "C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Firma\\cer_" + numCotizacion + ".pdf", "C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Aviso_de_Privacidad.pdf" };
                }
                else
                {
                    pdfs = new string[] { "C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Firma\\sv_" + numCotizacion + ".pdf", "C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Firma\\cer_" + numCotizacion + ".pdf", "C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Aviso_de_Privacidad.pdf" };
                }
                CombineMultiplePDFs(pdfs, "C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\Firma\\" + numCotizacion + ".pdf");

                //Correo del contratante
                //Persona Fisica:
                if (Request.Form["txtCorreoElectronicoPersonaFisica"].ToString() != "" && Request.Form["txtCorreoElectronicoPersonaFisica"].ToString() != string.Empty)
                {
                    mailContratante = Request.Form["txtCorreoElectronicoPersonaFisica"];
                }
                //Persona Moral:
                if (Request.Form["txtCorreoElectrPagWeb"].ToString() != "" && Request.Form["txtCorreoElectrPagWeb"].ToString() != string.Empty)
                {
                    mailContratante = Request.Form["txtCorreoElectrPagWeb"];
                }
                //Correo del asegurado
                if (Request.Form["txtCorreoElectronicoSolicitante"].ToString() != "" && Request.Form["txtCorreoElectronicoSolicitante"].ToString() != string.Empty)
                {
                    mailAsegurado = Request.Form["txtCorreoElectronicoSolicitante"];
                }
                //Correo del agente en caso de que no se haya capturado en el cuestionario del millon
                //Si no se capturó se muestra de la estructura del usuario en TW.
                if (mailAgente == "")
                {
                    Usuario objUsuario = ((Usuario)Session["sUSUARIO"]);
                    mailAgente = new MetodosAjax().getCorreoAgente(objUsuario.COD_AGENTE);
                }

                Response.Write("<ajaxToolkit:ToolkitScriptManager ID='scriptManager' runat='server' EnablePartialRendering='true'></ajaxToolkit:ToolkitScriptManager>");
                Response.Write("<div id='divPDF' class='col-12'><table border='1'><tr><td>");
                Response.Write("<embed src='../SolicitudPDF/Firma/" + numCotizacion + ".pdf' width='800' height='800'></td>");
                Response.Write("<td rowspan='2' style='text-align:left;vertical-align:top;padding:15'>");
                Response.Write("<fieldset style='width: 100%; margin-top: 35px; padding: 5px; border: 1px solid #EFEFEF; -webkit-border-radius: 10px; -moz-border-radius: 10px; border-radius: 20px;'><legend class='EtiquetaGeneralDescripcionRoja'>Estimado asegurado, por favor lee detenidamente la solicitud para verificar que todos los datos son correctos</legend><div id='grdBeneficiarios'></div></fieldset>");
                Response.Write("<p>Para iniciar el proceso de firma favor, de proporcionar correos electr&oacute;nicos y un n&uacute;mero de celular</p>");
                Response.Write("<br />Correo Electr&oacute;nico del contratante<br />(" + contratante.Replace("|", " ") + ") <br />");
                Response.Write("<input runat='server' name='txtMailContratante' type='text' maxlength='50' id='txtMailContratante' class='form-control inp-sel-48' placeholder='mail@mail.com' value='" + mailContratante + "' />");
                Response.Write("<br />Correo Electr&oacute;nico del asegurado<br />(" + asegurado.Replace("|", " ") + ") <br />");
                Response.Write("<input runat='server' name='txtMailAsegurado' type='text' maxlength='50' id='txtMailAsegurado' class='form-control inp-sel-48' placeholder='mail@mail.com' value='" + mailAsegurado + "' />");
                Response.Write("<br />Correo Electr&oacute;nico del agente<br />(" + agente + ") <br />");
                Response.Write("<input runat='server' name='txtMailAgente' type='text' maxlength='50' id='txtMailAgente' class='form-control inp-sel-48' placeholder='mail@mail.com' value='" + mailAgente + "' />");
                Response.Write("<br /><br />Tel&eacute;fono: <br />");
                Response.Write("<input name='txtTelefono' type='text' maxlength='20' id='txtTelefono' class='form-control inp-sel-48' placeholder='5512345678' value='" + telAgente + "' />");

                Response.Write("<br /><br /><br /><input id='envFirma' type='button' runat='server' value='Enviar a Firmar' class='btn btnred_g' style='width: 210px;' onclick='envFirma(\"P\", \"firma\", \"" + numCotizacion + "\", \"" + contratante + "\", \"" + asegurado + "\", \"" + agente + "\", \"" + ramo + "\", \"" + fecNacAseg + "\")' />");
                Response.Write("</td></tr></table></div>");

                Response.Write("<div style='display : none;' id='divMensaje' class='col-12' align='center'>");
                Response.Write("<br />");
                Response.Write("<p>¡MUCHAS GRACIAS!</p>");
                Response.Write("Se te ha enviado un correo electr&oacute;nico, para continuar con el proceso de firma biom&eacute;trica digital, por favor abre el correo en el que encontrar&aacute;s:");
                Response.Write("<br />");
                Response.Write("&#8226; La solicitud pre-llenada que contiene tu informaci&oacute;n previamente capturada durante el proceso de emisi&oacute;n.");
                Response.Write("<br />");
                Response.Write("&#8226; La liga para continuar con la firma biom&eacute;trica digital");
                Response.Write("<br />");
                Response.Write("<strong><em>La contrase&ntilde;a para visualizar el pdf adjunto en los correos enviados es DDMMAAAA</em></strong> y deber&aacute; recuperar la fecha de nacimiento del asegurado.");
                Response.Write("<br />");
                Response.Write("Los datos del folio generado son:");
                Response.Write("<br />");
                Response.Write("<table>");
                Response.Write("<tr>");
                Response.Write("<td style='width: 25%;'></td>");
                Response.Write("<td style='width: 50%;'>");
                Response.Write("<table class='table table-bordered tab-border-red' style='width: 100%;' border='0' cellpadding='0' cellspacing='0'>");
                Response.Write("<tr class='table-danger' style='color: #FFF;'>");
                Response.Write("<td align='center'>Folio</td>");
                Response.Write("<td align='center'>Solicitud</td>");
                Response.Write("</tr>");
                Response.Write("<tr>");
                Response.Write("<td id='tdFolio' runat='server' align='center'><input </td>");
                Response.Write("<td id='tdSolicitud' runat='server' align='center'></td>");
                Response.Write("</tr>");
                Response.Write("</table>");
                Response.Write("</td>");
                Response.Write("<td style='width: 25%;'></td>");
                Response.Write("</tr>");
                Response.Write("</table>");
                Response.Write("<br />");
                Response.Write("<br />");
                Response.Write("<input id='btnCerrarFirma' type='button' runat='server' onclick='Cerrar()' value='Cerrar' class='btn btnred_g' style='width: 210px;' />");
                Response.Write("</div>");

                Response.Write("<div class='contenedor'>");
                Response.Write("<div class='main' style='display: block;'>");
                Response.Write("<div class='contenido_g'>");
                Response.Write("<div class='modalBackground' style='display: none;' id='divCargando' runat='server'>");
                Response.Write("<asp:Panel ID='PanelCargando' runat='server' Style='position: absolute; left: 50%; top: 15%'>");
                Response.Write("<table cellspacing='0' cellpadding='0' border='0'>");
                Response.Write("<tr>");
                Response.Write("<td>");
                Response.Write("<img alt='' src='../Common/Images/spinner.gif' width='16' height='16' border='0' />&nbsp;");
                Response.Write("<asp:Label ID='lblProcesando' runat='server' Text='Procesando...' CssClass='letraTitulosBoldBlancaDerecha'></asp:Label>");
                Response.Write("</td>");
                Response.Write("</tr>");
                Response.Write("</table>");
                Response.Write("</asp:Panel>");
                Response.Write("</div></div></div></div>");

                ScriptManager.RegisterStartupScript(this, this.Page.GetType(), "refreshWindow();", "refreshWindow();", true);
            }
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error FirmaElectronica: " + ex.Message);
        }
    }
    public static void CombineMultiplePDFs(string[] fileNames, string outFile)
    {
        try
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Entra CombineMultiplePDFs");
            // step 1: creation of a document-object
            Document document = new Document();
            //create newFileStream object which will be disposed at the end
            using (FileStream newFileStream = new FileStream(outFile, FileMode.Create))
            {
                MapfreMMX.util.MLogFile.getInstance().writeText("Crea archivo");
                // step 2: we create a writer that listens to the document
                PdfCopy writer = new PdfCopy(document, newFileStream);
                if (writer == null)
                {
                    return;
                }

                // step 3: we open the document
                document.Open();
                MapfreMMX.util.MLogFile.getInstance().writeText("Abre documento");
                foreach (string fileName in fileNames)
                {
                    MapfreMMX.util.MLogFile.getInstance().writeText("Agrega archivo: " + fileName);
                    // we create a reader for a certain document
                    PdfReader reader = new PdfReader(fileName);
                    reader.ConsolidateNamedDestinations();
                    MapfreMMX.util.MLogFile.getInstance().writeText("Consolida archivo");

                    // step 4: we add content
                    for (int i = 1; i <= reader.NumberOfPages; i++)
                    {
                        PdfImportedPage page = writer.GetImportedPage(reader, i);
                        writer.AddPage(page);
                    }

                    PRAcroForm form = reader.AcroForm;
                    if (form != null)
                    {
                        writer.CopyAcroForm(reader);
                    }

                    reader.Close();
                }

                // step 5: we close the document and writer
                writer.Close();
                document.Close();
                MapfreMMX.util.MLogFile.getInstance().writeText("Termina PDF");
            }//disposes the newFileStream object
        }
        catch (Exception ex)
        {
            MapfreMMX.util.MLogFile.getInstance().writeText("Error CombineMultiplePDFs:" + ex.Message);
        }
    }

    public void FillFormCuestionariMedico(string numCotizacion)
    {
        //AcroFields pdfFormFields = pdfStamper.AcroFields;
        #region DeclaraVariables
        // The first worksheet and W-4 form
        String chkSiPregunta4 = "";
        String chkSiPregunta6 = "";
        String chkNoPregunta3 = "";
        String chkSiPregunta1 = "";
        String txtpregunta4 = "";
        String txtpregunta5 = "";
        String chkNoPregunta3d = "";
        String chkSiPregunta3d = "";
        String chkNoPregunta3c = "";
        String txtPoliza1 = "";
        String txtPoliza2 = "";
        String txtSolicitante = "";
        String txtPoliza3 = "";
        String txtPregunta1 = "";
        String chkSiPregunta2 = "";
        String txtPoliza11 = "";
        String txtPoliza10 = "";
        String txtPoliza13 = "";
        String txtPoliza12 = "";
        String chkNoPregunta6 = "";
        String txtPoliza5 = "";
        String txtPoliza6 = "";
        String txtFolio8 = "";
        String txtFolio9 = "";
        String txtPoliza7 = "";
        String chkNoPregunta3e = "";
        String txtFolio4 = "";
        String txtFolio5 = "";
        String txtFolio6 = "";
        String txtFolio7 = "";
        String chkNoPregunta3b = "";
        String txtFolio1 = "";
        String txtFolio2 = "";
        String txtFolio3 = "";
        String chkSiPregunta3c = "";
        String chkSiPregunta3b = "";
        String chkSiPregunta3e = "";
        String txtPoliza4 = "";
        String chkSiPregunta3g = "";
        String chkSiPregunta3f = "";
        String txtContratante = "";
        String chkNoPregunta1 = "";
        String txtFolio13 = "";
        String txtLugaryFecha = "";
        String txtFolio12 = "";
        String chkNoPregunta3g = "";
        String txtFolio11 = "";
        String chkNoPregunta2 = "";
        String txtFolio10 = "";
        String chkNoPregunta3a = "";
        String chkSiPregunta5 = "";
        String chkNoPregunta3f = "";
        String txtPoliza8 = "";
        String chkNoPregunta4 = "";
        String txtPoliza9 = "";
        String chkSiPregunta3 = "";
        String txtpregunta6 = "";
        String chkNoPregunta5 = "";
        String chkSiPregunta3a = "";
        #endregion
        #region setVariables
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta4"])) { chkSiPregunta4 = Request.Form["chkSiPregunta4"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta6"])) { chkSiPregunta6 = Request.Form["chkSiPregunta6"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta3"])) { chkNoPregunta3 = Request.Form["chkNoPregunta3"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta1"])) { chkSiPregunta1 = Request.Form["chkSiPregunta1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtpregunta4"])) { txtpregunta4 = Request.Form["txtpregunta4"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtpregunta5"])) { txtpregunta5 = Request.Form["txtpregunta5"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta3d"])) { chkNoPregunta3d = Request.Form["chkNoPregunta3d"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta3d"])) { chkSiPregunta3d = Request.Form["chkSiPregunta3d"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta3c"])) { chkNoPregunta3c = Request.Form["chkNoPregunta3c"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza1"])) { txtPoliza1 = Request.Form["txtPoliza1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza2"])) { txtPoliza2 = Request.Form["txtPoliza2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSolicitante"])) { txtSolicitante = Request.Form["txtSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza3"])) { txtPoliza3 = Request.Form["txtPoliza3"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPregunta1"])) { txtPregunta1 = Request.Form["txtPregunta1"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta2"])) { chkSiPregunta2 = Request.Form["chkSiPregunta2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza11"])) { txtPoliza11 = Request.Form["txtPoliza11"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza10"])) { txtPoliza10 = Request.Form["txtPoliza10"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza13"])) { txtPoliza13 = Request.Form["txtPoliza13"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza12"])) { txtPoliza12 = Request.Form["txtPoliza12"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta6"])) { chkNoPregunta6 = Request.Form["chkNoPregunta6"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza5"])) { txtPoliza5 = Request.Form["txtPoliza5"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza6"])) { txtPoliza6 = Request.Form["txtPoliza6"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio8"])) { txtFolio8 = Request.Form["txtFolio8"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio9"])) { txtFolio9 = Request.Form["txtFolio9"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza7"])) { txtPoliza7 = Request.Form["txtPoliza7"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta3e"])) { chkNoPregunta3e = Request.Form["chkNoPregunta3e"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio4"])) { txtFolio4 = Request.Form["txtFolio4"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio5"])) { txtFolio5 = Request.Form["txtFolio5"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio6"])) { txtFolio6 = Request.Form["txtFolio6"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio7"])) { txtFolio7 = Request.Form["txtFolio7"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta3b"])) { chkNoPregunta3b = Request.Form["chkNoPregunta3b"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio1"])) { txtFolio1 = Request.Form["txtFolio1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio2"])) { txtFolio2 = Request.Form["txtFolio2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio3"])) { txtFolio3 = Request.Form["txtFolio3"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta3c"])) { chkSiPregunta3c = Request.Form["chkSiPregunta3c"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta3b"])) { chkSiPregunta3b = Request.Form["chkSiPregunta3b"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta3e"])) { chkSiPregunta3e = Request.Form["chkSiPregunta3e"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza4"])) { txtPoliza4 = Request.Form["txtPoliza4"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta3g"])) { chkSiPregunta3g = Request.Form["chkSiPregunta3g"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta3f"])) { chkSiPregunta3f = Request.Form["chkSiPregunta3f"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtContratante"])) { txtContratante = Request.Form["txtContratante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta1"])) { chkNoPregunta1 = Request.Form["chkNoPregunta1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio13"])) { txtFolio13 = Request.Form["txtFolio13"]; }
        //if (!string.IsNullOrEmpty(Request.Form["txtLugaryFecha"])) { txtLugaryFecha = Request.Form["txtLugaryFecha"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio12"])) { txtFolio12 = Request.Form["txtFolio12"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta3g"])) { chkNoPregunta3g = Request.Form["chkNoPregunta3g"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio11"])) { txtFolio11 = Request.Form["txtFolio11"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta2"])) { chkNoPregunta2 = Request.Form["chkNoPregunta2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio10"])) { txtFolio10 = Request.Form["txtFolio10"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta3a"])) { chkNoPregunta3a = Request.Form["chkNoPregunta3a"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta5"])) { chkSiPregunta5 = Request.Form["chkSiPregunta5"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta3f"])) { chkNoPregunta3f = Request.Form["chkNoPregunta3f"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza8"])) { txtPoliza8 = Request.Form["txtPoliza8"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta4"])) { chkNoPregunta4 = Request.Form["chkNoPregunta4"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza9"])) { txtPoliza9 = Request.Form["txtPoliza9"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta3"])) { chkSiPregunta3 = Request.Form["chkSiPregunta3"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtpregunta6"])) { txtpregunta6 = Request.Form["txtpregunta6"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta5"])) { chkNoPregunta5 = Request.Form["chkNoPregunta5"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta3a"])) { chkSiPregunta3a = Request.Form["chkSiPregunta3a"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtEstadoProvinciaSolicitante"]) && !string.IsNullOrEmpty(Request.Form["txtMunicipioDelegacionSolicitante"])) { txtLugaryFecha = Request.Form["txtMunicipioDelegacionSolicitante"] + ", " + Request.Form["txtEstadoProvinciaSolicitante"] + " " + DateTime.Today.ToString("dd MM yyy"); }
        #endregion
        XElement ROOT = new XElement("ROOT");
        ROOT.Add(new XElement("COMPANIA", "1"));
        ROOT.Add(new XElement("RAMO", "100"));
        ROOT.Add(new XElement("ACTIVIDAD", "EMISION"));
        ROOT.Add(new XElement("IDIOMA", "mx_ES"));

        #region DISTRIBUCION
        XElement DISTRIBUCION = new XElement("DISTRIBUCION");

        DISTRIBUCION.Add(new XElement("DUPLEX_MODE", "FALSE"));
        DISTRIBUCION.Add(new XElement("LOCAL", "TRUE"));

        #region GESTOR_DOCUMENTAL
        XElement GESTOR_DOC = new XElement("GESTOR_DOCUMENTAL");

        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_SFILENAME", ""));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_FOLDER", ""));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_OBJETO", ""));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_CODCIA", ""));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_NUMPOLIZA", ""));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_NUMSUPLEMENTO"));
        //GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_NUMFOLIO", ""));

        DISTRIBUCION.Add(GESTOR_DOC);

        #endregion GESTOR_DOCUMENTAL

        #region EMAIL
        XElement EMAIL = new XElement("EMAIL");

        EMAIL.Add(new XElement("EMAIL_TO", ""));
        EMAIL.Add(new XElement("EMAIL_FROM", "servicioDocumental@mapfre.com.mx"));
        EMAIL.Add(new XElement("EMAIL_REPLY_TO"));
        EMAIL.Add(new XElement("EMAIL_ASUNTO", "Prueba"));
        EMAIL.Add(new XElement("EMAIL_CC"));
        EMAIL.Add(new XElement("EMAIL_BCC"));


        DISTRIBUCION.Add(EMAIL);
        #endregion EMAIL


        ROOT.Add(DISTRIBUCION);

        #endregion DISTRIBUCION

        #region CUESTIONARIO
        XElement CUESTIONARIO = new XElement("CUESTIONARIO");

        XElement TIPO_FORMULARIO = new XElement("TIPO_FORMULARIO", "1");

        CUESTIONARIO.Add(TIPO_FORMULARIO);

        #region CABECERA



        XElement CABECERA = new XElement("CABECERA");

        CABECERA.Add(new XElement("IMAGEN", "LOGO_MAPFRE_FONDO_BLANCO.jpg"));
        CABECERA.Add(new XElement("DOMICILIO", "SV_DOMICILIO_SOLICITUD.rtf"));
        CABECERA.Add(new XElement("NUMERO_FOLIO", ""));
        CABECERA.Add(new XElement("NUMERO_POLIZA", ""));
        CABECERA.Add(new XElement("LEYENDA_UNO_ENCABEZADO", "EV_LLENADO_SOLICITUD.rtf"));

        CUESTIONARIO.Add(CABECERA);

        #endregion CABECERA

        #region CONSULTA
        string chk1 = "FALSE";
        if (Request.Form["chkSiPregunta1"] == "Yes")
        {
            chk1 = "TRUE";
        }

        XElement CONSULTA = new XElement("CONSULTA");
        CONSULTA.Add(new XElement("TITULO", "Cuestionario para enfermedades respiratorias"));

        XElement PREGUNTAS = new XElement("PREGUNTAS");

        XElement PREGUNTA1 = new XElement("PREGUNTA");
        PREGUNTA1.Add(new XElement("NUM_PREGUNTA", "1"));
        PREGUNTA1.Add(new XElement("INCISO"));
        PREGUNTA1.Add(new XElement("RESPUESTA_CERRADA", chk1));
        PREGUNTA1.Add(new XElement("RESPUESTA_1"));
        PREGUNTA1.Add(new XElement("RESPUESTA_2"));
        PREGUNTA1.Add(new XElement("RESPUESTA_3"));
        PREGUNTA1.Add(new XElement("RESPUESTA_4"));
        PREGUNTA1.Add(new XElement("RESPUESTA_5"));
        PREGUNTA1.Add(new XElement("RESPUESTA_6"));
        PREGUNTA1.Add(new XElement("RESPUESTA_7"));
        PREGUNTA1.Add(new XElement("RESPUESTA_8"));


        PREGUNTAS.Add(PREGUNTA1);

        string chk2 = "FALSE";
        if (Request.Form["chkSiPregunta2"] == "Yes")
        {
            chk2 = "TRUE";
        }

        XElement PREGUNTA2 = new XElement("PREGUNTA");
        PREGUNTA2.Add(new XElement("NUM_PREGUNTA", "2"));
        PREGUNTA2.Add(new XElement("INCISO"));
        PREGUNTA2.Add(new XElement("RESPUESTA_CERRADA", chk2));
        PREGUNTA2.Add(new XElement("RESPUESTA_1"));
        PREGUNTA2.Add(new XElement("RESPUESTA_2"));
        PREGUNTA2.Add(new XElement("RESPUESTA_3"));
        PREGUNTA2.Add(new XElement("RESPUESTA_4"));
        PREGUNTA2.Add(new XElement("RESPUESTA_5"));
        PREGUNTA2.Add(new XElement("RESPUESTA_6"));
        PREGUNTA2.Add(new XElement("RESPUESTA_7"));
        PREGUNTA2.Add(new XElement("RESPUESTA_8"));

        PREGUNTAS.Add(PREGUNTA2);

        string chk3 = "FALSE";
        if (Request.Form["chkSiPregunta3"] == "Yes")
        {
            chk3 = "TRUE";
        }

        XElement PREGUNTA3 = new XElement("PREGUNTA");
        PREGUNTA3.Add(new XElement("NUM_PREGUNTA", "3"));
        PREGUNTA3.Add(new XElement("INCISO"));
        PREGUNTA3.Add(new XElement("RESPUESTA_CERRADA", chk3));
        PREGUNTA3.Add(new XElement("RESPUESTA_1"));
        PREGUNTA3.Add(new XElement("RESPUESTA_2"));
        PREGUNTA3.Add(new XElement("RESPUESTA_3"));
        PREGUNTA3.Add(new XElement("RESPUESTA_4"));
        PREGUNTA3.Add(new XElement("RESPUESTA_5"));
        PREGUNTA3.Add(new XElement("RESPUESTA_6"));
        PREGUNTA3.Add(new XElement("RESPUESTA_7"));
        PREGUNTA3.Add(new XElement("RESPUESTA_8"));

        PREGUNTAS.Add(PREGUNTA3);


        string chk4 = "FALSE";
        if (Request.Form["chkSiPregunta4"] == "Yes")
        {
            chk4 = "TRUE";
        }


        XElement PREGUNTA4 = new XElement("PREGUNTA");
        PREGUNTA4.Add(new XElement("NUM_PREGUNTA", "4"));
        PREGUNTA4.Add(new XElement("INCISO"));
        PREGUNTA4.Add(new XElement("RESPUESTA_CERRADA", chk4));
        PREGUNTA4.Add(new XElement("RESPUESTA_1"));
        PREGUNTA4.Add(new XElement("RESPUESTA_2"));
        PREGUNTA4.Add(new XElement("RESPUESTA_3"));
        PREGUNTA4.Add(new XElement("RESPUESTA_4"));
        PREGUNTA4.Add(new XElement("RESPUESTA_5"));
        PREGUNTA4.Add(new XElement("RESPUESTA_6"));
        PREGUNTA4.Add(new XElement("RESPUESTA_7"));
        PREGUNTA4.Add(new XElement("RESPUESTA_8"));

        PREGUNTAS.Add(PREGUNTA4);

        string chk5 = "FALSE";
        if (Request.Form["chkSiPregunta5"] == "Yes")
        {
            chk5 = "TRUE";
        }

        XElement PREGUNTA5 = new XElement("PREGUNTA");
        PREGUNTA5.Add(new XElement("NUM_PREGUNTA", "5"));
        PREGUNTA5.Add(new XElement("INCISO"));
        PREGUNTA5.Add(new XElement("RESPUESTA_CERRADA", chk5));
        PREGUNTA5.Add(new XElement("RESPUESTA_1"));
        PREGUNTA5.Add(new XElement("RESPUESTA_2"));
        PREGUNTA5.Add(new XElement("RESPUESTA_3"));
        PREGUNTA5.Add(new XElement("RESPUESTA_4"));
        PREGUNTA5.Add(new XElement("RESPUESTA_5"));
        PREGUNTA5.Add(new XElement("RESPUESTA_6"));
        PREGUNTA5.Add(new XElement("RESPUESTA_7"));
        PREGUNTA5.Add(new XElement("RESPUESTA_8"));

        PREGUNTAS.Add(PREGUNTA5);


        string chk6 = "FALSE";
        if (Request.Form["chkSiPregunta6"] == "Yes")
        {
            chk6 = "TRUE";
        }

        XElement PREGUNTA6 = new XElement("PREGUNTA");
        PREGUNTA6.Add(new XElement("NUM_PREGUNTA", "6"));
        PREGUNTA6.Add(new XElement("INCISO"));
        PREGUNTA6.Add(new XElement("RESPUESTA_CERRADA", chk6));
        PREGUNTA6.Add(new XElement("RESPUESTA_1"));
        PREGUNTA6.Add(new XElement("RESPUESTA_2"));
        PREGUNTA6.Add(new XElement("RESPUESTA_3"));
        PREGUNTA6.Add(new XElement("RESPUESTA_4"));
        PREGUNTA6.Add(new XElement("RESPUESTA_5"));
        PREGUNTA6.Add(new XElement("RESPUESTA_6"));
        PREGUNTA6.Add(new XElement("RESPUESTA_7"));
        PREGUNTA6.Add(new XElement("RESPUESTA_8"));

        PREGUNTAS.Add(PREGUNTA6);



        CONSULTA.Add(PREGUNTAS);

        CUESTIONARIO.Add(CONSULTA);

        #endregion CONSULTA

        CUESTIONARIO.Add(new XElement("LUGAR_Y_FECHA", txtLugaryFecha));

        #region FIRMAS
        XElement FIRMAS = new XElement("FIRMAS");

        XElement FIRMA = new XElement("FIRMA_CONTRATANTE");
        //FIRMA.Add(new XElement("TIPO_TERCERO", "CONTRATANTE"));
        FIRMA.Add(new XElement("NOMBRE", txtContratante));
        FIRMA.Add(new XElement("IMAGEN_FIRMA", ""));

        FIRMAS.Add(FIRMA);

        XElement FIRMA1 = new XElement("FIRMA_SOLICITANTE");
        //FIRMA1.Add(new XElement("TIPO_TERCERO", "SOLICITANTE"));
        FIRMA1.Add(new XElement("NOMBRE", txtSolicitante));
        FIRMA1.Add(new XElement("IMAGEN_FIRMA", ""));

        FIRMAS.Add(FIRMA1);

        CUESTIONARIO.Add(FIRMAS);
        #endregion FIRMAS

        #region
        XElement INFORMACION_ADICIONAL = new XElement("INFORMACION_ADICIONAL");
        INFORMACION_ADICIONAL.Add(new XElement("CONTENIDO", "EV_REGISTRO_CNSF_SOLICITUD.rtf"));
        INFORMACION_ADICIONAL.Add(new XElement("VI_FECHA_CNSF", "08 DE NOVIEMBRE 2017"));
        INFORMACION_ADICIONAL.Add(new XElement("VI_REGISTRO_CNSF", "CNSF-S0041-0554-2017"));

        CUESTIONARIO.Add(INFORMACION_ADICIONAL);
        #endregion

        ROOT.Add(CUESTIONARIO);
        #endregion CUESTIONARIO


        string xmlSolicitud = ROOT.ToString().Replace(".JPG", ".jpg")
          .Replace("true", "TRUE")
          .Replace("false", "FALSE")
          .Replace("&AMP;", "&#38;")
          .Replace(".RTF", ".rtf");
        XmlHpExtreme xmlHpExtreme = new XmlHpExtreme();

        string nombre = xmlHpExtreme.XmlHpExtremeCuestionario(xmlSolicitud, Request.Form["numCotizacion"]);


        //AbrirPdf(nombre);


        #region Comment
        //pdfFormFields.SetField("chkSiPregunta4", chkSiPregunta4);
        //pdfFormFields.SetField("chkSiPregunta6", chkSiPregunta6);
        //pdfFormFields.SetField("chkNoPregunta3", chkNoPregunta3);
        //pdfFormFields.SetField("chkSiPregunta1", chkSiPregunta1);
        //pdfFormFields.SetField("txtpregunta4", txtpregunta4);
        //pdfFormFields.SetField("txtpregunta5", txtpregunta5);
        //pdfFormFields.SetField("chkNoPregunta3d", chkNoPregunta3d);
        //pdfFormFields.SetField("chkSiPregunta3d", chkSiPregunta3d);
        //pdfFormFields.SetField("chkNoPregunta3c", chkNoPregunta3c);
        //pdfFormFields.SetField("txtPoliza1", txtPoliza1);
        //pdfFormFields.SetField("txtPoliza2", txtPoliza2);
        //pdfFormFields.SetField("txtSolicitante", txtSolicitante);
        //pdfFormFields.SetField("txtPoliza3", txtPoliza3);
        //pdfFormFields.SetField("txtPregunta1", txtPregunta1);
        //pdfFormFields.SetField("chkSiPregunta2", chkSiPregunta2);
        //pdfFormFields.SetField("txtPoliza11", txtPoliza11);
        //pdfFormFields.SetField("txtPoliza10", txtPoliza10);
        //pdfFormFields.SetField("txtPoliza13", txtPoliza13);
        //pdfFormFields.SetField("txtPoliza12", txtPoliza12);
        //pdfFormFields.SetField("chkNoPregunta6", chkNoPregunta6);
        //pdfFormFields.SetField("txtPoliza5", txtPoliza5);
        //pdfFormFields.SetField("txtPoliza6", txtPoliza6);
        //pdfFormFields.SetField("txtFolio8", txtFolio8);
        //pdfFormFields.SetField("txtFolio9", txtFolio9);
        //pdfFormFields.SetField("txtPoliza7", txtPoliza7);
        //pdfFormFields.SetField("chkNoPregunta3e", chkNoPregunta3e);
        //pdfFormFields.SetField("txtFolio4", txtFolio4);
        //pdfFormFields.SetField("txtFolio5", txtFolio5);
        //pdfFormFields.SetField("txtFolio6", txtFolio6);
        //pdfFormFields.SetField("txtFolio7", txtFolio7);
        //pdfFormFields.SetField("chkNoPregunta3b", chkNoPregunta3b);
        //pdfFormFields.SetField("txtFolio1", txtFolio1);
        //pdfFormFields.SetField("txtFolio2", txtFolio2);
        //pdfFormFields.SetField("txtFolio3", txtFolio3);
        //pdfFormFields.SetField("chkSiPregunta3c", chkSiPregunta3c);
        //pdfFormFields.SetField("chkSiPregunta3b", chkSiPregunta3b);
        //pdfFormFields.SetField("chkSiPregunta3e", chkSiPregunta3e);
        //pdfFormFields.SetField("txtPoliza4", txtPoliza4);
        //pdfFormFields.SetField("chkSiPregunta3g", chkSiPregunta3g);
        //pdfFormFields.SetField("chkSiPregunta3f", chkSiPregunta3f);
        //pdfFormFields.SetField("txtContratante", txtContratante);
        //pdfFormFields.SetField("chkNoPregunta1", chkNoPregunta1);
        //pdfFormFields.SetField("txtFolio13", txtFolio13);
        //pdfFormFields.SetField("txtLugaryFecha", txtLugaryFecha);
        //pdfFormFields.SetField("txtFolio12", txtFolio12);
        //pdfFormFields.SetField("chkNoPregunta3g", chkNoPregunta3g);
        //pdfFormFields.SetField("txtFolio11", txtFolio11);
        //pdfFormFields.SetField("chkNoPregunta2", chkNoPregunta2);
        //pdfFormFields.SetField("txtFolio10", txtFolio10);
        //pdfFormFields.SetField("chkNoPregunta3a", chkNoPregunta3a);
        //pdfFormFields.SetField("chkSiPregunta5", chkSiPregunta5);
        //pdfFormFields.SetField("chkNoPregunta3f", chkNoPregunta3f);
        //pdfFormFields.SetField("txtPoliza8", txtPoliza8);
        //pdfFormFields.SetField("chkNoPregunta4", chkNoPregunta4);
        //pdfFormFields.SetField("txtPoliza9", txtPoliza9);
        //pdfFormFields.SetField("chkSiPregunta3", chkSiPregunta3);
        //pdfFormFields.SetField("txtpregunta6", txtpregunta6);
        //pdfFormFields.SetField("chkNoPregunta5", chkNoPregunta5);
        //pdfFormFields.SetField("chkSiPregunta3a", chkSiPregunta3a);






        // report by reading values from completed PDF
        //string sTmp = "W-4 Completed for " + pdfFormFields.GetField("f1_09(0)") + " " +
        //  pdfFormFields.GetField("f1_10(0)");
        //MessageBox.Show(sTmp, "Finished");

        // flatten the form to remove editting options, set it to false
        // to leave the form open to subsequent manual edits
        //pdfStamper.FormFlattening = false;

        // close the pdf
        //pdfStamper.Close();
        //}
        //catch (Exception ex)
        //{
        //    MapfreMMX.util.MLogFile.getInstance().writeText("Error FillFormCuestionariMedico: " + ex.Message);
        //}
        #endregion
    }


    public void FillFormCuestionariMedicoNuevo(string numCotizacion)
    {
        //AcroFields pdfFormFields = pdfStamper.AcroFields;
        #region DeclaraVariables
        // The first worksheet and W-4 form
        String chkSiPregunta4 = "";
        String chkSiPregunta6 = "";
        String chkNoPregunta3 = "";
        String chkSiPregunta1 = "";
        String txtpregunta4 = "";
        String txtpregunta5 = "";
        String chkNoPregunta3d = "";
        String chkSiPregunta3d = "";
        String chkNoPregunta3c = "";
        String txtPoliza1 = "";
        String txtPoliza2 = "";
        String txtSolicitante = "";
        String txtPoliza3 = "";
        String txtPregunta1 = "";
        String chkSiPregunta2 = "";
        String txtPoliza11 = "";
        String txtPoliza10 = "";
        String txtPoliza13 = "";
        String txtPoliza12 = "";
        String chkNoPregunta6 = "";
        String txtPoliza5 = "";
        String txtPoliza6 = "";
        String txtFolio8 = "";
        String txtFolio9 = "";
        String txtPoliza7 = "";
        String chkNoPregunta3e = "";
        String txtFolio4 = "";
        String txtFolio5 = "";
        String txtFolio6 = "";
        String txtFolio7 = "";
        String chkNoPregunta3b = "";
        String txtFolio1 = "";
        String txtFolio2 = "";
        String txtFolio3 = "";
        String chkSiPregunta3c = "";
        String chkSiPregunta3b = "";
        String chkSiPregunta3e = "";
        String txtPoliza4 = "";
        String chkSiPregunta3g = "";
        String chkSiPregunta3f = "";
        String txtContratante = "";
        String chkNoPregunta1 = "";
        String txtFolio13 = "";
        String txtLugaryFecha = "";
        String txtFolio12 = "";
        String chkNoPregunta3g = "";
        String txtFolio11 = "";
        String chkNoPregunta2 = "";
        String txtFolio10 = "";
        String chkNoPregunta3a = "";
        String chkSiPregunta5 = "";
        String chkNoPregunta3f = "";
        String txtPoliza8 = "";
        String chkNoPregunta4 = "";
        String txtPoliza9 = "";
        String chkSiPregunta3 = "";
        String txtpregunta6 = "";
        String chkNoPregunta5 = "";
        String chkSiPregunta3a = "";
        #endregion
        #region setVariables
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta4"])) { chkSiPregunta4 = Request.Form["chkSiPregunta4"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta6"])) { chkSiPregunta6 = Request.Form["chkSiPregunta6"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta3"])) { chkNoPregunta3 = Request.Form["chkNoPregunta3"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta1"])) { chkSiPregunta1 = Request.Form["chkSiPregunta1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtpregunta4"])) { txtpregunta4 = Request.Form["txtpregunta4"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtpregunta5"])) { txtpregunta5 = Request.Form["txtpregunta5"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta3d"])) { chkNoPregunta3d = Request.Form["chkNoPregunta3d"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta3d"])) { chkSiPregunta3d = Request.Form["chkSiPregunta3d"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta3c"])) { chkNoPregunta3c = Request.Form["chkNoPregunta3c"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza1"])) { txtPoliza1 = Request.Form["txtPoliza1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza2"])) { txtPoliza2 = Request.Form["txtPoliza2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSolicitante"])) { txtSolicitante = Request.Form["txtSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza3"])) { txtPoliza3 = Request.Form["txtPoliza3"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPregunta1"])) { txtPregunta1 = Request.Form["txtPregunta1"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta2"])) { chkSiPregunta2 = Request.Form["chkSiPregunta2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza11"])) { txtPoliza11 = Request.Form["txtPoliza11"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza10"])) { txtPoliza10 = Request.Form["txtPoliza10"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza13"])) { txtPoliza13 = Request.Form["txtPoliza13"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza12"])) { txtPoliza12 = Request.Form["txtPoliza12"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta6"])) { chkNoPregunta6 = Request.Form["chkNoPregunta6"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza5"])) { txtPoliza5 = Request.Form["txtPoliza5"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza6"])) { txtPoliza6 = Request.Form["txtPoliza6"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio8"])) { txtFolio8 = Request.Form["txtFolio8"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio9"])) { txtFolio9 = Request.Form["txtFolio9"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza7"])) { txtPoliza7 = Request.Form["txtPoliza7"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta3e"])) { chkNoPregunta3e = Request.Form["chkNoPregunta3e"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio4"])) { txtFolio4 = Request.Form["txtFolio4"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio5"])) { txtFolio5 = Request.Form["txtFolio5"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio6"])) { txtFolio6 = Request.Form["txtFolio6"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio7"])) { txtFolio7 = Request.Form["txtFolio7"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta3b"])) { chkNoPregunta3b = Request.Form["chkNoPregunta3b"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio1"])) { txtFolio1 = Request.Form["txtFolio1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio2"])) { txtFolio2 = Request.Form["txtFolio2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio3"])) { txtFolio3 = Request.Form["txtFolio3"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta3c"])) { chkSiPregunta3c = Request.Form["chkSiPregunta3c"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta3b"])) { chkSiPregunta3b = Request.Form["chkSiPregunta3b"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta3e"])) { chkSiPregunta3e = Request.Form["chkSiPregunta3e"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza4"])) { txtPoliza4 = Request.Form["txtPoliza4"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta3g"])) { chkSiPregunta3g = Request.Form["chkSiPregunta3g"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta3f"])) { chkSiPregunta3f = Request.Form["chkSiPregunta3f"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtContratante"])) { txtContratante = Request.Form["txtContratante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta1"])) { chkNoPregunta1 = Request.Form["chkNoPregunta1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio13"])) { txtFolio13 = Request.Form["txtFolio13"]; }
        //if (!string.IsNullOrEmpty(Request.Form["txtLugaryFecha"])) { txtLugaryFecha = Request.Form["txtLugaryFecha"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio12"])) { txtFolio12 = Request.Form["txtFolio12"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta3g"])) { chkNoPregunta3g = Request.Form["chkNoPregunta3g"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio11"])) { txtFolio11 = Request.Form["txtFolio11"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta2"])) { chkNoPregunta2 = Request.Form["chkNoPregunta2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolio10"])) { txtFolio10 = Request.Form["txtFolio10"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta3a"])) { chkNoPregunta3a = Request.Form["chkNoPregunta3a"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta5"])) { chkSiPregunta5 = Request.Form["chkSiPregunta5"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta3f"])) { chkNoPregunta3f = Request.Form["chkNoPregunta3f"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza8"])) { txtPoliza8 = Request.Form["txtPoliza8"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta4"])) { chkNoPregunta4 = Request.Form["chkNoPregunta4"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPoliza9"])) { txtPoliza9 = Request.Form["txtPoliza9"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta3"])) { chkSiPregunta3 = Request.Form["chkSiPregunta3"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtpregunta6"])) { txtpregunta6 = Request.Form["txtpregunta6"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNoPregunta5"])) { chkNoPregunta5 = Request.Form["chkNoPregunta5"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSiPregunta3a"])) { chkSiPregunta3a = Request.Form["chkSiPregunta3a"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtEstadoProvinciaSolicitante"]) && !string.IsNullOrEmpty(Request.Form["txtMunicipioDelegacionSolicitante"])) { txtLugaryFecha = Request.Form["txtMunicipioDelegacionSolicitante"] + ", " + Request.Form["txtEstadoProvinciaSolicitante"] + " " + DateTime.Today.ToString("dd MM yyy"); }
        #endregion
        XElement ROOT = new XElement("ROOT");
        ROOT.Add(new XElement("COMPANIA", "1"));
        ROOT.Add(new XElement("RAMO", "100"));
        ROOT.Add(new XElement("ACTIVIDAD", "EMISION"));
        ROOT.Add(new XElement("IDIOMA", "mx_ES"));

        #region DISTRIBUCION
        XElement DISTRIBUCION = new XElement("DISTRIBUCION");

        DISTRIBUCION.Add(new XElement("DUPLEX_MODE", "FALSE"));
        DISTRIBUCION.Add(new XElement("LOCAL", "TRUE"));

        #region GESTOR_DOCUMENTAL
        XElement GESTOR_DOC = new XElement("GESTOR_DOCUMENTAL");

        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_SFILENAME", ""));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_FOLDER", ""));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_OBJETO", ""));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_CODCIA", ""));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_NUMPOLIZA", ""));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_NUMSUPLEMENTO"));
        //GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_NUMFOLIO", ""));

        DISTRIBUCION.Add(GESTOR_DOC);

        #endregion GESTOR_DOCUMENTAL

        #region EMAIL
        XElement EMAIL = new XElement("EMAIL");

        EMAIL.Add(new XElement("EMAIL_TO", ""));
        EMAIL.Add(new XElement("EMAIL_FROM", "servicioDocumental@mapfre.com.mx"));
        EMAIL.Add(new XElement("EMAIL_REPLY_TO"));
        EMAIL.Add(new XElement("EMAIL_ASUNTO", "Prueba"));
        EMAIL.Add(new XElement("EMAIL_CC"));
        EMAIL.Add(new XElement("EMAIL_BCC"));


        DISTRIBUCION.Add(EMAIL);
        #endregion EMAIL


        ROOT.Add(DISTRIBUCION);

        #endregion DISTRIBUCION

        #region CUESTIONARIO
        XElement CUESTIONARIO = new XElement("CUESTIONARIO");

        XElement TIPO_FORMULARIO = new XElement("TIPO_FORMULARIO", "2");

        CUESTIONARIO.Add(TIPO_FORMULARIO);

        #region CABECERA



        XElement CABECERA = new XElement("CABECERA");

        CABECERA.Add(new XElement("IMAGEN", "LOGO_MAPFRE_FONDO_BLANCO.jpg"));
        CABECERA.Add(new XElement("DOMICILIO", "SV_DOMICILIO_SOLICITUD.rtf"));
        CABECERA.Add(new XElement("NUMERO_FOLIO", ""));
        CABECERA.Add(new XElement("NUMERO_POLIZA", ""));
        CABECERA.Add(new XElement("LEYENDA_UNO_ENCABEZADO", "EV_LLENADO_SOLICITUD.rtf"));

        CUESTIONARIO.Add(CABECERA);

        #endregion CABECERA

        #region CONSULTA
        string chk1 = "FALSE";
        if (Request.Form["chkSiPregunta1"] == "Yes")
        {
            chk1 = "TRUE";
        }

        XElement CONSULTA = new XElement("CONSULTA");
        CONSULTA.Add(new XElement("TITULO", "Cuestionario para enfermedades respiratorias"));

        XElement PREGUNTAS = new XElement("PREGUNTAS");

        XElement PREGUNTA1 = new XElement("PREGUNTA");
        PREGUNTA1.Add(new XElement("NUM_PREGUNTA", "1"));
        PREGUNTA1.Add(new XElement("INCISO"));
        PREGUNTA1.Add(new XElement("RESPUESTA_CERRADA", chk1));
        PREGUNTA1.Add(new XElement("RESPUESTA_1", Request.Form["txtPregunta1a"]));
        PREGUNTA1.Add(new XElement("RESPUESTA_2"));
        PREGUNTA1.Add(new XElement("RESPUESTA_3"));
        PREGUNTA1.Add(new XElement("RESPUESTA_4"));
        PREGUNTA1.Add(new XElement("RESPUESTA_5"));
        PREGUNTA1.Add(new XElement("RESPUESTA_6"));
        PREGUNTA1.Add(new XElement("RESPUESTA_7"));
        PREGUNTA1.Add(new XElement("RESPUESTA_8"));


        PREGUNTAS.Add(PREGUNTA1);

        string chk2 = "FALSE";
        if (Request.Form["chkSiPregunta2"] == "Yes")
        {
            chk2 = "TRUE";
        }

        XElement PREGUNTA2 = new XElement("PREGUNTA");
        PREGUNTA2.Add(new XElement("NUM_PREGUNTA", "2"));
        PREGUNTA2.Add(new XElement("INCISO"));
        PREGUNTA2.Add(new XElement("RESPUESTA_CERRADA", chk2));
        PREGUNTA2.Add(new XElement("RESPUESTA_1", Request.Form["txtPregunta2a"]));
        PREGUNTA2.Add(new XElement("RESPUESTA_2"));
        PREGUNTA2.Add(new XElement("RESPUESTA_3"));
        PREGUNTA2.Add(new XElement("RESPUESTA_4"));
        PREGUNTA2.Add(new XElement("RESPUESTA_5"));
        PREGUNTA2.Add(new XElement("RESPUESTA_6"));
        PREGUNTA2.Add(new XElement("RESPUESTA_7"));
        PREGUNTA2.Add(new XElement("RESPUESTA_8"));

        PREGUNTAS.Add(PREGUNTA2);

        string chk3 = "FALSE";
        if (Request.Form["chkSiPregunta3"] == "Yes")
        {
            chk3 = "TRUE";
        }

        XElement PREGUNTA3 = new XElement("PREGUNTA");
        PREGUNTA3.Add(new XElement("NUM_PREGUNTA", "3"));
        PREGUNTA3.Add(new XElement("INCISO"));
        PREGUNTA3.Add(new XElement("RESPUESTA_CERRADA", chk3));
        PREGUNTA3.Add(new XElement("RESPUESTA_1"));
        PREGUNTA3.Add(new XElement("RESPUESTA_2"));
        PREGUNTA3.Add(new XElement("RESPUESTA_3"));
        PREGUNTA3.Add(new XElement("RESPUESTA_4"));
        PREGUNTA3.Add(new XElement("RESPUESTA_5"));
        PREGUNTA3.Add(new XElement("RESPUESTA_6"));
        PREGUNTA3.Add(new XElement("RESPUESTA_7"));
        PREGUNTA3.Add(new XElement("RESPUESTA_8"));

        PREGUNTAS.Add(PREGUNTA3);


        string chk4 = "FALSE";
        if (Request.Form["chkSiPregunta4"] == "Yes")
        {
            chk4 = "TRUE";
        }


        XElement PREGUNTA4 = new XElement("PREGUNTA");
        PREGUNTA4.Add(new XElement("NUM_PREGUNTA", "4"));
        PREGUNTA4.Add(new XElement("INCISO"));
        PREGUNTA4.Add(new XElement("RESPUESTA_CERRADA", chk4));
        PREGUNTA4.Add(new XElement("RESPUESTA_1"));
        PREGUNTA4.Add(new XElement("RESPUESTA_2"));
        PREGUNTA4.Add(new XElement("RESPUESTA_3"));
        PREGUNTA4.Add(new XElement("RESPUESTA_4"));
        PREGUNTA4.Add(new XElement("RESPUESTA_5"));
        PREGUNTA4.Add(new XElement("RESPUESTA_6"));
        PREGUNTA4.Add(new XElement("RESPUESTA_7"));
        PREGUNTA4.Add(new XElement("RESPUESTA_8"));

        PREGUNTAS.Add(PREGUNTA4);

        string chk5 = "FALSE";
        if (Request.Form["chkSiPregunta5"] == "Yes")
        {
            chk5 = "TRUE";
        }

        XElement PREGUNTA5 = new XElement("PREGUNTA");
        PREGUNTA5.Add(new XElement("NUM_PREGUNTA", "5"));
        PREGUNTA5.Add(new XElement("INCISO"));
        PREGUNTA5.Add(new XElement("RESPUESTA_CERRADA", chk5));
        PREGUNTA5.Add(new XElement("RESPUESTA_1", Request.Form["txtPregunta5a"]));
        PREGUNTA5.Add(new XElement("RESPUESTA_2", Request.Form["txtPregunta5b"]));
        PREGUNTA5.Add(new XElement("RESPUESTA_3", Request.Form["txtPregunta5c"]));
        PREGUNTA5.Add(new XElement("RESPUESTA_4"));
        PREGUNTA5.Add(new XElement("RESPUESTA_5"));
        PREGUNTA5.Add(new XElement("RESPUESTA_6"));
        PREGUNTA5.Add(new XElement("RESPUESTA_7"));
        PREGUNTA5.Add(new XElement("RESPUESTA_8"));

        PREGUNTAS.Add(PREGUNTA5);

        string chk5_1 = "FALSE";
        if (Request.Form["chkSiPregunta5_1"] == "Yes")
        {
            chk5_1 = "TRUE";
        }


        XElement PREGUNTA5_1 = new XElement("PREGUNTA");
        PREGUNTA5_1.Add(new XElement("NUM_PREGUNTA", "5.1"));
        PREGUNTA5_1.Add(new XElement("INCISO"));
        PREGUNTA5_1.Add(new XElement("RESPUESTA_CERRADA", chk5_1));
        PREGUNTA5_1.Add(new XElement("RESPUESTA_1"));
        PREGUNTA5_1.Add(new XElement("RESPUESTA_2"));
        PREGUNTA5_1.Add(new XElement("RESPUESTA_3"));
        PREGUNTA5_1.Add(new XElement("RESPUESTA_4"));
        PREGUNTA5_1.Add(new XElement("RESPUESTA_5"));
        PREGUNTA5_1.Add(new XElement("RESPUESTA_6"));
        PREGUNTA5_1.Add(new XElement("RESPUESTA_7"));
        PREGUNTA5_1.Add(new XElement("RESPUESTA_8"));

        PREGUNTAS.Add(PREGUNTA5_1);

        string chk6 = "FALSE";
        if (Request.Form["chkSiPregunta6"] == "Yes")
        {
            chk6 = "TRUE";
        }

        XElement PREGUNTA6 = new XElement("PREGUNTA");
        PREGUNTA6.Add(new XElement("NUM_PREGUNTA", "6"));
        PREGUNTA6.Add(new XElement("INCISO"));
        PREGUNTA6.Add(new XElement("RESPUESTA_CERRADA", chk6));
        PREGUNTA6.Add(new XElement("RESPUESTA_1", Request.Form["txtPregunta6a"]));
        PREGUNTA6.Add(new XElement("RESPUESTA_2", Request.Form["txtPregunta6b"]));
        PREGUNTA6.Add(new XElement("RESPUESTA_3", Request.Form["txtPregunta6c"]));
        PREGUNTA6.Add(new XElement("RESPUESTA_4"));
        PREGUNTA6.Add(new XElement("RESPUESTA_5"));
        PREGUNTA6.Add(new XElement("RESPUESTA_6"));
        PREGUNTA6.Add(new XElement("RESPUESTA_7"));
        PREGUNTA6.Add(new XElement("RESPUESTA_8"));

        PREGUNTAS.Add(PREGUNTA6);

        string chk7 = "FALSE";
        if (Request.Form["chkSiPregunta7"] == "Yes")
        {
            chk7 = "TRUE";
        }

        XElement PREGUNTA7 = new XElement("PREGUNTA");
        PREGUNTA7.Add(new XElement("NUM_PREGUNTA", "7"));
        PREGUNTA7.Add(new XElement("INCISO"));
        PREGUNTA7.Add(new XElement("RESPUESTA_CERRADA", chk7));
        PREGUNTA7.Add(new XElement("RESPUESTA_1"));
        PREGUNTA7.Add(new XElement("RESPUESTA_2"));
        PREGUNTA7.Add(new XElement("RESPUESTA_3"));
        PREGUNTA7.Add(new XElement("RESPUESTA_4"));
        PREGUNTA7.Add(new XElement("RESPUESTA_5"));
        PREGUNTA7.Add(new XElement("RESPUESTA_6"));
        PREGUNTA7.Add(new XElement("RESPUESTA_7"));
        PREGUNTA7.Add(new XElement("RESPUESTA_8"));

        PREGUNTAS.Add(PREGUNTA7);

        string chk8 = "FALSE";
        if (Request.Form["chkSiPregunta8"] == "Yes")
        {
            chk8 = "TRUE";
        }

        XElement PREGUNTA8 = new XElement("PREGUNTA");
        PREGUNTA8.Add(new XElement("NUM_PREGUNTA", "8"));
        PREGUNTA8.Add(new XElement("INCISO"));
        PREGUNTA8.Add(new XElement("RESPUESTA_CERRADA", chk8));
        PREGUNTA8.Add(new XElement("RESPUESTA_1"));
        PREGUNTA8.Add(new XElement("RESPUESTA_2"));
        PREGUNTA8.Add(new XElement("RESPUESTA_3"));
        PREGUNTA8.Add(new XElement("RESPUESTA_4"));
        PREGUNTA8.Add(new XElement("RESPUESTA_5"));
        PREGUNTA8.Add(new XElement("RESPUESTA_6"));
        PREGUNTA8.Add(new XElement("RESPUESTA_7"));
        PREGUNTA8.Add(new XElement("RESPUESTA_8"));

        PREGUNTAS.Add(PREGUNTA8);

        string chk9 = "FALSE";
        if (Request.Form["chkSiPregunta6"] == "Yes")
        {
            chk9 = "TRUE";
        }

        XElement PREGUNTA9 = new XElement("PREGUNTA");
        PREGUNTA9.Add(new XElement("NUM_PREGUNTA", "9"));
        PREGUNTA9.Add(new XElement("INCISO"));
        PREGUNTA9.Add(new XElement("RESPUESTA_CERRADA", chk9));
        PREGUNTA9.Add(new XElement("RESPUESTA_1"));
        PREGUNTA9.Add(new XElement("RESPUESTA_2"));
        PREGUNTA9.Add(new XElement("RESPUESTA_3"));
        PREGUNTA9.Add(new XElement("RESPUESTA_4"));
        PREGUNTA9.Add(new XElement("RESPUESTA_5"));
        PREGUNTA9.Add(new XElement("RESPUESTA_6"));
        PREGUNTA9.Add(new XElement("RESPUESTA_7"));
        PREGUNTA9.Add(new XElement("RESPUESTA_8"));

        PREGUNTAS.Add(PREGUNTA9);

        string chk10 = "FALSE";
        if (Request.Form["chkSiPregunta10"] == "Yes")
        {
            chk10 = "TRUE";
        }

        XElement PREGUNTA10 = new XElement("PREGUNTA");
        PREGUNTA10.Add(new XElement("NUM_PREGUNTA", "10"));
        PREGUNTA10.Add(new XElement("INCISO"));
        PREGUNTA10.Add(new XElement("RESPUESTA_CERRADA", chk10));
        PREGUNTA10.Add(new XElement("RESPUESTA_1"));
        PREGUNTA10.Add(new XElement("RESPUESTA_2"));
        PREGUNTA10.Add(new XElement("RESPUESTA_3"));
        PREGUNTA10.Add(new XElement("RESPUESTA_4"));
        PREGUNTA10.Add(new XElement("RESPUESTA_5"));
        PREGUNTA10.Add(new XElement("RESPUESTA_6"));
        PREGUNTA10.Add(new XElement("RESPUESTA_7"));
        PREGUNTA10.Add(new XElement("RESPUESTA_8"));

        PREGUNTAS.Add(PREGUNTA10);

        string chk11 = "TRUE";
        if (Request.Form["chkSiPregunta11"] == "Yes")
        {
            chk11 = "FALSE";
        }

        XElement PREGUNTA11 = new XElement("PREGUNTA");
        PREGUNTA11.Add(new XElement("NUM_PREGUNTA", "11"));
        PREGUNTA11.Add(new XElement("INCISO"));
        PREGUNTA11.Add(new XElement("RESPUESTA_CERRADA", chk11));
        PREGUNTA11.Add(new XElement("RESPUESTA_1", Request.Form["txtPregunta11a"]));
        PREGUNTA11.Add(new XElement("RESPUESTA_2", Request.Form["txtPregunta11b"]));
        PREGUNTA11.Add(new XElement("RESPUESTA_3", Request.Form["txtPregunta11c"]));
        PREGUNTA11.Add(new XElement("RESPUESTA_4"));
        PREGUNTA11.Add(new XElement("RESPUESTA_5"));
        PREGUNTA11.Add(new XElement("RESPUESTA_6"));
        PREGUNTA11.Add(new XElement("RESPUESTA_7"));
        PREGUNTA11.Add(new XElement("RESPUESTA_8"));

        PREGUNTAS.Add(PREGUNTA11);

        string chk12 = "FALSE";
        if (Request.Form["chkSiPregunta12"] == "Yes")
        {
            chk12 = "TRUE";
        }

        XElement PREGUNTA12 = new XElement("PREGUNTA");
        PREGUNTA12.Add(new XElement("NUM_PREGUNTA", "12"));
        PREGUNTA12.Add(new XElement("INCISO"));
        PREGUNTA12.Add(new XElement("RESPUESTA_CERRADA", chk12));
        PREGUNTA12.Add(new XElement("RESPUESTA_1"));
        PREGUNTA12.Add(new XElement("RESPUESTA_2"));
        PREGUNTA12.Add(new XElement("RESPUESTA_3"));
        PREGUNTA12.Add(new XElement("RESPUESTA_4"));
        PREGUNTA12.Add(new XElement("RESPUESTA_5"));
        PREGUNTA12.Add(new XElement("RESPUESTA_6"));
        PREGUNTA12.Add(new XElement("RESPUESTA_7"));
        PREGUNTA12.Add(new XElement("RESPUESTA_8"));

        PREGUNTAS.Add(PREGUNTA12);

        CONSULTA.Add(PREGUNTAS);

        CUESTIONARIO.Add(CONSULTA);

        #endregion CONSULTA

        CUESTIONARIO.Add(new XElement("LUGAR_Y_FECHA", txtLugaryFecha));

        #region FIRMAS
        XElement FIRMAS = new XElement("FIRMAS");

        XElement FIRMA = new XElement("FIRMA_CONTRATANTE");
        //FIRMA.Add(new XElement("TIPO_TERCERO", "CONTRATANTE"));
        FIRMA.Add(new XElement("NOMBRE", txtContratante));
        FIRMA.Add(new XElement("IMAGEN_FIRMA", ""));

        FIRMAS.Add(FIRMA);

        XElement FIRMA1 = new XElement("FIRMA_SOLICITANTE");
        //FIRMA1.Add(new XElement("TIPO_TERCERO", "SOLICITANTE"));
        FIRMA1.Add(new XElement("NOMBRE", txtSolicitante));
        FIRMA1.Add(new XElement("IMAGEN_FIRMA", ""));

        FIRMAS.Add(FIRMA1);

        CUESTIONARIO.Add(FIRMAS);
        #endregion FIRMAS

        #region
        XElement INFORMACION_ADICIONAL = new XElement("INFORMACION_ADICIONAL");
        INFORMACION_ADICIONAL.Add(new XElement("CONTENIDO", "EV_REGISTRO_CNSF_SOLICITUD.rtf"));
        INFORMACION_ADICIONAL.Add(new XElement("VI_FECHA_CNSF", "08 DE NOVIEMBRE 2017"));
        INFORMACION_ADICIONAL.Add(new XElement("VI_REGISTRO_CNSF", "CNSF-S0041-0554-2017"));

        CUESTIONARIO.Add(INFORMACION_ADICIONAL);
        #endregion

        ROOT.Add(CUESTIONARIO);
        #endregion CUESTIONARIO


        string xmlSolicitud = ROOT.ToString().Replace(".JPG", ".jpg")
          .Replace("true", "TRUE")
          .Replace("false", "FALSE")
          .Replace("&AMP;", "&#38;")
          .Replace(".RTF", ".rtf");
        XmlHpExtreme xmlHpExtreme = new XmlHpExtreme();

        string nombre = xmlHpExtreme.XmlHpExtremeCuestionario(xmlSolicitud, Request.Form["numCotizacion"]);


        //AbrirPdf(nombre);


        #region Comment
        //pdfFormFields.SetField("chkSiPregunta4", chkSiPregunta4);
        //pdfFormFields.SetField("chkSiPregunta6", chkSiPregunta6);
        //pdfFormFields.SetField("chkNoPregunta3", chkNoPregunta3);
        //pdfFormFields.SetField("chkSiPregunta1", chkSiPregunta1);
        //pdfFormFields.SetField("txtpregunta4", txtpregunta4);
        //pdfFormFields.SetField("txtpregunta5", txtpregunta5);
        //pdfFormFields.SetField("chkNoPregunta3d", chkNoPregunta3d);
        //pdfFormFields.SetField("chkSiPregunta3d", chkSiPregunta3d);
        //pdfFormFields.SetField("chkNoPregunta3c", chkNoPregunta3c);
        //pdfFormFields.SetField("txtPoliza1", txtPoliza1);
        //pdfFormFields.SetField("txtPoliza2", txtPoliza2);
        //pdfFormFields.SetField("txtSolicitante", txtSolicitante);
        //pdfFormFields.SetField("txtPoliza3", txtPoliza3);
        //pdfFormFields.SetField("txtPregunta1", txtPregunta1);
        //pdfFormFields.SetField("chkSiPregunta2", chkSiPregunta2);
        //pdfFormFields.SetField("txtPoliza11", txtPoliza11);
        //pdfFormFields.SetField("txtPoliza10", txtPoliza10);
        //pdfFormFields.SetField("txtPoliza13", txtPoliza13);
        //pdfFormFields.SetField("txtPoliza12", txtPoliza12);
        //pdfFormFields.SetField("chkNoPregunta6", chkNoPregunta6);
        //pdfFormFields.SetField("txtPoliza5", txtPoliza5);
        //pdfFormFields.SetField("txtPoliza6", txtPoliza6);
        //pdfFormFields.SetField("txtFolio8", txtFolio8);
        //pdfFormFields.SetField("txtFolio9", txtFolio9);
        //pdfFormFields.SetField("txtPoliza7", txtPoliza7);
        //pdfFormFields.SetField("chkNoPregunta3e", chkNoPregunta3e);
        //pdfFormFields.SetField("txtFolio4", txtFolio4);
        //pdfFormFields.SetField("txtFolio5", txtFolio5);
        //pdfFormFields.SetField("txtFolio6", txtFolio6);
        //pdfFormFields.SetField("txtFolio7", txtFolio7);
        //pdfFormFields.SetField("chkNoPregunta3b", chkNoPregunta3b);
        //pdfFormFields.SetField("txtFolio1", txtFolio1);
        //pdfFormFields.SetField("txtFolio2", txtFolio2);
        //pdfFormFields.SetField("txtFolio3", txtFolio3);
        //pdfFormFields.SetField("chkSiPregunta3c", chkSiPregunta3c);
        //pdfFormFields.SetField("chkSiPregunta3b", chkSiPregunta3b);
        //pdfFormFields.SetField("chkSiPregunta3e", chkSiPregunta3e);
        //pdfFormFields.SetField("txtPoliza4", txtPoliza4);
        //pdfFormFields.SetField("chkSiPregunta3g", chkSiPregunta3g);
        //pdfFormFields.SetField("chkSiPregunta3f", chkSiPregunta3f);
        //pdfFormFields.SetField("txtContratante", txtContratante);
        //pdfFormFields.SetField("chkNoPregunta1", chkNoPregunta1);
        //pdfFormFields.SetField("txtFolio13", txtFolio13);
        //pdfFormFields.SetField("txtLugaryFecha", txtLugaryFecha);
        //pdfFormFields.SetField("txtFolio12", txtFolio12);
        //pdfFormFields.SetField("chkNoPregunta3g", chkNoPregunta3g);
        //pdfFormFields.SetField("txtFolio11", txtFolio11);
        //pdfFormFields.SetField("chkNoPregunta2", chkNoPregunta2);
        //pdfFormFields.SetField("txtFolio10", txtFolio10);
        //pdfFormFields.SetField("chkNoPregunta3a", chkNoPregunta3a);
        //pdfFormFields.SetField("chkSiPregunta5", chkSiPregunta5);
        //pdfFormFields.SetField("chkNoPregunta3f", chkNoPregunta3f);
        //pdfFormFields.SetField("txtPoliza8", txtPoliza8);
        //pdfFormFields.SetField("chkNoPregunta4", chkNoPregunta4);
        //pdfFormFields.SetField("txtPoliza9", txtPoliza9);
        //pdfFormFields.SetField("chkSiPregunta3", chkSiPregunta3);
        //pdfFormFields.SetField("txtpregunta6", txtpregunta6);
        //pdfFormFields.SetField("chkNoPregunta5", chkNoPregunta5);
        //pdfFormFields.SetField("chkSiPregunta3a", chkSiPregunta3a);






        // report by reading values from completed PDF
        //string sTmp = "W-4 Completed for " + pdfFormFields.GetField("f1_09(0)") + " " +
        //  pdfFormFields.GetField("f1_10(0)");
        //MessageBox.Show(sTmp, "Finished");

        // flatten the form to remove editting options, set it to false
        // to leave the form open to subsequent manual edits
        //pdfStamper.FormFlattening = false;

        // close the pdf
        //pdfStamper.Close();
        //}
        //catch (Exception ex)
        //{
        //    MapfreMMX.util.MLogFile.getInstance().writeText("Error FillFormCuestionariMedico: " + ex.Message);
        //}
        #endregion
    }

    public void AbrirPdf(string nombre)
    {
        string RutaImp = ConfigurationSettings.AppSettings["RutaImpresionArchivo"].ToString();

        string FileName = @RutaImp + nombre + ".pdf";

        Response.ClearContent();

        Response.ClearHeaders();

        Response.AddHeader("Content-Disposition", "inline;filename=" + FileName);

        Response.ContentType = "application/pdf";

        Response.WriteFile(FileName);

        Response.Flush();

        Response.Clear();
    }
    private void FillFormSolicitud(string nomFile)
    {
        #region comment
        //string pdfTemplate = @"C:\inetpub\wwwroot\EmisionGeneralVida\SolicitudPDF\solicitud_de_vida.pdf";
        //string newFile = @"C:\inetpub\wwwroot\EmisionGeneralVida\SolicitudPDF\Firma\sv_" + nomFile + ".pdf";

        //try
        //{
        //    MapfreMMX.util.MLogFile.getInstance().writeText("FillFormSolicitud(" + nomFile + ")");
        //    PdfReader pdfReader = new PdfReader(pdfTemplate);
        //    PdfStamper pdfStamper = new PdfStamper(pdfReader, new FileStream(
        //                newFile, FileMode.Create));

        //AcroFields pdfFormFields = pdfStamper.AcroFields;
        #region DeclaraVariables
        String CLM_Contratante = "";
        String CLM_Asegurado = "";
        String EsMoral = "";
        String AseguradoEsContratante = "";
        String txtRelacionSolicitantePersonaFisica = "";
        String chkRechazadoSi = "";
        String txtParentescoDos = "";
        String txtCodigoCiudadSolicitante = "";
        String chkCagoPublicoNoSolicitante = "";
        String txtDuracionUno = "";
        String chkInsuficienciaRenalNo = "";
        String chkCorazonSi = "";
        String chkFinalidadSeguroPatrimonial = "";
        String txtNoInteriorSolicitante = "";
        String txtPaisLugarNacimientoPersonaFisica = "";
        String txtEa = "";
        String txtOberservacionesDos = "";
        String txtPlan = "";
        String txtPolizaUno = "";
        String txtFolioUno = "";
        String txtFolioTres = "";
        String chkEndocrinasNo = "";
        String txtBeneficiariosNombreCompletoUno = "";
        String txtDomicilioCompletoDos = "";
        String txtEspecificacionCompañiaSumaAseguradaMonedaPlan = "";
        String chkMancomunado = "";
        String chkBefSi = "";
        String txtEspecifiquePersonaFIsica = "";
        String chkBeneficiarioNo = "";
        String txtFechaNacimientoUno = "";
        String txtTelefonoContratante = "";
        String txtNoInteriorContratante = "";
        String txtMotivo = "";
        String txtFechaNacimientoPersonaFisica = "";
        String txtFechaConstitucion = "";
        String chkSolicitanteNo = "";
        String chkCerebroVasculadresNo = "";
        String chkCrecimientoGeometrico = "";
        String txtTipoNumeroEmisorIdentidadOficialSolicitante = "";
        String txtCurpSolicitante = "";
        String txtPadecimientoTres = "";
        String txtOberservacionesTres = "";
        String chkMonedaNacional = "";
        String chkFinalidadSeguroCredito = "";
        String txtCorreoElectronicoPersonaFisica = "";
        String txtFolioCinco = "";
        String txtPaisResidenciaFiscalContratante = "";
        String txtNombreCompletoApoderadoLegal = "";
        String chkFormaPagoSemestral = "";
        String chkCorazonNo = "";
        String txtOcupacionProfesionPersonaFisica = "";
        String txtNombreFirmaSolicitante = "";
        String chkAparatoDigestivoSi = "";
        String txtPolizaNueve = "";
        String txtOcupacionSolicitante = "";
        String txtVigenciaSolicitante = "";
        String txtFolioDiez = "";
        String chkFormaPagoTrimestral = "";
        String txtFolioTrece = "";
        String txtMoneda = "";
        String txtNacionPersFis = "";
        String chkAccidenteMac = "";
        String chkHipertesionArterialSi = "";
        String chkConductoCobroTransferenciaBancaria = "";
        String chkFumaNoSolicitante = "";
        String txtSumaAseguradaInvalidez = "";
        String chkSolicitanteSi = "";
        String txtFolioNueve = "";
        String chkServiciosFunerariosSI = "";
        String chkSidaNo = "";
        String txtDuracionTres = "";
        String txtRfcPersonaFisica = "";
        String chkConductoCobroEfectivo = "";
        String txtClaveAgente = "";
        String chkSexoMasculinoSolicitante = "";
        String txtRelacionSolicitante = "";
        String txtPolizaOnce = "";
        String chkSangreSi = "";
        String chkCargoFuncionPublicaSi = "";
        String chkAccidentePo = "";
        String chkPsiquiatricasNerviosasNo = "";
        String txtOrdenesTransferenciaPermanentesContratante = "";
        String chkContratanteSi = "";
        String txtTipoNumeroEmisorIdentificacionOficialPersonaFisica = "";
        String chkConductoCobroAgente = "";
        String chkAccidentePoc = "";
        String chkFormaPagoUnico = "";
        String txtFechaNacimientoDos = "";
        String txtSumaAseguradaBasica = "";
        String txtIngresoMensualSolicitante = "";
        String txtComisionAgente = "";
        String txtFechaNacimientoSolicitante = "";
        String chkPulmonaresRespiratoriasNo = "";
        String chkNivelada = "";
        String chkCargoFuncionPublicaNo = "";
        String txtPolizaDos = "";
        String txtPorcentajeDos = "";
        String chkSolicitudSi = "";
        String txtCrecimiento = "";
        String txtFechaInicioTres = "";
        String chkFinalidadSeguroSocios = "";
        String txtPreguntaUno = "";
        String txtOberservacionesUno = "";
        String txtnNumSerieFirmElectr = "";
        String txtPolizaCinco = "";
        String chkEnfermedadesGravesNo = "";
        String txtGiroTelefonoEmpresaSolicitante = "";
        String txtColoniaSolicitante = "";
        String txtEstadoProvinciaContratante = "";
        String chkConsumoDrogasNo = "";
        String txtFechaInicioDos = "";
        String txtMunicipioDelegacionContratante = "";
        String txtPolizaDiez = "";
        String txtFolioSiete = "";
        String txtRfcPersonaMoral = "";
        String txtTelefonoSolicitante = "";
        String txtFolioDoce = "";
        String chkAccidenteMapoc = "";
        String txtPolizaCuatro = "";
        String txtPaisRecidenciaFiscalSolicitante = "";
        String txtPeso = "";
        String txtNacionalidadesSolicitante = "";
        String txtFolioMercantil = "";
        String txtNombreFirmaContratante = "";
        String chkCirrosisHeptitisNo = "";
        String txtPolizaSeis = "";
        String chkCrebroVasculadresSI = "";
        String txtPorcentajeUno = "";
        String txtCanFumaSol = "";
        String txtCalleSolicitante = "";
        String txtNombrePaternoMaternoSolicitante = "";
        String txtVigenciaPersonaFisica = "";
        String txtEstadoProvinciaSolicitante = "";
        String txtPadecimientoUno = "";
        String chkBipa = "";
        String chkEnfermedadMencionadaNo = "";
        String chkDecreciente = "";
        String txtDomicilioCompletoTres = "";
        String chkBita = "";
        String chkFumaSiSolicitante = "";
        String txtNombreAgente = "";
        String txtPolizaSiete = "";
        String txtCpPoboxSolicitante = "";
        String txtNumeroSerieFIrmaElectronicaAvanzadaPersonaFisica = "";
        String txtMunicipioDelegacionSolicitante = "";
        String chkFormaPagoMensual = "";
        String txtNoExteriorContratante = "";
        String chkAccidenteMa = "";
        String txtDomicilioCompletoUno = "";
        String chkServiciosFunerariosNo = "";
        String txtCualDeporte = "";
        String chkBeneficiarioSi = "";
        String txtNombrePaternoMaternoPersonaFisica = "";
        String txtEstadoActualUno = "";
        String txtFolioSeis = "";
        String chkFinalidadSeguroRetiro = "";
        String txtPreguntaTres = "";
        String txtGiroNegocioPersonaFisica = "";
        String txtCiudadPoblacionContratente = "";
        String chkBefNO = "";
        String txtParentescoUno = "";
        String txtEstadoActualTres = "";
        String txtEstadoCivilSolicitante = "";
        String txtBeneficiariosNombreCompletoTres = "";
        String txtFolioOcho = "";
        String txtFechaNacimientoTres = "";
        String txtCiudadPoblacionSolicitante = "";
        String txtMedioEntrega = "";
        String chkartritisNo = "";
        String chkFinalidadSeguroHombreClave = "";
        String txtBeneficiariosNombreCompletoDos = "";
        String txtPaisLugarNacimientoSolicitante = "";
        String chkFinalidadSeguroEducacion = "";
        String txtNacionalidadApoderado = "";
        String txtFirmaAgente = "";
        String chkPulmonaresRespiratoriasSi = "";
        String chkEndocrinasSI = "";
        String txtColoniaContratente = "";
        String txtCalleContratente = "";
        String chkFormaPagoQuincenal = "";
        String chkSexoFemeninoSolicitante = "";
        String txtFolioOnce = "";
        String txtPlazo = "";
        String txtCorreoElectronicoSolicitante = "";
        String txtCurpPersonaFIsica = "";
        String txtClavePaisContratante = "";
        String txtPolizaOcho = "";
        String txtClavePaisSolicitante = "";
        String chkMonedaDolares = "";
        String chkCrecimientoConstante = "";
        String txtSumaAseguradaPlanSuperacionPlus = "";
        String txtEspecifiqueSolicitante = "";
        String chkPsiquiatricasNerviosasSi = "";
        String txtCorreoElectrPagWeb = "";
        String chkRechazadoNo = "";
        String chkDeportePeligrosoNo = "";
        String txtSumaAseguradaAccidente = "";
        String txtEspecificarCargoSolicitante = "";
        String txtCodigoPaisContratante = "";
        String chkSangreNo = "";
        String txtCpPoboxContratante = "";
        String chkTemporalIndividual = "";
        String chkMonedaUdis = "";
        String txtFolioCuatro = "";
        String txtNumeroSerieFimaElectronicaAvanzadaSolicitante = "";
        String txtPolizaDoce = "";
        String chkHipertensionArterialNo = "";
        String txtTinNifEquivalenteSolicitante = "";
        String chkAparatoDigestivoNo = "";
        String txtTinNifPersonaFisica = "";
        String chkInsuficienciaRenalSi = "";
        String chkDeportePeligrosoSi = "";
        String txtDomicApoderadoLegal = "";
        String txtrazonSocial = "";
        String chkSidaSI = "";
        String chkCargoPublicoSiSolicitante = "";
        String txtPolizaTrece = "";
        String txtParentescoTres = "";
        String chkEnfermedadesGravesSi = "";
        String txtFolioDos = "";
        String chkBit = "";
        String chkConsumoDrogasSI = "";
        String txtRfcSolicitante = "";
        String txtEstatura = "";
        String txtPaisContratante = "";
        String chkFormaPagoSemanal = "";
        String txtDuracionDos = "";
        String txtNoExteriorSolicitante = "";
        String chkFormaPagoContado = "";
        String chkCrecimientoLineal = "";
        String txtEspecifiqueCargoPersonaFisica = "";
        String chkArtritisSI = "";
        String txtGiroMercantilObjSocial = "";
        String chkCirrosisHeptitisSi = "";
        String txtPolizaTres = "";
        String chkEnfermedadMencionadaSi = "";
        String chkPasi = "";
        String txtPadecimientoDos = "";
        String txtPreguntaDos = "";
        String txtEmpresaPrestaServicioSolicitante = "";
        String chkConductoCobroDomiciliado = "";
        String txtNacionalidad = "";
        String txtFechaInicioUno = "";
        String chkSolicitudNo = "";
        String txtEstadoActualDos = "";
        String chkContratanteNo = "";
        String chkAccidenteMapo = "";
        String txtPorcentajeTres = "";
        String txtSolLugaryFecha = "";

        #endregion

        //#region beneficiarios

        //var dtBeneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();
        //var nb = dtBeneficiarios.Rows.Count;

        //String[] fechaBeneficiario = new String[nb];
        //String[] parentescoBeneficiario = new String[nb];
        //String[] nombreBeneficiario = new String[nb];
        //String[] porcentajeBeneficiario = new String[nb];
        //String[] domicilioBeneficiario = new String[nb];

        //for (int i = 0; i <= nb - 1; i++)
        //{
        //    fechaBeneficiario[i] = dtBeneficiarios.Rows[i]["fecnac"].ToString();
        //    parentescoBeneficiario[i] = dtBeneficiarios.Rows[i]["nom_parent"].ToString();
        //    nombreBeneficiario[i] = dtBeneficiarios.Rows[i]["nombre"].ToString() + " " + dtBeneficiarios.Rows[i]["paterno"].ToString() + " " + dtBeneficiarios.Rows[i]["materno"].ToString();
        //    porcentajeBeneficiario[i] = dtBeneficiarios.Rows[i]["porcentaje"].ToString();
        //    domicilioBeneficiario[i] = dtBeneficiarios.Rows[i]["domicilio"].ToString();
        //}

        //if (nombreBeneficiario.Length > 0 && nombreBeneficiario[0] != null)
        //{
        //    txtBeneficiariosNombreCompletoUno = nombreBeneficiario[0];
        //}
        //if (nombreBeneficiario.Length > 1 && nombreBeneficiario[1] != null)
        //{
        //    txtBeneficiariosNombreCompletoDos = nombreBeneficiario[1];
        //}
        //if (nombreBeneficiario.Length > 2 && nombreBeneficiario[2] != null)
        //{
        //    txtBeneficiariosNombreCompletoTres = nombreBeneficiario[2];
        //}
        //if (parentescoBeneficiario.Length > 0 && parentescoBeneficiario[0] != null)
        //{
        //    txtParentescoUno = parentescoBeneficiario[0];
        //}
        //if (parentescoBeneficiario.Length > 1 && parentescoBeneficiario[1] != null)
        //{
        //    txtParentescoDos = parentescoBeneficiario[1];
        //}
        //if (parentescoBeneficiario.Length > 2 && parentescoBeneficiario[2] != null)
        //{
        //    txtParentescoTres = parentescoBeneficiario[2];
        //}
        //if (porcentajeBeneficiario.Length > 0 && porcentajeBeneficiario[0] != null)
        //{
        //    txtPorcentajeUno = porcentajeBeneficiario[0];
        //}
        //if (porcentajeBeneficiario.Length > 1 && porcentajeBeneficiario[1] != null)
        //{
        //    txtPorcentajeDos = porcentajeBeneficiario[1];
        //}
        //if (porcentajeBeneficiario.Length > 2 && porcentajeBeneficiario[2] != null)
        //{
        //    txtPorcentajeTres = porcentajeBeneficiario[2];
        //}
        //if (domicilioBeneficiario.Length > 0 && domicilioBeneficiario[0] != null)
        //{
        //    txtDomicilioCompletoUno = domicilioBeneficiario[0];
        //}
        //if (domicilioBeneficiario.Length > 1 && domicilioBeneficiario[1] != null)
        //{
        //    txtDomicilioCompletoDos = domicilioBeneficiario[1];
        //}
        //if (domicilioBeneficiario.Length > 2 && domicilioBeneficiario[2] != null)
        //{
        //    txtDomicilioCompletoTres = domicilioBeneficiario[2];
        //}
        //if (fechaBeneficiario.Length > 0 && fechaBeneficiario[0] != null)
        //{
        //    txtFechaNacimientoUno = fechaBeneficiario[0];
        //}
        //if (fechaBeneficiario.Length > 1 && fechaBeneficiario[1] != null)
        //{
        //    txtFechaNacimientoDos = fechaBeneficiario[1];
        //}
        //if (fechaBeneficiario.Length > 2 && fechaBeneficiario[2] != null)
        //{
        //    txtFechaNacimientoTres = fechaBeneficiario[2];
        //}

        #endregion

        #region setVariables

        if (!string.IsNullOrEmpty(Request.Form["txtRelacionSolicitantePersonaFisica"])) { txtRelacionSolicitantePersonaFisica = Request.Form["txtRelacionSolicitantePersonaFisica"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkRechazadoSi"])) { chkRechazadoSi = Request.Form["chkRechazadoSi"]; }
        //if (!string.IsNullOrEmpty(Request.Form["txtParentescoDos"])) { txtParentescoDos = Request.Form["txtParentescoDos"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtCodigoCiudadSolicitante"])) { txtCodigoCiudadSolicitante = Request.Form["txtCodigoCiudadSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkCagoPublicoNoSolicitante"])) { chkCagoPublicoNoSolicitante = Request.Form["chkCagoPublicoNoSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtDuracionUno"])) { txtDuracionUno = Request.Form["txtDuracionUno"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkInsuficienciaRenalNo"])) { chkInsuficienciaRenalNo = Request.Form["chkInsuficienciaRenalNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkCorazonSi"])) { chkCorazonSi = Request.Form["chkCorazonSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkFinalidadSeguroPatrimonial"])) { chkFinalidadSeguroPatrimonial = Request.Form["chkFinalidadSeguroPatrimonial"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNoInteriorSolicitante"])) { txtNoInteriorSolicitante = Request.Form["txtNoInteriorSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPaisLugarNacimientoPersonaFisica"])) { txtPaisLugarNacimientoPersonaFisica = Request.Form["txtPaisLugarNacimientoPersonaFisica"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtEa"])) { txtEa = Request.Form["txtEa"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtOberservacionesDos"])) { txtOberservacionesDos = Request.Form["txtOberservacionesDos"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPlan"])) { txtPlan = Request.Form["txtPlan"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPolizaUno"])) { txtPolizaUno = Request.Form["txtPolizaUno"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolioUno"])) { txtFolioUno = Request.Form["txtFolioUno"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolioTres"])) { txtFolioTres = Request.Form["txtFolioTres"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkEndocrinasNo"])) { chkEndocrinasNo = Request.Form["chkEndocrinasNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtBeneficiariosNombreCompletoUno"])) { txtBeneficiariosNombreCompletoUno = Request.Form["txtBeneficiariosNombreCompletoUno"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtDomicilioCompletoDos"])) { txtDomicilioCompletoDos = Request.Form["txtDomicilioCompletoDos"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtEspecificacionCompañiaSumaAseguradaMonedaPlan"])) { txtEspecificacionCompañiaSumaAseguradaMonedaPlan = Request.Form["txtEspecificacionCompañiaSumaAseguradaMonedaPlan"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkMancomunado"])) { chkMancomunado = Request.Form["chkMancomunado"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkBefSi"])) { chkBefSi = Request.Form["chkBefSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtEspecifiquePersonaFIsica"])) { txtEspecifiquePersonaFIsica = Request.Form["txtEspecifiquePersonaFIsica"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkBeneficiarioNo"])) { chkBeneficiarioNo = Request.Form["chkBeneficiarioNo"]; }
        //if (!string.IsNullOrEmpty(Request.Form["txtFechaNacimientoUno"])) { txtFechaNacimientoUno = Request.Form["txtFechaNacimientoUno"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtTelefonoContratante"])) { txtTelefonoContratante = Request.Form["txtTelefonoContratante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNoInteriorContratante"])) { txtNoInteriorContratante = Request.Form["txtNoInteriorContratante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtMotivo"])) { txtMotivo = Request.Form["txtMotivo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFechaNacimientoPersonaFisica"])) { txtFechaNacimientoPersonaFisica = Request.Form["txtFechaNacimientoPersonaFisica"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFechaConstitucion"])) { txtFechaConstitucion = Request.Form["txtFechaConstitucion"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSolicitanteNo"])) { chkSolicitanteNo = Request.Form["chkSolicitanteNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkCerebroVasculadresNo"])) { chkCerebroVasculadresNo = Request.Form["chkCerebroVasculadresNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkCrecimientoGeometrico"])) { chkCrecimientoGeometrico = Request.Form["chkCrecimientoGeometrico"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtTipoNumeroEmisorIdentidadOficialSolicitante"])) { txtTipoNumeroEmisorIdentidadOficialSolicitante = Request.Form["txtTipoNumeroEmisorIdentidadOficialSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtCurpSolicitante"])) { txtCurpSolicitante = Request.Form["txtCurpSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPadecimientoTres"])) { txtPadecimientoTres = Request.Form["txtPadecimientoTres"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtOberservacionesTres"])) { txtOberservacionesTres = Request.Form["txtOberservacionesTres"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkMonedaNacional"])) { chkMonedaNacional = Request.Form["chkMonedaNacional"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkFinalidadSeguroCredito"])) { chkFinalidadSeguroCredito = Request.Form["chkFinalidadSeguroCredito"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtCorreoElectronicoPersonaFisica"])) { txtCorreoElectronicoPersonaFisica = Request.Form["txtCorreoElectronicoPersonaFisica"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolioCinco"])) { txtFolioCinco = Request.Form["txtFolioCinco"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPaisResidenciaFiscalContratante"])) { txtPaisResidenciaFiscalContratante = Request.Form["txtPaisResidenciaFiscalContratante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNombreCompletoApoderadoLegal"])) { txtNombreCompletoApoderadoLegal = Request.Form["txtNombreCompletoApoderadoLegal"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkFormaPagoSemestral"])) { chkFormaPagoSemestral = Request.Form["chkFormaPagoSemestral"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkCorazonNo"])) { chkCorazonNo = Request.Form["chkCorazonNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtOcupacionProfesionPersonaFisica"])) { txtOcupacionProfesionPersonaFisica = Request.Form["txtOcupacionProfesionPersonaFisica"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNombreFirmaSolicitante"])) { txtNombreFirmaSolicitante = Request.Form["txtNombreFirmaSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkAparatoDigestivoSi"])) { chkAparatoDigestivoSi = Request.Form["chkAparatoDigestivoSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPolizaNueve"])) { txtPolizaNueve = Request.Form["txtPolizaNueve"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtOcupacionSolicitante"])) { txtOcupacionSolicitante = Request.Form["txtOcupacionSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtVigenciaSolicitante"])) { txtVigenciaSolicitante = Request.Form["txtVigenciaSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolioDiez"])) { txtFolioDiez = Request.Form["txtFolioDiez"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkFormaPagoTrimestral"])) { chkFormaPagoTrimestral = Request.Form["chkFormaPagoTrimestral"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolioTrece"])) { txtFolioTrece = Request.Form["txtFolioTrece"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtMoneda"])) { txtMoneda = Request.Form["txtMoneda"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNacionPersFis"])) { txtNacionPersFis = Request.Form["txtNacionPersFis"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkAccidenteMac"])) { chkAccidenteMac = Request.Form["chkAccidenteMac"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkHipertesionArterialSi"])) { chkHipertesionArterialSi = Request.Form["chkHipertesionArterialSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkConductoCobroTransferenciaBancaria"])) { chkConductoCobroTransferenciaBancaria = Request.Form["chkConductoCobroTransferenciaBancaria"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkFumaNoSolicitante"])) { chkFumaNoSolicitante = Request.Form["chkFumaNoSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSumaAseguradaInvalidez"])) { txtSumaAseguradaInvalidez = Request.Form["txtSumaAseguradaInvalidez"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSolicitanteSi"])) { chkSolicitanteSi = Request.Form["chkSolicitanteSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolioNueve"])) { txtFolioNueve = Request.Form["txtFolioNueve"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkServiciosFunerariosSI"])) { chkServiciosFunerariosSI = Request.Form["chkServiciosFunerariosSI"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSidaNo"])) { chkSidaNo = Request.Form["chkSidaNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtDuracionTres"])) { txtDuracionTres = Request.Form["txtDuracionTres"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtRfcPersonaFisica"])) { txtRfcPersonaFisica = Request.Form["txtRfcPersonaFisica"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkConductoCobroEfectivo"])) { chkConductoCobroEfectivo = Request.Form["chkConductoCobroEfectivo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtClaveAgente"])) { txtClaveAgente = Request.Form["txtClaveAgente"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSexoMasculinoSolicitante"])) { chkSexoMasculinoSolicitante = Request.Form["chkSexoMasculinoSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtRelacionSolicitante"])) { txtRelacionSolicitante = Request.Form["txtRelacionSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPolizaOnce"])) { txtPolizaOnce = Request.Form["txtPolizaOnce"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSangreSi"])) { chkSangreSi = Request.Form["chkSangreSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkCargoFuncionPublicaSi"])) { chkCargoFuncionPublicaSi = Request.Form["chkCargoFuncionPublicaSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkAccidentePo"])) { chkAccidentePo = Request.Form["chkAccidentePo"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkPsiquiatricasNerviosasNo"])) { chkPsiquiatricasNerviosasNo = Request.Form["chkPsiquiatricasNerviosasNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtOrdenesTransferenciaPermanentesContratante"])) { txtOrdenesTransferenciaPermanentesContratante = Request.Form["txtOrdenesTransferenciaPermanentesContratante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkContratanteSi"])) { chkContratanteSi = Request.Form["chkContratanteSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtTipoNumeroEmisorIdentificacionOficialPersonaFisica"])) { txtTipoNumeroEmisorIdentificacionOficialPersonaFisica = Request.Form["txtTipoNumeroEmisorIdentificacionOficialPersonaFisica"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkConductoCobroAgente"])) { chkConductoCobroAgente = Request.Form["chkConductoCobroAgente"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkAccidentePoc"])) { chkAccidentePoc = Request.Form["chkAccidentePoc"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkFormaPagoUnico"])) { chkFormaPagoUnico = Request.Form["chkFormaPagoUnico"]; }
        //if (!string.IsNullOrEmpty(Request.Form["txtFechaNacimientoDos"])) { txtFechaNacimientoDos = Request.Form["txtFechaNacimientoDos"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSumaAseguradaBasica"])) { txtSumaAseguradaBasica = Request.Form["txtSumaAseguradaBasica"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtIngresoMensualSolicitante"])) { txtIngresoMensualSolicitante = Request.Form["txtIngresoMensualSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtComisionAgente"])) { txtComisionAgente = Request.Form["txtComisionAgente"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFechaNacimientoSolicitante"])) { txtFechaNacimientoSolicitante = Request.Form["txtFechaNacimientoSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkPulmonaresRespiratoriasNo"])) { chkPulmonaresRespiratoriasNo = Request.Form["chkPulmonaresRespiratoriasNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkNivelada"])) { chkNivelada = Request.Form["chkNivelada"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkCargoFuncionPublicaNo"])) { chkCargoFuncionPublicaNo = Request.Form["chkCargoFuncionPublicaNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPolizaDos"])) { txtPolizaDos = Request.Form["txtPolizaDos"]; }
        //if (!string.IsNullOrEmpty(Request.Form["txtPorcentajeDos"])) { txtPorcentajeDos = Request.Form["txtPorcentajeDos"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSolicitudSi"])) { chkSolicitudSi = Request.Form["chkSolicitudSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtCrecimiento"])) { txtCrecimiento = Request.Form["txtCrecimiento"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFechaInicioTres"])) { txtFechaInicioTres = Request.Form["txtFechaInicioTres"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkFinalidadSeguroSocios"])) { chkFinalidadSeguroSocios = Request.Form["chkFinalidadSeguroSocios"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPreguntaUno"])) { txtPreguntaUno = Request.Form["txtPreguntaUno"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtOberservacionesUno"])) { txtOberservacionesUno = Request.Form["txtOberservacionesUno"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtnNumSerieFirmElectr"])) { txtnNumSerieFirmElectr = Request.Form["txtnNumSerieFirmElectr"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPolizaCinco"])) { txtPolizaCinco = Request.Form["txtPolizaCinco"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkEnfermedadesGravesNo"])) { chkEnfermedadesGravesNo = Request.Form["chkEnfermedadesGravesNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtGiroTelefonoEmpresaSolicitante"])) { txtGiroTelefonoEmpresaSolicitante = Request.Form["txtGiroTelefonoEmpresaSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtColoniaSolicitante"])) { txtColoniaSolicitante = Request.Form["txtColoniaSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtEstadoProvinciaContratante"])) { txtEstadoProvinciaContratante = Request.Form["txtEstadoProvinciaContratante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkConsumoDrogasNo"])) { chkConsumoDrogasNo = Request.Form["chkConsumoDrogasNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFechaInicioDos"])) { txtFechaInicioDos = Request.Form["txtFechaInicioDos"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtMunicipioDelegacionContratante"])) { txtMunicipioDelegacionContratante = Request.Form["txtMunicipioDelegacionContratante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPolizaDiez"])) { txtPolizaDiez = Request.Form["txtPolizaDiez"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolioSiete"])) { txtFolioSiete = Request.Form["txtFolioSiete"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtRfcPersonaMoral"])) { txtRfcPersonaMoral = Request.Form["txtRfcPersonaMoral"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtTelefonoSolicitante"])) { txtTelefonoSolicitante = Request.Form["txtTelefonoSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolioDoce"])) { txtFolioDoce = Request.Form["txtFolioDoce"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkAccidenteMapoc"])) { chkAccidenteMapoc = Request.Form["chkAccidenteMapoc"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPolizaCuatro"])) { txtPolizaCuatro = Request.Form["txtPolizaCuatro"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPaisRecidenciaFiscalSolicitante"])) { txtPaisRecidenciaFiscalSolicitante = Request.Form["txtPaisRecidenciaFiscalSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPeso"])) { txtPeso = Request.Form["txtPeso"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNacionalidadesSolicitante"])) { txtNacionalidadesSolicitante = Request.Form["txtNacionalidadesSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolioMercantil"])) { txtFolioMercantil = Request.Form["txtFolioMercantil"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNombreFirmaContratante"])) { txtNombreFirmaContratante = Request.Form["txtNombreFirmaContratante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkCirrosisHeptitisNo"])) { chkCirrosisHeptitisNo = Request.Form["chkCirrosisHeptitisNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPolizaSeis"])) { txtPolizaSeis = Request.Form["txtPolizaSeis"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkCrebroVasculadresSI"])) { chkCrebroVasculadresSI = Request.Form["chkCrebroVasculadresSI"]; }
        //if (!string.IsNullOrEmpty(Request.Form["txtPorcentajeUno"])) { txtPorcentajeUno = Request.Form["txtPorcentajeUno"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtCanFumaSol"])) { txtCanFumaSol = Request.Form["txtCanFumaSol"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtCalleSolicitante"])) { txtCalleSolicitante = Request.Form["txtCalleSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNombrePaternoMaternoSolicitante"])) { txtNombrePaternoMaternoSolicitante = Request.Form["txtNombrePaternoMaternoSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtVigenciaPersonaFisica"])) { txtVigenciaPersonaFisica = Request.Form["txtVigenciaPersonaFisica"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtEstadoProvinciaSolicitante"])) { txtEstadoProvinciaSolicitante = Request.Form["txtEstadoProvinciaSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPadecimientoUno"])) { txtPadecimientoUno = Request.Form["txtPadecimientoUno"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkBipa"])) { chkBipa = Request.Form["chkBipa"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkEnfermedadMencionadaNo"])) { chkEnfermedadMencionadaNo = Request.Form["chkEnfermedadMencionadaNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkDecreciente"])) { chkDecreciente = Request.Form["chkDecreciente"]; }
        //if (!string.IsNullOrEmpty(Request.Form["txtDomicilioCompletoTres"])) { txtDomicilioCompletoTres = Request.Form["txtDomicilioCompletoTres"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkBita"])) { chkBita = Request.Form["chkBita"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkFumaSiSolicitante"])) { chkFumaSiSolicitante = Request.Form["chkFumaSiSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNombreAgente"])) { txtNombreAgente = Request.Form["txtNombreAgente"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPolizaSiete"])) { txtPolizaSiete = Request.Form["txtPolizaSiete"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtCpPoboxSolicitante"])) { txtCpPoboxSolicitante = Request.Form["txtCpPoboxSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNumeroSerieFIrmaElectronicaAvanzadaPersonaFisica"])) { txtNumeroSerieFIrmaElectronicaAvanzadaPersonaFisica = Request.Form["txtNumeroSerieFIrmaElectronicaAvanzadaPersonaFisica"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtMunicipioDelegacionSolicitante"])) { txtMunicipioDelegacionSolicitante = Request.Form["txtMunicipioDelegacionSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkFormaPagoMensual"])) { chkFormaPagoMensual = Request.Form["chkFormaPagoMensual"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNoExteriorContratante"])) { txtNoExteriorContratante = Request.Form["txtNoExteriorContratante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkAccidenteMa"])) { chkAccidenteMa = Request.Form["chkAccidenteMa"]; }
        //if (!string.IsNullOrEmpty(Request.Form["txtDomicilioCompletoUno"])) { txtDomicilioCompletoUno = Request.Form["txtDomicilioCompletoUno"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkServiciosFunerariosNo"])) { chkServiciosFunerariosNo = Request.Form["chkServiciosFunerariosNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtCualDeporte"])) { txtCualDeporte = Request.Form["txtCualDeporte"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkBeneficiarioSi"])) { chkBeneficiarioSi = Request.Form["chkBeneficiarioSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNombrePaternoMaternoPersonaFisica"])) { txtNombrePaternoMaternoPersonaFisica = Request.Form["txtNombrePaternoMaternoPersonaFisica"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtEstadoActualUno"])) { txtEstadoActualUno = Request.Form["txtEstadoActualUno"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolioSeis"])) { txtFolioSeis = Request.Form["txtFolioSeis"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkFinalidadSeguroRetiro"])) { chkFinalidadSeguroRetiro = Request.Form["chkFinalidadSeguroRetiro"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPreguntaTres"])) { txtPreguntaTres = Request.Form["txtPreguntaTres"]; }
        //Si la persona física llena el cuestionario del millon se obtiene el giro de la empresa del Anexo.
        bool cuestionarioMillon = Convert.ToBoolean(Request.Form["cuestionarioMillon"]);
        if (cuestionarioMillon)
        {
            if (!string.IsNullOrEmpty(Request.Form["txtSAGiroEmpresa"])) { txtGiroNegocioPersonaFisica = Request.Form["txtSAGiroEmpresa"]; }
        }
        else
        {
            if (!string.IsNullOrEmpty(Request.Form["txtGiroNegocioPersonaFisica"])) { txtGiroNegocioPersonaFisica = Request.Form["txtGiroNegocioPersonaFisica"]; }
        }
        if (!string.IsNullOrEmpty(Request.Form["txtCiudadPoblacionContratente"])) { txtCiudadPoblacionContratente = Request.Form["txtCiudadPoblacionContratente"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkBefNO"])) { chkBefNO = Request.Form["chkBefNO"]; }
        //if (!string.IsNullOrEmpty(Request.Form["txtParentescoUno"])) { txtParentescoUno = Request.Form["txtParentescoUno"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtEstadoActualTres"])) { txtEstadoActualTres = Request.Form["txtEstadoActualTres"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtEstadoCivilSolicitante"])) { txtEstadoCivilSolicitante = Request.Form["txtEstadoCivilSolicitante"]; }
        //if (!string.IsNullOrEmpty(Request.Form["txtBeneficiariosNombreCompletoTres"])) { txtBeneficiariosNombreCompletoTres = Request.Form["txtBeneficiariosNombreCompletoTres"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolioOcho"])) { txtFolioOcho = Request.Form["txtFolioOcho"]; }
        //if (!string.IsNullOrEmpty(Request.Form["txtFechaNacimientoTres"])) { txtFechaNacimientoTres = Request.Form["txtFechaNacimientoTres"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtCiudadPoblacionSolicitante"])) { txtCiudadPoblacionSolicitante = Request.Form["txtCiudadPoblacionSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtMedioEntrega"])) { txtMedioEntrega = Request.Form["txtMedioEntrega"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkartritisNo"])) { chkartritisNo = Request.Form["chkartritisNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkFinalidadSeguroHombreClave"])) { chkFinalidadSeguroHombreClave = Request.Form["chkFinalidadSeguroHombreClave"]; }
        //if (!string.IsNullOrEmpty(Request.Form["txtBeneficiariosNombreCompletoDos"])) { txtBeneficiariosNombreCompletoDos = Request.Form["txtBeneficiariosNombreCompletoDos"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPaisLugarNacimientoSolicitante"])) { txtPaisLugarNacimientoSolicitante = Request.Form["txtPaisLugarNacimientoSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkFinalidadSeguroEducacion"])) { chkFinalidadSeguroEducacion = Request.Form["chkFinalidadSeguroEducacion"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNacionalidadApoderado"])) { txtNacionalidadApoderado = Request.Form["txtNacionalidadApoderado"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFirmaAgente"])) { txtFirmaAgente = Request.Form["txtFirmaAgente"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkPulmonaresRespiratoriasSi"])) { chkPulmonaresRespiratoriasSi = Request.Form["chkPulmonaresRespiratoriasSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkEndocrinasSI"])) { chkEndocrinasSI = Request.Form["chkEndocrinasSI"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtColoniaContratente"])) { txtColoniaContratente = Request.Form["txtColoniaContratente"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtCalleContratente"])) { txtCalleContratente = Request.Form["txtCalleContratente"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkFormaPagoQuincenal"])) { chkFormaPagoQuincenal = Request.Form["chkFormaPagoQuincenal"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSexoFemeninoSolicitante"])) { chkSexoFemeninoSolicitante = Request.Form["chkSexoFemeninoSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolioOnce"])) { txtFolioOnce = Request.Form["txtFolioOnce"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPlazo"])) { txtPlazo = Request.Form["txtPlazo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtCorreoElectronicoSolicitante"])) { txtCorreoElectronicoSolicitante = Request.Form["txtCorreoElectronicoSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtCurpPersonaFIsica"])) { txtCurpPersonaFIsica = Request.Form["txtCurpPersonaFIsica"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtClavePaisContratante"])) { txtClavePaisContratante = Request.Form["txtClavePaisContratante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPolizaOcho"])) { txtPolizaOcho = Request.Form["txtPolizaOcho"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtClavePaisSolicitante"])) { txtClavePaisSolicitante = Request.Form["txtClavePaisSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkMonedaDolares"])) { chkMonedaDolares = Request.Form["chkMonedaDolares"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkCrecimientoConstante"])) { chkCrecimientoConstante = Request.Form["chkCrecimientoConstante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSumaAseguradaPlanSuperacionPlus"])) { txtSumaAseguradaPlanSuperacionPlus = Request.Form["txtSumaAseguradaPlanSuperacionPlus"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtEspecifiqueSolicitante"])) { txtEspecifiqueSolicitante = Request.Form["txtEspecifiqueSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkPsiquiatricasNerviosasSi"])) { chkPsiquiatricasNerviosasSi = Request.Form["chkPsiquiatricasNerviosasSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtCorreoElectrPagWeb"])) { txtCorreoElectrPagWeb = Request.Form["txtCorreoElectrPagWeb"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkRechazadoNo"])) { chkRechazadoNo = Request.Form["chkRechazadoNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkDeportePeligrosoNo"])) { chkDeportePeligrosoNo = Request.Form["chkDeportePeligrosoNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSumaAseguradaAccidente"])) { txtSumaAseguradaAccidente = Request.Form["txtSumaAseguradaAccidente"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtEspecificarCargoSolicitante"])) { txtEspecificarCargoSolicitante = Request.Form["txtEspecificarCargoSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtCodigoPaisContratante"])) { txtCodigoPaisContratante = Request.Form["txtCodigoPaisContratante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSangreNo"])) { chkSangreNo = Request.Form["chkSangreNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtCpPoboxContratante"])) { txtCpPoboxContratante = Request.Form["txtCpPoboxContratante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkTemporalIndividual"])) { chkTemporalIndividual = Request.Form["chkTemporalIndividual"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkMonedaUdis"])) { chkMonedaUdis = Request.Form["chkMonedaUdis"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolioCuatro"])) { txtFolioCuatro = Request.Form["txtFolioCuatro"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNumeroSerieFimaElectronicaAvanzadaSolicitante"])) { txtNumeroSerieFimaElectronicaAvanzadaSolicitante = Request.Form["txtNumeroSerieFimaElectronicaAvanzadaSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPolizaDoce"])) { txtPolizaDoce = Request.Form["txtPolizaDoce"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkHipertensionArterialNo"])) { chkHipertensionArterialNo = Request.Form["chkHipertensionArterialNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtTinNifEquivalenteSolicitante"])) { txtTinNifEquivalenteSolicitante = Request.Form["txtTinNifEquivalenteSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkAparatoDigestivoNo"])) { chkAparatoDigestivoNo = Request.Form["chkAparatoDigestivoNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtTinNifPersonaFisica"])) { txtTinNifPersonaFisica = Request.Form["txtTinNifPersonaFisica"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkInsuficienciaRenalSi"])) { chkInsuficienciaRenalSi = Request.Form["chkInsuficienciaRenalSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkDeportePeligrosoSi"])) { chkDeportePeligrosoSi = Request.Form["chkDeportePeligrosoSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtDomicApoderadoLegal"])) { txtDomicApoderadoLegal = Request.Form["txtDomicApoderadoLegal"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtrazonSocial"])) { txtrazonSocial = Request.Form["txtrazonSocial"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSidaSI"])) { chkSidaSI = Request.Form["chkSidaSI"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkCargoPublicoSiSolicitante"])) { chkCargoPublicoSiSolicitante = Request.Form["chkCargoPublicoSiSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPolizaTrece"])) { txtPolizaTrece = Request.Form["txtPolizaTrece"]; }
        //if (!string.IsNullOrEmpty(Request.Form["txtParentescoTres"])) { txtParentescoTres = Request.Form["txtParentescoTres"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkEnfermedadesGravesSi"])) { chkEnfermedadesGravesSi = Request.Form["chkEnfermedadesGravesSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFolioDos"])) { txtFolioDos = Request.Form["txtFolioDos"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkBit"])) { chkBit = Request.Form["chkBit"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkConsumoDrogasSI"])) { chkConsumoDrogasSI = Request.Form["chkConsumoDrogasSI"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtRfcSolicitante"])) { txtRfcSolicitante = Request.Form["txtRfcSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtEstatura"])) { txtEstatura = Request.Form["txtEstatura"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPaisContratante"])) { txtPaisContratante = Request.Form["txtPaisContratante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkFormaPagoSemanal"])) { chkFormaPagoSemanal = Request.Form["chkFormaPagoSemanal"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtDuracionDos"])) { txtDuracionDos = Request.Form["txtDuracionDos"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNoExteriorSolicitante"])) { txtNoExteriorSolicitante = Request.Form["txtNoExteriorSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkFormaPagoContado"])) { chkFormaPagoContado = Request.Form["chkFormaPagoContado"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkCrecimientoLineal"])) { chkCrecimientoLineal = Request.Form["chkCrecimientoLineal"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtEspecifiqueCargoPersonaFisica"])) { txtEspecifiqueCargoPersonaFisica = Request.Form["txtEspecifiqueCargoPersonaFisica"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkArtritisSI"])) { chkArtritisSI = Request.Form["chkArtritisSI"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtGiroMercantilObjSocial"])) { txtGiroMercantilObjSocial = Request.Form["txtGiroMercantilObjSocial"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkCirrosisHeptitisSi"])) { chkCirrosisHeptitisSi = Request.Form["chkCirrosisHeptitisSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPolizaTres"])) { txtPolizaTres = Request.Form["txtPolizaTres"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkEnfermedadMencionadaSi"])) { chkEnfermedadMencionadaSi = Request.Form["chkEnfermedadMencionadaSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkPasi"])) { chkPasi = Request.Form["chkPasi"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPadecimientoDos"])) { txtPadecimientoDos = Request.Form["txtPadecimientoDos"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtPreguntaDos"])) { txtPreguntaDos = Request.Form["txtPreguntaDos"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtEmpresaPrestaServicioSolicitante"])) { txtEmpresaPrestaServicioSolicitante = Request.Form["txtEmpresaPrestaServicioSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkConductoCobroDomiciliado"])) { chkConductoCobroDomiciliado = Request.Form["chkConductoCobroDomiciliado"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNacionalidad"])) { txtNacionalidad = Request.Form["txtNacionalidad"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtFechaInicioUno"])) { txtFechaInicioUno = Request.Form["txtFechaInicioUno"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSolicitudNo"])) { chkSolicitudNo = Request.Form["chkSolicitudNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtEstadoActualDos"])) { txtEstadoActualDos = Request.Form["txtEstadoActualDos"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkContratanteNo"])) { chkContratanteNo = Request.Form["chkContratanteNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkAccidenteMapo"])) { chkAccidenteMapo = Request.Form["chkAccidenteMapo"]; }
        //if (!string.IsNullOrEmpty(Request.Form["txtPorcentajeTres"])) { txtPorcentajeTres = Request.Form["txtPorcentajeTres"]; }
        if (txtEstadoProvinciaSolicitante != "" && txtMunicipioDelegacionSolicitante != "") { txtSolLugaryFecha = txtMunicipioDelegacionSolicitante + ", " + txtEstadoProvinciaSolicitante + " " + DateTime.Today.ToString("dd MM yyyy"); }
        if (!string.IsNullOrEmpty(Request.Form["CLM_Contratante"])) { CLM_Contratante = Request.Form["CLM_Contratante"]; }
        if (!string.IsNullOrEmpty(Request.Form["CLM_Asegurado"])) { CLM_Asegurado = Request.Form["CLM_Asegurado"]; }
        if (!string.IsNullOrEmpty(Request.Form["EsMoral"])) { EsMoral = Request.Form["EsMoral"]; }
        if (!string.IsNullOrEmpty(Request.Form["AseguradoEsContratante"])) { AseguradoEsContratante = Request.Form["AseguradoEsContratante"]; }

        //Recuperar datos faltantes en la solicitud única:
        CLM CLMBuscaContratante = new CLM();
        CLM CLMBuscaAsegurado = new CLM();

        //De los datos del contratante persona física Tipo, Numero y emisor de la identificación oficial, ya que persona Moral no tiene.
        if (EsMoral == "false")
        {
            var CLMContra = CLMBuscaContratante.GetCLMData(CLM_Contratante, 0);
            string noID = CLMContra.Tables[0].Rows[0]["p_tip_identificacion"].ToString();
            string identif = TipoIdentificacion(noID);
            txtTipoNumeroEmisorIdentificacionOficialPersonaFisica = identif + " " + CLMContra.Tables[0].Rows[0]["p_num_identificacion"].ToString();
            txtNoExteriorContratante = CLMContra.Tables[0].Rows[0]["p_num_exterior"].ToString();
            txtNoInteriorContratante = CLMContra.Tables[0].Rows[0]["p_num_interior"].ToString();
            if (AseguradoEsContratante == "true")
            {
                txtTipoNumeroEmisorIdentidadOficialSolicitante = txtTipoNumeroEmisorIdentificacionOficialPersonaFisica;
                txtNoExteriorSolicitante = txtNoExteriorContratante;
                txtNoInteriorSolicitante = txtNoInteriorContratante;
            }
            else if (AseguradoEsContratante == "false")
            {
                var CLMAsegurado = CLMBuscaAsegurado.GetCLMData(CLM_Asegurado, 0);
                noID = CLMAsegurado.Tables[0].Rows[0]["p_tip_identificacion"].ToString();
                identif = TipoIdentificacion(noID);
                txtTipoNumeroEmisorIdentidadOficialSolicitante = identif + " " + CLMAsegurado.Tables[0].Rows[0]["p_num_identificacion"].ToString();
                txtNoExteriorSolicitante = CLMAsegurado.Tables[0].Rows[0]["p_num_exterior"].ToString();
                txtNoInteriorSolicitante = CLMAsegurado.Tables[0].Rows[0]["p_num_interior"].ToString();
            }
        }
        else if (EsMoral == "true")
        {
            var CLMContra = CLMBuscaContratante.GetCLMData(CLM_Contratante, 0);
            txtNoExteriorContratante = CLMContra.Tables[0].Rows[0]["p_num_exterior"].ToString();
            txtNoInteriorContratante = CLMContra.Tables[0].Rows[0]["p_num_interior"].ToString();
            if (AseguradoEsContratante == "true")
            {
                txtTipoNumeroEmisorIdentidadOficialSolicitante = txtTipoNumeroEmisorIdentificacionOficialPersonaFisica;
                txtNoExteriorSolicitante = txtNoExteriorContratante;
                txtNoInteriorSolicitante = txtNoInteriorContratante;
            }
            else if (AseguradoEsContratante == "false")
            {
                var CLMAsegurado = CLMBuscaAsegurado.GetCLMData(CLM_Asegurado, 0);
                string noID = CLMAsegurado.Tables[0].Rows[0]["p_tip_identificacion"].ToString();
                string identif = TipoIdentificacion(noID);
                txtTipoNumeroEmisorIdentidadOficialSolicitante = identif + " " + CLMAsegurado.Tables[0].Rows[0]["p_num_identificacion"].ToString();
                txtNoExteriorSolicitante = CLMAsegurado.Tables[0].Rows[0]["p_num_exterior"].ToString();
                txtNoInteriorSolicitante = CLMAsegurado.Tables[0].Rows[0]["p_num_interior"].ToString();
                txtGiroNegocioPersonaFisica = "";
            }
        }

        #endregion

        #region Comment
        // The first worksheet and W-4 form
        //pdfFormFields.SetField("txtRelacionSolicitantePersonaFisica", txtRelacionSolicitantePersonaFisica);
        //pdfFormFields.SetField("chkRechazadoSi", chkRechazadoSi);
        //pdfFormFields.SetField("txtParentescoDos", txtParentescoDos);
        //pdfFormFields.SetField("txtCodigoCiudadSolicitante", txtCodigoCiudadSolicitante);
        //pdfFormFields.SetField("chkCagoPublicoNoSolicitante", chkCagoPublicoNoSolicitante);
        //pdfFormFields.SetField("txtDuracionUno", txtDuracionUno);
        //pdfFormFields.SetField("chkInsuficienciaRenalNo", chkInsuficienciaRenalNo);
        //pdfFormFields.SetField("chkCorazonSi", chkCorazonSi);
        //pdfFormFields.SetField("chkFinalidadSeguroPatrimonial", chkFinalidadSeguroPatrimonial);
        //pdfFormFields.SetField("txtNoInteriorSolicitante", txtNoInteriorSolicitante);
        //pdfFormFields.SetField("txtPaisLugarNacimientoPersonaFisica", txtPaisLugarNacimientoPersonaFisica);
        //pdfFormFields.SetField("txtEa", txtEa);
        //pdfFormFields.SetField("txtOberservacionesDos", txtOberservacionesDos);
        //pdfFormFields.SetField("txtPlan", txtPlan);
        //pdfFormFields.SetField("txtPolizaUno", txtPolizaUno);
        //pdfFormFields.SetField("txtFolioUno", txtFolioUno);
        //pdfFormFields.SetField("txtFolioTres", txtFolioTres);
        //pdfFormFields.SetField("chkEndocrinasNo", chkEndocrinasNo);
        //pdfFormFields.SetField("txtBeneficiariosNombreCompletoUno", txtBeneficiariosNombreCompletoUno);
        //pdfFormFields.SetField("txtDomicilioCompletoDos", txtDomicilioCompletoDos);
        //pdfFormFields.SetField("txtEspecificacionCompañiaSumaAseguradaMonedaPlan", txtEspecificacionCompañiaSumaAseguradaMonedaPlan);
        //pdfFormFields.SetField("chkMancomunado", chkMancomunado);
        //pdfFormFields.SetField("chkBefSi", chkBefSi);
        //pdfFormFields.SetField("txtEspecifiquePersonaFIsica", txtEspecifiquePersonaFIsica);
        //pdfFormFields.SetField("chkBeneficiarioNo", chkBeneficiarioNo);
        //pdfFormFields.SetField("txtFechaNacimientoUno", txtFechaNacimientoUno);
        //pdfFormFields.SetField("txtTelefonoContratante", txtTelefonoContratante);
        //pdfFormFields.SetField("txtNoInteriorContratante", txtNoInteriorContratante);
        //pdfFormFields.SetField("txtMotivo", txtMotivo);
        //pdfFormFields.SetField("txtFechaNacimientoPersonaFisica", txtFechaNacimientoPersonaFisica);
        //pdfFormFields.SetField("txtFechaConstitucion", txtFechaConstitucion);
        //pdfFormFields.SetField("chkSolicitanteNo", chkSolicitanteNo);
        //pdfFormFields.SetField("chkCerebroVasculadresNo", chkCerebroVasculadresNo);
        //pdfFormFields.SetField("chkCrecimientoGeometrico", chkCrecimientoGeometrico);
        //pdfFormFields.SetField("txtTipoNumeroEmisorIdentidadOficialSolicitante", txtTipoNumeroEmisorIdentidadOficialSolicitante);
        //pdfFormFields.SetField("txtCurpSolicitante", txtCurpSolicitante);
        //pdfFormFields.SetField("txtPadecimientoTres", txtPadecimientoTres);
        //pdfFormFields.SetField("txtOberservacionesTres", txtOberservacionesTres);
        //pdfFormFields.SetField("chkMonedaNacional", chkMonedaNacional);
        //pdfFormFields.SetField("chkFinalidadSeguroCredito", chkFinalidadSeguroCredito);
        //pdfFormFields.SetField("txtCorreoElectronicoPersonaFisica", txtCorreoElectronicoPersonaFisica);
        //pdfFormFields.SetField("txtFolioCinco", txtFolioCinco);
        //pdfFormFields.SetField("txtPaisResidenciaFiscalContratante", txtPaisResidenciaFiscalContratante);
        //pdfFormFields.SetField("txtNombreCompletoApoderadoLegal", txtNombreCompletoApoderadoLegal);
        //pdfFormFields.SetField("chkFormaPagoSemestral", chkFormaPagoSemestral);
        //pdfFormFields.SetField("chkCorazonNo", chkCorazonNo);
        //pdfFormFields.SetField("txtOcupacionProfesionPersonaFisica", txtOcupacionProfesionPersonaFisica);
        //pdfFormFields.SetField("txtNombreFirmaSolicitante", txtNombreFirmaSolicitante);
        //pdfFormFields.SetField("chkAparatoDigestivoSi", chkAparatoDigestivoSi);
        //pdfFormFields.SetField("txtPolizaNueve", txtPolizaNueve);
        //pdfFormFields.SetField("txtOcupacionSolicitante", txtOcupacionSolicitante);
        //pdfFormFields.SetField("txtVigenciaSolicitante", txtVigenciaSolicitante);
        //pdfFormFields.SetField("txtFolioDiez", txtFolioDiez);
        //pdfFormFields.SetField("chkFormaPagoTrimestral", chkFormaPagoTrimestral);
        //pdfFormFields.SetField("txtFolioTrece", txtFolioTrece);
        //pdfFormFields.SetField("txtMoneda", txtMoneda);
        //pdfFormFields.SetField("txtNacionPersFis", txtNacionPersFis);
        //pdfFormFields.SetField("chkAccidenteMac", chkAccidenteMac);
        //pdfFormFields.SetField("chkHipertesionArterialSi", chkHipertesionArterialSi);
        //pdfFormFields.SetField("chkConductoCobroTransferenciaBancaria", chkConductoCobroTransferenciaBancaria);
        //pdfFormFields.SetField("chkFumaNoSolicitante", chkFumaNoSolicitante);
        //pdfFormFields.SetField("txtSumaAseguradaInvalidez", txtSumaAseguradaInvalidez);
        //pdfFormFields.SetField("chkSolicitanteSi", chkSolicitanteSi);
        //pdfFormFields.SetField("txtFolioNueve", txtFolioNueve);
        //pdfFormFields.SetField("chkServiciosFunerariosSI", chkServiciosFunerariosSI);
        //pdfFormFields.SetField("chkSidaNo", chkSidaNo);
        //pdfFormFields.SetField("txtDuracionTres", txtDuracionTres);
        //pdfFormFields.SetField("txtRfcPersonaFisica", txtRfcPersonaFisica);
        //pdfFormFields.SetField("chkConductoCobroEfectivo", chkConductoCobroEfectivo);
        //pdfFormFields.SetField("txtClaveAgente", txtClaveAgente);
        //pdfFormFields.SetField("chkSexoMasculinoSolicitante", chkSexoMasculinoSolicitante);
        //pdfFormFields.SetField("txtRelacionSolicitante", txtRelacionSolicitante);
        //pdfFormFields.SetField("txtPolizaOnce", txtPolizaOnce);
        //pdfFormFields.SetField("chkSangreSi", chkSangreSi);
        //pdfFormFields.SetField("chkCargoFuncionPublicaSi", chkCargoFuncionPublicaSi);
        //pdfFormFields.SetField("chkAccidentePo", chkAccidentePo);
        //pdfFormFields.SetField("chkPsiquiatricasNerviosasNo", chkPsiquiatricasNerviosasNo);
        //pdfFormFields.SetField("txtOrdenesTransferenciaPermanentesContratante", txtOrdenesTransferenciaPermanentesContratante);
        //pdfFormFields.SetField("chkContratanteSi", chkContratanteSi);
        //pdfFormFields.SetField("txtTipoNumeroEmisorIdentificacionOficialPersonaFisica", txtTipoNumeroEmisorIdentificacionOficialPersonaFisica);
        //pdfFormFields.SetField("chkConductoCobroAgente", chkConductoCobroAgente);
        //pdfFormFields.SetField("chkAccidentePoc", chkAccidentePoc);
        //pdfFormFields.SetField("chkFormaPagoUnico", chkFormaPagoUnico);
        //pdfFormFields.SetField("txtFechaNacimientoDos", txtFechaNacimientoDos);
        //pdfFormFields.SetField("txtSumaAseguradaBasica", txtSumaAseguradaBasica);
        //pdfFormFields.SetField("txtIngresoMensualSolicitante", txtIngresoMensualSolicitante);
        //pdfFormFields.SetField("txtComisionAgente", txtComisionAgente);
        //pdfFormFields.SetField("txtFechaNacimientoSolicitante", txtFechaNacimientoSolicitante);
        //pdfFormFields.SetField("chkPulmonaresRespiratoriasNo", chkPulmonaresRespiratoriasNo);
        //pdfFormFields.SetField("chkNivelada", chkNivelada);
        //pdfFormFields.SetField("chkCargoFuncionPublicaNo", chkCargoFuncionPublicaNo);
        //pdfFormFields.SetField("txtPolizaDos", txtPolizaDos);
        //pdfFormFields.SetField("txtPorcentajeDos", txtPorcentajeDos);
        //pdfFormFields.SetField("chkSolicitudSi", chkSolicitudSi);
        //pdfFormFields.SetField("txtCrecimiento", txtCrecimiento);
        //pdfFormFields.SetField("txtFechaInicioTres", txtFechaInicioTres);
        //pdfFormFields.SetField("chkFinalidadSeguroSocios", chkFinalidadSeguroSocios);
        //pdfFormFields.SetField("txtPreguntaUno", txtPreguntaUno);
        //pdfFormFields.SetField("txtOberservacionesUno", txtOberservacionesUno);
        //pdfFormFields.SetField("txtnNumSerieFirmElectr", txtnNumSerieFirmElectr);
        //pdfFormFields.SetField("txtPolizaCinco", txtPolizaCinco);
        //pdfFormFields.SetField("chkEnfermedadesGravesNo", chkEnfermedadesGravesNo);
        //pdfFormFields.SetField("txtGiroTelefonoEmpresaSolicitante", txtGiroTelefonoEmpresaSolicitante);
        //pdfFormFields.SetField("txtColoniaSolicitante", txtColoniaSolicitante);
        //pdfFormFields.SetField("txtEstadoProvinciaContratante", txtEstadoProvinciaContratante);
        //pdfFormFields.SetField("chkConsumoDrogasNo", chkConsumoDrogasNo);
        //pdfFormFields.SetField("txtFechaInicioDos", txtFechaInicioDos);
        //pdfFormFields.SetField("txtMunicipioDelegacionContratante", txtMunicipioDelegacionContratante);
        //pdfFormFields.SetField("txtPolizaDiez", txtPolizaDiez);
        //pdfFormFields.SetField("txtFolioSiete", txtFolioSiete);
        //pdfFormFields.SetField("txtRfcPersonaMoral", txtRfcPersonaMoral);
        //pdfFormFields.SetField("txtTelefonoSolicitante", txtTelefonoSolicitante);
        //pdfFormFields.SetField("txtFolioDoce", txtFolioDoce);
        //pdfFormFields.SetField("chkAccidenteMapoc", chkAccidenteMapoc);
        //pdfFormFields.SetField("txtPolizaCuatro", txtPolizaCuatro);
        //pdfFormFields.SetField("txtPaisRecidenciaFiscalSolicitante", txtPaisRecidenciaFiscalSolicitante);
        //pdfFormFields.SetField("txtPeso", txtPeso);
        //pdfFormFields.SetField("txtNacionalidadesSolicitante", txtNacionalidadesSolicitante);
        //pdfFormFields.SetField("txtFolioMercantil", txtFolioMercantil);
        //pdfFormFields.SetField("txtNombreFirmaContratante", txtNombreFirmaContratante);
        //pdfFormFields.SetField("chkCirrosisHeptitisNo", chkCirrosisHeptitisNo);
        //pdfFormFields.SetField("txtPolizaSeis", txtPolizaSeis);
        //pdfFormFields.SetField("chkCrebroVasculadresSI", chkCrebroVasculadresSI);
        //pdfFormFields.SetField("txtPorcentajeUno", txtPorcentajeUno);
        //pdfFormFields.SetField("txtCanFumaSol", txtCanFumaSol);
        //pdfFormFields.SetField("txtCalleSolicitante", txtCalleSolicitante);
        //pdfFormFields.SetField("txtNombrePaternoMaternoSolicitante", txtNombrePaternoMaternoSolicitante);
        //pdfFormFields.SetField("txtVigenciaPersonaFisica", txtVigenciaPersonaFisica);
        //pdfFormFields.SetField("txtEstadoProvinciaSolicitante", txtEstadoProvinciaSolicitante);
        //pdfFormFields.SetField("txtPadecimientoUno", txtPadecimientoUno);
        //pdfFormFields.SetField("chkBipa", chkBipa);
        //pdfFormFields.SetField("chkEnfermedadMencionadaNo", chkEnfermedadMencionadaNo);
        //pdfFormFields.SetField("chkDecreciente", chkDecreciente);
        //pdfFormFields.SetField("txtDomicilioCompletoTres", txtDomicilioCompletoTres);
        //pdfFormFields.SetField("chkBita", chkBita);
        //pdfFormFields.SetField("chkFumaSiSolicitante", chkFumaSiSolicitante);
        //pdfFormFields.SetField("txtNombreAgente", txtNombreAgente);
        //pdfFormFields.SetField("txtPolizaSiete", txtPolizaSiete);
        //pdfFormFields.SetField("txtCpPoboxSolicitante", txtCpPoboxSolicitante);
        //pdfFormFields.SetField("txtNumeroSerieFIrmaElectronicaAvanzadaPersonaFisica", txtNumeroSerieFIrmaElectronicaAvanzadaPersonaFisica);
        //pdfFormFields.SetField("txtMunicipioDelegacionSolicitante", txtMunicipioDelegacionSolicitante);
        //pdfFormFields.SetField("chkFormaPagoMensual", chkFormaPagoMensual);
        //pdfFormFields.SetField("txtNoExteriorContratante", txtNoExteriorContratante);
        //pdfFormFields.SetField("chkAccidenteMa", chkAccidenteMa);
        //pdfFormFields.SetField("txtDomicilioCompletoUno", txtDomicilioCompletoUno);
        //pdfFormFields.SetField("chkServiciosFunerariosNo", chkServiciosFunerariosNo);
        //pdfFormFields.SetField("txtCualDeporte", txtCualDeporte);
        //pdfFormFields.SetField("chkBeneficiarioSi", chkBeneficiarioSi);
        //pdfFormFields.SetField("txtNombrePaternoMaternoPersonaFisica", txtNombrePaternoMaternoPersonaFisica);
        //pdfFormFields.SetField("txtEstadoActualUno", txtEstadoActualUno);
        //pdfFormFields.SetField("txtFolioSeis", txtFolioSeis);
        //pdfFormFields.SetField("chkFinalidadSeguroRetiro", chkFinalidadSeguroRetiro);
        //pdfFormFields.SetField("txtPreguntaTres", txtPreguntaTres);
        //pdfFormFields.SetField("txtGiroNegocioPersonaFisica", txtGiroNegocioPersonaFisica);
        //pdfFormFields.SetField("txtCiudadPoblacionContratente", txtCiudadPoblacionContratente);
        //pdfFormFields.SetField("chkBefNO", chkBefNO);
        //pdfFormFields.SetField("txtParentescoUno", txtParentescoUno);
        //pdfFormFields.SetField("txtEstadoActualTres", txtEstadoActualTres);
        //pdfFormFields.SetField("txtEstadoCivilSolicitante", txtEstadoCivilSolicitante);
        //pdfFormFields.SetField("txtBeneficiariosNombreCompletoTres", txtBeneficiariosNombreCompletoTres);
        //pdfFormFields.SetField("txtFolioOcho", txtFolioOcho);
        //pdfFormFields.SetField("txtFechaNacimientoTres", txtFechaNacimientoTres);
        //pdfFormFields.SetField("txtCiudadPoblacionSolicitante", txtCiudadPoblacionSolicitante);
        //pdfFormFields.SetField("txtMedioEntrega", txtMedioEntrega);
        //pdfFormFields.SetField("chkartritisNo", chkartritisNo);
        //pdfFormFields.SetField("chkFinalidadSeguroHombreClave", chkFinalidadSeguroHombreClave);
        //pdfFormFields.SetField("txtBeneficiariosNombreCompletoDos", txtBeneficiariosNombreCompletoDos);
        //pdfFormFields.SetField("txtPaisLugarNacimientoSolicitante", txtPaisLugarNacimientoSolicitante);
        //pdfFormFields.SetField("chkFinalidadSeguroEducacion", chkFinalidadSeguroEducacion);
        //pdfFormFields.SetField("txtNacionalidadApoderado", txtNacionalidadApoderado);
        //pdfFormFields.SetField("txtFirmaAgente", txtFirmaAgente);
        //pdfFormFields.SetField("chkPulmonaresRespiratoriasSi", chkPulmonaresRespiratoriasSi);
        //pdfFormFields.SetField("chkEndocrinasSI", chkEndocrinasSI);
        //pdfFormFields.SetField("txtColoniaContratente", txtColoniaContratente);
        //pdfFormFields.SetField("txtCalleContratente", txtCalleContratente);
        //pdfFormFields.SetField("chkFormaPagoQuincenal", chkFormaPagoQuincenal);
        //pdfFormFields.SetField("chkSexoFemeninoSolicitante", chkSexoFemeninoSolicitante);
        //pdfFormFields.SetField("txtFolioOnce", txtFolioOnce);
        //pdfFormFields.SetField("txtPlazo", txtPlazo);
        //pdfFormFields.SetField("txtCorreoElectronicoSolicitante", txtCorreoElectronicoSolicitante);
        //pdfFormFields.SetField("txtCurpPersonaFIsica", txtCurpPersonaFIsica);
        //pdfFormFields.SetField("txtClavePaisContratante", txtClavePaisContratante);
        //pdfFormFields.SetField("txtPolizaOcho", txtPolizaOcho);
        //pdfFormFields.SetField("txtClavePaisSolicitante", txtClavePaisSolicitante);
        //pdfFormFields.SetField("chkMonedaDolares", chkMonedaDolares);
        //pdfFormFields.SetField("chkCrecimientoConstante", chkCrecimientoConstante);
        //pdfFormFields.SetField("txtSumaAseguradaPlanSuperacionPlus", txtSumaAseguradaPlanSuperacionPlus);
        //pdfFormFields.SetField("txtEspecifiqueSolicitante", txtEspecifiqueSolicitante);
        //pdfFormFields.SetField("chkPsiquiatricasNerviosasSi", chkPsiquiatricasNerviosasSi);
        //pdfFormFields.SetField("txtCorreoElectrPagWeb", txtCorreoElectrPagWeb);
        //pdfFormFields.SetField("chkRechazadoNo", chkRechazadoNo);
        //pdfFormFields.SetField("chkDeportePeligrosoNo", chkDeportePeligrosoNo);
        //pdfFormFields.SetField("txtSumaAseguradaAccidente", txtSumaAseguradaAccidente);
        //pdfFormFields.SetField("txtEspecificarCargoSolicitante", txtEspecificarCargoSolicitante);
        //pdfFormFields.SetField("txtCodigoPaisContratante", txtCodigoPaisContratante);
        //pdfFormFields.SetField("chkSangreNo", chkSangreNo);
        //pdfFormFields.SetField("txtCpPoboxContratante", txtCpPoboxContratante);
        //pdfFormFields.SetField("chkTemporalIndividual", chkTemporalIndividual);
        //pdfFormFields.SetField("chkMonedaUdis", chkMonedaUdis);
        //pdfFormFields.SetField("txtFolioCuatro", txtFolioCuatro);
        //pdfFormFields.SetField("txtNumeroSerieFimaElectronicaAvanzadaSolicitante", txtNumeroSerieFimaElectronicaAvanzadaSolicitante);
        //pdfFormFields.SetField("txtPolizaDoce", txtPolizaDoce);
        //pdfFormFields.SetField("chkHipertensionArterialNo", chkHipertensionArterialNo);
        //pdfFormFields.SetField("txtTinNifEquivalenteSolicitante", txtTinNifEquivalenteSolicitante);
        //pdfFormFields.SetField("chkAparatoDigestivoNo", chkAparatoDigestivoNo);
        //pdfFormFields.SetField("txtTinNifPersonaFisica", txtTinNifPersonaFisica);
        //pdfFormFields.SetField("chkInsuficienciaRenalSi", chkInsuficienciaRenalSi);
        //pdfFormFields.SetField("chkDeportePeligrosoSi", chkDeportePeligrosoSi);
        //pdfFormFields.SetField("txtDomicApoderadoLegal", txtDomicApoderadoLegal);
        //pdfFormFields.SetField("txtrazonSocial", txtrazonSocial);
        //pdfFormFields.SetField("chkSidaSI", chkSidaSI);
        //pdfFormFields.SetField("chkCargoPublicoSiSolicitante", chkCargoPublicoSiSolicitante);
        //pdfFormFields.SetField("txtPolizaTrece", txtPolizaTrece);
        //pdfFormFields.SetField("txtParentescoTres", txtParentescoTres);
        //pdfFormFields.SetField("chkEnfermedadesGravesSi", chkEnfermedadesGravesSi);
        //pdfFormFields.SetField("txtFolioDos", txtFolioDos);
        //pdfFormFields.SetField("chkBit", chkBit);
        //pdfFormFields.SetField("chkConsumoDrogasSI", chkConsumoDrogasSI);
        //pdfFormFields.SetField("txtRfcSolicitante", txtRfcSolicitante);
        //pdfFormFields.SetField("txtEstatura", txtEstatura);
        //pdfFormFields.SetField("txtPaisContratante", txtPaisContratante);
        //pdfFormFields.SetField("chkFormaPagoSemanal", chkFormaPagoSemanal);
        //pdfFormFields.SetField("txtDuracionDos", txtDuracionDos);
        //pdfFormFields.SetField("txtNoExteriorSolicitante", txtNoExteriorSolicitante);
        //pdfFormFields.SetField("chkFormaPagoContado", chkFormaPagoContado);
        //pdfFormFields.SetField("chkCrecimientoLineal", chkCrecimientoLineal);
        //pdfFormFields.SetField("txtEspecifiqueCargoPersonaFisica", txtEspecifiqueCargoPersonaFisica);
        //pdfFormFields.SetField("chkArtritisSI", chkArtritisSI);
        //pdfFormFields.SetField("txtGiroMercantilObjSocial", txtGiroMercantilObjSocial);
        //pdfFormFields.SetField("chkCirrosisHeptitisSi", chkCirrosisHeptitisSi);
        //pdfFormFields.SetField("txtPolizaTres", txtPolizaTres);
        //pdfFormFields.SetField("chkEnfermedadMencionadaSi", chkEnfermedadMencionadaSi);
        //pdfFormFields.SetField("chkPasi", chkPasi);
        //pdfFormFields.SetField("txtPadecimientoDos", txtPadecimientoDos);
        //pdfFormFields.SetField("txtPreguntaDos", txtPreguntaDos);
        //pdfFormFields.SetField("txtEmpresaPrestaServicioSolicitante", txtEmpresaPrestaServicioSolicitante);
        //pdfFormFields.SetField("chkConductoCobroDomiciliado", chkConductoCobroDomiciliado);
        //pdfFormFields.SetField("txtNacionalidad", txtNacionalidad);
        //pdfFormFields.SetField("txtFechaInicioUno", txtFechaInicioUno);
        //pdfFormFields.SetField("chkSolicitudNo", chkSolicitudNo);
        //pdfFormFields.SetField("txtEstadoActualDos", txtEstadoActualDos);
        //pdfFormFields.SetField("chkContratanteNo", chkContratanteNo);
        //pdfFormFields.SetField("chkAccidenteMapo", chkAccidenteMapo);
        //pdfFormFields.SetField("txtPorcentajeTres", txtPorcentajeTres);
        //pdfFormFields.SetField("txtSolLugaryFecha", txtSolLugaryFecha);
        #endregion
        //GenerarXML
        XElement ROOT = new XElement("ROOT");
        ROOT.Add(new XElement("COMPANIA", "1"));
        ROOT.Add(new XElement("RAMO", "100"));
        ROOT.Add(new XElement("ACTIVIDAD", "EMISION"));
        ROOT.Add(new XElement("IDIOMA", "mx_ES"));

        #region DISTRIBUCION
        XElement DISTRIBUCION = new XElement("DISTRIBUCION");

        DISTRIBUCION.Add(new XElement("DUPLEX_MODE", "FALSE"));
        DISTRIBUCION.Add(new XElement("LOCAL", "TRUE"));

        #region WEB
        XElement WEB = new XElement("WEB");

        WEB.Add(new XElement("WEB_EMAIL_TO", ""));
        WEB.Add(new XElement("WEB_EMAIL_FROM", "servicioDocumental@mapfre.com.mx"));
        WEB.Add(new XElement("WEB_EMAIL_REPLY_TO"));
        WEB.Add(new XElement("WEB_EMAIL_ASUNTO", nomFile + "- MX"));
        WEB.Add(new XElement("WEB_EMAIL_CC"));
        WEB.Add(new XElement("WEB_EMAIL_BCC"));


        DISTRIBUCION.Add(WEB);

        #endregion WEBL

        #region EMAIL
        XElement EMAIL = new XElement("EMAIL");

        EMAIL.Add(new XElement("EMAIL_TO", ""));
        EMAIL.Add(new XElement("EMAIL_FROM", "servicioDocumental@mapfre.com.mx"));
        EMAIL.Add(new XElement("EMAIL_REPLY_TO"));
        EMAIL.Add(new XElement("EMAIL_ASUNTO", nomFile + "- MX"));
        EMAIL.Add(new XElement("EMAIL_CC"));
        EMAIL.Add(new XElement("EMAIL_BCC"));


        DISTRIBUCION.Add(EMAIL);
        #endregion EMAIL

        #region GESTOR_DOCUMENTAL
        XElement GESTOR_DOC = new XElement("GESTOR_DOCUMENTAL");

        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_SFILENAME", nomFile + ".pdf"));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_FOLDER", "/MAPFRE/EMISION/Vida/"));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_OBJETO", "mmx_solicitud"));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_CODCIA", "1"));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_NUMPOLIZA", nomFile));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_NUMSUPLEMENTO"));
        //GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_NUMFOLIO", ""));

        DISTRIBUCION.Add(GESTOR_DOC);

        #endregion GESTOR_DOCUMENTAL

        ROOT.Add(DISTRIBUCION);

        #endregion DISTRIBUCION

        #region SOLICITUD
        XElement SOLICITUD = new XElement("SOLICITUD");
        #region CABECERA


        XElement CABECERA = new XElement("CABECERA");

        CABECERA.Add(new XElement("IMAGEN", "LOGO_MAPFRE_FONDO_BLANCO.jpg"));
        CABECERA.Add(new XElement("DOMICILIO", "SV_DOMICILIO_SOLICITUD.rtf"));
        CABECERA.Add(new XElement("NOMBRE_DOCUMENTO", "SOLICITUD UNICA VIDA INDIVIDUAL."));
        CABECERA.Add(new XElement("LEYENDA_UNO_ENCABEZADO", "EV_SUMA_ASEGURADA_ENCABEZADO.rtf"));
        CABECERA.Add(new XElement("NUMERO_FOLIO", ""));
        CABECERA.Add(new XElement("NUMERO_POLIZA", ""));
        CABECERA.Add(new XElement("LEYENDA_DOS_ENCABEZADO", "EV_LLENADO_SOLICITUD.rtf"));

        SOLICITUD.Add(CABECERA);

        #endregion CABECERA

        #region INFORMACION_CONTRATANTE

        XElement INFORMACION_CONTRATANTE = new XElement("INFORMACION_CONTRATANTE");


        XElement PERSONA_MORAL = new XElement("PERSONA_MORAL");
        PERSONA_MORAL.Add(new XElement("TITULO", "DATOS DEL CONTRATANTE PERSONA MORAL"));
        PERSONA_MORAL.Add(new XElement("RAZON_SOCIAL", txtrazonSocial));
        PERSONA_MORAL.Add(new XElement("NACIONALIDAD", txtNacionalidad));
        PERSONA_MORAL.Add(new XElement("RFC", txtRfcPersonaMoral));
        PERSONA_MORAL.Add(new XElement("RELACION_SOLICITANTE", txtRelacionSolicitante));
        PERSONA_MORAL.Add(new XElement("NUMERO_SERIE_FEA", txtnNumSerieFirmElectr));
        PERSONA_MORAL.Add(new XElement("CORREO_ELECTRONICO", txtCorreoElectrPagWeb));
        PERSONA_MORAL.Add(new XElement("GIRO_MERCANTIL", txtGiroMercantilObjSocial));
        PERSONA_MORAL.Add(new XElement("FOLIO_MERCANTIL", txtFolioMercantil));
        PERSONA_MORAL.Add(new XElement("FECHA_DE_CONSTITUCION", txtFechaConstitucion));
        PERSONA_MORAL.Add(new XElement("NOMBRE_APODERADO_LEGAL", txtNombreCompletoApoderadoLegal));
        PERSONA_MORAL.Add(new XElement("NACIONALIDAD_APODERADO_LEGAL", txtNacionalidadApoderado));
        PERSONA_MORAL.Add(new XElement("DOMICILIO_APODERADO_LEGAL", txtDomicApoderadoLegal));

        INFORMACION_CONTRATANTE.Add(PERSONA_MORAL);

        XElement PERSONA_FISICA = new XElement("PERSONA_FISICA");
        PERSONA_FISICA.Add(new XElement("TITULO", "DATOS DEL CONTRATANTE PERSONA FISICA"));
        PERSONA_FISICA.Add(new XElement("NOMBRE", txtNombrePaternoMaternoPersonaFisica));
        PERSONA_FISICA.Add(new XElement("NACIONALIDAD", txtNacionPersFis));
        PERSONA_FISICA.Add(new XElement("FECHA_DE_NACIMIENTO", txtFechaNacimientoPersonaFisica));
        PERSONA_FISICA.Add(new XElement("PAIS_Y_LUGAR_DE_NACIMIENTO", txtPaisLugarNacimientoPersonaFisica));
        PERSONA_FISICA.Add(new XElement("RFC", txtRfcPersonaFisica));
        PERSONA_FISICA.Add(new XElement("CURP", txtCurpPersonaFIsica));
        PERSONA_FISICA.Add(new XElement("TIN1_NIF", txtTinNifPersonaFisica));
        PERSONA_FISICA.Add(new XElement("RELACION_SOLICITANTE", txtRelacionSolicitantePersonaFisica));
        PERSONA_FISICA.Add(new XElement("TIP_NUM_EMI_IDENTIFICACION_OFICIAL", txtTipoNumeroEmisorIdentificacionOficialPersonaFisica));
        PERSONA_FISICA.Add(new XElement("VIGENCIA", txtVigenciaPersonaFisica));
        PERSONA_FISICA.Add(new XElement("OCUPACION_PROFESION", txtOcupacionProfesionPersonaFisica));
        PERSONA_FISICA.Add(new XElement("GIRO_NEGOCIO", txtGiroNegocioPersonaFisica));
        PERSONA_FISICA.Add(new XElement("ESPECIFIQUE", txtEspecifiquePersonaFIsica));
        PERSONA_FISICA.Add(new XElement("NUMERO_SERIE_FEA", txtNumeroSerieFIrmaElectronicaAvanzadaPersonaFisica));
        PERSONA_FISICA.Add(new XElement("CORREO_ELECTRONICO", txtCorreoElectronicoPersonaFisica));

        string chkFP = "FALSE";
        if (Request.Form["chkCargoFuncionPublicaSi"] == "Yes")
        {
            chkFP = "TRUE";
        }

        PERSONA_FISICA.Add(new XElement("OCUPA_CARGO_PUBLICO", chkFP));
        PERSONA_FISICA.Add(new XElement("ESPECIFIQUE_CARGO_PUBLICO", txtEspecifiqueCargoPersonaFisica));

        INFORMACION_CONTRATANTE.Add(PERSONA_FISICA);

        string chkBenef = "FALSE";
        if (Request.Form["chkBeneficiarioSi"] == "Yes")
        {
            chkBenef = "TRUE";
        }
        string chkSolici = "FALSE";
        if (Request.Form["chkSolicitanteSi"] == "Yes")
        {
            chkSolici = "TRUE";
        }
        string chkContra = "FALSE";
        if (Request.Form["chkContratanteSi"] == "Yes")
        {
            chkContra = "TRUE";
        }

        XElement DOMICILIO_FISCAL = new XElement("DOMICILIO_FISCAL");
        DOMICILIO_FISCAL.Add(new XElement("TITULO", "DOMICILIO FISCAL DEL CONTRATANTE(persona fisica o moral si no cuenta con el, indique el domicilio particular"));
        DOMICILIO_FISCAL.Add(new XElement("CALLE", txtCalleContratente));
        DOMICILIO_FISCAL.Add(new XElement("NUM_EXTERIOR", txtNoExteriorContratante));
        DOMICILIO_FISCAL.Add(new XElement("NUM_INTERIOR", txtNoInteriorContratante));
        DOMICILIO_FISCAL.Add(new XElement("COLONIA", txtColoniaContratente));
        DOMICILIO_FISCAL.Add(new XElement("MUNICIPIO_O_DELEGACION", txtMunicipioDelegacionContratante));
        DOMICILIO_FISCAL.Add(new XElement("CIUDAD_O_POBLACION", txtCiudadPoblacionContratente));
        DOMICILIO_FISCAL.Add(new XElement("ESTADO_O_PROVINCIA", txtEstadoProvinciaContratante));
        DOMICILIO_FISCAL.Add(new XElement("PAIS", txtPaisContratante));
        DOMICILIO_FISCAL.Add(new XElement("CP_O_POBOX", txtCpPoboxContratante));
        DOMICILIO_FISCAL.Add(new XElement("TELEFONO", txtTelefonoContratante));
        DOMICILIO_FISCAL.Add(new XElement("CLAVE_DE_PAIS", txtClavePaisContratante));
        DOMICILIO_FISCAL.Add(new XElement("CODIGO_DE_CIUDAD", txtCodigoCiudadSolicitante));
        DOMICILIO_FISCAL.Add(new XElement("PAIS_RESIDENCIA_FISCAL", txtPaisResidenciaFiscalContratante));
        DOMICILIO_FISCAL.Add(new XElement("ORDENES_TRANSFERENCIA", txtOrdenesTransferenciaPermanentesContratante));
        DOMICILIO_FISCAL.Add(new XElement("LEYENDA_UNO_FATCA", "EV_LEYENDA_UNO_FATCA.rtf"));
        DOMICILIO_FISCAL.Add(new XElement("FATCA_CONTRATANTE", chkContra));
        DOMICILIO_FISCAL.Add(new XElement("FATCA_SOLICITANTE", chkSolici));
        DOMICILIO_FISCAL.Add(new XElement("FATCA_BENEFICIARIOS", chkBenef));
        DOMICILIO_FISCAL.Add(new XElement("LEYENDA_DOS_FATCA", "EV_LEYENDA_DOS_FATCA.rtf"));


        INFORMACION_CONTRATANTE.Add(DOMICILIO_FISCAL);

        SOLICITUD.Add(INFORMACION_CONTRATANTE);

        #endregion  INFORMACION_CONTRATANTE

        #region INFORMACION_SOLICITANTE

        XElement INFORMACION_SOLICITANTE = new XElement("INFORMACION_SOLICITANTE");

        INFORMACION_SOLICITANTE.Add(new XElement("TITULO", "DATOS DEL SOLICITANTE"));

        XElement PERSONA_FISICA_SOL = new XElement("PERSONA_FISICA");

        PERSONA_FISICA_SOL.Add(new XElement("NOMBRE", txtNombrePaternoMaternoSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("NACIONALIDAD", txtNacionalidadesSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("FECHA_DE_NACIMIENTO", txtFechaNacimientoSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("PAIS_Y_LUGAR_DE_NACIMIENTO", txtPaisLugarNacimientoSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("RFC", txtRfcSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("CURP", txtCurpSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("TIN1_NIF", txtTinNifEquivalenteSolicitante));
        //2506
        PERSONA_FISICA_SOL.Add(new XElement("ESTADO_CIVIL", txtEstadoCivilSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("OCUPACION_PROFESION", txtOcupacionSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("ESPECIFIQUE", txtEspecifiqueSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("INGRESO_MENSUAL", txtIngresoMensualSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("EMPRESA_DONDE_PRESTA_SERIVICIOS", txtEmpresaPrestaServicioSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("GIRO_TELEFONO_EMPRESA", txtGiroTelefonoEmpresaSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("TIP_NUM_EMI_IDENTIFICACION_OFICIAL", txtTipoNumeroEmisorIdentidadOficialSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("VIGENCIA", txtVigenciaSolicitante));

        string chkSexo = "FEMENINO";
        if (Request.Form["chkSexoMasculinoSolicitante"] == "Yes")
        {
            chkSexo = "MASCULINO";
        }

        PERSONA_FISICA_SOL.Add(new XElement("SEXO", chkSexo));


        string chkFuma = "FALSE";
        if (Request.Form["chkFumaSiSolicitante"] == "Yes")
        {
            chkFuma = "TRUE";
        }
        PERSONA_FISICA_SOL.Add(new XElement("FUMA", chkFuma));
        PERSONA_FISICA_SOL.Add(new XElement("CANTIDAD", txtCanFumaSol));
        PERSONA_FISICA_SOL.Add(new XElement("NUMERO_SERIE_FEA", txtNumeroSerieFimaElectronicaAvanzadaSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("CORREO_ELECTRONICO", txtCorreoElectronicoSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("CALLE", txtCalleSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("NUM_EXTERIOR", txtNoExteriorSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("NUM_INTERIOR", txtNoInteriorSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("COLONIA", txtColoniaSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("MUNICIPIO_O_DELEGACION", txtMunicipioDelegacionSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("CIUDAD_O_POBLACION", txtCiudadPoblacionSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("ESTADO_O_PROVINCIA", txtEstadoProvinciaSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("PAIS", txtPaisRecidenciaFiscalSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("CP_O_POBOX", txtCpPoboxSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("TELEFONO", txtTelefonoSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("CLAVE_DE_PAIS", txtClavePaisSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("CODIGO_DE_CIUDAD", txtCodigoCiudadSolicitante));

        string chkCargoS = "FALSE";
        if (Request.Form["chkCargoPublicoSiSolicitante"] == "Yes")
        {
            chkCargoS = "TRUE";
        }

        PERSONA_FISICA_SOL.Add(new XElement("OCUPA_CARGO_PUBLICO", chkCargoS));
        PERSONA_FISICA_SOL.Add(new XElement("ESPECIFIQUE_CARGO_PUBLICO", txtEspecificarCargoSolicitante));
        PERSONA_FISICA_SOL.Add(new XElement("LEYENDA_UNO_SOLICITANTE", "EV_REFERENCIAS_SOLICITANTE.rtf"));

        INFORMACION_SOLICITANTE.Add(PERSONA_FISICA_SOL);

        SOLICITUD.Add(INFORMACION_SOLICITANTE);

        #endregion INFORMACION_SOLICITANTE

        #region INFORMACION_COBRANZA

        XElement INFORMACION_COBRANZA = new XElement("INFORMACION_COBRANZA");

        INFORMACION_COBRANZA.Add(new XElement("TITULO", "COBRANZA"));


        XElement FORMA_DE_PAGO = new XElement("FORMA_DE_PAGO");

        string chkFPC = "FALSE";
        if (Request.Form["chkFormaPagoContado"] == "Yes")
        {
            chkFPC = "TRUE";
        }
        string chkFPSE = "FALSE";
        if (Request.Form["chkFormaPagoSemestral"] == "Yes")
        {
            chkFPSE = "TRUE";
        }
        string chkFPTRI = "FALSE";
        if (Request.Form["chkFormaPagoTrimestral"] == "Yes")
        {
            chkFPTRI = "TRUE";
        }

        string chkFPME = "FALSE";
        if (Request.Form["chkFormaPagoMensual"] == "Yes")
        {
            chkFPME = "TRUE";
        }

        string chkFPQ = "FALSE";
        if (Request.Form["chkFormaPagoQuincenal"] == "Yes")
        {
            chkFPQ = "TRUE";
        }

        string chkFPU = "FALSE";
        if (Request.Form["chkFormaPagoUnico"] == "Yes")
        {
            chkFPU = "TRUE";
        }

        string chkFPMO = "FALSE";
        if (Request.Form["chkFormaPagoSemanal"] == "Yes")
        {
            chkFPMO = "TRUE";
        }


        FORMA_DE_PAGO.Add(new XElement("CONTADO", chkFPC));
        FORMA_DE_PAGO.Add(new XElement("SEMESTRAL", chkFPSE));
        FORMA_DE_PAGO.Add(new XElement("TRIMESTRAL", chkFPTRI));
        FORMA_DE_PAGO.Add(new XElement("MENSUAL", chkFPME));
        FORMA_DE_PAGO.Add(new XElement("UNICO", chkFPU));
        FORMA_DE_PAGO.Add(new XElement("QUINCENAL", chkFPQ));
        FORMA_DE_PAGO.Add(new XElement("SEMANAL", chkFPMO));


        INFORMACION_COBRANZA.Add(FORMA_DE_PAGO);


        XElement CONDUCTO_DE_COBRO = new XElement("CONDUCTO_DE_COBRO");

        string chkCCA = "FALSE";
        if (Request.Form["chkConductoCobroAgente"] == "Yes")
        {
            chkCCA = "TRUE";
        }

        string chkCCE = "FALSE";
        if (Request.Form["chkConductoCobroEfectivo"] == "Yes")
        {
            chkCCE = "TRUE";
        }
        string chkCCTB = "FALSE";
        if (Request.Form["chkConductoCobroTransferenciaBancaria"] == "Yes")
        {
            chkCCTB = "TRUE";
        }
        string chkCCDO = "FALSE";
        if (Request.Form["chkConductoCobroDomiciliado"] == "Yes")
        {
            chkCCDO = "TRUE";
        }

        CONDUCTO_DE_COBRO.Add(new XElement("AGENTE", chkCCA));
        CONDUCTO_DE_COBRO.Add(new XElement("EFECTIVO", chkCCE));
        CONDUCTO_DE_COBRO.Add(new XElement("TRANSFERENCIA_BANCARIA", chkCCTB));
        CONDUCTO_DE_COBRO.Add(new XElement("DOMICILIADO", chkCCDO));

        INFORMACION_COBRANZA.Add(CONDUCTO_DE_COBRO);

        INFORMACION_COBRANZA.Add(new XElement("LEYENDA_UNO_COBRANZA", "EV_REFERENCIAS_FORMA_PAGO.rtf"));

        SOLICITUD.Add(INFORMACION_COBRANZA);

        #endregion INFORMACION_COBRANZA

        #region TIPO_PLAN_COBERTURAS

        XElement TIPO_PLAN_COBERTURAS = new XElement("TIPO_PLAN_COBERTURAS");

        TIPO_PLAN_COBERTURAS.Add(new XElement("TITULO", "TITULO DE PLAN Y COBERTURAS"));
        #region INFORMACION_PLAN
        XElement INFORMACION_PLAN = new XElement("INFORMACION_PLAN");

        INFORMACION_PLAN.Add(new XElement("PLAN", txtPlan));
        INFORMACION_PLAN.Add(new XElement("PLAZO", txtPlazo));
        INFORMACION_PLAN.Add(new XElement("EA", txtEa));
        INFORMACION_PLAN.Add(new XElement("MONEDA", txtMoneda));

        XElement TIPO_MONEDA = new XElement("TIPO_MONEDA");

        string chkTMN = "FALSE";
        if (Request.Form["chkMonedaNacional"] == "Yes")
        {
            chkTMN = "TRUE";
        }
        string chkTMDO = "FALSE";
        if (Request.Form["chkMonedaDolares"] == "Yes")
        {
            chkTMDO = "TRUE";
        }
        string chkTPU = "FALSE";
        if (Request.Form["chkMonedaUdis"] == "Yes")
        {
            chkTPU = "TRUE";
        }

        TIPO_MONEDA.Add(new XElement("NACIONAL", chkTMN));
        TIPO_MONEDA.Add(new XElement("DOLARES", chkTMDO));
        TIPO_MONEDA.Add(new XElement("UDIS", chkTPU));

        INFORMACION_PLAN.Add(TIPO_MONEDA);

        XElement TIPO_CRECIMIENTO = new XElement("TIPO_CRECIMIENTO");

        string chkTCC = "FALSE";
        if (Request.Form["chkCrecimientoConstante"] == "Yes")
        {
            chkTCC = "TRUE";
        }
        string chkTCL = "FALSE";
        if (Request.Form["chkCrecimientoLineal"] == "Yes")
        {
            chkTCL = "TRUE";
        }
        string chkTCG = "FALSE";
        if (Request.Form["chkCrecimientoGeometrico"] == "Yes")
        {
            chkTCG = "TRUE";
        }
        TIPO_CRECIMIENTO.Add(new XElement("CONSTANTE", chkTCC));
        TIPO_CRECIMIENTO.Add(new XElement("LINEAL_10", chkTCL));
        TIPO_CRECIMIENTO.Add(new XElement("GEOMETRICO_5", chkTCG));

        INFORMACION_PLAN.Add(TIPO_CRECIMIENTO);

        TIPO_PLAN_COBERTURAS.Add(INFORMACION_PLAN);

        #endregion INFORMACION_PLAN



        #region COBERTURAS

        XElement COBERTURAS = new XElement("COBERTURAS");

        #region COBERTURA



        var valorSMBa = "";
        if (txtSumaAseguradaBasica == "")
        {
            valorSMBa = txtSumaAseguradaBasica;
        }
        else
        {
            var valorBasico = Convert.ToDouble(txtSumaAseguradaBasica);
            valorSMBa = string.Format(new CultureInfo("es-MX"), "{0:c}", valorBasico);
        }


        XElement COBERTURA1 = new XElement("COBERTURA");
        COBERTURA1.Add(new XElement("NOMBRE_COB", "BASICA"));
        COBERTURA1.Add(new XElement("SUMA_ASEGURADA_COB", string.Format(new CultureInfo("es-MX"), "{0:c}", valorSMBa)));
        COBERTURAS.Add(COBERTURA1);

        string chkMA = "FALSE";
        if (Request.Form["chkAccidenteMa"] == "Yes")
        {
            chkMA = "TRUE";
        }
        string chkMAC = "FALSE";
        if (Request.Form["chkAccidenteMac"] == "Yes")
        {
            chkMAC = "TRUE";
        }
        string chkPO = "FALSE";
        if (Request.Form["chkAccidentePo"] == "Yes")
        {
            chkPO = "TRUE";
        }
        string chkPOC = "FALSE";
        if (Request.Form["chkAccidentePoc"] == "Yes")
        {
            chkPOC = "TRUE";
        }
        string chkMAPO = "FALSE";
        if (Request.Form["chkAccidenteMapo"] == "Yes")
        {
            chkMAPO = "TRUE";
        }
        string chkMAPOC = "FALSE";
        if (Request.Form["chkAccidenteMapoc"] == "Yes")
        {
            chkMAPOC = "TRUE";
        }


        var valor = "";
        if (txtSumaAseguradaAccidente == "")
        {
            valor = txtSumaAseguradaAccidente;
        }
        else
        {
            var valorAccidente = Convert.ToDouble(txtSumaAseguradaAccidente);
            valor = string.Format(new CultureInfo("es-MX"), "{0:c}", valorAccidente);
        }


        XElement COBERTURA2 = new XElement("COBERTURA");
        COBERTURA2.Add(new XElement("NOMBRE_COB", "ACCIDENTE"));
        XElement TIPOS_COBERTURA = new XElement("TIPOS_COBERTURA");
        TIPOS_COBERTURA.Add(new XElement("MA", chkMA));
        TIPOS_COBERTURA.Add(new XElement("MAC", chkMAC));
        TIPOS_COBERTURA.Add(new XElement("PO", chkPO));
        TIPOS_COBERTURA.Add(new XElement("POC", chkPOC));
        TIPOS_COBERTURA.Add(new XElement("MAPO", chkMAPO));
        TIPOS_COBERTURA.Add(new XElement("MAPOC", chkMAPOC));
        COBERTURA2.Add(TIPOS_COBERTURA);
        COBERTURA2.Add(new XElement("SUMA_ASEGURADA_COB", valor));
        COBERTURAS.Add(COBERTURA2);

        XElement COBERTURA3 = new XElement("COBERTURA");
        COBERTURA3.Add(new XElement("NOMBRE_COB", "INVALIDEZ TOTAL Y PERMANENTE"));

        string chkTBipa = "FALSE";
        if (Request.Form["chkBipa"] == "Yes")
        {
            chkTBipa = "TRUE";
        }
        string chkTPASI = "FALSE";
        if (Request.Form["chkPasi"] == "Yes")
        {
            chkTPASI = "TRUE";
        }


        var valorInv = "";
        if (txtSumaAseguradaInvalidez == "")
        {
            valorInv = txtSumaAseguradaInvalidez;
        }
        else
        {
            var valorInvalidez = Convert.ToDouble(txtSumaAseguradaInvalidez);
            valorInv = string.Format(new CultureInfo("es-MX"), "{0:c}", valorInvalidez);
        }


        XElement TIPOS_COBERTURA3 = new XElement("TIPO_COBERTURA");
        TIPOS_COBERTURA3.Add(new XElement("BIPA", chkTBipa));
        TIPOS_COBERTURA3.Add(new XElement("PASI", chkTPASI));
        COBERTURA3.Add(TIPOS_COBERTURA3);
        COBERTURA3.Add(new XElement("SUMA_ASEGURADA_COB", valorInv));
        COBERTURAS.Add(COBERTURA3);

        XElement COBERTURA4 = new XElement("COBERTURA");
        COBERTURA4.Add(new XElement("NOMBRE_COB", "PLAN SUPERACION PLUS"));

        string chkMancom = "FALSE";
        if (Request.Form["chkMancomunado"] == "Yes")
        {
            chkMancom = "TRUE";
        }
        string chkTIndiv = "FALSE";
        if (Request.Form["chkTemporalIndividual"] == "Yes")
        {
            chkTIndiv = "TRUE";
        }


        var valorPlan = "";
        if (txtSumaAseguradaPlanSuperacionPlus == "")
        {
            valorPlan = txtSumaAseguradaPlanSuperacionPlus;
        }
        else
        {
            var valorPLanSuperior = Convert.ToDouble(txtSumaAseguradaPlanSuperacionPlus);
            valorPlan = string.Format(new CultureInfo("es-MX"), "{0:c}", valorPLanSuperior);
        }

        XElement TIPOS_COBERTURA4 = new XElement("TIPO_COBERTURA");
        TIPOS_COBERTURA4.Add(new XElement("TEMPORAL_INDIVIDUAL", chkTIndiv));
        TIPOS_COBERTURA4.Add(new XElement("MANCOMUNADO", chkMancom));
        COBERTURA4.Add(TIPOS_COBERTURA4);
        COBERTURA4.Add(new XElement("SUMA_ASEGURADA_COB", valorPlan));
        COBERTURAS.Add(COBERTURA4);


        #endregion COBERTURA

        TIPO_PLAN_COBERTURAS.Add(COBERTURAS);

        #endregion COBERTURAS
        #region EXCENSION_PÀGO_PRIMAS

        string chkBIT = "FALSE";
        if (Request.Form["chkBit"] == "Yes")
        {
            chkBIT = "TRUE";
        }
        string chkBITA = "FALSE";
        if (Request.Form["chkBita"] == "Yes")
        {
            chkBITA = "TRUE";
        }
        string chkEnfG = "FALSE";
        if (Request.Form["chkEnfermedadesGravesSi"] == "Yes")
        {
            chkEnfG = "TRUE";
        }
        string chksfu = "FALSE";
        if (Request.Form["chkServiciosFunerariosSI"] == "Yes")
        {
            chksfu = "TRUE";
        }
        string chkBEF = "FALSE";
        if (Request.Form["chkBefSi"] == "Yes")
        {
            chkBEF = "TRUE";
        }

        XElement EXCENSION_PAGO_PRIMAS = new XElement("EXCENSION_PAGO_PRIMAS");
        EXCENSION_PAGO_PRIMAS.Add(new XElement("BIT", chkBIT));
        EXCENSION_PAGO_PRIMAS.Add(new XElement("BITA", chkBITA));
        EXCENSION_PAGO_PRIMAS.Add(new XElement("ENFERMEDADES_GRAVES", chkEnfG));
        EXCENSION_PAGO_PRIMAS.Add(new XElement("SERVICIOS_FUNERARIOS", chksfu));
        EXCENSION_PAGO_PRIMAS.Add(new XElement("BEF", chkBEF));

        TIPO_PLAN_COBERTURAS.Add(EXCENSION_PAGO_PRIMAS);
        #endregion EXCENSION_PÀGO_PRIMAS

        TIPO_PLAN_COBERTURAS.Add(new XElement("LEYENDA_UNO_PLAN_COBERTURAS", "EV_REFERENCIAS_PLAN_COBERTURAS.rtf"));

        SOLICITUD.Add(TIPO_PLAN_COBERTURAS);
        #endregion TIPO_PLAN_COBERTURAS

        #region  CUESTIONARIO
        XElement CUESTIONARIO = new XElement("CUESTIONARIO");
        CUESTIONARIO.Add(new XElement("TITULO", "CUESTIONARIO"));

        string chkDAP = "FALSE";
        if (Request.Form["chkDeportePeligrosoSi"] == "Yes")
        {
            chkDAP = "TRUE";
        }


        XElement DATOS_GENERALES = new XElement("DATOS_GENERALES");
        DATOS_GENERALES.Add(new XElement("PESO", txtPeso));
        DATOS_GENERALES.Add(new XElement("ESTATURA", txtEstatura));
        DATOS_GENERALES.Add(new XElement("DEPORTE_AFICION_PELIGROSA", chkDAP));
        DATOS_GENERALES.Add(new XElement("NOMBRE_DEPORTE", txtCualDeporte));

        CUESTIONARIO.Add(DATOS_GENERALES);

        XElement PREGUNTAS = new XElement("PREGUNTAS");

        string chkCORA = "FALSE";
        if (Request.Form["chkCorazonSi"] == "Yes")
        {
            chkCORA = "TRUE";
        }

        XElement PREGUNTA = new XElement("PREGUNTA");
        PREGUNTA.Add(new XElement("NUM_PREGUNTA", "1"));
        PREGUNTA.Add(new XElement("RESPUESTA", chkCORA));
        PREGUNTAS.Add(PREGUNTA);

        string chkHiper = "FALSE";
        if (Request.Form["chkHipertesionArterialSi"] == "Yes")
        {
            chkHiper = "TRUE";
        }

        XElement PREGUNTA2 = new XElement("PREGUNTA");
        PREGUNTA2.Add(new XElement("NUM_PREGUNTA", "2"));
        PREGUNTA2.Add(new XElement("RESPUESTA", chkHiper));
        PREGUNTAS.Add(PREGUNTA2);

        string chkCerebro = "FALSE";
        if (Request.Form["chkCrebroVasculadresSI"] == "Yes")
        {
            chkCerebro = "TRUE";
        }

        XElement PREGUNTA3 = new XElement("PREGUNTA");
        PREGUNTA3.Add(new XElement("NUM_PREGUNTA", "3"));
        PREGUNTA3.Add(new XElement("RESPUESTA", chkCerebro));
        PREGUNTAS.Add(PREGUNTA3);

        string chkPSQN = "FALSE";
        if (Request.Form["chkPsiquiatricasNerviosasSi"] == "Yes")
        {
            chkPSQN = "TRUE";
        }

        XElement PREGUNTA4 = new XElement("PREGUNTA");
        PREGUNTA4.Add(new XElement("NUM_PREGUNTA", "4"));
        PREGUNTA4.Add(new XElement("RESPUESTA", chkPSQN));
        PREGUNTAS.Add(PREGUNTA4);

        string chkENDO = "FALSE";
        if (Request.Form["chkEndocrinasSI"] == "Yes")
        {
            chkENDO = "TRUE";
        }

        XElement PREGUNTA5 = new XElement("PREGUNTA");
        PREGUNTA5.Add(new XElement("NUM_PREGUNTA", "5"));
        PREGUNTA5.Add(new XElement("RESPUESTA", chkENDO));
        PREGUNTAS.Add(PREGUNTA5);

        string chkINSFR = "FALSE";
        if (Request.Form["chkInsuficienciaRenalSi"] == "Yes")
        {
            chkINSFR = "TRUE";
        }

        XElement PREGUNTA6 = new XElement("PREGUNTA");
        PREGUNTA6.Add(new XElement("NUM_PREGUNTA", "6"));
        PREGUNTA6.Add(new XElement("RESPUESTA", chkINSFR));
        PREGUNTAS.Add(PREGUNTA6);

        string chkSangre = "FALSE";
        if (Request.Form["chkSangreSi"] == "Yes")
        {
            chkSangre = "TRUE";
        }

        XElement PREGUNTA7 = new XElement("PREGUNTA");
        PREGUNTA7.Add(new XElement("NUM_PREGUNTA", "7"));
        PREGUNTA7.Add(new XElement("RESPUESTA", chkSangre));
        PREGUNTAS.Add(PREGUNTA7);

        string chkCIHE = "FALSE";
        if (Request.Form["chkCirrosisHeptitisSi"] == "Yes")
        {
            chkCIHE = "TRUE";
        }

        XElement PREGUNTA8 = new XElement("PREGUNTA");
        PREGUNTA8.Add(new XElement("NUM_PREGUNTA", "8"));
        PREGUNTA8.Add(new XElement("RESPUESTA", chkCIHE));
        PREGUNTAS.Add(PREGUNTA8);

        string chkDRG = "FALSE";
        if (Request.Form["chkConsumoDrogasSI"] == "Yes")
        {
            chkDRG = "TRUE";
        }

        XElement PREGUNTA9 = new XElement("PREGUNTA");
        PREGUNTA9.Add(new XElement("NUM_PREGUNTA", "9"));
        PREGUNTA9.Add(new XElement("RESPUESTA", chkDRG));
        PREGUNTAS.Add(PREGUNTA9);

        string chkSIDA = "FALSE";
        if (Request.Form["chkSidaSI"] == "Yes")
        {
            chkSIDA = "TRUE";
        }

        XElement PREGUNTA10 = new XElement("PREGUNTA");
        PREGUNTA10.Add(new XElement("NUM_PREGUNTA", "10"));
        PREGUNTA10.Add(new XElement("RESPUESTA", chkSIDA));
        PREGUNTAS.Add(PREGUNTA10);

        string chkARTR = "FALSE";
        if (Request.Form["chkArtritisSI"] == "Yes")
        {
            chkARTR = "TRUE";
        }

        XElement PREGUNTA11 = new XElement("PREGUNTA");
        PREGUNTA11.Add(new XElement("NUM_PREGUNTA", "11"));
        PREGUNTA11.Add(new XElement("RESPUESTA", chkARTR));
        PREGUNTAS.Add(PREGUNTA11);


        string chkPULM = "FALSE";
        if (Request.Form["chkPulmonaresRespiratoriasSi"] == "Yes")
        {
            chkPULM = "TRUE";
        }

        XElement PREGUNTA12 = new XElement("PREGUNTA");
        PREGUNTA12.Add(new XElement("NUM_PREGUNTA", "12"));
        PREGUNTA12.Add(new XElement("RESPUESTA", chkPULM));
        PREGUNTAS.Add(PREGUNTA12);

        string chkAPDig = "FALSE";
        if (Request.Form["chkAparatoDigestivoSi"] == "Yes")
        {
            chkAPDig = "TRUE";
        }

        XElement PREGUNTA13 = new XElement("PREGUNTA");
        PREGUNTA13.Add(new XElement("NUM_PREGUNTA", "13"));
        PREGUNTA13.Add(new XElement("RESPUESTA", chkAPDig));
        PREGUNTAS.Add(PREGUNTA13);

        string chkOtra = "FALSE";
        if (Request.Form["chkEnfermedadMencionadaSi"] == "Yes")
        {
            chkOtra = "TRUE";
        }

        XElement PREGUNTA14 = new XElement("PREGUNTA");
        PREGUNTA14.Add(new XElement("NUM_PREGUNTA", "14"));
        PREGUNTA14.Add(new XElement("RESPUESTA", chkOtra));
        PREGUNTAS.Add(PREGUNTA14);

        CUESTIONARIO.Add(PREGUNTAS);

        XElement RESPUESTAS_AMPLIADAS = new XElement("RESPUESTAS_AMPLIADAS");
        RESPUESTAS_AMPLIADAS.Add("TITULO", "RESPUESTAS_AMPLIADAS");

        //XElement RESPUESTA_AMPLIADA = new XElement("RESPUESTA_AMPLIADA");
        //RESPUESTA_AMPLIADA.Add(new XElement("RESPUESTA_AMPLIADA", "1"));
        //RESPUESTA_AMPLIADA.Add(new XElement("PADECIMIENTO", "txtPadecimientoUno"));
        //RESPUESTA_AMPLIADA.Add(new XElement("FECHA_INICIO", "txtFechaInicioUno"));
        //RESPUESTA_AMPLIADA.Add(new XElement("DURACION", "txtDuracionUno"));
        //RESPUESTA_AMPLIADA.Add(new XElement("ESTADO_ACTUAL", "txtEstadoActualUno"));

        //CUESTIONARIO.Add(RESPUESTA_AMPLIADA);

        XElement RESPUESTA_AMPLIADA1 = new XElement("RESPUESTA_AMPLIADA");
        RESPUESTA_AMPLIADA1.Add(new XElement("RESPUESTA_AMPLIADA", "1"));
        RESPUESTA_AMPLIADA1.Add(new XElement("PADECIMIENTO", txtPadecimientoUno));
        RESPUESTA_AMPLIADA1.Add(new XElement("FECHA_INICIO", txtFechaInicioUno));
        RESPUESTA_AMPLIADA1.Add(new XElement("DURACION", txtDuracionUno));
        RESPUESTA_AMPLIADA1.Add(new XElement("ESTADO_ACTUAL", txtEstadoActualUno));

        RESPUESTAS_AMPLIADAS.Add(RESPUESTA_AMPLIADA1);

        XElement RESPUESTA_AMPLIADA2 = new XElement("RESPUESTA_AMPLIADA");
        RESPUESTA_AMPLIADA2.Add(new XElement("RESPUESTA_AMPLIADA", "2"));
        RESPUESTA_AMPLIADA2.Add(new XElement("PADECIMIENTO", txtPadecimientoDos));
        RESPUESTA_AMPLIADA2.Add(new XElement("FECHA_INICIO", txtFechaInicioDos));
        RESPUESTA_AMPLIADA2.Add(new XElement("DURACION", txtDuracionDos));
        RESPUESTA_AMPLIADA2.Add(new XElement("ESTADO_ACTUAL", txtEstadoActualDos));

        RESPUESTAS_AMPLIADAS.Add(RESPUESTA_AMPLIADA2);

        XElement RESPUESTA_AMPLIADA3 = new XElement("RESPUESTA_AMPLIADA");
        RESPUESTA_AMPLIADA3.Add(new XElement("RESPUESTA_AMPLIADA", "3"));
        RESPUESTA_AMPLIADA3.Add(new XElement("PADECIMIENTO", txtPadecimientoTres));
        RESPUESTA_AMPLIADA3.Add(new XElement("FECHA_INICIO", txtFechaInicioTres));
        RESPUESTA_AMPLIADA3.Add(new XElement("DURACION", txtDuracionTres));
        RESPUESTA_AMPLIADA3.Add(new XElement("ESTADO_ACTUAL", txtEstadoActualTres));

        RESPUESTAS_AMPLIADAS.Add(RESPUESTA_AMPLIADA3);

        CUESTIONARIO.Add(RESPUESTAS_AMPLIADAS);

        XElement OTROS_SEGUROS_DE_VIDA = new XElement("OTROS_SEGUROS_DE_VIDA");

        string chkSoliS = "FALSE";
        if (Request.Form["chkSolicitudSi"] == "Yes")
        {
            chkSoliS = "TRUE";
        }
        OTROS_SEGUROS_DE_VIDA.Add(new XElement("HA_SOLICITADO_OTRO_SEGURO", chkSoliS));
        OTROS_SEGUROS_DE_VIDA.Add(new XElement("ESPECIFIQUE", txtEspecificacionCompañiaSumaAseguradaMonedaPlan));
        //PROBAR
        string chkRech = "FALSE";
        if (Request.Form["chkRechazadoSi"] == "Yes")
        {
            chkRech = "TRUE";
        }

        OTROS_SEGUROS_DE_VIDA.Add(new XElement("HA_SIDO_RECHAZADO", chkRech));
        OTROS_SEGUROS_DE_VIDA.Add(new XElement("MOTIVO_RECHAZO", txtMotivo));

        CUESTIONARIO.Add(OTROS_SEGUROS_DE_VIDA);
        SOLICITUD.Add(CUESTIONARIO);

        #endregion CUESTIONARIO

        #region DESIGNA_BENEFICIARIOS
        XElement DESIGNA_BENEFICIARIOS = new XElement("DESIGNA_BENEFICIARIOS");
        DESIGNA_BENEFICIARIOS.Add(new XElement("TITULO", "EV_LEYENDA_BENEFICIARIOS.rtf"));

        XElement BENEFICIARIOS = new XElement("BENEFICIARIOS");

        //XElement BENEFICIARIO = new XElement("BENEFICIARIO");
        //BENEFICIARIO.Add(new XElement("NUM_BENEFICIARIO", "1"));
        //BENEFICIARIO.Add(new XElement("NOMBRE", txtBeneficiariosNombreCompletoUno));
        //BENEFICIARIO.Add(new XElement("PARENTESCO", txtParentescoUno));
        //BENEFICIARIO.Add(new XElement("PARTICIPACION", txtPorcentajeUno));

        //BENEFICIARIOS.Add(BENEFICIARIO);

        //XElement BENEFICIARIO2 = new XElement("BENEFICIARIO");
        //BENEFICIARIO2.Add(new XElement("NUM_BENEFICIARIO", "2"));
        //BENEFICIARIO2.Add(new XElement("NOMBRE", txtBeneficiariosNombreCompletoDos));
        //BENEFICIARIO2.Add(new XElement("PARENTESCO", txtParentescoDos));
        //BENEFICIARIO2.Add(new XElement("PARTICIPACION", txtPorcentajeDos));

        //BENEFICIARIOS.Add(BENEFICIARIO2);

        //XElement BENEFICIARIO3 = new XElement("BENEFICIARIO");
        //BENEFICIARIO3.Add(new XElement("NUM_BENEFICIARIO", "3"));
        //BENEFICIARIO3.Add(new XElement("NOMBRE", txtBeneficiariosNombreCompletoTres));
        //BENEFICIARIO3.Add(new XElement("PARENTESCO", txtParentescoTres));
        //BENEFICIARIO3.Add(new XElement("PARTICIPACION", txtPorcentajeTres));

        //BENEFICIARIOS.Add(BENEFICIARIO3);
        XElement DOMICILIOS = new XElement("DOMICILIOS");

        var dtBeneficiarios = ((DataTable)Session["Beneficiarios"]).Copy();
        var nb = dtBeneficiarios.Rows.Count;
        //DataTable dt = dtBeneficiarios;
        for (int i = 0; i < nb; i++)
        {
            DataTable dt = dtBeneficiarios;
            DataRow dr = dt.Rows[i];
            XElement BENEFICIARIO1 = new XElement("BENEFICIARIO");
            //foreach (DataRow dr in dt.Rows)
            //{

            BENEFICIARIO1.Add(new XElement("NUM_BENEFICIARIO", dr["cod_benef"].ToString()));
            BENEFICIARIO1.Add(new XElement("NOMBRE", dr["nombre"].ToString() + " " + dr["paterno"].ToString() + " " + dr["materno"].ToString()));
            BENEFICIARIO1.Add(new XElement("PARENTESCO", dr["nom_parent"].ToString()));
            BENEFICIARIO1.Add(new XElement("PARTICIPACION", dr["porcentaje"].ToString()));

            BENEFICIARIO1.Add(new XElement("DOMICILIO", dr["domicilio"].ToString()));
            BENEFICIARIO1.Add(new XElement("FECHA_NACIMIENTO", dr["fecnac"].ToString()));


            //}
            BENEFICIARIOS.Add(BENEFICIARIO1);
            DOMICILIOS.Add(BENEFICIARIO1);
            DOMICILIOS.Add(new XElement("LEYENDA_UNO_BENEFICIARIOS", "EV_ADVERTENCIA_BENEFICIARIOS.rtf"));
        }


        DESIGNA_BENEFICIARIOS.Add(BENEFICIARIOS);
        //XElement DOMICILIOS = new XElement("DOMICILIOS");

        //XElement BENEFICIARIO4 = new XElement("BENEFICIARIO");
        //BENEFICIARIO4.Add(new XElement("NUM_BENEFICIARIO", "1"));
        //BENEFICIARIO4.Add(new XElement("DOMICILIO", txtDomicilioCompletoUno));
        //BENEFICIARIO4.Add(new XElement("FECHA_NACIMIENTO", txtFechaNacimientoUno));


        //DOMICILIOS.Add(BENEFICIARIO4);

        //XElement BENEFICIARIO5 = new XElement("BENEFICIARIO");
        //BENEFICIARIO5.Add(new XElement("NUM_BENEFICIARIO", "2"));
        //BENEFICIARIO5.Add(new XElement("NOMBRE", txtDomicilioCompletoDos));
        //BENEFICIARIO5.Add(new XElement("PARENTESCO", txtFechaNacimientoDos));


        //DOMICILIOS.Add(BENEFICIARIO5);

        //XElement BENEFICIARIO6 = new XElement("BENEFICIARIO");
        //BENEFICIARIO6.Add(new XElement("NUM_BENEFICIARIO", "3"));
        //BENEFICIARIO6.Add(new XElement("NOMBRE", txtFechaNacimientoTres));
        //BENEFICIARIO6.Add(new XElement("PARENTESCO", txtParentescoTres));


        //DOMICILIOS.Add(BENEFICIARIO6);


        DESIGNA_BENEFICIARIOS.Add(DOMICILIOS);


        SOLICITUD.Add(DESIGNA_BENEFICIARIOS);
        #endregion DESIGNA_BENEFICIARIOS

        #region OBSERVACIONES
        XElement OBSERVACIONES = new XElement("OBSERVACIONES");
        OBSERVACIONES.Add(new XElement("TITULO", "OBSERVACIONES"));

        XElement OBSERVACION = new XElement("OBSERVACION");

        OBSERVACION.Add(new XElement("NUM_BENEFICIARIO", "1"));
        OBSERVACION.Add(new XElement("NOMBRE", txtOberservacionesUno));

        OBSERVACIONES.Add(OBSERVACION);

        XElement OBSERVACION2 = new XElement("OBSERVACION");

        OBSERVACION2.Add(new XElement("NUM_BENEFICIARIO", "2"));
        OBSERVACION2.Add(new XElement("NOMBRE", txtOberservacionesDos));

        OBSERVACIONES.Add(OBSERVACION2);


        XElement OBSERVACION3 = new XElement("OBSERVACION");

        OBSERVACION3.Add(new XElement("NUM_BENEFICIARIO", "3"));
        OBSERVACION3.Add(new XElement("NOMBRE", txtOberservacionesTres));

        OBSERVACIONES.Add(OBSERVACION3);

        SOLICITUD.Add(OBSERVACIONES);

        #endregion OBSERVACIONES

        #region INFORMACION

        XElement INFORMACION = new XElement("INFORMACION");

        INFORMACION.Add(new XElement("LEYENDA_UNO_INFORMACION", "EV_CONSTITUYE_SOLICITUD.rtf"));
        INFORMACION.Add(new XElement("LEYENDA_DOS_INFORMACION", "EV_INTERES_SOLICITANTE.rtf"));
        INFORMACION.Add(new XElement("LEYENDA_TRES_INFORMACION", "EV_LEY_CONTRATO_DE_SEGURO.rtf"));
        INFORMACION.Add(new XElement("LUGAR_Y_FECHA", txtSolLugaryFecha));

        SOLICITUD.Add(INFORMACION);

        #endregion INFORMACION

        #region USO_CONTRATANTE

        XElement USO_CONTRATANTE = new XElement("USO_CONTRATANTE");
        USO_CONTRATANTE.Add(new XElement("TITULO", "PARA USO EXCLUSIVO DEL CONTRATANTE"));
        USO_CONTRATANTE.Add(new XElement("LEYENDA_UNO_USO_CONTRATANTE", "EV_AUTORIZO_ENTREGA_CORREO.rtf"));
        USO_CONTRATANTE.Add(new XElement("MEDIO_ENTREGA", txtMedioEntrega));

        XElement FIRMAS = new XElement("FIRMAS");

        XElement FIRMA = new XElement("FIRMA_CONTRATANTE");
        //FIRMA.Add(new XElement("TIPO_TERCERO", "CONTRATANTE"));
        FIRMA.Add(new XElement("NOMBRE", txtNombreFirmaContratante));
        FIRMA.Add(new XElement("IMAGEN_FIRMA", ""));

        FIRMAS.Add(FIRMA);

        XElement FIRMA1 = new XElement("FIRMA_SOLICITANTE");
        //FIRMA1.Add(new XElement("TIPO_TERCERO", "SOLICITANTE"));
        FIRMA1.Add(new XElement("NOMBRE", txtNombreFirmaSolicitante));
        FIRMA1.Add(new XElement("IMAGEN_FIRMA", ""));

        FIRMAS.Add(FIRMA1);

        XElement FIRMA2 = new XElement("FIRMA_AGENTE");
        //FIRMA2.Add(new XElement("TIPO_TERCERO", "AGENTE"));
        FIRMA2.Add(new XElement("NOMBRE", txtNombreAgente));
        FIRMA2.Add(new XElement("IMAGEN_FIRMA", ""));

        FIRMAS.Add(FIRMA2);
        USO_CONTRATANTE.Add(FIRMAS);
        SOLICITUD.Add(USO_CONTRATANTE);

        #endregion USO_CONTRATANTE

        #region USO_AGENTE
        XElement USO_AGENTE = new XElement("USO_AGENTE");
        USO_AGENTE.Add(new XElement("TITULO", "PARA SER LLENADO EXCLUSIVAMENTE POR EL AGENTE"));
        USO_AGENTE.Add(new XElement("LEYENDA_UNO_AGENTE", "EV_MANIFIESTO_AGENTE.rtf"));
        USO_AGENTE.Add(new XElement("NOMBRE", txtNombreAgente));
        USO_AGENTE.Add(new XElement("CLAVE", txtClaveAgente));

        string chkCN = "FALSE";
        if (Request.Form["chkNivelada"] == "Yes")
        {
            chkCN = "TRUE";
        }

        string chkCD = "FALSE";
        if (Request.Form["chkDecreciente"] == "Yes")
        {
            chkCD = "TRUE";
        }


        XElement COMISION = new XElement("COMISION");
        COMISION.Add(new XElement("NIVELADA", chkCN));
        COMISION.Add(new XElement("DECRECIENTE", chkCD));

        USO_AGENTE.Add(COMISION);

        string chkFSP = "FALSE";
        if (Request.Form["chkFinalidadSeguroPatrimonial"] == "Yes")
        {
            chkFSP = "TRUE";
        }

        string chkFSE = "FALSE";
        if (Request.Form["chkFinalidadSeguroEducacion"] == "Yes")
        {
            chkFSE = "TRUE";
        }

        string chkFSR = "FALSE";
        if (Request.Form["chkFinalidadSeguroRetiro"] == "Yes")
        {
            chkFSR = "TRUE";
        }
        string chkFSS = "FALSE";
        if (Request.Form["chkFinalidadSeguroSocios"] == "Yes")
        {
            chkFSS = "TRUE";
        }
        string chkFSH = "FALSE";
        if (Request.Form["chkFinalidadSeguroHombreClave"] == "Yes")
        {
            chkFSH = "TRUE";
        }
        string chkFSC = "FALSE";
        if (Request.Form["chkFinalidadSeguroCredito"] == "Yes")
        {
            chkFSC = "TRUE";
        }


        XElement FINALIDAD_SEGURO = new XElement("FINALIDAD_SEGURO");
        FINALIDAD_SEGURO.Add(new XElement("PATRIMONIAL", chkFSP));
        FINALIDAD_SEGURO.Add(new XElement("EDUCACION", chkFSE));
        FINALIDAD_SEGURO.Add(new XElement("RETIRO", chkFSR));
        FINALIDAD_SEGURO.Add(new XElement("SEGURO_SOCIOS", chkFSS));
        FINALIDAD_SEGURO.Add(new XElement("HOMBRE_CLAVE", chkFSH));
        FINALIDAD_SEGURO.Add(new XElement("CREDITO", chkFSC));


        USO_AGENTE.Add(FINALIDAD_SEGURO);


        USO_AGENTE.Add(new XElement("LEYENDA_DOS_AGENTE", "EV_INFORMACION_CONSULTE_PAGINA.rtf"));

        SOLICITUD.Add(USO_AGENTE);



        #endregion USO_AGENTE

        XElement INFORMACION_ADICIONAL = new XElement("INFORMACION_ADICIONAL", "EV_INFORMACION_ADICIONAL.rtf");
        SOLICITUD.Add(INFORMACION_ADICIONAL);

        ROOT.Add(SOLICITUD);



        #endregion SOLICITUD



        string xmlSolicitud = ROOT.ToString().Replace(".JPG", ".jpg")
              .Replace("true", "TRUE")
              .Replace("false", "FALSE")
              .Replace("&AMP;", "&#38;")
              .Replace(".RTF", ".rtf");

        XmlHpExtreme xmlHpExtreme = new XmlHpExtreme();
        string archivo = xmlHpExtreme.XmlHpExtremeSolicitud(xmlSolicitud, Request.Form["numCotizacion"]);
        //AbrirPdf(nombre);

        //}

        //return ROOT;

        // flatten the form to remove editting options, set it to false
        // to leave the form open to subsequent manual edits
        //    pdfStamper.FormFlattening = false;

        //    // close the pdf
        //    pdfStamper.Close();

        //}
        //catch (Exception ex)
        //{
        //    MapfreMMX.util.MLogFile.getInstance().writeText("Error FillFormSolicitud()" + ex.Message);
        //}
    }
    private void FillFormCuestionarioSumaAsegurada(string nomFile)
    {
        //string pdfTemplate = @"C:\inetpub\wwwroot\EmisionGeneralVida\SolicitudPDF\cuestionario_SA_mayor_a_15_millones.pdf";
        //string newFile = @"C:\inetpub\wwwroot\EmisionGeneralVida\SolicitudPDF\Firma\cSA_" + nomFile + ".pdf";
        //MapfreMMX.util.MLogFile.getInstance().writeText("FillCuestionarioSA(" + nomFile + ")");
        //try
        //{
        //    PdfReader pdfReader = new PdfReader(pdfTemplate);
        //    PdfStamper pdfStamper = new PdfStamper(pdfReader, new FileStream(
        //                newFile, FileMode.Create));

        //    AcroFields pdfFormFields = pdfStamper.AcroFields;
        // The first worksheet and W-4 form
        #region DeclaraVariables
        String txtSAPade3 = "";
        String txtSAPadeEdoAct2 = "";
        String txtSAm1FinAlcohol = "";
        String txtSAa1FinDroga = "";
        String txtSANomAgt1 = "";
        String txtSACVEAgt3 = "";
        String txtSAFolio4 = "";
        String txtSANumPre1 = "";
        String txtSANomRef1 = "";
        String txtSAPadeDura2 = "";
        String txtSAd2FinDroga = "";
        String txtSAEvoCancer = "";
        String txtSAEvoDiabetes = "";
        String txtSAa2FinAlcohol = "";
        String txtSANomAgt2 = "";
        String txtSAa1Mamo = "";
        String txtSAFolio8 = "";
        String txtSAPoliza9 = "";
        String txtSAInfAgt1 = "";
        String txtSAPadeEdoAct4 = "";
        String chkSACuest4No = "";
        String txtSAm1FinDroga = "";
        String txtSACuestCausa1 = "";
        String chkSACuest5Si = "";
        String txtSAEdadHijos = "";
        String txtSAd1IniDroga = "";
        String txtSACausasHIjos = "";
        String txtSAa1Papani = "";
        String txtSACuestKgDism = "";
        String txtSAEdadFallePadre = "";
        String txtSAm2Papani = "";
        String txtSAFecPade1 = "";
        String txtSAPoliza11 = "";
        String txtSATelRef1 = "";
        String txtSAd1IniAlcohol = "";
        String txtSAPoliza13 = "";
        String txtSANomContra = "";
        String chkSACuest5No = "";
        String txtSAm2IniAlcohol = "";
        String txtSAd2IniDroga = "";
        String txtSAViveHnos = "";
        String chkSAReqViajarSi = "";
        String txtSAPoliza4 = "";
        String chkSATraAltSi = "";
        String chkSAOcupacionNo = "";
        String txtSACausasPadre = "";
        String chkSAInfAgt8Si = "";
        String txtSAd2IniFumar = "";
        String txtSACausasHnos = "";
        String txtSADomRef1 = "";
        String txtSAd1FinAlcohol = "";
        String txtSAFolio11 = "";
        String txtSAPoliza10 = "";
        String txtSAPoliza7 = "";
        String txtSAPoliza12 = "";
        String txtSAFolio12 = "";
        String chkSALugFab = "";
        String txtSAClavePais = "";
        String txtSAm2Mamo = "";
        String chkSAPipa = "";
        String txtSAm2FinAlcohol = "";
        String txtSADomRef2 = "";
        String chkSACuest6bSi = "";
        String txtSAPadeDura3 = "";
        String chkSACuest4Si = "";
        String txtSAQuienDiabetes = "";
        String txtSAm2IniDroga = "";
        String txtSAd1FinFumar = "";
        String txtSANomDomiDr = "";
        String txtSANomSol = "";
        String txtSAEdadFalleHijos = "";
        String txtSAm1Mamo = "";
        String txtSAAeronaveHoras = "";
        String txtSANumCopas = "";
        String txtSAViveMadre = "";
        String txtSACVEAgt2 = "";
        String txtSAa1IniDroga = "";
        String txtSAFolio9 = "";
        String chkSALugTal = "";
        String txtSACuest6c1Res = "";
        String chkSAInfAgt7No = "";
        String txtSAFolio5 = "";
        String txtSAPoliza8 = "";
        String txtSAFolio7 = "";
        String txtSAFolio6 = "";
        String txtSAd1IniFumar = "";
        String txtSAPade2 = "";
        String txtSAFolio3 = "";
        String txtSAFolio2 = "";
        String txtSAd2Papani = "";
        String chkSACuest6bNo = "";
        String txtSATipoTransporte = "";
        //2605
        //String txtSATipoMaquinas = "";
        String txtSACuestCausa2 = "";
        String txtSAa2IniDroga = "";
        String txtSANomRef2 = "";
        String txtSAa2FinDroga = "";
        String txtSAPade1 = "";
        String txtSANomHosp = "";
        String txtSATelefono = "";
        String txtSACodCiudad = "";
        String chkSAAfici = "";
        String txtSAPoliza5 = "";
        String txtSAVivePadre = "";
        String txtCuest6aCual = "";
        String txtSAPadeEdoAct3 = "";
        String txtSAm1IniAlcohol = "";
        String chkSACuest3Si = "";
        String txtSAPade4 = "";
        String txtSAOtroLugarTrabajo = "";
        String chkSACigarros = "";
        String chkSACuest1No = "";
        String txtSAInfAgt4 = "";
        String txtSAAlturaTrabajo = "";
        String chkSAUsarMotoNo = "";
        String txtSAa1IniFumar = "";
        String txtSACuestCuando4 = "";
        String chkSALugCal = "";
        String txtSAInfAgt2 = "";
        String txtSAd2FinAlcohol = "";
        String txtSAm2FinDroga = "";
        String chkSAAeroPartSi = "";
        String txtSAPctAgt1 = "";
        String txtSAEmailAgt = "";
        String txtSAEdoSAlMadre = "";
        String txtSANomCon = "";
        String txtSAEdoSAlHijos = "";
        String txtSAd1Papani = "";
        String chkSALugOfc = "";
        String txtSASustancias = "";
        String txtSANumPre3 = "";
        String txtSAPctAgt3 = "";
        String txtSAEvoPresion = "";
        String txtSACVEAgt1 = "";
        String txtSACuestCausa4 = "";
        String txtSAEvoCardiaca = "";
        String txtSAEdoSAlHnos = "";
        String chkSATraAltNo = "";
        String chkSAPuro = "";
        String txtSAa1IniAlcohol = "";
        String chkSAUsarMotoSi = "";
        String chkSACubRiesDepoSi = "";
        String txtSANomAgt3 = "";
        String txtSAMotDrogas = "";
        String txtSANumPre2 = "";
        String txtSACuestCausa3 = "";
        String txtSAPadeDura1 = "";
        String txtSAm1FinFumar = "";
        String txtSAm1Papani = "";
        String txtSAFrecDrogas = "";
        String chkSACuest6aSi = "";
        String txtSAFolio13 = "";
        String txtSAFecPade2 = "";
        String txtSAd1Mamo = "";
        String txtSACuest6c2Res = "";
        String txtSACuestCuando3 = "";
        String txtSACuestCuando2 = "";
        String txtSAFecPade4 = "";
        String txtSAFecPade3 = "";
        String chkSAReqViajarNo = "";
        String txtSAm2IniFumar = "";
        String txtSAViveHijos = "";
        String txtSAFolio10 = "";
        String txtSAPoliza2 = "";
        String chkSAAmat = "";
        String txtSACausasMadre = "";
        String txtSAa2IniFumar = "";
        String txtSAFolio1 = "";
        String txtSAa1FinFumar = "";
        String txtSAEdoSAlPadre = "";
        String txtSAInfAgt6 = "";
        String txtSAInfAgt3 = "";
        String txtSAPoliza1 = "";
        String txtSAPadeDura4 = "";
        String txtSATipoFrecDrogas = "";
        String txtSAFrecuenciaMoto = "";
        String txtSANumCigarros = "";
        String txtSAOcupacion = "";
        String txtSATelAgt = "";
        String txtSAQuienPresion = "";
        String chkSAOcupacionSi = "";
        String txtSAa1FinAlcohol = "";
        String txtSAPctAgt2 = "";
        String txtSAFrecFumar = "";
        String txtSAEdadPadre = "";
        String txtSAm1IniDroga = "";
        String chkSACuest2No = "";
        String chkSACubRiesDepoNo = "";
        String txtSAm2FinFumar = "";
        String txtSAEdadFalleHnos = "";
        String txtSAm1IniFumar = "";
        String chkSACuest6aNo = "";
        String txtSAa2Papani = "";
        String chkSACuest2Si = "";
        String txtSAa2IniAlcohol = "";
        String txtSAd1FinDroga = "";
        String txtSAEdadMadre = "";
        String txtSAMotFumar = "";
        String txtSAPadeEdoAct1 = "";
        String txtSAEdadHnos = "";
        String txtSAEdadFalleMadre = "";
        String chkSACuest3No = "";
        String chkSAAeroPartNo = "";
        String txtSACuestKgAum = "";
        String txtSAd2IniAlcohol = "";
        String txtSATelRef2 = "";
        String chkSAInfAgt8No = "";
        String txtSAa2FinFumar = "";
        String txtSAd2FinFumar = "";
        String txtCuest6bCuant = "";
        String txtSAMotAlcohol = "";
        String txtSAPoliza3 = "";
        String txtSAGiroEmpresa = "";
        String txtSAFrecAlcohol = "";
        String chkSAProfe = "";
        String txtSAd2Mamo = "";
        String chkSAInfAgt7Si = "";
        String txtSAQuienCardiaca = "";
        String chkSACuest1Si = "";
        String txtSAQuienCancer = "";
        String txtSANumPre4 = "";
        String txtSAPoliza6 = "";
        String txtSANomSoli = "";
        String txtSAa2Mamo = "";
        String txtSALugaryFecha = "";

        #endregion
        #region setVariables
        if (!string.IsNullOrEmpty(Request.Form["txtSAPade3"])) { txtSAPade3 = Request.Form["txtSAPade3"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPadeEdoAct2"])) { txtSAPadeEdoAct2 = Request.Form["txtSAPadeEdoAct2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAm1FinAlcohol"])) { txtSAm1FinAlcohol = Request.Form["txtSAm1FinAlcohol"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAa1FinDroga"])) { txtSAa1FinDroga = Request.Form["txtSAa1FinDroga"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSANomAgt1"])) { txtSANomAgt1 = Request.Form["txtSANomAgt1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACVEAgt3"])) { txtSACVEAgt3 = Request.Form["txtSACVEAgt3"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFolio4"])) { txtSAFolio4 = Request.Form["txtSAFolio4"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSANumPre1"])) { txtSANumPre1 = Request.Form["txtSANumPre1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSANomRef1"])) { txtSANomRef1 = Request.Form["txtSANomRef1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPadeDura2"])) { txtSAPadeDura2 = Request.Form["txtSAPadeDura2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAd2FinDroga"])) { txtSAd2FinDroga = Request.Form["txtSAd2FinDroga"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAEvoCancer"])) { txtSAEvoCancer = Request.Form["txtSAEvoCancer"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAEvoDiabetes"])) { txtSAEvoDiabetes = Request.Form["txtSAEvoDiabetes"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAa2FinAlcohol"])) { txtSAa2FinAlcohol = Request.Form["txtSAa2FinAlcohol"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSANomAgt2"])) { txtSANomAgt2 = Request.Form["txtSANomAgt2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAa1Mamo"])) { txtSAa1Mamo = Request.Form["txtSAa1Mamo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFolio8"])) { txtSAFolio8 = Request.Form["txtSAFolio8"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPoliza9"])) { txtSAPoliza9 = Request.Form["txtSAPoliza9"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAInfAgt1"])) { txtSAInfAgt1 = Request.Form["txtSAInfAgt1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPadeEdoAct4"])) { txtSAPadeEdoAct4 = Request.Form["txtSAPadeEdoAct4"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSACuest4No"])) { chkSACuest4No = Request.Form["chkSACuest4No"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAm1FinDroga"])) { txtSAm1FinDroga = Request.Form["txtSAm1FinDroga"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACuestCausa1"])) { txtSACuestCausa1 = Request.Form["txtSACuestCausa1"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSACuest5Si"])) { chkSACuest5Si = Request.Form["chkSACuest5Si"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAEdadHijos"])) { txtSAEdadHijos = Request.Form["txtSAEdadHijos"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAd1IniDroga"])) { txtSAd1IniDroga = Request.Form["txtSAd1IniDroga"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACausasHIjos"])) { txtSACausasHIjos = Request.Form["txtSACausasHIjos"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAa1Papani"])) { txtSAa1Papani = Request.Form["txtSAa1Papani"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACuestKgDism"])) { txtSACuestKgDism = Request.Form["txtSACuestKgDism"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAEdadFallePadre"])) { txtSAEdadFallePadre = Request.Form["txtSAEdadFallePadre"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAm2Papani"])) { txtSAm2Papani = Request.Form["txtSAm2Papani"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFecPade1"])) { txtSAFecPade1 = Request.Form["txtSAFecPade1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPoliza11"])) { txtSAPoliza11 = Request.Form["txtSAPoliza11"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSATelRef1"])) { txtSATelRef1 = Request.Form["txtSATelRef1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAd1IniAlcohol"])) { txtSAd1IniAlcohol = Request.Form["txtSAd1IniAlcohol"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPoliza13"])) { txtSAPoliza13 = Request.Form["txtSAPoliza13"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSANomContra"])) { txtSANomContra = Request.Form["txtSANomContra"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSACuest5No"])) { chkSACuest5No = Request.Form["chkSACuest5No"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAm2IniAlcohol"])) { txtSAm2IniAlcohol = Request.Form["txtSAm2IniAlcohol"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAd2IniDroga"])) { txtSAd2IniDroga = Request.Form["txtSAd2IniDroga"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAViveHnos"])) { txtSAViveHnos = Request.Form["txtSAViveHnos"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSAReqViajarSi"])) { chkSAReqViajarSi = Request.Form["chkSAReqViajarSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPoliza4"])) { txtSAPoliza4 = Request.Form["txtSAPoliza4"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSATraAltSi"])) { chkSATraAltSi = Request.Form["chkSATraAltSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSAOcupacionNo"])) { chkSAOcupacionNo = Request.Form["chkSAOcupacionNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACausasPadre"])) { txtSACausasPadre = Request.Form["txtSACausasPadre"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSAInfAgt8Si"])) { chkSAInfAgt8Si = Request.Form["chkSAInfAgt8Si"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAd2IniFumar"])) { txtSAd2IniFumar = Request.Form["txtSAd2IniFumar"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACausasHnos"])) { txtSACausasHnos = Request.Form["txtSACausasHnos"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSADomRef1"])) { txtSADomRef1 = Request.Form["txtSADomRef1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAd1FinAlcohol"])) { txtSAd1FinAlcohol = Request.Form["txtSAd1FinAlcohol"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFolio11"])) { txtSAFolio11 = Request.Form["txtSAFolio11"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPoliza10"])) { txtSAPoliza10 = Request.Form["txtSAPoliza10"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPoliza7"])) { txtSAPoliza7 = Request.Form["txtSAPoliza7"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPoliza12"])) { txtSAPoliza12 = Request.Form["txtSAPoliza12"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFolio12"])) { txtSAFolio12 = Request.Form["txtSAFolio12"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSALugFab"])) { chkSALugFab = Request.Form["chkSALugFab"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAClavePais"])) { txtSAClavePais = Request.Form["txtSAClavePais"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAm2Mamo"])) { txtSAm2Mamo = Request.Form["txtSAm2Mamo"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSAPipa"])) { chkSAPipa = Request.Form["chkSAPipa"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAm2FinAlcohol"])) { txtSAm2FinAlcohol = Request.Form["txtSAm2FinAlcohol"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSADomRef2"])) { txtSADomRef2 = Request.Form["txtSADomRef2"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSACuest6bSi"])) { chkSACuest6bSi = Request.Form["chkSACuest6bSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPadeDura3"])) { txtSAPadeDura3 = Request.Form["txtSAPadeDura3"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSACuest4Si"])) { chkSACuest4Si = Request.Form["chkSACuest4Si"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAQuienDiabetes"])) { txtSAQuienDiabetes = Request.Form["txtSAQuienDiabetes"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAm2IniDroga"])) { txtSAm2IniDroga = Request.Form["txtSAm2IniDroga"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAd1FinFumar"])) { txtSAd1FinFumar = Request.Form["txtSAd1FinFumar"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSANomDomiDr"])) { txtSANomDomiDr = Request.Form["txtSANomDomiDr"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNombreFirmaSolicitante"])) { txtSANomSol = Request.Form["txtNombreFirmaSolicitante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAEdadFalleHijos"])) { txtSAEdadFalleHijos = Request.Form["txtSAEdadFalleHijos"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAm1Mamo"])) { txtSAm1Mamo = Request.Form["txtSAm1Mamo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAAeronaveHoras"])) { txtSAAeronaveHoras = Request.Form["txtSAAeronaveHoras"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSANumCopas"])) { txtSANumCopas = Request.Form["txtSANumCopas"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAViveMadre"])) { txtSAViveMadre = Request.Form["txtSAViveMadre"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACVEAgt2"])) { txtSACVEAgt2 = Request.Form["txtSACVEAgt2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAa1IniDroga"])) { txtSAa1IniDroga = Request.Form["txtSAa1IniDroga"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFolio9"])) { txtSAFolio9 = Request.Form["txtSAFolio9"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSALugTal"])) { chkSALugTal = Request.Form["chkSALugTal"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACuest6c1Res"])) { txtSACuest6c1Res = Request.Form["txtSACuest6c1Res"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSAInfAgt7No"])) { chkSAInfAgt7No = Request.Form["chkSAInfAgt7No"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFolio5"])) { txtSAFolio5 = Request.Form["txtSAFolio5"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPoliza8"])) { txtSAPoliza8 = Request.Form["txtSAPoliza8"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFolio7"])) { txtSAFolio7 = Request.Form["txtSAFolio7"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFolio6"])) { txtSAFolio6 = Request.Form["txtSAFolio6"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAd1IniFumar"])) { txtSAd1IniFumar = Request.Form["txtSAd1IniFumar"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPade2"])) { txtSAPade2 = Request.Form["txtSAPade2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFolio3"])) { txtSAFolio3 = Request.Form["txtSAFolio3"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFolio2"])) { txtSAFolio2 = Request.Form["txtSAFolio2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAd2Papani"])) { txtSAd2Papani = Request.Form["txtSAd2Papani"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSACuest6bNo"])) { chkSACuest6bNo = Request.Form["chkSACuest6bNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSATipoTransporte"])) { txtSATipoTransporte = Request.Form["txtSATipoTransporte"]; }
        //2605
        //if (!string.IsNullOrEmpty(Request.Form["txtSATipoMaquinas"])) { txtSATipoMaquinas = Request.Form["txtSATipoMaquinas"]; }

        if (!string.IsNullOrEmpty(Request.Form["txtSACuestCausa2"])) { txtSACuestCausa2 = Request.Form["txtSACuestCausa2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAa2IniDroga"])) { txtSAa2IniDroga = Request.Form["txtSAa2IniDroga"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSANomRef2"])) { txtSANomRef2 = Request.Form["txtSANomRef2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAa2FinDroga"])) { txtSAa2FinDroga = Request.Form["txtSAa2FinDroga"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPade1"])) { txtSAPade1 = Request.Form["txtSAPade1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSANomHosp"])) { txtSANomHosp = Request.Form["txtSANomHosp"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSATelefono"])) { txtSATelefono = Request.Form["txtSATelefono"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACodCiudad"])) { txtSACodCiudad = Request.Form["txtSACodCiudad"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSAAfici"])) { chkSAAfici = Request.Form["chkSAAfici"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPoliza5"])) { txtSAPoliza5 = Request.Form["txtSAPoliza5"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAVivePadre"])) { txtSAVivePadre = Request.Form["txtSAVivePadre"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtCuest6aCual"])) { txtCuest6aCual = Request.Form["txtCuest6aCual"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPadeEdoAct3"])) { txtSAPadeEdoAct3 = Request.Form["txtSAPadeEdoAct3"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAm1IniAlcohol"])) { txtSAm1IniAlcohol = Request.Form["txtSAm1IniAlcohol"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSACuest3Si"])) { chkSACuest3Si = Request.Form["chkSACuest3Si"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPade4"])) { txtSAPade4 = Request.Form["txtSAPade4"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAOtroLugarTrabajo"])) { txtSAOtroLugarTrabajo = Request.Form["txtSAOtroLugarTrabajo"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSACigarros"])) { chkSACigarros = Request.Form["chkSACigarros"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSACuest1No"])) { chkSACuest1No = Request.Form["chkSACuest1No"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAInfAgt4"])) { txtSAInfAgt4 = Request.Form["txtSAInfAgt4"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAAlturaTrabajo"])) { txtSAAlturaTrabajo = Request.Form["txtSAAlturaTrabajo"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSAUsarMotoNo"])) { chkSAUsarMotoNo = Request.Form["chkSAUsarMotoNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAa1IniFumar"])) { txtSAa1IniFumar = Request.Form["txtSAa1IniFumar"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACuestCuando4"])) { txtSACuestCuando4 = Request.Form["txtSACuestCuando4"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSALugCal"])) { chkSALugCal = Request.Form["chkSALugCal"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAInfAgt2"])) { txtSAInfAgt2 = Request.Form["txtSAInfAgt2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAd2FinAlcohol"])) { txtSAd2FinAlcohol = Request.Form["txtSAd2FinAlcohol"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAm2FinDroga"])) { txtSAm2FinDroga = Request.Form["txtSAm2FinDroga"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSAAeroPartSi"])) { chkSAAeroPartSi = Request.Form["chkSAAeroPartSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPctAgt1"])) { txtSAPctAgt1 = Request.Form["txtSAPctAgt1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAEmailAgt"])) { txtSAEmailAgt = Request.Form["txtSAEmailAgt"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAEdoSAlMadre"])) { txtSAEdoSAlMadre = Request.Form["txtSAEdoSAlMadre"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtNombreFirmaContratante"])) { txtSANomCon = Request.Form["txtNombreFirmaContratante"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAEdoSAlHijos"])) { txtSAEdoSAlHijos = Request.Form["txtSAEdoSAlHijos"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAd1Papani"])) { txtSAd1Papani = Request.Form["txtSAd1Papani"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSALugOfc"])) { chkSALugOfc = Request.Form["chkSALugOfc"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSASustancias"])) { txtSASustancias = Request.Form["txtSASustancias"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSANumPre3"])) { txtSANumPre3 = Request.Form["txtSANumPre3"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPctAgt3"])) { txtSAPctAgt3 = Request.Form["txtSAPctAgt3"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAEvoPresion"])) { txtSAEvoPresion = Request.Form["txtSAEvoPresion"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACVEAgt1"])) { txtSACVEAgt1 = Request.Form["txtSACVEAgt1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACuestCausa4"])) { txtSACuestCausa4 = Request.Form["txtSACuestCausa4"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAEvoCardiaca"])) { txtSAEvoCardiaca = Request.Form["txtSAEvoCardiaca"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAEdoSAlHnos"])) { txtSAEdoSAlHnos = Request.Form["txtSAEdoSAlHnos"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSATraAltNo"])) { chkSATraAltNo = Request.Form["chkSATraAltNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSAPuro"])) { chkSAPuro = Request.Form["chkSAPuro"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAa1IniAlcohol"])) { txtSAa1IniAlcohol = Request.Form["txtSAa1IniAlcohol"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSAUsarMotoSi"])) { chkSAUsarMotoSi = Request.Form["chkSAUsarMotoSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSACubRiesDepoSi"])) { chkSACubRiesDepoSi = Request.Form["chkSACubRiesDepoSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSANomAgt3"])) { txtSANomAgt3 = Request.Form["txtSANomAgt3"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAMotDrogas"])) { txtSAMotDrogas = Request.Form["txtSAMotDrogas"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSANumPre2"])) { txtSANumPre2 = Request.Form["txtSANumPre2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACuestCausa3"])) { txtSACuestCausa3 = Request.Form["txtSACuestCausa3"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPadeDura1"])) { txtSAPadeDura1 = Request.Form["txtSAPadeDura1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAm1FinFumar"])) { txtSAm1FinFumar = Request.Form["txtSAm1FinFumar"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAm1Papani"])) { txtSAm1Papani = Request.Form["txtSAm1Papani"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFrecDrogas"])) { txtSAFrecDrogas = Request.Form["txtSAFrecDrogas"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSACuest6aSi"])) { chkSACuest6aSi = Request.Form["chkSACuest6aSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFolio13"])) { txtSAFolio13 = Request.Form["txtSAFolio13"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFecPade2"])) { txtSAFecPade2 = Request.Form["txtSAFecPade2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAd1Mamo"])) { txtSAd1Mamo = Request.Form["txtSAd1Mamo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACuest6c2Res"])) { txtSACuest6c2Res = Request.Form["txtSACuest6c2Res"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACuestCuando3"])) { txtSACuestCuando3 = Request.Form["txtSACuestCuando3"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACuestCuando2"])) { txtSACuestCuando2 = Request.Form["txtSACuestCuando2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFecPade4"])) { txtSAFecPade4 = Request.Form["txtSAFecPade4"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFecPade3"])) { txtSAFecPade3 = Request.Form["txtSAFecPade3"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSAReqViajarNo"])) { chkSAReqViajarNo = Request.Form["chkSAReqViajarNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAm2IniFumar"])) { txtSAm2IniFumar = Request.Form["txtSAm2IniFumar"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAViveHijos"])) { txtSAViveHijos = Request.Form["txtSAViveHijos"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFolio10"])) { txtSAFolio10 = Request.Form["txtSAFolio10"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPoliza2"])) { txtSAPoliza2 = Request.Form["txtSAPoliza2"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSAAmat"])) { chkSAAmat = Request.Form["chkSAAmat"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACausasMadre"])) { txtSACausasMadre = Request.Form["txtSACausasMadre"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAa2IniFumar"])) { txtSAa2IniFumar = Request.Form["txtSAa2IniFumar"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFolio1"])) { txtSAFolio1 = Request.Form["txtSAFolio1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAa1FinFumar"])) { txtSAa1FinFumar = Request.Form["txtSAa1FinFumar"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAEdoSAlPadre"])) { txtSAEdoSAlPadre = Request.Form["txtSAEdoSAlPadre"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAInfAgt6"])) { txtSAInfAgt6 = Request.Form["txtSAInfAgt6"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAInfAgt3"])) { txtSAInfAgt3 = Request.Form["txtSAInfAgt3"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPoliza1"])) { txtSAPoliza1 = Request.Form["txtSAPoliza1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPadeDura4"])) { txtSAPadeDura4 = Request.Form["txtSAPadeDura4"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSATipoFrecDrogas"])) { txtSATipoFrecDrogas = Request.Form["txtSATipoFrecDrogas"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFrecuenciaMoto"])) { txtSAFrecuenciaMoto = Request.Form["txtSAFrecuenciaMoto"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSANumCigarros"])) { txtSANumCigarros = Request.Form["txtSANumCigarros"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAOcupacion"])) { txtSAOcupacion = Request.Form["txtSAOcupacion"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSATelAgt"])) { txtSATelAgt = Request.Form["txtSATelAgt"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAQuienPresion"])) { txtSAQuienPresion = Request.Form["txtSAQuienPresion"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSAOcupacionSi"])) { chkSAOcupacionSi = Request.Form["chkSAOcupacionSi"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAa1FinAlcohol"])) { txtSAa1FinAlcohol = Request.Form["txtSAa1FinAlcohol"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPctAgt2"])) { txtSAPctAgt2 = Request.Form["txtSAPctAgt2"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFrecFumar"])) { txtSAFrecFumar = Request.Form["txtSAFrecFumar"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAEdadPadre"])) { txtSAEdadPadre = Request.Form["txtSAEdadPadre"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAm1IniDroga"])) { txtSAm1IniDroga = Request.Form["txtSAm1IniDroga"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSACuest2No"])) { chkSACuest2No = Request.Form["chkSACuest2No"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSACubRiesDepoNo"])) { chkSACubRiesDepoNo = Request.Form["chkSACubRiesDepoNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAm2FinFumar"])) { txtSAm2FinFumar = Request.Form["txtSAm2FinFumar"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAEdadFalleHnos"])) { txtSAEdadFalleHnos = Request.Form["txtSAEdadFalleHnos"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAm1IniFumar"])) { txtSAm1IniFumar = Request.Form["txtSAm1IniFumar"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSACuest6aNo"])) { chkSACuest6aNo = Request.Form["chkSACuest6aNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAa2Papani"])) { txtSAa2Papani = Request.Form["txtSAa2Papani"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSACuest2Si"])) { chkSACuest2Si = Request.Form["chkSACuest2Si"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAa2IniAlcohol"])) { txtSAa2IniAlcohol = Request.Form["txtSAa2IniAlcohol"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAd1FinDroga"])) { txtSAd1FinDroga = Request.Form["txtSAd1FinDroga"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAEdadMadre"])) { txtSAEdadMadre = Request.Form["txtSAEdadMadre"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAMotFumar"])) { txtSAMotFumar = Request.Form["txtSAMotFumar"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPadeEdoAct1"])) { txtSAPadeEdoAct1 = Request.Form["txtSAPadeEdoAct1"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAEdadHnos"])) { txtSAEdadHnos = Request.Form["txtSAEdadHnos"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAEdadFalleMadre"])) { txtSAEdadFalleMadre = Request.Form["txtSAEdadFalleMadre"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSACuest3No"])) { chkSACuest3No = Request.Form["chkSACuest3No"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSAAeroPartNo"])) { chkSAAeroPartNo = Request.Form["chkSAAeroPartNo"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSACuestKgAum"])) { txtSACuestKgAum = Request.Form["txtSACuestKgAum"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAd2IniAlcohol"])) { txtSAd2IniAlcohol = Request.Form["txtSAd2IniAlcohol"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSATelRef2"])) { txtSATelRef2 = Request.Form["txtSATelRef2"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSAInfAgt8No"])) { chkSAInfAgt8No = Request.Form["chkSAInfAgt8No"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAa2FinFumar"])) { txtSAa2FinFumar = Request.Form["txtSAa2FinFumar"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAd2FinFumar"])) { txtSAd2FinFumar = Request.Form["txtSAd2FinFumar"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtCuest6bCuant"])) { txtCuest6bCuant = Request.Form["txtCuest6bCuant"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAMotAlcohol"])) { txtSAMotAlcohol = Request.Form["txtSAMotAlcohol"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPoliza3"])) { txtSAPoliza3 = Request.Form["txtSAPoliza3"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAGiroEmpresa"])) { txtSAGiroEmpresa = Request.Form["txtSAGiroEmpresa"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAFrecAlcohol"])) { txtSAFrecAlcohol = Request.Form["txtSAFrecAlcohol"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSAProfe"])) { chkSAProfe = Request.Form["chkSAProfe"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAd2Mamo"])) { txtSAd2Mamo = Request.Form["txtSAd2Mamo"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSAInfAgt7Si"])) { chkSAInfAgt7Si = Request.Form["chkSAInfAgt7Si"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAQuienCardiaca"])) { txtSAQuienCardiaca = Request.Form["txtSAQuienCardiaca"]; }
        if (!string.IsNullOrEmpty(Request.Form["chkSACuest1Si"])) { chkSACuest1Si = Request.Form["chkSACuest1Si"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAQuienCancer"])) { txtSAQuienCancer = Request.Form["txtSAQuienCancer"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSANumPre4"])) { txtSANumPre4 = Request.Form["txtSANumPre4"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAPoliza6"])) { txtSAPoliza6 = Request.Form["txtSAPoliza6"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSANomSoli"])) { txtSANomSoli = Request.Form["txtSANomSoli"]; }
        if (!string.IsNullOrEmpty(Request.Form["txtSAa2Mamo"])) { txtSAa2Mamo = Request.Form["txtSAa2Mamo"]; }
        //verif
        //if (txtEstadoProvinciaSolicitante != "" && txtMunicipioDelegacionSolicitante != "") { txtSolLugaryFecha = txtMunicipioDelegacionSolicitante + ", " + txtEstadoProvinciaSolicitante + " " + DateTime.Today.ToString("dd MM yyyy"); }
        if (!string.IsNullOrEmpty(Request.Form["txtEstadoProvinciaSolicitante"]) && !string.IsNullOrEmpty(Request.Form["txtMunicipioDelegacionSolicitante"])) { txtSALugaryFecha = Request.Form["txtMunicipioDelegacionSolicitante"] + ", " + Request.Form["txtEstadoProvinciaSolicitante"] + " " + DateTime.Today.ToString("dd MM yyy"); }
        #endregion

        #region comment
        //pdfFormFields.SetField("txtSAPade3", txtSAPade3);
        //pdfFormFields.SetField("txtSAPadeEdoAct2", txtSAPadeEdoAct2);
        //pdfFormFields.SetField("txtSAm1FinAlcohol", txtSAm1FinAlcohol);
        //pdfFormFields.SetField("txtSAa1FinDroga", txtSAa1FinDroga);
        //pdfFormFields.SetField("txtSANomAgt1", txtSANomAgt1);
        //pdfFormFields.SetField("txtSACVEAgt3", txtSACVEAgt3);
        //pdfFormFields.SetField("txtSAFolio4", txtSAFolio4);
        //pdfFormFields.SetField("txtSANumPre1", txtSANumPre1);
        //pdfFormFields.SetField("txtSANomRef1", txtSANomRef1);
        //pdfFormFields.SetField("txtSAPadeDura2", txtSAPadeDura2);
        //pdfFormFields.SetField("txtSAd2FinDroga", txtSAd2FinDroga);
        //pdfFormFields.SetField("txtSAEvoCancer", txtSAEvoCancer);
        //pdfFormFields.SetField("txtSAEvoDiabetes", txtSAEvoDiabetes);
        //pdfFormFields.SetField("txtSAa2FinAlcohol", txtSAa2FinAlcohol);
        //pdfFormFields.SetField("txtSANomAgt2", txtSANomAgt2);
        //pdfFormFields.SetField("txtSAa1Mamo", txtSAa1Mamo);
        //pdfFormFields.SetField("txtSAFolio8", txtSAFolio8);
        //pdfFormFields.SetField("txtSAPoliza9", txtSAPoliza9);
        //pdfFormFields.SetField("txtSAInfAgt1", txtSAInfAgt1);
        //pdfFormFields.SetField("txtSAPadeEdoAct4", txtSAPadeEdoAct4);
        //pdfFormFields.SetField("chkSACuest4No", chkSACuest4No);
        //pdfFormFields.SetField("txtSAm1FinDroga", txtSAm1FinDroga);
        //pdfFormFields.SetField("txtSACuestCausa1", txtSACuestCausa1);
        //pdfFormFields.SetField("chkSACuest5Si", chkSACuest5Si);
        //pdfFormFields.SetField("txtSAEdadHijos", txtSAEdadHijos);
        //pdfFormFields.SetField("txtSAd1IniDroga", txtSAd1IniDroga);
        //pdfFormFields.SetField("txtSACausasHIjos", txtSACausasHIjos);
        //pdfFormFields.SetField("txtSAa1Papani", txtSAa1Papani);
        //pdfFormFields.SetField("txtSACuestKgDism", txtSACuestKgDism);
        //pdfFormFields.SetField("txtSAEdadFallePadre", txtSAEdadFallePadre);
        //pdfFormFields.SetField("txtSAm2Papani", txtSAm2Papani);
        //pdfFormFields.SetField("txtSAFecPade1", txtSAFecPade1);
        //pdfFormFields.SetField("txtSAPoliza11", txtSAPoliza11);
        //pdfFormFields.SetField("txtSATelRef1", txtSATelRef1);
        //pdfFormFields.SetField("txtSAd1IniAlcohol", txtSAd1IniAlcohol);
        //pdfFormFields.SetField("txtSAPoliza13", txtSAPoliza13);
        //pdfFormFields.SetField("txtSANomContra", txtSANomContra);
        //pdfFormFields.SetField("chkSACuest5No", chkSACuest5No);
        //pdfFormFields.SetField("txtSAm2IniAlcohol", txtSAm2IniAlcohol);
        //pdfFormFields.SetField("txtSAd2IniDroga", txtSAd2IniDroga);
        //pdfFormFields.SetField("txtSAViveHnos", txtSAViveHnos);
        //pdfFormFields.SetField("chkSAReqViajarSi", chkSAReqViajarSi);
        //pdfFormFields.SetField("txtSAPoliza4", txtSAPoliza4);
        //pdfFormFields.SetField("chkSATraAltSi", chkSATraAltSi);
        //pdfFormFields.SetField("chkSAOcupacionNo", chkSAOcupacionNo);
        //pdfFormFields.SetField("txtSACausasPadre", txtSACausasPadre);
        //pdfFormFields.SetField("chkSAInfAgt8Si", chkSAInfAgt8Si);
        //pdfFormFields.SetField("txtSAd2IniFumar", txtSAd2IniFumar);
        //pdfFormFields.SetField("txtSACausasHnos", txtSACausasHnos);
        //pdfFormFields.SetField("txtSADomRef1", txtSADomRef1);
        //pdfFormFields.SetField("txtSAd1FinAlcohol", txtSAd1FinAlcohol);
        //pdfFormFields.SetField("txtSAFolio11", txtSAFolio11);
        //pdfFormFields.SetField("txtSAPoliza10", txtSAPoliza10);
        //pdfFormFields.SetField("txtSAPoliza7", txtSAPoliza7);
        //pdfFormFields.SetField("txtSAPoliza12", txtSAPoliza12);
        //pdfFormFields.SetField("txtSAFolio12", txtSAFolio12);
        //pdfFormFields.SetField("chkSALugFab", chkSALugFab);
        //pdfFormFields.SetField("txtSAClavePais", txtSAClavePais);
        //pdfFormFields.SetField("txtSAm2Mamo", txtSAm2Mamo);
        //pdfFormFields.SetField("chkSAPipa", chkSAPipa);
        //pdfFormFields.SetField("txtSAm2FinAlcohol", txtSAm2FinAlcohol);
        //pdfFormFields.SetField("txtSADomRef2", txtSADomRef2);
        //pdfFormFields.SetField("chkSACuest6bSi", chkSACuest6bSi);
        //pdfFormFields.SetField("txtSAPadeDura3", txtSAPadeDura3);
        //pdfFormFields.SetField("chkSACuest4Si", chkSACuest4Si);
        //pdfFormFields.SetField("txtSAQuienDiabetes", txtSAQuienDiabetes);
        //pdfFormFields.SetField("txtSAm2IniDroga", txtSAm2IniDroga);
        //pdfFormFields.SetField("txtSAd1FinFumar", txtSAd1FinFumar);
        //pdfFormFields.SetField("txtSANomDomiDr", txtSANomDomiDr);
        //pdfFormFields.SetField("txtSANomSol", txtSANomSol);
        //pdfFormFields.SetField("txtSAEdadFalleHijos", txtSAEdadFalleHijos);
        //pdfFormFields.SetField("txtSAm1Mamo", txtSAm1Mamo);
        //pdfFormFields.SetField("txtSAAeronaveHoras", txtSAAeronaveHoras);
        //pdfFormFields.SetField("txtSANumCopas", txtSANumCopas);
        //pdfFormFields.SetField("txtSAViveMadre", txtSAViveMadre);
        //pdfFormFields.SetField("txtSACVEAgt2", txtSACVEAgt2);
        //pdfFormFields.SetField("txtSAa1IniDroga", txtSAa1IniDroga);
        //pdfFormFields.SetField("txtSAFolio9", txtSAFolio9);
        //pdfFormFields.SetField("chkSALugTal", chkSALugTal);
        //pdfFormFields.SetField("txtSACuest6c1Res", txtSACuest6c1Res);
        //pdfFormFields.SetField("chkSAInfAgt7No", chkSAInfAgt7No);
        //pdfFormFields.SetField("txtSAFolio5", txtSAFolio5);
        //pdfFormFields.SetField("txtSAPoliza8", txtSAPoliza8);
        //pdfFormFields.SetField("txtSAFolio7", txtSAFolio7);
        //pdfFormFields.SetField("txtSAFolio6", txtSAFolio6);
        //pdfFormFields.SetField("txtSAd1IniFumar", txtSAd1IniFumar);
        //pdfFormFields.SetField("txtSAPade2", txtSAPade2);
        //pdfFormFields.SetField("txtSAFolio3", txtSAFolio3);
        //pdfFormFields.SetField("txtSAFolio2", txtSAFolio2);
        //pdfFormFields.SetField("txtSAd2Papani", txtSAd2Papani);
        //pdfFormFields.SetField("chkSACuest6bNo", chkSACuest6bNo);
        //pdfFormFields.SetField("txtSATipoTransporte", txtSATipoTransporte);
        //pdfFormFields.SetField("txtSACuestCausa2", txtSACuestCausa2);
        //pdfFormFields.SetField("txtSAa2IniDroga", txtSAa2IniDroga);
        //pdfFormFields.SetField("txtSANomRef2", txtSANomRef2);
        //pdfFormFields.SetField("txtSAa2FinDroga", txtSAa2FinDroga);
        //pdfFormFields.SetField("txtSAPade1", txtSAPade1);
        //pdfFormFields.SetField("txtSANomHosp", txtSANomHosp);
        //pdfFormFields.SetField("txtSATelefono", txtSATelefono);
        //pdfFormFields.SetField("txtSACodCiudad", txtSACodCiudad);
        //pdfFormFields.SetField("chkSAAfici", chkSAAfici);
        //pdfFormFields.SetField("txtSAPoliza5", txtSAPoliza5);
        //pdfFormFields.SetField("txtSAVivePadre", txtSAVivePadre);
        //pdfFormFields.SetField("txtCuest6aCual", txtCuest6aCual);
        //pdfFormFields.SetField("txtSAPadeEdoAct3", txtSAPadeEdoAct3);
        //pdfFormFields.SetField("txtSAm1IniAlcohol", txtSAm1IniAlcohol);
        //pdfFormFields.SetField("chkSACuest3Si", chkSACuest3Si);
        //pdfFormFields.SetField("txtSAPade4", txtSAPade4);
        //pdfFormFields.SetField("txtSAOtroLugarTrabajo", txtSAOtroLugarTrabajo);
        //pdfFormFields.SetField("chkSACigarros", chkSACigarros);
        //pdfFormFields.SetField("chkSACuest1No", chkSACuest1No);
        //pdfFormFields.SetField("txtSAInfAgt4", txtSAInfAgt4);
        //pdfFormFields.SetField("txtSAAlturaTrabajo", txtSAAlturaTrabajo);
        //pdfFormFields.SetField("chkSAUsarMotoNo", chkSAUsarMotoNo);
        //pdfFormFields.SetField("txtSAa1IniFumar", txtSAa1IniFumar);
        //pdfFormFields.SetField("txtSACuestCuando4", txtSACuestCuando4);
        //pdfFormFields.SetField("chkSALugCal", chkSALugCal);
        //pdfFormFields.SetField("txtSAInfAgt2", txtSAInfAgt2);
        //pdfFormFields.SetField("txtSAd2FinAlcohol", txtSAd2FinAlcohol);
        //pdfFormFields.SetField("txtSAm2FinDroga", txtSAm2FinDroga);
        //pdfFormFields.SetField("chkSAAeroPartSi", chkSAAeroPartSi);
        //pdfFormFields.SetField("txtSAPctAgt1", txtSAPctAgt1);
        //pdfFormFields.SetField("txtSAEmailAgt", txtSAEmailAgt);
        //pdfFormFields.SetField("txtSAEdoSAlMadre", txtSAEdoSAlMadre);
        //pdfFormFields.SetField("txtSANomCon", txtSANomCon);
        //pdfFormFields.SetField("txtSAEdoSAlHijos", txtSAEdoSAlHijos);
        //pdfFormFields.SetField("txtSAd1Papani", txtSAd1Papani);
        //pdfFormFields.SetField("chkSALugOfc", chkSALugOfc);
        //pdfFormFields.SetField("txtSASustancias", txtSASustancias);
        //pdfFormFields.SetField("txtSANumPre3", txtSANumPre3);
        //pdfFormFields.SetField("txtSAPctAgt3", txtSAPctAgt3);
        //pdfFormFields.SetField("txtSAEvoPresion", txtSAEvoPresion);
        //pdfFormFields.SetField("txtSACVEAgt1", txtSACVEAgt1);
        //pdfFormFields.SetField("txtSACuestCausa4", txtSACuestCausa4);
        //pdfFormFields.SetField("txtSAEvoCardiaca", txtSAEvoCardiaca);
        //pdfFormFields.SetField("txtSAEdoSAlHnos", txtSAEdoSAlHnos);
        //pdfFormFields.SetField("chkSATraAltNo", chkSATraAltNo);
        //pdfFormFields.SetField("chkSAPuro", chkSAPuro);
        //pdfFormFields.SetField("txtSAa1IniAlcohol", txtSAa1IniAlcohol);
        //pdfFormFields.SetField("chkSAUsarMotoSi", chkSAUsarMotoSi);
        //pdfFormFields.SetField("chkSACubRiesDepoSi", chkSACubRiesDepoSi);
        //pdfFormFields.SetField("txtSANomAgt3", txtSANomAgt3);
        //pdfFormFields.SetField("txtSAMotDrogas", txtSAMotDrogas);
        //pdfFormFields.SetField("txtSANumPre2", txtSANumPre2);
        //pdfFormFields.SetField("txtSACuestCausa3", txtSACuestCausa3);
        //pdfFormFields.SetField("txtSAPadeDura1", txtSAPadeDura1);
        //pdfFormFields.SetField("txtSAm1FinFumar", txtSAm1FinFumar);
        //pdfFormFields.SetField("txtSAm1Papani", txtSAm1Papani);
        //pdfFormFields.SetField("txtSAFrecDrogas", txtSAFrecDrogas);
        //pdfFormFields.SetField("chkSACuest6aSi", chkSACuest6aSi);
        //pdfFormFields.SetField("txtSAFolio13", txtSAFolio13);
        //pdfFormFields.SetField("txtSAFecPade2", txtSAFecPade2);
        //pdfFormFields.SetField("txtSAd1Mamo", txtSAd1Mamo);
        //pdfFormFields.SetField("txtSACuest6c2Res", txtSACuest6c2Res);
        //pdfFormFields.SetField("txtSACuestCuando3", txtSACuestCuando3);
        //pdfFormFields.SetField("txtSACuestCuando2", txtSACuestCuando2);
        //pdfFormFields.SetField("txtSAFecPade4", txtSAFecPade4);
        //pdfFormFields.SetField("txtSAFecPade3", txtSAFecPade3);
        //pdfFormFields.SetField("chkSAReqViajarNo", chkSAReqViajarNo);
        //pdfFormFields.SetField("txtSAm2IniFumar", txtSAm2IniFumar);
        //pdfFormFields.SetField("txtSAViveHijos", txtSAViveHijos);
        //pdfFormFields.SetField("txtSAFolio10", txtSAFolio10);
        //pdfFormFields.SetField("txtSAPoliza2", txtSAPoliza2);
        //pdfFormFields.SetField("chkSAAmat", chkSAAmat);
        //pdfFormFields.SetField("txtSACausasMadre", txtSACausasMadre);
        //pdfFormFields.SetField("txtSAa2IniFumar", txtSAa2IniFumar);
        //pdfFormFields.SetField("txtSAFolio1", txtSAFolio1);
        //pdfFormFields.SetField("txtSAa1FinFumar", txtSAa1FinFumar);
        //pdfFormFields.SetField("txtSAEdoSAlPadre", txtSAEdoSAlPadre);
        //pdfFormFields.SetField("txtSAInfAgt6", txtSAInfAgt6);
        //pdfFormFields.SetField("txtSAInfAgt3", txtSAInfAgt3);
        //pdfFormFields.SetField("txtSAPoliza1", txtSAPoliza1);
        //pdfFormFields.SetField("txtSAPadeDura4", txtSAPadeDura4);
        //pdfFormFields.SetField("txtSATipoFrecDrogas", txtSATipoFrecDrogas);
        //pdfFormFields.SetField("txtSAFrecuenciaMoto", txtSAFrecuenciaMoto);
        //pdfFormFields.SetField("txtSANumCigarros", txtSANumCigarros);
        //pdfFormFields.SetField("txtSAOcupacion", txtSAOcupacion);
        //pdfFormFields.SetField("txtSATelAgt", txtSATelAgt);
        //pdfFormFields.SetField("txtSAQuienPresion", txtSAQuienPresion);
        //pdfFormFields.SetField("chkSAOcupacionSi", chkSAOcupacionSi);
        //pdfFormFields.SetField("txtSAa1FinAlcohol", txtSAa1FinAlcohol);
        //pdfFormFields.SetField("txtSAPctAgt2", txtSAPctAgt2);
        //pdfFormFields.SetField("txtSAFrecFumar", txtSAFrecFumar);
        //pdfFormFields.SetField("txtSAEdadPadre", txtSAEdadPadre);
        //pdfFormFields.SetField("txtSAm1IniDroga", txtSAm1IniDroga);
        //pdfFormFields.SetField("chkSACuest2No", chkSACuest2No);
        //pdfFormFields.SetField("chkSACubRiesDepoNo", chkSACubRiesDepoNo);
        //pdfFormFields.SetField("txtSAm2FinFumar", txtSAm2FinFumar);
        //pdfFormFields.SetField("txtSAEdadFalleHnos", txtSAEdadFalleHnos);
        //pdfFormFields.SetField("txtSAm1IniFumar", txtSAm1IniFumar);
        //pdfFormFields.SetField("chkSACuest6aNo", chkSACuest6aNo);
        //pdfFormFields.SetField("txtSAa2Papani", txtSAa2Papani);
        //pdfFormFields.SetField("chkSACuest2Si", chkSACuest2Si);
        //pdfFormFields.SetField("txtSAa2IniAlcohol", txtSAa2IniAlcohol);
        //pdfFormFields.SetField("txtSAd1FinDroga", txtSAd1FinDroga);
        //pdfFormFields.SetField("txtSAEdadMadre", txtSAEdadMadre);
        //pdfFormFields.SetField("txtSAMotFumar", txtSAMotFumar);
        //pdfFormFields.SetField("txtSAPadeEdoAct1", txtSAPadeEdoAct1);
        //pdfFormFields.SetField("txtSAEdadHnos", txtSAEdadHnos);
        //pdfFormFields.SetField("txtSAEdadFalleMadre", txtSAEdadFalleMadre);
        //pdfFormFields.SetField("chkSACuest3No", chkSACuest3No);
        //pdfFormFields.SetField("chkSAAeroPartNo", chkSAAeroPartNo);
        //pdfFormFields.SetField("txtSACuestKgAum", txtSACuestKgAum);
        //pdfFormFields.SetField("txtSAd2IniAlcohol", txtSAd2IniAlcohol);
        //pdfFormFields.SetField("txtSATelRef2", txtSATelRef2);
        //pdfFormFields.SetField("chkSAInfAgt8No", chkSAInfAgt8No);
        //pdfFormFields.SetField("txtSAa2FinFumar", txtSAa2FinFumar);
        //pdfFormFields.SetField("txtSAd2FinFumar", txtSAd2FinFumar);
        //pdfFormFields.SetField("txtCuest6bCuant", txtCuest6bCuant);
        //pdfFormFields.SetField("txtSAMotAlcohol", txtSAMotAlcohol);
        //pdfFormFields.SetField("txtSAPoliza3", txtSAPoliza3);
        //pdfFormFields.SetField("txtSAGiroEmpresa", txtSAGiroEmpresa);
        //pdfFormFields.SetField("txtSAFrecAlcohol", txtSAFrecAlcohol);
        //pdfFormFields.SetField("chkSAProfe", chkSAProfe);
        //pdfFormFields.SetField("txtSAd2Mamo", txtSAd2Mamo);
        //pdfFormFields.SetField("chkSAInfAgt7Si", chkSAInfAgt7Si);
        //pdfFormFields.SetField("txtSAQuienCardiaca", txtSAQuienCardiaca);
        //pdfFormFields.SetField("chkSACuest1Si", chkSACuest1Si);
        //pdfFormFields.SetField("txtSAQuienCancer", txtSAQuienCancer);
        //pdfFormFields.SetField("txtSANumPre4", txtSANumPre4);
        //pdfFormFields.SetField("txtSAPoliza6", txtSAPoliza6);
        //pdfFormFields.SetField("txtSANomSoli", txtSANomSoli);
        //pdfFormFields.SetField("txtSAa2Mamo", txtSAa2Mamo);
        //pdfFormFields.SetField("txtSALugaryFecha", txtSALugaryFecha);
        #endregion
        //GenerarXML
        XElement ROOT = new XElement("ROOT");
        ROOT.Add(new XElement("COMPANIA", "1"));
        ROOT.Add(new XElement("RAMO", "100"));
        ROOT.Add(new XElement("ACTIVIDAD", "EMISION"));
        ROOT.Add(new XElement("IDIOMA", "mx_ES"));

        #region DISTRIBUCION
        XElement DISTRIBUCION = new XElement("DISTRIBUCION");

        DISTRIBUCION.Add(new XElement("DUPLEX_MODE", "FALSE"));
        DISTRIBUCION.Add(new XElement("LOCAL", "TRUE"));


        //Usuario objUsuario = new Usuario();

        //if (Session["sUSUARIO"] != null)
        //{
        //    objUsuario = ((Usuario)Session["sUSUARIO"]);

        //Agregado
        #region WEB
        XElement WEB = new XElement("WEB");

        WEB.Add(new XElement("WEB_EMAIL_TO", ""));
        WEB.Add(new XElement("WEB_EMAIL_FROM", "servicioDocumental@mapfre.com.mx"));
        WEB.Add(new XElement("WEB_EMAIL_REPLY_TO"));
        WEB.Add(new XElement("WEB_EMAIL_ASUNTO", "Prueba"));
        WEB.Add(new XElement("WEB_EMAIL_CC"));
        WEB.Add(new XElement("WEB_EMAIL_BCC"));


        DISTRIBUCION.Add(WEB);

        #endregion WEB

        #region EMAIL
        XElement EMAIL = new XElement("EMAIL");

        EMAIL.Add(new XElement("EMAIL_TO", ""));
        EMAIL.Add(new XElement("EMAIL_FROM", "servicioDocumental@mapfre.com.mx"));
        EMAIL.Add(new XElement("EMAIL_REPLY_TO"));
        EMAIL.Add(new XElement("EMAIL_ASUNTO", ""));
        EMAIL.Add(new XElement("EMAIL_CC"));
        EMAIL.Add(new XElement("EMAIL_BCC"));


        DISTRIBUCION.Add(EMAIL);
        #endregion EMAIL

        #region GESTOR_DOCUMENTAL
        XElement GESTOR_DOC = new XElement("GESTOR_DOCUMENTAL");

        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_SFILENAME", ""));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_FOLDER", "/MAPFRE/EMISION/Vida/"));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_OBJETO", "mmx_anexo"));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_CODCIA", "1"));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_NUMPOLIZA", ""));
        GESTOR_DOC.Add(new XElement("GD_ATRIBUTO_NUMSUPLEMENTO"));


        DISTRIBUCION.Add(GESTOR_DOC);

        #endregion GESTOR_DOCUMENTAL

        ROOT.Add(DISTRIBUCION);

        #endregion DISTRIBUCION

        #region ANEXO
        XElement ANEXO = new XElement("ANEXO");

        #region CABECERA


        XElement CABECERA = new XElement("CABECERA");

        CABECERA.Add(new XElement("IMAGEN", "LOGO_MAPFRE_FONDO_BLANCO.jpg"));
        CABECERA.Add(new XElement("LEYENDA_UNO_ENCABEZADO", "EV_SOLICITUD_MONTO_SA.rtf"));
        CABECERA.Add(new XElement("DOMICILIO", "SV_DOMICILIO_SOLICITUD.rtf"));
        CABECERA.Add(new XElement("NUMERO_FOLIO", ""));
        CABECERA.Add(new XElement("NUMERO_POLIZA", ""));
        CABECERA.Add(new XElement("LEYENDA_DOS_ENCABEZADO", "EV_LLENADO_SOLICITUD.rtf"));

        ANEXO.Add(CABECERA);

        #endregion CABECERA

        #region INFORMACION_SOLICITANTE

        XElement INFORMACION_SOLICITANTE = new XElement("INFORMACION_SOLICITANTE");


        INFORMACION_SOLICITANTE.Add(new XElement("TITULO", "INFORMACION LABORAL DEL SOLICITANTE"));

        string chkOc = "FALSE";
        if (Request.Form["chkSAOcupacionSi"] == "Yes")
        {
            chkOc = "TRUE";
        }

        string chkRq = "FALSE";
        if (Request.Form["chkSAReqViajarSi"] == "Yes")
        {
            chkRq = "TRUE";
        }
        string chkAP = "FALSE";
        if (Request.Form["chkSAAeroPartSi"] == "Yes")
        {
            chkAP = "TRUE";
        }
        string chkUM = "FALSE";
        if (Request.Form["chkSAUsarMotoSi"] == "Yes")
        {
            chkUM = "TRUE";
        }
        string chkTA = "FALSE";
        if (Request.Form["chkSATraAltSi"] == "Yes")
        {
            chkTA = "TRUE";
        }

        //PERSONA FISICA
        XElement PERSONA_FISICA = new XElement("PERSONA_FISICA");
        PERSONA_FISICA.Add(new XElement("GIRO_EMPRESA", txtSAGiroEmpresa));
        PERSONA_FISICA.Add(new XElement("TELEFONO", txtSATelefono));
        PERSONA_FISICA.Add(new XElement("CLAVE_DE_PAIS", txtSAClavePais));
        PERSONA_FISICA.Add(new XElement("CODIGO_DE_CIUDAD", txtSACodCiudad));
        //2605
        PERSONA_FISICA.Add(new XElement("TIPO_MAQUINAS", txtSASustancias));
        PERSONA_FISICA.Add(new XElement("OTRA_OCUPACION", chkOc));
        PERSONA_FISICA.Add(new XElement("OCUPACION", txtSAOcupacion));
        PERSONA_FISICA.Add(new XElement("REQUIERE_VIAJAR", chkRq));
        PERSONA_FISICA.Add(new XElement("TIPO_TRANSPORTE", txtSATipoTransporte));
        PERSONA_FISICA.Add(new XElement("AERONAVES_PARTICULARES", chkAP));
        PERSONA_FISICA.Add(new XElement("TIPO_Y_HORAS_VUELO", txtSAAeronaveHoras));
        PERSONA_FISICA.Add(new XElement("UTILIZA_MOTOCICLETA", chkUM));
        PERSONA_FISICA.Add(new XElement("FRECUENCIA_Y_USO", txtSAFrecuenciaMoto));
        PERSONA_FISICA.Add(new XElement("TRABAJA_EN_ALTURAS", chkTA));
        PERSONA_FISICA.Add(new XElement("ALTURA_PROMEDIO", txtSAAlturaTrabajo));

        string chkOF = "FALSE";
        if (Request.Form["chkSALugOfc"] == "Yes")
        {
            chkOF = "TRUE";
        }
        string chkFa = "FALSE";
        if (Request.Form["chkSALugFab"] == "Yes")
        {
            chkFa = "TRUE";
        }
        string chkTa = "FALSE";
        if (Request.Form["chkSALugTal"] == "Yes")
        {
            chkTa = "TRUE";
        }
        string chkCa = "FALSE";
        if (Request.Form["chkSALugCal"] == "Yes")
        {
            chkCa = "TRUE";
        }
        XElement LUGAR_TRABAJO = new XElement("LUGAR_TRABAJO");
        LUGAR_TRABAJO.Add(new XElement("OFICINA", chkOF));
        LUGAR_TRABAJO.Add(new XElement("FABRICA", chkFa));
        LUGAR_TRABAJO.Add(new XElement("TALLER", chkTa));
        LUGAR_TRABAJO.Add(new XElement("CALLE", chkCa));
        LUGAR_TRABAJO.Add(new XElement("OTRO", txtSAOtroLugarTrabajo));

        PERSONA_FISICA.Add(LUGAR_TRABAJO);

        INFORMACION_SOLICITANTE.Add(PERSONA_FISICA);

        INFORMACION_SOLICITANTE.Add(new XElement("LEYENDA_UNO_SOLICITANTE", "EV_REFERENCIAS_INFO_LABORAL.rtf"));

        ANEXO.Add(INFORMACION_SOLICITANTE);

        #endregion INFORMACION_SOLICITANTE

        #region DEPORTES_O_AFICION
        XElement DEPORTES_O_AFICION = new XElement("DEPORTES_O_AFICION");
        DEPORTES_O_AFICION.Add(new XElement("TITULO", "DEPORTES Y/O AFICION"));

        string chkPr = "FALSE";
        if (Request.Form["chkSAProfe"] == "Yes")
        {
            chkPr = "TRUE";
        }
        string chkAf = "FALSE";
        if (Request.Form["chkSAAfici"] == "Yes")
        {
            chkAf = "TRUE";
        }
        string chkAm = "FALSE";
        if (Request.Form["chkSAAmat"] == "Yes")
        {
            chkAm = "TRUE";
        }


        XElement TIPO_DE_PRACTICA = new XElement("TIPO_DE_PRACTICA");
        TIPO_DE_PRACTICA.Add(new XElement("PROFESIONAL", chkPr));
        TIPO_DE_PRACTICA.Add(new XElement("AFICIONADO", chkAf));
        TIPO_DE_PRACTICA.Add(new XElement("AMATEUR", chkAm));

        DEPORTES_O_AFICION.Add(TIPO_DE_PRACTICA);

        string chkCr = "FALSE";
        if (Request.Form["chkSACubRiesDepoSi"] == "Yes")
        {
            chkCr = "TRUE";
        }


        DEPORTES_O_AFICION.Add(new XElement("DESEA_CUBRIR_RIESGO", chkCr));

        ANEXO.Add(DEPORTES_O_AFICION);
        #endregion DEPORTES_O_AFICION

        #region HABITOS
        XElement HABITOS = new XElement("HABITOS");
        HABITOS.Add(new XElement("TITULO", "HABITOS"));

        XElement PREGUNTA = new XElement("PREGUNTA");
        PREGUNTA.Add(new XElement("RESPUESTA_UNO", txtSANumCopas));
        PREGUNTA.Add(new XElement("RESPUESTA_DOS", txtSAFrecAlcohol));
        PREGUNTA.Add(new XElement("FECHA_INICIO", txtSAd1IniAlcohol + txtSAd2IniAlcohol + txtSAm1IniAlcohol + txtSAm2IniAlcohol + txtSAa1IniAlcohol + txtSAa2IniAlcohol));
        PREGUNTA.Add(new XElement("FECHA_TERMINO", txtSAd1FinAlcohol + txtSAd2FinAlcohol + txtSAm1FinAlcohol + txtSAm2FinAlcohol + txtSAa1FinAlcohol + txtSAa2FinAlcohol));
        PREGUNTA.Add(new XElement("MOTIVO", txtSAMotAlcohol));

        HABITOS.Add(PREGUNTA);

        XElement PREGUNTA1 = new XElement("PREGUNTA");

        string chkPuro = "FALSE";
        if (Request.Form["chkSAPuro"] == "Yes")
        {
            chkPuro = "TRUE";
        }

        string chkPipa = "FALSE";
        if (Request.Form["chkSAPipa"] == "Yes")
        {
            chkPipa = "TRUE";
        }

        string chkCiga = "FALSE";
        if (Request.Form["chkSACigarros"] == "Yes")
        {
            chkCiga = "TRUE";
        }


        XElement RESPUESTA_UNO = new XElement("RESPUESTA_UNO");
        RESPUESTA_UNO.Add(new XElement("CIGARROS", chkCiga));
        RESPUESTA_UNO.Add(new XElement("PURO", chkPuro));
        RESPUESTA_UNO.Add(new XElement("PIPA", chkPipa));
        RESPUESTA_UNO.Add(new XElement("CANTIDAD", txtSANumCigarros));

        PREGUNTA1.Add(RESPUESTA_UNO);

        PREGUNTA1.Add(new XElement("RESPUESTA_DOS", txtSAFrecFumar));
        PREGUNTA1.Add(new XElement("FECHA_INICIO", txtSAd1IniFumar + txtSAd2IniFumar + txtSAm1IniFumar + txtSAm2IniFumar + txtSAa1IniFumar + txtSAa2IniFumar));
        PREGUNTA1.Add(new XElement("FECHA_TERMINO", txtSAd1FinFumar + txtSAd2FinFumar + txtSAm1FinFumar + txtSAm2FinFumar + txtSAa1FinFumar + txtSAa2FinFumar));
        PREGUNTA1.Add(new XElement("MOTIVO", txtSAMotFumar));

        HABITOS.Add(PREGUNTA1);

        XElement PREGUNTA2 = new XElement("PREGUNTA");
        PREGUNTA2.Add(new XElement("RESPUESTA_UNO", txtSATipoFrecDrogas));
        PREGUNTA2.Add(new XElement("RESPUESTA_DOS", txtSAFrecDrogas));
        PREGUNTA2.Add(new XElement("FECHA_INICIO", txtSAd1IniDroga + txtSAd2IniDroga + txtSAm1IniDroga + txtSAm2IniDroga + txtSAa1IniDroga + txtSAa2IniDroga));
        PREGUNTA2.Add(new XElement("FECHA_TERMINO", txtSAd1FinDroga + txtSAd2FinDroga + txtSAm1FinDroga + txtSAm2FinDroga + txtSAa1FinDroga + txtSAa2FinDroga));
        PREGUNTA2.Add(new XElement("MOTIVO", txtSAMotDrogas));

        HABITOS.Add(PREGUNTA2);

        ANEXO.Add(HABITOS);
        #endregion HABITOS

        #region ANTECEDENTES_FAMILIARES
        XElement ANTECEDENTES_FAMILIARES = new XElement("ANTECEDENTES_FAMILIARES");

        XElement ANTECEDENTES = new XElement("ANTECEDENTES");
        XElement FAMILIAR = new XElement("FAMILIAR");
        FAMILIAR.Add(new XElement("PARENTESCO", "Madre"));
        FAMILIAR.Add(new XElement("EDAD", txtSAEdadMadre));
        FAMILIAR.Add(new XElement("ESTADO_DE_SALUD", txtSAEdoSAlMadre));
        FAMILIAR.Add(new XElement("VIVE", txtSAViveMadre));
        FAMILIAR.Add(new XElement("EDAD_MUERTE", txtSAEdadFalleMadre));
        FAMILIAR.Add(new XElement("CAUSAS", txtSACausasMadre));

        ANTECEDENTES.Add(FAMILIAR);

        XElement FAMILIAR2 = new XElement("FAMILIAR");
        FAMILIAR2.Add(new XElement("PARENTESCO", "padre"));
        FAMILIAR2.Add(new XElement("EDAD", txtSAEdadPadre));
        FAMILIAR2.Add(new XElement("ESTADO_DE_SALUD", txtSAEdoSAlPadre));
        FAMILIAR2.Add(new XElement("VIVE", txtSAVivePadre));
        FAMILIAR2.Add(new XElement("EDAD_MUERTE", txtSAEdadFallePadre));
        FAMILIAR2.Add(new XElement("CAUSAS", txtSACausasPadre));

        ANTECEDENTES.Add(FAMILIAR2);

        XElement FAMILIAR3 = new XElement("FAMILIAR");
        FAMILIAR3.Add(new XElement("PARENTESCO", "Hermanos"));
        FAMILIAR3.Add(new XElement("EDAD", txtSAEdadHnos));
        FAMILIAR3.Add(new XElement("ESTADO_DE_SALUD", txtSAEdoSAlHnos));
        FAMILIAR3.Add(new XElement("VIVE", txtSAViveHnos));
        FAMILIAR3.Add(new XElement("EDAD_MUERTE", txtSAEdadFalleHnos));
        FAMILIAR3.Add(new XElement("CAUSAS", txtSACausasHnos));

        ANTECEDENTES.Add(FAMILIAR3);


        XElement FAMILIAR4 = new XElement("FAMILIAR");
        FAMILIAR4.Add(new XElement("PARENTESCO", "Hijos"));
        FAMILIAR4.Add(new XElement("EDAD", txtSAEdadHijos));
        FAMILIAR4.Add(new XElement("ESTADO_DE_SALUD", txtSAEdoSAlHijos));
        FAMILIAR4.Add(new XElement("VIVE", txtSAViveHijos));
        FAMILIAR4.Add(new XElement("EDAD_MUERTE", txtSAEdadFalleHijos));
        FAMILIAR4.Add(new XElement("CAUSAS", txtSACausasHIjos));

        ANTECEDENTES.Add(FAMILIAR4);

        ANTECEDENTES_FAMILIARES.Add(ANTECEDENTES);

        //enfermedades
        XElement ENFERMEDADES = new XElement("ENFERMEDADES");

        XElement ENFERMEDAD = new XElement("ENFERMEDAD");
        ENFERMEDAD.Add(new XElement("NOM_ENFERMEDAD", "Enfermedad cardiaca"));
        ENFERMEDAD.Add(new XElement("QUIEN", txtSAQuienCardiaca));
        ENFERMEDAD.Add(new XElement("EVOLUCION", txtSAEvoCardiaca));

        ENFERMEDADES.Add(ENFERMEDAD);

        XElement ENFERMEDAD2 = new XElement("ENFERMEDAD");
        ENFERMEDAD2.Add(new XElement("NOM_ENFERMEDAD", "Cáncer"));
        ENFERMEDAD2.Add(new XElement("QUIEN", txtSAQuienCancer));
        ENFERMEDAD2.Add(new XElement("EVOLUCION", txtSAEvoCancer));

        ENFERMEDADES.Add(ENFERMEDAD2);

        XElement ENFERMEDAD3 = new XElement("ENFERMEDAD");
        ENFERMEDAD3.Add(new XElement("NOM_ENFERMEDAD", "Presión arterial alta"));
        ENFERMEDAD3.Add(new XElement("QUIEN", txtSAQuienPresion));
        ENFERMEDAD3.Add(new XElement("EVOLUCION", txtSAEvoPresion));

        ENFERMEDADES.Add(ENFERMEDAD3);

        XElement ENFERMEDAD4 = new XElement("ENFERMEDAD");
        ENFERMEDAD4.Add(new XElement("NOM_ENFERMEDAD", "Diabetes"));
        ENFERMEDAD4.Add(new XElement("QUIEN", txtSAQuienDiabetes));
        ENFERMEDAD4.Add(new XElement("EVOLUCION", txtSAEvoDiabetes));

        ENFERMEDADES.Add(ENFERMEDAD4);

        ANTECEDENTES_FAMILIARES.Add(ENFERMEDADES);

        //XElement LUGAR_Y_FECHA = new XElement("LUGAR_Y_FECHA");
        ANTECEDENTES_FAMILIARES.Add(new XElement("LUGAR_Y_FECHA", txtSALugaryFecha));

        XElement FIRMAS = new XElement("FIRMAS");
        XElement FIRMA = new XElement("FIRMA_CONTRATANTE");
        //FIRMA.Add(new XElement("TIPO_TERCERO", "CONTRATANTE"));
        FIRMA.Add(new XElement("NOMBRE", txtSANomCon));
        FIRMA.Add(new XElement("IMAGEN_FIRMA", ""));

        FIRMAS.Add(FIRMA);

        XElement FIRMA1 = new XElement("FIRMA_SOLICITANTE");
        //FIRMA1.Add(new XElement("TIPO_TERCERO", "SOLICITANTE"));
        FIRMA1.Add(new XElement("NOMBRE", txtSANomSol));
        FIRMA1.Add(new XElement("IMAGEN_FIRMA", ""));

        FIRMAS.Add(FIRMA1);

        ANTECEDENTES_FAMILIARES.Add(FIRMAS);


        ANTECEDENTES_FAMILIARES.Add(new XElement("FORMATO", "VI-898"));

        ANEXO.Add(ANTECEDENTES_FAMILIARES);
        #endregion ANTECEDENTES_FAMILIARES

        #region CUESTIONARIO
        XElement CUESTIONARIO = new XElement("CUESTIONARIO");
        CUESTIONARIO.Add(new XElement("TITULO", "CUESTIONARIO ¿Padecio y/o padece alguna de las siguientes enfermedades?"));
        XElement PREGUNTAS_GENERALES = new XElement("PREGUNTAS_GENERALES");

        string chkCst1 = "FALSE";
        if (Request.Form["chkSACuest1Si"] == "Yes")
        {
            chkCst1 = "TRUE";
        }

        XElement PREGUNTAG1 = new XElement("PREGUNTA");
        PREGUNTAG1.Add(new XElement("NUM_PREGUNTA", "1"));
        PREGUNTAG1.Add(new XElement("RESPUESTA", chkCst1));
        PREGUNTAG1.Add(new XElement("CAUSA", txtSACuestCausa1));
        PREGUNTAG1.Add(new XElement("CUANDO"));

        PREGUNTAS_GENERALES.Add(PREGUNTAG1);

        string chkCst2 = "FALSE";
        if (Request.Form["chkSACuest2Si"] == "Yes")
        {
            chkCst2 = "TRUE";
        }


        XElement PREGUNTAG2 = new XElement("PREGUNTA");
        PREGUNTAG2.Add(new XElement("NUM_PREGUNTA", "2"));
        PREGUNTAG2.Add(new XElement("RESPUESTA", chkCst2));
        PREGUNTAG2.Add(new XElement("CAUSA", txtSACuestCausa2));
        PREGUNTAG2.Add(new XElement("CUANDO", txtSACuestCuando2));

        PREGUNTAS_GENERALES.Add(PREGUNTAG2);

        string chkCuest3 = "FALSE";
        if (Request.Form["chkSACuest3Si"] == "Yes")
        {
            chkCuest3 = "TRUE";
        }

        XElement PREGUNTAG3 = new XElement("PREGUNTA");
        PREGUNTAG3.Add(new XElement("NUM_PREGUNTA", "3"));
        PREGUNTAG3.Add(new XElement("RESPUESTA", chkCuest3));
        PREGUNTAG3.Add(new XElement("CAUSA", txtSACuestCausa3));
        PREGUNTAG3.Add(new XElement("CUANDO", txtSACuestCuando3));

        PREGUNTAS_GENERALES.Add(PREGUNTAG3);

        string chkCuest4 = "FALSE";
        if (Request.Form["chkSACuest4Si"] == "Yes")
        {
            chkCuest4 = "TRUE";
        }

        XElement PREGUNTAG4 = new XElement("PREGUNTA");
        PREGUNTAG4.Add(new XElement("NUM_PREGUNTA", "4"));
        PREGUNTAG4.Add(new XElement("RESPUESTA", chkCuest4));
        PREGUNTAG4.Add(new XElement("CAUSA", txtSACuestCausa4));
        PREGUNTAG4.Add(new XElement("CUANDO", txtSACuestCuando4));

        PREGUNTAS_GENERALES.Add(PREGUNTAG4);

        CUESTIONARIO.Add(PREGUNTAS_GENERALES);

        XElement PREGUNTAS_PARTICULARES = new XElement("PREGUNTAS_PARTICULARES");

        string chkCuest5 = "FALSE";
        if (Request.Form["chkSACuest5Si"] == "Yes")
        {
            chkCuest5 = "TRUE";
        }

        XElement PREGUNTAP1 = new XElement("PREGUNTA");
        PREGUNTAP1.Add(new XElement("NUM_PREGUNTA", "5"));
        PREGUNTAP1.Add(new XElement("RESPUESTA", chkCuest5));
        PREGUNTAP1.Add(new XElement("KG_AUMENTADOS", txtSACuestKgAum));
        PREGUNTAP1.Add(new XElement("KG_DISMINUIDOS", txtSACuestKgDism));

        PREGUNTAS_PARTICULARES.Add(PREGUNTAP1);

        string chkCuest6a = "FALSE";
        if (Request.Form["chkSACuest6aSi"] == "Yes")
        {
            chkCuest6a = "TRUE";
        }


        XElement PREGUNTAP2 = new XElement("PREGUNTA");
        PREGUNTAP2.Add(new XElement("NUM_PREGUNTA", "6"));
        PREGUNTAP2.Add(new XElement("INCISO", "a"));
        PREGUNTAP2.Add(new XElement("RESPUESTA", chkCuest6a));
        PREGUNTAP2.Add(new XElement("CUAL", txtCuest6aCual));

        PREGUNTAS_PARTICULARES.Add(PREGUNTAP2);

        string chkCuest6b = "FALSE";
        if (Request.Form["chkSACuest6bSi"] == "Yes")
        {
            chkCuest6b = "TRUE";
        }


        XElement PREGUNTAP3 = new XElement("PREGUNTA");
        PREGUNTAP3.Add(new XElement("NUM_PREGUNTA", "6"));
        PREGUNTAP3.Add(new XElement("INCISO", "b"));
        PREGUNTAP3.Add(new XElement("RESPUESTA", chkCuest6b));
        PREGUNTAP3.Add(new XElement("MESES", txtCuest6bCuant));

        PREGUNTAS_PARTICULARES.Add(PREGUNTAP3);

        //modifi

        if (txtSAd1Papani == "d")
        {
            txtSAd1Papani = "";
        }
        if (txtSAd2Papani == "d")
        {
            txtSAd2Papani = "";
        }
        if (txtSAm1Papani == "m")
        {
            txtSAm1Papani = "";
        }
        if (txtSAm2Papani == "m")
        {
            txtSAm2Papani = "";
        }
        if (txtSAa1Papani == "y")
        {
            txtSAa1Papani = "";
        }
        if (txtSAa2Papani == "y")
        {
            txtSAa2Papani = "";
        }
        XElement PREGUNTAP4 = new XElement("PREGUNTA");
        PREGUNTAP4.Add(new XElement("NUM_PREGUNTA", "6"));
        PREGUNTAP4.Add(new XElement("INCISO", "c"));
        XElement ESTUDIO = new XElement("ESTUDIO");
        ESTUDIO.Add(new XElement("NUMERO", "1"));
        ESTUDIO.Add(new XElement("FECHA", txtSAd1Papani + txtSAd2Papani + txtSAm1Papani + txtSAm2Papani + txtSAa1Papani + txtSAa2Papani));
        ESTUDIO.Add(new XElement("RESULTADO", txtSACuest6c1Res));

        PREGUNTAP4.Add(ESTUDIO);

        //modifi

        if (txtSAd1Mamo == "d")
        {
            txtSAd1Mamo = "";
        }
        if (txtSAd2Mamo == "d")
        {
            txtSAd2Mamo = "";
        }
        if (txtSAm1Mamo == "m")
        {
            txtSAm1Mamo = "";
        }
        if (txtSAm2Mamo == "m")
        {
            txtSAm2Mamo = "";
        }
        if (txtSAa1Mamo == "y")
        {
            txtSAa1Mamo = "";
        }
        if (txtSAa2Mamo == "y")
        {
            txtSAa2Mamo = "";
        }

        XElement ESTUDIO2 = new XElement("ESTUDIO");
        ESTUDIO2.Add(new XElement("NUMERO", "2"));
        ESTUDIO2.Add(new XElement("FECHA", txtSAd1Mamo + txtSAd2Mamo + txtSAm1Mamo + txtSAm2Mamo + txtSAa1Mamo + txtSAa2Mamo));
        ESTUDIO2.Add(new XElement("RESULTADO", txtSACuest6c2Res));

        PREGUNTAP4.Add(ESTUDIO2);

        PREGUNTAS_PARTICULARES.Add(PREGUNTAP4);

        CUESTIONARIO.Add(PREGUNTAS_PARTICULARES);

        XElement RESPUESTAS_AMPLIADAS = new XElement("RESPUESTAS_AMPLIADAS");
        RESPUESTAS_AMPLIADAS.Add(new XElement("TITULO", "EN CASO AFIRMATIVO DE ALGUNA DE LAS PREGUNTAS ANTERIORES AMPLIAR LA INFORMACION"));

        if (txtSAFecPade1 == "dd/mm/yyyy")
        {
            txtSAFecPade1 = "";
        }
        XElement RESPUESTAS_AMPLIADA = new XElement("RESPUESTA_AMPLIADA");
        RESPUESTAS_AMPLIADA.Add(new XElement("PREGUNTA", txtSANumPre1));
        RESPUESTAS_AMPLIADA.Add(new XElement("PADECIMIENTO", txtSAPade1));
        RESPUESTAS_AMPLIADA.Add(new XElement("FECHA_INICIO", txtSAFecPade1));
        RESPUESTAS_AMPLIADA.Add(new XElement("DURACION", txtSAPadeDura1));
        RESPUESTAS_AMPLIADA.Add(new XElement("ESTADO_ACTUAL", txtSAPadeEdoAct1));

        RESPUESTAS_AMPLIADAS.Add(RESPUESTAS_AMPLIADA);

        if (txtSAFecPade2 == "dd/mm/yyyy")
        {
            txtSAFecPade2 = "";
        }

        XElement RESPUESTAS_AMPLIADA1 = new XElement("RESPUESTA_AMPLIADA");
        RESPUESTAS_AMPLIADA1.Add(new XElement("PREGUNTA", txtSANumPre2));
        RESPUESTAS_AMPLIADA1.Add(new XElement("PADECIMIENTO", txtSAPade2));
        RESPUESTAS_AMPLIADA1.Add(new XElement("FECHA_INICIO", txtSAFecPade2));
        RESPUESTAS_AMPLIADA1.Add(new XElement("DURACION", txtSAPadeDura2));
        RESPUESTAS_AMPLIADA1.Add(new XElement("ESTADO_ACTUAL", txtSAPadeEdoAct2));

        RESPUESTAS_AMPLIADAS.Add(RESPUESTAS_AMPLIADA1);

        if (txtSAFecPade3 == "dd/mm/yyyy")
        {
            txtSAFecPade3 = "";
        }

        XElement RESPUESTAS_AMPLIADA2 = new XElement("RESPUESTA_AMPLIADA");
        RESPUESTAS_AMPLIADA2.Add(new XElement("PREGUNTA", txtSANumPre3));
        RESPUESTAS_AMPLIADA2.Add(new XElement("PADECIMIENTO", txtSAPade3));
        RESPUESTAS_AMPLIADA2.Add(new XElement("FECHA_INICIO", txtSAFecPade3));
        RESPUESTAS_AMPLIADA2.Add(new XElement("DURACION", txtSAPadeDura3));
        RESPUESTAS_AMPLIADA2.Add(new XElement("ESTADO_ACTUAL", txtSAPadeEdoAct3));

        RESPUESTAS_AMPLIADAS.Add(RESPUESTAS_AMPLIADA2);

        if (txtSAFecPade4 == "dd/mm/yyyy")
        {
            txtSAFecPade4 = "";
        }

        XElement RESPUESTAS_AMPLIADA3 = new XElement("RESPUESTA_AMPLIADA");
        RESPUESTAS_AMPLIADA3.Add(new XElement("PREGUNTA", txtSANumPre4));
        RESPUESTAS_AMPLIADA3.Add(new XElement("PADECIMIENTO", txtSAPade4));
        RESPUESTAS_AMPLIADA3.Add(new XElement("FECHA_INICIO", txtSAFecPade4));
        RESPUESTAS_AMPLIADA3.Add(new XElement("DURACION", txtSAPadeDura4));
        RESPUESTAS_AMPLIADA3.Add(new XElement("ESTADO_ACTUAL", txtSAPadeEdoAct4));

        RESPUESTAS_AMPLIADAS.Add(RESPUESTAS_AMPLIADA3);

        CUESTIONARIO.Add(RESPUESTAS_AMPLIADAS);

        CUESTIONARIO.Add(new XElement("NOMB_Y_DOM_MEDICO", txtSANomDomiDr));
        CUESTIONARIO.Add(new XElement("NOMBRE_HOSPITAL", txtSANomHosp));

        XElement REFERENCIAS_PERSONALES = new XElement("REFERENCIAS_PERSONALES");
        XElement REFERENCIA = new XElement("REFERENCIA");
        REFERENCIA.Add(new XElement("NOMBRE_COMPLETO", txtSANomRef1));
        REFERENCIA.Add(new XElement("DOMICILIO", txtSADomRef1));
        REFERENCIA.Add(new XElement("TELEFONO", txtSATelRef1));

        REFERENCIAS_PERSONALES.Add(REFERENCIA);

        XElement REFERENCIA2 = new XElement("REFERENCIA");
        REFERENCIA2.Add(new XElement("NOMBRE_COMPLETO", txtSANomRef2));
        REFERENCIA2.Add(new XElement("DOMICILIO", txtSADomRef2));
        REFERENCIA2.Add(new XElement("TELEFONO", txtSATelRef2));

        REFERENCIAS_PERSONALES.Add(REFERENCIA2);
        CUESTIONARIO.Add(REFERENCIAS_PERSONALES);

        CUESTIONARIO.Add(new XElement("LEYENDA_UNO_CUESTIONARIO", "EV_CONSTITUYE_SOLICITUD.rtf"));
        CUESTIONARIO.Add(new XElement("LUGAR_Y_FECHA", txtSALugaryFecha));


        XElement FIRMASC = new XElement("FIRMAS");
        XElement FIRMAC1 = new XElement("FIRMA_CONTRATANTE");
        //FIRMAC1.Add(new XElement("TIPO_TERCERO", "CONTRATANTE"));
        FIRMAC1.Add(new XElement("NOMBRE", txtSANomCon));
        FIRMAC1.Add(new XElement("IMAGEN_FIRMA", ""));

        FIRMASC.Add(FIRMAC1);

        XElement FIRMAC2 = new XElement("FIRMA_SOLICITANTE");
        //FIRMAC2.Add(new XElement("TIPO_TERCERO", "SOLICITANTE"));
        FIRMAC2.Add(new XElement("NOMBRE", txtSANomSol));
        FIRMAC2.Add(new XElement("IMAGEN_FIRMA", ""));

        FIRMASC.Add(FIRMAC2);

        CUESTIONARIO.Add(FIRMASC);

        ANEXO.Add(CUESTIONARIO);
        #endregion CUESTIONARIO

        #region AGENTE


        XElement AGENTE = new XElement("AGENTE");
        AGENTE.Add(new XElement("TITULO", "INFORMACION EXCLUSIVA PARA LLENADO DEL AGENTE"));
        XElement PREGUNTAS_AGENTE = new XElement("PREGUNTAS_AGENTE");

        XElement PREGUNTASAG = new XElement("PREGUNTA");
        PREGUNTASAG.Add(new XElement("NUM_PREGUNTA", "1"));
        PREGUNTASAG.Add(new XElement("RESPUESTA", txtSAInfAgt1));

        PREGUNTAS_AGENTE.Add(PREGUNTASAG);

        XElement PREGUNTASAG2 = new XElement("PREGUNTA");
        PREGUNTASAG2.Add(new XElement("NUM_PREGUNTA", "2"));
        PREGUNTASAG2.Add(new XElement("RESPUESTA", txtSAInfAgt2));

        PREGUNTAS_AGENTE.Add(PREGUNTASAG2);

        XElement PREGUNTASAG3 = new XElement("PREGUNTA");
        PREGUNTASAG3.Add(new XElement("NUM_PREGUNTA", "3"));
        PREGUNTASAG3.Add(new XElement("RESPUESTA", txtSAInfAgt3));

        PREGUNTAS_AGENTE.Add(PREGUNTASAG3);

        XElement PREGUNTASAG4 = new XElement("PREGUNTA");
        PREGUNTASAG4.Add(new XElement("NUM_PREGUNTA", "4"));
        PREGUNTASAG4.Add(new XElement("RESPUESTA", txtSAInfAgt4));

        PREGUNTAS_AGENTE.Add(PREGUNTASAG4);

        XElement PREGUNTASAG5 = new XElement("PREGUNTA");
        PREGUNTASAG5.Add(new XElement("NUM_PREGUNTA", "6"));
        PREGUNTASAG5.Add(new XElement("RESPUESTA", txtSAInfAgt6));

        PREGUNTAS_AGENTE.Add(PREGUNTASAG5);

        string chkCuest7 = "FALSE";
        if (Request.Form["chkSAInfAgt7Si"] == "Yes")
        {
            chkCuest7 = "TRUE";
        }

        XElement PREGUNTASAG6 = new XElement("PREGUNTA");
        PREGUNTASAG6.Add(new XElement("NUM_PREGUNTA", "7"));
        PREGUNTASAG6.Add(new XElement("RESPUESTA", chkCuest7));

        PREGUNTAS_AGENTE.Add(PREGUNTASAG6);

        string chkCuest8 = "FALSE";
        if (Request.Form["chkSAInfAgt8Si"] == "Yes")
        {
            chkCuest8 = "TRUE";
        }


        XElement PREGUNTASAG7 = new XElement("PREGUNTA");
        PREGUNTASAG7.Add(new XElement("NUM_PREGUNTA", "8"));
        PREGUNTASAG7.Add(new XElement("RESPUESTA", chkCuest8));

        PREGUNTAS_AGENTE.Add(PREGUNTASAG7);

        AGENTE.Add(PREGUNTAS_AGENTE);

        XElement AGENTES_COMISION = new XElement("AGENTES_COMISION");
        XElement AGENTES_CO = new XElement("AGENTE");
        AGENTES_CO.Add(new XElement("NOMBRE", txtSANomAgt1));
        AGENTES_CO.Add(new XElement("CLAVE", txtSACVEAgt1));
        AGENTES_CO.Add(new XElement("PORCENTAJE", txtSAPctAgt1));
        AGENTES_CO.Add(new XElement("FIRMA"));

        AGENTES_COMISION.Add(AGENTES_CO);

        XElement AGENTES_CO2 = new XElement("AGENTE");
        AGENTES_CO2.Add(new XElement("NOMBRE", txtSANomAgt2));
        AGENTES_CO2.Add(new XElement("CLAVE", txtSACVEAgt2));
        AGENTES_CO2.Add(new XElement("PORCENTAJE", txtSAPctAgt2));
        AGENTES_CO2.Add(new XElement("FIRMA"));

        AGENTES_COMISION.Add(AGENTES_CO2);

        XElement AGENTES_CO3 = new XElement("AGENTE");
        AGENTES_CO3.Add(new XElement("NOMBRE", txtSANomAgt3));
        AGENTES_CO3.Add(new XElement("CLAVE", txtSACVEAgt3));
        AGENTES_CO3.Add(new XElement("PORCENTAJE", txtSAPctAgt3));
        AGENTES_CO3.Add(new XElement("FIRMA"));

        AGENTES_COMISION.Add(AGENTES_CO3);

        AGENTE.Add(AGENTES_COMISION);

        AGENTE.Add(new XElement("TELEFONOS", txtSATelAgt));
        AGENTE.Add(new XElement("CORREO_ELECTRONICO", txtSAEmailAgt));


        ANEXO.Add(AGENTE);

        #endregion AGENTE

        #region INFORMACION_ADICIONAL
        XElement INFORMACION_ADICIONAL = new XElement("INFORMACION_ADICIONAL");
        INFORMACION_ADICIONAL.Add(new XElement("CONTENIDO", "EV_INFORMACION_ADICIONAL_VI_898.rtf"));
        INFORMACION_ADICIONAL.Add(new XElement("CONTENIDO", "EV_REGISTRO_CNSF_SOLICITUD.rtf"));
        INFORMACION_ADICIONAL.Add(new XElement("VI_FECHA_CNSF", "18 de Octubre de  2021"));
        INFORMACION_ADICIONAL.Add(new XElement("VI_REGISTRO_CNSF", "CGEN-S0041-0101-2021/G01350-001"));

        ANEXO.Add(INFORMACION_ADICIONAL);

        #endregion INFORMACION_ADICIONAL

        ROOT.Add(ANEXO);

        #endregion ANEXO

        string xmlSolicitud = ROOT.ToString().Replace(".JPG", ".jpg")
              .Replace("true", "TRUE")
              .Replace("false", "FALSE")
              .Replace("&AMP;", "&#38;")
              .Replace(".RTF", ".rtf");

        string nombre = "POLIZAEMISION_" + Request.Form["numCotizacion"];


        XmlHpExtreme xmlHpExtreme = new XmlHpExtreme();

        nombre = xmlHpExtreme.XmlHpExtremeMonto(xmlSolicitud, Request.Form["numCotizacion"]);


        //AbrirPdf(nombre);



        // report by reading values from completed PDF
        // string sTmp = "W-4 Completed for " + pdfFormFields.GetField("f1_09(0)") + " " +
        //   pdfFormFields.GetField("f1_10(0)");
        //MessageBox.Show(sTmp, "Finished");

        // flatten the form to remove editting options, set it to false
        // to leave the form open to subsequent manual edits
        //        pdfStamper.FormFlattening = false;

        //        // close the pdf
        //        pdfStamper.Close();
        //    }
        //    catch (Exception ex)
        //    {
        //        MapfreMMX.util.MLogFile.getInstance().writeText("Error FillCuestionarioSA:" + ex.Message);
        //   }

    }

    public string TipoIdentificacion(string noIdentificacion)
    {
        switch (noIdentificacion)
        {
            case "1":
                return "Credencial para votar";
            case "2":
                return "Pasaporte";
            case "3":
                return "Cédula Profesional";
            case "4":
                return "Cartilla del Servicio Militar Nacional";
            case "5":
                return "Certificado de Matrícula Consular";
            case "6":
                return "Tarjeta Única de Identidad Militar";
            case "7":
                return "Credenciales y/o carnets IMSS o ISSSTE";
            case "8":
                return "Tarjeta de afiliación al INAPAM";
            case "9":
                return "Licencia para conducir";
            case "10":
                return "Credenciales de autoridades estatales";
            case "11":
                return "Credenciales de autoridades municipales";
            case "12":
                return "Credenciales de autoridades federales";
            default:
                return string.Empty;
        }
    }
}