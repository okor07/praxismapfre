﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Oracle.DataAccess.Client;
using MapfreMMX.oracle;

using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.xml;

using System.IO;
using System.Text;
using System.Globalization;
using MapfreMMX.util;

public partial class EmisionGeneral_FirmaElectronicaCorreos : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Ajax.Utility.RegisterTypeForAjax(typeof(MetodosAjax));
        try
        {
            //20230823 Mejoras Firma Digital:
            //Se agrega este formulario para la modificación de correos de los intervinientes.
            MapfreMMX.util.MLogFile.getInstance().writeText("Entra FirmaElectronicaCorreos");
            if (string.IsNullOrEmpty(Request.Params["transaccion"]) || string.IsNullOrEmpty(Request.Params["folio"]) || string.IsNullOrEmpty(Request.Params["solicitud"]))
            {
                Response.Write("<div id='divError' class='col-12' align='center'>");
                Response.Write("<br />");
                Response.Write("<p>ERROR:</p>");
                Response.Write("Lo sentimos, no se cargaron correctamente los datos. Favor de intentar nuevamente");
                Response.Write("<br />");
                Response.Write("<br />");
                Response.Write("<input id='btnCerrarError' type='button' runat='server' onclick='Cerrar()' value='Cerrar' class='btn btnred_g' style='width: 210px;' />");
                Response.Write("</div>");
            }
            else
            {
                //Se consultan los correos de la solicitud.
                string transaccion = Request.Params["transaccion"];
                string folio = Request.Params["folio"];
                string solicitud = Request.Params["solicitud"];

                string mailContratante = string.Empty;
                string mailAsegurado = string.Empty;
                string mailAgente = string.Empty;
                string editado = "S";
                //Traer estos datos desde la consulta de los correos.
                string ramo = string.Empty;
                string nom_contratante = string.Empty;
                string nom_asegurado = string.Empty;
                string nom_agente = string.Empty;
                string cod_agente = string.Empty;
                string telAgente = string.Empty;

                MetodosAjax objMetodosAjax = new MetodosAjax();
                DataRow drCorreos = objMetodosAjax.consultaCorreos(solicitud, transaccion, folio);

                //Si tiene elementos el DataRow se muestran los correos almacenados
                if (drCorreos.ItemArray.Length > 0)
                {
                    //Variables para recuperar los correos del contratante, asegurado y agente, así com el teléfono del agente en caso de que la SA sea mayor a 1.5MDP
                    mailContratante = drCorreos["MAIL_CONTRATANTE"].ToString();
                    mailAsegurado = drCorreos["MAIL_ASEGURADO"].ToString();
                    mailAgente = drCorreos["MAIL_AGENTE"].ToString();
                    editado = drCorreos["EDITADO"].ToString();
                    ramo = drCorreos["COD_RAMO"].ToString();
                    nom_contratante = drCorreos["NOM_CONTRATANTE"].ToString();
                    nom_asegurado = drCorreos["NOM_ASEG"].ToString();
                    nom_agente = drCorreos["COD_AGT"].ToString();
                    telAgente = drCorreos["TELEFONO"].ToString();
                }
                    MapfreMMX.util.MLogFile.getInstance().writeText("mailContratante: " + mailContratante);
                    MapfreMMX.util.MLogFile.getInstance().writeText("mailAsegurado: " + mailAsegurado);
                    MapfreMMX.util.MLogFile.getInstance().writeText("mailAgente: " + mailAgente);
                    MapfreMMX.util.MLogFile.getInstance().writeText("editado: " + editado);

                    string btnEnviarFirma = "<input id='envFirmaMod' type='button' runat='server' value='Enviar a Firmar' class='btn btnred_g' style='width: 210px;' onclick='EditarCorreos(\"" + solicitud + "\", \"" + transaccion + "\", \"" + folio + "\")' hidden/>";
                    string btnModificar = "<input id='btnModificar' type='button' runat='server' value='Modificar y Enviar a Firmar' class='btn btnred_g' style='width: 210px;' onclick='ModificarCorreos()' hidden/>";
                    string btnCerrarMod = "<input id='btnCerrarMod' type='button' runat='server' onclick='Cerrar()' value='Cerrar' class='btn btnred_g' style='width: 210px;' />";


                    Response.Write("<ajaxToolkit:ToolkitScriptManager ID='scriptManager' runat='server' EnablePartialRendering='true'></ajaxToolkit:ToolkitScriptManager>");
                    Response.Write("<div id='divPDF' class='col-12'><table border='1'><tr><td>");
                    Response.Write("<td rowspan='2' style='text-align:left;vertical-align:top;padding:15'>");
                    Response.Write("<fieldset style='width: 100%; margin-top: 35px; padding: 5px; border: 1px solid #EFEFEF; -webkit-border-radius: 10px; -moz-border-radius: 10px; border-radius: 20px;'><legend class='EtiquetaGeneralDescripcionRoja'>Estimado asegurado, por favor lee detenidamente la solicitud para verificar que todos los datos son correctos</legend><div id='grdBeneficiarios'></div></fieldset>");
                    Response.Write("<p>Para iniciar el proceso de firma favor, de proporcionar correos electr&oacute;nicos y un n&uacute;mero de celular</p>");
                    Response.Write("<br />Correo Electr&oacute;nico del contratante<br />(" + nom_contratante + ") <br />");
                    Response.Write("<input runat='server' name='txtMailContratante' type='text' maxlength='50' id='txtMailContratante' class='form-control inp-sel-48' placeholder='mail@mail.com' value='" + mailContratante + "' disabled />");
                    Response.Write("<br />Correo Electr&oacute;nico del asegurado<br />(" + nom_asegurado + ") <br />");
                    Response.Write("<input runat='server' name='txtMailAsegurado' type='text' maxlength='50' id='txtMailAsegurado' class='form-control inp-sel-48' placeholder='mail@mail.com' value='" + mailAsegurado + "' disabled />");
                    Response.Write("<br />Correo Electr&oacute;nico del agente<br />(" + nom_agente + ") <br />");
                    Response.Write("<input runat='server' name='txtMailAgente' type='text' maxlength='50' id='txtMailAgente' class='form-control inp-sel-48' placeholder='mail@mail.com' value='" + mailAgente + "' disabled />");
                    Response.Write("<br /><br />Tel&eacute;fono: <br />");
                    Response.Write("<input name='txtTelefono' type='text' maxlength='20' id='txtTelefono' class='form-control inp-sel-48' placeholder='5512345678' value='" + telAgente + "' disabled />");
                    Response.Write("<br /><br />");
                    
                    if (editado == "")
                    {
                        
                        //Habilitar el botón para cerrar solamente
                        Response.Write("<table><tr><td style='width: 33%;'></td>");
                        Response.Write("<td style='width: 33%;'>" + btnCerrarMod + "</td>");
                        Response.Write("<td style='width: 33%;'></td>");
                        Response.Write("</tr></table>");
                        throw new Exception("No existen correos registrados para los intervinientes.");
                    }
                    else if (editado == "N")
                    {
                        //Hablitar el botón para modificar los campos y el botón de cerrar.
                        btnModificar = "<input id='btnModificar' type='button' runat='server' value='Modificar' class='btn btnred_g' style='width: 210px;' onclick='ModificarCorreos()' />";
                        Response.Write("<table><tr><td style='width: 25%;'></td>");
                        Response.Write("<td style='width: 50%;'>");
                        Response.Write("<table><tr><td style='width: 50%;'>" + btnModificar + btnEnviarFirma);
                        Response.Write("</td><td style='width: 50%;'>" + btnCerrarMod);
                        Response.Write("</td></tr></table>");
                        Response.Write("</td><td style='width: 25%;'></td></tr></table>");
                    }
                    else if (editado == "S")
                    {
                        //Habilitar el botón para cerrar solamente
                        Response.Write("<table><tr><td style='width: 33%;'></td>");
                        Response.Write("<td style='width: 33%;'>" + btnCerrarMod + "</td>");
                        Response.Write("<td style='width: 33%;'></td>");
                        Response.Write("</tr></table>");
                    }

                    Response.Write("</td></tr></table></div>");

                    Response.Write("<div style='display : none;' id='divMensaje' class='col-12' align='center'>");
                    Response.Write("<br />");
                    Response.Write("<p>¡MUCHAS GRACIAS!</p>");
                    Response.Write("Se te ha enviado un correo electr&oacute;nico, para continuar con el proceso de firma biom&eacute;trica digital, por favor abre el correo en el que encontrar&aacute;s:");
                    Response.Write("<br />");
                    Response.Write("&#8226; La solicitud pre-llenada que contiene tu informaci&oacute;n previamente capturada durante el proceso de emisi&oacute;n.");
                    Response.Write("<br />");
                    Response.Write("&#8226; La liga para continuar con la firma biom&eacute;trica digital");
                    Response.Write("<br />");
                    Response.Write("<strong><em>La contrase&ntilde;a para visualizar el pdf adjunto en los correos enviados es DDMMAAAA</em></strong> y deber&aacute; recuperar la fecha de nacimiento del asegurado.");
                    Response.Write("<br />");
                    Response.Write("Los datos del folio generado son:");
                    Response.Write("<br />");
                    Response.Write("<table>");
                    Response.Write("<tr>");
                    Response.Write("<td style='width: 25%;'></td>");
                    Response.Write("<td style='width: 50%;'>");
                    Response.Write("<table class='table table-bordered tab-border-red' style='width: 100%;' border='0' cellpadding='0' cellspacing='0'>");
                    Response.Write("<tr class='table-danger' style='color: #FFF;'>");
                    Response.Write("<td align='center'>Folio</td>");
                    Response.Write("<td align='center'>Solicitud</td>");
                    Response.Write("</tr>");
                    Response.Write("<tr>");
                    Response.Write("<td id='tdFolio' runat='server' align='center'></td>");
                    Response.Write("<td id='tdSolicitud' runat='server' align='center'></td>");
                    Response.Write("<td id='tdTransaccion' runat='server' align='center' style='display : none;'><input type='hidden' id='hdnTransaccion' name='hdnTransaccion' value=''></td>");
                    Response.Write("<td id='tdURL' runat='server' align='center' style='display : none;'><input type='hidden' id='hdnURL' name='hdnURL' value=''></td>");
                    Response.Write("</tr>");
                    Response.Write("</table>");
                    Response.Write("</td>");
                    Response.Write("<td style='width: 25%;'></td>");
                    Response.Write("</tr>");
                    Response.Write("</table>");
                    Response.Write("<br />");
                    Response.Write("<br />");
                    Response.Write("<input id='btnCerrarFirma' type='button' runat='server' onclick='redirectGestion2008()' value='Cerrar' class='btn btnred_g' style='width: 210px;' />");
                    Response.Write("</div>");

                    Response.Write("<div class='contenedor'>");
                    Response.Write("<div class='main' style='display: block;'>");
                    Response.Write("<div class='contenido_g'>");
                    Response.Write("<div class='modalBackground' style='display: none;' id='divCargando' runat='server'>");
                    Response.Write("<asp:Panel ID='PanelCargando' runat='server' Style='position: absolute; left: 50%; top: 15%'>");
                    Response.Write("<table cellspacing='0' cellpadding='0' border='0'>");
                    Response.Write("<tr>");
                    Response.Write("<td>");
                    Response.Write("<img alt='' src='../Common/Images/spinner.gif' width='16' height='16' border='0' />&nbsp;");
                    Response.Write("<asp:Label ID='lblProcesando' runat='server' Text='Procesando...' CssClass='letraTitulosBoldBlancaDerecha'></asp:Label>");
                    Response.Write("</td>");
                    Response.Write("</tr>");
                    Response.Write("</table>");
                    Response.Write("</asp:Panel>");
                    Response.Write("</div></div></div></div>");
            }
        }
        catch (Exception ex)
        {
            //Mandar mensaje en caso de error.
            ClientScript.RegisterStartupScript(GetType(), "ErrorModCorreos", "<script>alert('Se produjo un error al cargar los datos, intentar nuevamente. Error: " + ex.Message + "');</script>");
            MapfreMMX.util.MLogFile.getInstance().writeText("Error FirmaElectronicaCorreos: " + ex.Message);
        }
    }
}