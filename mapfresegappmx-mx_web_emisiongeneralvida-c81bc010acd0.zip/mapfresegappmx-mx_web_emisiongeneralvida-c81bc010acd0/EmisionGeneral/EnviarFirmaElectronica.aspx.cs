﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Configuration;
using System.Xml;
using System.IO;
using Oracle.DataAccess.Client;
using MapfreMMX.oracle;
using System.Data;
using MapfreMMX.util;

public partial class EmisionGeneral_EnviarFirmaElectronica : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        XmlDocument soapEnvelopeXml = new XmlDocument();
        XmlDocument XmlDoc = new XmlDocument();
        string numCotizacion = Request.QueryString["numCotizacion"];
        string nomContratante = Request.QueryString["contratante"];
        string nomAsegurado = Request.QueryString["asegurado"];
        string agente = Request.QueryString["agt"];
        string ramo = Request.QueryString["ramo"];
        string mailContratante = Session["mailContratante"].ToString();
        string mailAsegurado = Session["mailAsegurado"].ToString();
        string mailAgente = Session["mailAgente"].ToString();
        try
        {
            Byte[] bytes = File.ReadAllBytes("C:\\inetpub\\wwwroot\\EmisionGeneralVida\\SolicitudPDF\\" + ConfigurationManager.AppSettings["fileService"]);
            String file = Convert.ToBase64String(bytes);
            soapEnvelopeXml.LoadXml(@"<ThirdPartyFormUpdateRQ>
	<Security_Data>
		<Unique_Data>
			<Login_Data>
				<Login_Id>" + ConfigurationManager.AppSettings["LoginId"] + @"</Login_Id>
				<Application_Code>" + ConfigurationManager.AppSettings["AppCode"] + @"</Application_Code>
			</Login_Data>
		</Unique_Data>
		<Password>" + ConfigurationManager.AppSettings["PasswordSd"] + @"</Password>
		<Merchant_Id>" + ConfigurationManager.AppSettings["MerchantId"] + @"</Merchant_Id>
	</Security_Data>
	<FormDetails>
		<FormKey>PDF_" + DateTime.Now.ToString("yyyyMMddHHmmss") + @"</FormKey>
		<ProductId>" + ConfigurationManager.AppSettings["ProductId"] + @"</ProductId>
		<PDF_Certification>
			<User_Validation>
				<INIT_DOCUMENT_TO_CERTIFICATE>
					<INIT_Date>" + DateTime.Today.ToString("dd/MM/yyyy") + @"</INIT_Date>
					<Number_of_Signers>4</Number_of_Signers>
					<Signature_Counter>2</Signature_Counter>
					<PDF_Name>PRUEBA_EVERIS</PDF_Name>
					<PDF_to_Certificate>{""isImageControlData"":""N"",
					""formKey"":""MTU3NDQ1OTkyNDI2NGNhcmxvcw"",""name"":""Form280420.pdf"",
					""isFileData"":""Y"",""fileUploadType"":""Y"",
                    ""type"":""application/pdf"",
					""preservedValue"":""true"",
					""fileContent"":""" + file + @"""}</PDF_to_Certificate>
				</INIT_DOCUMENT_TO_CERTIFICATE>
                <Signers_Information>
					<Email_User>" + mailContratante + @"</Email_User>
                    <Type_of_Signer>rolFirmante2</Type_of_Signer>
					<Position_to_Sign>2</Position_to_Sign>
				</Signers_Information>
				<Signers_Information>
					<Email_User>" + mailAsegurado + @"</Email_User>
                    <Type_of_Signer>rolFirmante3</Type_of_Signer>
					<Position_to_Sign>3</Position_to_Sign>
				</Signers_Information>
				<Signers_Information>
					<Email_User>" + mailAgente + @"</Email_User>
                    <Type_of_Signer>rolFirmante4</Type_of_Signer>
					<Position_to_Sign>4</Position_to_Sign>
				</Signers_Information>
			</User_Validation>
		</PDF_Certification>
		<Transition>
			<Name>" + ConfigurationManager.AppSettings["TransitionName"] + @"</Name>
		</Transition>
		<SearchName>" + ConfigurationManager.AppSettings["SearchName"] + @"</SearchName>
        <PersistenceFormat>XML</PersistenceFormat>
	</FormDetails>
</ThirdPartyFormUpdateRQ>");

            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            HttpWebRequest request = CreateWebRequest();
                
            using (Stream stream = request.GetRequestStream())
            {
                soapEnvelopeXml.Save(stream);
            }

            

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                Stream receiveStream = response.GetResponseStream();
                StreamReader rdStream = new StreamReader(receiveStream);
                string test = rdStream.ReadToEnd();
                
                XmlDoc.LoadXml(test);
            }
        }
        catch (WebException ex)
        { 
        
        }
        try
        {
            string formId = XmlDoc.SelectSingleNode("ThirdPartyFormUpdateRS/FormDetails/FormId").InnerText;
            string formKey = XmlDoc.SelectSingleNode("ThirdPartyFormUpdateRS/FormDetails/FormKey").InnerText;
            InsertaDatos("1", ramo, formId, formKey, numCotizacion, nomContratante, nomAsegurado, DateTime.Today.ToString("ddMMyyyy"), agente, Session["XMLEmisionFirma"].ToString(), "PENDIENTE DE FIRMA", DateTime.Today.ToString("ddMMyyyy"), DateTime.Today.AddYears(1).ToString("ddMMyyyy"));
        }
        catch (Exception ex1)
        { }
    }

    public static HttpWebRequest CreateWebRequest()
    {
        var _url = "https://demo.idmission.com/IDS/service/integ/idm/thirdparty/upsert";
        //var _action = "IDS/service/integ/idm/thirdparty/upsert";
        HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(_url);
        webRequest.Headers.Add(@"SOAP:Action");
        webRequest.ContentType = "application/xml;charset=utf-8";
        //webRequest.ContentLength= 1786784;
        webRequest.Timeout = 1000000000;
        webRequest.Accept = "application/xml;";
        webRequest.Method = "POST";
        return webRequest;
    }

    public bool InsertaDatos(string cod_cia, string cod_ramo, string id_transaccion, string num_folio, string num_poliza,
        string nom_contratante, string nom_aseg, string fec_ini_tramite, string cod_agt, string txt_solicitud, string txt_estatus,
        string fec_efec, string fec_vcto)
    {
        MCommand cmd = new MCommand();
        bool resp = false;
        DataRow dr;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "tron2000.em_k_gen_firma_digital_mmx.p_inserta";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, Convert.ToInt32(cod_cia));
                cmd.agregarINParametro("p_cod_ramo", OracleDbType.Int32, Convert.ToInt32(cod_ramo));
                cmd.agregarINParametro("p_id_transaccion", OracleDbType.Varchar2, id_transaccion);
                cmd.agregarINParametro("p_num_folio", OracleDbType.Varchar2, num_folio);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, num_poliza);
                cmd.agregarINParametro("p_nom_contratante", OracleDbType.Varchar2, nom_contratante);
                cmd.agregarINParametro("p_nom_aseg", OracleDbType.Varchar2, nom_contratante);
                cmd.agregarINParametro("p_fec_ini_tramite", OracleDbType.Varchar2, fec_ini_tramite);
                cmd.agregarINParametro("p_cod_agt", OracleDbType.Int32, cod_agt);
                cmd.agregarINParametro("p_txt_solicitud", OracleDbType.Clob, txt_solicitud);
                cmd.agregarINParametro("p_txt_estatus", OracleDbType.Varchar2, txt_estatus);
                cmd.agregarINParametro("p_fec_efec_poliza", OracleDbType.Varchar2, fec_efec);
                cmd.agregarINParametro("p_fec_vcto_poliza", OracleDbType.Varchar2, fec_vcto);
                
                dr = cmd.ejecutarRegistroSP();
                resp = true;
                
            }
        }
        catch (Exception ex)
        {
            resp = false;
            {
                throw new Exception("Error EnviarFirmaElectronica.InsertaDatos():  " + ex.Message);
                MapfreMMX.util.MLogFile.getInstance().writeText("Error EnviarFirmaElectronica.InsertaDatos():  " + ex.Message);
            }
        }
        return resp;
    }
}