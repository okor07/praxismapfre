﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Generales.Clases;

public partial class Controles_wucBeneficiarios : System.Web.UI.UserControl
{
    #region Fields

    private DataTable _Beneficiarios;

    #endregion

    #region Properties

    public DataTable Beneficiarios
    {
        get { return _Beneficiarios; }
        set { _Beneficiarios = value; }
    }

    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session.Remove("sBeneficiarios");

            LlenarEstructuraDT();
            lnkbtnInsertar.Attributes.Add("onclick", "AjustarFrame();");
        }

        if (Session["sBeneficiarios"] != null)
        {
            _Beneficiarios = (DataTable)Session["sBeneficiarios"];
        }

        lnkbtnInsertar.Click += new EventHandler(lnkbtnInsertar_Click);

        Catalogos objCatalogos = new Catalogos();

        drpParentesco.DataSource = objCatalogos.getParentesco();
        drpParentesco.DataTextField = "NOM_VALOR";
        drpParentesco.DataValueField = "COD_VALOR";
        drpParentesco.DataBind();

        txtPorcentaje.Attributes.Add("onKeyPress", "return KeyNumber(this, event);");
    }

    void lnkbtnInsertar_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["sBeneficiarios"] != null)
            {
                //Se Parsea la Información de los Beneficiarios guardada en sesión.
                DataTable objTemp = (DataTable)Session["sBeneficiarios"];

                //Modo Inserción.
                //Se sabe que está en Modo Edición gracias al Campo no visible "HiddenBeneficiario"
                //Si tiene valor vacio quiere decir que es una Inserción.
                if (string.IsNullOrEmpty(HiddenBeneficiario.Value))
                {

                    string strValPorcYNoBenef = ValPorcentajeYNoBenef(txtPorcentaje.Text, drpTipoBenef.SelectedItem.Value, objTemp.Rows.Count);

                    if (string.IsNullOrEmpty(strValPorcYNoBenef))
                    {
                        //Se agrega una nueva fila al DataTable de Beneficiarios.
                        //Con la información capturada en cada campo.
                        DataRow objDataRow = objTemp.NewRow();
                        objDataRow["ID"] = objTemp.Rows.Count;
                        objDataRow["tip_docum"] = "";
                        objDataRow["cod_docum"] = "";
                        objDataRow["Nombre"] = txt_Bene_Nombre.Text;
                        objDataRow["ApePaterno"] = txt_Bene_ApePaterno.Text;
                        objDataRow["ApeMaterno"] = txt_Bene_ApeMaterno.Text;
                        objDataRow["Parentesco"] = drpParentesco.SelectedItem.Text;
                        objDataRow["cod_parent"] = drpParentesco.SelectedItem.Value;
                        objDataRow["PorcentajeDesc"] = txtPorcentaje.Text + "%";
                        objDataRow["Porcentaje"] = txtPorcentaje.Text;
                        objDataRow["Beneficiario"] = drpTipoBenef.SelectedItem.Text;
                        objDataRow["tip_benef"] = drpTipoBenef.SelectedItem.Value;

                        objTemp.Rows.Add(objDataRow);

                        hdFieldPorcBene.Value = hdFieldPorcBeneAux.Value;

                        //Se limpian Campos.
                        LimpiarCampos();

                    }
                    else
                    {
                        lblValidacion.Text = strValPorcYNoBenef;
                        lblValidacion.Visible = true;
                    }
                }
                //Modo Edición.
                //Si "HiddenBeneficiario" tiene valor diferente de vacio quiere decir que es una Edición.
                else
                {
                    foreach (DataRow dr in objTemp.Rows)
                    {
                        
                    }
                }
                //Se guarda en Sesión el objeto DataTable con la información de los Beneficiarios.
                Session["sBeneficiarios"] = objTemp;
                
                //Se muestra en el GridView "dgBeneficiarios" la información de los Beneficiarios.
                dgBeneficiarios.DataSource = objTemp;
                dgBeneficiarios.DataBind();
                uPanelGrid.Update();

            }
        }
        catch (Exception ex)
        {
            string strException = ex.ToString();
        }
    }

    protected void btnBorrar_Click(object sender, EventArgs e)
    {
        //Se obtiene el ID de la fila al que se pulsa el LinkButton "Borrar"
        int ID = Convert.ToInt32(((LinkButton)sender).Attributes["elID"]);

        //Se valida que la sesión con la Información de los Beneficiarios no sea Nula.
        if (Session["sBeneficiarios"] != null)
        {
            //Se Parsea la Información de los Beneficiarios guardada en sesión.
            DataTable objTemp = (DataTable)Session["sBeneficiarios"];

            //Se obtiene el Tipo de Beneficiario del elemento que se desea borrar.
            string strTipoBene = "";
            foreach (DataRow drTipoBene in objTemp.Rows)
            {
                if (drTipoBene["ID"].ToString().Trim() == ID.ToString().Trim())
                    strTipoBene = drTipoBene["tip_benef"].ToString();
            }
            //Validación para los beneficiarios Principales al Cien.
            if (strTipoBene == "6")
            {
                objTemp = EliminarTipBenefNoPrincipales(objTemp);
            }

            //Se elimina la fila en el Indice Indicado.
            objTemp.Rows.RemoveAt(ID);

            int Cont = 0;
            //Se reasignan los valores de ID de cada fila para validar
            //que ningún ID se repita y aparezcan de acuerdo a su Indice de Posición.
            foreach (DataRow dr in objTemp.Rows)
            {
                dr["ID"] = Cont;
                Cont++;
            }

            //Se limpian los campos.
            LimpiarCampos();
            //Se guarda en Sesión el objeto DataTable con la información de los Beneficiarios.
            Session["sBeneficiarios"] = objTemp;

            ///Se muestra en el GridView "dgBeneficiarios" la información de los Beneficiarios.
            dgBeneficiarios.DataSource = objTemp;
            dgBeneficiarios.DataBind();
            uPanelGrid.Update();
        }
    }

    protected DataTable EliminarTipBenefNoPrincipales(DataTable dt)
    {
        for (int i = dt.Rows.Count-1; i >= 0; i--)
        {
            if (dt.Rows[i]["tip_benef"].ToString().Trim() != "6")
                dt.Rows.RemoveAt(i);
        }
        return dt;
    }

    /// <summary>
    /// Método donde se crea la estructura del DataTable, es decir se crean las Columnas del DataTable.
    /// </summary>
    protected void LlenarEstructuraDT()
    {
        _Beneficiarios = new DataTable();
        _Beneficiarios.Columns.Add(new DataColumn("ID", System.Type.GetType("System.String")));
        _Beneficiarios.Columns.Add(new DataColumn("tip_docum", System.Type.GetType("System.String")));
        _Beneficiarios.Columns.Add(new DataColumn("cod_docum", System.Type.GetType("System.String")));
        _Beneficiarios.Columns.Add(new DataColumn("Nombre", System.Type.GetType("System.String")));
        _Beneficiarios.Columns.Add(new DataColumn("ApePaterno", System.Type.GetType("System.String")));
        _Beneficiarios.Columns.Add(new DataColumn("ApeMaterno", System.Type.GetType("System.String")));
        _Beneficiarios.Columns.Add(new DataColumn("Parentesco", System.Type.GetType("System.String")));
        _Beneficiarios.Columns.Add(new DataColumn("cod_parent", System.Type.GetType("System.String")));
        _Beneficiarios.Columns.Add(new DataColumn("PorcentajeDesc", System.Type.GetType("System.String")));
        _Beneficiarios.Columns.Add(new DataColumn("Porcentaje", System.Type.GetType("System.String")));
        _Beneficiarios.Columns.Add(new DataColumn("Beneficiario", System.Type.GetType("System.String")));
        _Beneficiarios.Columns.Add(new DataColumn("tip_benef", System.Type.GetType("System.String")));
        
        Session.Add("sBeneficiarios", _Beneficiarios);
    }

    protected void LimpiarCampos()
    {
        txt_Bene_Nombre.Text = "";
        txt_Bene_ApePaterno.Text = "";
        txt_Bene_ApeMaterno.Text = "";
        txtEspPrima.Text = "";
        txtPorcentaje.Text = "";

        drpParentesco.SelectedIndex = 0;
        lblValidacion.Text = "";
        lblValidacion.Visible = false;
    }

    protected string ValPorcentajeYNoBenef(string strPorcentaje, string strTipoBene, int NoBenef)
    {
        string strMensaje = "";
        int NoMaxBenef = 10;
        float PorcentajeTotal = getPorcPorTipoBene(strTipoBene);

        //Validación de haber Capturado Primero al Principal con 100%
        if (strTipoBene != "6")
        {
            if (!validarCapturadoPrincipal())
            {
                strMensaje = "* Debe capturar a los beneficiarios principales al 100%.\n";
                return strMensaje;
            }
        }

        //Validación para que cada tipo de Beneficiario no exceda 100%.
        float Porcentaje = 0F;
        if (float.TryParse(strPorcentaje, out Porcentaje))
        {
            PorcentajeTotal = PorcentajeTotal + Porcentaje;
            if (PorcentajeTotal > 100)
                strMensaje += "* El porcentaje no puede exceder el 100% por Tipo de Beneficiario.\n";
        }

        //Validación para el Número máximo de Beneficiarios.
        if(NoBenef >= NoMaxBenef)
            strMensaje += "* No pueden agregarse mas de 10 Beneficiarios.\n";

        return strMensaje;
    }

    protected float getPorcPorTipoBene(string strTipoBene)
    {
        float PorcentajeTotal = 0F;
        if (Session["sBeneficiarios"] != null)
        {
            DataTable objTemp = (DataTable)Session["sBeneficiarios"];
            foreach (DataRow dr in objTemp.Rows)
            {
                if (dr["tip_benef"].ToString() == strTipoBene)
                    PorcentajeTotal = PorcentajeTotal + Convert.ToSingle(dr["Porcentaje"].ToString());
            }
        }
        return PorcentajeTotal;
    }

    protected bool validarCapturadoPrincipal()
    {
        bool ExistePrincipalAlCien = false;
        if (Session["sBeneficiarios"] != null)
        {
            DataTable objTemp = (DataTable)Session["sBeneficiarios"];
            float Porcentaje = 0F;
            foreach (DataRow dr in objTemp.Rows)
            {
                if (dr["tip_benef"].ToString() == "6")
                {
                    Porcentaje = Porcentaje + Convert.ToSingle(dr["Porcentaje"].ToString());
                }
            }
            if (Porcentaje == 100)
                ExistePrincipalAlCien = true;

        }
        return ExistePrincipalAlCien;
    }

}
