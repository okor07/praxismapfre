﻿//'****************************************************************************
//'@Author                       : 
//'@version                      : 1.0
//'Development Environment       : Microsoft Visual Studio .Net 2008
//'Name of the file              : uscDataCLM.ascx.cs
//'Creation/Modification History :
//'Description                   :          
//'Modification                  : Marco A. Navarrete C. Indra SWLabs
//'C1                            : 12-05-2014
//                               : Se agregó la propiedad Modalidad para consultar 
//                                 si el producto a emitir es un producto FATCA.
//'*****************************************************************************

using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MapfreMMX.util;

public partial class uscDataCLM : System.Web.UI.UserControl
{
    private string _strTipoUC = "Cont"; //Tambien puede ser Aseg
    private string _strTipoUCOrigen = "Aseg"; //Indica desde qué Control copiará los datos
    public string classTitulo = "letraNormal";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Ajax.Utility.RegisterTypeForAjax(typeof(CLM));
            chkContSol.Attributes.Add("onclick", "copiaContUS('" + _strTipoUCOrigen + "','" + _strTipoUC + "');DatosSeguroCLM(this);");

            btnEnviaDatos.Attributes.Add("onclick", "getGUIDCLM('" + _strTipoUC + "');");
            rdoBusca.Attributes.Add("onclick", "tipBusqueda('" + _strTipoUC + "', this);");

            hdnOrigen.Value = WebUtils.getAppSetting("codOrigen");
            hdnURLCLM.Value = WebUtils.getAppSetting("urlCLM");
        }
    }

    #region "Properties"
    public void LoadCtrl()
    {
        Page_Load(null, null);
    }
    public TipoBeneficiario TipoUC
    {
        set
        {
            hdnCodBenef.Value = ((int)value).ToString();
            _strTipoUC = getTipBenefCorto(value);
        }
    }
    public string ClaveUnica
    {
        get { return lblCLM.Text; }
    }
    public TipoBeneficiario TipoUCOrigen
    {
        set
        {
            _strTipoUCOrigen = getTipBenefCorto(value);
        }
    }
    public TipoBeneficiario[] TipoUCDestinos
    {
        set
        {
            foreach (TipoBeneficiario tipBenef in value)
            {
                hdnFuntion.Value += "LimpiaDependientes('" + _strTipoUC + "','" + getTipBenefCorto(tipBenef) + "');";
            }
        }
    }
    public CheckBox UCchkContSol
    {
        get { return chkContSol; }
        set { chkContSol = value; }
    }
    /// <summary>
    /// Si el Tipo de Gestor es variable se tiene que manejar desde la función <b>getGUIDCLM</b> del archivo de javascript <b>clm.js</b>
    /// </summary>
    public string Gestor
    {
        get { return hdnGestor.Value; }
        set { hdnGestor.Value = value; }
    }
    /// <summary>
    /// Si el Ramo es variable se tiene que manejar desde la función <b>getGUIDCLM</b> del archivo de javascript <b>clm.js</b>
    /// </summary>
    public string Ramo
    {
        get { return hdnRamo.Value; }
        set { hdnRamo.Value = value; }
    }
    /// <summary>
    /// Si el Agente es variable se tiene que manejar desde la función <b>getGUIDCLM</b> del archivo de javascript <b>clm.js</b>
    /// </summary>
    public string Agente
    {
        get { return hdnAgente.Value; }
        set { hdnAgente.Value = value; }
    }
    public string CodigoBenef
    {
        get { return hdnCodBenef.Value; }
        set { hdnCodBenef.Value = value; }
    }
    public string Token
    {
        get { return hdnToken.Value; }
        set { hdnToken.Value = value; }
    }
    public string UsrLogin
    {
        get { return hdnUsrLogin.Value; }
        set { hdnUsrLogin.Value = value; }
    }

    //C1
    /// <summary>
    /// Si el modalidad es variable se tiene que manejar desde la función <b>getGUIDCLM</b> del archivo de javascript <b>clm.js</b>
    /// </summary>
    public string Modalidad
    {
        get { return hdnCodModalidad.Value; }
        set { hdnCodModalidad.Value = value; }
    }
    #endregion "Properties"

    #region "Ver"
    public Boolean veApellidoPaterno
    {
        set
        {
            if (value)
            {
                lblApellidoPaternoT.Style.Add("display", "inline");
                lblApellidoPaterno.Style.Add("display", "inline");
            }
            else
            {
                lblApellidoPaternoT.Style.Add("display", "none");
                lblApellidoPaterno.Style.Add("display", "none");
            }
        }
    }
    public Boolean veApellidoMaterno
    {
        set
        {
            if (value)
            {
                lblApellidoMaternoT.Style.Add("display", "inline");
                lblApellidoMaterno.Style.Add("display", "inline");
            }
            else
            {
                lblApellidoMaternoT.Style.Add("display", "none");
                lblApellidoMaterno.Style.Add("display", "none");
            }
        }
    }
    public Boolean veNombre
    {
        set
        {
            if (value)
            {
                lblNombreT.Style.Add("display", "inline");
                lblNombre.Style.Add("display", "inline");
            }
            else
            {
                lblNombreT.Style.Add("display", "none");
                lblNombre.Style.Add("display", "none");
            }
        }
    }
    public Boolean veSexo
    {
        set
        {
            if (value)
            {
                lblSexoT.Style.Add("display", "inline");
                lblSexo.Style.Add("display", "inline");
            }
            else
            {
                lblSexoT.Style.Add("display", "none");
                lblSexo.Style.Add("display", "none");
            }
        }
    }
    public Boolean veNacimiento
    {
        set
        {
            if (value)
            {
                lblNacimientoT.Style.Add("display", "inline");
                lblNacimiento.Style.Add("display", "inline");
            }
            else
            {
                lblNacimientoT.Style.Add("display", "none");
                lblNacimiento.Style.Add("display", "none");
            }
        }
    }
    public Boolean veEdad
    {
        set
        {
            if (value)
            {
                lblEdadT.Style.Add("display", "inline");
                lblEdad.Style.Add("display", "inline");
                lblAnos.Style.Add("display", "inline");
            }
            else
            {
                lblEdadT.Style.Add("display", "none");
                lblEdad.Style.Add("display", "none");
                lblAnos.Style.Add("display", "none");
            }
        }
    }
    public Boolean veEdoCivil
    {
        set
        {
            if (value)
            {
                lblEdoCivilT.Style.Add("display", "inline");
                lblEdoCivil.Style.Add("display", "inline");
            }
            else
            {
                lblEdoCivilT.Style.Add("display", "none");
                lblEdoCivil.Style.Add("display", "none");
            }
        }
    }
    public Boolean veProfesion
    {
        set
        {
            if (value)
            {
                lblProfesionT.Style.Add("display", "inline");
                lblProfesion.Style.Add("display", "inline");
            }
            else
            {
                lblProfesionT.Style.Add("display", "none");
                lblProfesion.Style.Add("display", "none");
            }
        }
    }
    public Boolean veParentesco
    {
        set
        {
            if (value)
            {
                lblParentescoT.Visible = value;
                lblParentesco.Style.Add("visibility", "visible");
            }
            else
            {
                lblParentescoT.Visible = value;
                lblParentesco.Style.Add("visibility", "hidden");
            }
        }
    }
    public Boolean veDireccion
    {
        set
        {
            if (value)
            {
                lblDireccionT.Style.Add("display", "inline");
                lblDireccion.Style.Add("display", "inline");
            }
            else
            {
                lblDireccionT.Style.Add("display", "none");
                lblDireccion.Style.Add("display", "none");
            }
        }
    }
    public Boolean veColonia
    {
        set
        {
            if (value)
            {
                lblColoniaT.Style.Add("display", "inline");
                lblColonia.Style.Add("display", "inline");
            }
            else
            {
                lblColoniaT.Style.Add("display", "none");
                lblColonia.Style.Add("display", "none");
            }
        }
    }
    public Boolean veEdo
    {
        set
        {
            if (value)
            {
                lblEdoT.Style.Add("display", "inline");
                lblEdo.Style.Add("display", "inline");
            }
            else
            {
                lblEdoT.Style.Add("display", "none");
                lblEdo.Style.Add("display", "none");
            }
        }
    }
    public Boolean vePoblacion
    {
        set
        {
            if (value)
            {
                lblPoblacionT.Style.Add("display", "inline");
                lblPoblacion.Style.Add("display", "inline");
            }
            else
            {
                lblPoblacionT.Style.Add("display", "none");
                lblPoblacion.Style.Add("display", "none");
            }
        }
    }
    public Boolean veCP
    {
        set
        {
            if (value)
            {
                lblCPT.Style.Add("display", "inline");
                lblCP.Style.Add("display", "inline");
            }
            else
            {
                lblCPT.Style.Add("display", "none");
                lblCP.Style.Add("display", "none");
            }
        }
    }
    public Boolean veTelefono
    {
        set
        {
            if (value)
            {
                lblTelefonoT.Style.Add("display", "inline");
                lblTelefono.Style.Add("display", "inline");
            }
            else
            {
                lblTelefonoT.Style.Add("display", "none");
                lblTelefono.Style.Add("display", "none");
            }
        }
    }
    public Boolean veCorreo
    {
        set
        {
            if (value)
            {
                lblCorreoT.Style.Add("display", "inline");
                lblCorreo.Style.Add("display", "inline");
            }
            else
            {
                lblCorreoT.Style.Add("display", "none");
                lblCorreo.Style.Add("display", "none");
            }
        }
    }
    public Boolean veCelular
    {
        set
        {
            if (value)
            {
                lblCelularT.Style.Add("display", "inline");
                lblCelular.Style.Add("display", "inline");
            }
            else
            {
                lblCelularT.Style.Add("display", "none");
                lblCelular.Style.Add("display", "none");
            }
        }
    }
    public Boolean veRFC
    {
        set
        {
            if (value)
            {
                lblRFCT.Style.Add("display", "inline");
                lblRFC.Style.Add("display", "inline");
            }
            else
            {
                lblRFCT.Style.Add("display", "none");
                lblRFC.Style.Add("display", "none");
            }
        }
    }
    public Boolean veCURP
    {
        set
        {
            if (value)
            {
                lblCURPT.Style.Add("display", "inline");
                lblCURP.Style.Add("display", "inline");
            }
            else
            {
                lblCURPT.Style.Add("display", "none");
                lblCURP.Style.Add("display", "none");
            }
        }
    }
    public Boolean veActividad
    {
        set
        {
            if (value)
            {
                lblActividadT.Style.Add("display", "inline");
                lblActividad.Style.Add("display", "inline");
            }
            else
            {
                lblActividadT.Style.Add("display", "none");
                lblActividad.Style.Add("display", "none");
            }
        }
    }
    public Boolean veRepresentante
    {
        set
        {
            if (value)
            {
                lblRepresentanteT.Style.Add("display", "inline");
                lblRepresentante.Style.Add("display", "inline");
            }
            else
            {
                lblRepresentanteT.Style.Add("display", "none");
                lblRepresentante.Style.Add("display", "none");
            }
        }
    }
    public Boolean veCargo
    {
        set
        {
            if (value)
            {
                lblCargoT.Style.Add("display", "inline");
                lblCargo.Style.Add("display", "inline");
            }
            else
            {
                lblCargoT.Style.Add("display", "none");
                lblCargo.Style.Add("display", "none");
            }
        }
    }
    public Boolean veNacionalidad
    {
        set
        {
            if (value)
            {
                lblNacionalidadT.Style.Add("display", "inline");
                lblNacionalidad.Style.Add("display", "inline");
            }
            else
            {
                lblNacionalidadT.Style.Add("display", "none");
                lblNacionalidad.Style.Add("display", "none");
            }
        }
    }
    public bool veFacturar
    {
        set
        {
            if (value)
            {
                lblFacturar.Style.Add("display", "inline");
                rdoFacturarSi.Style.Add("display", "inline");
                divFacturar.Style.Add("display", "inline");
            }
            else
            {
                lblFacturar.Style.Add("display", "none");
                rdoFacturarSi.Style.Add("display", "none");
                divFacturar.Style.Add("display", "none");
            }
        }
    }
    #endregion "Ver"

    /// <summary>
    /// Propiedad para correr una funcion propia de cada aplicacion
    /// despues de obtener los datos del cliente
    /// </summary>
    public string AfterScript_DatosCLM
    {
        set { hdnFuntion.Value += value; }
    }
    /// <summary>
    /// Propiedad para correr una funcion propia de cada aplicacion
    /// para validar el cliente que se recupero en la consulta.
    /// </summary>
    public string validaConsultaScript
    {
        set { hdnValidaConsulta.Value += value; }
    }
    /// <summary>
    /// Propiedad para correr una funcion propia de cada aplicacion
    /// al tratar de copiar los datos del cliente.
    /// </summary>
    public string validaCopiaScript
    {
        set { hdnValidaCopia.Value += value; }
    }

    private string getTipBenefCorto(TipoBeneficiario TipBenef)
    {
        string benef = "";
        switch (TipBenef)
        {
            case TipoBeneficiario.Asegurado:
                benef = "Aseg";
                break;
            case TipoBeneficiario.Beneficiario:
                benef = "Benef";
                break;
            case TipoBeneficiario.Conductor:
                benef = "Cond";
                break;
            case TipoBeneficiario.Contratante:
                benef = "Cont";
                break;
            case TipoBeneficiario.YO:
                benef = "YO";
                break;
        }
        return benef;
    }

    public void generaToken(object usuario) 
    {
        string usr = "";
        string usrType = "";
        if (usuario != null)
        {
            Usuario objUsuario = ((Usuario)usuario);
            usr = objUsuario.USUARIO.Length > 8 ? objUsuario.USUARIO.Substring(0, 8) : objUsuario.USUARIO;
            usrType = objUsuario.TIPO_USUARIO.ToString();
        }
        else throw new Exception("Ha expirado la sesión");

        hdnUsrLogin.Value = usr;
        hdnUsrTypeLogin.Value = usrType;
        hdnToken.Value = usr + "_" + Request.UserHostAddress.Replace('.', '_');
    }
}

public enum TipoBeneficiario
{
    Contratante = 0,
    YO = 1,
    Asegurado = 2,
    Conductor = 3,
    Beneficiario = 5
}
