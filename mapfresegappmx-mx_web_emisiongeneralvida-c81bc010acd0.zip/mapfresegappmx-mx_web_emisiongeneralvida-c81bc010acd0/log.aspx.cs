﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using MapfreMMX.util;

public partial class log : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnDownload_Click(object sender, EventArgs e)
    {
        if (WebUtils.getAppSetting("ConsultarLog") == "S")
        {
            string strFilePath = WebUtils.getAppSetting("LOG_PATH") + "/AppLog.log";
            try
            {
                MLogFile.getInstance().Close();

                Response.ContentType = "text/plain";
                Response.AddHeader("content-disposition", "attachment; filename=AppLog.log");
                Response.BinaryWrite(File.ReadAllBytes(@strFilePath));
                Response.Flush();
                Response.Close();
            }
            catch (Exception ex)
            {
                Response.ClearHeaders();
                Response.ClearContent();

                Exception Inner = null;
                lblError.Text = ex.Message;
                lblError.Text += ex.StackTrace;

                Inner = ex.InnerException;
                while (Inner != null)
                {
                    lblError.Text += Inner.ToString();
                    Inner = Inner.InnerException;
                }
            }
        }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        if (WebUtils.getAppSetting("ConsultarLog") == "S")
        {
            MLogFile.Path = WebUtils.getAppSetting("LOG_PATH");
            MLogFile.getInstance().clearAndBackupLog();
            MLogFile.getInstance().writeText("Se crea respaldo : " + DateTime.Now.ToString("yyMMdd-HHmmss-") + "AppLog.log");
        }
    }
}
