﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Impresion_ImpCont : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Ajax.Utility.RegisterTypeForAjax(typeof(MetodosAjax));

        String num_poliza = Request.QueryString["poliza"];
        String ramo = Request.QueryString["ramo"];
        String fecha = Request.QueryString["fec_emis"];
        String ciudad = Request.QueryString["ciudad"];
        String pago = Request.QueryString["cobro"];

        if (ramo == "111")
        {
            btnAceptar.Attributes.Add("onClick", "getPoliza();");
        }
        else
        {
            if (pago == "UL")
            {
                btnAceptar.Attributes.Add("onClick", "getPolizaUL();");
            }
            else
            {
                if (pago == "L")
                {
                    btnAceptar.Attributes.Add("onClick", "getPolizaULIND();cierraventana();");
                }
                else
                {
                    btnAceptar.Attributes.Add("onClick", "getPolizaULINDR();cierraventana();");
                }

                Session["cobro"] = pago;
            }
        }
        Session["Num_poliza"] = num_poliza;
        Session["Num_ramo"] = ramo;
        Session["Fec_emis"] = fecha;
        Session["Ciudad"] = ciudad;
    }
}