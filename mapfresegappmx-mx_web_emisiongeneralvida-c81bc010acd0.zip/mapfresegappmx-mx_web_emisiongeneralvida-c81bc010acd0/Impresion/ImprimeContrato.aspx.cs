﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using Oracle.DataAccess.Client;
using MapfreMMX.oracle;
using System.Data;
using System.Globalization;
using System.Text;
using System.Configuration;
using System.Net;
using System.Xml;
using System.IO;
//using iTextSharp.text.pdf;

public partial class Impresion_ImprimeContrato : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String num_poliza = Session["Num_poliza"].ToString();
        String ramo = Session["Num_ramo"].ToString();//Request.QueryString["ramo"];
        String fecha = Session["Fec_emis"].ToString();// Request.QueryString["fec_emis"];        
        String ciudad = Session["Ciudad"].ToString();//Request.QueryString["ciudad"];
        String contrato = "";
        String xml = "";
        string sPubFile = "";
        if (ramo == "111")
        {
            contrato = getContratoPPR(num_poliza);
            sPubFile = ConfigurationManager.AppSettings["PubFileCont"];
        }
        //Unit Linked
        else
        {
            contrato = getContratoUL(num_poliza);
            sPubFile = ConfigurationManager.AppSettings["PubFileContUL"];
        }
        xml = ArmaXML(ramo, num_poliza, fecha, contrato, ciudad);
        var bytes = Encoding.UTF8.GetBytes(xml);
        var base64 = Convert.ToBase64String(bytes);

        HttpWebRequest request = CreateWebRequest();
        XmlDocument soapEnvelopeXml = new XmlDocument();
        byte[] yourByteArray = null;

        soapEnvelopeXml.LoadXml(@"<soapenv:Envelope xmlns:eng=""urn:hpexstream-services/Engine"" xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"">
                                       <soapenv:Header>
                                          <wsse:Security soapenv:mustUnderstand=""0"" xmlns:wsse=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"" xmlns:wsu=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"">
                                             <wsse:UsernameToken wsu:Id=""UsernameToken-1"">
                                                <wsse:Username>" + ConfigurationManager.AppSettings["userHP"] + @"</wsse:Username>
                                                <wsse:Password Type=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText"">" + ConfigurationManager.AppSettings["passHP"] + @"</wsse:Password>
                                                <wsse:Nonce EncodingType=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary"">9XbhOoet06M5XXD83sgM7Q==</wsse:Nonce>
                                                <wsu:Created>2015-07-21T08:23:30.207Z</wsu:Created>
                                             </wsse:UsernameToken>
                                          </wsse:Security>
                                       </soapenv:Header>
                                       <soapenv:Body>
                                          <eng:Compose>
                                             <EWSComposeRequest>
                                                <driver>
                                                   <!--Fichero de datos en Base64-->
                                                   <driver>" + base64 + @"</driver>
                                                   <fileName>INPUT</fileName>
                                                </driver>
                                                <engineOptions>
                                                   <name>IMPORTDIRECTORY</name>
                                                   <value>/var/opt/exstream/pubs</value>
                                                </engineOptions>
                                                <engineOptions>
                                                   <!--Ruta donde se encuentra fichero de referencias-->
                                                   <!--A su vez, el fichero contiene ruta a recursos-->
                                                   <name>FILEMAP</name>
                                                   <value>REFERENCIAS,/mnt/HP_Exstream/pubs/EMISION_VIDA/REFERENCIAS.ini</value>
                                                </engineOptions>
                                                <!--Optional:-->
                                                <pubFile>" + sPubFile + @"</pubFile>
                                             </EWSComposeRequest>
                                          </eng:Compose>
                                       </soapenv:Body>
                                    </soapenv:Envelope>");

        using (Stream stream = request.GetRequestStream())
        {
            soapEnvelopeXml.Save(stream);
        }
        using (WebResponse wresponse = request.GetResponse())
        {
            using (StreamReader rd = new StreamReader(wresponse.GetResponseStream()))
            {
                string soapResult = rd.ReadToEnd();
                int iCadenaIni = soapResult.IndexOf("<fileOutput>") + 12;
                int iCadenaFin = soapResult.IndexOf("</fileOutput>");

                string sFileOutput = soapResult.Substring(iCadenaIni, (iCadenaFin - iCadenaIni));
                yourByteArray = Convert.FromBase64String(sFileOutput);
                System.IO.FileStream stream = new FileStream(@"C:\Temp\Contrato" + num_poliza + ".pdf", FileMode.CreateNew);
                System.IO.BinaryWriter writer = new BinaryWriter(stream);
                writer.Write(yourByteArray, 0, yourByteArray.Length);
                writer.Close();
                MuestraPDF(this, stream.Name);
            }
        }        

    }
    public string getContratoPPR(string num_poliza)//80
    {        
        MCommand cmd = new MCommand();
        DataRow objRow = null;
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "Tron2000.EV_K_PRODUCTOS_VIDA_MMX.p_obtiene_num_contrato_ppr";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Int32, 1);
                cmd.agregarINParametro("p_num_poliza",OracleDbType.Varchar2,num_poliza);
                cmd.agregarINParametro("p_num_spto",OracleDbType.Int32,0);
                cmd.agregarOUTParametro("p_num_contrato_ppr",OracleDbType.Varchar2,80);
                objRow=cmd.ejecutarRegistroSP();
                return objRow["p_num_contrato_ppr"].ToString();   
            }
        }
        catch (Exception ex)
        {
            throw new Exception("Error ImprimeContrato.getContrato():  "+ ex.Message);
            MapfreMMX.util.MLogFile.getInstance().writeText("Error ImprimeContrato.getContrato():  " + ex.Message);
        }        
    }
   public String ArmaXML(String ramo, String poliza,String fecha, String contrato, String ciudad)
   {
       String[] fechas;
       fechas = fecha.Split('/');
       XElement Root= new XElement("ROOT");
       Root.Add(new XElement("COMPANIA", "1"));
       Root.Add(new XElement("RAMO",ramo));
       Root.Add(new XElement("ACTIVIDAD", "EMISION"));
       Root.Add(new XElement("IDIOMA", "mx_ES"));
       //Distribución
       XElement Distribucion = new XElement("DISTRIBUCION");
       Distribucion.Add(new XElement("DUPLEX_MODE","FALSE"));
       Distribucion.Add(new XElement("LOCAL","TRUE"));
       Root.Add(Distribucion);
       //Cabecera
       XElement Cabecera = new XElement("CABECERA");
        if (ramo == "111")
        {
            Cabecera.Add(new XElement("CONTENIDO", "EV_CONTRATO_PPR_MILLON_VIDA.rtf"));
        }
        else
        {
            Cabecera.Add(new XElement("CONTENIDO", "EV_CONTRATO_PPR_UNIT_LINKED_VIDA.rtf"));
        }
       //Convierte no. a mes
       DateTimeFormatInfo mes = new CultureInfo("es-ES", false).DateTimeFormat;
       String mes_letra = mes.GetMonthName(Convert.ToInt32(fechas[1]));
       Cabecera.Add(new XElement("EV_AVISOS_VI_DIA", fechas[0]));
       Cabecera.Add(new XElement("EV_AVISOS_VI_MES",mes_letra));
       Cabecera.Add(new XElement("EV_AVISOS_VI_ANIO",fechas[2]));
       Cabecera.Add(new XElement("EV_AVISOS_VI_CIUDAD",ciudad));
       Root.Add(Cabecera);
        //Pie
        XElement Pie = new XElement("PIE");
        if (ramo == "111")
        {
            
            Pie.Add(new XElement("FIRMA", "FIRMA_RESPONSABLE_VIDA_PPR.jpg"));
            Pie.Add(new XElement("NUM_CONTRATO", contrato));
        }
        else
        {
            Pie.Add(new XElement("FIRMA1", "FIRMA_RESPONSABLE_VIDA_I.jpg"));
            Pie.Add(new XElement("FIRMA2", "FIRMA_RESPONSABLE_VIDA_II.jpg"));
            Pie.Add(new XElement("NUM_CONTRATO", contrato));
        }
       Root.Add(Pie);

       return Root.ToString();
   }
   public static HttpWebRequest CreateWebRequest()
   {
       string RutaURL = ConfigurationManager.AppSettings["URLWSHpExtream"];

       HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(RutaURL);
       webRequest.Headers.Add(@"SOAP:Action");
       webRequest.ContentType = "text/xml;charset=\"utf-8\"";
       webRequest.Accept = "text/xml";
       webRequest.Method = "POST";
       return webRequest;
   }
   protected void MuestraPDF(Page parent, string sArchivo)
   {       
       parent.Response.Clear();
       parent.Response.ClearContent();
       parent.Response.ClearHeaders();
       parent.Response.ContentType = "application/pdf";
       parent.Response.TransmitFile(sArchivo);
       //parent.Response.End();
       HttpContext.Current.ApplicationInstance.CompleteRequest();
       //envía todo al cliente
       System.Threading.Thread.Sleep(5000);
       parent.Response.Flush();       
       //Elimina el archivo pdf de la cotización
       System.IO.File.Delete(sArchivo);

   }

    public string getContratoUL(string num_poliza)//80
    {
        MCommand cmd = new MCommand();
        DataRow objRow = null;
        string campo = "NUM_CONTRATO_PPR";
        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "tron2000.ev_k_poliza_gral_mmx.f_dato_variable";
                cmd.agregarRETURNParametro("result", OracleDbType.Varchar2, 80);
                cmd.agregarINParametro("p_cod_campo", OracleDbType.Varchar2, campo);
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, num_poliza);
                cmd.agregarINParametro("p_entorno", OracleDbType.Int32, 1);                
                objRow = cmd.ejecutarRegistroSP();

                return objRow["result"].ToString();
            }
        }
        catch (Exception ex)
        {
            throw new Exception("Error ImprimeContrato.getContratoUL():  " + ex.Message);
            MapfreMMX.util.MLogFile.getInstance().writeText("Error ImprimeContrato.getContratoUL():  " + ex.Message);
        }
    }
}