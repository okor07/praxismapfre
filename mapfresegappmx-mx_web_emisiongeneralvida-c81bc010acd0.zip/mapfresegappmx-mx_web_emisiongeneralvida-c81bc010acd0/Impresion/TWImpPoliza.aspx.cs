﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Impresion_TWImpPoliza : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string strCliente = Request.QueryString["Cliente"].ToString();
        string strRamo = Request.QueryString["Ramo"].ToString();

        try
        {
            Page objPage = new Page();
            objPage.AppRelativeVirtualPath = "~/Impresion/iFrameImp.aspx";

            MapfreMMX.util.Impresion objImpresion = new MapfreMMX.util.Impresion();
            objImpresion.AgregaParametro("NombreCliente", strCliente);
            objImpresion.GeneraPDF(objPage, "CotizacionRamo210-ProteccionSegura");
            //string strXml = objImpresion.ObtieneXML("NombreDeLaPlantilla");
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
    }
}
