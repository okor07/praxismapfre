﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Impresion_ImpConstancia : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Ajax.Utility.RegisterTypeForAjax(typeof(MetodosAjax));

        String num_poliza = Request.QueryString["poliza"];
        String ramo = Request.QueryString["ramo"];

        btnAceptar.Attributes.Add("onClick", "cierraventana()");

        Session["Num_poliza"] = num_poliza;
    }
}