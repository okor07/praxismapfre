﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using Oracle.DataAccess.Client;
using MapfreMMX.oracle;
using System.Data;
using System.Globalization;
using System.Text;
using System.Configuration;
using System.Net;
using System.Xml;
using System.IO;
using MapfreMMX.util;

//using iTextSharp.text.pdf;

public partial class Impresion_ImprimeConstancia : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String num_poliza = Session["Num_poliza"].ToString();        
        String xml = "";
        string sPubFile = WebUtils.getAppSetting("pubconstancia");//constancia PPR
        string cia = "1";

        xml = obtienexmlconstancia(cia, num_poliza, "CP");
        var bytes = Encoding.UTF8.GetBytes(xml);
        var base64 = Convert.ToBase64String(bytes);

        HttpWebRequest request = CreateWebRequest();
        XmlDocument soapEnvelopeXml = new XmlDocument();
        byte[] yourByteArray = null;

        soapEnvelopeXml.LoadXml(@"<soapenv:Envelope xmlns:eng=""urn:hpexstream-services/Engine"" xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"">
                                       <soapenv:Header>
                                          <wsse:Security soapenv:mustUnderstand=""0"" xmlns:wsse=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"" xmlns:wsu=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"">
                                             <wsse:UsernameToken wsu:Id=""UsernameToken-1"">
                                                <wsse:Username>" + ConfigurationManager.AppSettings["userHP"] + @"</wsse:Username>
                                                <wsse:Password Type=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText"">" + ConfigurationManager.AppSettings["passHP"] + @"</wsse:Password>
                                                <wsse:Nonce EncodingType=""http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary"">9XbhOoet06M5XXD83sgM7Q==</wsse:Nonce>
                                                <wsu:Created>2015-07-21T08:23:30.207Z</wsu:Created>
                                             </wsse:UsernameToken>
                                          </wsse:Security>
                                       </soapenv:Header>
                                       <soapenv:Body>
                                          <eng:Compose>
                                             <EWSComposeRequest>
                                                <driver>
                                                   <!--Fichero de datos en Base64-->
                                                   <driver>" + base64 + @"</driver>
                                                   <fileName>INPUT</fileName>
                                                </driver>
                                                <engineOptions>
                                                   <name>IMPORTDIRECTORY</name>
                                                   <value>/var/opt/exstream/pubs</value>
                                                </engineOptions>
                                                <engineOptions>
                                                   <!--Ruta donde se encuentra fichero de referencias-->
                                                   <!--A su vez, el fichero contiene ruta a recursos-->
                                                   <name>FILEMAP</name>
                                                   <value>REFERENCIAS,/mnt/HP_Exstream/pubs/EMISION_VIDA/REFERENCIAS.ini</value>
                                                </engineOptions>
                                                <!--Optional:-->
                                                <pubFile>" + sPubFile + @"</pubFile>
                                             </EWSComposeRequest>
                                          </eng:Compose>
                                       </soapenv:Body>
                                    </soapenv:Envelope>");

        using (Stream stream = request.GetRequestStream())
        {
            soapEnvelopeXml.Save(stream);
        }

        using (WebResponse wresponse = request.GetResponse())
        {
            using (StreamReader rd = new StreamReader(wresponse.GetResponseStream()))
            {
                string soapResult = rd.ReadToEnd();
                int iCadenaIni = soapResult.IndexOf("<fileOutput>") + 12;
                int iCadenaFin = soapResult.IndexOf("</fileOutput>");

                string sFileOutput = soapResult.Substring(iCadenaIni, (iCadenaFin - iCadenaIni));
                yourByteArray = Convert.FromBase64String(sFileOutput);
                System.IO.FileStream stream = new FileStream(@"C:\Temp\Contrato" + num_poliza + ".pdf", FileMode.CreateNew);
                System.IO.BinaryWriter writer = new BinaryWriter(stream);
                writer.Write(yourByteArray, 0, yourByteArray.Length);
                writer.Close();
                MuestraPDF(this, stream.Name);
            }
        }
    }

    public static HttpWebRequest CreateWebRequest()
    {
        string RutaURL = ConfigurationManager.AppSettings["URLWSHpExtream"];

        HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(RutaURL);
        webRequest.Headers.Add(@"SOAP:Action");
        webRequest.ContentType = "text/xml;charset=\"utf-8\"";
        webRequest.Accept = "text/xml";
        webRequest.Method = "POST";
        return webRequest;
    }

    protected void MuestraPDF(Page parent, string sArchivo)
    {
        parent.Response.Clear();
        parent.Response.ClearContent();
        parent.Response.ClearHeaders();
        parent.Response.ContentType = "application/pdf";
        parent.Response.TransmitFile(sArchivo);
        //parent.Response.End();
        HttpContext.Current.ApplicationInstance.CompleteRequest();
        //envía todo al cliente
        System.Threading.Thread.Sleep(5000);
        parent.Response.Flush();
        //Elimina el archivo pdf de la cotización
        System.IO.File.Delete(sArchivo);

    }

    public string obtienexmlconstancia(string cia, string poliza, string tipo)
    {
        MCommand cmd = new MCommand();
        DataRow dr;
        decimal dNumSpto = 0;

        try
        {
            using (OracleConnection conexion = MConexion.getConexion("ConnectionTW"))
            {
                cmd.Connection = conexion;
                cmd.CommandText = "TRON2000.em_k_imp_gral_mmx.p_imprime_poliza";
                cmd.agregarINParametro("p_cod_cia", OracleDbType.Decimal, Convert.ToDecimal(cia));
                cmd.agregarINParametro("p_num_poliza", OracleDbType.Varchar2, poliza);
                cmd.agregarINParametro("p_num_spto", OracleDbType.Decimal, dNumSpto);
                cmd.agregarINParametro("p_tip_emision", OracleDbType.Varchar2, tipo);
                cmd.agregarOUTParametro("p_xml", OracleDbType.Clob, 32000);
                cmd.agregarOUTParametro("p_error", OracleDbType.Varchar2, 500);

                dr = cmd.ejecutarRegistroSP();

                if (dr["p_error"].ToString() == "")
                {
                    return dr["p_xml"].ToString();
                }
                else
                {
                    return "Error:" + dr["p_error"].ToString();
                }
            }
        }
        catch (Exception ex)
        {
            {
                throw new Exception("Error ImprimeConstancia.obtienexmlconstancia():  " + ex.Message);
                MapfreMMX.util.MLogFile.getInstance().writeText("Error ImprimeConstancia.obtienexmlconstancia():  " + ex.Message);
            }
        }
    }
}